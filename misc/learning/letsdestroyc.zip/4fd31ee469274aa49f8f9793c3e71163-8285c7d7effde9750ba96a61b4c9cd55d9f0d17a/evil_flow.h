
#ifndef EVIL_NO_FLOW
  // Included by default
  
  #define then ){
  #define end }
  #define If if(
  #define Else } else {
  #define For for(
  #define While while(
  #define Do do{
  #define Switch(x) switch(x){
  #define Case(x) case x:
#endif