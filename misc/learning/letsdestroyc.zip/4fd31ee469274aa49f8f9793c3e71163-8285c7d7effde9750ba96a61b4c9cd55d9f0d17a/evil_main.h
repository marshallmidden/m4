

#ifndef EVIL_NO_MAIN
  // Included by default
  #define Main int main(int __attribute__((unused)) argc, char __attribute__((unused)) **argv
#endif