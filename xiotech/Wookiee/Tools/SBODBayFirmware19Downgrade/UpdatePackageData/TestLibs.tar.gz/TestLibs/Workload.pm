#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library
#
#   20/12/2005  XIOtech   Gopinadh Anasuri
#
#   A set of library functions for integration testing. 
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2004-2005 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::Workload - Perl Tests to test Backend and FrontEnd WorkLoad ( and some redi-copy )

$Id: Workload.pm 13380 2006-09-05 18:44:01Z DavisB $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing the WorkLoad on backend 
and frontend of the controllers. Much of this is testing in a two-way
environment.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

               WorkLoadMain
               BEWorkload1
               BEWorkload2
               BEWorkload3
               FEBEWorkLoad 
        The less significant ones
               None   

=cut

#
# - what I am
#

package TestLibs::Workload;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;

use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;
use TestLibs::Cleanuplib;
use TestLibs::iscsi;

use strict;

# Constants used

use constant WL_DONTCHECKBE     =>  0;
use constant WL_CHECKBE         =>  1;

#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 13380 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker


    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &WorkLoadMain
                        &BEWorkload1
                        &BEWorkload2
                        &BEWorkload3
                        &FEBEWorkLoad
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 13380 $);
}
    our @EXPORT_OK;

##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $objPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.


 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.


=back

=cut


###############################################################################

###############################################################################

=head2 WorkloadMain function

This subroutine is the entry point for the workload test. this subroutine holds the
calls to the subroutines which perform the neccessary operations for testing the BE 
and FE.

Test Steps ...

     1) collect system information
     2) call BEWorkload1 subroutine
     3) call BEWorkload2 subroutine 
     4) call BEWorkload3 subroutine
     5) Compute elapsed time for BE activity
     6) Break Mirrors created for the test
     7) call LipFEPort subroutine without any load on BE
     8) confirm IO still Ok

Now Combine both FE and BE process activity
    
     9) call BEWorkload1 to prepare intial setup
    10) call BEWorkload2 
    11) call LipFEPort subroutine with BE process
    12) Compute elapsed time for FE activity
    13) Compare BE and FE duration 
    14) Break Mirrors created for the test
    15) confirm IO
    16) start defrag all
    17) confirm IO
    18) Do mirror state validation

=cut

=over 1

=item Usage:

 my $rc = WorkloadMain( $objPtr, $snPtr, $ipPtr, $case (optional), $loopcount (optional) );
 
 where: $objPtr is a pointer to a list of controller objects
        $snPtr  is a pointer to a list of controller serial numbers
        $ipPtr is a pointer to ip addresses
        $case is an optional parameter
        $loopcount is number of loops test has to be run

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.

 There should be no defrag, copy, or init operation running when the test 
 is started. 


=back

=cut
##############################################################################
#
#          Name: WorkloadMain
#
#        Inputs: controller, ip addr
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine is the entry point for the workload test. 
#                this subroutine invokes respective subroutine as required by 
#                the test.
#
##############################################################################
sub WorkLoadMain
{
    trace();

    my ( $objPtr, $snPtr, $ipPtr, $case, $loop ) = @_;

    my $i = 0;
    my $ret;
    my $master;
    my $ctlr;
    my $bestarttime;
    my $beendtime;
    my $lipstarttime;
    my $lipendtime;
    my $betotaltime;
    my $liptotaltime;
    my $fidreadbegintime;
    my $fidreadendtime;
    my $fidreadtotaltime;
    my $waittime;
    my $fetimeout;
    my $becomplete = 0;
    my $loopcount = 0;
    my $numCtlrs = 0;
    my @coList;
    my @srcVdiskList;
    my @destVdiskList;
    my @origVdiskList;
    my @origMirrorList;
    my @serialNums;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my %mirrorData;
    my $msg;
    my $msg0;
    my %data;
    my %data1;
    my %data2;
    my %rsp;

    @coList = @$objPtr;
    
    $msg = "-------------------- Test Case : Workload test begin ---------------------------";
    $msg0 = "-------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 


    $ctlr = $coList[$master];
    
    #
    # We collect data that will be used later for test validation. 
    # The data collected is BE status arrays and FE I/O performance data.  
    #
    
    # Show the current BE configuration
    DispVdiskInfo($ctlr);
    
    # Get measure of the current IO
    $ret = VerifyIOGather($objPtr, $snPtr, $master, \@activeServers, \@initialVdisks, \@tMap, 20, 10);

    # Get the BE DATA
    MirrorInitialData($objPtr, \%mirrorData);
    
    # This creates the conditions needed for the test. We create several mirrors
    # and prepare for several copy/swap operations. Two of the copy/swaps are done 
    # to guarantee fragmentation.

    $ret = BEWorkload1($objPtr, $ipPtr, \@srcVdiskList, \@destVdiskList, \@origVdiskList, \@origMirrorList);
    if ( $ret != GOOD ) { return ERROR; }

  
    #
    # This start major BE activity by resuming several 
    # mirrors and starting the defrags. It also starts the remaining copy/swap
    # operations.
    #

    $ret = BEWorkload2($objPtr, \@srcVdiskList, \@destVdiskList, \@origVdiskList);
    if ( $ret != GOOD ) { return ERROR; }

    # refresh any connections
    TestNReconnectAll($objPtr);    
    
    DispVdiskInfo($ctlr);

    #
    # As long as copy/swaps are runnng and defrag has
    # work to do, this function keeps defrag running and deleted source vdisks
    # as the copies finish. The operation is timed. We are characterizing
    # operation with only the BE process doing extra work.
    #
    $bestarttime = time();
    
    do 
    {
        $ret = BEWorkload3($objPtr, \@destVdiskList);
        if ( $ret == ERROR ) { return ERROR; }
        
        #
        # Check to see if the CCB is getting serviced
        # The goal is to make sure the system stays functional when there is a 
        # lot of activity on the FE and BE processes.
        #
        $fidreadbegintime = time();
        
        for ($i = 0; $i < 10; $i++) 
        {
            print "reading FID 280 \n";
            
            %data = $ctlr->MPXReadFID(280);
            
            print "reading FID 281 \n";
            
            %data1 = $ctlr->MPXReadFID(281);
            
            print "reading FID 282 \n";
            
            %data2 = $ctlr->MPXReadFID(282);
            
            if ( (! %data) || (! %data1) || (! %data2 ) )    # Return error if one of calls fails to return
            {
                logInfo(">>>>>>>> Failed to get response from ReadFID <<<<<<<<");
                return ERROR;
            }
            
            if ( ( $data{STATUS} != PI_GOOD ) 
                ||( $data1{STATUS} != PI_GOOD ) 
                || ( $data2{STATUS} != PI_GOOD )
           )      # Return error if any one call fails
            {
                logInfo(">>>>>>>> Error from ReadFID <<<<<<<<");
                PrintError(%data);
                return ERROR;
            }
   
            # Capture and log the log messages on to XTC log file  
            
            %rsp = $ctlr->logInfo(100, 0x10, 0);
   
            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from logInfo <<<<<<<<");
                return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from logInfo <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }
            
            # 
            # This routines writes the debug messages on to XTC log file.
            # User needs to verify the log file if there are any errors present manually.
            #
 
            logLogInfo(0, 0, %rsp);          
        }  
        
        $fidreadendtime = time();
        
    } while  ($ret != INVALID);   # Invalid indicates we are done.


    #
    # compute fidread time
    #
    $fidreadtotaltime = $fidreadendtime - $fidreadbegintime;  
    
    logInfo(" Total time taken for fidreads with BE only = $fidreadtotaltime\n " );
    
    #
    # compute elapsed time
    #

    $beendtime = time();
    $betotaltime  = $beendtime - $bestarttime;
    logInfo ( " Total time taken for backend = $betotaltime\n " );
   
    #
    # Remove the mirrors created by the test.
    #
    
    $ret = CleanupMirrors($ctlr, \@origMirrorList);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Now we do the FE process load only. There is no extra load on the BE process. 
    # We run this for the same time as the BE test used.
    #
    
    # refresh any connections
    TestNReconnectAll($objPtr);    
        
    $ret = FEBEWorkLoad ($objPtr, WL_DONTCHECKBE, $betotaltime, $loopcount, \@destVdiskList, \$becomplete);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # We make sure that the I/O has not been interrupted.
    #
    $ret = VerifyIO( $objPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Now test will be run by combining both FE and BE process activity.
    #
    
    # first the call to prepare
    $ret = BEWorkload1($objPtr, $ipPtr, \@srcVdiskList, \@destVdiskList, \@origVdiskList);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = BEWorkload2($objPtr, \@srcVdiskList, \@destVdiskList, \@origVdiskList);
    if ( $ret != GOOD ) { return ERROR; }
    
    # refresh any connections
    TestNReconnectAll($objPtr);    

    # Now run the load for twice the time required for just the BE
    
    $becomplete = 0;
    $fetimeout = 2 * $betotaltime;
    $fetimeout = $fetimeout + time();
    $lipstarttime = time();
   
    while ( $fetimeout > time() )
    {
        $ret = FEBEWorkLoad ($objPtr, WL_CHECKBE, 10, $loopcount, \@destVdiskList, \$becomplete );
        if ( $ret != GOOD ) { return ERROR; }
       
        $fidreadbegintime = time();
        
      for ($i = 0; $i < 10; $i++) 
      {
            print "reading FID 280 \n";
            
            %data = $ctlr->MPXReadFID(280);
            
            print "reading FID 281 \n";
            
            %data1 = $ctlr->MPXReadFID(281);
            
            print "reading FID 282 \n";
            
            %data2 = $ctlr->MPXReadFID(282);
            
            if ( (! %data) || (! %data1) || (! %data2 ) )              # if no return from any one call
            {
                logInfo(">>>>>>>> Failed to get response from ReadFID <<<<<<<<");
                return ERROR;
            }
            
            if ( ( $data{STATUS} != PI_GOOD ) 
                ||( $data1{STATUS} != PI_GOOD ) 
                || ( $data2{STATUS} != PI_GOOD ))      # if any one call returned an error
            {
                logInfo(">>>>>>>> Error from ReadFID <<<<<<<<");
                PrintError(%data);
                return ERROR;
            }
           
            # Capture and log the log messages on to XTC log file  
             
            %rsp = $ctlr->logInfo(100, 0x10, 0);
   
            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from logInfo <<<<<<<<");
                return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from logInfo <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }
 
            # 
            # This routines writes the debug messages on to XTC log file.
            # User needs to verify the log file if there are any errors present manually.
            #
            
            logLogInfo(0, 0, %rsp);
            
       }     
        
        $fidreadendtime = time();
        $fidreadtotaltime = $fidreadendtime - $fidreadbegintime;
        
        if ($becomplete == 1)
        {
           last;
        }
    }
                
     # If we are not actually done with the BE activity. 
     # and  if we just timed out, then there is still a
     # defrag running and maybe some copy/swap operations.
     # We need to wait until they finish (but not start any
     # more work for the BE to do. So, wait for defrag to 
     # finish and wait for all copy/swap operations to be done.
                
    if ( $becomplete == 0 )
    {
        for ( $i = 0; $i < scalar(@destVdiskList); $i++ )
        {
            if ( $destVdiskList[$i] != INVALID)
            {

                $ret = WaitForCpComplete( $ctlr, $destVdiskList[$i] );
                if ( $ret != GOOD ) { return ERROR; }
            }

        }
    }

    logInfo(" Total time taken for fidreads at with FE = $fidreadtotaltime\n " );
    
    # restart defrag
    
    $ret = DefragAllBegin( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }
    
    # refresh any connections
    TestNReconnectAll($objPtr);    
    
    #
    # All the BE work is done, so compute elapsed time
    #
    $lipendtime = time();
    $liptotaltime = $lipendtime - $lipstarttime; 
    
    # We are trying to see if combining the activity on both the FE and BE changed 
    # the time needed to do all the BE work. ideally, it should not. Since we don't 
    # know what to expect at this time, log the data for evaluation.
    
    logInfo(" Time observed during BE activity =  $betotaltime\n  ");
    logInfo(" Time observed during FE activity =  $liptotaltime\n ");
    logInfo(" Total time taken for fidreads  without BE = $fidreadtotaltime\n " );
    
    #
    # We make sure that the I/O has not been interrupted.
    #
    
    $ret = VerifyIO( $objPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Remove the mirrors created by the test.
    #

    $ret = CleanupMirrors($ctlr, \@origMirrorList);
    if ( $ret != GOOD ) { return ERROR; }
    
    #
    # re-start defragging the system after breaking the mirrors
    #

    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }
    
    # refresh any connections
    TestNReconnectAll($objPtr);    
    
    #
    # We make sure that the I/O has not been interrupted.
    # we do this one more time to make sure we cleaned up after the test 
    # successfully.
    #
    $ret = VerifyIO( $objPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }
    
    #
    # verify if pre-existing mirrors are not damaged
    #
    
    $ret = TestEndMirrorCheck($objPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    $msg = "--------------- Test Case : Workload test completed successfully --------------------";
    $msg0 = "-------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);
    
    return GOOD;
}                      

##############################################################################


=head2 BEWorkload1 function

This subroutine adds 40 mirrors and immediately pauses the mirrors, Prepares a 
setup for performing  certain number of copy/swap operations (will create only destination vdisks 
and no copy/swap is done ) Only two copy swaps will be started on first two destination vdisks. 

    Setup  40 Mirrors
    Pause the mirrors
    Setup for copy/swap operations 
    Perform Two Copy/Swap operations

=cut

=over 1

=item Usage:

 my $rc = BEWorkload1( $objPtr,
                       $ipPtr,
                       $srcVdiskListPtr,
                       $destVdiskListPtr,
                       $origVdiskListPtr,
                       $origMirrorListPtr );
 
 where: $objPtr is a pointer to a list of controller objects
        $srcVdiskListPtr is a pointer to list of  copy source vdisks
        $destVdiskListPtr is a pointer to list of copy destination vdisks 
        $origVdiskListPtr is a pointer to list of pre-existing vdisks before the test 
        $origMirrorListPtr is a pointer to list of pre-existing Mirrors before the test 

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.

 There should be no defrag, copy, or init operation running when the test 
 is started. 

=back

=cut

##############################################################################
#
#          Name: BEWorkload1
#
#        Inputs: controller object, IP address, source vdisklist, 
#                destination vdisklist, pre-existing vdisklist,
#                pre-existing mirror list.
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine adds 40 mirrors and immediately pauses the 
#                mirrors, Prepares setup for performing  certain number of 
#                copy/swap operations (will create only destination vdisks and 
#                no copy/swap is done ) Only two copy swaps will be started on 
#                first two destination vdisks.
#
##############################################################################
sub BEWorkload1
{
    trace();

    my ( $objPtr, $ipPtr, $srcVdiskListPtr, $destVdiskListPtr, $origVdiskListPtr, $origMirrorListPtr) = @_;

    my $i;
    my $j;
    my $k = 0;
    my $ret;
    my %rsp;
    my %rsp1;
    my %info;
    my %vdi;
    my @originalVdisks;
    my @baseVdisks;
    my @newVdisks;
    my @newMirrorVdisks;
    my $numBaseVdisksUsed;
    my $baseVdisk;
    my $newVd;
    my $srcVdisk;
    my $baseVdiskIndex;
    my @baseVdisksUsed;
    my @tempVdisks;
    my @objList;
    my @coList;
    my $master;
    my $ctlr;
    my $masterIndex;
    my $count = 0;

    @objList = @$objPtr;
    
    #
    # Find the master controller
    #
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    @coList = @$objPtr;

    $ctlr = $coList[$master];


    
    #
    # Get the VIDs of all the current vdisks
    #
    
    %rsp = $ctlr->virtualDisks();
    
    if ( ! %rsp  )              
    {
       logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
       return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
       TestLibs::IntegCCBELib::PrintError(%rsp);
       return ERROR;
    }
        
    # Get the list of pre-existing vdisks
    
    for ($i = 0; $i < $rsp{COUNT}; $i++)
    {
       $$origVdiskListPtr[$i] = $rsp{VDISKS}[$i]{VID};
    }

    # Get the list of pre-existing mirrors
    
    for ( $i = 0; $i < scalar(@$origVdiskListPtr); $i++ )
    {
      
      #
      # get vdisk info for the disk
      #
      
      %vdi = $ctlr->virtualDiskInfo( $$origVdiskListPtr[$i] );

      if (!%vdi)                        # no response
      {
         logInfo(">>>>> Failed to receive a response from virtualDiskInfo($$origVdiskListPtr[$i]) <<<<<");
         return ERROR;
      }
      elsif ($vdi{STATUS} != 0)            # 0 is good, anything else is bad
      {
         logInfo(">>>>> ERROR: virtualDiskInfo($$origVdiskListPtr[$i]) returned an error <<<<<");
         PrintError(%vdi);
         return ERROR;
      }

      #
      # If vdisk is a mirror dest, add to mirror list 
      #        
      
      if ( $vdi{MIRROR} != 0 ) 
      {
         $$origMirrorListPtr[$count] = $$origVdiskListPtr[$i];
         $count++;
      }
    }

   
    if ( scalar(@$origMirrorListPtr) != 0 )
    {
        logInfo("Pre-existing mirror vdisks: \n@$origMirrorListPtr");
    }
        
    #
    # Remove any vlinks that may exist
    #
    $ret = TestLibs::BEUtils::RemoveVlinks($ctlr, \@$origVdiskListPtr, \@tempVdisks);  
    if ( $ret  != GOOD )      
    {
       logInfo(">>>>>>>> Error from RemoveVlinks <<<<<<<<");
       return ERROR;
    }
        
    #
    # Remove any currently existing mirrors
    #
    $ret = TestLibs::BEUtils::RemoveMirrors($ctlr, \@tempVdisks, \@baseVdisks);  
    if ( $ret  != GOOD )      
    {
       logInfo(">>>>>>>> Error from RemoveMirrors <<<<<<<<");
       return ERROR;
    }

    logInfo("Base vdisks (not vlinks or mirrors): \n@baseVdisks");
                                                      
    logInfo("Adding 40 Mirrors For BE Work Load Test : \n");

    #########################################
    # Add up to 40 mirrors to existing configuration. 
    # All RAID_5 & RAID_10, multiple groups
    # If no RAID_5 vdisks detected, will make all mirrors
    # RAID_10 only.
    #########################################
    
    $ret = &TestLibs::IntegCCBELib::BasicConfig($objPtr, 55, $ipPtr, 0, 30 );
    
    $ret = &TestLibs::IntegCCBELib::BasicConfig($objPtr, 55, $ipPtr, 0, 10 );
      
    # Pause newly created mirrors 
    
    %info = $ctlr->resyncData(1);

    if (%info)
    {
        if ($info{STATUS} == PI_GOOD)
        { 
            for ($i = 0; $i < $info{COUNT}; $i++)
            {
                if ($info{DTLCPY}[$i]{VMIRROR} == 1)
                {       
                    %rsp1 = $ctlr->virtualDiskControl(0x06,$info{DTLCPY}[$i]{RCSDV}, $info{DTLCPY}[$i]{RCDDV});

                    if (!%rsp1)                        # no response
                    {
                        print "\n";
                        logInfo(">>>>> Failed to receive a response from virtualdiskcontrol while pausing <<<<<");
                        return ERROR;
                    }

                    elsif ($rsp1{STATUS}  != PI_GOOD)            # 1 is bad
                    {
                        logInfo("Pausing of mirror disk $info{DTLCPY}[$i]{RCDDV} has Failed. \n");
                        print "\n";
                        TestLibs::IntegCCBELib::PrintError(%rsp1);
                        return ERROR;
                    }
                    else
                    {
                        logInfo("Vdisk Mirror $info{DTLCPY}[$i]{RCDDV} is Paused\n");
                    }
                }
            }   
        } 
        else
        {
            my $msg = "Unable to retrieve the resync data.";
            displayError($msg, %info);
        }
    }  
    else
    {
        print "ERROR: Did not receive a response packet from function resyncData.\n";
        return ERROR;
    } 
    
    #
    # Create replacement vdisks to do copy/swap, as many as present in origVdiskList
    #
    
    for ( $i = 0; $i < scalar(@$origVdiskListPtr); $i++ )
    {
        $newVd =  TestLibs::BEUtils::CreateReplacementVdisk($ctlr, $$origVdiskListPtr[$i] );
        if ( $newVd < 0 ) { return ERROR; }
                    
        $$destVdiskListPtr[$i] = $newVd;
        $$srcVdiskListPtr[$i]  = $$origVdiskListPtr[$i];
    }

    #
    # Start two copy/swap operations, to keep initial gap at the begining
    #
    
    for ( $i = 0; $i < 2; $i++ )
    {
        $ret = TestLibs::BEUtils::RediCpVdisks( $ctlr, $$srcVdiskListPtr[$i], $$destVdiskListPtr[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    #
    # Wait for the copy to complete
    
    for ( $i = 0; $i < 2; $i++ )
    {
        $ret = TestLibs::BEUtils::WaitForCpComplete( $ctlr, $$destVdiskListPtr[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }
    
    return GOOD;
}

###############################################################################

=head2 BEWorkload2 function

This subroutine Unpauses if there are any vdisks paused and starts copy operation 
on the remaining destination vdisks created in BEWorkload1, Then start defrag.

    Unpause the mirrors
    Start copy/swap on remaining vdisks
    Begin Defrag 

=cut

=over 1

=item Usage:

 my $rc = BEWorkload2( $objPtr, 
                       $srcVdiskListPtr, 
                       $destVdiskListPtr, 
                       $origVdiskListPtr );
 
 where: $objPtr is a pointer to a list of controller objects
        $srcVdiskListPtr is a pointer to list of  copy source vdisks
        $destVdiskListPtr is a pointer to list of copy destination vdisks 
        $origVdiskListPtr is a pointer to list of pre-existing vdisks before the test 
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 BEWorkload1 part needs to succesfully run to create initial setup required for the test.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#           Name: BEWorkload2
#
#         Inputs: controller object,  source vdisklist, 
#                 destination vdisklist, pre-existing vdisklist
#
#        Outputs: GOOD, if successful, ERROR otherwise
#
#   Globals Used: none
#
#    Description: This subroutine Unpauses if there are any vdisks paused and 
#                starts copy operation on the remaining destination vdisks created 
#                in BEWorkload1 part, Then the system is defragged. 
#
#
##############################################################################

sub BEWorkload2
{
    trace();
    
    my ( $objPtr, $srcVdiskListPtr, $destVdiskListPtr, $origVdiskListPtr ) = @_;

    my $lc;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my $cnt = 0;
    my $cnt1 = 0;
    my $newVd;
    my $i;
    my $j;
    my $k = 0;
    my %rsp;
    my $ret;
    my @pdds;
    my %rsp1;
    my %info;
    
    #
    # Find the master controller
    #
     
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    @coList = @$objPtr;

    $ctlr = $coList[$master];

    %info = $ctlr->resyncData(1);
    
    #
    # Begin unpausing the vdisks, which were paused earlier in the test.
    #
    
    if (%info)
    {
        if ($info{STATUS} == PI_GOOD)
        { 
            for ($i = 0; $i < $info{COUNT}; $i++)
            {
                if (($info{DTLCPY}[$i]{VMIRROR} != 2) &&
                                    ($info{DTLCPY}[$i]{VMIRROR} == 3 ))
                {       
                    %rsp1 = $ctlr->virtualDiskControl(0x07,$info{DTLCPY}[$i]{RCSDV}, $info{DTLCPY}[$i]{RCDDV});

                    if (!%rsp1)                        # no response
                    {
                        print "\n";
                        logInfo(">>>>> Failed to receive a response from virtualdiskcontrol <<<<<");
                        return ERROR;
                    }

                    elsif ($rsp1{STATUS}  != PI_GOOD)            # 1 is bad
                    {
                        logInfo("Unpausing of mirror disk $info{DTLCPY}[$i]{RCDDV} has Failed. \n");
                        print "\n";
                        TestLibs::IntegCCBELib::PrintError(%rsp1);
                        return ERROR;
                    }
                    else
                    {
                        logInfo("Vdisk Mirror $info{DTLCPY}[$i]{RCDDV} Unpaused\n");
                    }
                }
            }   
        } 
        else
        {
            my $msg = "Unable to retrieve the resync data.";
            displayError($msg, %info);
        }
    }  
    else
    {
        print "ERROR: Did not receive a response packet from function resyncData.\n";
        return ERROR;
    } 
    
    #
    # Start copy/swap on remaining destination vdisks created earlier in the test.
    #
    
    for ( $j = 2; $j < scalar(@$srcVdiskListPtr); $j++ )
    {
        $ret = TestLibs::BEUtils::RediCpVdisks($ctlr, $$srcVdiskListPtr[$j], $$destVdiskListPtr[$j]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    #
    # Start defragging the system
    #

    $ret = &TestLibs::BEUtils::DefragAllBegin($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    return GOOD;
}
###############################################################################


###############################################################################

=head2 BEWorkload3 function

This routine checks if there are any vdisks on which the copy/swap is completed 
and deletes those vdisks, If defrag is not running, restarts defrag.

  Check for any copy/swap completed vdisks
  Delete vdisks 
  restart defrag
  

=cut

=over 1

=item Usage:

 my $rc = BEWorkload3( $objPtr, $destVdiskListPtr );
 
 where: $objPtr is a pointer to a list of controller objects
        $destVdiskListPtr is a pointer to list of copy destination vdisks      

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.

 There should be no defrag, copy, or init operation running when the test 
 is started. 

=back

=cut

##############################################################################
#
#          Name: BEWorkload3
#
#        Inputs: controller object, destination vdisklist 
#
#       Outputs: GOOD, if successful, ERROR otherwise , INVALID if there 
#                are no remaining copy/swap running and all vdisks are 
#                deleted. 
#
#  Globals Used: none
#
#   Description: This routine checks if there are any vdisks on which the 
#                copy/swap is completed and deletes those vdisks, If defrag 
#                is not running, restart defrag.
#
#
##############################################################################
sub BEWorkload3
{
    trace();

    my ( $objPtr, $destVdiskListPtr ) = @_;


    my $i;
    my $ret;
    my $ret1;
    my %rsp;
    my $cnt1;
    my $master;
    my $ctlr;
    my @coList;
    
    my $stillCopying = 0;
    
    #
    # Find the master controller
    #
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    @coList = @$objPtr;

    $ctlr = $coList[$master];

    # check for the destination vdisks on which copy has been completed 
    # and those vdisks will be deleted. If a disk is found on which copy 
    # is still in progress look for the other vdisks on which copy has 
    # completed and delete them.  
    
    for ( $i = 0; $i < scalar(@$destVdiskListPtr); $i++ )
    {
        if ( $$destVdiskListPtr[$i] != INVALID )
        {
            my %rsp = $ctlr->virtualDiskInfo( $$destVdiskListPtr[$i] );

            if (!%rsp)                        # no response
            {
                logInfo(">>>>> Failed to receive a response from virtualDiskInfo($$destVdiskListPtr[$i]) <<<<<");
                return ERROR;
            }
            elsif ($rsp{STATUS} != 0)            # 0 is good, anything else is bad
            {
                logInfo(">>>>> ERROR: virtualDiskInfo($$destVdiskListPtr[$i]) returned an error <<<<<");
                TestLibs::IntegCCBELib::PrintError(%rsp);
                return ERROR;
            }
 
            if ( ($rsp{SCPCOMP} == 100) && ($rsp{OWNER} == 0xff) )
            {
                $ret1 = &TestLibs::IntegCCBELib::DeleteSingleVdisk($ctlr, $$destVdiskListPtr[$i] );
                logInfo ("Deleted Vdisk $$destVdiskListPtr[$i] \n");
                $$destVdiskListPtr[$i] = INVALID;
                if ( $ret1 != GOOD ) { return ERROR; }
            }
            else
            {
                $stillCopying = 1;
            }
        }
    }
    
    #
    # Restart defrag for the deleted Vdisks
    #
    
    $ret = &TestLibs::BEUtils::DefragAllBegin($ctlr);
    if ( $ret != GOOD ) { return ERROR; }
    
    
    # If copy is still in progress on a vdisk, just returns GOOD. this vdisk will
    # be deleted in the next iteration when copy has completed.
    
    if ($stillCopying == 1)
    {
        return GOOD;
    }
    
    #
    # When there no more copy operations in progress and all the vdisks on which 
    # copy has completed are delete then returns INVALID.
    #
    
    return INVALID;
}

###############################################################################

=head2 FEBEWorkLoad function

This function LIPs FE port on each controller n times or for specified time limits.

=cut

=over 1

=item Usage:

 my $rc = FEBEWorkLoad($ctlrs, 
                       $flag, 
                       $liptimeout, 
                       $loopcount, 
                       $destVdiskListPtr, 
                       $becomplete );
 
 where $ctlrs is a reference to the array of controller objects
       $flag is a FLAG to check whether BE activity needs to be included or not
       $timeout is time in seconds for LIPing the FE ports.
       $loopcount is the count to determine how many times port is to be LIP.
       $destVdiskListPtr list of copy destination vdisks 
       $becomplete is a flag to determine if lipping is stopped since BE activity is done
       
=item Returns:

      Good on successful execution of function.
      ERROR on function failure.

=item Description:
 
    Identify all good ports on each controller and chose one of them for LIP. 
    LIPs the chosen ports n times or for specified time limit or till all 
    BE activites completes. 
    

=back

=cut

##############################################################################
#
#          Name: FEBEWorkLoad 
#
#        Inputs: array of controller objects,
#                flag for including BE activity (or) not, 
#                Timeout in seconds for LIPing the FE ports,
#                Number of times FE port is to be reset,
#                list of copy destination vdisks,
#                flag to check if BE activity has completed.
#
#       Outputs: GOOD    - successful,
#                          Successful execution of function. 
#
#                ERROR   - function failed   
#
#  Globals Used: none
#
#   Description: -
#                Identify all good ports on each controller and choose one of them 
#                (first) for LIP. LIPs the chosen ports n times or for specified timeout 
#                (or) loopcount (or) till the BE activity is complete. liptimeout and loopcount 
#                are optional parameters, only one of the two parameters will be used for 
#                determining how many LIPs will be done.If both are specified larger value 
#                out of both will be used.
#
##############################################################################

sub FEBEWorkLoad

{   
    my ($ctlrs, $flag, $liptimeout, $loopcount, $destVdiskListPtr, $becomplete ) = @_;

    my @oList = @$ctlrs;
    my $i;
    my $j;
    my $lipcount = 1;
    my %rsp;
    my @activeports;
    my @tmp;
    my $ctlr;
    my $ret;
    my $loopsremaining; 
    my $timeremaining; 
    my $portflag = 0; 

    #
    # If none of the optional parameters are specified then return ERROR
    #
    
    if ( ($loopcount <= 0) && ($liptimeout <= 0) )
    {
       logInfo(" >>>>>>>> None of the optional parameters have valid values <<<<<<<<"); 
       return ERROR;  
    }
    
    #
    # If loopcount specified is valid then set flag loopsremaining to 1
    #
    
    if ( $loopcount > 0 )
    {
       $loopsremaining = 1;
    }
    else
    {
       $loopsremaining = 0;
    }


    if ( $liptimeout > 0 )
    {
       $timeremaining = 1;
    }
    else
    {
       $timeremaining = 0;
    }



    # Identify good channel ports (with card) on each controller.  

    for ( $i=0; $i < scalar@oList; $i++)
    {
        $ctlr = $oList[$i]; 
    
        for $j (0..3)
        {
            &TestLibs::iscsi::ValidateTargetType ($ctlr, $j, \$portflag);

            if ($portflag == 1)
            { 
 
            %rsp = $ctlr->deviceList("FE", $j);
        
            if ( ! %rsp  )              # If no return from call
            {
                 logInfo(">>>>>>>> Failed to get response from deviceList <<<<<<<<");
                 return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                if ( $rsp{ERROR_CODE} != $ctlr->PI_ERROR_INV_CHAN )
                {
                    logInfo(">>>>>>>> Error from deviceList <<<<<<<<");
                    PrintError(%rsp);
                    return ERROR;
                }
                else
                {
                    logInfo("No card on channel $j of CN$i");
                }
            }
            else
            {
                push(@tmp, $j);
            }
        }
        }
        
        if (scalar(@tmp))
        {
            push @activeports, [@tmp];
        }    
        else
        {
            logInfo(">>>>>>>>> There are no active ports on controller CN$i<<<<<<<<<<<");
        }
    }

    if (scalar(@activeports))
    {
        $liptimeout = $liptimeout + time();
    
        while ( ($loopsremaining == 1) ||  ($timeremaining == 1) ) 
        {
            for ($i = 0; $i < scalar(@oList); $i++) 
            {
                $ctlr = $oList[$i]; 
                
               # LIP a port on controller
               
               %rsp = $ctlr->resetQlogicFE($activeports[$i][0], $ctlr->RESET_QLOGIC_RESET_INITIALIZE);
               
               sleep 1;
               
               if ( ! %rsp  )                      # If no return from call
               {
                   logInfo(">>>>>>>> Failed to get response from reset FE port<<<<<<<<");
                   return ERROR;
               }
               if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
               {
                   if ( $rsp{ERROR_CODE} != $ctlr->PI_ERROR_INV_CHAN )
                   {
                       logInfo(">>>>>>>> Error from reset port <<<<<<<<");
                       PrintError(%rsp);
                       return ERROR;
                   }
               }
               else
               {
                   logInfo ("QL Reset successful on controller CN$i :: Iteration:$lipcount ");   
               }
            }
       
       #
       # Flag is set to include BE activity 
       #
           if ( $flag == WL_CHECKBE )
           {
                do
                {
                    $ret = &TestLibs::Workload::BEWorkload3( $ctlrs, $destVdiskListPtr );
            
                    if( $ret == INVALID )
                    { 
                        $$becomplete = 1;  # Set the flag which determines completion of BE activity 
                        return GOOD;
                    }
                    
                    #
                    # Timeout has occured so stop performing BE activity check
                    #
                    
                    if ( $liptimeout < time() )
                    {
                        return GOOD;
                    }
                
                } while ($ret != INVALID);
           }
           
           # Determining how many LIPs have to be performed, decides if timeout does 
           # more LIPS (or) loopcount does more LIPS. 
          
           # If timeout happens then timeremaining flag will be set to 0 
             
           if ( ($liptimeout < time()) && ($timeremaining == 1) )
           {
                $timeremaining = 0;
           }
           
           # If loopcount exhausts then loopsremaining flag will be set to 0 
           
           $lipcount++;
           
           if ( ($loopcount == $lipcount ) && ($loopsremaining == 1) )
           {
                $loopsremaining = 0;
           }
           
        }
    
    return GOOD;
    } 
    else
    {
        logInfo(">>>>>>>>No active ports found...<<<<<<<<<");
        return ERROR;
    }
}


#########################################################################################################

##############################################################################

1;   # we need this for a PM

##############################################################################
=head1 CHANGELOG

##############################################################################
# Change log:
# $Log$
# Revision 1.1  2006/09/05 18:44:01  DavisB
# TBolt00015688
# In my environment, I have the "cd" command aliased to echo the directory changed to. Also,
# I have the current directory in my $PATH. Both broke the kernel build.
#
# Revision 1.2  2005/11/14 11:49:58  AnasuriG
# Changes done as part of iSCSI scripting for Integration testing
#
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
# Revision 1.1  2005/03/08 11:15:29  BalemarthyS
# New file for Stress testing on FE & BE Created by Gopinadh Anasuri, Review by Craig Menning
#
#
##############################################################################

=cut
