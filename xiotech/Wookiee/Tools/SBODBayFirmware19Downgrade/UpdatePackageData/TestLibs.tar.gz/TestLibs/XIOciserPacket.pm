# $Header$

###############################################################################
#
#   XIOciser Packet Library
#
#   9/29/2003  XIOtech   Eric Thiemann
#
#   Description: This library provides a place to put functions that relate
#                to XIOciser packets.
#
#   Copyright 2003 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
###############################################################################


#
# The name of this perl module.  
#
package TestLibs::XIOciserPacket;

#
# Includes...
#
use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :XIOCISER);
use TestLibs::utility;
use XIOTech::cmdMgr;
use IO::Socket::INET;

#
# Setup...
#
use strict;
STDOUT->autoflush(1);
STDERR->autoflush(1);

#--------------------------------CONSTANTS-------------------------------------

#
# XIOciser packet related constants...
#

# Size of the XIOciser packet header (in bytes).
use constant XIOCISER_PACKET_HEADER_SIZE   => 72;

# The value that is palced in the signature field of all XIOciser packets.
# This gives a XIOciser component the ability to find out if a packet is an
# actual XIOciser packet.
use constant XIOCISER_PACKET_SIGNATURE     => 0x91300319;

# The current version of the XIOciser protocol.  This protocol version of a
# XIOciser packet is stored in the protocolVersion field of the packet.
use constant XIOCISER_PROTOCOL_VERSION     => 1;

#
# Socket related constants...
#

# The error code that represents that there was a socket error sending or
# receiving data.
use constant SCK_ERR_DATA_TRANSFER         => -1;

# The error code that represents that the remote host disconnected.
use constant SCK_ERR_DISCONNECT            => -2;

# The error code that represents that a non-XIOciser packet was received.
use constant SCK_ERR_NON_XIOCISER_PACKET   => -3;

#
# XIOciser packet command codes (see "XIOciser Command.doc" for more
# information).  Note: some of the commands listed are not used by the XTC,
# however, they are listed for completeness.
#

#
# Monitor Direct Targeted Commands
#
use constant MONITOR_DIRECT_TARGETED_CMD_BASE    =>    0x00000000;
use constant XCMD_GET_DIRECTOR_LIST              =>    0x00000001;
use constant XCMD_START_DIRECTOR                 =>    0x00000002;
use constant XCMD_REPORT_DIRECTOR_STARTUP_STATUS =>    0x00000003;
use constant XCMD_ADD_DIRECTOR                   =>    0x00000004;

#
# Director Direct Targeted Commands
#
use constant DIRECTOR_DIRECT_TARGETTED_CMD_BASE  =>    0x00001000;
use constant XCMD_LOGIN_GUI                      =>    0x00001001;
use constant XCMD_START_XTC                      =>    0x00001002;
use constant XCMD_GET_LOGGED_IN_GUIS             =>    0x00001003;
use constant XCMD_GET_ADMINISTRATOR_GUI          =>    0x00001004;
use constant XCMD_GET_DIRECTOR_INFO              =>    0x00001005;
use constant XCMD_GET_OVERALL_TESTING_STATE      =>    0x00001006;
use constant XCMD_CHANGE_DIRECTOR_NAME           =>    0x00001007;
use constant XCMD_LOGIN_XTC                      =>    0x00001008;

#
# GUI Direct Targeted Commands
#
use constant GUI_DIRECT_TARGETED_CMD_BASE        =>    0x00002000;
use constant XCMD_REPORT_MONITOR_STARTUP_STATUS  =>    0x00002001;
use constant XCMD_REPORT_XTC_STARTUP_STATUS      =>    0x00002002;
use constant XCMD_REPORT_UPDATED_DIRECTOR_INFO   =>    0x00002003;
use constant XCMD_REPORT_UPDATED_TASK_INFO       =>    0x00002004;

#
# Listener Direct Targeted Commands
#
use constant LISTENER_DIRECT_TARGETED_CMD_BASE   =>    0x00003000;
use constant XCMD_LOG_INTO_SERVER                =>    0x00003001;
use constant XCMD_LOGIN_XIOCISER_TASK            =>    0x00003002;

#
# GUI Routed Targeted Commands
#
use constant GUI_ROUTED_TARGETED_CMD_BASE        =>    0x00004000;
use constant XCMD_REPORT_TESTCASE_STATUS_MESSAGE =>    0x00004001;
use constant XCMD_REPORT_NEW_TESTCASE            =>    0x00004002;
use constant XCMD_REPORT_TESTCASE_BINARY_STATUS  =>    0x00004003;
use constant XCMD_REPORT_TESTCASE_END            =>    0x00004004;
use constant XCMD_REPORT_STARTED_TASK            =>    0x00004005;
use constant XCMD_REPORT_ENDED_TASK              =>    0x00004006;

#
# XTC Routed Targeted Commands
#
use constant XTC_ROUTED_TARGETED_CMD_BASE        =>    0x00005000;
use constant XCMD_RESUME_TESTCASE                =>    0x00005001;

#
# Listener Routed Targeted Commands
#
use constant LISTENER_ROUTED_TARGETED_CMD_BASE   =>    0x00006000;
use constant XCMD_RUN_XIOCISER_COMPATIBLE_TASK   =>    0x00006001;

#
# Multi-target Commands
#
use constant MULTI_TARGET_CMD_BASE               =>    0x00007000;
use constant XCMD_USE_AS_SYNCHRONOUS_SOCKET      =>    0x00007001;

#------------------------------------------------------------------------------

#
# Set up the module export settings.
#
BEGIN {
    use Exporter ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    $VERSION     = 1.00;
    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        &CreateXIOciserPacket
                        &PrintXIOciserPacket
                        &BasicSendXIOciserPacket
                        &BasicReceiveXIOciserPacket
                        &SocketSend
                        &SocketRecv
                        &SocketConnect
                        &SocketClose
                                                
                        XIOCISER_PACKET_HEADER_SIZE
                        XIOCISER_PACKET_SIGNATURE
                        XIOCISER_PROTOCOL_VERSION

                        SCK_ERR_DATA_TRANSFER
                        SCK_ERR_DISCONNECT 
                        SCK_ERR_NON_XIOCISER_PACKET 
                        
                        MONITOR_DIRECT_TARGETED_CMD_BASE    
                        XCMD_GET_DIRECTOR_LIST              
                        XCMD_START_DIRECTOR                 
                        XCMD_REPORT_DIRECTOR_STARTUP_STATUS 
                        XCMD_ADD_DIRECTOR                   
                                              
                        DIRECTOR_DIRECT_TARGETTED_CMD_BASE  
                        XCMD_LOGIN_GUI                      
                        XCMD_START_XTC                      
                        XCMD_GET_LOGGED_IN_GUIS             
                        XCMD_GET_ADMINISTRATOR_GUI          
                        XCMD_GET_DIRECTOR_INFO              
                        XCMD_GET_OVERALL_TESTING_STATE      
                        XCMD_CHANGE_DIRECTOR_NAME           
                        XCMD_LOGIN_XTC                      
                       
                        GUI_DIRECT_TARGETED_CMD_BASE        
                        XCMD_REPORT_MONITOR_STARTUP_STATUS  
                        XCMD_REPORT_XTC_STARTUP_STATUS      
                        XCMD_REPORT_UPDATED_DIRECTOR_INFO   
                        XCMD_REPORT_UPDATED_TASK_INFO       
                       
                        LISTENER_DIRECT_TARGETED_CMD_BASE   
                        XCMD_LOG_INTO_SERVER                
                        XCMD_LOGIN_XIOCISER_TASK            
                       
                        GUI_ROUTED_TARGETED_CMD_BASE        
                        XCMD_REPORT_TESTCASE_STATUS_MESSAGE 
                        XCMD_REPORT_NEW_TESTCASE            
                        XCMD_REPORT_TESTCASE_BINARY_STATUS  
                        XCMD_REPORT_TESTCASE_END            
                        XCMD_REPORT_STARTED_TASK            
                        XCMD_REPORT_ENDED_TASK              
                        
                        XTC_ROUTED_TARGETED_CMD_BASE        
                        XCMD_RESUME_TESTCASE                
                        
                        LISTENER_ROUTED_TARGETED_CMD_BASE   
                        XCMD_RUN_XIOCISER_COMPATIBLE_TASK   
                        
                        MULTI_TARGET_CMD_BASE               
                        XCMD_USE_AS_SYNCHRONOUS_SOCKET                                                                                                            
                     );
}
our @EXPORT_OK;

#
# When this module is loaded, output the module version name on the screen.
#
logVersion(__PACKAGE__, q$Revision: 4298 $);

###############################################################################
############################ Implementation Section ###########################
###############################################################################


###############################################################################
#
#          Name: CreateXIOciserPacket
#
#        Inputs: Scalars:
#                command code, brief data, reference to the body, reference to 
#                the payload, and command status for the packet that is being
#                created
#
#                Note: If the packet does not have a body and/or payload
#                part, then undef must be used for the body and/or payload 
#                reference inputs
#
#                Note: commandStatus is only applicable to response packets
#                and thus may be not specified if desired.
#
#       Outputs: A reference to a hash representing the packet.  The following
#                keys are in the resultant hash...
#                            SIGNATURE
#                            PROTOCOL_VERSION
#                            BODY_SIZE
#                            PAYLOAD_SIZE
#                            COMMAND_CODE
#                            COMMAND_SEQUENCE_ID
#                            BRIEF_DATA
#                            COMMAND_STATUS
#                            REF_BODY        -> reference to the binary body
#                            REF_PAYLOAD     -> reference to the binary payload           
#
#   Description: Creates a XIOciser packet.
#
###############################################################################
sub CreateXIOciserPacket
{
    trace();

    my ($commandCode, $briefData, $refBody, $refPayload, $commandStatus) = @_;
    my %packetHash;

    #
    # Set some default values for the packet.
    #
    my $signature = XIOCISER_PACKET_SIGNATURE;
    my $protocolVersion = XIOCISER_PROTOCOL_VERSION;
    my $bodySize = 0;
    my $payloadSize = 0;
    my $commandSequenceID = 0;   # This is currently an unused field
    if (!defined($commandStatus))
    {
        $commandStatus = GOOD;
    }

    #
    # Set the body and payload sizes if they were specified.
    #
    if (defined($refBody))
    {
        $bodySize = length($$refBody);
    }
    if (defined($refPayload))
    {
        $payloadSize = length($$refPayload);
    }

    #
    # Fill hash representing the packet with the fields of the packet.
    #
    $packetHash{SIGNATURE} = $signature;
    $packetHash{PROTOCOL_VERSION} = $protocolVersion;
    $packetHash{BODY_SIZE} = $bodySize;
    $packetHash{PAYLOAD_SIZE} = $payloadSize;
    $packetHash{COMMAND_CODE} = $commandCode;
    $packetHash{COMMAND_SEQUENCE_ID} = $commandSequenceID;
    $packetHash{BRIEF_DATA} = $briefData;
    $packetHash{COMMAND_STATUS} = $commandStatus;
    $packetHash{REF_BODY} = $refBody;
    $packetHash{REF_PAYLOAD} = $refPayload;

    return \%packetHash;
}

###############################################################################
#
#          Name: PrintXIOciserPacket
#
#        Inputs: Scalars:
#                refPacket - reference to hash representing the packet to print            
#               
#       Outputs: none       
#
#   Description: Prints the fields of the specified XIOciser packet.
#
###############################################################################
sub PrintXIOciserPacket
{
    my ($refPacket) = @_;

    logInfo("XIOciser packet contents:");
    if (defined($refPacket))
    {
        logInfo("SIGNATURE:           " . $$refPacket{SIGNATURE} . " (0x" . DecToAsciiHexData($$refPacket{SIGNATURE}, "word") . ")");
        logInfo("PROTOCOL_VERSION:    " . $$refPacket{PROTOCOL_VERSION});
        logInfo("BODY_SIZE:           " . $$refPacket{BODY_SIZE});
        logInfo("PAYLOAD_SIZE:        " . $$refPacket{PAYLOAD_SIZE});
        logInfo("COMMAND_CODE:        " . $$refPacket{COMMAND_CODE} . " (0x" . DecToAsciiHexData($$refPacket{COMMAND_CODE}, "word") . ")");
        logInfo("COMMAND_SEQUENCE_ID: " . $$refPacket{COMMAND_SEQUENCE_ID});
        logInfo("BRIEF_DATA:          " . $$refPacket{BRIEF_DATA});
        logInfo("COMMAND_STATUS:      " . $$refPacket{COMMAND_STATUS});
        logInfo("REF_BODY:            " . $$refPacket{REF_BODY});
        logInfo("REF_PAYLOAD:         " . $$refPacket{REF_PAYLOAD});
    }
    else
    {
        logInfo("Packet is undefined");
    }
}

################################################################################
#
#          Name: BasicSendXIOciserPacket
#
#        Inputs: Scalars:
#                socket - handle to the socket that is connected to
#                         the destination for this packet 
#                refPacket - reference to hash representing the packet to send             
#               
#       Outputs: GOOD if sending the data was successful
#                SCK_ERR_DISCONNECT if the client disconnected
#                SCK_ERR_DATA_TRANSFER if there was a data transfer error        
#
#   Description: Sends a XIOciser packet and returns any appropriate error
#                code.  The method is considered "basic" because it does not
#                process errors, it just returns the error code.
#
###############################################################################
sub BasicSendXIOciserPacket
{
    trace();
    
    my ($socket, $refPacket) = @_;
    my $header;      
    my $binaryPacket;

    #
    # Construct the header of the packet.
    #
    $header .= pack("L", $$refPacket{SIGNATURE});
    $header .= pack("L", $$refPacket{PROTOCOL_VERSION});   
    $header .= pack("L", $$refPacket{BODY_SIZE});
    $header .= pack("L", $$refPacket{PAYLOAD_SIZE});
    $header .= pack("a20", "");               # reserved0
    $header .= pack("L", $$refPacket{COMMAND_CODE});
    $header .= pack("L", $$refPacket{COMMAND_SEQUENCE_ID});
    $header .= pack("l", $$refPacket{BRIEF_DATA});
    $header .= pack("l", $$refPacket{COMMAND_STATUS});
    $header .= pack("a20", "");               # reserved1

    #
    # Add the header to the packet.
    #
    $binaryPacket = $header;

    #
    # If a body exists, add the body to the packet.
    #
    if ($$refPacket{BODY_SIZE} > 0)
    {
        $binaryPacket .= ${$$refPacket{REF_BODY}};
    }

    #
    # If a payload exists, add the payload to the packet.
    #
    if ($$refPacket{PAYLOAD_SIZE} > 0)
    {
        $binaryPacket .= ${$$refPacket{REF_PAYLOAD}};
    }

    return SocketSend($socket, \$binaryPacket, length($binaryPacket)); 
}

###############################################################################
#
#          Name: BasicReceiveXIOciserPacket
#
#        Inputs: Scalars:
#                socket - handle to the socket that is connected to
#                         the host that the packet will be received from              
#               
#       Outputs: Hash with the following keys...
#                STATUS - this can be any of the following constants...
#                      GOOD if receiving the data was successful
#                      SCK_ERR_DISCONNECT if the client disconnected
#                      SCK_ERR_DATA_TRANSFER if there was a data transfer error
#                      SCK_ERR_NON_XIOCISER_PACKET if the received packet is
#                                                  not a XIOciser packet
#                REF_PACKET - a reference to a hash representing the packet.
#                             The following keys are in the resultant hash...
#                                SIGNATURE
#                                PROTOCOL_VERSION
#                                BODY_SIZE
#                                PAYLOAD_SIZE
#                                COMMAND_CODE
#                                COMMAND_SEQUENCE_ID
#                                BRIEF_DATA
#                                COMMAND_STATUS
#                                REF_BODY      -> reference to the binary body
#                                REF_PAYLOAD -> reference to the binary payload
#
#   Description: Receives a XIOciser packet and returns any appropriate error
#                code.  This method is considered "basic" because it does
#                not process errors, it just returns the error code.
#
###############################################################################
sub BasicReceiveXIOciserPacket
{
    trace();
    
    my ($socket) = @_;
    my %packetHash;
    my $refHeader;
    my %tempHash;
    my %returnedHash;
    my $rc = GOOD;

    #
    # Packet field variables.
    #
    my $signature;
    my $protocolVersion;
    my $bodySize;
    my $payloadSize;
    my $reserved0;
    my $commandCode;
    my $commandSequenceID;
    my $briefData;
    my $commandStatus;
    my $reserved1;

    #
    # Receive the header for the packet.
    #
    %tempHash = SocketRecv($socket, XIOCISER_PACKET_HEADER_SIZE);

    #
    # If receiving the packet header succeeded...
    #
    $rc = $tempHash{STATUS};
    if ($rc == GOOD)
    {
        #
        # Get the packet fields from the header.
        #
        $refHeader = $tempHash{REF_DATA};
        ($signature,
         $protocolVersion,
         $bodySize,
         $payloadSize,
         $reserved0,
         $commandCode,
         $commandSequenceID,
         $briefData,
         $commandStatus,
         $reserved1) = unpack("LLLLa20LLlla20", $$refHeader);

        #
        # If the header is a valid XIOciser packet header...
        #
        if ($signature == XIOCISER_PACKET_SIGNATURE)
        {
            #
            # If there is a body for the packet...
            #
            if ($bodySize > 0)
            {
                #
                # Receive the body for the packet.
                #
                %tempHash = SocketRecv($socket, $bodySize);
                
                #
                # If receiving the body succeeded, set the reference to the 
                # body in the packet hash.
                # 
                $rc = $tempHash{STATUS};
                if ($rc == GOOD)
                {
                    $packetHash{REF_BODY} = $tempHash{REF_DATA};  
                }
            }

            #
            # If no errors have occurred yet...
            #
            if ($rc == GOOD)
            {
                #
                # If there is a payload for the packet...
                #
                if ($payloadSize > 0)
                {
                    #
                    # Receive the payload for the packet.
                    #
                    %tempHash = SocketRecv($socket, $payloadSize);
                    
                    #
                    # If receiving the payload succeeded, set the reference to
                    # the payload in the packet hash.
                    #
                    $rc = $tempHash{STATUS};
                    if ($rc == GOOD)
                    {
                        $packetHash{REF_PAYLOAD} = $tempHash{REF_DATA};
                    }
                }
            }
        }
        else
        {
            $rc = SCK_ERR_NON_XIOCISER_PACKET;
        } 
    }

    #
    # If receiving the packet succeeded, set the values in the packet hash.
    #
    if ($rc == GOOD)
    {
        $packetHash{SIGNATURE} = $signature;
        $packetHash{PROTOCOL_VERSION} = $protocolVersion;
        $packetHash{BODY_SIZE} = $bodySize;
        $packetHash{PAYLOAD_SIZE} = $payloadSize;
        $packetHash{COMMAND_CODE} = $commandCode;
        $packetHash{COMMAND_SEQUENCE_ID} = $commandSequenceID;
        $packetHash{BRIEF_DATA} = $briefData;
        $packetHash{COMMAND_STATUS} = $commandStatus;
        #{REF_BODY} has already been set
        #{REF_PAYLOAD} has already been set
    }

    #
    # Set the return code and packet reference in the returned hash.
    # Note: if the return code is not GOOD, then the packet hash reference
    # will be set to undef.
    #
    $returnedHash{STATUS} = $rc;
    if ($rc == GOOD)
    {
        $returnedHash{REF_PACKET} = \%packetHash;
    }
    else
    {
        $returnedHash{REF_PACKET} = undef;
    }

    return %returnedHash;
}


###############################################################################
#
#          Name: SocketSend
#
#        Inputs: Scalars:
#                socket - handle to the socket that is connected to
#                         the client to send data to
#                refData - reference to the binary data to send
#                dataLength - lengh of the data to send              
#               
#       Outputs: GOOD if sending the data was successful
#                SCK_ERR_DISCONNECT if the client disconnected
#                SCK_ERR_DATA_TRANSFER if there was a data transfer error        
#
#   Description: Sends the specified amount of data to a connected client.
#
###############################################################################
sub SocketSend
{
    trace();

    my ($socket, $refData, $dataLength) = @_;
    my $totalBytesWritten = 0;
    my $bytesWritten = 0;
    my $rc = GOOD;

    #
    # Keeping sending until all of the specified data has been sent.
    #
    while ($totalBytesWritten < $dataLength)
    {    
        #
        # Write some data to the socket.
        #
        $bytesWritten = $socket->syswrite($$refData, 
                                          $dataLength - $totalBytesWritten,
                                          $totalBytesWritten);

        #
        # If there was not a socket error...
        #
        if (defined($bytesWritten))
        {
            #
            # Update the total number of bytes sent
            #
            $totalBytesWritten += $bytesWritten;
            
            #
            # If the client disconnected...
            #
            if ($bytesWritten == 0)
            {
                $rc = SCK_ERR_DISCONNECT;
                last;
            }
        }
        else
        {
            #
            # A socket error occurred, so set the appropriate error
            # code and break the loop.
            #
            $rc = SCK_ERR_DATA_TRANSFER;
            last;
        }
    }

    return $rc; 
}

###############################################################################
#
#          Name: SocketRecv
#
#        Inputs: Scalars:
#                socket - handle to the socket that is connected to
#                         the client to receive data from
#                dataLength - lengh of the data to receive              
#               
#       Outputs: Hash with the following keys...
#                STATUS - this can be any of the following constants...
#                      GOOD if receiving the data was successful
#                      SCK_ERR_DISCONNECT if the client disconnected
#                      SCK_ERR_DATA_TRANSFER if there was a data transfer error
#                REF_DATA - reference to the binary data that was received       
#
#   Description: Receives the specified amount of data from a connected client.
#
###############################################################################
sub SocketRecv
{
    trace();
   
    my ($socket, $dataLength) = @_;
    my $bytesReceived = 0;
    my $totalBytesReceived = 0;
    my $rc = GOOD;
    my $data;
    my %returnedHash;


    #
    # Keeping receiving until all of the specified data has been received.
    #
    while ($totalBytesReceived < $dataLength)
    {    
        #
        # Read some data from the socket.
        #
        $bytesReceived = $socket->sysread($data, 
                                          $dataLength - $totalBytesReceived,
                                          $totalBytesReceived);

        #
        # If there was not a socket error...
        #
        if (defined($bytesReceived))
        {
            #
            # Update the total number of bytes received.
            #
            $totalBytesReceived += $bytesReceived;

            #
            # If the client disconnected...
            #
            if ($bytesReceived == 0)
            {
                $rc = SCK_ERR_DISCONNECT;
                last;
            }
        }
        else
        {
            #
            # A socket error occurred, so set the appropriate error
            # code and break the loop.
            #
            $rc = SCK_ERR_DATA_TRANSFER;
            last;
        }
    }

    #
    # Fill in the hash that is returned.
    #
    $returnedHash{STATUS} = $rc;
    $returnedHash{REF_DATA} = \$data; 

    return %returnedHash; 
}

###############################################################################
#
#          Name: SocketConnect
#
#        Inputs: Scalars:
#                ipAddress - the IP address of the machine to connect to
#                port - the TCP port on the machine to connect to             
#               
#       Outputs: IO::Socket::INET object for the connection if successful
#                undef if the connect failed      
#
#   Description: Makes a connection to the specified client.
#
###############################################################################
sub SocketConnect
{
    trace();

    my ($ipAddress, $port) = @_;

    my $socket = IO::Socket::INET->new(PeerAddr => $ipAddress,
                                       PeerPort => $port,
                                       Proto => "tcp",
                                       Type => SOCK_STREAM);

    return $socket;
}

###############################################################################
#
#          Name: SocketClose
#
#        Inputs: Scalars:
#                socket - the IO:Socket::INET object to close         
#               
#       Outputs: none      
#
#   Description: Closes the connection on the specified socket
#
###############################################################################
sub SocketClose
{
    trace();

    my ($socket) = @_;

    #
    # Shutdown both send and receive on the socket.
    #
    $socket->shutdown(2);

    #
    # Close the socket.
    #
    $socket->close();
}

#------------------------------------------------------------------------------
#
# This is needed for a perl module.
#
1;
#------------------------------------------------------------------------------

__END__

=head1 CHANGELOG

 $Log$
 Revision 1.1  2005/05/04 18:53:52  RysavyR
 Initial revision

 Revision 1.6  2003/10/07 15:40:03  ThiemanE
 Added some command code constants for XIOciser
 Reviewed by Craigm

 Revision 1.5  2003/09/30 21:18:31  ThiemanE
 Added the SocketClose function and removed some debug print statements

 Revision 1.4  2003/09/30 20:16:09  ThiemanE
 Fixed a problem with sending large packets

 Revision 1.3  2003/09/30 20:04:18  ThiemanE
 Fixed a body and payload dereferencing problem

 Revision 1.2  2003/09/30 18:17:31  ThiemanE
 Fixed a problem where the payload was received as the body

 Revision 1.1  2003/09/30 17:19:22  ThiemanE
 Added file to CVS - reviewed by Craigm

 
=cut
