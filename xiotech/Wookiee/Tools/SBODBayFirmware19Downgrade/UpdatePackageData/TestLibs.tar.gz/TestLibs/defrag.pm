#! /usr/bin/perl 
# $Header$
##############################################################################
#  
#   CCBE Integration test library - Defrag test functions
#
#   10/1/2002  XIOtech   Craig Menning
#
#   A set of library functions for integration testing. This set support
#   testing of the controller's defrag function
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::defrag - Perl Tests to test defrag ( and some redi-copy )

$Id: defrag.pm 13852 2006-09-20 11:25:31Z AnasuriG $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing the defrag 
function on the controllers. Much of this is testing in a two-way
environment.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

              Defrag2Way            ( A two way test )
              
              DefragTest            ( A one way test )

              InitialDefragConfig   ( setup for the 2 way test )

              InitialDefragConfig2  ( alternate 2 way setup )
              
        The less significant ones

              DefragCase1 
              DefragCase2 
              DefragCase3 
              DefragCase4 
              DefragCase5 
              DefragCase6 
              DefragCase7 
              DefragCase8 
              DefragCase9 
              DefragCase10
              DefragCase11
              DefragCase12
              DefragCase13
              DefragCase14
              DefragCase15
              DefragCase16
              DefragCase17
              
              DefragBegin
              DefragPart1
              DefragPart2
              DefragPart3
              DefragPart4

=cut


#                         
# - what I am
#

package TestLibs::defrag;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;

use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - Constants used
#

# redi copy options
#use constant    CB => "CB";
#use constant    CM => "CM";
#use constant    CS => "CS";


#use constant CCBETIMEOUT => 600;

             # these are bit significant
#use constant NO_RAID_INIT => 1;    # for makeVdisks, defrag test  
#use constant DEFRAG_WAIT => 2;     # for defrag test


#use constant ISFRAGMENTED => 1;
#use constant NOTFRAGMENTED => 0;
#use constant SKIPVALIDATIONFAILURE => 128;


#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 13852 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &DebugEntry

                        &Defrag2Way

                        &DefragBegin
                        
                        &DefragCase1 
                        &DefragCase2 
                        &DefragCase3 
                        &DefragCase4 
                        &DefragCase5 
                        &DefragCase6 
                        &DefragCase7 
                        &DefragCase8 
                        &DefragCase9 
                        &DefragCase10
                        &DefragCase11
                        &DefragCase12
                        &DefragCase13
                        &DefragCase14
                        &DefragCase15
                        &DefragCase16
                        &DefragCase17
                        
                        &DefragPart1
                        &DefragPart2
                        &DefragPart3
                        &DefragPart4
                        
                        &DefragTest

                        &InitialDefragConfig
                        &InitialDefragConfig2
                        

                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 13852 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.
         
 $moxaIP: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.
          
 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller. 

 $retIn: This is a controle variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be 
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the 
          attached servers. When configuring systems, this list determines 
          which WWNs will be associated with vdisks. If an entry in this 
          list is not found on the system, it will be ignored. A WWN 
          found on the system that is not included in the list will not 
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.
       



=back

=cut


###############################################################################

=head2 DefragTest function

This is the initial defrag test written to run on a 1 way system. It is
in four parts. Part 1 labels drives and creates three vdisks. The 2nd and 3rd
are mapped to servers. (At this time IO could be started on the servers.)
Part 2  is a loop that creates two vdisks, deletes the first of the two 
and then starts a defrag. (Currently the raids are not initialized and this 
creates some problems.)  Part 3 deletes the first disk created in part 1 
and then starts a defrag. Part 4 deletes every other un-associated vdisk
and then starts a defrag.

If the functions are exposed, each part could be run separately.


=cut

=over 1

=item Usage:

 my $rc = DefragTest($ctlr, $wwnPtr);
 
 where: $ctlr is a controller object
        $wwnPtr is a pointer to server WWNs
       

=item Returns:

       $rc will be GOOD always, the logs must be checked for failure.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.
 There will be several vdisks on the system when the script finishes.
 The first two will be associated to servers. If IO had been run, the
 servers should not report errors.

=item Initial Conditions:

 The controller has minimal configuration. If the system is a two way, the 
 second controller is not used. Currently, script related problems
 are seen if less than 28 pdisks are used. The caller should log in and
 provide a license. 




=back

=cut


##############################################################################
#
#          Name: DefragTest
#
#        Inputs: controller object, server wwn list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This is the initial defrag test that runs on a single
#                controlller, without concurrent IO. It consists of 4 
#                major parts. Initial configuration which creates 3
#                vdisks and associates two of them to servers so that IO
#                can be done. The second part is a loop that creates 2 
#                vdisks and then deletes one then starts defrag. The third
#                part deletes the first vdisk and startes a defrag. The
#                4th part deletes every other vdisks and then defrags the 
#                disks.   
#
#
##############################################################################
sub DefragTest
{
    trace();
    my ($ctlr, $wwnPtr) = @_;

    my $ret;
    my $option;
    my $loops;


    # we start from scratch,
    # label the drives
    # get list of data drives
    # create 3 vdisks
    # associate 2nd and 3rd to servers so IO can be done
    
    $ret = DefragPart1($ctlr, 1, $wwnPtr);   # 1 is 1 way system


    # for n loops

        # create 2 vdisks
        # start inits
        # delete 1st of the 2 vdisks
        # start defrag
    
    $loops = 25;
     
    
    #
    # option flag, bit significant controls...
    #        NO_RAID_INIT   No init of the raids
    #        DEFRAG_WAIT    Wait for raids to finish in each loop
    #
     
 #   $option = NO_RAID_INIT + DEFRAG_WAIT; 
    $option = 0; 
        
    $ret = DefragPart2($ctlr, $loops, $option);

    # delete first vdisk
    # start defrag

    $ret = DefragPart3($ctlr, $option);
    
    # delete every other disk (ones from the loop)
    # start defrag (for each)    

    $ret = DefragPart4($ctlr, $option);

    return GOOD;


}
###############################################################################

=head2 InitialDefragConfig function

This configures the system as a two way system for the defrag test. The
pdisks are labeled and vdisks created. The test was written during Baby
Alpha so there will be no RAID 5 vdisks. Vdisks will be mapped to the 
servers so that IO can be done. At the end, the user is prompted to start
IO.



=cut

=over 1

=item Usage:

 my $rc = InitialDefragConfig($ctlr, $wwnPtr);
 
 where: $ctlr is the master controller object
        $wwnPtr is a pointer to server WWNs
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The caller needs to make sure the controllers in the system have the 
 proper license ( 2 way ). 



=back

=cut


##############################################################################
#
#          Name: InitialDefragConfig
#
#        Inputs: controller object, server wwn list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Starting from a clean system, label drives, make 2way,
#                make many vdisks, Associate most. Then allow the user
#                to start IO.   
#
#
##############################################################################
sub InitialDefragConfig
{
    trace();
    my ($coPtr, $ipPtr, $wwnPtr) = @_;


    my $ret;
    # basic config # 18 should be called
    
    $ret = BasicConfig($coPtr,  18, $ipPtr, $wwnPtr );

    return $ret;




}
###############################################################################

=head2 InitialDefragConfig2 function

This configures the system as a two way system for the defrag test. The
pdisks are labeled and vdisks created. The test was written during Baby
Alpha so there will be no RAID 5 vdisks. Vdisks will be mapped to the 
servers so that IO can be done. At the end, the user is prompted to start
IO.

This differs from InitialDefragConfig slightly. The vdisks are created so
that a raid does not necessarily span all data disks.



=cut

=over 1

=item Usage:

 my $rc = InitialDefragConfig2($ctlr, $wwnPtr);
 
 where: $ctlr is the master controller object
        $wwnPtr is a pointer to server WWNs
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The call needs to make sure the controllers in the system have the 
 proper license ( 2 way ). 




=back

=cut



##############################################################################
#
#          Name: InitialDefragConfig2
#
#        Inputs: controller object, server wwn list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Starting from a clean system, label drives, make 2way,
#                make many vdisks, Associate most. Then allow the user
#                to start IO.   
#
#
##############################################################################
sub InitialDefragConfig2
{
    trace();
    my ($coPtr, $ipPtr, $wwnPtr) = @_;


    my $ret;
    # basic config # 18 should be called
    
    $ret = BasicConfig($coPtr,  18, $ipPtr, $wwnPtr );

    return $ret;


}


###############################################################################

=head2 Defrag2Way function

This is the main entry point for a series of two way defrag tests. A group
of tests is run sequentially. Each test is slightly different and checks
a different aspect of the defrag function. The individual tests are written
so that they can be called in any order. Each test basically cleans up the
configuration before doing its test. All this can be done with IO running.

Refer to the "DefragCase##" functions for a description of the individual
tests. In general, the tests all have the same inputs. Those test that do 
failover or failback have additional requirements related to the Moxa
power commander.


=cut

=over 1

=item Usage:

 my $rc = Defrag2Way( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is the IP address of the moxa power controller
        $mmPtr is a the mapping of the moxa channels
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.




=back

=cut




##############################################################################
#
#          Name: Defrag2Way
#
#        Inputs: controller object, server wwn list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Starting with a system that has some vdisks and IO running, 
#                ( IO is required for part of this ) Create, delete, and
#                move vdisks and run defrag. There are several test cases 
#                invoked by this test, Each test ca    
#
#
#               
#
#
##############################################################################
sub Defrag2Way
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my %info1;
    my @serialNums;
    my @startingTmap;
    my @pdiskData; 
    my @vdiskData; 
    my @raidData;
    my $vdiskListPtr;


    @serialNums = @$snPtr;

    $ret = GOOD;

    ######################################################################
    # With a defrag running, rediCP one of the first vdisks to a new one.
    # then delete the old one and start another defrag. 
    #
    # Steps are 1) pick an active vdisk
    #           2) get its size
    #           3) create a new one
    #           3) get baseline IO activity info
    #           4) start the redi CP
    #           5) wait for redicp to complete
    #           5) confirm IO still going
    #           6) defrag again
    #           7) confirm IO still Ok
    ######################################################################

    $ret = DefragCase1(  $coPtr, $ret, $snPtr  );


    ######################################################################
    # With a defrag running, rediCP one of the first vdisks to a new one.
    # While redicp is running, delete another vdisk, start another defrag.
    # Finally, delete the old one and start another defrag. 
    #
    # Steps are 1) pick an active vdisk
    #           2) get its size
    #           3) create a new one
    #           3) get baseline IO activity info
    #           4) start the redi CP
    #           5) DON't wait for redicp to complete
    #           5) confirm IO still going
    #           5) delete another unused vdisk (between to cp src and dest)
    #           6) begin defrag again
    #           7) confirm IO still Ok
    #           8) wait for cp to complet
    #           9) confrim IO again
    #          10) wait for defrag to complete ? 
    #          11) confirm IO again
    ######################################################################

    $ret = DefragCase2(  $coPtr, $ret, $snPtr   );




    ######################################################################
    # With defrag running, move an active target, see what happens, 
    # move it back.
    ######################################################################

    $ret = DefragCase3(  $coPtr, $ret, $snPtr    );



    ######################################################################
    # With defrag running, fail a controller, see what happens.
    # Unfail the controller, see what happens. Confirm IO both times.
    ######################################################################

    $ret = DefragCase4(  $coPtr, $ret, $snPtr, $moxaIP, $mmPtr    );


    
    ###################################################################### 
    # Delete some vdisks, start defrag on both controllers, observe
    ######################################################################

    $ret = DefragCase5(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # Do the create 2, delete one, defrag loop. Do this with the IO before
    # the defrag. IO does not move location during the defrag.
    ######################################################################

    $ret = DefragCase6(  $coPtr, $ret, $snPtr   );


    
    ######################################################################
    # Move all the IO to later in the drive (redicp)
    # Delete some of the source vdisks
    # Defrag the drives ( forces IO to shift position
    ###################################################################### 

    $ret = DefragCase7(  $coPtr, $ret, $snPtr    );



    ###################################################################### 
    # delete all inactive vdisks, defrag. This essentially packs the disk.
    # and pack the IO.
    ######################################################################

    $ret = DefragCase8(  $coPtr, $ret, $snPtr   );


    
    ######################################################################
    # delete all unuased vdisks, defrag (pack system) then create a bunch
    # of vdisks and randomly redicp the vdisks to move the IO all over
    # the place. Delete the unused vdisks, defrag. Tessing IO between 
    # each step
    ###################################################################### 

    $ret = DefragCase9(  $coPtr, $ret, $snPtr    );


    ###################################################################### 
    # start a bunch of defrags. kill them off, check SOS tables.
    ###################################################################### 

    $ret = DefragCase10(  $coPtr, $ret, $snPtr   );



    ###################################################################### 
    # start a bunch of defrags, kill them off. check SOS tables.
    # redicp some of the partially moved vdisks. Delete all the unused
    # vdisks and defrag.
    ###################################################################### 

    $ret = DefragCase11( $coPtr, $ret, $snPtr   );



    ###################################################################### 
    # start a defrag on a single drive (make sure it has lots to move)
    # fail a drive, observe what happens, (don't trash a raid 0,1 drive)
    # let the rebuild happen, delete a vdisk, defrag again.
    ###################################################################### 

    $ret = DefragCase12(  $coPtr, $ret, $snPtr   );



    ###################################################################### 
    # do all this randomly
    ###################################################################### 

    $ret = DefragCase14(  $coPtr, $ret, $snPtr, $moxaIP, $mmPtr  );



    ###################################################################### 
    # start some defrags, check sos tables, create some vdisks,
    # check sos tables, start inits, check sos tables, wait for inits
    # to finish, check sos tables, defrag, test sos tables.
    ###################################################################### 

    
    $ret = DefragCase13(  $coPtr, $snPtr, $ret );




    return $ret;

}

##############################################################################
#
#               Private Functions, but made public for debug
#
##############################################################################

##############################################################################
#
#          Name: FutureDefragCases
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#
#
#   Next #1: Create vdisks that are split and not using the whole pack
#            Disks on one controller are not shared with pdisks for the 
#            other, run IO. Create holes in the packs so that each contoller
#            has its own defragging to do, do those defrags.
#
#
#   Next #2: Similar to one, but also have some vdisks that use all disks 
#            and are doing the IO, but not moving via defrag.
#
#   Next #3: Same as 2 but the vdisks on all drives moves due to the defrag.
#
#
#
#############################################################################


###############################################################################

=head2 DefragCase1 function

This test case begins a redi-copy operation while defrag is running. The
copy is allowed to complete and another defrag is done. The test has these
basic steps...

    Setup ( get initial server activity info )
    Find 2 early vdisks and make replacements
    Do a redi-copy of first one
    Delete the copied disk
    Begin defrag on the disks
    Start a redi-copy on 2nd one
    Wait for the defrag to complete
    Verify IO is still running
    Delete the copied vdisk
    Defrag the pdisks, wait for complete
    Verify IO is still running
    Check the SOS tables

=cut

=over 1

=item Usage:

 my $rc = DefragCase1( $coPtr, $retIn, $snPtr  );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: DefragCase1
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                With a defrag running, rediCP one of the first vdisks to a new one.
#                then delete the old one and start another defrag. 
#        
#                Steps are 
#                   1) pick an active vdisk
#                   2) get its size
#                   3) create a new one
#                   3) get baseline IO activity info
#                   4) start the redi CP
#                   5) wait for redicp to complete
#                   5) confirm IO still going
#                   6) defrag again
#                   7) confirm IO still Ok
##############################################################################
sub DefragCase1
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 1: start redicp while running defrag  -----------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }
    
    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);
    
    
    #
    # Do initial defrag to ensure no fragments initially
    #
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    DispVdiskInfo($ctlr);

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
    ######################################################################
    # With a defrag running, rediCP one of the first vdisks to a new one.
    # then delete the old one and start another defrag. 
    ######################################################################

    # setup - need to get a defrag running

    #
    # find early vdisks
    #
    @oldVds = FindEarlyVdisk( $ctlr, 2 );     # find two vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    if ( scalar(  @oldVds ) < 2 ) 
    { 
        logInfo(" Not enough early vdisks found.");
        return ERROR; 
    }

    #
    # create replacement vdisks at the end
    #
    $newVds[0] =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVds[0] < 0 ) { return ERROR; }
    
    $newVds[1] =  CreateReplacementVdisk($ctlr, $oldVds[1] );
    if ( $newVds[1] < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVds[0]);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = WaitForCpComplete( $ctlr, $newVds[0] );
    if ( $ret != GOOD ) { return ERROR; }


    # delete the source ( the early vdisk )
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVds[0]) ) 
    {
        return ERROR;
    }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }
    
 #   CtlrLogTextAll( $coPtr, "Defrag Case 1: Delay 10 minutes between c/s and defrag start");
 #   DelaySecs(600);

      
    # start the defrag ( for the 1st vdisk deleted )
    $ret = DefragAllBegin($ctlr);                                     # parallel defrag
    if ( $ret != GOOD ) { return ERROR; }

    # end of setup...

  #  CtlrLogTextAll( $coPtr, "Defrag Case 1: Delay 10 minutes while defrag runs, before 2nd c/s");
  #  DelaySecs(600);

    # redicp the next vdisk - wait for completion, check status
    $ret = RediCpVdisks($ctlr, $oldVds[1], $newVds[1] );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = WaitForCpComplete( $ctlr, $newVds[1] );
    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }
    
  #  CtlrLogTextAll( $coPtr, "Defrag Case 1: Delay 10 minutes while defrag runs, after 2nd c/s");
  #  DelaySecs(600);

    # wait for defrag to complete, check     
    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

  #  CtlrLogTextAll( $coPtr, "Defrag Case 1: Delay 10 minutes after defrag is complete");
  #  DelaySecs(600);

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # defrag the 2nd disk - wait for completion, check status
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVds[1]) ) 
    {
        return ERROR;
    }

  #  CtlrLogTextAll( $coPtr, "Defrag Case 1: Delay 10 minutes before 2nd defrag");
  #  DelaySecs(600);

    # defrag all drive ( for the 1st vdisk deleted )
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    
    #
    # Steps are 1) pick an active vdisk
    #           2) get its size
    #           3) create a new one
    #           3) get baseline IO activity info
    #           4) start the redi CP
    #           5) wait for redicp to complete
    #           5) confirm IO still going
    #           6) defrag again
    #           7) confirm IO still Ok
    ######################################################################

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }
    

  #  CtlrLogTextAll( $coPtr, "Defrag Case 1: Delay 10 minutes after 2nd defrag");
  #  DelaySecs(600);

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 1.");


    return GOOD;

}

###############################################################################

=head2 DefragCase2 function

This test case deletes a vdisk and does a redi-copy while defrag is running. 
The defrag is allowed to complete and another defrag is done. The test has 
these basic steps...

    Setup ( get initial server activity info )
    Find a vdisk, make a replacement and do a redi-copy
    Wait for the copy to complete
    Verify IO is still running
    Find a 2nd vdisk, make a replacement and do a redi-copy
    Wait for the copy to complete
    Find a 3rd vdisk and make a replacement 
    Delete the 1st copied disk
    Begin defrag on the disks
    Start a redi-copy of the 3rd vdisk
    Delete the 2nd copied vdisk
    Defrag the pdisks
    Wait for the defrag to complete
    Verify IO is still running
    Delete the 3rd copied vdisk
    Begin defrag on the disks
    Wait for the defrag to complete
    Verify IO is still running
    Check the SOS tables

=cut

=over 1

=item Usage:

 my $rc = DefragCase2( $coPtr, $retIn, $snPtr  );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: DefragCase2
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase2
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd1;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my $oldVd2;
    my $oldVd3;
    my $newVd2;
    my $newVd3;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 2: delete a vdisk and do a redi-cp while running defrag ------";
    $msg0 = "-------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    #
    # Do initial defrag to ensure no fragments initially
    #
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    DispVdiskInfo($ctlr);


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     

    ######################################################################
    # With a defrag running, rediCP one of the first vdisks to a new one.
    # While redicp is running, delete another vdisk, start another defrag.
    # Finally, delete the old one and start another defrag. 
    ######################################################################

    # find an early disk  ( get all 3 for the test)
    @oldVds = FindEarlyVdisk( $ctlr, 3 );     # find three vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    if ( scalar(  @oldVds ) < 3 ) 
    { 
        return ERROR; 
    }

    # create a new, slightly bigger vdisk
    $newVd1 =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd1 < 0 ) { return ERROR; }

    # redicp the vdisks to the new location
    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd1 );
    if ( $ret != GOOD ) { return ERROR; }

    # wait for complete, will delete disk later
    $ret = WaitForCpComplete( $ctlr, $newVd1 );
    if ( $ret != GOOD ) { return ERROR; }



    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # find the 2nd early  vdisk
    #@oldVds = FindEarlyVdisk( $ctlr, 1 );     # find three vdisks
    #if ( $oldVds[0] == INVALID ) { return ERROR; }

    # make a sightly bigger copy
    $oldVd2 = $oldVds[1];
    $newVd2 =  CreateReplacementVdisk($ctlr, $oldVds[1] );
    if ( $newVd2 < 0 ) { return ERROR; }


    # start redicp
    $ret = RediCpVdisks($ctlr, $oldVds[1], $newVd2 );
    if ( $ret != GOOD ) { return ERROR; }
    
    # wait for done
    $ret = WaitForCpComplete( $ctlr, $newVd2 );
    if ( $ret != GOOD ) { return ERROR; }

    # now we have 2 unused vdisks at the front

    # find next (3rd) early vdisk 
    #@oldVds = FindEarlyVdisk( $ctlr, 1 );     # find three vdisks
    #if ( $oldVds[0] == INVALID ) { return ERROR; }

    # create a slightly larger vdisk
    $oldVd3 = $oldVds[2];
    $newVd3 =  CreateReplacementVdisk($ctlr, $oldVds[2] );
    if ( $newVd3 < 0 ) { return ERROR; }

    # delete the first copied disk (after we make the new ones)
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd1) ) 
    {
        return ERROR;
    }

        # defrag the first deleted vdisk - no wait for completion
    $ret = DefragAllBegin($ctlr);                                      # parallel
    if ( $ret != GOOD ) { return ERROR; }

    # redicp the 3rd vdisk - no wait for completion
    logInfo("Beginning redi-cp on third vdisk($oldVds[2] to $newVd3) while defragging first.");
    $ret = RediCpVdisks($ctlr, $oldVds[2], $newVd3 );
    if ( $ret != GOOD ) { return ERROR; }

    # delete 2nd vdisk
    logInfo("Delete 2nd vdisk($newVd2) while defragging 1st and redi-cp on 3rd.");
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd2) ) 
    {
        return ERROR;
    }

    DelaySecs(30);

    $ret = DefragWait( $ctlr );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed waiting for first defrag to end. <<<<<<<<");
        return (ERROR);
    }
    
    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    
    # begin defrag for 2nd vdisk (1st may still be running)
    logInfo("Defrag 2nd (1st defrag done, redi-copy may be done).");
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }
    
    # wait for done
    $ret = WaitForCpComplete( $ctlr, $newVd3 );
    if ( $ret != GOOD ) { return ERROR; }
    
    # delete 3rd vdisk
    logInfo("      deleting the 3rd source vdisk");
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd3) ) 
    {
        return ERROR;
    }
    
    # begin defrag, wait for complete
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }
    
    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 2.");

    return GOOD;

}

###############################################################################

=head2 DefragCase3 function

This test case moves a target while a defrag is running. The 
following steps are done...

    Setup ( get initial server activity info )
    Find a vdisk, make a replacement and do a redi-copy
    Wait for the copy to complete
    Find the owning controller/target for this vdisk
    Delete the source vdisk
    Start the defrag operation
    Move the target to a different controller
    Verify IO is still running
    Check the SOS tables
    Move the target back to the original controller
    Verify IO is still running
    Check the SOS tables


=cut

=over 1

=item Usage:

 my $rc = DefragCase3( $coPtr, $retIn, $snPtr  );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase3
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase3
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    
    my @oldVds;
    my $newVd;
    my $ctlr;
    my @coList;
    my $master;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $msg;
    my $msg0;
    my @snList;
    my $index;
    my $targ;
    my $index2;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 3: move a target during defrag ------";
    $msg0 = "------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    @snList = @$snPtr;

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     

    ######################################################################
    # With defrag running, move an active target, see what happens, 
    # move it back.
    ######################################################################

    # Find an early vdisk

    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }


    # make new vdisk
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }


    # start redicp, wait for completion

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }

    # find owner of the busy, just moved disk

    ($index, $targ) = FindVdiskOwner($coPtr, $snPtr, $oldVds[0]);
    if ( $index == INVALID ) { return ERROR; }
    if ( $targ == INVALID ) { return ERROR; }

    # delete the copied vdisk
    logInfo("Deleting $newVd");

    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) ) 
    {
        return ERROR;
    }

    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # start defrag
    $ret = DefragAllBegin( $ctlr );                                   # parallel
    if ( $ret != GOOD ) { return ERROR; }

    # move the target to another controller
    
    $index2 = 0;
    if ( $index == 0 ) { $index2 = 1; }

    $ret = MoveTarget($ctlr, $snList[$index2], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    DelaySecs(30);

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }
   
    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # move the target back

    $ret = MoveTarget($ctlr, $snList[$index], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    # probably need a delay here.
    DelaySecs(30);

    $ret = RescanBE( $ctlr);
    if ( $ret == ERROR )
    {
        return ERROR;
    }

    DelaySecs(20);

    # verify IO
    
    logInfo("There should be some rebuilds running now, look for degraded disks.");

    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }
    
    

    # wait for all pdisks and raids to be operational and nothing happening
    logInfo("Waiting for any rebuilds caused by the taget move to finish.");
    $ret = WaitRebuild( $ctlr );    
    if ( $ret != GOOD ) { return ERROR; }


    # check defrag state, and restart the defrags
    logInfo("Expect some drives to be fragmented as defrag was not completed.");
    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("Re-starting the defrags.");
    $ret = DefragAll( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 3.");

    return GOOD;

}

###############################################################################

=head2 DefragCase4 function

This test case does controller failover while a defrag is running. The 
following steps are done...

    Setup ( get initial server activity info )
    Find a vdisk, make a replacement and do a redi-copy
    Wait for the copy to complete
    Delete the source vdisk
    Start a defrag
    Fail the owning controller/target for this vdisk
    Verify IO is still running
    Unfail the controller
    Verify IO is still running
    Wait for defrag to complete
    Verify IO is still running
    Check SOS tables


=cut

=over 1

=item Usage:

 my $rc = DefragCase4($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is the IP address of the Moxa controller
        $mmPtr is a pointer to a list of tha Moxa channel mappings

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut



##############################################################################
#
#          Name: DefragCase4
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase4
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newV;
    my @newVds;
    my $ret;
    my %info;
    my $needed;
    my $slave;
    my $si;
    my $ctlrS; 
    my $newVd1;
    my $vid1;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 4: Failover during defrag ------";
    $msg0 = "-------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    #logInfo(">>>>>>>>  THIS TEST IS EXPECTED TO FAIL  <<<<<<<<");
    #logInfo(">>>>>>>>  FAILING OWNER WILL STOP DEFRAG <<<<<<<<");

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    #
    # Do initial defrag to ensure no fragments initially 
    #
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    DispVdiskInfo($ctlr);

   
    $si = 0;
    if ( $master == 0 ) { $si = 1; }

    $ctlrS = $coList[$si];

    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
    ######################################################################
    # With defrag running, fail a controller, see what happens.
    # Unfail the controller, see what happens. Confirm IO both times.
    ######################################################################
    
    # find all unowned disks
    # delete them
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # find an early vdisk 
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # get all, ordered 
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # make a new vdisk
    $newVd1 =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd1 < 0 ) { return ERROR; }


    # redicp the disk
    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd1 );
    if ( $ret != GOOD ) { return ERROR; }
    
    # wait for done
    $ret = WaitForCpComplete( $ctlr, $newVd1 );
    if ( $ret != GOOD ) { return ERROR; }


    # delete the vdisk
    logInfo("Deleting $newVd1");

    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd1) ) 
    {
        return ERROR;
    }

    # start defrag
    logInfo("Starting defrag all");
    $ret = DefragAllBegin( $ctlr );                              # parallel
    if ( $ret != GOOD ) { return ERROR; }


    # fail the controller that owned the vdisk being used

    logInfo("failing controller.1");
    $ret = FailMyOwner($coPtr, $snPtr, $oldVds[0] );
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("          Pausing 2 minutes while failover occurs");
    DelaySecs(120);

   
    # unfail the controller
    logInfo("          Now unfail the controller");
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    logInfo("Verify I/O after unfailing controller");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    #
    # Find the master in case it changed
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    $ctlr = $coList[$master];

    # wait for defrag to complete

    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    # there are also some rebuilds running so we should wait for them to
    # to complete also.

    # wait for all pdisks and raids to be operation and nothing happening
    $ret = WaitRebuild( $ctlr );    
    if ( $ret != GOOD ) { return ERROR; }

    # double check defrags 
    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }



    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 4.");


    return GOOD;

}

###############################################################################

=head2 DefragCase5 function

This test case starts defrag on two controllers while IO is running. The 
following steps are done...

    Setup ( get initial server activity info )
    On the master, find a vdisk, make a replacement 
    On a slave, find a vdisk, make a replacement
    Begin redi copy on the master
    Begin redi copy on the slave
    Wait for both redi copy operations to complete
    Verify IO is still running
    Delete both source vdisks
    Start Defrag on both controllers
    Wait for all defrags to complete
    Verify IO is still running
    Check SOS tables
     



=cut

=over 1

=item Usage:

 my $rc = DefragCase5($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut




##############################################################################
#
#          Name: DefragCase5
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase5
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newV;
    my @newVds;
    my $ret;
    my %info;
    my $needed;
    my $slave;
    my $si;
    my $ctlrS;
    my $vid1;
    my $newVd1;
    my $vid2;
    my $newVd2;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 5: defrag on both controllers with IO running ------";
    $msg0 = "---------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    #
    # Do initial defrag to ensure no fragments initially
    #
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }


    DispVdiskInfo($ctlr);

   
    $si = 0;
    if ( $master == 0 ) { $si = 1; }

    $ctlrS = $coList[$si];

    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
    
    ###################################################################### 
    # Delete some vdisks, start defrag on both controllers, observe
    ######################################################################


    # find an early vdisk - owned by the first controller
    
    %info = $ctlr->virtualDiskCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    $needed = $info{COUNT};

#    # we ask for all the vdisks so that we  can later make 
#    # requests from the sorted list.
#
#    @oldVds = FindEarlyVdisk( $ctlr, $needed );     # get all, ordered 
#    if ( $oldVds[0] == INVALID ) { return ERROR; }
#    
#    # got the list, now find the first one for first controller
#
#    logInfo("Finding vdisk owned by CN0");
#    $vid1 = FirstVdiskOnCtlr($coPtr, \@oldVds, 0, $snPtr);
#    if ( $vid1 == INVALID ) 
#    { 
#        logInfo("Unable to find suitable vdisks, test cannot run.");
#        return ERROR; 
#    }
#
#
#    # make a new vdisk
#    
#    $newVd1 =  CreateReplacementVdisk($ctlr, $vid1 );
#    if ( $newVd1 < 0 ) { return ERROR; }
#
#    # find an early vdisk - owned by the second controller
#    logInfo("Finding vdisk owned by CN1");
#    $vid2 = FirstVdiskOnCtlr($coPtr, \@oldVds, 1, $snPtr);
#    if ( $vid2 == INVALID )  
#    { 
#        logInfo("Unable to find suitable vdisks, test cannot run.");
#        return ERROR; 
#    }
#    
#    # make a new vdisk
#    
#    $newVd2 =  CreateReplacementVdisk($ctlr, $vid2 );
#    if ( $newVd2 < 0 ) { return ERROR; }
#    
#    # start redicp on each controller
#    
#    logInfo("      Start a redi-copy task on both controllers");
#    $ret = RediCpVdisks($ctlr, $vid1, $newVd1 );
#    if ( $ret != GOOD ) { return ERROR; }
#
#
#    $ret = RediCpVdisks($ctlr, $vid2, $newVd2 );
#    if ( $ret != GOOD ) { return ERROR; }
#
    # wait for all to complete

    my @srcVdisks;
    my @dstVdisks;
    
    $ret = TestLibs::BEUtils::FindVdiskForEachController($coPtr, \@srcVdisks);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # loop to make replacements 
    #
    for ( $si = 0; $si < scalar(@srcVdisks); $si++)
    {
        # create a replacemment
        if (  $srcVdisks[$si] == INVALID ) { next; }      # skip if no disk on controller
        $dstVdisks[$si] =  CreateReplacementVdisk($ctlr, $srcVdisks[$si] );
        if ( $dstVdisks[$si] < 0 ) { return ERROR; }
    }
    
    #
    # loop to start copies
    #
    for ( $si = 0; $si < scalar(@srcVdisks); $si++)
    {
        if (  $srcVdisks[$si] == INVALID ) { next; }      # skip if no disk on controller
        # start a copy
        $ret = RediCpVdisks($ctlr, $srcVdisks[$si], $dstVdisks[$si] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    #
    # loop to wait for copies to end
    #
    for ( $si = 0; $si < scalar(@srcVdisks); $si++)
    {
        if (  $srcVdisks[$si] == INVALID ) { next; }      # skip if no disk on controller
        # wait for each copy to complete
        $ret = WaitForCpComplete( $ctlr, $dstVdisks[$si] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }


#    logInfo("      Allowing redi-copy to complete on both controllers");
#    $ret = WaitForCpComplete( $ctlr, $newVd1 );
#    if ( $ret != GOOD ) { return ERROR; }
#
#
#    $ret = WaitForCpComplete( $ctlr, $newVd2 );
#    if ( $ret != GOOD ) { return ERROR; }
#
#    $ret = TestNReconnect($ctlrS);
#    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    
    #
    # loop to delete source raids(vdisks)
    #
    for ( $si = 0; $si < scalar(@srcVdisks); $si++)
    {
        if (  $srcVdisks[$si] == INVALID ) { next; }      # skip if no disk on controller
        # delete vdisk
        $ret = DeleteSingleVdisk($ctlr, $dstVdisks[$si] );
        if ( $ret != GOOD ) { return ERROR; }
    }



    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    # start defrag on master controllers 
       
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # we probably timed out the slave controller, so, reconnect

    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }


    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }
    

#    $ret = DefragWait( $ctlrS );
#    if ( $ret != GOOD ) { return ERROR; }


    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }
    
    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 5.");


    return GOOD;

}

###############################################################################

=head2 DefragCase6 function

This test case starts defrag on two controllers while IO is running. The 
defrag is chosen so that IO will not move. The 
following steps are done...

    Setup ( get initial server activity info )
    Delete all unused vdisks
    Defrag all pdisks, wait for completion
    Run DefragPart2 ( create 2, delete 1st, defrag loop ) on master
    Verify IO is still running
    Check SOS tables
    Wait for any defrags to complete
    Verify IO is still running
    Check SOS tables


=cut

=over 1

=item Usage:

 my $rc = DefragCase6($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut




##############################################################################
#
#          Name: DefragCase6
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase6
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newV;
    my @newVds;
    my $ret;
    my %info;
    my $needed;
    my $slave;
    my $loops;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    $loops = 5;
    

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 6: while IO runs, defrag disks, but don't move IO ------";
    $msg0 = "-------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
    


    ######################################################################
    # Do the create 2, delete one, defrag loop. Do this with the IO before
    # the defrag. IO does not move location during the defrag.
    ######################################################################
    
    
    # find all unowned disks
    # delete them
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # start defrag  (to assure no initial gaps)
    $ret = DefragAll( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }
 
    # call defrag part 2, 5 loops, do on master
    $ret = DefragPart2($coList[$master], $loops, NO_RAID_INIT | DEFRAG_WAIT);
    
    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # call defrag part 2, 5 loops, do on master
    $ret = DefragPart2($coList[$master], $loops, NO_RAID_INIT | DEFRAG_WAIT);
    
    # wait for defrag to complete

    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }
    
    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 6.");

    
    return GOOD;

}

###############################################################################

=head2 DefragCase7 function

This test case starts defrag on two controllers while IO is running. The 
defrag is chosen so that IO will move. The 
following steps are done...

    Setup ( get initial server activity info )
    Find 5 early vdisks, make clones and start redi copy on all
    Wait for copies to complete
    Delete the five source vdisks
    Verify IO is still running
    Delete all unused vdisks
    Defrag all pdisks, wait for completion
    Verify IO is still running
    Check SOS tables


=cut

=over 1

=item Usage:

 my $rc = DefragCase7($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut



##############################################################################
#
#          Name: DefragCase7
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase7
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ret;
    my @oldVds;
    my @newVds;
    my $newVd;
    my $i;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 7: Defrag all disks while IO is running ------";
    $msg0 = "---------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    #
    # Do initial defrag to ensure no fragments initially
    #
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }


    DispVdiskInfo($ctlr);



    # get measure of the current IO


 
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
  
    ######################################################################
    # Move all the IO to later in the drive (redicp)
    # Delete some of the source vdisks
    # Defrag the drives ( forces IO to shift position
    ###################################################################### 

    # find the first 5 early vdisks
    @oldVds = FindEarlyVdisk( $ctlr, 5 );     # find  vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # create 5 vdisks for copies
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
        #push ( @newVds, $newVd);
    }

    # do 5 redicp operations
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    # delete the source vdisks
    for ($i = 1; $i < scalar( @oldVds); $i++ )
    {
        logInfo("Deleting $oldVds[$i]");
        if ( ERROR == DeleteSingleVdisk($ctlr, $newVds[$i]) ) 
        {
            return ERROR;
        }
    }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # defrag it all
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO

    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 7.");


    return GOOD;

}

###############################################################################

=head2 DefragCase8 function

This test case deletes any currently unused vdisks and then defrags. This 
essentially packs the IO. The following steps are done...

    Setup ( get initial server activity info )
    Delete all unassociated vdisks
    Verify IO is still running
    Defrag all pdisks, wait for completion
    Verify IO is still running
    Check SOS tables


=cut

=over 1

=item Usage:

 my $rc = DefragCase8($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut



##############################################################################
#
#          Name: DefragCase8
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase8
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ret;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 8: Defrag all disks while IO is running ------";
    $msg0 = "---------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ###################################################################### 
    # delete all inactive vdisks, defrag. This essentially packs the disk.
    # and pack the IO.
    ######################################################################


    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # defrag all pdisks
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 8.");

    
    return GOOD;

}

###############################################################################

=head2 DefragCase9 function

This test case deletes any currently unused vdisks and then defrags. This 
essentially packs the IO. Then a buch of new vdisks are created and the IO
moved to them. The original disks are dleted and then the system is defraged.
The following steps are done...

    Setup ( get initial server activity info )
    Delete all unassociated vdisks
    Verify IO is still running
    Defrag all pdisks, wait for completion .... system is now 'packed'
    Create a bunch of vdisk clones( 1/2 number of existing vdisks, 
          randomly chosen)
    Run redi copy on all old/clone pairs
    Wait for redi copy operations to complete
    Verify IO is still running
    Delete all the source ( unused) vdisks
    Begin defrag on the pdisks
    Verify IO is still running
    Wait for defrags to complete
    Verify IO is still running
    Check SOS tables


=cut

=over 1

=item Usage:

 my $rc = DefragCase9($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase9
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR      
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase9
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $ret;
    my %info;
    my $needed;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 9: while IO runs, defrag disks before and after redicopy ------";
    $msg0 = "--------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 9: while IO runs, defrag disks before and after redicopy." );

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    # get measure of the current IO

  
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
    
    ######################################################################
    # delete all unuased vdisks, defrag (pack system) then create a bunch
    # of vdisks and randomly redicp the vdisks to move the IO all over
    # the place. Delete the unused vdisks, defrag. Testing IO between 
    # each step
    ###################################################################### 

    # find all unowned disks
    # delete them
    
    logInfo("      Preparing for test by deleting unused vdisks");
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # defrag all pdisks

    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 9: config Ok, make replacement disks." );

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # create vdisks (number = 1/2 number of active vdisks)

    %info = $ctlr->virtualDiskCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    $needed = $info{COUNT} / 2;

    @oldVds = GetRandomVdisks( $ctlr, $needed );     # find some vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # got disks to copy, make the replacements
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
    }

    # may need to refresh the connection to the slave
    TestNReconnectAll($coPtr);

    CtlrLogTextAll($coPtr, "Test Case 9: begin copies." );

    
    # copy half vdisks to new ones (random selection)
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    CtlrLogTextAll($coPtr, "Test Case 9: copies complete." );
    
    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 9: delete sources." );
    
    # delete unused vdisks
    logInfo("      Deleting the vdisks that were sources for the copies");
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 9: deleted sources, start defrag." );
    
    # defrag pdisks
    $ret = DefragAll($ctlr);                         # parallel
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO    
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 9: defrags complete." );

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 9.");
    CtlrLogTextAll($coPtr, "Test Case 9: test ends." );


    
    return GOOD;

}

##############################################################################
#
#          Name: DefragCase10
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: This case is not supported by the featues in the controller 
#
##############################################################################
sub DefragCase10
{
    trace();
    my ( $ctlr ) = @_;



    ###################################################################### 
    # start a bunch of defrags. kill them off, check SOS tables.
    ###################################################################### 

    # pick 3 random vdisks

    # make new vdisks for copies

    # redicp the vdisks, wait for complete

    # delete source vdisks

    # verify IO

    # check SOS tables

    # start defrags
    
    # check SOS tables

    # terminate defrags on half - CAN'T DO THIS, FEATURE NOT AVAILABLE

    # check sos tables

    # wait for other half to complete

    # check sos tables

    # restart 1st half - CAN'T DO THIS, FEATURE NOT AVAILABLE

    # wait for complete

    # check sos tables

    # verify IO
    
    return GOOD;

}

###############################################################################

=head2 DefragCase11 function

This test case starts a redi copy operation while defrag is running. The 
following steps are done...

    Setup ( get initial server activity info )
    Identify three vdisks, make replacements and redi copy them
    Wait for redi copy operations to complete
    Verify IO is still running
    Delete all the source ( unused) vdisks
    Begin defrag on the pdisks
    Check SOS tables
    Verify IO is still running
    Find up to three vdisks that are moving
    Begin redi copy on the three
    Wait for redi copy to complete
    Verify IO is still running
    Check SOS tables
    Delete all the source ( unused) vdisks
    Begin defrag on the pdisks
    Wait for defrag to complete
    Verify IO is still running
    Check SOS tables



=cut

=over 1

=item Usage:

 my $rc = DefragCase11($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase11
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase11
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $j;
    my $k;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $ret;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;




    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 11: launch a redi-copy operation while defragging some vdisks ------";
    $msg0 = "-------------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    #
    # Do initial defrag to ensure no fragments initially
    #
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    DispVdiskInfo($ctlr);


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     

    ###################################################################### 
    # start a bunch of defrags, kill them off. check SOS tables.
    # redicp some of the partially moved vdisks. Delete all the unused
    # vdisks and defrag.
    ###################################################################### 

    # select 3 random vdisks

    @oldVds = GetRandomVdisks( $ctlr, 3 );     # find three vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    if ( scalar(@oldVds) != 3 ) { return ERROR; }

    
    # create 3 replacement vdisks
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] =  $newVd;
        push ( @newVds, $newVd);
    }

    CtlrLogTextAll($coPtr, "Test Case 11: Begin copies to fragment some disks" );

    # redicp the 3 vdisks, wait for complete
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    # find all unowned disks
    # delete them
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # defrag pdisks
    CtlrLogTextAll($coPtr, "Test Case 11: Begin Defrag to move some disks" );

    $ret = DefragAllBegin($ctlr);                      # parallel
    if ( $ret != GOOD ) { return ERROR; }


    # after a while, stop the defrags
      # this is not an option, at least not directly, so just go on

    # check sos tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }



    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # identify partially moved vdisks

    # "defrag all" made it difficult to find moving vdisks, so we
    # will take early vdisks instead and assume they will be moving as
    # we have been deleting vdisks. We skip the first 2 and take the
    # next 3 for this test 

    my $skippedVds = 2;

    @oldVds = FindEarlyVdisk( $ctlr, 5 );     # find three vdisks
    # @oldVds = FindMovingVdisks( $ctlr, 3 );     # find up to three vdisks
    if ( scalar(@oldVds) < 1 ) { return ERROR; }      # want at least one
    if ( $oldVds[0] == INVALID ) { return ERROR; }


    # create some new vdisks
    for ( $i = $skippedVds; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
        #push ( @newVds, $newVd);
    }


    # redicp the partially moved vdisks to the new ones
    CtlrLogTextAll($coPtr, "Test Case 11: begin redi-cp on some partially moved disks (while doing defrag)" );

    for ( $i = $skippedVds; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = $skippedVds; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }
    CtlrLogTextAll($coPtr, "Test Case 11: all copies are complete" );


    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # check SOS tables
    
    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }


    # delete all unused disks
    CtlrLogTextAll($coPtr, "Test Case 11: Deleting no longer used vdisks" );
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    DelaySecs(30);           # allow deletes to propagate
    
    $ret = DefragAllBegin($ctlr);                      # parallel

    $ret = DefragAllBegin($ctlr);          # deliberately NOT checking the 
                                           # return as the previous one may
                                           # still be runnng.
    $ret = DefragWait( $ctlr );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed waiting for test defrag to end. <<<<<<<<");
        return (ERROR);
    }
    


    # defrag all pdisks
    CtlrLogTextAll($coPtr, "Test Case 11: Begin defrag to clean up after test." );

    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 11: System is defragmented, final IO verification" );
    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    CtlrLogTextAll($coPtr, "Test Case 11: System is defragmented, final check of SOS tables" );
    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 11.");
    CtlrLogTextAll($coPtr, "Test Case 11: End of test" );

    return GOOD;

}

###############################################################################

=head2 DefragCase12 function

This test case fails a pdisk while defrag is running. The rebuild is
allowed to complete and then another defrag is done. There is also IO
running during the test. The 
following steps are done...

    Setup ( get initial server activity info )
    Identify three vdisks, make replacements and redi copy them
    Wait for redi copy operations to complete
    Delete two of the three old vdisks
    Verify IO is still running
    Check SOS tables
    Start defrag on the first data pdisk
    Fail the second pdisk
    Check SOS tables
    Allow the rebuild to finish
    Verify IO is still running
    Delete the third copied vdisk
    Begin defrag on the pdisks
    Verify IO is still running
    Check SOS tables
    Wait for defrag to complete
    Verify IO is still running
    Check SOS tables




=cut

=over 1

=item Usage:

 my $rc = DefragCase12($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 

 Unlike most other tests where IO is optional, this test requires IO so that
 a pdisk rebuild will be started.




=back

=cut


##############################################################################
#
#          Name: DefragCase12
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase12
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my @pdds2;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 12: fail a pdisk while running defrag, do rebuild ------";
    $msg0 = "-------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    my $productID =  getMagProductID( 0, $ctlr);
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }
    
    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    # verify we have hotspares to work with for this test
    logInfo("      Determining the number of hot spare drives.");
    @hotSpares = GetTheseDisks( $ctlr, CCBEHOTSPARETYPE);
    if ( $hotSpares[0] == INVALID) { return ERROR; }
    if ( scalar (@hotSpares) < 1) 
    {
        logInfo ("We don't have a hotspare for the test. Test fails.");
        return ERROR;
    }

    #logInfo("With the new Defrag All implementation, this test is now obsolete.");
    #return $retIn;

    #
    # Do initial defrag to ensure no fragments initially
    #
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
    ###################################################################### 
    # start a defrag on a single drive (make sure it has lots to move)
    # fail a drive, observe what happens, (don't trash a raid 0,1 drive)
    # let the rebuild happen, delete a vdisk, defrag again.
    ###################################################################### 

    # find 3 early vdisks

    @oldVds = FindEarlyVdisk( $ctlr, 3 );     # find three vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    if ( scalar(@oldVds) != 3 ) { return ERROR; }
    
    # make 3 new vdisks
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
        #push ( @newVds, $newVd);
    }

    # redicp the vdisks, wait for complete
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    # we now have space at the beginning to defrag away.

    # delete 2 source vdisks   ( 2nd and 3rd one )

    for ($i = 1; $i < 3; $i++ )
    {
        logInfo("Deleting $newVds[$i]");

        if ( ERROR == DeleteSingleVdisk($ctlr, $newVds[$i]) ) 
        {
            return ERROR;
        }

    }



    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # check sos tables
    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    
    # start defrag on one PDD ( one with only R10 drives )
    # this really begins the test
    # first find two PDDs to work with

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # use @pdd[0] as the one to start defrag on, use @pdds[1] as the one to fail
    # note, a hotspare was verified at the beginning.

    $ret = StartSingleDefrag($ctlr, $pdds[0]);
    if ( $ret != GOOD ) { return ERROR; }


    # New defrag code will not allow an additional defrag start 
    # until after the previous defrag ends, so....
    push (@pdds2, $pdds[0]);
    
    $ret = DefragWait( $ctlr, \@pdds2 );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed waiting for first defrag to end. <<<<<<<<");
        return (ERROR);
    }

    # fail a different drive

    if ( $productID == 2750 )
    {
        $ret = FailPdisk( $coPtr, $pdds[1], PDISKFAIL );
    }
    else
    {
        $ret = FailPdisk( $coPtr, $pdds[1] );
    }
    
    # check sos tables
    
    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }
    
    #
    # Since we may have rebuilt over to a hotspare, we need to make sure the
    # pdisk labels are correct.
    # 
    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

        
    # delete last source vdisk (actually, the first one found)

    logInfo("Deleting $newVds[0]");
    %rsp = $ctlr->virtualDiskDelete($newVds[0]);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from virtualDiskDelete <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Unable to delete virtual disk $oldVds[0]. <<<<<");
        PrintError(%rsp);
        return ERROR;
    }


    # defrag all drives

    $ret = DefragAll($ctlr);                        # parallel
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }


    # we have failed a drive, that is not good as far as any following test goes,
    # we need to restore the pdisk to a 
    # useable state (pdiskrestore and label as a new hotspare)



    ########################
    # 'restore' the drive
    ########################

    $ret = UnfailPdisk($coPtr, $pdds[1]);
    if ( $ret == ERROR )
    {
        return ERROR;
    }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }
    
#    logInfo("restoring the physical drive");
#    %rsp = $ctlr->physicalDiskRestore($pdds[1]);
#    if ( ! %rsp  )
#    {
#        logInfo(">>>>>>>> Failed to get response from physicalDiskRestore <<<<<<<<");
#        return ERROR;
#    }
#
#    if ($rsp{STATUS} != PI_GOOD)
#    {
#        logInfo(">>>>>>>> Unable to restore drive $pdds[1]. <<<<<<<<");
#        PrintError(%rsp);
#        return ERROR;
#    }
#
#    $ret = RescanBE( $ctlr);
#    if ( $ret == ERROR )
#    {
#        return ERROR;
#    }
#
#    ##################################
#    # Label the drive as a hotspare
#    ##################################
#    
#    $ret = LabelSingleDrive( $ctlr, $pdds[1], CCBEUNLABLEDTYPE);
#    if ( $ret == ERROR )
#    {
#        return ERROR;
#    }
#    $ret = LabelSingleDrive( $ctlr, $pdds[1], CCBEHOTSPARETYPE);
#    if ( $ret == ERROR )
#    {
#        return ERROR;
#    }


    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 12.");


    return GOOD;

}

###############################################################################

=head2 DefragCase13 function

This test case creates and initializes vdisks while defrag is running. 
The rebuild is
allowed to complete and then another defrag is done. There is also IO
running during the test. The 
following steps are done...

    Setup ( get initial server activity info )
    Identify a vdisk, make a clone
    Start redi copy, wait for completion
    Check SOS tables
    Delete the source vdisk
    Begin defrag on the pdisks
    Check SOS tables
    Get a list of current vdisks
    make two new vdisks, do not initialize
    Check SOS tables
    Start init on the new vdisks
    Check SOS tables
    Wait for init to end
    Check SOS tables
    Verify IO is still running
    Begin defrag on the pdisks
    Wait for defrag to end
    Check SOS tables
    Verify IO is still running


=cut

=over 1

=item Usage:

 my $rc = DefragCase13($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase13
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase13
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    
    my @oldVds;
    my $newVd;
    my $ctlr;
    my @coList;
    my $master;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $msg;
    my $msg0;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 13: create and init vdisks while defrag runs ------";
    $msg0 = "--------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     

    ###################################################################### 
    # start some defrags, check sos tables, create some vdisks,
    # check sos tables, start inits, check sos tables, wait for inits
    # to finish, check sos tables, defrag, test sos tables.
    ###################################################################### 

    # find an early vdisk
    logInfo("      Finding an early vdisk");
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }


    # make a vdisk

    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }

    # begin redicp, wait for end

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }


    # delete the first copied disk (after we make the new one)
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) ) 
    {
        return ERROR;
    }

    # check sos tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # begin defrags. The test is to see what happens as we create
    # a vdisk and do the inits 

    $ret = DefragAllBegin( $ctlr );                     # parallel
    if ( $ret != GOOD ) { return ERROR; }
    
    # check sos tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # create some vdisks
    
 
    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)
    $ret = MakeVdisks($ctlr, 14, NO_RAID_INIT );  # option 14 is 2 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
        return (ERROR);
    }
     


    # check sos tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # start inits on new vdisks
    logInfo("      Starting raids inits, this will stop the defrags");
    $ret = InitNewerVdisks( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }
    
    # check sos tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );      # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # wait for init to end

    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }

    # check sos tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );      # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO

    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # restart the defrags since the inits stopped them
    logInfo("      Restarting the defrags");
    $ret = DefragAll( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    # check sos tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 13.");

    return GOOD;

}

###############################################################################

=head2 DefragCase14 function

This test case has no supporting code. It is intended to be a random test.

=cut

=over 1

=item Usage:

 my $rc = DefragCase14($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase14
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase14
{
    trace();
    my (  $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr  ) = @_;



    ###################################################################### 
    # do all this randomly
    ###################################################################### 

    
    return GOOD;

}
###############################################################################

=head2 DefragCase15 function


This test case has no supporting code.

=cut

=over 1

=item Usage:

 my $rc = DefragCase15($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase15
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase15
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $ret;
    my %info;
    my $needed;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 15: while IO runs, defrag disks before and after redicopy ------";
    $msg0 = "--------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     

    ######################################################################
    # defrag (pack system) then create a bunch
    # of vdisks and randomly redicp the vdisks to move the IO all over
    # the place. Delete the unused vdisks, defrag. Testing IO between 
    # each step
    ###################################################################### 

    # create vdisks (number = 1/2 number of active vdisks)

    %info = $ctlr->virtualDiskCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    $needed = $info{COUNT} / 2;

    @oldVds = GetRandomVdisks( $ctlr, $needed );     # find some vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # got disks to copy, make the replacements
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
    }


    
    # copy half vdisks to new ones (random selection)
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }


    # find all unowned disks
    # delete them
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    
    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }


    # defrag all pdisks
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 15.");


    
    return GOOD;

}

##############################################################################
#
#          Name: DefragCase16
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase16
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr  ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $j;
    my $k;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $ret;
    my $index2;

    my @vdisks; 
    my $numVDDs; 
    my @pdds; 
    my $lc;  
    my $vid1; 
    my $newVd1; 
    my @snList;
    my $targ; 
    my $index;
 

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 16: debug of some of the modules in the test (OBSOLETE) ------";
    $msg0 = "-------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

return GOOD;

# uses moveTarget

    @coList = @$coPtr;
    
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    @snList = @$snPtr;

    
    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
    ###################################################################### 
    # start a bunch of defrags, kill them off. check SOS tables.
    # redicp some of the partially moved vdisks. Delete all the unused
    # vdisks and defrag.
    ###################################################################### 

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find three vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # find owner of the  disk

    ($index, $targ) = FindVdiskOwner($coPtr, $snPtr, $oldVds[0]);
    if ( $index == INVALID ) { return ERROR; }
    if ( $targ == INVALID ) { return ERROR; }



    # move the target to another controller
    
    $index2 = 0;
    if ( $index == 0 ) { $index2 = 1; }

    $ret = MoveTarget($ctlr, $snList[$index2], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }
 
    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # move the target back

    $ret = MoveTarget($ctlr, $snList[$index], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO

    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # fail the controller that owned the vdisk being used

    $ret = FailMyOwner($coPtr, $snPtr, $oldVds[0] );
    if ( $ret != GOOD ) { return ERROR; }


    # unfail the controller
    
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 

    $ctlr = $coList[$master];


    # verify IO   but not while a controller is failed
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

     
    # start defrag on one PDD ( one with only R10 drives )
    # this really begins the test
    # first find two PDDs to work with

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # use @pdd[0] as the one to start defrag on, use @pdds[1] as the one to fail
    # note, a hotspare was verified at the beginning.

    $ret = StartSingleDefrag($ctlr, $pdds[0]);
    if ( $ret != GOOD ) { return ERROR; }

    # fail a different drive

    $ret = FailPdisk( $coPtr, $pdds[1] );
    
    # check sos tables
    
    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
print ("\n");
        DelaySecs( 15 );
    }
    



    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

 

    logInfo("End of defrag test case 16.");

    return GOOD;

}

###############################################################################

=head2 DefragCase17 function


This test case was created for code development and test. Its purpose is 
just to debug some of the functions called.

Actual testing performed may vary without notice. This may not present 
a valid set of tests on the controller.


=cut

=over 1

=item Usage:

 my $rc = DefragCase15($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is the IP address of the Moxa controller
        $mmPtr is a pointer to a list of tha Moxa channel mappings

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: DefragCase17
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: A test case put together to vailtate functions in this module 
#
##############################################################################
sub DefragCase17
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr  ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $j;
    my $k;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $ret;
    my $index2;

    my @vdisks; 
    my $numVDDs; 
    my @pdds; 
    my $lc;  
    my $vid1; 
    my $newVd1; 
    my @snList;
    my $targ; 
    my $index;
 

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 17: debug of some of the modules in the test (OBSOLETE)------";
    $msg0 = "-------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

return GOOD;

# uses movetarget

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    @snList = @$snPtr;

    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     

    ###################################################################### 
    # start a bunch of defrags, kill them off. check SOS tables.
    # redicp some of the partially moved vdisks. Delete all the unused
    # vdisks and defrag.
    ###################################################################### 

    # select 3 random vdisks

    # use oldVds for the size as the newvds list may actually be the 
    # wrong size from earlier use

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);
    
    @oldVds = GetRandomVdisks( $ctlr, 3 );     # find three vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    if ( scalar(@oldVds) != 3 ) { return ERROR; }

    
    # create 3 replacement vdisks
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
    }


    # redicp the 3 vdisks, wait for complete
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    # find all unowned disks
    # delete them
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # defrag pdisks

    $ret = DefragAllBegin($ctlr);                  # parallel
    if ( $ret != GOOD ) { return ERROR; }



    # check sos tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }



    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # identify partially moved vdisks


    @oldVds = FindMovingVdisks( $ctlr, 3 );     # find up to three vdisks
    if ( scalar(@oldVds) < 1 ) { return ERROR; }      # want at least one
    if ( $oldVds[0] == INVALID ) { return ERROR; }


    # create some new vdisks
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
        #push ( @newVds, $newVd);
    }


    # redicp the partially moved vdisks to the new ones
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }


    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # check SOS tables
    
    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # wait for complete

    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    # we should now be ready to do something else


    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)
    $ret = MakeVdisks($ctlr, 14, NO_RAID_INIT );  # option 14 is 2 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
        return (ERROR);
    }
     
    # start defrag on one PDD ( one with only R10 drives )
    # this really begins the test
    # first find two PDDs to work with

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # use @pdd[0] as the one to start defrag on, use @pdds[1] as the one to fail
    # note, a hotspare was verified at the beginning.

    $ret = StartSingleDefrag($ctlr, $pdds[0]);
    if ( $ret != GOOD ) { return ERROR; }

    # fail a different drive

    $ret = FailPdisk( $coPtr, $pdds[1] );
    
    # check sos tables
    
    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }
    
    # call defrag part 2, 5 loops, do on master
    $ret = DefragPart2($coList[$master], 5, 0);
    
    # got the list, now find the first one for first controller

    $vid1 = FirstVdiskOnCtlr($coPtr, \@oldVds, 0, $snPtr);
    if ( $vid1 == INVALID ) { return ERROR; }


    # make a new vdisk
    
    $newVd1 =  CreateReplacementVdisk($ctlr, $vid1 );
    if ( $newVd1 < 0 ) { return ERROR; }

    # start redicp on each controller

    $ret = RediCpVdisks($ctlr, $vid1, $newVd1 );
    if ( $ret != GOOD ) { return ERROR; }


    # find owner of the busy, just moved disk

    ($index, $targ) = FindVdiskOwner($coPtr, $snPtr, $oldVds[0]);
    if ( $index == INVALID ) { return ERROR; }
    if ( $targ == INVALID ) { return ERROR; }



    # move the target to another controller
    
    $index2 = 0;
    if ( $index == 0 ) { $index2 = 1; }

    $ret = MoveTarget($ctlr, $snList[$index2], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }
 
    # fail the controller that owned the vdisk being used

    $ret = FailMyOwner($coPtr, $snPtr, $vid1 );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # unfail the controller

    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

 
 
 
 
 
   
    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # move the target back

    $ret = MoveTarget($ctlr, $snList[$index], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO




    # delete all unused disks
    $ret = DeleteUnusedVdisks( $ctlr , 0);
    if ( $ret != GOOD ) { return ERROR; }

    # defrag all pdisks

    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of defrag test case 17.");

    return GOOD;

}
###############################################################################

=head2 DefragCase15 function


This test case has no supporting code.

=cut

=over 1

=item Usage:

 my $rc = DefragCase15($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase18
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase18
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $ret;
    my %info;
    my $needed;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "----------------------------------- Test Case 18: debug stuff ------------------";
    $msg0 = "--------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    #
    # Clean up any unused vdisks
    #
    $ret = DeleteUnusedVdisks( $ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    #
    # Clean up pdisk labels
    #
    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }
    
    #
    # Get and display initial data for mirror validation
    #
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    #
    # Rel 3.1 adds resync, need to wait for it to complete
    #
    logInfo( "Making sure all mirror resync is complete at start of test.");
    $ret = MirrorResyncWait($coPtr, 4 * $MRWTimeout);
    if ($ret != GOOD)
    {
        logInfo("Failed Mirror Resync wait at start of test.");
        return ERROR;
    }

    #
    # collect initial mirror state data
    #
    MirrorInitialData( $coPtr, \%mirrorData);

    DispVdiskInfo($ctlr);


    # get measure of the current IO



    $ret = CheckAndWait4RediCp($ctlr, 75 );
    if ( $ret != GOOD ) { return ERROR; }


return GOOD;
    
    ######################################################################
    # delete all unuased vdisks, defrag (pack system) then create a bunch
    # of vdisks and randomly redicp the vdisks to move the IO all over
    # the place. Delete the unused vdisks, defrag. Testing IO between 
    # each step
    ###################################################################### 

    # find all unowned disks
    # delete them
    
    logInfo("      Preparing for test by deleting unused vdisks");
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }



#    # defrag all pdisks
#
#    $ret = DefragBegin($ctlr);
#    if ( $ret != GOOD ) { return ERROR; }
#
#    # wait for defrags to complete
#    $ret = DefragWait( $ctlr );
#    if ( $ret != GOOD ) { return ERROR; }



    if ( $ret != GOOD ) { return ERROR; }


    # create vdisks (number = 1/2 number of active vdisks)

    %info = $ctlr->virtualDiskCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    $needed = $info{COUNT} / 2;

    @oldVds = GetRandomVdisks( $ctlr, $needed );     # find some vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # got disks to copy, make the replacements
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
    }


    
    # copy half vdisks to new ones (random selection)
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }


    
    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of defrag test case 18.");


    
    return GOOD;

}

##############################################################################
#
#          Name: DefragCase19
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Debug test case for the following bug
#. 
#   The problem occurs when we delete a vdisk 
#   that is the destination of a redi-copy operation
#   and the source is owned by the slave controller. This does repeat. 
#   The script that generates
#   the error has been changed to avoid it. To reproduce, the script did 
#   the following.
#   1) identify two vdisks on the master and 1 on the slave
#   2) create duplicate vdisks of those in one
#   3) begin redi-copy from disks in 1) to disks in 2)
#   4) delete the destination vdisks (those in 2) before redi-copy completes. 
#
##############################################################################
sub DefragCase19
{
    trace();
    my (  $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr  ) = @_;



    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newV;
    my @newVds;
    my $ret;
    my %info;
    my $needed;
    my $slave;
    my $si;
    my $ctlrS;
    my $vid1;
    my $newVd1;
    my $newVd;
    my $vid2;
    my $newVd2;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 19: delete dest. disks for redi-cp (bug 6203) ------";
    $msg0 = "---------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }

    # find the master controller
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }
       
    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    $si = 0;
    if ( $master == 0 ) { $si = 1; }

    $ctlrS = $coList[$si];



    

    
    ###################################################################### 
    # Delete some vdisks, start defrag on both controllers, observe
    ######################################################################



    # find all unowned disks
    # delete them
    
    logInfo("      Preparing for test by deleting unused vdisks");
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }



#    # defrag all pdisks
#
#    $ret = DefragBegin($ctlr);
#    if ( $ret != GOOD ) { return ERROR; }
#
#    # wait for defrags to complete
#    $ret = DefragWait( $ctlr );
#    if ( $ret != GOOD ) { return ERROR; }



    if ( $ret != GOOD ) { return ERROR; }


    # create vdisks (number = 1/2 number of active vdisks)

    %info = $ctlr->virtualDiskCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    $needed = $info{COUNT} / 2;

    @oldVds = GetRandomVdisks( $ctlr, $needed );     # find some vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # got disks to copy, make the replacements
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
    }


    
    # copy half vdisks to new ones (random selection)
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    # find all unowned disks
    # delete them
    
    logInfo("     Deleting created vdisks (copy/swap destinations.)");
    $ret = DeleteVdiskList( $ctlr, \@newVds );
    if ( $ret != GOOD ) { return ERROR; }

    
    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 15.");


    
    return GOOD;

}
###############################################################################

=head2 DefragCase20 function

This test case begins a redi-copy operation while defrag is running. The
copy is allowed to complete and another defrag is done. The test has these
basic steps...

    Setup ( get initial server activity info )
    Find a vdisk, make a replacement and do a redi-copy
    Delete the copied disk
    Find a vdisk, make a replacement
    Begin defrag on the disks
    Start a redi-copy
    Wait for the defrag to complete
    Verify IO is still running
    Delete the copied vdisk
    Defrag the pdisks, wait for complete
    Verify IO is still running
    Check the SOS tables

=cut

=over 1

=item Usage:

 my $rc = DefragCase20( $coPtr, $retIn, $snPtr  );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: DefragCase20
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                With a defrag running, rediCP one of the first vdisks to a new one.
#                then delete the old one and start another defrag. 
#        
#                Steps are 
#                   1) pick an active vdisk
#                   2) get its size
#                   3) create a new one
#                   3) get baseline IO activity info
#                   4) start the redi CP
#                   5) wait for redicp to complete
#                   5) confirm IO still going
#                   6) defrag again
#                   7) confirm IO still Ok
##############################################################################
sub DefragCase20
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 20: start defrag while doing a rebuild  -----------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    #
    # Do initial defrag to ensure no fragments initially
    #
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    DispVdiskInfo($ctlr);



    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
    ######################################################################
    # With a defrag running, rediCP one of the first vdisks to a new one.
    # then delete the old one and start another defrag. 
    ######################################################################

    # setup - need to get a defrag running

    # find 2 early vdisks
    @oldVds = FindEarlyVdisk( $ctlr, 2 );     # find two vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    if ( scalar(  @oldVds ) < 2 ) 
    { 
        logInfo(" Not enough early vdisks found.");
        return ERROR; 
    }

    # copy first one to the end
    $newVds[0] =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVds[0] < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVds[0]);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = WaitForCpComplete( $ctlr, $newVds[0] );
    if ( $ret != GOOD ) { return ERROR; }

    # create a new vdisk for 2nd one 
    $newVds[1] =  CreateReplacementVdisk($ctlr, $oldVds[1] );
    if ( $newVds[1] < 0 ) { return ERROR; }

    # delete the source ( the early vdisk )
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVds[0]) ) 
    {
        return ERROR;
    }

    # start the defrag ( for the 1st vdisk deleted )
    $ret = DefragAllBegin($ctlr);                    # parallel
    if ( $ret != GOOD ) { return ERROR; }

    # end of setup...

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }
    
    # redicp the next vdisk - wait for completion, check status
    $ret = RediCpVdisks($ctlr, $oldVds[1], $newVds[1] );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = WaitForCpComplete( $ctlr, $newVds[1] );
    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }
    

    # wait for defrag to complete, check     
    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }


    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # defrag the 2nd disk - wait for completion, check status
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVds[1]) ) 
    {
        return ERROR;
    }

    # start the defrag ( for the 1st vdisk deleted )
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    
    #
    # Steps are 1) pick an active vdisk
    #           2) get its size
    #           3) create a new one
    #           3) get baseline IO activity info
    #           4) start the redi CP
    #           5) wait for redicp to complete
    #           5) confirm IO still going
    #           6) defrag again
    #           7) confirm IO still Ok
    ######################################################################

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 20.");


    return GOOD;

}

###############################################################################
###############################################################################

=head2 DefragCase21 function

This test case moves a target while a defrag is running. The 
following steps are done...

    Setup ( get initial server activity info )
    Find a vdisk, make a replacement and do a redi-copy
    Wait for the copy to complete
    Find the owning controller/target for this vdisk
    Delete the source vdisk
    Start the defrag operation
    Move the target to a different controller
    Verify IO is still running
    Check the SOS tables
    Move the target back to the original controller
    Verify IO is still running
    Check the SOS tables


=cut

=over 1

=item Usage:

 my $rc = DefragCase21( $coPtr, $retIn, $snPtr  );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase21
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase21
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    
    my @oldVds;
    my $newVd;
    my $ctlr;
    my @coList;
    my $master;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $msg;
    my $msg0;
    my @snList;
    my $index;
    my $targ;
    my $index2;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 21: defrag while in a rebuild (OBSOLETE) ------";
    $msg0 = "------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);



return GOOD;

# this test calls moveTarget which does not work.

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return ERROR; }
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    @snList = @$snPtr;

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     

    ######################################################################
    # With defrag running, move an active target, see what happens, 
    # move it back.
    ######################################################################

    # housecleaning

    logInfo("Removing all unused vdisks");

    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    # defrag all pdisks

    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    # Find an early vdisk

    logInfo("Creating initial conditions for the test");

    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }


    # make new vdisk
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }


    # start redicp, wait for completion

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }

    # find owner of the busy, just moved disk

    ($index, $targ) = FindVdiskOwner($coPtr, $snPtr, $oldVds[0]);
    if ( $index == INVALID ) { return ERROR; }
    if ( $targ == INVALID ) { return ERROR; }

    # delete the copied vdisk
    logInfo("Deleting $newVd");

    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) ) 
    {
        return ERROR;
    }

    # start defrag                                           # 
    $ret = DefragAllBegin( $ctlr );                             # parallel
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }



    # move the target to another controller
    
    $index2 = 0;
    if ( $index == 0 ) { $index2 = 1; }

    $ret = MoveTarget($ctlr, $snList[$index2], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }
   
    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # move the target back

    $ret = MoveTarget($ctlr, $snList[$index], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    # probably need a delay here.
    DelaySecs(20);

    $ret = RescanBE( $ctlr);
    if ( $ret == ERROR )
    {
        return ERROR;
    }

    DelaySecs(20);

    # verify IO
    
    logInfo("There should be some rebuilds running now, look for degraded disks.");

    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }
    
    

#    # wait for all pdisks and raids to be operational and nothing happening
#    logInfo("Waiting for any rebuilds caused by the taget move to finish.");
#    $ret = WaitRebuild( $ctlr );    
#    if ( $ret != GOOD ) { return ERROR; }

    logInfo("Initial conditions created, we now have drives rebuilding, wait two minutes then begin 2nd part of test");
    DelaySecs(120);

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # copy it to the end
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }


    # delete the source ( the early vdisk )
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) ) 
    {
        return ERROR;
    }

    logInfo("Now we have a hole to defrag");

    # find the next early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find three vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }


    # create a vdisk to copy it to 
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }

      
    # start the defrag ( for the 1st vdisk deleted )
    $ret = DefragAllBegin($ctlr);                               # parallel
    if ( $ret != GOOD ) { return ERROR; }

    # now let all this finish and clean up


    # wait for all pdisks and raids to be operational and nothing happening
    logInfo("Waiting for any rebuilds caused by the target move to finish.");
    $ret = WaitRebuild( $ctlr );    
    if ( $ret != GOOD ) { return ERROR; }

    # check defrag state, and restart the defrags
    logInfo("Expect some drives to be fragmented as defrag was not completed. Restarting defrags.");

    # delete the source ( the early vdisk )
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) ) 
    {
        return ERROR;
    }

    # start the defrag ( for the 1st vdisk deleted )
    $ret = DefragAllBegin($ctlr);                          # parallel
    if ( $ret != GOOD ) { return ERROR; }

    # now let all this finish and clean up


    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    # wait for defrag to complete

    DelaySecs(20);


    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 21.");

    return GOOD;

}
###############################################################################

=head2 DefragCase22 function

This test case starts a redi copy operation while defrag is running. The 
following steps are done...

    Setup ( get initial server activity info )
    Identify three vdisks, make replacements and redi copy them
    Wait for redi copy operations to complete
    Verify IO is still running
    Delete all the source ( unused) vdisks
    Begin defrag on the pdisks
    Check SOS tables
    Verify IO is still running
    Find up to three vdisks that are moving
    Begin redi copy on the three
    Wait for redi copy to complete
    Wait for raid inits to complete
    Verify IO is still running
    Check SOS tables
    Delete all the source ( unused) vdisks
    Begin defrag on the pdisks
    Wait for defrag to complete
    Verify IO is still running
    Check SOS tables



=cut

=over 1

=item Usage:

 my $rc = DefragCase22($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase22
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase22
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $j;
    my $k;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $ret;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;




    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 22: launch a redi-copy operation while defragging some vdisks ------";
    $msg0 = "-------------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    #
    # Do initial defrag to ensure no fragments initially
    #
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Restore any connections that may have timed out
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) { return ERROR; }


    DispVdiskInfo($ctlr);


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     

    ###################################################################### 
    # start a bunch of defrags. check SOS tables.
    # redicp some of the partially moved vdisks. Delete all the unused
    # vdisks and defrag.
    ###################################################################### 

    # select 3 random vdisks

    @oldVds = GetRandomVdisks( $ctlr, 3 );     # find three vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    if ( scalar(@oldVds) != 3 ) { return ERROR; }

    
    # create 3 replacement vdisks
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] =  $newVd;
        push ( @newVds, $newVd);
    }


    # redicp the 3 vdisks, wait for complete
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    # find all unowned disks
    # delete them
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }



    # after a while, stop the defrags
      # this is not an option, at least not directly, so just go on

    # check sos tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }



    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # identify partially moved vdisks


    # "defrag all" made it difficult to find moving vdisks, so we
    # will take early vdisks instead and assume they will be moving as
    # we have been deleting vdisks. We skip the first 2 and take the
    # next 3 for this test 

    my $skippedVds = 2;

    @oldVds = FindEarlyVdisk( $ctlr, 5 );     # find three vdisks
    # @oldVds = FindMovingVdisks( $ctlr, 3 );     # find up to three vdisks
    if ( scalar(@oldVds) < 1 ) { return ERROR; }      # want at least one
    if ( $oldVds[0] == INVALID ) { return ERROR; }


    # create some new vdisks
    for ( $i = $skippedVds; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
        #push ( @newVds, $newVd);
    }

    # defrag pdisks

    $ret = DefragAllBegin($ctlr);                           # parallel
    if ( $ret != GOOD ) { return ERROR; }


    # redicp the partially moved vdisks to the new ones
    for ( $i = $skippedVds; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = $skippedVds; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }


    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # check SOS tables
    
    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }


    $ret = WaitRebuild($ctlr );


    $ret = DefragWait( $ctlr );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed waiting for defrag to end. <<<<<<<<");
        return (ERROR);
    }
    

    # delete all unused disks
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # defrag all pdisks

    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 22.");

    return GOOD;

}
###############################################################################

=head2 DefragCase23 function

This test case deletes any currently unused vdisks and then defrags. This 
essentially packs the IO. Then a buch of new vdisks are created and the IO
moved to them. The original disks are deleted and then the system is defraged.
The following steps are done...

    Setup ( get initial server activity info )
    Delete all unassociated vdisks
    Verify IO is still running
    Defrag all pdisks, wait for completion .... system is now 'packed'
    Create a bunch of vdisk clones( 1/2 number of existing vdisks, 
          randomly chosen)
    Run redi copy on all old/clone pairs
    Wait for redi copy operations to complete
    Verify IO is still running
    Delete all the source ( unused) vdisks
    Begin defrag on the pdisks
    Verify IO is still running
    Wait for defrags to complete
    Verify IO is still running
    Check SOS tables


=cut

=over 1

=item Usage:

 my $rc = DefragCase23($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase23
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR      
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase23
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $ret;
    my %info;
    my $needed;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    my $loops = 25;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 23: while IO runs, defrag disks before and after redicopy ------";
    $msg0 = "--------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 23: Begin" );

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
    ######################################################################
    # delete all unuased vdisks, defrag (pack system) then create a bunch
    # of vdisks and randomly redicp the vdisks to move the IO all over
    # the place. Delete the unused vdisks, defrag. Testing IO between 
    # each step
    ###################################################################### 

    # find all unowned disks
    # delete them
    
    logInfo("      Preparing for test by deleting unused vdisks");
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # defrag all pdisks
    CtlrLogTextAll($coPtr, "Test Case 23: Defrag to pack system at start" );

    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }


    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    while ( $loops-- > 0 )
    {

        # create vdisks (number = 1/2 number of active vdisks)
        CtlrLogTextAll($coPtr, "Test Case 23: RediCopy Loop head" );

        CtlrLogTextAll($coPtr, "Deleting unused vdisks, $loops loops to go.");
        $ret = DeleteUnusedVdisks( $ctlr, 0 );
        if ( $ret != GOOD ) { return ERROR; }
        DelaySecs(5);

        %info = $ctlr->virtualDiskCount();
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskCount <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskCount <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        $needed = $info{COUNT} / 2;

        @oldVds = GetRandomVdisks( $ctlr, $needed );     # find some vdisks
        if ( $oldVds[0] == INVALID ) { return ERROR; }

        # got disks to copy, make the replacements
        for ( $i = 0; $i < scalar( @oldVds); $i++ )
        {
            $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
            if ( $newVd < 0 ) { return ERROR; }
            $newVds[$i] = $newVd;
        }


        DispVdisksRaids($ctlr);         # 'vdisks' and 'raids'
        
        $ret = DispSOSTables( $ctlr );  # sos 'n'
        if ( $ret != GOOD ) { return ERROR; }
    

        
        DelaySecs(60);
        
        CtlrLogTextAll($coPtr, "Test Case 23: Begin RediCopies" );


        # copy half vdisks to new ones (random selection)
        for ( $i = 0; $i < scalar( @oldVds); $i++ )
        {
            $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
            if ( $ret != GOOD ) { return ERROR; }
        }

        for ( $i = 0; $i < scalar( @oldVds); $i++ )
        {

            $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
            if ( $ret != GOOD ) { return ERROR; }
        }

        CtlrLogTextAll($coPtr, "Test Case 23: RediCopies done" );

        # put the delay here so that any miscompare created can be detected
        # on the server and cause IO to stop.
        DelaySecs(120);

        CtlrLogTextAll($coPtr, "Test Case 23: Verifying IO" );

        # verify IO
        $ret = VerifyIO( $coPtr,
                         \@activeServers, 
                         \@tMap, 
                         \@initialVdisks,
                         $snPtr
                       );

        if ( $ret != GOOD ) { return ERROR; }




    }

    # delete unused vdisks
    logInfo("      Deleting the vdisks that were sources for the copies");
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    
    DelaySecs(120);

    # defrag pdisks
    CtlrLogTextAll($coPtr, "Test Case 23: Defrag to pack system after RediCopies" );
    $ret = DefragAll($ctlr);                           # parallel
    if ( $ret != GOOD ) { return ERROR; }

  #  # verify IO    
  #  $ret = VerifyIO( $coPtr,
  #                   \@activeServers, 
  #                   \@tMap, 
  #                   \@initialVdisks,
  #                   $snPtr
  #                 );
  #
  #  if ( $ret != GOOD ) { return ERROR; }
  #
  #  # wait for defrags to complete
  #  $ret = DefragWait( $ctlr );
  #  if ( $ret != GOOD ) { return ERROR; }
    
    # verify IO    
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    CtlrLogTextAll($coPtr, "Test Case 23: End" );

    logInfo("End of defrag test case 23.");


    
    return GOOD;

}

##############################################################################
###############################################################################

=head2 DefragCase24 function

This test case deletes any currently unused vdisks and then defrags. This 
essentially packs the IO. Then a buch of new vdisks are created and the IO
moved to them. The original disks are deleted and then the system is defraged.
The following steps are done...

    Setup ( get initial server activity info )
    Delete all unassociated vdisks
    Verify IO is still running
    Defrag all pdisks, wait for completion .... system is now 'packed'
    Create a bunch of vdisk clones( 1/2 number of existing vdisks, 
          randomly chosen)
    Run redi copy on all old/clone pairs
    Wait for redi copy operations to complete
    Verify IO is still running
    Delete all the source ( unused) vdisks
    Begin defrag on the pdisks
    Verify IO is still running
    Wait for defrags to complete
    Verify IO is still running
    Check SOS tables


=cut

=over 1

=item Usage:

 my $rc = DefragCase24($coPtr, $retIn, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


##############################################################################
#
#          Name: DefragCase24
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR      
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DefragCase24
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $i;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $ret;
    my %info;
    my $needed;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    my $loops = 4;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ Test Case 24: while IO runs, defrag disks before and after redicopy ------";
    $msg0 = "--------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 24: Begin" );

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     
    
    ######################################################################
    # delete all unuased vdisks, defrag (pack system) then create a bunch
    # of vdisks and randomly redicp the vdisks to move the IO all over
    # the place. Delete the unused vdisks, defrag. Testing IO between 
    # each step
    ###################################################################### 

    # find all unowned disks
    # delete them
    
    logInfo("      Preparing for test by deleting unused vdisks");
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }


    # defrag all pdisks
    CtlrLogTextAll($coPtr, "Test Case 24: Defrag to pack system at start" );

    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

   # # wait for defrags to complete
   # $ret = DefragWait( $ctlr );
   # if ( $ret != GOOD ) { return ERROR; }


    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }



    %info = $ctlr->virtualDiskCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    $needed = $info{COUNT} - 2;

    @oldVds = GetRandomVdisks( $ctlr, $needed );     # find some vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # got disks to copy, make the replacements
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
    }

    while ( $loops-- > 0 )
    {

        # create vdisks (number = 1/2 number of active vdisks)
        CtlrLogTextAll($coPtr, "Test Case 24: RediCopy Loop head" );

        CtlrLogTextAll($coPtr, " $loops loops to go.");
        DelaySecs(5);



        DispVdisksRaids($ctlr);         # 'vdisks' and 'raids'
            
        $ret = DispSOSTables( $ctlr );  # sos 'n'
        if ( $ret != GOOD ) { return ERROR; }
        

            
        DelaySecs(60);
        
        CtlrLogTextAll($coPtr, "Test Case 24: Begin RediCopies" );


        # copy half vdisks to new ones (random selection)
        for ( $i = 0; $i < scalar( @oldVds); $i++ )
        {
            $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
            if ( $ret != GOOD ) { return ERROR; }
        }
        
        ServerPropSpin( $ctlr, 8 );

        for ( $i = 0; $i < scalar( @oldVds); $i++ )
        {

            $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
            if ( $ret != GOOD ) { return ERROR; }
        }

        DelaySecs(120);

        CtlrLogTextAll($coPtr, "Test Case 24: RediCopies done, verifying IO" );

        # verify IO
        $ret = VerifyIO( $coPtr,
                         \@activeServers, 
                         \@tMap, 
                         \@initialVdisks,
                         $snPtr
                       );

        if ( $ret != GOOD ) { return ERROR; }




    }

    # delete unused vdisks
    logInfo("      Deleting the vdisks that were sources for the copies");
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    
    DelaySecs(120);

    # defrag pdisks
    CtlrLogTextAll($coPtr, "Test Case 24: Defrag to pack system after RediCopies" );
    $ret = DefragAll($ctlr);                         # parallel
    if ( $ret != GOOD ) { return ERROR; }
    
    # verify IO    
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    CtlrLogTextAll($coPtr, "Test Case 24: End" );

    logInfo("End of defrag test case 24.");


    
    return GOOD;

}

##############################################################################

###############################################################################

=head2 DefragCase50 function

This test case creates a gap before the first user data segment of a pdisk, 
starts a defrag of that pdisk, delays random time from 0-10 sec, then powers 
off one of the controllers.  
The test will only execute if there are 2 or more controllers and 1 or more 
pdisks with server activity. 

The test has these basic steps...

      1) Select a pdisk with the most segments that have server activity
      2) Create a gap before the first segment on the pdisk
      3) Start a defrag on that pdisk
      4) Delay random 0-10 secs  
      5) Power off a random controller
      6) Failover timeline
      7) Verify IO
      8) Power on controller
      9) Reconnect to and unfail controller
     10) Verify IO
     11) Defrag pdisk
     12) Verify IO
     13) Repeat loopCount times
      
=cut

=over 1

=item Usage:

 my $rc = DefragCase50( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount );
                          
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is a pointer to a list of moxa IP addresses
        $mmPtr is a pointer to the mapping of the moxa channels 
        $loopCount is the number of times to perform the internal test loop
        
=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 There must be 2 or more controllers.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: DefragCase50
#
#        Inputs: $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount
#                
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: This test case starts a defrag on a single pdisk, delays 0-10
#                secs, and then powers off a controller.
#
# Steps are 1) Select a pdisk with the most segments that have server activity
#           2) Create a gap before the first segment on the pdisk
#           3) Start a defrag on that pdisk
#           4) Delay random 0-10 secs  
#           5) Power off a random controller
#           6) Failover timeline
#           7) Verify IO
#           8) Power on controller
#           9) Reconnect to and unfail controller
#          10) Verify IO
#          11) Defrag pdisk
#          12) Verify IO
#          13) Repeat loopCount times
#
##############################################################################
sub DefragCase50
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList = @$coPtr;
    my @snList = @$snPtr;
    my $numCtlrs = scalar(@coList);
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlr2Index;
    my $ctlr2;
    my $victimIndex;
    my $victim;
    my $delay;
    my $foundOne;
    my @driveList;
    my $ret;
    my $i;
    my @deadList;
    my @pdiskInfo;
    my %info;
    my $numActivePdisks;
    my @activePdisks;
    my $activePdisksPtr = \@activePdisks;
    my @vdisks;
    my $vdisksPtr = \@vdisks;
    my $targetVdisk;
    my $newVdisk;
    my $loop;
    my $r5EnabledFlag;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    
    
    #
    # If $retIn is not GOOD, we're outa here.
    #
    if ( $retIn != GOOD ) 
    {
        return $retIn;
    }

    $msg = "------ Test Case 50: Power off a controller during defrag of a single pdisk ----------";
    $msg0 = "--------------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    #
    # Make sure we have enough controllers to do this test.
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers.  Test case is skipped.");
        return ($retIn);
    }

    #
    # Find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Defrag clean Up - Stop any defrags that may already be going on.
    #
    $ret = StartSingleDefrag($ctlr, "STOP");
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Wait for 30 seconds to allow all defrags to be stopped
    #
    DelaySecs(30);

    #
    # Get measure of the current IO
    #

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
     

    # logInfo("PID\tSEGMENTS\tACTIVESEGMENTS\tPERCENTACTIVE");
    # foreach $entry (@activePdisks) 
    # {
    #     logInfo("$entry->{PID}\t$entry->{SEGMENTS}\t$entry->{ACTIVESEGMENTS}\t$entry->{PERCENTACTIVE}");
    # }
    
    #   
    # Get list of active pdisks   
    #   
    $ret = GetActiveDataDisks($ctlr, \@initialVdisks, PD_DT_ALL, 4, 4, $activePdisksPtr);   
    if ( $ret == ERROR )   
    {   
        logInfo(">>>>>>>> Error from GetActiveDataDisks <<<<<<<<");   
        return ERROR;   
    }   
    #   
    # If we get INVALID, there are no pdisks that we can use, skip test.   
    #   
    if ( $ret == INVALID )   
    {   
        logInfo("No suitable active data disks available.  Test case skipped.");   
        return GOOD;   
    }   
    $numActivePdisks = scalar(@activePdisks); 

    #
    # Handle RAID-5 defrag.
    # If RAID-5 defrag is enabled, take the first PID, as it will have the most 
    # segments active.  
    # If RAID-5 defrag is not enabled, look for the first PID that does not have 
    # any RAID-5 segments.  If we can't find any, skip this test. 
    
    if ( $ctlr->{CONTROLLER_TYPE} == CTRL_TYPE_BIGFOOT )
    {
        $r5EnabledFlag = RAID5_DEFRAG_ENABLED_BIGFOOT;
    }
    else
    {
        $r5EnabledFlag = RAID5_DEFRAG_ENABLED_WOOKIEE;
    } 
       
    #
    if ( $r5EnabledFlag )
    {
        $victimIndex = 0;
        $victim = $activePdisks[0]{PID};         
    }
    else
    {
        $foundOne = 0;
        for ( $i = 0; $i < $numActivePdisks; $i++ )
        {
            $ret = PdiskGotRaid($ctlr, $activePdisks[$i]{PID}, RAID_5);
            if ( $ret == INVALID )
            {
                logInfo(">>>>>>>> PdiskGotRaid failed for PID $activePdisks[$i]{PID} <<<<<<<<");
                return ERROR;
            }
            if ( $ret == FALSE )
            {
                $foundOne = 1;
                $victimIndex = $i;
                $victim = $activePdisks[$i]{PID};
                last;
            }
        }
        if ( $foundOne == 0 )
        {
            logInfo("RAID-5 defrag is not enabled.  All active pdisks have one or more Raid 5 segments."); 
            logInfo("This test case requires at least one active pdisk without any Raid 5 segments.");
            logInfo("Test case is skipped.");
            return GOOD;
        }    
    }

    #
    # Just for info, log details on victim.
    #
    logInfo("Victim PID:  $victim     User Segments:  $activePdisks[$victimIndex]{SEGMENTS}".
            "     Active User Segments:  $activePdisks[$victimIndex]{ACTIVESEGMENTS}");    

    #
    # If we got here, we have a good pdisk that we can use to defrag, so we can
    # proceed with the test.  Do an initial defrag of the selected pdisk so we 
    # start with a clean slate. 
    #
    $ret = StartSingleDefrag($ctlr, $victim);
    if ( $ret != GOOD ) 
    {
        logInfo(">>>>>>>> Start of initial defrag of PID $victim failed <<<<<<<<");
        return ERROR; 
    }

    $driveList[0] = $victim;
    $ret = DefragWait( $ctlr, \@driveList );
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>>>>>> Initial defrag of PID $victim failed <<<<<<<<");
        return ERROR;
    }

    #
    # Make sure we are still connected
    #
    $ret = TestNReconnectAll($coPtr);
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>>>>>> Failed to reconnect to controllers after initial defrag <<<<<<<<");
        return ERROR;
    }

    # 
    # Loop thru the main part of the test loopCount times
    #
    for ( $loop = 0; $loop < $loopCount; $loop++ )
    {
        logInfo("Loop #:  $loop");
        #
        # Log current Raids and SOS info.
        #
        %info = $ctlr->raids();
        if ( ! %info  )             
        {
            logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )    
        {
            logInfo(">>>>>>>> Error from raids command <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
        logRaids( %info ); 
       
        %info = $ctlr->getSos($victim);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from getSos($victim) <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Could not retrieve SOS table ($victim) <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
        logSos( %info );
            
        #
        # Create a gap on the pdisk
        #
    
        #
        # Find the VID corresponding to the first user segment on the pdisk
        #
        $ret = GetVdisksOnPdisk($ctlr, $victim, $vdisksPtr);
        if ( $ret != GOOD )          
        {
            logInfo(">>>>>>>> Error from GetVdisksOnPdisk <<<<<<<<");
            return ERROR;
        }
         
        #
        # Use the first segment vdisk
        #
        $targetVdisk = $vdisks[0];                                                                            
            
        #
        # Create a replacement vdisk
        #
        $newVdisk =  CreateReplacementVdisk( $ctlr, $targetVdisk );
        if ( $newVdisk < 0 ) 
        { 
            logInfo(">>>>>>>> Error from CreateReplacementVdisk <<<<<<<<");
            return ERROR; 
        }

        #
        # Start a copy-swap  
        #
        $ret = RediCpVdisks($ctlr, $targetVdisk, $newVdisk );
        if ( $ret != GOOD ) 
        { 
            logInfo(">>>>>>>> Error from RediCpVdisks <<<<<<<<");
            return ERROR; 
        }

        #
        # Wait for it to complete
        #
        logInfo("      Waiting for redi-copy to complete");
        $ret = WaitForCpComplete( $ctlr, $newVdisk );
        if ( $ret != GOOD ) 
        { 
            logInfo(">>>>>>>> Error from WaitForCpComplete <<<<<<<<");
            return ERROR; 
        }
       
        # 
        # Delete the source vdisk
        #
        $ret = DeleteSingleVdisk( $ctlr, $newVdisk ); 
        if ( $ret != GOOD ) 
        { 
            logInfo(">>>>>>>> Error from DeleteSingleVdisk <<<<<<<<");
            return ERROR; 
        }

        #
        # Log current Raids and SOS info.
        #
        %info = $ctlr->raids();
        if ( ! %info  )             
        {
            logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )    
        {
            logInfo(">>>>>>>> Error from raids command <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
        logRaids( %info ); 
       
        %info = $ctlr->getSos($victim);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from getSos($victim) <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Could not retrieve SOS table ($victim) <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
        logSos( %info );

        #
        # Verify IO before test
        #
        logInfo("Verify IO before test");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         \@tMap, 
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }
    
        #
        # Select a controller to power off (can be same or different than master)  
        #
        $ctlr2Index = int( rand($numCtlrs) );
        $ctlr2 = $coList[$ctlr2Index];
     
        #
        # Select random delay between start of defrag and power off 
        #
        $delay = int( rand(11) );

        # 
        # Log info to controllers
        #
        CtlrLogTextAll($coPtr, "Test Case 50: Start defrag on PID $victim, delay $delay secs, turn off $ctlr2->{HOST}" );
    
        #
        # Start the defrag
        #
        $ret = StartSingleDefrag($ctlr, $victim);
        if ( $ret != GOOD ) 
        {
            logInfo(">>>>>>>> Start of defrag of PID $victim failed <<<<<<<<");
            return ERROR; 
        }

        sleep( $delay );
    
        #
        # Power off the controller 
        #
        $ret = PowerChange( $$moxaIP[$ctlr2Index], $$mmPtr[$ctlr2Index], 0 );
        if ( $ret != GOOD ) 
        {
            logInfo(">>>>>>>> PowerChange failed turning controller off <<<<<<<<");
            return ERROR; 
        }

        #
        # Failover timeline
        #
        @deadList = ($ctlr2Index);
        FailOverTimeLineNway( $coPtr, 120, $snPtr, \@deadList);

        #
        # Find the new master
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) { return(ERROR); }
        $ctlr = $coList[$master];

        #
        # Log current SOS info
        #
        %info = $ctlr->getSos($victim);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from getSos($victim) <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Could not retrieve SOS table ($victim) <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
        logSos( %info );

        #
        # Verify IO
        #
        logInfo("Verify IO after failing the controller");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         0,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Power controller back on 
        #
        CtlrLogText($$coPtr[$master], "Test Case 50: now turning on $ctlr2->{HOST}" );
        $ret = PowerChange($$moxaIP[$ctlr2Index], $$mmPtr[$ctlr2Index], 1);
        if ( $ret != GOOD ) 
        {
            logInfo(">>>>>>>> PowerChange failed turning controller on <<<<<<<<");
            return ERROR; 
        }

        #
        # Wait 60 seconds and then reconnect to controller
        #
        logInfo("Pause for 60 seconds and reconnect to controller $ctlr2->{HOST} ");
        $ret = Reconnect( $ctlr2, 60 );
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> Failed to reconnect to the controller    <<<<<<<<");
            return ERROR;
        }

        #
        # Wait until controller completes power up
        #
        $ret = Wait4MinPowerUpState($ctlr2, POWER_UP_FAILED, 120);          
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Unfail controller
        #
        $ret = UnFailController( $ctlr, $snList[$ctlr2Index] );
        if ( $ret != GOOD ) 
        {
            logInfo(">>>>>>>> UnFailController failed <<<<<<<<");
            return ERROR; 
        }

        @deadList = (INVALID);
        FailOverTimeLineNway( $coPtr, 120, $snPtr, \@deadList);

        #
        # Verify IO after unfailing controller
        #
        logInfo("Verify IO after restoring the controller");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Find the master controller
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) { return(ERROR); }
        $ctlr = $coList[$master];
    
        #
        # Log current SOS info
        #
        %info = $ctlr->getSos($victim);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from getSos($victim) <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Could not retrieve SOS table ($victim) <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
        logSos( %info );

        #
        # Powering off a controller should stop the defrag.  Do a defrag to clean up. 
        #
        $ret = StartSingleDefrag($ctlr, $victim);
        if ( $ret != GOOD ) 
        {
            logInfo(">>>>>>>> Start of clean up defrag of PID $victim failed <<<<<<<<");
            return ERROR; 
        }

        $driveList[0] = $victim;
        $ret = DefragWait( $ctlr, \@driveList );
        if ( $ret != GOOD ) 
        { 
            logInfo(">>>>>>>> Clean up defrag of PID $victim failed <<<<<<<<");
            return ERROR;
        }
 
        #
        # Make sure we are still connected
        #
        $ret = TestNReconnectAll($coPtr);
        if ( $ret != GOOD ) 
        { 
            logInfo(">>>>>>>> Failed to reconnect to controllers <<<<<<<<");
            return ERROR;
        }
     
        #
        # Verify IO at end 
        #
        logInfo("Verify IO at end of test");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }
    }   # end of for loop 

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of defrag test case 50.");

    return GOOD;

}


###############################################################################







###############################################################################

###############################################################################


###############################################################################

=head2 DebugEntry function

A function used for debugging the code as a generic entry. The final 
parameter represents the test case to be run. A test case of 99 will
run most tests. There is no guarantee that the tests can actually 
run sequentially and give full coverage.



=cut

=over 1

=item Usage:

 my $rc = DebugEntry($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $case );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is the IP address of the Moxa controller
        $mmPtr is a pointer to a list of tha Moxa channel mappings
        $case is the test case to run

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the 
           expected state is found.



=back

=cut


##############################################################################
#
#          Name: DebugEntry
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub DebugEntry
{
    trace();
    my ( $coPtr,  $snPtr, $moxaIP, $mmPtr, $wwnPtr, $ipPtr, $case ) = @_;

    my $loopCount;
    my $ret;
    $ret = GOOD;

    my @coList = @$coPtr;

    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "                starting Defrag Case $case. ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");

    #####################################################
    #
    # The following test cases use defrag all
    #
    #####################################################

    if ( $case==1   || $case == 99 ) { $ret = DefragCase1(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==2   || $case == 99 ) { $ret = DefragCase2(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==4   || $case == 99 ) { $ret = DefragCase4( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==5   || $case == 99 ) { $ret = DefragCase5(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==6   || $case == 99 ) { $ret = DefragCase6(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==7   || $case == 99 ) { $ret = DefragCase7(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==8   || $case == 99 ) { $ret = DefragCase8(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==9   || $case == 99 ) { $ret = DefragCase9(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==10                 ) { $ret = DefragCase10( $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==11  || $case == 99 ) { $ret = DefragCase11( $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==12  || $case == 99 ) { $ret = DefragCase12( $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==13  || $case == 99 ) { $ret = DefragCase13( $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

 #   if ( $case==17                 ) { $ret = DefragCase17( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); }
 #   if ( $ret != GOOD ) { return $ret; }

 #   if ( $case==16                 ) { $ret = DefragCase16( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); }
 #   if ( $ret != GOOD ) { return $ret; }

    if ( $case==15                 ) { $ret = DefragCase15( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==18                 ) { $ret = DefragCase18( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==19                 ) { $ret = DefragCase19( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==20  || $case == 99 ) { $ret = DefragCase20(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

  # if ( $case==21  || $case == 99 )  { $ret = DefragCase21(  $coPtr, GOOD, $snPtr  ); }
  #  if ( $ret != GOOD ) { return $ret; }

    if ( $case==22  || $case == 99 )  { $ret = DefragCase22(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==23 || $case == 99  )  { $ret = DefragCase23(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==24 || $case == 99  )  
    {
        $ret = DefragCase24(  $coPtr, GOOD, $snPtr  ); 
    }
    if ( $ret != GOOD ) { return $ret; }




    #####################################################
    #
    # The following test cases use single disk defrag
    #
    #####################################################
 

    $loopCount = 10;
    if ( $case==50 || $case == 99 ) { $ret = DefragCase50( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount ); }
    if ( $ret != GOOD ) { return $ret; }


    #####################################################
    #
    # Other cases
    #
    #####################################################
 


    if ( $case==3   ) { $ret = DefragCase3(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==4 || $case == 99   ) { $ret = DefragCase4(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr   ); }
    if ( $ret != GOOD ) { return $ret; }

    
    if ( $case == 115 ) 
    {
        while(1)
        {
            $ret = DefragCase15( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); 
        }
    }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 119 ) 
    {
        while(1)
        {
            $ret = DefragCase19( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); 
        }
    }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 116 ) 
    {
        while(1)
        {
            $ret = DefragCase15( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     );
            $ret = DefragCase19( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     );
             
        }
    }
    if ( $ret != GOOD ) { return $ret; }


#    if ( $case==14 ) { $ret = InitialDefragConfig( $coPtr, $ipPtr, $wwnPtr ); }
#    if ( $case==15 ) { $ret = InitialDefragConfig2( $coPtr, $ipPtr, $wwnPtr  ); }
#    if ( $case==1  ) { $ret = DefragCase14( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr  ); }
#    if ( $case==1  ) { $ret = DefragCase15( $coPtr, $ret, $snPtr  ); }

    PeriodicDataGather($coPtr);

    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "                    Defrag Case $case ends. ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
#    DelaySecs(300);
    
    return $ret;

}


##############################################################################
#
#          Name: Support Functions
#
#  These are probably not exported.
#
##############################################################################

###############################################################################


###############################################################################

=head2 DefragPart4 function

This function deletes every other unused vdisk in the system and then does a defrag
on all pdisks.   Always waits for the defrags to finish.

=cut

=over 1

=item Usage:

 my $rc = DefragPart4( $ctlr, $option );
 
 where: $ctlr is a controller object
        $option is IGNORED

=item Returns:

       $rc will be a GOOD or INVALID. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
.

=item Initial Conditions:

 The used (associated) vdisks must come before the first unused vdisk when
 the list of vdisks is fetched. The caller either assumes this is true or
 verifies it. If not, then we will attempt to delete any associated vdisk,
 which will fail. 

=back

=cut



##############################################################################
#
#          Name: DefragPart4
#
#        Inputs: controller object , option flag
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Deletes every other vdisk (starting w/ 1st unused) and
#                starts defrag on all pdds.
#
##############################################################################
sub DefragPart4
{
    trace();
    my ($ctlr, $option) = @_;


    my @vdisks;
    my $numVDDs;
    my %rsp;
    my $lun;
    my $sid;
    my $ret;
    my $unowned;
    my $i;
    my $firstNew;
    my $j;

    # delete every other unused vdisk
    # start defrag

    logInfo("Defrag test: Part 4, delete every other vdisk, defrag");

    #
    # figure out who has the first vdisk 
    #

    # get a list of vdisks (vdisklist)
    @vdisks = GetVdiskList( $ctlr );

    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }

    $numVDDs = scalar (@vdisks);  # of drives available

    logInfo("Found $numVDDs vdisks");

    # find the first un-owned drive
    $unowned = ERROR;
    $i = 0;
    while ( ($unowned == ERROR) && ( $i < $numVDDs) )
    {
        
        logInfo("Look to see if vdisk $vdisks[$i] is owned.");

        # get the owner
        %rsp = $ctlr->virtualDiskOwner($vdisks[$i]);
        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskOwner <<<<<<<<");
            return ERROR;
        }
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to retrieve virtualDiskOwner. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        if ( $rsp{NDEVS} == 0 )
        {
            $unowned = GOOD;
            $firstNew = $i;         # firstNew is the array index here
        }

        $i++;

    }

    if ( $unowned == ERROR )
    {
        logInfo(">>>>>>>> Failed to find an unowned vdisk <<<<<<<<");
        return ERROR;
    }

    # $firstNew points to the unowned vdisk

    #
    # now delete every other disk
    #

    while ( ( $firstNew < $numVDDs) )
    {

        logInfo("Deleting $vdisks[$firstNew]");

        if ( ERROR == DeleteSingleVdisk($ctlr, $vdisks[$firstNew]) ) 
        {
            return ERROR;
        }

        $firstNew = $firstNew + 2;      # point to next one to delete

    }

    #
    # now start the defrag
    #


    logInfo("Beginning defrag.");

    $ret = DefragAll($ctlr);                             # possible parallel
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to start defrag(s). <<<<<<<<");
        return (ERROR);
    }

 
    #
    # Wait for completion
    #

    # This will wait for all the defrags to complete. Either include
    # this call (to be nice to the controller, or skip it. If it
    # is skipped, you will test what happens when we use up all the 
    # memory.

  #  if ( ($option & DEFRAG_WAIT) )
  #  {
  #      $ret = DefragWait( $ctlr );
  #  }
  #

    return GOOD;

}

###############################################################################

=head2 DefragPart3 function

This function deletes the first vdisk on a system and then defrags all 
PDDs. Always waits for the defrags to finish.

=cut

=over 1

=item Usage:

 my $rc = DefragPart3( $ctlr, $option );
 
 where: $ctlr is a controller object
        $option is IGNORED

=item Returns:

       $rc will be a GOOD or INVALID. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.

=item Initial Conditions:

 The first vdisk found must not be associated to a server. 

=back

=cut


##############################################################################
#
#          Name: DefragPart3
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Deletes the first vdisk, starts defrag 
#
##############################################################################
sub DefragPart3
{
    trace();
    my ($ctlr, $option) = @_;


    my @vdisks;
    my $numVDDs;
    my %rsp;
    my $lun;
    my $sid;
    my $ret;
    my $unowned;
    my $i;
    my $firstNew;

    # delete first vdisk
    # start defrag

    logInfo("Defrag test: Part 3, delete first not-associated vdisk, defrag");

    #
    # figure out who has the first vdisk 
    #

    # get a list of disks (vdisklist)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available



    # find the first un-owned drive
    $unowned = ERROR;
    $i = 0;
    while ( ($unowned == ERROR) && ( $i < $numVDDs) )
    {
        # get the owner
        %rsp = $ctlr->virtualDiskOwner($vdisks[$i]);
        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskOwner <<<<<<<<");
            return ERROR;
        }
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to retrieve virtualDiskOwner. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        if ( $rsp{NDEVS} == 0 )
        {
            $unowned = GOOD;
            $firstNew = $vdisks[$i];
        }

        $i++;

    }

    if ( $unowned == ERROR )
    {
        logInfo(">>>>>>>> Failed to find an unowned vdisk <<<<<<<<");
        return ERROR;
    }

    # $firstNew points to the first unowned vdisk

    #
    # now delete the first disk
    #

    logInfo("Deleting $firstNew");

    if ( ERROR == DeleteSingleVdisk($ctlr, $firstNew) ) 
    {
        return ERROR;
    }


    #
    # now start the defrag
    #



    $ret = DefragAll($ctlr);                      # possible parallel
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to start defrag(s). <<<<<<<<");
        return (ERROR);
    }
 
    #
    # Wait for completion
    #

    # This will wait for all the defrags to complete. Either include
    # this call (to be nice to the controller, or skip it. If it
    # is skipped, you will test what happens when we use up all the 
    # memory.

  #  if ( ($option & DEFRAG_WAIT) )
  #  {
  #      $ret = DefragWait( $ctlr );
  #  }





    return GOOD;
}

###############################################################################


###############################################################################

=head2 DefragDebug1 function

This function is for debugging the defrag tests. Currently it 
dumps the SOS tables for a PDD. It may change without notice. 

=cut

=over 1

=item Usage:

 my $rc = DefragDebug1( $ctlr, $pdd  );
 
 where: $ctlr is a controller object
        $pdd is the pdd to use


=item Returns:

       $rc will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.



=back

=cut


##############################################################################
#
#          Name: DefragDebug1
#
#        Inputs: controller object, pdd number
#
#       Outputs: prints sos table
#
#  Globals Used: none
#
#   Description: .
#
##############################################################################
sub DefragDebug1
{
    trace();
    my ($ctlr, $pdd) = @_;

    my %info;

 
    print "Retrieving SOS Table for disk $pdd.      \r";
    %info = $ctlr->getSos($pdd);
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from getSos <<<<<<<<");
        return ERROR;
    }
    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> ERROR: Could not retrieve SOS table ($pdd) <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logSos(%info);
    
    return GOOD;
    
    # return 
}

###############################################################################

=head2 DefragDebug2 function

This function is for debugging the defrag tests. Currently it is a loop 
that dumps the SOS tables for all PDDs. It may change without notice. 

=cut

=over 1

=item Usage:

 my $rc = DefragDebug2( $ctlr, $pdd  );
 
 where: $ctlr is a controller object
        $pdd is not used


=item Returns:

       $rc will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.



=back

=cut


##############################################################################
#
#          Name: DefragDebug2
#
#        Inputs: controller object
#
#       Outputs: prints sos table
#
#  Globals Used: none
#
#   Description: .
#
##############################################################################
sub DefragDebug2
{
    trace();
    my ($ctlr, $pdd) = @_;

    my %info;
    my @disks;
    my $i;
    
    @disks = GetDataDisks($ctlr, PD_DT_ALL);
    
    if ( $disks[0] == INVALID )
    {
        return ERROR;
    }

    for ( $i = 0; $i <scalar(@disks); $i++)
    {
        DefragDebug1($ctlr, $disks[$i])
    }
    
    return GOOD;
    
    # return 

}


###############################################################################


###############################################################################

=head2 DefragPart2 function

This test is a loop that creates two vdisks, initializes them, deletes 
the first one and then does a defrag. 

=cut

=over 1

=item Usage:

 my $rc = DefragPart2( $ctlr, $loops, $option  );
 
 where: $ctlr is a controller object
        $loops is the number of iterations to perform
        $option affects the raid inits and other parameters in the test

=item Returns:

       $rc will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.


=item Initial Conditions:

 This is a part of the defrag test and thus requires an initial configuration.
 Specifically, there should already be some vdisks present. These may of may
 not be associated to servers. Concurrent IO is optional.

=back

=cut


##############################################################################
#                                                                               
#          Name: DefragPart2
#
#        Inputs: controller object, loops
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Create/create/delete/defrag loop for defrag test.
#                This will add 'loops' vdisks to the configuration 
#
#                This will always wait for defrags to finish
#
##############################################################################
sub DefragPart2
{
    trace();
    my ($ctlr, $loops, $option) = @_;
    my @vdisks;
    my $i;
    my $ret;
    my $firstNew;
    my %rsp;
    my $numVDDs;


    logInfo("Defrag test: Part 2, create 2/delete 1/defrag vdisks");


    # for n loops
    for ( $i = 0; $i < $loops; $i ++ )
    {

        # first get a list of existing vdisks
        @vdisks = GetVdiskList( $ctlr );
        if ( $vdisks[0] == INVALID )
        {
            logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
            return ERROR;
        }
        $numVDDs = scalar (@vdisks);  # of drives available




        #
        # create 2 vdisks
        #

        #
        # The 3rd parameter in MakeVdisks, if 0 will do raid inits on ALL 
        # raids each time it is called, Even on drives that are already
        # done. Using 'NO_RAID_INIT' will skip the raid inits. This gives
        # two different test scenarios.
        #


        $ret = MakeVdisks($ctlr, 15, ($option ) );  # option 13 is 2 vdisks
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
            return (ERROR);
        }
     
#DefragDebug2($ctlr);             
     
        #
        # delete 1st of the 2 vdisks
        #
        $firstNew = FindFirstNew ( $ctlr, \@vdisks );
        if ( $firstNew == INVALID )
        {
            logInfo(">>>>>>>> Unable to determine first new vdisk. <<<<<<<<");
            return ERROR;
        }

        logInfo("Deleting $firstNew");

        if ( ERROR == DeleteSingleVdisk($ctlr, $firstNew) ) 
        {
            return ERROR;
        }



#DefragDebug2($ctlr);
        #
        # start defrag
        #

        DispPdiskInfo($ctlr);            # shows current state

        GPDeviceStatus($ctlr);           # for Jeff's debug

        $ret = DefragAll($ctlr);     
        
        if ( $ret == ERROR )
        {
            GPDeviceStatus($ctlr);        # also for debug
            logInfo(">>>>>>>> Failed to start defrags. <<<<<<<<");
            return (ERROR);
        }

        #
        # Wait for completion
        #

        # This will wait for all the defrags to complete. Either include
        # this call (to be nice to the controller, or skip it. If it
        # is skipped, you will test what happens when we use up all the 
        # memory.

   #     if ( ($option & DEFRAG_WAIT) )
   #     {
   #         $ret = DefragWait( $ctlr );
   #     }

    #print " enter a character ";
    #my $ans = <STDIN>;



    }

    return GOOD;
}

###############################################################################


###############################################################################

=head2 DefragPart1 function

This function creates the initial configuration for a one way defrag test.
It assumes we are starting from an unconfigured system. The drives are
labeled and three vdisks created. Two of the vdisks are associated with servers
so that IO may be run. At the end, confirguation information is displayed.

=cut

=over 1

=item Usage:

 my $rc = DefragPart1( $ctlr, $option, $wwnPtr  );
 
 where: $ctlr is a controller object
        $option controls some features within the test
        $wwnPtr is a pointer to a list of wwns used by the servers

=item Returns:

       $rc will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.

=item Initial Conditions:

 The system should be unconfigured, the controller should have a license.
 It is assumed that we are already logged into the controller.


=back

=cut


##############################################################################
#
#          Name: DefragPart1
#
#        Inputs: controller object, option, server wwn list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################
sub DefragPart1
{
    trace();
    my ($ctlr, $option, $wwnPtr) = @_;

    my $ret;
    my %rsp;
    my @vdisks;
    my $numVDDs;
    my $lun;
    my $sid;


    logInfo("Defrag test: Part 1, create initial vdisks");

    #
    # validate option
    #


    if ( ! $option )     # if not defined
    {
        $option = 1;
    }
    if ( ($option < 0) || ($option > 2) )  # out of range check
    {
        $option = 1;
    }

    #
    # we start from scratch,
    # label the drives
    #
    $ret = LabelAllDrives($ctlr, 11, 2, 1, 0, 0 );     # for 14 drive bays

    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to label the drives <<<<<<<<");
        return (ERROR);
    }


    #
    # create 3 vdisks
    #
    $ret = MakeVdisks($ctlr, 12, 0 );     # option 12 is 3 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 3 new vdisks <<<<<<<<");
        return (ERROR);
    }

    #
    # associate 2nd and 3rd to servers so IO can be done
    # We're going to assoca all and then disassociate the first one
    #
    $ret = AssociateServers($ctlr, 2, $wwnPtr );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to associate drives to servers <<<<<<<<");
        return (ERROR);
    }

    #
    # figure out who has the first vdisk 
    #

    # find the first vdisk (vdisklist)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available




    # get the owner
    %rsp = $ctlr->virtualDiskOwner($vdisks[0]);
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskOwner <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve virtualDiskOwner. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    if ( $rsp{NDEVS} > 0 )
    {
        $lun = $rsp{OWNERS}[0]{LUN};
        $sid = $rsp{OWNERS}[0]{SID};

        #
        # got the info, now disassoc it
        #
        $ret = DisassocOne( $ctlr, $sid, $lun, $vdisks[0]);
        if ( $ret == ERROR )
        {
            return ERROR;
        }
    }

    #####################
    # show what is there
    #####################

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }

    $ret = DispVdisksRaids($ctlr);
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to display vdisks and raids <<<<<<<<");
        return (ERROR);
    }



    # finish up

    return GOOD;


}


1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.4  2006/09/20 11:25:31  AnasuriG
# TBolt00000000 added call for defragcase4 in DebugEntry subroutine
#
# Revision 1.3  2006/08/01 11:12:41  AnasuriG
# TBolt00015075
# Added changes for PDISKFAIL
#
# Revision 1.2  2006/07/25 20:33:42  EidenN
# tbolt00000000
# Added a cleanup to stop any defrags that may already be running at the start of each case
#
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
# Revision 1.68  2005/01/12 20:16:03  MenningC
# tbolt0012094: Fix deleting vdisks in defrag 9; reviewed by Al
#
# Revision 1.67  2005/01/04 17:25:22  KohlmeyerA
# Tbolt00000000:  Fixed bug in Defrag 4 if master moves.  Reviewed by Craig.
#
# Revision 1.66  2004/12/21 17:46:21  MenningC
# TBOLT00000000:Fix timing in defrag 22. Reviewed by Al
#
# Revision 1.65  2004/12/06 17:26:26  MenningC
# tbolt00000000: Fix test case 50, reviewed by Al
#
# Revision 1.64  2004/11/22 20:27:27  MenningC
# TBOLT00000000:AUpdates to validation for mirrors, fix wait for inits to end. Reviewed by Dave
#
# Revision 1.63  2004/11/17 20:49:39  MenningC
# TBOLT00000000:Another fix to defrag 11. Reviewed by Al
#
# Revision 1.62  2004/11/16 16:09:15  MenningC
# TBOLT00000000:Logtext and defrag cleanup. Reviewed by Al
#
# Revision 1.61  2004/11/02 20:40:02  KohlmeyerA
# Tbolt00000000: Fixed bug in Defrag12.  Added a FixPdiskLabels after failing a pdisk.
# Reviewed by Craig.
#
# Revision 1.60  2004/10/28 20:12:14  MenningC
# Tbolt00000000: defrag 9-add reconnect to slave. reviewed by Al
#
# Revision 1.59  2004/10/01 20:58:47  KohlmeyerA
# Tbolt00000000: Fixed problem with sequence of finding replacement vdisks in test 20.
# Reviewed by Craig.
#
# Revision 1.58  2004/09/22 16:18:38  KohlmeyerA
# Tbolt00000000: Updated tests to create all replacement vdisks before deleting any old vdisks.
# Also added initial clean up to a number of the test.
# Reviewed by Craig.
#
# Revision 1.57  2004/09/02 21:27:14  KohlmeyerA
# Tbolt00000000:  Added TestNReconnect to a couple places that were timing out connect.
# eviewed by Craig
#
# Revision 1.56  2004/08/31 21:13:19  MenningC
# Tbolt00000000: Add raid 5 defrag enabled flag for wookiee; reviewed by Al
#
# Revision 1.55  2004/08/30 19:13:39  KohlmeyerA
# Tbolt00000000:  Removed the SKIPVALIDATIONFAILURE flag from a number of
# the CheckSosTables calls.  Reviewed by Craig
#
# Revision 1.54  2004/08/20 13:52:01  MenningC
# tbolt00000000:enable case 4 as part of 99; reviewed by Al
#
# Revision 1.53  2004/08/18 15:22:03  MenningC
# tbolt00000000:continued defrag updates; reviewed by Al
#
# Revision 1.52  2004/08/04 15:30:08  MenningC
# tbolt00000000: support for future defrag all, reviewed by Al
#
# Revision 1.51  2004/07/30 20:52:53  KohlmeyerA
# Tbolt00000000:  Added test case 50.  Reviewed by Craig.
#
# Revision 1.50  2004/06/23 17:03:50  KohlmeyerA
# Tbolt00000000:  Removed case 4 from case 99 as case 4 is expected to fail.
# Added logInfo to case 4.  Reviewed by Craig.
#
# Revision 1.49  2004/05/26 15:55:39  KohlmeyerA
# Tbolt00000000:  Added flag and modified DefragRemain and CheckSosTables
# to handle Raid 5 no longer being defragmented.  Also did some cleanup of multiple defragwait and defragremain functions.
# Reviewed by Craig
#
# Revision 1.48  2004/05/10 20:25:08  KohlmeyerA
# tbolt00000000:  Updated test cases called by case 99.  Reviewed by Craig
#
# Revision 1.47  2004/04/15 18:49:58  KohlmeyerA
# Tbolt00000000 - Added additional parm to GetDataDisks calls due to changes for SATA.  Reviewed by Craig
#
# Revision 1.46  2004/02/19 17:18:27  MenningC
# tbolt00000000:Add check for case where no vdisk is mapped to a controller., reviewed by Al
#
# Revision 1.45  2004/02/18 20:28:53  MenningC
# tbolt00000000:Fix defrag 5, timing on be14, etc., reviewed by Al
#
# Revision 1.44  2004/01/27 19:52:41  MenningC
# TBOLT00000000:changes for readability and additional data collection.
# Reviewed by Al
#
# Revision 1.43  2004/01/12 21:35:19  MenningC
# TBOLT00000000: Additions for nwayfailover, remove some delays in defrag, add a configuration option. Reviewed by Randy.
#
# Revision 1.42  2003/11/12 19:17:02  MenningC
# tbolt00000000: Scrub fixes and some additional debug code. Reviewed by Olga
#
# Revision 1.41  2003/11/05 21:16:39  MenningC
# tbolt00000000: Added 5 minute delays before and after testing. Defrag case 1 got additional delays.  Reviewed by Olga
#
# Revision 1.40  2003/10/08 15:35:22  WerningJ
# Tbolt00000000: defrag all fixes to test cases 11 and 22. reviewed by Olga
#
# Revision 1.39  2003/10/08 14:21:37  WerningJ
# Tbolt00000000: changes to support defrag all, reveiwed by Eric
#
# Revision 1.38  2003/09/30 20:51:04  MenningC
# tbolt00000000: Fix for empty vdisk list and initial fixes for one defrag at a time. Reviewed by Eric.
#
# Revision 1.37  2003/09/10 13:26:53  MenningC
# tbolt00000000: fix ictest menu, undace configs for n-way, improve 1 way support. reviewed by Olga
#
# Revision 1.36  2003/09/08 18:37:28  MenningC
# tbolt00000000: added sos table print to case 5. reviewed by Olga
#
# Revision 1.35  2003/08/08 13:43:20  MenningC
# tbolt00000000: changes to spread disk groups across drive bays. Reviewed by Eric
#
# Revision 1.34  2003/06/26 18:04:28  MenningC
# TBOLT00000000: Changes to support unchanging drive labels during hotspare in R2 and R3; reviewed by Olga
#
# Revision 1.33  2003/06/03 19:47:36  MenningC
# TBOLT00000000: Changed many of the 'display' functions in the CCBCL to fill a string rather than print to the screen. The test scripts can now use these functions. Reviewed by Jeff W.
#
# Revision 1.32  2003/05/28 14:54:20  MenningC
# TBOLT00000000: Changes to support bypassing of drives, patch for servermates, fix a defrag case timing.; reviewed by JW
#
# Revision 1.31  2003/05/14 18:53:31  MenningC
# TBOLT00000000: changes for debugging defrag case 11; reviewed by JW
#
# Revision 1.30  2003/04/30 19:13:16  MenningC
# tbolt00000000: changes to support debug of a miscompare problem. Reviewed by Olga
#
# Revision 1.29  2003/04/25 18:27:20  MenningC
# tbolt00000000: updates to case 99 23 and 2; reviewed by Olga
#
# Revision 1.28  2003/04/21 15:13:40  MenningC
# tbolt00000000: fix timeout in rmstate, fix bestress case22, fix defrag case 23; reviewed by JW
#
# Revision 1.27  2003/04/21 12:46:22  MenningC
# tbolt00000000: add case 23
#
# Revision 1.26  2003/04/08 18:45:43  MenningC
# tbolt00000000: delay after failing pdd and unfail changes ; reviewed by JW
#
# Revision 1.25  2003/03/26 21:24:52  WerningJ
# Removed calls to unused modules
# Reviewed by Craig M
#
# Revision 1.24  2003/03/14 16:22:09  MenningC
# added test case 22 as WIP, reviewed by JW
#
# Revision 1.23  2003/02/10 22:28:36  MenningC
# Tbolt00000000: changes to test case 6, reveiwed by Jeff Werning.
#
# Revision 1.22  2003/02/06 14:06:39  MenningC
# Tbolt00000000: fixes to test case 6 and 7 per Jeff Williams
#
# Revision 1.21  2003/01/29 17:17:07  MenningC
# Tbolt00000000: more debug of the BEstress tests, reviewed by J Werning
#
# Revision 1.20  2003/01/22 20:48:31  MenningC
# Tbolt00000000: fix for target maps. Reviewed by Jeff Werning.
#
# Revision 1.19  2003/01/15 15:40:03  MenningC
# Tbolt00000000:a fix for test case 4. Reviewed by J Werning.
#
# Revision 1.18  2003/01/14 15:26:39  MenningC
# Tbolt00000000: Changes to support BEUtils lib, removed UMC. Reveiewed by J Werning.
#
# Revision 1.17  2003/01/13 17:03:00  MenningC
# Tbolt00000000: Add a time dealy in tc 3, change waitforredicp, reviewed by Max.
#
# Revision 1.16  2003/01/07 22:27:50  MenningC
# Tbolt00000000: Many changes to handle the new content of targetstatus, reveiwed by Jeff Werning
#
# Revision 1.15  2003/01/02 15:07:59  MenningC
# Tbolt00000000:fix case 3, add 21, add 20 (still under debug-don't use), reviewed by Jeff Werning
#
# Revision 1.14  2002/12/26 20:14:54  MenningC
# Tbolt00000000: fixes for defrag case 3 and redicp, reviewed by Jeff Werning
#
# Revision 1.13  2002/12/23 22:07:12  MenningC
# Tbolt00000000: changed moxa ip to a list pointer, reviewed by JW
#
# Revision 1.12  2002/12/23 15:16:05  MenningC
# Tbolt00000000: Updates to sos validation. reviewed by J W
#
# Revision 1.11  2002/11/20 17:21:29  MenningC
# TBOLT00000000: more defrag and redicp changes,
#  reviewed by J. Werning
#
# Revision 1.10  2002/11/19 16:29:32  MenningC
# tbolt00000000: Updates to redicp, defrag and ctlrgrabber. Reviewed by Olga
#
# Revision 1.9  2002/11/13 20:30:18  MenningC
# tbolt00000000: Additional changes for the defrag test ; reviewed by J Werning
#
# Revision 1.8  2002/11/11 22:02:17  MenningC
# tbolt00000000: defrag debug changes, lots of them.
#
# Revision 1.7  2002/10/29 22:25:06  MenningC
# tbolt00000000:changes due to debug of defrag, reviewed by Olga
#
# Revision 1.6  2002/10/28 17:01:23  MenningC
# tbolt00000000:more unreviewed code changes.
#
# Revision 1.4  2002/10/21 17:53:08  MenningC
# tbolt00000000 additional code being saved away, pod, not reviewed (yet)
#
# Revision 1.2  2002/10/10 12:53:00  MenningC
# tbolt00000000 test for mark; reviewed by mark j
#
# Revision 1.1  2002/10/10 12:46:37  MenningC
# tbolt00000000 new file
#
#
##############################################################################
