#! /usr/bin/perl 
# $Header$
##############################################################################
#  
#   CCBE Integration test library - R10, R5 parity scan tests
#
#   112/26/2002  XIOtech   Craig Menning
#
#   A set of library functions for integration testing. This set support
#   testing of the controller's raid 5 support. Most test revolve around the
#   use of parity scan.
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002-2003 XIOtech
#
#   For XIOtech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::Parity - Perl Tests to test R5 and parity scan

$Id: Parity.pm 12253 2006-08-01 11:12:41Z AnasuriG $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing the robustness
of the Raid 5 support of the controller.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

            ParityEntry() 
              
        The less significant ones

              <none>

=cut


#                         
# - what I am
#

package TestLibs::Parity;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;

use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;

#
# - perl compiler/interpreter flags 'n' things
#


use strict;

#
# - local Constants used
#



#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 12253 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &ParityEntry

                        

                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 12253 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.
         
 $moxaPtr: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.
          
 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller. 

 $retIn: This is a controle variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be 
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the 
          attached servers. When configuring systems, this list determines 
          which WWNs will be associated with vdisks. If an entry in this 
          list is not found on the system, it will be ignored. A WWN 
          found on the system that is not included in the list will not 
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.
       



=back

=cut


###############################################################################


###############################################################################



###############################################################################

=head2 BETest2Way function

This is a dummy entry point for a series of BE stress tests. 

DO not call/use this function, The primary purpose is for 
documentation and development only.

Refer to the "ParityCase##" functions for a description of the individual
tests. In general, the tests all have the same inputs. Those test that do 
failover or failback have additional requirements related to the Moxa
power commander.


=cut

=over 1

=item Usage:

 my $rc = BETest2Way( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is the IP address of the moxa power controller
        $mmPtr is a the mapping of the moxa channels
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.




=back

=cut




##############################################################################
#
#          Name: BETest2Way
#
#        Inputs: controller object, server wwn list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Starting with a system that has some vdisks and IO running, 
#                ( IO is required for part of this ) DO a variety of things
#                and then start or force a rebuild.  There are several test cases 
#                invoked by this test, Each test case is described below.    
#
#
#               
#
#
##############################################################################
sub ParityTestCases
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my %info1;
    my @serialNums;
    my @startingTmap;
    my @pdiskData; 
    my @vdiskData; 
    my @raidData;
    my $vdiskListPtr;


    @serialNums = @$snPtr;

    $ret = GOOD;

    ######################################################################
    # Fail a controller, power cycle it many times, run parity scan, unfail
    ######################################################################

    $ret = BETestCase1(  $coPtr, $ret, $snPtr  );


    ######################################################################
    # Power cycles as in case 1, but with parity scan after each cycle
    ######################################################################

    $ret = BETestCase2(  $coPtr, $ret, $snPtr   );




    ######################################################################
    # More power cycles, unfailing controller each time
    # 
    ######################################################################

    $ret = BETestCase3(  $coPtr, $ret, $snPtr    );



    ######################################################################
    # Fails multiple pdisks, rebuild and run parity scan
    #
    ######################################################################

    $ret = BETestCase4(  $coPtr, $ret, $snPtr, $moxaIP, $mmPtr    );


    ######################################################################
    #     # Steps are 1)    moves a vdisk   don't use
    ######################################################################

    $ret = BETestCase5(  $coPtr, $ret, $snPtr, $moxaIP, $mmPtr    );


    
    ###################################################################### 
    # Do lots of QL resets on the FE and BE, pscan at end
    ######################################################################

    $ret = BETestCase6(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # DO lots of QL LIPS , do pscans
    #
    ######################################################################

    $ret = BETestCase7(  $coPtr, $ret, $snPtr   );


    
    ######################################################################
    # Copy swaps, fail ctlr during c/s, do pscan, unfail, finish swap, pscan
    ###################################################################### 

    $ret = BETestCase8(  $coPtr, $ret, $snPtr    );



    ###################################################################### 
    # Defrags, fail ctlr during defrag, do pscan, unfail, finish defrag, pscan
    ######################################################################

    $ret = BETestCase9(  $coPtr, $ret, $snPtr   );


    ###################################################################### 
    # C/s from early drive to r5p3 to r5p5,  do pscan, copy back to start
    #  do pscan
    ######################################################################

    $ret = BETestCase10(  $coPtr, $ret, $snPtr   );

    ###################################################################### 
    # C/s from r5p3 to r5p5, fail a pdisk in each, finish c/s, do pscan
    # restore, do pscan
    # This one will require a very specific configuration, and check to 
    # ensure that configuration exists before doing the test. (nuts)
    ######################################################################

    ###################################################################### 
    # power cycle a controller ( to fail it) then
    #    use that controller to do lots of lips on the FE and BE
    #
    ######################################################################

    $ret = BETestCase11(  $coPtr, $ret, $snPtr   );



    ###################################################################### 
    # DO lots of QL LIPS  power cycle a controller, unfail, do pscans      (see 7)
    ######################################################################

    $ret = BETestCase12(  $coPtr, $ret, $snPtr   );



    ###################################################################### 
    # fail a disk during a scrub
    #
    # Steps are 1) verify IO
    #           2) enable/start scrubbing
    #           3) fail a pdisk
    #           4) verify IO
    #           5) check scrubbing state
    #           6) wait for rebuild to end
    #           7) verify IO
    #           8) check scrub state/ re-enable if needed
    #           9) wait for one pass to complete
    #          10) verify IO
    #          11) stop scrubbing
    #          12) restore the failed pdisk
    #          13) verify IO
    ######################################################################

    $ret = BETestCase13(  $coPtr, $ret, $snPtr   );



    ###################################################################### 
    # Fail a pdisk while doing elections. This uses a data disk and 
    # rebuilds are expected.
    #
    #
    # Steps:
    #    1) Wait until all disks are operational
    #    2) Do 10 elections, back to back
    #    3) Start Election, Fail the pdisk  ( a data one )
    #    4) Do more elections, repeat until 200 are done, or
    #       the rebuild has finished
    #    5) If needed wait for the rebuild to finish.
    #    6) Do 10 more elections
    #    7) Verify IO
    #    8) Restore the disk to operation
    #    9) Do 50 more elections
    #   10) Verify IO
    ######################################################################

    $ret = BETestCase14(  $coPtr, $ret, $snPtr   );


    ###################################################################### 
    # Fail a pdisk while doing elections. Uses a hotspare disk, rebuilds 
    # not expected.
    #
    #
    # Steps:
    #    1) Wait until all disks are operational
    #    2) Do 10 elections, back to back
    #    3) Start election, Fail the pdisk  ( a hotspare one )
    #    4) Do more elections, repeat until 200 are done, or
    #       the rebuild has finished
    #    5) If needed wait for the rebuild to finish.
    #    6) Do 10 more elections
    #    7) Restore the disk
    #    8) Do 50 more elections
    #    9) Verify IO.
    ######################################################################

    $ret = BETestCase15(  $coPtr, $ret, $snPtr   );




    ###################################################################### 
    # Do multiple elections while a rebuild is running
    #
    # Steps:
    #    1) Wait until all disks are operational
    #    2) Fail a data disk so that a rebuild will start
    #    3) D0 200 elections or until rebuild finished
    #    4) If necessary, wait for the rebuild to finish.
    #    5) Restore the data disk
    #    6) Verify IO
    ######################################################################

    $ret = BETestCase16(  $coPtr, $ret, $snPtr   );


    ###################################################################### 
    # Do multiple elections while init is running
    #
    # Steps:
    #    1) Wait until all disks are operational
    #    2) Create and init a vdisk
    #    3) Do 200 elections or until init finished
    #    4) If necessary, wait for the init to finish.
    #    5) Verify IO
    #
    ######################################################################

    $ret = BETestCase17(  $coPtr, $ret, $snPtr   );



    ###################################################################### 
    # With no hotspares, fail and unfail a 'parity' disk
    # when done put back the hoptspares 
    #
    # Steps are 1) Identify the hotspares
    #           2) unlabel all hotspares
    #           3) verify IO
    #           4) fail a pdisk
    #           5) wait 20 seconds (for failure to be handled)
    #           6) verify IO
    #           7) wait for rebuild to end (should be immediate)
    #           8) restore the failed disk (this should start a rebuild)
    #           9) verify IO
    #          10) wait for rebuild to finish (should take a while)
    #          11) verify IO
    #          12) restore all the hotspares
    #          13) verify IO
    #          14) Make sure there is no rebuild running.
    #
    ######################################################################

    $ret = BETestCase18(  $coPtr, $ret, $snPtr   );




    ###################################################################### 
    # Fail a pdisk while doing a raid init on a single raid vdisk
    #
    # Steps are 1) Create a vdisk (single Raid)
    #           2) Start the raid init
    #           3) verify IO
    #           4) fail a pdisk (rebuild will start)
    #           5) wait for rebuilds to finish
    #           6) verify IO
    #           7) wait for init to finish
    #           8) verify IO
    #           9) delete the new vdisk
    #          10) verify IO
    #
    ######################################################################

    $ret = BETestCase19(  $coPtr, $ret, $snPtr   );




    ###################################################################### 
    # Fail a disk while doing raid inits on a multi raid vdisk
    #
    # Steps are 1) Create a vdisk (multiple Raid)
    #           2) Start the raid init
    #           3) verify IO
    #           4) fail a pdisk (rebuild will start)
    #           5) wait for rebuilds to finish
    #           6) verify IO
    #           7) wait for init to finish
    #           8) verify IO
    #           9) delete the new vdisk
    #          10) verify IO
    #
    ######################################################################

    $ret = BETestCase20(  $coPtr, $ret, $snPtr   );



    ###################################################################### 
    # Power Cycle the slave controller repeatedly
    #
    # Steps are 1) Locate a slave controller
    #           2) verify IO
    #           3) turn off the controller
    #           4) failover timeline from master
    #           5) verify IO
    #           6) for 'n' loops
    #                 turn on slave controller
    #                 wait 2 minute (timeline?)
    #                 verify IO
    #                 turn off controller
    #                 wait 2 minutes (timeline?)
    #                 verify IO
    #           7) turn on controller
    #           8) reconnect and unfail
    #           9) timeline for 2 minutes
    #          10) verify IO
    #
    ######################################################################

    $ret = BETestCase21(  $coPtr, $ret, $snPtr   );



    ###################################################################### 
    # Power Cycle the slave controller repeatedly while rebuild is running.
    #
    # Steps are 1) Locate a slave controller
    #           2) verify IO
    #           3) select a pdisk
    #           4) fail the pdisk
    #           5) confirm rebuild start
    #           6) turn off the slave controller
    #           7) failover timeline from master
    #           8) verify IO
    #           9) for 'n' loops
    #                 turn on slave controller
    #                 wait 2 minute (timeline?)
    #                 verify IO
    #                 turn off controller
    #                 wait 2 minutes (timeline?)
    #                 verify IO
    #          10) turn on controller
    #          11) reconnect and unfail
    #          12) timeline for 2 minutes
    #          13) verify IO
    #          14) wait for/verify rebuild is complete
    #          15) verify IO
    #
    ######################################################################

    $ret = BETestCase22(  $coPtr, $ret, $snPtr   );

    

    ###################################################################### 
    # Redi-copy and defrag while rebuilds are running.
    #
    # Steps are 1) Redi-copy a vdisk, wait for complete
    #           2) fail a pdisk - rebuilds start
    #           3) verify IO
    #           4) do another redi-copy, wait for complete
    #           5) verify IO
    #           6) delete first source vdisk
    #           7) start another redi-copy
    #           8) Begin defrags
    #           9) wait for copy complete
    #          10) verify IO
    #          11) wait for rebuild complete
    #          11.3) check SOS tables
    #          11.5) restart defrags
    #          12) verify IO
    #          13) wait for defrag complete
    #          14) check sos tables
    #          15) verify IO
    #           
    #
    ######################################################################

    $ret = BETestCase23(  $coPtr, $ret, $snPtr   );


    ###################################################################### 
    # While doing a redi-cp, delete a vdisk that is being initialized.
    #
    # Steps are 0.5) delete unused vdisks
    #           1) Create a vdisk
    #           2) start a redi-copy operation
    #           3) start init of the new vdisk
    #           4) verify IO
    #           5) delete the new vdisk
    #           6) verify IO
    #           7) wait for redi-cp to end
    #           8) wait for init/ all disks operational
    #           9) verify IO
    #         9.5) delete unused vdisks
    #          10) check sos tables
    #          11) start defag
    #          12) verify IO
    #          13) wait for defrag complete
    #          13.5) unfail pdisk
    #          14) check sos tables
    #          15) verify IO
    #           
    #
    ######################################################################

    $ret = BETestCase24(  $coPtr, $ret, $snPtr   );

    ###################################################################### 
    # While doing a redi-cp (mirror) delete the destination vdisk.
    #
    # Steps are 1) delete unused vdisks
    #           2) start a redi-copy operation
    #           3) wait a while
    #           4) verify IO
    #           5) delete the destination vdisk
    #           6) verify IO
    #           7) wait for redi-cp to end
    #           8) wait for init/ all disks operational
    #           9) verify IO
    #         9.5) delete unused vdisks
    #          10) check sos tables
    #          11) start defag
    #          12) verify IO
    #          13) wait for defrag complete
    #          14) check sos tables
    #          15) verify IO
    #           
    #
    ######################################################################

    $ret = BETestCase25(  $coPtr, $ret, $snPtr   );

    ###################################################################### 
    # While doing a redi-cp and defrag, delete a vdisk that is being initialized.
    #
    # Steps are 0.5) redi-copy 2 vdisks
    #           0.7) delete unused vdisks
    #           1) Create a vdisk
    #           2) start a redi-copy operation
    #           3) start init of the new vdisk
    #           3.6) start a defrag
    #           4) verify IO
    #           5) delete the new vdisk
    #           6) verify IO
    #           7) wait for redi-cp to end
    #           8) wait for init/ all disks operational
    #           9) verify IO
    #         9.5) delete unused vdisks
    #          10) check sos tables
    #          11) start defag
    #          12) verify IO
    #          13) wait for defrag complete
    #          14) check sos tables
    #          15) verify IO
    #           
    #
    ######################################################################

    $ret = BETestCase26(  $coPtr, $ret, $snPtr   );

    ###################################################################### 
    # Start a redi-cp operation TO a vdisk that is being initialized
    #
    # Steps are 1) houseclean
    #           2) create a rcp destination
    #           3) start inits on the vdisk
    #           4) begin a redicp TO the new vdisk
    #           5) wait for redi-cp to finish
    #          15) verify IO
    #           
    #
    ######################################################################

    $ret = BETestCase27(  $coPtr, $ret, $snPtr   );

    ###################################################################### 
    # Start a redi-cp operation FROM a vdisk that is being initialized
    #
    # Steps are 1) houseclean
    #           2) create a vdisk
    #           3) create a another vdisk
    #           4) begin inits on both
    #           5) start a redi-cp from one to the other
    #           6) verify IO
    #           6.5) display vdisk status
    #           7) delete the source vdisk
    #           8) display vdisk status
    #           9) wait for redi-cp to finish
    #          10) wait for inits to end
    #          11) verify IO
    #          12) delete unused vdisks
    #           
    #
    ######################################################################

    $ret = BETestCase28(  $coPtr, $ret, $snPtr   );

    ###################################################################### 
    # Start a redi-cp operation while drives are rebuilding
    #
    # Steps are 1) houseclean
    #           2) fail a pdisk
    #           3) wait for rebuild to start
    #           4) verify IO
    #           5) begin two redi-copy operations
    #           6) verify IO
    #           7) wait for redi-copy to end
    #           6) verify IO
    #           8) wait for rebuilds to end
    #           9) verify IO
    #           
    #
    ######################################################################

    $ret = BETestCase29(  $coPtr, $ret, $snPtr   );

    ###################################################################### 
    # Start a redi-cp operation while another disk is being initialized
    #
    # Steps are 1) houseclean
    #           2) create a vdisk
    #           3) create a another vdisk
    #           4) begin inits on both
    #           6) verify IO
    #           5) start a redi copy to a third new vdisk
    #           9) wait for redi-cp to finish
    #          11) verify IO
    #          10) wait for inits to end
    #          11) verify IO
    #           
    #
    ######################################################################

    $ret = BETestCase30(  $coPtr, $ret, $snPtr   );


    ###################################################################### 
    # Fail a pdisk repeatedly, waiting for the rebuilds to complete each
    # time.
    #
    # Steps are
    #           1) pick an active vdisk
    #           2) get its size
    #           3) create a new one
    #           4) get baseline IO activity info
    #           5) start the redi CP
    #           6) wait for redicp to complete
    #           7) confirm IO still going
    #           8) begin defrag 
    #           9) confirm IO still Ok
    #          10) fail a pdisk
    #          11) confirm IO again
    #          12) wait for rebuilds to end
    #          13) confirm IO
    #          14) check SOS tables
    #          15) restart/re-run defrag
    #          16) wait for defrag to complete
    #          17) check sos tables  
    #          18) confirm IO again
    #          19) restore the failed pdisk
    #          20) verify IO
    #           
    #
    ######################################################################

    $ret = BETestCase30(  $coPtr, $ret, $snPtr   );




    return $ret;

}

##############################################################################
#
#               Private Functions, but made public for debug
#
##############################################################################

#############################################################################

###############################################################################

=head2 ParityCase00 function

This test case just 
runs a parity scan. The test has these
basic steps...

     0) do a parity scan

=cut

=over 1

=item Usage:

 my $rc = ParityCase00( $coPtr, 
                        $retIn, 
                        $snPtr, 
                        $moxaIP, 
                        $mmPtr, 
                        $loopCount, 
                        $pDFailMeans  );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is a pointer to the moxa IP addresses, 
        $mmPtr is a pointer to the moxa port map 
        $loopCount is the number of loops to do 
        $pDFailMeans determines how the pdisk will be failed

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase00
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#
##############################################################################
sub ParityCase00
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
   
    my $ret;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "--------------- Test Case 0: just do a parity scan  ---------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # parity scan 
    logInfo("Just a parity scan.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    logInfo("End of Parity test case 0.");


    return GOOD;

}

###############################################################################


###############################################################################

=head2 ParityCase01 function

This test case fails a controller, power cycles it several times and then 
runs a parity scan. The test has these
basic steps...

     0) Houseclean system
     1) get baseline IO activity info
     2) turn off a controller (randomly chosen)
     3) power cycle that controller 'n' times
     4) unfail the controller
     5) confirm IO still going
     6) do a parity scan
     7) check SOS tables

=cut

=over 1

=item Usage:

 my $rc = ParityCase01( $coPtr, 
                        $retIn, 
                        $snPtr, 
                        $moxaIP, 
                        $mmPtr, 
                        $loopCount, 
                        $pDFailMeans  );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is a pointer to the moxa IP addresses, 
        $mmPtr is a pointer to the moxa port map 
        $loopCount is the number of loops to do 
        $pDFailMeans determines how the pdisk will be failed

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase01
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#
##############################################################################
sub ParityCase01
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $i;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;
    my $victim;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 1: power cycle a controller many times  ---------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # get measure of the current IO
    #
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);

    DispVdiskInfo($ctlr);

    # parity scan the world
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Initial parity scan reported an error - test failed.");
        return ERROR;
    }

    # parity scan 
    logInfo("Parity Scan at beginning of the test.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }


    ######################################################################
    # Now begin a loop to cycle power on the contoller 
    ######################################################################

    # setup - no need to houseclean
    CtlrLogTextAll($coPtr, "Test Case 1: Initial data collected, beginning test. " );

    # randomly select a controller

    $victim = int(  (scalar(@coList) *  rand(0.9999) ) );

    logInfo("Randomly selected controller is number $victim. ");

    #            turn off the controller

    CtlrLogTextAll($coPtr, "Test Case 1: now turning off $$coPtr[$victim]->{HOST}" );
    $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 0);
    if ( $ret != GOOD ) { return ERROR; }


    #            find current master
    DelaySecs(20);
    $master = FindMaster( $coPtr );
    $ctlr = $coList[$master];


    #            failover timeline from master
    $ret = FailOverTimeLine($coList[$master], 90, $snPtr, 0 );
    if ( $ret != GOOD ) { return ERROR; }


    #            verify IO
    logInfo("Verify IO after failing the controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # parity scan 
    logInfo("Parity Scan after powering down the controller.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    CtlrLogText($$coPtr[$master], "Test Case 1: beginning loop to cycle power $loopCount times." );


    #            for 'n' loops
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        #                 turn on slave controller
        CtlrLogText($$coPtr[$master], "Test Case 1: now turning on $$coPtr[$victim]->{HOST}" );
        $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 1);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(90);

        #                 turn off controller
        CtlrLogText($$coPtr[$master], "Test Case 1: now turning off $$coPtr[$victim]->{HOST}" );
        $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 0);
        if ( $ret != GOOD ) { return ERROR; }


        DelaySecs(30);

    }
    

    #           7) turn on controller
    CtlrLogText($$coPtr[$master], "Test Case 1: now turning on $$coPtr[$victim]->{HOST} (last time)" );
    $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 1);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # In the following, one contoller is failed and so this may require the
    # attempt to reconnect to time out (this is long). Since the controller 
    # should not be errortrapped, it should be able to be connected. ANyway,
    # we will not consider any error to be an issue, thus no check on the 
    # return.
    #

    TestNReconnectAll($coPtr);

    #           8) reconnect and unfail
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    #           9) timeline for 2 minutes (delay in above fcn)
    #          10) verify IO

    
    logInfo("Verify IO at end of the test, after restoring the controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # parity scan 
    logInfo("Parity Scan after unfailing the controller.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Verify IO
    #
    logInfo("Verify IO at end of the test, after parity scan");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Check the mirrors 
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of Parity test case 1.");


    return GOOD;

}

###############################################################################

=head2 ParityCase02 function
This test case fails a controller, power cycles it several times and then 
runs a parity scan. The test has these
basic steps...

     0) Houseclean system
     1) get baseline IO activity info
     2) turn off a controller (randomly chosen)
     3) power cycle that controller 'n' times
        (parity scan after each off and on)
     4) unfail the controller
     5) confirm IO still going
     6) do a parity scan
     7) check SOS tables

=cut

=over 1

=item Usage:

 my $rc = ParityCase02( $coPtr, 
                        $retIn, 
                        $snPtr, 
                        $moxaIP, 
                        $mmPtr, 
                        $loopCount, 
                        $pDFailMeans  );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is a pointer to the moxa IP addresses, 
        $mmPtr is a pointer to the moxa port map 
        $loopCount is the number of loops to do 
        $pDFailMeans determines how the pdisk will be failed

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 







=back

=cut

##############################################################################
#
#          Name: ParityCase02
#
#        Inputs: $coPtr, $retIn, $snPtr , $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
##############################################################################
sub ParityCase02
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $i;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;
    my $victim;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 2: power cycle a controller many times  ---------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # get measure of the current IO
    #
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);

    DispVdiskInfo($ctlr);

    # parity scan the world
    logInfo("Initial parity scan.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Initial parity scan reported an error - test failed.");
        return ERROR;
    }
    
    

    $ret = MirrorPartnerCheck( $ctlr );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed - Beginning Mirror Partner check  <<<<<<<<");
        return ERROR;
    }

    

    ######################################################################
    # Now begin a loop to cycle power on the contoller 
    ######################################################################

    # setup - no need to houseclean
    CtlrLogTextAll($coPtr, "Test Case 2: Initial data collected, beginning test. " );

    # randomly select a controller

    $victim = int(  (scalar(@coList) *  rand(0.9999) ) );

    logInfo("Randomly selected controller is number $victim. ");

    # build list of remaining object(s)
    my @short;

    for ( $i = 0; $i < scalar(@coList); $i++ )
    {
        if ( $i != $victim )
        {
            push(@short, $coList[$i]);
        }
    }

print"The short list is: @short \n";


    #            turn off the controller

    CtlrLogTextAll($coPtr, "Test Case 2: now turning off $$coPtr[$victim]->{HOST}   " );
    $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 0);
    if ( $ret != GOOD ) { return ERROR; }


    #            find current master
    DelaySecs(20);
    $master = FindMaster( $coPtr );
    $ctlr = $coList[$master];


    #            failover timeline from master
    $ret = FailOverTimeLine($coList[$master], 90, $snPtr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # parity scan the survivors
    logInfo("Parity scan with one controller turned off (first time).  ");
    $ret = TestLibs::BEUtils::PScanCheck( \@short, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan ($victim is off) reported an error - test failed.");
        return ERROR;
    }

    #            verify IO
    logInfo("Verify IO after failing the controller  ");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    CtlrLogText($$coPtr[$master], "Test Case 2: beginning loop to cycle power $loopCount times.  " );


    #            for 'n' loops
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        #                 turn on slave controller
        CtlrLogText($$coPtr[$master], "Test Case 2: now turning ON $$coPtr[$victim]->{HOST}  (loop $i)" );
        $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 1);
        if ( $ret != GOOD ) { return ERROR; }

        logInfo("Delay 3 minutes to allow the other controller to boot and the BE to be stable  (loop $i)");
        DelaySecs(180);

        # parity scan the survivors
        logInfo("Parity scan with all controllers active.");
        $ret = TestLibs::BEUtils::PScanCheck( \@short, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("Parity scan ($victim is on) reported an error - test failed.");
            return ERROR;
        }

        #                 turn off controller
        CtlrLogText($$coPtr[$master], "Test Case 2: now turning OFF $$coPtr[$victim]->{HOST}  (loop $i)" );
        $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 0);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(30);

        # parity scan the survivors
        logInfo("Parity scan with one controller turned off.");
        $ret = TestLibs::BEUtils::PScanCheck( \@short, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("Parity scan ($victim is off) reported an error - test failed.");
            return ERROR;
        }

    }
    

    #           7) turn on controller
    CtlrLogText($$coPtr[$master], "Test Case 2: now turning on $$coPtr[$victim]->{HOST}    (last time)" );
    $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 1);
    if ( $ret != GOOD ) { return ERROR; }

    #           8) reconnect and unfail
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    #           9) timeline for 2 minutes (delay in above fcn)
    #          10) verify IO

    
    logInfo("Verify IO at end of the test, after restoring the controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # parity scan 
    logInfo("Parity Scan after unfailing the controller.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    $ret = MirrorPartnerCheck( $ctlr );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed - Mirror Partner check at end <<<<<<<<");
        return ERROR;
    }


    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Verify IO
    #
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Check the mirrors 
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of Parity test case 2.");


    return GOOD;

}
###############################################################################
###############################################################################

=head2 ParityCase03 function
This test case fails a controller, power cycles it several times and then 
runs a parity scan. The test has these
basic steps...

     0) Houseclean system
     1) get baseline IO activity info
     2) turn off a controller (randomly chosen)
     3) power cycle that controller 'n' times
        (unfail the controller when turned on)
        (parity scan after each off and on)
     4) unfail the controller
     5) confirm IO still going
     6) do a parity scan
     7) check SOS tables


This test requires multiple controllers.

=cut

=over 1

=item Usage:

 my $rc = ParityCase03( $coPtr, 
                        $retIn, 
                        $snPtr, 
                        $moxaIP, 
                        $mmPtr, 
                        $loopCount, 
                        $pDFailMeans  );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is a pointer to the moxa IP addresses, 
        $mmPtr is a pointer to the moxa port map 
        $loopCount is the number of loops to do 
        $pDFailMeans determines how the pdisk will be failed

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 







=back

=cut

##############################################################################
#
#          Name: ParityCase03
#
#        Inputs: $coPtr, $retIn, $snPtr , $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
##############################################################################
sub ParityCase03
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $i;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;
    my $victim;
    my @deadList;
    my $slaveSN;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 3: power cycle/unfail many times  ---------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # get measure of the current IO
    #
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);

    DispVdiskInfo($ctlr);

    # parity scan the world
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Initial parity scan reported an error - test failed.");
        return ERROR;
    }

    ######################################################################
    # Now begin a loop to cycle power on the contoller 
    ######################################################################

    # setup - no need to houseclean
    CtlrLogTextAll($coPtr, "Test Case 3: Initial data collected, beginning test. " );

    # randomly select a controller

    $victim = int(  (scalar(@coList) *  rand(0.9999) ) );

    logInfo("Randomly selected controller is number $victim. ");

    # build list of remaining object(s)
    my @short;

    for ( $i = 0; $i < scalar(@coList); $i++ )
    {
        if ( $i != $victim )
        {
            push(@short, $coList[$i] );
        }
    }

    # get the slave's serial number

    $slaveSN = TestLibs::IntegCCBELib::GetSerial( $coList[$victim] );


    #            turn off the controller

    CtlrLogTextAll($coPtr, "Test Case 3: now turning off $$coPtr[$victim]->{HOST}" );
    $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 0);
    if ( $ret != GOOD ) { return ERROR; }


    #            find current master
    DelaySecs(20);
    $master = FindMaster( $coPtr );
    $ctlr = $coList[$master];


    #            failover timeline from master
    $ret = FailOverTimeLine($coList[$master], 90, $snPtr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # parity scan the survivors
    logInfo("Parity scan with one controller turned off (first time).");
    $ret = TestLibs::BEUtils::PScanCheck( \@short, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan ($victim is off) reported an error - test failed.");
        return ERROR;
    }

    #            verify IO
    logInfo("Verify IO after failing the controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    CtlrLogText($$coPtr[$master], "Test Case 3: beginning loop to cycle power $loopCount times." );


    #            for 'n' loops
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        #                 turn on slave controller
        CtlrLogText($$coPtr[$master], "Test Case 3: now turning ON $$coPtr[$victim]->{HOST}, loop $i." );
        $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 1);
        if ( $ret != GOOD ) { return ERROR; }

        # unfail the controller


        # need to reconnect to the controller
        logInfo("Pause for 60 seconds and reconnect to slave($$snPtr[$victim])  ");
        $ret = TestLibs::IntegCCBELib::Reconnect( $coList[$victim], 60 );
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to reconnect to the controller   <<<<<<<<");
            return ERROR;
        }

        # wait for the controller to sufficiently boot
        Wait4MinPowerUpState($coList[$victim], POWER_UP_FAILED, 360);          


        # find the master, if it changed
        logInfo("Searching for the master controller in the group");
        $master = TestLibs::IntegCCBELib::FindMaster( $coPtr );
        if ( $master == INVALID )
        {
            logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
            return ERROR;
        }

        #
        # unfail the slave
        #
        
        logInfo("Unfailing the controller  ");
        $ret = TestLibs::IntegCCBELib::UnFailController( $coList[$master], $slaveSN );
        if (  $ret == ERROR )
        {
            logError(">>>>>>>> Failed to restore the controller to active duty  <<<<<<<<");
            return ERROR;
        }

        # allow the failback to complete (takes about 1.5 minutes
        logInfo("-------- Pause as the controller fails back -----------");
        @deadList = (INVALID);
        FailOverTimeLineNway( $coPtr, 90, $snPtr, \@deadList);
                


        # parity scan all controllers
        logInfo("Parity scan with all controllers active.");
        $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("Parity scan ($victim is on/unfailed) reported an error - test failed.");
            return ERROR;
        }

        #                 turn off controller
        CtlrLogText($$coPtr[$master], "Test Case 3: now turning OFF $$coPtr[$victim]->{HOST}, loop $i." );
        $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 0);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(30);

        # parity scan the survivors
        logInfo("Parity scan with one controller turned off.");
        $ret = TestLibs::BEUtils::PScanCheck( \@short, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("Parity scan ($victim is off) reported an error - test failed.");
            return ERROR;
        }


    }
    

    #           7) turn on controller
    CtlrLogText($$coPtr[$master], "Test Case 3: now turning on $$coPtr[$victim]->{HOST} (last time)" );
    $ret = PowerChange($$moxaIP[$victim], $$mmPtr[$victim], 1);
    if ( $ret != GOOD ) { return ERROR; }

    #           8) reconnect and unfail
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    #           9) timeline for 2 minutes (delay in above fcn)
    #          10) verify IO

    
    logInfo("Verify IO at end of the test, after restoring the controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # parity scan 
    logInfo("Parity Scan after unfailing the controller.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Verify IO
    #
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Check the mirrors 
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of Parity test case 3.");


    return GOOD;

}
###############################################################################

###############################################################################

=head2 ParityCase04 function             



This test case fails multiple disks and lets them rebuild, then does 
a parity scan. The pdisks are chosen to be in different raids so that
raid will go offline.

The test has these
basic steps...

     1) identify some pdisks
     2) fail those pdisks
     3) wait until rebuilds start
     4) verify IO
     5) wait for rebuilds to finish
     6) verify IO
     7) do the parity scan
     8) restore the failed pdisk(s)
     9) verify IO
    10) do another parity scan

=cut

=over 1

=item Usage:

 my $rc = ParityCase04( $coPtr, $retIn, $snPtr, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $pDFailMeans selects pwoer down or bypass to fail a disk

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 4, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 54, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase04
#
#        Inputs: $coPtr, $retIn, $snPtr , $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub ParityCase04
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @snList;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    my @oldVds;
    my $index;
    my $targ;
    my $index2;
    my @pdds;
    my $lc;
    my %rsp;
    my @ses;
    my @slot;
    my $ret;
    my $ses1;
    my $slot1;
    my $numPddsFailed;
    my $i;
    my $lid;
    my $port;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 4: Fail multiple pdisks, rebuild and parity scan.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # get measure of the current IO
    #
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);

    DispVdiskInfo($ctlr);
    @snList = @$snPtr;

    # parity scan 
    logInfo("Parity Scan at start of test.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Initial parity scan reported an error - test failed.");
        return ERROR;
    }

    ######################################################################
    # Fail multiple pdisks, rebuild, unfail 
    ######################################################################


    #
    # Locate some isolated pdisks. Shouldn't need more than three.
    #
    $ret = FindIsolatedPdds($ctlr, \@pdds, 3);
    if ( $ret != GOOD ) { return ERROR; }

    $numPddsFailed = scalar(@pdds);

    logInfo("The number of disks to be failed: $numPddsFailed ");
    logInfo("These pdisks will be failed @pdds ");

    #
    # Fail those pdisks
    #

    for ( $i = 0; $i < $numPddsFailed; $i++)
    {
        # get ses and slot info for when we unfail
        GetSesAndSlot ($ctlr, $pdds[$i], \$ses1, \$slot1, \$lid, \$port);
        $ses[$i] = $ses1;
        $slot[$i] = $slot1;

        $ret = FailPdisk( $coPtr, $pdds[$i] , $pDFailMeans);
        if ( $ret != GOOD ) { return ERROR; }
    }

    # the disks are failed, now some rebuilds will soon begin

    DelaySecs(120);

    #
    # verify IO is still good
    #
    
    logInfo("Verify IO with multiple failed pdisks");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    #

    logInfo("polling until rebuild finishes");
    $ret = INVALID;


    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );
 
    #
    # verify IO is still good
    #
    
    logInfo("Verify IO after rebuild of multiple failed pdisks");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # parity scan 
    #
    
    logInfo("Parity Scan after rebuild completes.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    #
    # unfail the drives
    #
    
    for ( $i = 0; $i < $numPddsFailed; $i++)
    {
        $ret = UnfailPdisk($coPtr, $pdds[$i], $ses[$i], $slot[$i], 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

    }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # verify IO is still good
    #
    
    logInfo("Verify IO after rebuild of multiple failed pdisks");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # parity scan 
    #
    
    logInfo("Parity Scan after rebuild completes.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    #
    # Verify IO
    #
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Check the mirrors 
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of Parity test case 4.");

    return GOOD;
}






###############################################################################
###############################################################################

=head2 ParityCase05 function

This test case changes the VID number of R5 vdisks. A 
parity scan is done after each change. 

Uses virtualDiskControl.

The test has these
basic steps...

     0) Houseclean system
     1) identify a vdisk
     2) change its VDD number
     3) verify IO
     4) do parity scan
     5) repeat 2-4 'n' times
     6) put vdisk back where we found it
     7) verify IO
     8) do parity scan

=cut

=over 1

=item Usage:

 my $rc = ParityCase05( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
       

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase05
#
#        Inputs: $coPtr, $retIn, $snPtr, $pDFailMeans   
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub ParityCase05
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    my $ret;
    my @pdds;
    my @oldVds;
    my $index;
    my $targ;
    my $index2;
    my @snList;
    my $lc;
    my %rsp;
    my $failedDisk;
    my $ses;
    my $slot;
    my $count;
    my @vdds;
    my @uVdds;
    my $numVdisksMoving;
    my $loop;
    my $j;
    my @newVds;
    my $numDestVids;
    my $numV2M;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 5: Change VID number several times.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # get measure of the current IO
    #
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);

    DispVdiskInfo($ctlr);

    ######################################################################
    # change the VID number for a vdisk multiple times
    ######################################################################

    @snList = @$snPtr;

    #
    # Identify the vdisks for the test
    #

    $count = 10;              # number to look for (max.)

    $ret = LocateRaidXVdisks($ctlr, \@vdds, $count, RAID_5);
    if ( $ret == ERROR )
    {
        logInfo("Errors getting raid info causes the test to fail.");
        return ERROR;
    }

    if ( $ret != GOOD )
    {
        logInfo("Not enough Raid 5 disks were found, Raid 10 will also be used.");

        $ret = LocateRaidXVdisks($ctlr, \@vdds, ($count - scalar(@vdds)), RAID_10);
    
        if ( $ret == ERROR )
        {
            logInfo("Errors getting raid info causes the test to fail.");
            return ERROR;
        }
    }

    $numVdisksMoving = scalar(@vdds);

    logInfo("The number of vdisks to be moved: $numVdisksMoving ");
    logInfo("These vdisks will be moved: @vdds ");

    $ret = FindUnusedVdds( $ctlr, \@uVdds, $numVdisksMoving );

    $numDestVids = scalar(@uVdds);
    
    logInfo("These $numDestVids vdisks will be the alternates:  @uVdds ");

# return GOOD;


#    my @homes;
#
#    for ( $loop = 0; $loop < scalar(@vdds); $loop++ )
#    {
#        #
#        # find the current owner for each vdisk
#        #
#
#
#
#
#    }
#

    $numV2M = min ( $numDestVids,  $numVdisksMoving);

    for ( $loop = 0; $loop < $loopCount; $loop++ )
    {

        # Move vdisks to the unused number        


        for ( $j = 0; $j < $numV2M; $j++ )
        {


            print "Moving vdisk  $vdds[$j] to $uVdds[$j], loop $loop.      \n"; 
                                                      # src         dest
            %rsp = $ctlr->virtualDiskControl(0x00, $vdds[$j], $uVdds[$j]);

            if (!%rsp)                        # no response
            {
                print "\n";
                logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                return ERROR;
            }

            if ($rsp{STATUS} == 1)            # 1 is bad
            {
                logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                print "\n";
                PrintError(%rsp);
                return ERROR;
            }

        }

        # now put them back the way they were

        for ( $j = 0; $j < $numV2M; $j++ )
        {


            print "Moving vdisk  $uVdds[$j] to $vdds[$j], loop $loop.      \n"; 
                                                      # src         dest
            %rsp = $ctlr->virtualDiskControl(0x00, $uVdds[$j], $vdds[$j]);

            if (!%rsp)                        # no response
            {
                print "\n";
                logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                return ERROR;
            }

            if ($rsp{STATUS} == 1)            # 1 is bad
            {
                logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                print "\n";
                PrintError(%rsp);
                return ERROR;
            }

        }


    }


    #
    # verify ongoing IO
    #

    # verify IO is still good
    logInfo("Verify IO after moving vdisk(s)");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }
    


    #
    # parity scan - all controllers
    #

    logInfo("Parity Scan after moving vdisks.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    #
    # Verify IO
    #
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Check the mirrors 
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of parity test case 5.");


    return GOOD;

}

###############################################################################
###############################################################################

=head2 ParityCase06 function

This test case repeatedly resets the BE qlogic cards with parity scan 
during and after the resets
. 
The test has these
basic steps...

     0) Houseclean system
     1) start parity scan - continuous
     2) for 'n' loops
           sequentially reset each FE QL card
           wait 5 secs between resets
     3) verify IO
     4) check parity scan for errors
     5) for 'n' loops
           sequentially reset the BE QL cards
           wait 5 secs between cards
     6) verify IO
     7) check parity scan for errors
     8) confirm still continuous on all controllers
     9) wait for 3 minutes for IO to do compares
    10) verify IO
    11) check parity scan for errors
    12) stop parity scans
    13) check parity scan for errors
    14) re-check parity scan (2 loops)
    15) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase06( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase06
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub ParityCase06
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    my $i;
    my $j;
    my $k;
    my $l;
    my $ret;
    my $c;
    my $q;
    my $failFlag;
    my %rsp;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 6: Lots of resets on the Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # get measure of the current IO
    #
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);

    DispVdiskInfo($ctlr);

    ######################################################################
    # several loops to reset cards 
    ######################################################################


    #
    # start a parity scan on all controllers
    #

    logInfo("Starting continuous parity scans on all controllers.");
    $ret =  PScanStart( $coPtr, SCRUB_PC_CLEARLOG_MASK, INVALID);
    if ($ret != GOOD )
    {
        logInfo("Failure starting scans for the parity check");
        return ERROR;
    }

    #
    # for n loops
    #

    logInfo("Start FE Qlogic reset loop.");

    for ( $i = 0; $i < $loopCount; $i++ )
    {
    
        #
        # for each controller
        #
    
        for ( $c = 0; $c < scalar(@$coPtr); $c++ )
        {
            
            $ctlr = $$coPtr[$c];
        
            #
            # for each ql card
            #
        
            for ( $q = 0; $q < 4; $q ++ )
            {
                #
                # reset the FE qlogic cards
                #

                QLReset( $ctlr, "FE", $q, RESET_QLOGIC_RESET_INITIALIZE );
                                                                 
                # wait 5 seconds

                sleep 5;
            }
        }
    }
        
    #
    # verify IO
    #
 
    logInfo("Verify IO after $loopCount loops sequentially resetting the FE QLogic cards");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    #
    # parity scan (just check for errors)
    #
    
    logInfo("Checking parity scan results after FE QLResets.");

    $ret =  PScanResults( $coPtr, 0 , 0, undef );
    
    if ($ret != GOOD )
    {
        logInfo("Errors seen during the parity scan");
        return ERROR;                                                              
    }

    #
    # confirm parity scan is still continuous
    #

    logInfo("Verify that parity scans are still continuous.");

    $failFlag = 0;

    for ( $c = 0; $c < scalar(@$coPtr); $c++ )
    {
        
        $ctlr = $$coPtr[$c];
        
        %rsp = $ctlr->scrubInfo();


        if ( !%rsp )
        {
            logInfo(">>>>>>>> Did not receive a response packet from scrubInfo  <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error returned  from scrubInfo  <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        $msg = "For controller $ctlr->{HOST}, parity scanning is $rsp{PC_1PASS}";
        logInfo ($msg);

        if ( $rsp{PC_1PASS} ne "CONTINUOUS")
        {
            logInfo("Parity scanning should be CONTINUOUS");
            $failFlag = 1;
        }


    }

    if ( $failFlag != 0 )
    {
        return ERROR;
    }

    #
    # for n loops
    #

    logInfo("Starting loop to reset BE QLogic cards.");

    for ( $i = 0; $i < $loopCount; $i++ )
    {
    
        #
        # for each controller
        #
    
        for ( $c = 0; $c < scalar(@$coPtr); $c++ )
        {
            
            $ctlr = $$coPtr[$c];
        
            #
            # for each ql card
            #
        
            for ( $q = 0; $q < 4; $q ++ )
            {
                #
                # reset the FE qlogic cards
                #

                QLReset( $ctlr, "BE", $q, RESET_QLOGIC_RESET_INITIALIZE );
                                                                 
                # wait 5 seconds

                sleep 5;
            }
        }
    }
        
    #
    # verify IO
    #
 
    logInfo("Verify IO after $loopCount loops sequentially resetting the BE QLogic cards");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    #
    # parity scan (just check for errors)
    #
    
    logInfo("Check parity scan data for errors.");

    $ret =  PScanResults( $coPtr, 0 , 0, undef );
    
    if ($ret != GOOD )
    {
        logInfo("Errors seen during the parity scan");
        return ERROR;                                                              
    }

    #
    # confirm parity scan has switched to single
    #

    logInfo("Verify that parity scan is now in SINGLE mode.");

    $failFlag = 0;

    for ( $c = 0; $c < scalar(@$coPtr); $c++ )
    {
        
        $ctlr = $$coPtr[$c];
        
        %rsp = $ctlr->scrubInfo();


        if ( !%rsp )
        {
            logInfo(">>>>>>>> Did not receive a response packet from scrubInfo  <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error returned  from scrubInfo  <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        $msg = "For controller $ctlr->{HOST}, parity scanning is $rsp{PC_1PASS}";
        logInfo ($msg);

        if ( $rsp{PC_1PASS} eq "CONTINUOUS")
        {
            logInfo("Parity scanning should be SINGLE");
            $failFlag = 1;
        }


    }

    if ( $failFlag != 0 )
    {
        return ERROR;
    }

    #
    # wait 3 minutes for IO to accumulate
    #
    
    logInfo("Wait for 3 minutes for IO to accumulate.");

    DelaySecs(360);



    #
    # verify IO
    #

    logInfo("Verify IO after 3 minute delay");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }



    #
    # check parity scan for errors
    #
    
    logInfo("Check parity scan for errors after the 3 minute delay.");

    $ret =  PScanResults( $coPtr, 0 , 0, undef );
    
    if ($ret != GOOD )
    {
        logInfo("Errors seen during the parity scan");
        return ERROR;                                                              
    }


    #
    # stop parity scan
    #

    
    logInfo("Stop the parity scan.");

    $ret =  PScanStop( $coPtr ); 
       
    if ($ret != GOOD )
    {
        logInfo("Failure stopping scans for the parity check");
        return ERROR;                                                              
    }

    #
    # check parity scan for errors
    #
    
    logInfo("Recheck parity scan data for errors.");

    $ret =  PScanResults( $coPtr, 0 , 0, undef );
    
    if ($ret != GOOD )
    {
        logInfo("Errors seen during the parity scan");
        return ERROR;                                                              
    }



    #
    # re-run parity scan - 2 loops
    #
    
    logInfo("Complete parity Scan at end.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }


    # 
    # verify IO
    #


    logInfo("Verify IO at end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Check the mirrors 
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of parity test case 6.");


    return GOOD;

}

###############################################################################
###############################################################################

=head2 ParityCase07 function

This test case repeatedly LIPs the BE qlogic cards. 
The test has these
basic steps...

     0) Houseclean system
     1) select the controller
        2) for 'n' loops
              sequentially LIP each QL card
              wait 15 secs between LIPs
        3) verify IO
     4) repeat for the other controller(s)
     5) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase07( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase07
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub ParityCase07
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    

    my $i;
    my $j;
    my $k;
    my $l;
    my $ret;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 7: Lots of LIPs on the BE Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # get measure of the current IO
    #
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);

    DispVdiskInfo($ctlr);

    #
    # run parity scan - 2 loops
    #
    
    logInfo("Complete parity scan at beginning.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    ######################################################################
    # loops to LIP the BE cards. 
    ######################################################################

    # Steps are 1) select the controller
    for ( $i = 0; $i < scalar(@$coPtr); $i++ )
    {

        $ctlr = $coList[$i];

        #           2) for 'n' loops

        logInfo("(2) Begin loop to LIP each card with 15 second delay");

        for ( $j = 0; $j < $loopCount; $j++ )
        {
 
 
            
            #   sequentially LIP each QL card
            for ( $k = 0; $k < 4; $k++ )
            {
 
                $ret = ResetBELoop ($ctlr, $k );

               
                if ( $ret == ERROR ) 
                { 
                    print ("\n");
                    logInfo("Error from ResetBELoop. Card = $k.");
                    return ERROR; 
                }
                
                print("                                          LIP # $j, with delay, launched. \r");
                                                                 
                # wait 15 secs between LIPs
                if ( $ret != INVALID )
                {
                    DelaySecs(15);
                }
            }

        }

        print "\n";
        
        #  3) verify IO is still good
        
        logInfo("(3) Verify IO after $loopCount loops sequentially LIPping the BE QLogic cards");
        $ret = VerifyIO( $coPtr,
                         \@activeServers, 
                         \@tMap, 
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }
        
        
        #
        # re-run parity scan - 2 loops
        #
    
        logInfo("Complete parity scan after LIPs on a contoller.");
        $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("Parity scan reported an error - test failed.");
            return ERROR;
        }
    }
    
    # verify IO is still good
    logInfo("Verify IO at end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # re-run parity scan - 2 loops
    #

    logInfo("Complete parity scan at end.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    #
    # Verify IO
    #
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Check the mirrors 
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of parity test case 7.");


    return GOOD;

}
###############################################################################

=head2 ParityCase08 function

This test power cycles the slave controller while doing a redi-copy. 
The test has these
basic steps...

    
     1) pick a controller
     2) start a redi-copy
     3) power cycle a slave controller
     4) verify IO
     5) unfail the controller
     6) wait for the copy to complete
     7) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase08( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase08
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
##############################################################################
sub ParityCase08
{
    trace();
    my ($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    my $i;
    my $j;
    my @pdds;
    my $ret;
    my $ret2;

    my $other;
    my @oldVds;
    my $newVd;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 8: Power cycle a controller during a redi-copy.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    #
    # Make sure we have enough controllers to do this test.
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers.  Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    $other = 1;
    if ( $master == 1 ) { $other = 0; }
    my $ctlrS =  $coList[$other];

    CtlrLogTextAll($coPtr, "Test Case 8: Starting up. " );

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # get measure of the current IO
    #
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);

    DispVdiskInfo($ctlr);

    #
    # run parity scan - 2 loops
    #

    CtlrLogTextAll($coPtr, "Test Case 8: Complete parity scan at beginning. " );

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    ######################################################################
    # redi-copy and power cycle a controller 
    ######################################################################


    CtlrLogTextAll($coPtr, "Test Case 8: Select vdisk and create a clone. " );

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find three vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # nake a replacement
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }

    # copy it to the replacement
    

    CtlrLogTextAll($coPtr, "Test Case 8: Begin a redi-copy operation. " );

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 8: Short pause as the copy begins. " );
    DelaySecs(5);

    # copy has started. now power cycle the other controller. This will
    # fail it and mess up the copy.

    CtlrLogTextAll($coPtr, "Test Case 8: Power cycling slave controller with redi-copy running. " );

    $ret = PowerCycle($$moxaIP[$other], $$mmPtr[$other]);

    CtlrLogText($ctlr, "Test Case 8: Begin 150 second delay as slave reboots. " );

    logInfo("Delay as the controller boots.");
    DelaySecs(150);

    CtlrLogText($ctlr, "Test Case 8: After delay, verify IO. " );

    # verify IO is still good
    
    logInfo("Verify IO with a failed controller");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );

    #
    # re-run parity scan - 2 loops
    #
    
    CtlrLogText($ctlr, "Test Case 8: Parity scan on master with other controller failed (errors expected). " );

    logInfo("Complete parity scan with a failed controller, errors expected.");
    $ret2 = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret2 != GOOD )
    {
        logInfo(">>>>>>>>>>>>>Parity scan reported an error - this may be OK if on the copy dest. <<<<<<<<<<");
        #return ERROR;
    }
    if ( $ret != GOOD ) 
    { 
        logInfo("The IO check failed. Parity scan returned $ret.");
        return ERROR; 
    }



    CtlrLogText($ctlr, "Test Case 8: Unfailing slave controller. " );

    # reconnect and unfail
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good

    CtlrLogTextAll($coPtr, "Test Case 8: Verify IO after unfailing controller.");

    $ret2 = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret2 != GOOD )
    {
        logInfo(">>>>>>>>>>>>>Parity scan reported an error - this may be OK if on the copy dest. <<<<<<<<<<");
        #return ERROR;
    }
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }



# do I need to restart the copy?  no, it should have been rebuilt by the master

    CtlrLogTextAll($coPtr, "Test Case 8: Checking that copies are complete on all controllers. " );

    for ( $i = 0; $i < scalar(@coList); $i++)
    {
        $ret = WaitForCpComplete( $coList[$i], $newVd );
        if ( $ret != GOOD ) { return ERROR; }
    }

    CtlrLogTextAll($coPtr, "Test Case 8: Delete the source disk. " );

    # delete the source ( the early vdisk )
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) ) 
    {
        return ERROR;
    }

    CtlrLogTextAll($coPtr, "Test Case 8: Verify IO at end. " );
    $ret2 = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret2 != GOOD )
    {
        logInfo(">>>>>>>>>>>>>Parity scan reported an error - this may be OK if on the copy dest. <<<<<<<<<<");
        #return ERROR;
    }

    # verify IO is still good
    logInfo("Verify IO with a failed controller");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }




    #
    # re-run parity scan - 2 loops
    #

    CtlrLogTextAll($coPtr, "Test Case 8: Complete parity scan at end (should be good).. " );

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    # done

    #
    # Verify IO
    #
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Check the mirrors 
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 8: End of parity test case 8. " );

    return GOOD;

}

###############################################################################

###############################################################################

=head2 ParityCase09 function

This test power cycles the slave controller while doing defrag. 
The test has these
basic steps...

    
     1) pick a controller
     2) start defrags
     3) power cycle a slave controller
     4) verify IO
     5) unfail the controller
     6) wait for the defrag to complete
     7) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase09( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase09
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
##############################################################################
sub ParityCase09
{
    trace();
    my ($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    my $i;
    my $j;
    my @pdds;
    my $ret;
    my @oldVds;
    my $newVd;

    my %info;
    my $needed;
    my $vid1;
    my $vid2;
    my $newVd1;
    my $newVd2;
    my $other;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 9: Power cycle a controller during a defrag.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    #
    # Make sure we have enough controllers to do this test.
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers.  Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];
    
    $other = 1;
    if ( $master == 1 ) { $other = 0; }

    my $ctlrS = $coList[$other];

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # get measure of the current IO
    #
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);

    DispVdiskInfo($ctlr);

    #
    # re-run parity scan - 2 loops
    #

    logInfo("Complete parity scan at beginning.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
#        return ERROR;
    }

    ######################################################################
    # defrag and power cycle a controller 
    ######################################################################

    ####################################
    # first clean up from previous tests
    ####################################

    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # defrag all pdisks
    $ret = DefragAllBegin($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # wait for defrags to complete
    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    ###############################
    # select vdisks for copy
    ###############################

    # find an early vdisk - owned by the first controller
    
    %info = $ctlr->virtualDiskCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    $needed = $info{COUNT};

    # we ask for all the vdisks so that we  can later make 
    # requests from the sorted list.

    @oldVds = FindEarlyVdisk( $ctlr, $needed );     # get all, ordered 
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    
    # got the list, now find the first one for first controller

    $vid1 = FirstVdiskOnCtlr($coPtr, \@oldVds, 0, $snPtr);
    if ( $vid1 == INVALID ) { return ERROR; }


    # make a new vdisk
    
    $newVd1 =  CreateReplacementVdisk($ctlr, $vid1 );
    if ( $newVd1 < 0 ) { return ERROR; }

    # find an early vdisk - owned by the second controller
    
    $vid2 = FirstVdiskOnCtlr($coPtr, \@oldVds, 1, $snPtr);
    if ( $vid2 == INVALID ) { return ERROR; }
    
    # make a new vdisk
    
    $newVd2 =  CreateReplacementVdisk($ctlr, $vid2 );
    if ( $newVd2 < 0 ) { return ERROR; }
    
    ####################################
    # start redicp for both vdisks
    ####################################
    
    logInfo("      Start a redi-copy task for both vdisks");
    $ret = RediCpVdisks($ctlr, $vid1, $newVd1 );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = RediCpVdisks($ctlr, $vid2, $newVd2 );
    if ( $ret != GOOD ) { return ERROR; }

    # wait for both to complete

    logInfo("      Allowing redi-copy to complete for both vdisks");
    $ret = WaitForCpComplete( $ctlr, $newVd1 );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = WaitForCpComplete( $ctlr, $newVd2 );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    
    # delete both source vdisks

    logInfo("      Deleting the two source vdisks");

    logInfo("Deleting $newVd1");

    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd1) ) 
    {
        return ERROR;
    }


    logInfo("Deleting $newVd2");
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd2) ) 
    {
        return ERROR;
    }

    ################################################
    # System now fragmented for test - begin defrag
    ################################################


    # defrag all pdisks
    $ret = DefragAllBegin($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # defrag has started. now power cycle the other controller.

    CtlrLogTextAll($coPtr, "Test Case 9: Power cycling slave controller with defrag running. " );

    $ret = PowerCycle($$moxaIP[$other], $$mmPtr[$other]);

    logInfo("Delay as the controller reboots.");
    DelaySecs(150);

    # verify IO is still good
    logInfo("Verify IO with a failed controller");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # re-run parity scan - 2 loops
    #

    logInfo("Complete parity scan with a failed controller.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
#        return ERROR;
    }




    # reconnect and unfail
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    logInfo("Verify IO with a failed controller");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }



    # defrag all pdisks (the failover stopped any running defrag)
    $ret = DefragAllBegin($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # wait for defrags to complete
    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # re-run parity scan - 2 loops
    #

    logInfo("Complete parity scan with an unfailed controller.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
#        return ERROR;
    }




    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }

    # defrag all pdisks
    $ret = DefragAllBegin($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # wait for defrags to complete
    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }



    # verify IO is still good
    logInfo("Verify IO with a failed controller");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }




    #
    # re-run parity scan - 2 loops
    #

    logInfo("Complete parity scan at end.");
    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
#        return ERROR;
    }

    #
    # Verify IO
    #
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Check the mirrors 
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of parity test case 9.");


    return GOOD;

}

###############################################################################
###############################################################################

=head2 ParityCase10 function

This does a redi-copy to a raid 5 parity 5 vdisk, then parity scan.
Then copies the disk to a raid 5 parity 3 vdisk, does another parity
scan, finally opies the vdisk back to the starting location. 
The test has these
basic steps...

    
     1) find an early vdisk
     2) create a destination disk R5P5
     3) copy/swap the vdisk
     4) run pscan
     5) create a destination disk R5P3
     6) copy/swap the disks
     7) run pscan
     8) copy disk back to original
     9) run pscan

=cut

=over 1

=item Usage:

 my $rc = ParityCase10( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase10
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
##############################################################################
sub ParityCase10
{
    trace();
    my ($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $newVd2;


    my $i;
    my $j;
    my @pdds;
    my $ret;
    my $other;
    my @oldVds;
    my $newVd;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "--------------- Test Case 10: Redicopies changing parity.------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    $other = 1;
    if ( $master == 1 ) { $other = 0; }
    my $ctlrS =  $coList[$other];

    CtlrLogTextAll($coPtr, "Test Case 10: Starting up, measuring IO. " );

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    DeleteUnusedVdisks( $ctlr, 0);

    #
    # run parity scan - 2 loops
    #

    CtlrLogTextAll($coPtr, "Test Case 10: Complete parity scan at beginning. " );

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
     #   return ERROR;
    }

    ######################################################################
    # redi-copy to R5P3 then R5P5 then back to start
    ######################################################################


    CtlrLogTextAll($coPtr, "Test Case 10: Select vdisk and create a clone. " );

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find a vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    logInfo("Source vdisk:");
    ShortVdiskInfo($ctlr, $oldVds[0] );
    
    #################################
    # Now copy to a R5P3 drive
    #################################


    # nake a replacement
    $newVd =  CreateSimilarVdisk($ctlr, $oldVds[0], RAID_5, 3, 0);
    if ( $newVd < 0 ) { return ERROR; }

    # copy it to the replacement
    
    logInfo("Destination vdisk:");
    ShortVdiskInfo($ctlr, $newVd );

    CtlrLogTextAll($coPtr, "Test Case 10: Begin a redi-copy operation to R5P3. " );

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 10: Short pause as the copy begins. " );
    DelaySecs(5);

    # copy has started. 
    
    
    CtlrLogTextAll($coPtr, "Test Case 10: Checking that copies are complete on all controllers. " );

    for ( $i = 0; $i < scalar(@coList); $i++)
    {
        $ret = WaitForCpComplete( $coList[$i], $newVd );
        if ( $ret != GOOD ) { return ERROR; }
    }

    #
    # re-run parity scan - 2 loops
    #

    CtlrLogTextAll($coPtr, "Test Case 10: Complete parity scan after first copy " );

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }


    CtlrLogTextAll($coPtr, "Test Case 10: Verify IO after first copy. " );

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }



    ##############################
    # Now copy to a R5P5 drive
    ##############################



    # nake a replacement
    $newVd2 =  CreateSimilarVdisk($ctlr, $oldVds[0], RAID_5, 5, 0);
    if ( $newVd2 < 0 ) { return ERROR; }

    # copy it to the replacement
    logInfo("Destination vdisk:");
    ShortVdiskInfo($ctlr, $newVd2);
    

    CtlrLogTextAll($coPtr, "Test Case 10: Begin a redi-copy operation to R5P5. " );

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd2);
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 10: Short pause as the copy begins. " );
    DelaySecs(5);

    # copy has started. 
    
    
    CtlrLogTextAll($coPtr, "Test Case 10: Checking that copies are complete on all controllers. " );

    for ( $i = 0; $i < scalar(@coList); $i++)
    {
        $ret = WaitForCpComplete( $coList[$i], $newVd2 );
        if ( $ret != GOOD ) { return ERROR; }
    }

    #
    # re-run parity scan - 2 loops
    #

    CtlrLogTextAll($coPtr, "Test Case 10: Complete parity scan after second copy " );

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }

    CtlrLogTextAll($coPtr, "Test Case 10: Verify IO after second copy. " );

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    #################################
    # copy back to starting vdisk
    #################################

    CtlrLogTextAll($coPtr, "Test Case 10: Begin a redi-copy operation to starting vdisk. " );

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 10: Short pause as the copy begins. " );
    DelaySecs(5);

    # copy has started. 
    
    
    CtlrLogTextAll($coPtr, "Test Case 10: Checking that copies are complete on all controllers. " );

    for ( $i = 0; $i < scalar(@coList); $i++)
    {
        $ret = WaitForCpComplete( $coList[$i], $newVd );
        if ( $ret != GOOD ) { return ERROR; }
    }


    CtlrLogTextAll($coPtr, "Test Case 10: Verify IO after third copy. " );

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }



    CtlrLogTextAll($coPtr, "Test Case 10: Delete the R5P3 disk. " );
  
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) ) 
    {
        return ERROR;
    }

    CtlrLogTextAll($coPtr, "Test Case 10: Delete the R5P5 disk. " );
  
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd2) ) 
    {
        return ERROR;
    }



    #
    # re-run parity scan - 2 loops
    #

    CtlrLogTextAll($coPtr, "Test Case 10: Complete parity scan at end (should be good).. " );

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test failed.");
        return ERROR;
    }


    # done

    CtlrLogTextAll($coPtr, "End of parity test case 10. " );

    return GOOD;

}

###############################################################################

###############################################################################

=head2 ParityCase09OLD function

This test case repeatedly relabels pdisks. A pdisk is failed and 
rebuilt to stress the system. 
The test has these
basic steps...

 Steps are 1) for 'n' loops
                 re-label each drive with its current type
                 no delay between commands
           2) verify IO
           3) for 'n' loops
                 re-label the same drive, over and over
           4) verify IO
           5) fail a pdisk
           6) wait for rebuild to start
           7) verify IO
           8) for 'n' loops
                 re-label each drive with its current type
           9) for 'n' loops
                 relabel one drive over and over
                 ( drive is not one being rebuilt )
          10) for 'n' loops 
                 re-label all drives with their current type
          11) verify IO
          12) wait for rebuild to end
          13) verify IO
          14) restore the failed pdisk
          15) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase09( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 9, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 59, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase09
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                LIPs the BE loops  
#        
# Steps are 1) for 'n' loops
#                 re-label each drive with its current type
#                 no delay between commands
#           2) verify IO
#           3) for 'n' loops
#                 re-label the same drive, over and over
#           4) verify IO
#           5) fail a pdisk
#           6) wait for rebuild to start
#           7) verify IO
#           8) for 'n' loops
#                 re-label each drive with its current type
#           9) for 'n' loops
#                 relabel one drive over and over
#                 ( drive is not one being rebuilt )
#          10) for 'n' loops 
#                 re-label all drives with their current type
#          11) verify IO
#          12) wait for rebuild to end
#          13) verify IO
#          14) restore the failed pdisk
#          15) verify IO
#
#
##############################################################################
sub ParityCase09OLD
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;


    my @pdds;
    my @allPdds;
    my $i;
    my $j;
    my $type;
    my $ret;
    my %rsp;
    my $lc;
    my $total;
    my $ses;
    my $slot;
    my $lid;
    my $port;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 9: Re-label drives repeatedly, fail a drive.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # loops to relabel drives. 
    ######################################################################

    
    # we are going to re-label these
    @allPdds = GetPddList( $ctlr );
    if ( $allPdds[0] == INVALID) { return ERROR; }

    # we will fail the 2nd one of these
    @pdds = GetDataDisks( $ctlr );
    if ( $pdds[0] == INVALID) { return ERROR; }


    
    logInfo("Begin 1st loop to relabel ".scalar(@allPdds)."  drives $loopCount times.");
    CtlrLogTextAll($coPtr, "Test Case 9: Begin 1st loop to relabel ".scalar(@allPdds)."  drives $loopCount times." );
     
    # loop to relabel all drives without delay
    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");
        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {

            # get the current label
            $type = GetDriveLabel( $ctlr, $allPdds[$i] );
            if ( $type == INVALID )
            {
                return ERROR; 
            }
        
            # re-apply that label to the same drive
            $ret = ReLabelSingleDrive ( $ctlr, $allPdds[$i], $type );
            if ( $ret != GOOD ) { return ERROR; }
        }
    }
    
    logInfo("End loop to relabel ".scalar(@allPdds)." drives $loopCount times.");

    #           4) verify IO
    logInfo("Verify IO after several rescans on among controllers with delay");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # now fail a pdisk
    CtlrLogTextAll($coPtr, "Test Case 9: now failing pdd $pdds[1]" );

    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);


    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }
    
    # the disk is failed, now some rebuilds will soon begin


    
    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # loop to relabel all drives without delay

    $total = scalar(@allPdds) - 1;

    logInfo("Begin 2nd loop to relabel $total drives $loopCount times.");

    CtlrLogTextAll($coPtr, "Test Case 9: Begin 2nd loop to relabel $total drives $loopCount times" );

    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");
        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {
            # probably need to make sure we don't use the dead drive

            if ( $allPdds[$i] !=  $pdds[1] )
            {
                # get the current label
                $type = GetDriveLabel( $ctlr, $allPdds[$i] );
                if ( $type == INVALID )
                {
                    return ERROR; 
                }

                # re-apply that label to the same drive
                $ret = ReLabelSingleDrive ( $ctlr, $allPdds[$i], $type );
                if ( $ret != GOOD ) { return ERROR; }

            }
        }
    }

    logInfo("END loop to relabel $total drives $loopCount times.");


    $total = $loopCount * scalar(@allPdds) ;

    logInfo("Begin 3rd loop to relabel drive $pdds[2] $total times.");
    CtlrLogTextAll($coPtr, "Test Case 9: Begin 3rd loop to relabel drive $pdds[2] $total times" );

    # loop to relabel the same drive without delay
    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");
        # this loop just increases the number of commands sent
        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {

            # get the current label
            $type = GetDriveLabel( $ctlr, $pdds[2] );
            if ( $type == INVALID )
            {
                return ERROR; 
            }
        
            # re-apply that label to the same drive
            $ret = ReLabelSingleDrive ( $ctlr, $pdds[2], $type );
            if ( $ret != GOOD ) { return ERROR; }
        }
    }

    logInfo("End loop to relabel drive $pdds[2] $total times.");

    # make sure IO is still good
    logInfo("Verify IO after several rescans on among controllers with delay");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );
 

    # make sure IO is still good

    CtlrLogTextAll($coPtr, "Test Case 9: Verify IO after rebuild has completed");
    
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # unfail the drive
    CtlrLogTextAll($coPtr, "Test Case 9: Unfailing pdisk $pdds[1]");
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    
    

    # verify IO
    CtlrLogTextAll($coPtr, "Confirm IO after test is done and disk restored.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     
    if ( $ret != GOOD ) { return ERROR; }






    logInfo("End of BE stress test case 9.");


    return GOOD;

}
###############################################################################
###############################################################################
###############################################################################

=head2 ParityCase10OLD function

This test case repeatedly labels drives while running raid inits and
failing a pdisk.
 
The test has these
basic steps...

 Steps are 1) for 'n' loops
                 re-label each drive with its current type
                 no delay between commands
           2) verify IO
           3) create some vdisks
           4) start raid inits on them
           1) for 'n' loops
                 re-label each drive with its current type
                 no delay between commands
           4) verify IO
           3) for 'n' loops
                 re-label the same drive, over and over
           4) verify IO
           5) fail a pdisk
           6) wait for rebuild to start
           7) verify IO
           8) for 'n' loops
                 re-label each drive with its current type
           9) for 'n' loops
                 relabel one drive over and over
                 ( drive is not one being rebuilt )
          10) for 'n' loops 
                 re-label all drives with their current type
          11) verify IO
          12) wait for rebuild to end
          13) verify IO
          14) restore the failed pdisk
          15) verify IO





=cut

=over 1

=item Usage:

 my $rc = ParityCase10OLD( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 10, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 60, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase10 OLD
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                Relabel drives while doing inits  
#        
# Steps are 1) for 'n' loops
#                 re-label each drive with its current type
#                 no delay between commands
#           2) verify IO
#           3) create some vdisks
#           4) start raid inits on them
#           1) for 'n' loops
#                 re-label each drive with its current type
#                 no delay between commands
#           4) verify IO
#           3) for 'n' loops
#                 re-label the same drive, over and over
#           4) verify IO
#           5) fail a pdisk
#           6) wait for rebuild to start
#           7) verify IO
#           8) for 'n' loops
#                 re-label each drive with its current type
#           9) for 'n' loops
#                 relabel one drive over and over
#                 ( drive is not one being rebuilt )
#          10) for 'n' loops 
#                 re-label all drives with their current type
#          11) verify IO
#          12) wait for rebuild to end
#          13) verify IO
#          14) restore the failed pdisk
#          15) verify IO
#
##############################################################################
sub ParityCase10OLD
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @pdds;
    my @allPdds;
    my $i;
    my $j;
    my $type;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my $lc;
    my %rsp;
    my $total;
    my $ses;
    my $slot;
    my $lid;
    my $port;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 10: Re-label pdisks while doing init and fail pdisk.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # loops to label drives 
    ######################################################################

    
    # we are going to re-label these
    @allPdds = GetPddList( $ctlr );
    if ( $allPdds[0] == INVALID) { return ERROR; }

    # we will fail the 2nd one of these
    @pdds = GetDataDisks( $ctlr );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # loop to relabel all drives without delay

    $total = $loopCount * scalar(@allPdds);
    logInfo("Begin loop to relabel all drives $total times.");
    CtlrLogTextAll($coPtr,"Test Case 10: Begin loop to relabel all drives $total times."); 

    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");
        
        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {

            # get the current label
            $type = GetDriveLabel( $ctlr, $allPdds[$i] );
            if ( $type == INVALID )
            {
                return ERROR; 
            }
        
            # re-apply that label to the same drive
            $ret = ReLabelSingleDrive ( $ctlr, $allPdds[$i], $type );
            if ( $ret != GOOD ) { return ERROR; }
        }
    }
    logInfo("End loop to relabel all drives $total times.");

    #           4) verify IO
    logInfo("Verify IO after several relabels");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # create some vdisks
 
    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)
    CtlrLogTextAll($coPtr,"Test Case 10: Creating new vdisks "); 

    $ret = MakeVdisks($ctlr, 14, NO_RAID_INIT );  # option 14 is 2 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
        return (ERROR);
    }

    # start inits on new vdisks
    logInfo("      Starting raids inits.");
    CtlrLogTextAll($coPtr,"Test Case 10:       Starting raids inits."); 

    $ret = InitNewerVdisks( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }
    

    # loop to relabel all drives without delay
    $total = $loopCount * scalar(@allPdds);
    logInfo("Begin loop to relabel all drives $total times.");
    CtlrLogTextAll($coPtr,"Test Case 10: Begin loop to label drives during init."); 

    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");
        
        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {

            # get the current label
            $type = GetDriveLabel( $ctlr, $allPdds[$i] );
            if ( $type == INVALID )
            {
                return ERROR; 
            }
        
            # re-apply that label to the same drive
            $ret = ReLabelSingleDrive ( $ctlr, $allPdds[$i], $type );
            if ( $ret != GOOD ) { return ERROR; }
        }
    }
    logInfo("End loop to relabel all drives $total times.");

    #           4) verify IO
    logInfo("Verify IO after relabeling all drives while init runs.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # wait for the inits

    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }


# # has init finished? if not, rebuild will fail
#
#    $ret = INVALID;
#
#    $lc = 0; 
#    while ( $ret != GOOD )
#    {
#        $lc++;
#        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));
#                                                                                                      # should this be an inti check?
#        $ret = DegradeCheck( $ctlr );
#        if ( $ret == ERROR )
#        {
#            return ERROR;
#        }
#        DelaySecs( 15 );
#    }


    PSDCheck( $ctlr );
 


    # now fail a pdisk
    CtlrLogTextAll($coPtr, "Test Case 10: now failing pdd $pdds[1]" );

    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);


    $ret = FailPdisk( $coPtr, $pdds[1], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }
    
    # the disk is failed, now some rebuilds will soon begin

    DelaySecs(60);
    
    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # loop to relabel all drives without delay

    $total = $loopCount * (scalar(@allPdds) - 1);
    logInfo("Begin loop to relabel most drives $total times during rebuild.");
    CtlrLogTextAll($coPtr, "Test Case 10: Begin loop to relabel most drives $total times during rebuild." );

    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");

        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {
            # probably need to make sure we don't use the dead drive

            if ( $allPdds[$i] !=  $pdds[1] )
            {
                # get the current label
                $type = GetDriveLabel( $ctlr, $allPdds[$i] );
                if ( $type == INVALID )
                {
                    return ERROR; 
                }

                # re-apply that label to the same drive
                $ret = ReLabelSingleDrive ( $ctlr, $allPdds[$i], $type );
                if ( $ret != GOOD ) { return ERROR; }

            }
        }
    }

    logInfo("End loop to relabel most drives $total times.");

    # let the rebuild finish
    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 

    # loop to relabel the same drive without delay
    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j of $loopCount             \r");

        # this loop just increases the number of commands sent
        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {

            # get the current label
            $type = GetDriveLabel( $ctlr, $pdds[2] );
            if ( $type == INVALID )
            {
                return ERROR; 
            }
        
            # re-apply that label to the same drive
            $ret = ReLabelSingleDrive ( $ctlr, $pdds[2], $type );
            if ( $ret != GOOD ) { return ERROR; }
        }
    }

    # make sure IO is still good
    logInfo("Verify IO after several relabels with rebuild running");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    

    # wait for the inits to end ( they are probably done by now )

    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }


    # make sure IO is still good
    logInfo("Verify IO once rebuilds have completed");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    
    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    

    # verify IO
    logInfo("Confirm IO after test is done and disk restored.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     
    if ( $ret != GOOD ) { return ERROR; }







    logInfo("End of BE stress test case 10.");


    return GOOD;

}

###############################################################################

=head2 ParityCase11 function

This test case reads the quorum FIDs repeatedly. 
The test has these
basic steps...


 Steps are 1) read the fid directory
           2) read each fid in the directory
           3) repeat 2) 'n' times
           4) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase11( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase11
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                LIPs the BE loops  
#        
# Steps are 1) read the fid directory
#           2) read each fid in the directory
#           3) repeat 2) 'n' times
#           4) verify IO
#
##############################################################################
sub ParityCase11
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $i;
    my $j;
    my %data;
    my $ret;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 11: FID reads.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    #  FID reads. 
    ######################################################################

    # FID directory

    #### 00000000  44 69 72 65 63 74 6F 72  79 20 09 00 00 00 00 00  Directory ......
    #### 00000010  58 49 4F 20 4C 61 62 65  6C 20 02 00 09 00 00 00  XIO Label ......
    #### 00000020  42 45 20 4E 56 52 41 4D  20 20 81 0B 0B 00 00 00  BE NVRAM  ......
    #### 00000030  46 45 20 4E 56 52 41 4D  20 20 81 0B 8C 0B 00 00  FE NVRAM  ......
    #### 00000040  45 4D 43 20 4E 56 52 41  4D 20 81 0B 0D 17 00 00  EMC NVRAM ......
    #### 00000050  53 54 20 53 63 72 61 74  63 68 01 01 8E 22 00 00  ST Scratch..."..
    #### 00000060  4D 41 53 54 45 52 5F 43  4F 4E 09 00 8F 23 00 00  MASTER_CON...#..
    #### 00000070  43 4F 4E 54 52 4C 5F 4D  41 50 19 00 98 23 00 00  CONTRL_MAP...#..
    #### 00000080  43 4F 4D 4D 5F 41 52 45  41 20 01 04 B1 23 00 00  COMM_AREA ...#..
    #### 00000090  4E 4D 5F 50 44 49 53 4B  20 20 01 02 B2 27 00 00  NM_PDISK  ...'..
    #### 000000A0  4E 4D 5F 56 44 49 53 4B  20 20 01 02 B3 29 00 00  NM_VDISK  ...)..
    #### 000000B0  4E 4D 5F 53 45 52 56 45  52 20 01 01 B4 2B 00 00  NM_SERVER ...+..
    #### 000000C0  4E 4D 5F 56 4C 49 4E 4B  5F 43 21 00 B5 2C 00 00  NM_VLINK_C!..,..
    #### 000000D0  4E 4D 5F 43 4F 4E 54 52  4F 4C 09 00 D6 2C 00 00  NM_CONTROL...,..
    #### 000000E0  4E 4D 5F 54 41 52 47 45  54 20 81 00 DF 2C 00 00  NM_TARGET ...,..
    #### 000000F0  4E 4D 5F 45 4E 43 4C 4F  53 55 41 00 60 2D 00 00  NM_ENCLOSUA.`-..
    #### 00000100  4E 4D 5F 4D 49 53 43 44  45 56 21 00 A1 2D 00 00  NM_MISCDEV!..-..
    #### 00000110  4E 4D 5F 56 43 47 20 20  20 20 02 00 C2 2D 00 00  NM_VCG    ...-..
    #### 00000120  4E 4D 5F 56 4C 49 4E 4B  5F 56 21 00 C4 2D 00 00  NM_VLINK_V!..-..
    #### 00000130  52 4D 5F 43 4F 4E 46 49  47 31 41 00 E5 2D 00 00  RM_CONFIG1A..-..
    #### 00000140  52 4D 5F 43 4F 4E 46 49  47 32 41 00 26 2E 00 00  RM_CONFIG2A.&...
    #### 00000150  52 4D 5F 4C 4F 47 5F 31  20 20 81 00 67 2E 00 00  RM_LOG_1  ..g...
    #### 00000160  52 4D 5F 4C 4F 47 5F 32  20 20 81 00 E8 2E 00 00  RM_LOG_2  ......
    #### 00000170  43 4B 50 5F 44 49 52 45  43 54 81 00 69 2F 00 00  CKP_DIRECT..i/..
    #### 00000180  43 4B 50 5F 4D 43 4E 46  30 30 09 00 EA 2F 00 00  CKP_MCNF00.../..

    my @safeFids = (0,1,2,3,4,5,6,7);
    for ( $j = 0; $j < $loopCount; $j++ )
    {
        
        foreach $i (@safeFids)
        #for ($i = 0; $i < 23; $i++ )
        {
            if ( $i == 8 ) { next; }        # skip FID 8 

            print "reading FID $i \n";
            
            %data = $ctlr->ReadFID($i);
            if ( ! %data  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from ReadFID <<<<<<<<");
                return ERROR;
            }
            if ( $data{STATUS} != PI_GOOD )      # if call returned an error
            {
                # probably need to handle the expected bad CRC on FID 23
            
                logInfo(">>>>>>>> Error from ReadFID <<<<<<<<");
                PrintError(%data);
                return ERROR;
            }
        }

    }

    #           4) verify IO
    logInfo("Verify IO after reading FIDs");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 11.");


    return GOOD;

}

###############################################################################

=head2 ParityCase12 function

This test case send loop primitives to the BE qlogic cards. 
The test has these
basic steps...
     1) determine valid loop primitives
     2) select a controller
     3) issue each of the loop primitives, randomly select the
        QL card that is used ( do this 'n' times)
     4) verify IO
     5) repeat 2-4 for the other controller(s)


=cut

=over 1

=item Usage:

 my $rc = ParityCase12( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase12
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCountv 
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                loop primitives to the BE loops  
#        
# Steps are 1) determine valid loop primitives
#           2) select a controller
#           3) issue each of the loop primitives, randomly select the
#              QL card that is used ( do this 'n' times)
#           4) verify IO
#           5) repeat 2-4 for the other controller(s)
#
##############################################################################
sub ParityCase12
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $i;
    my $j;
    my $k;
    my $ret;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 12: Send loop primitives (just LIP) to the BE Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # loops to LIP the BE cards. 
    ######################################################################

    # Steps are 1) select the controller
    for ( $i = 0; $i < scalar(@$coPtr); $i++ )
    {

        $ctlr = $coList[$i];

        #           2) for 'n' loops
        for ( $j = 0; $j < $loopCount; $j++ )
        {
            
            #   sequentially LIP each QL card
            for ( $k = 0; $k < 4; $k++ )
            {
 
                $ret = ResetBELoop ($ctlr, $k );
                if ( $ret == ERROR ) 
                { 
                    print ("\n");
                    logInfo("Error from ResetBELoop.");
                    return ERROR; 
                }
                
               
                # wait 10 secs between LIPs
                if ( $ret != INVALID )
                {
                    DelaySecs(15);
                }
            }

        }
        
        #  3) verify IO is still good
        
        logInfo("Verify IO after $loopCount loops sequentially LIPping the BE QLogic cards");
        $ret = VerifyIO( $coPtr,
                         \@activeServers, 
                         \@tMap, 
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

    }


#add code here
#           option      - loop primitive option
#                           LP_RESET_LOOP           0x0000
#                           LP_RESET_LID_PORT       0x0001
#                           LP_SID_PID_RESET        0x0002
#                           LP_LOGIN_LID            0x0011
#                           LP_LOGIN_PID            0x0012
#                           LP_LOGOUT_LID           0x0021
#                           LP_LOGOUT_PID           0x0022
#                           LP_TARGET_RESET_LID     0x0031
#                           LP_TARGET_RESET_PID     0x0032
#                           LP_PORT_BYPASS_LID      0x0041
#                           LP_PORT_BYPASS_PID      0x0042
#                           LP_PORT_ENABLE_LID      0x0043
#                           LP_PORT_ENABLE_PID      0x0044
#                           LP_PORT_BYPASS_TEST_LID 0x00F1
#                           LP_PORT_BYPASS_TEST_PID 0x00F2


    logInfo("End of BE stress test case 12.");


    return GOOD;

}


###############################################################################

=head2 ParityCase13 function

This test case fails a pdisk during a scrub. 
The test has these
basic steps...

     1) verify IO
     2) enable/start scrubbing
     3) fail a pdisk
     4) verify IO
     5) check scrubbing state
     6) wait for rebuild to end
     7) verify IO
     8) check scrub state/ re-enable if needed
     9) wait for one pass to complete
    10) verify IO
    11) stop scrubbing
    12) restore the failed pdisk
    13) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase13( $coPtr, $retIn, $snPtr, $pDFailMeans  );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 13, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 63, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase13
#
#        Inputs: $coPtr, $retIn, $snPtr, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                LIPs the BE loops  
#        
# Steps are 1) verify IO
#           2) enable/start scrubbing
#           3) fail a pdisk
#           4) verify IO
#           5) check scrubbing state
#           6) wait for rebuild to end
#           7) verify IO
#           8) check scrub state/ re-enable if needed
#           9) wait for one pass to complete
#          10) verify IO
#          11) stop scrubbing
#          12) restore the failed pdisk
#          13) verify IO
#
##############################################################################
sub ParityCase13
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @pdds;
    my $ret;
    my %rsp;
    my $lc;
    my $ses;
    my $slot;
    my $lid;
    my $port;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 13: Fail a pdisk during a scrub.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # loops to LIP the BE cards. 
    ######################################################################

    @pdds = GetDataDisks( $ctlr );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # Steps are 1) verify IO
    
    logInfo("Verify IO at start of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           2) enable/start scrubbing

    $ret = ScrubSet("ENABLE", "DISABLE", 0, $coPtr);

    if ( $ret != GOOD ) { return ERROR; }




    #           3) fail a pdisk
    CtlrLogTextAll($coPtr, "Test Case 13: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }
    
    # the disk is failed, now some rebuilds will soon begin


    #           4) verify IO
    
    logInfo("Verify IO after failing a pdisk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           5) check scrubbing state

    %rsp = $ctlr->scrubInfo();

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo(sprintf("  Classic Scrubbing: %s", $rsp{SCRUBBING}));
        }
        else
        {
            logInfo("Unable to retrieve the scrubbing information.");
            PrintError( %rsp);
            return ERROR;
        }
    }
    else
    {
        logInfo("ERROR: Did not receive a response packet from Scrub Info.");
        return ERROR;
    }





    #           6) wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 
    #           7) verify IO
    
    logInfo("Verify IO after rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           8) check scrub state/ re-enable if needed

    $ret = ScrubSet("ENABLE", "DISABLE", 0, $coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    #           9) wait for one pass to complete

    logInfo("20 minute delay to allow scrubbing to run for a while");
    DelaySecs(1200);


    #          10) verify IO
    
    logInfo("Verify IO after scrub running for a while");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #          11) stop scrubbing

    #          12) restore the failed pdisk

    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    

    # disable scrubbing
    $ret = ScrubSet("DISABLE", "DISABLE", 0, $coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    #          13) verify IO
    
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }



    logInfo("End of BE stress test case 13.");


    return GOOD;

}

###############################################################################

=head2 ParityCase14 function

This test case fails a pdisk during an election. 
The test has these
basic steps...

    1) Wait until all disks are operational
    2) Do 10 elections, back to back
    3) Start Election, Fail the pdisk  ( a data one )
    4) Do more elections, repeat until 200 are done, or
       the rebuild has finished
    5) If needed wait for the rebuild to finish.
    6) Do 10 more elections
    7) Verify IO
    8) Restore the disk to operation
    9) Do 50 more elections
   10) Verify IO





=cut

=over 1

=item Usage:

 my $rc = ParityCase14( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 14, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 64, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase14
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans 
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                LIPs the BE loops  
#        
# Steps:
#    1) Wait until all disks are operational
#    2) Do 10 elections, back to back
#    3) Start Election, Fail the pdisk  ( a data one )
#    4) Do more elections, repeat until 200 are done, or
#       the rebuild has finished
#    5) If needed wait for the rebuild to finish.
#    6) Do 10 more elections
#    7) Verify IO
#    8) Restore the disk to operation
#    9) Do 50 more elections
#   10) Verify IO
#
##############################################################################
sub ParityCase14
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlrS;

    my $lc;
    my $ret;
    my @pdds;
    my %rsp;
    my $elStateM;
    my $ses;
    my $slot;
    my $lid;
    my $port;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 14: Fail a pdisk during an election.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    # pick a slave controller
    if ($master == 0)
    {
        $ctlrS = $coList[1];
    }
    else
    {
        $ctlrS = $coList[0];
    }


    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # begin elections test 
    ######################################################################

    @pdds = GetDataDisks( $ctlr );
    if ( $pdds[0] == INVALID) { return ERROR; }


    #    1) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 

    #    2) Do 10 elections, back to back

    $ret = ElectionsTest($ctlr, $ctlrS, 10);
    if ( $ret != GOOD ) { return ERROR; }



    #    3) Start Election, Fail the pdisk  ( a data one )


    %rsp = $ctlr->genericCommand("ELECTION", 0 );

    # see how the start of the election went

    if (!%rsp)                        # no response
    {
        logInfo(">>>>>>>> Failed to receive a response from ELECTION start <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} == 1)            # 1 is bad
    {
        logInfo(">>>>>>>> Failed: starting an election returned an error <<<<<<<<");
        PrintError(%rsp);
        logError("Failure in BEStress test");
        return ERROR;
    }




    CtlrLogTextAll($coPtr, "Test Case 14: now failing pdd $pdds[1] during an election" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }
    
    # the disk is failed, now some rebuilds will soon begin

    # let's wait until this lecetion ends

    $elStateM = 0;

    # loop getting state and printing changes until election finishes
    while ( $elStateM != 0 )
    {
        ##
        # get the master's election state
        ##
        %rsp = $ctlr->vcgElectionState();

        # see how getting the master's status went
        if (!%rsp)                        # no response
        {
            logInfo(">>>>>>>> Failed to receive a response from ELECTION status <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} == 1)            # 1 is bad
        {
            logInfo(">>>>>>>> Failed: getting election status returned an error <<<<<<<<");
            PrintError(%rsp);
            logInfo("Failure in elections test");
            return ERROR;
        }

    }

    #    4) Do more elections, repeat until 200 are done, or
    #       the rebuild has finished

    $ret = ElectionsTest($ctlr, $ctlrS, 100);
    if ( $ret != GOOD ) { return ERROR; }



    #    5) If needed wait for the rebuild to finish.
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 


    #    6) Do 10 more elections

    $ret = ElectionsTest($ctlr, $ctlrS, 10);
    if ( $ret != GOOD ) { return ERROR; }


    #    7) Verify IO
    logInfo("Verify IO after the rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #    8) Restore the disk to operation
    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    
    #    9) Do 50 more elections


    $ret = ElectionsTest($ctlr, $ctlrS, 50);
    if ( $ret != GOOD ) { return ERROR; }



    #   10) Verify IO
    
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }




    logInfo("End of BE stress test case 14.");


    return GOOD;

}
###############################################################################

###############################################################################

=head2 ParityCase14 function

This test case fails a pdisk during an election. 
The test has these
basic steps...

    1) Wait until all disks are operational
    2) Do 10 elections, back to back
    3) Start Election, Fail the pdisk  ( a hotspare one )
    4) Do more elections, repeat until 200 are done, or
       the rebuild has finished
    5) If needed wait for the rebuild to finish.
    6) Do 10 more elections
    7) Verify IO
    8) Restore the disk to operation
    9) Do 50 more elections
   10) Verify IO





=cut

=over 1

=item Usage:

 my $rc = ParityCase15( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 15, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 65, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase15
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                Fail a hotspare drive during an election  
#        
# Steps:
#    1) Wait until all disks are operational
#    2) Do 10 elections, back to back
#    3) Start Election, Fail the pdisk  ( a hotspare one )
#    4) Do more elections, repeat until 200 are done, or
#       the rebuild has finished
#    5) If needed wait for the rebuild to finish.
#    6) Do 10 more elections
#    7) Verify IO
#    8) Restore the disk to operation
#    9) Do 50 more elections
#   10) Verify IO
#
##############################################################################
sub ParityCase15
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlrS;

    my @pdds;
    my %rsp;
    my $ret;
    my $lc;
    my $elStateM;
    my $ses;
    my $slot;
    my $lid;
    my $port;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 15: Fail a pdisk(HOTSPARE) during an election.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    # pick a slave controller
    if ($master == 0)
    {
        $ctlrS = $coList[1];
    }
    else
    {
        $ctlrS = $coList[0];
    }


    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # begin elections test 
    ######################################################################

    @pdds = GetTheseDisks( $ctlr, CCBEHOTSPARETYPE );
    if ( $pdds[0] == INVALID) { return ERROR; }


    #    1) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 

    #    2) Do 10 elections, back to back

    $ret = ElectionsTest($ctlr, $ctlrS, 10);
    if ( $ret != GOOD ) { return ERROR; }



    #    3) Start Election, Fail the pdisk  ( a data one )


    %rsp = $ctlr->genericCommand("ELECTION", 0);

    # see how the start of the election went

    if (!%rsp)                        # no response
    {
        logInfo(">>>>>>>> Failed to receive a response from ELECTION start <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} == 1)            # 1 is bad
    {
        logInfo(">>>>>>>> Failed: starting an election returned an error <<<<<<<<");
        PrintError(%rsp);
        logError("Failure in BEStress test");
        return ERROR;
    }




    CtlrLogTextAll($coPtr, "Test Case 15: now failing pdd $pdds[1] during an election" );


    GetSesAndSlot ($ctlr, $pdds[0], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[0], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }
    
    # the disk is failed, now some rebuilds will soon begin

    # let's wait until this lecetion ends

    $elStateM = 0;

    # loop getting state and printing changes until election finishes
    while ( $elStateM != 0 )
    {
        ##
        # get the master's election state
        ##
        %rsp = $ctlr->vcgElectionState();

        # see how getting the master's status went
        if (!%rsp)                        # no response
        {
            logInfo(">>>>>>>> Failed to receive a response from ELECTION status <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} == 1)            # 1 is bad
        {
            logInfo(">>>>>>>> Failed: getting election status returned an error <<<<<<<<");
            PrintError(%rsp);
            logInfo("Failure in elections test");
            return ERROR;
        }

    }

    #    4) Do more elections, repeat until 200 are done, or
    #       the rebuild has finished

    $ret = ElectionsTest($ctlr, $ctlrS, 100);
    if ( $ret != GOOD ) { return ERROR; }



    #    5) If needed wait for the rebuild to finish.
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 


    #    6) Do 10 more elections

    $ret = ElectionsTest($ctlr, $ctlrS, 10);
    if ( $ret != GOOD ) { return ERROR; }


    #    7) Verify IO
    logInfo("Verify IO after the rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #    8) Restore the disk to operation
    # unfail the drive
    $master = FindMaster( $coPtr );
    $ctlr = $coList[$master];

    $ret = UnfailPdisk($coPtr, $pdds[0], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    

    #    9) Do 50 more elections


    $ret = ElectionsTest($ctlr, $ctlrS, 50);
    if ( $ret != GOOD ) { return ERROR; }



    #   10) Verify IO
    
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }




    logInfo("End of BE stress test case 15.");


    return GOOD;

}

###############################################################################

=head2 ParityCase17 function

This test case does elections while an init is running. 
The test has these
basic steps...

     1) Wait until all disks are operational
     2) Create and init a vdisk
     3) Do 200 elections or until init finished
     4) If necessary, wait for the init to finish.
     5) Verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase17( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase17
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                Elections during raid init  
#        
# Steps:
#    1) Wait until all disks are operational
#    2) Create and init a vdisk
#    3) Do 200 elections or until init finished
#    4) If necessary, wait for the init to finish.
#    5) Verify IO
#
##############################################################################
sub ParityCase17
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlrS;

    my $ret;
    my $numVDDs;
    my $lc;
    my @vdisks;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 17: Elections during a single raid init.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    # pick a slave controller
    if ($master == 0)
    {
        $ctlrS = $coList[1];
    }
    else
    {
        $ctlrS = $coList[0];
    }


    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # Elections during a single raid init. 
    ######################################################################


    #    1) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until drives are operational");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 

    #    2) Create and init a vdisk

    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)
    $ret = MakeVdisks($ctlr, 14, NO_RAID_INIT );  # option 14 is 2 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
        return (ERROR);
    }
     
    # start inits on new vdisks
    logInfo("      Starting raids inits, this will stop the defrags");
    $ret = InitNewerVdisks( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }
    

    #    3) Do 200 elections or until init finished
    $ret = ElectionsTest($ctlr, $ctlrS, 10);
    if ( $ret != GOOD ) { return ERROR; }


    #    4) If necessary, wait for the init to finish.
    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }



    #    5) Verify IO
    
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }



    logInfo("End of BE stress test case 17.");


    return GOOD;

}
###############################################################################


###############################################################################

=head2 ParityCase19 function

This test case fails a pdisk while doing an init on a single raid drive. 
The test has these
basic steps...
     1) Create a vdisk (single Raid)
     2) Start the raid init
     3) verify IO
     4) fail a pdisk (rebuild will start)
     5) wait for rebuilds to finish
     6) verify IO
     7) wait for init to finish
     8) verify IO
     9) delete the new vdisk
    10) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase19( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 19, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 69, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase19
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                Fail a pdisk while initializong a single raid vdisk  
#        
# Steps are 1) Create a vdisk (single Raid)
#           2) Start the raid init
#           3) verify IO
#           4) fail a pdisk (rebuild will start)
#           5) wait for rebuilds to finish
#           6) verify IO
#           7) wait for init to finish
#           8) verify IO
#           9) delete the new vdisk
#          10) verify IO
#
##############################################################################
sub ParityCase19
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $lc;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my @pdds;
    my %rsp;
    my $ses;
    my $slot;
    my $lid;
    my $port;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 19: Fail a pdisk during init of a single raid vdisk.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # create vdisk, init, then fail a pdisk
    ######################################################################

    #    0) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until drives are operational");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 
    # Steps are 1) Create a vdisk (single Raid)
    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)
    $ret = MakeVdisks($ctlr, 14, NO_RAID_INIT );  # option 14 is 2 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
        return (ERROR);
    }
     
    #           2) Start the raid init
    # start inits on new vdisks
    logInfo("      Starting raids inits, this will stop the defrags");
    $ret = InitNewerVdisks( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }


    #           3) verify IO
    logInfo("Verify IO after starting the raid init");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           4) fail a pdisk (rebuild will start)

    # now fail the pdisk

    @pdds = GetDataDisks( $ctlr );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 19: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }
    
    # the disk is failed, now some rebuilds will soon begin





    #           5) wait for rebuilds to finish
    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 

    #           6) verify IO
    logInfo("Verify IO after rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           7) wait for init to finish
    # wait for the inits to end ( they are probably done by now )

    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }



    #           8) verify IO
    logInfo("Verify IO at end of the init");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           9) delete the new vdisk
    # get rid of any unused vdisks
    $ret = DeleteUnusedVdisks( $ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    # restore the failed pdisk
    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    
    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    


    #          10) verify IO
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 19.");


    return GOOD;

}
###############################################################################


###############################################################################

=head2 ParityCase20 function

This test case fails a pdisk while doing an init on a multiple raid drive. 
The test has these
basic steps...
     1) Create a vdisk (single Raid)
     2) Start the raid init
     3) verify IO
     4) fail a pdisk (rebuild will start)
     5) wait for rebuilds to finish
     6) verify IO
     7) wait for init to finish
     8) verify IO
     9) delete the new vdisk
    10) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase20( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 20, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 70, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase20
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                Fail a pdisk while initializong a multiple raid vdisk  
#        
# Steps are 1) Create a vdisk (multiple Raid)
#           2) Start the raid init
#           3) verify IO
#           4) fail a pdisk (rebuild will start)
#           5) wait for rebuilds to finish
#           6) verify IO
#           7) wait for init to finish
#           8) verify IO
#           9) delete the new vdisk
#          10) verify IO
#
##############################################################################
sub ParityCase20
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $lc;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my @pdds;
    my %rsp;
    my $ses;
    my $slot;
    my $lid;
    my $port;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 20: Fail a pdisk during init of a multiple raid vdisk.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # create vdisk, init, then fail a pdisk
    ######################################################################

    #    0) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until drives are operational");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 
    # Steps are 1) Create a vdisk (single Raid)
    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)


    $ret = CreateMultiRaidVdisk($ctlr, 2000, RAID_10);
    if ( $ret != GOOD ) { return ERROR; }

    
    #           2) Start the raid init
    # start inits on new vdisks
    logInfo("      Starting raids inits, this will stop the defrags");
    $ret = InitNewerVdisks( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }


    #           3) verify IO
    logInfo("Verify IO after starting the raid init");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           4) fail a pdisk (rebuild will start)

    # now fail the pdisk

    @pdds = GetDataDisks( $ctlr );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 20: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }
    
    # the disk is failed, now some rebuilds will soon begin





    #           5) wait for rebuilds to finish
    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );
 

    #           6) verify IO
    logInfo("Verify IO after rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           7) wait for init to finish
    # wait for the inits to end ( they are probably done by now )

    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }



    #           8) verify IO
    logInfo("Verify IO at end of the init");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           9) delete the new vdisk
    # get rid of any unused vdisks
    $ret = DeleteUnusedVdisks( $ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    # restore the failed pdisk
    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    
    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    


    #          10) verify IO
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 20.");


    return GOOD;

}


###############################################################################

=head2 ParityCase21 function

This test case repeatedly powercycles a slave controller. 
The test has these
basic steps...
    
     1) Locate a slave controller
     2) verify IO
     3) turn off the controller
     4) failover timeline from master
     5) verify IO
     6) for 'n' loops
           turn on slave controller
           wait 2 minute (timeline?)
           verify IO
           turn off controller
           wait 2 minutes (timeline?)
           verify IO
     7) turn on controller
     8) reconnect and unfail
     9) timeline for 2 minutes
    10) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase21( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase21
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                Many power cycles on a slave controller.  
#        
# Steps are 1) Locate a slave controller
#           2) verify IO
#           3) turn off the controller
#           4) failover timeline from master
#           5) verify IO
#           6) for 'n' loops
#                 turn on slave controller
#                 wait 2 minute (timeline?)
#                 verify IO
#                 turn off controller
#                 wait 2 minutes (timeline?)
#                 verify IO
#           7) turn on controller
#           8) reconnect and unfail
#           9) timeline for 2 minutes
#          10) verify IO
#
##############################################################################
sub ParityCase21
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $slave;
    my $ret;
    my $i;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 21: Repeatedly power cycle a slave controller.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # power cycles on the slave controller. 
    ######################################################################

    # Steps are 1) Locate a slave controller
    $slave = 1;
    if ( $master == 1 ) { $slave = 0; }


    #           2) verify IO
    logInfo("Verify IO at the beginning of the test");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           3) turn off the controller

    CtlrLogTextAll($coPtr, "Test Case 21: now turning off $$coPtr[$slave]->{HOST}" );
    $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 0);
    if ( $ret != GOOD ) { return ERROR; }


    #           4) failover timeline from master

    $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
    if ( $ret != GOOD ) { return ERROR; }


    #           5) verify IO
    logInfo("Verify IO after failing the slave controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           6) for 'n' loops
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        #                 turn on slave controller
        CtlrLogText($$coPtr[$master], "Test Case 21: now turning on $$coPtr[$slave]->{HOST}" );
        $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 1);
        if ( $ret != GOOD ) { return ERROR; }

        #                 wait 2 minute (timeline?)
        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        #                 verify IO
        logInfo("Verify IO with slave turned on. Loop $i");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers, 
                         0, 
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #                 turn off controller
        CtlrLogText($$coPtr[$master], "Test Case 21: now turning off $$coPtr[$slave]->{HOST}" );
        $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 0);
        if ( $ret != GOOD ) { return ERROR; }



        #                 wait 2 minutes (timeline?)
        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        #                 verify IO
        logInfo("Verify IO with slave turned off. Loop $i");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers, 
                         0, 
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }
    }

    #           7) turn on controller
    CtlrLogText($$coPtr[$master], "Test Case 21: now turning on $$coPtr[$slave]->{HOST}" );
    $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 1);
    if ( $ret != GOOD ) { return ERROR; }

    #           8) reconnect and unfail
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    #           9) timeline for 2 minutes (delay in above fcn)
    #          10) verify IO

    
    logInfo("Verify IO at end of the test, after restoring the controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 21.");


    return GOOD;

}
###############################################################################

###############################################################################

=head2 ParityCase22 function

This test case repeatedly powercycles a slave controller during a rebuild. 
The test has these
basic steps...
    
     1) Locate a slave controller
     2) verify IO
     3) select a pdisk
     4) fail the pdisk
     5) confirm rebuild start
     3) turn off the slave controller
     4) failover timeline from master
     5) verify IO
     6) for 'n' loops
           turn on slave controller
           wait 2 minute (timeline?)
           verify IO
           turn off controller
           wait 2 minutes (timeline?)
           verify IO
     7) turn on controller
     8) reconnect and unfail
     9) timeline for 2 minutes
    10) verify IO
    11) wait for/verify rebuild is complete
    12) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase22( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 22, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 72, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase22
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                Many power cycles on a slave controller.  
#        
# Steps are 1) Locate a slave controller
#           2) verify IO
#           3) select a pdisk
#           4) fail the pdisk
#           5) confirm rebuild start
#           6) turn off the slave controller
#           7) failover timeline from master
#           8) verify IO
#           9) for 'n' loops
#                 turn on slave controller
#                 wait 2 minute (timeline?)
#                 verify IO
#                 turn off controller
#                 wait 2 minutes (timeline?)
#                 verify IO
#          10) turn on controller
#          11) reconnect and unfail
#          12) timeline for 2 minutes
#          13) verify IO
#          14) wait for/verify rebuild is complete
#          15) verify IO
#
##############################################################################
sub ParityCase22
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ses;
    my $slot;
    my $lid;
    my $port;


    my $slave;
    my $ret;
    my $i;
    my $lc;
    my %rsp;
    my @pdds;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 22: Repeatedly power cycle a controller during rebuild.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # power cycles on the slave controller, during a rebuild
    ######################################################################




    # Steps are 1) Locate a slave controller
    $slave = 1;
    if ( $master == 1 ) { $slave = 0; }


    #           2) verify IO
    logInfo("Verify IO at the beginning of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           3) select a pdisk
    # we will fail the 2nd one of these
    @pdds = GetDataDisks( $ctlr );
    if ( $pdds[0] == INVALID) { return ERROR; }

    #           4) fail the pdisk
    CtlrLogTextAll($coPtr, "Test Case 22: now failing pdd $pdds[1]" );

    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    #           5) confirm rebuild start
    $ret = DegradeCheck( $ctlr );
    logInfo("Degrade check returned $ret.");

    #           6) turn off the controller

    CtlrLogText($$coPtr[$master], "Test Case 22: now turning off $$coPtr[$slave]->{HOST}" );
    $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 0);
    if ( $ret != GOOD ) { return ERROR; }


    #           7) failover timeline from master

    $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
    if ( $ret != GOOD ) { return ERROR; }


    #           8) verify IO
    logInfo("Verify IO after failing the slave controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers, 
                     0, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           9) for 'n' loops
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        #                 turn on slave controller
        CtlrLogText($$coPtr[$master], "Test Case 22: now turning on $$coPtr[$slave]->{HOST}" );
        $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 1);
        if ( $ret != GOOD ) { return ERROR; }

        #                 wait 2 minute (timeline?)
        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        #                 verify IO
        logInfo("Verify IO with slave turned on. Loop $i");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers, 
                         0, 
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #                 turn off controller
        CtlrLogText($$coPtr[$master], "Test Case 22: now turning off $$coPtr[$slave]->{HOST}" );
        $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 0);
        if ( $ret != GOOD ) { return ERROR; }



        #                 wait 2 minutes (timeline?)
        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        #                 verify IO
        logInfo("Verify IO with slave turned off. Loop $i");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers, 
                         0, 
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }
    }

    #           10) turn on controller
    CtlrLogText($$coPtr[$master], "Test Case 22: now turning on $$coPtr[$slave]->{HOST}" );
    $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 1);
    if ( $ret != GOOD ) { return ERROR; }

    #           11) reconnect and unfail
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    #           12) timeline for 2 minutes (delay in above fcn)
    #          13) verify IO

    
    logInfo("Verify IO at end of the test, after restoring the controller");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #          14) wait for/verify rebuild is complete

    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    
    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    

    #          15) verify IO

    
    logInfo("Verify IO at end of the test, after restoring the pdisk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of BE stress test case 22.");




    return GOOD;

}


###############################################################################

=head2 ParityCase23 function

This test case rrund redi-copy and attempts a defrag while rebuilds are 
running. 
The test has these
basic steps...

     1) Redi-copy a vdisk, wait for complete
     2) fail a pdisk - rebuilds start
     3) verify IO
     4) do another redi-copy, wait for complete
     5) verify IO
     6) delete first source vdisk
     7) start another redi-copy
     8) Begin defrags
     9) wait for copy complete
    10) verify IO
    11) wait for rebuild complete
    11.3) check SOS tables
    11.5) restart defrags
    12) verify IO
    13) wait for defrag complete
    13.5) unfail pdisk
    14) check sos tables
    15) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase23( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 23, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 73, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase23
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                redi-cp and defrag during a rebuild  
#        
# Steps are 1) Redi-copy a vdisk, wait for complete
#           2) fail a pdisk - rebuilds start
#           3) verify IO
#           4) do another redi-copy, wait for complete
#           5) verify IO
#           6) delete first source vdisk
#           7) start another redi-copy
#           8) Begin defrags
#           9) wait for copy complete
#          10) verify IO
#          11) wait for rebuild complete
#          11.3) check SOS tables
#          11.5) restart defrags
#          12) verify IO
#          13) wait for defrag complete
#          13.5) unfail pdisk
#          14) check sos tables
#          15) verify IO
#
##############################################################################
sub ParityCase23
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @pdds;
    my $ret;
    my $newVd;
    my $newVd2;
    my $lc;
    my @oldVds;
    my $failedDisk;
    my $ses;
    my $slot;
    my $lid;
    my $port;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 23: Redi-copy and defrag while doing a rebuild.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }



    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # redi-cp and defrag during rebuild. 
    ######################################################################

    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # we will fail the 2nd one of these
    @pdds = GetDataDisks( $ctlr );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # Steps are 1) Redi-copy a vdisk, wait for complete
    # this makes sure there is space to defrag

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 5 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # copy it to the end
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    # let copy complete 
    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }


    #           2) fail a pdisk - rebuilds start
    CtlrLogTextAll($coPtr, "Test Case 23: now failing pdd $pdds[1]" );
    
    $failedDisk =  $pdds[1];

    GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $failedDisk, $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }



    #           3) verify IO
    logInfo("Verify IO after failing the pdisk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # if a hotspare was used, we need to relabel disks for
    # the next vdiskcreate (just data disks)



    $ret = FixPdiskLabels ($ctlr, DONTMAKEHOTSPARE);
    if ( $ret != GOOD ) { return ERROR; }

    #           4) do another redi-copy, wait for complete

    # copy it to the end
    $newVd2 =  CreateReplacementVdisk($ctlr, $oldVds[1] );
    if ( $newVd2 < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[1], $newVd2);
    if ( $ret != GOOD ) { return ERROR; }

    # let copy complete 
    $ret = WaitForCpComplete( $ctlr, $newVd2 );
    if ( $ret != GOOD ) { return ERROR; }

    #           5) verify IO
    logInfo("Verify IO after 2nd copy, during rebuild");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    #           6) delete first source vdisk
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) ) 
    {
        return ERROR;
    }

    #           7) start another redi-copy
    # copy it to the end
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[2] );
    if ( $newVd < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[2], $newVd);
    if ( $ret != GOOD ) { return ERROR; }


    #           8) Begin defrags
    # Since a rebuild is going on, these really can't start. The
    # appropriate messages should get logged
    logInfo("Due to rebuilds, the following defrags will probably NOT start.");
    $ret = DefragAllBegin($ctlr);
    if ( $ret != GOOD ) { return ERROR; }


    #           9) wait for copy complete
    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }

    #          10) verify IO
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #          11) wait for rebuild complete
    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }
    

    PSDCheck( $ctlr );
 


    #          11.3) check SOS tables
    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     
    if ( $ret != GOOD ) { return ERROR; }

    #          11.5) restart defrags
    # Since a rebuild is done, these should start. The
    # appropriate messages should get logged

    logInfo("Rebuilds are done, the following defrags will probably WILL start.");
    $ret = DefragAllBegin($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    #          12) verify IO
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #          13) wait for defrag complete
    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    # 13.5) unfail the drive
    $ret = UnfailPdisk($coPtr, $failedDisk, $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    #          14) check sos tables
    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );     
    if ( $ret != GOOD ) { return ERROR; }

    #          15) verify IO

    logInfo("Verify IO after defrags finish");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 23.");


    return GOOD;

}
###############################################################################
###############################################################################

=head2 ParityCase24 .. 26 function

These test cases stress the move vdisk function. Case 24 just does a lot of moves.
Case 25 does moves during a redi-copy. Case 26 does moves, then 
moves during a redi-copy.

The test has these
basic steps...
     1) Create 2 vdisks (single Raid)
     2) change its vid many times  (vdiskmove)
     3) Create 2 move vdisks for redi-copy destinations
     4) start the redi-copies
     5) change the vid several times
     6) wait for redicp to complete
     7) check io at the end

Steps 3-6 are skipped for 24
Step 2 is skipped for case 25


=cut

=over 1

=item Usage:

 my $rc = ParityCase24 .. 26( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase24 .. 26
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                Fail a pdisk while initializing a single raid vdisk  
#        
# Steps are 1) Create a vdisk (single Raid)
#           2) change its vid many times  (vdiskmove)
#
#
##############################################################################
sub ParityCase24
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;
    
    my $ret;

    $ret = ParityCase2426($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, 0, $pDFailMeans );

    return $ret;

}

sub ParityCase25
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;
    
    my $ret;

    $ret = ParityCase2426($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, 1, $pDFailMeans );

    return $ret;

}

sub ParityCase26
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;
    
    my $ret;

    $ret = ParityCase2426($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, 2, $pDFailMeans );

    return $ret;

}


###############################################################################

=head2 ParityCase2426 function

This test case fails a pdisk while doing an init on a single raid drive. 
The test has these
basic steps...
     1) Create a vdisk (single Raid)
     2) change its vid many times  (vdiskmove)
=cut

=over 1

=item Usage:

 my $rc = ParityCase2426( $coPtr, $retIn, $snPtr, $loopCount, $ option, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done
        $option is 0, 1, 2

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase2426
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                Fail a pdisk while initializing a single raid vdisk  
#        
# Steps are 1) Create a vdisk (single Raid)
#           2) change its vid many times  (vdiskmove)
#
#
##############################################################################
sub ParityCase2426
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $option, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $lc;
    my $i;
    my $j;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my @pdds;
    my @nowVds;
    my @newVds;
    my %rsp;
    my $foundIt;
    my $newVd1;
    my $newVd2;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 24..26: Move vdisk, option = $option.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);



    # get measure of the current IO


#    @vCounts = GetVdiskActivityCounts($coPtr);
#
#    @sCounts = GetServerActivityCounts($coPtr);
#
#    logInfo("Pause to allow activity to accumulate");
#    DelaySecs(20);
#
##    @tMap = GetTargetMap( $coPtr, $snPtr );
##    if ( $tMap[0] == INVALID ) { return ERROR; }
#
#    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
#    if ( $ret != GOOD )  {return ERROR; }
#
#
#    #
#    # get the initial active vdisks for the test
#    #
#
#
#    logInfo("Generating Activity Information");
#
#    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
#    if (scalar(@activeServers) > 0 )
#    {
#        if ( $activeServers[0] == INVALID ) { return ERROR; }
#    }
#
#    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
#    if (scalar(@initialVdisks) > 0 )
#    {
#        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
#    }
#

    ######################################################################
    # create vdisk, init, then fail a pdisk
    ######################################################################

    #    0) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'
    
#    logInfo("polling until drives are operational");
#    $ret = INVALID;
#
#    $lc = 0; 
#    while ( $ret != GOOD )
#    {
#        $lc++;
#        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));
#
#        $ret = DegradeCheck( $ctlr );
#        if ( $ret == ERROR )
#        {
#            return ERROR;
#        }
#        DelaySecs( 15 );
#    }

    # Steps are 1) Create a vdisk (single Raid)
    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)
    $ret = MakeVdisks($ctlr, 14, NO_RAID_INIT );  # option 14 is 2 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
        return (ERROR);
    }
     
    #           2) Start the raid init

    # identify the two new ones


    # first get a list of current vdisks
    @nowVds = GetVdiskList( $ctlr );
    if ( $nowVds[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@nowVds);  # of drives currently available

    # now find which are new vdisks

    for ( $i = 0; $i < $numVDDs; $i++ )
    {
        $foundIt = 0;

        for ( $j = 0; $j < scalar(@vdisks); $j++ )
        {
            if ( $vdisks[$j] == $nowVds[$i] )
            {
                $foundIt = 1;
            }
        }

        if ( $foundIt == 0 )
        {
            push (@newVds, $nowVds[$i]);
        }
    }
    
    my @altVds;

    for ( $i = 0; $i < scalar(@newVds); $i++ )
    {
        $altVds[$i] = $newVds[$i] + 128;
    }

    # now the loops 

    logInfo(" Starting vdisks @vdisks");
    logInfo(" Source vdisks @newVds");
    logInfo(" Alternate vdisks @altVds");

    # option 1: skip the next loop

    if ( $option != 1 )
    {
        for ( $i = 0; $i < $loopCount; $i++ )
        {

        
            # move to alt

            for ( $j = 0; $j < scalar(@newVds); $j++ )
            {

                print "Moving vdisk  $newVds[$j] to $altVds[$j], loop $i.      \n"; 
                                                          # src         dest
                %rsp = $ctlr->virtualDiskControl(0x00, $newVds[$j], $altVds[$j]);

                if (!%rsp)                        # no response
                {
                    print "\n";
                    logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                    return ERROR;
                }

                if ($rsp{STATUS} == 1)            # 1 is bad
                {
                    logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                    print "\n";
                    PrintError(%rsp);
                    return ERROR;
                }

            }

            # move back
            for ( $j = 0; $j < scalar(@newVds); $j++ )
            {

                print "Moving vdisk  $altVds[$j] to $newVds[$j], loop $i.      \n"; 
                                                          # src         dest
                %rsp = $ctlr->virtualDiskControl(0x00, $altVds[$j], $newVds[$j]);

                if (!%rsp)                        # no response
                {
                    print "\n";
                    logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                    return ERROR;
                }

                if ($rsp{STATUS} == 1)            # 1 is bad
                {
                    print "\n";
                    logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                    PrintError(%rsp);
                    return ERROR;
                }

            }

            print "\n";

            logInfo ("Move vdisk loop $i complete");
        
        }
    }

    
    # option 0 skip the rest

    if ( $option != 0 )
    {
    
        # now, start a redicp on both of these and repeat the loop


        # copy it to the end
        $newVd1 =  CreateReplacementVdisk($ctlr, $vdisks[0] );
        if ( $newVd1 < 0 ) { return ERROR; }

        $ret = RediCpVdisks($ctlr, $vdisks[0], $newVd1);
        if ( $ret != GOOD ) { return ERROR; }

        # copy it to the end
        $newVd2 =  CreateReplacementVdisk($ctlr, $vdisks[1] );
        if ( $newVd2 < 0 ) { return ERROR; }

        $ret = RediCpVdisks($ctlr, $vdisks[1], $newVd2);
        if ( $ret != GOOD ) { return ERROR; }


        # For R1 and R2, we do not have the ability to move a vdisk that 
        # is part of a copy/swap. So, this test must work with different 
        # vdisks. Allowing a move during C/S is a future enhancement.
        #
        # We do this by using @vdisks or @newVds for the copies above
        #                    <current>  <future>




        for ( $i = 0; $i < $loopCount; $i++ )
        {

        
            # move to alt

            for ( $j = 0; $j < scalar(@newVds); $j++ )
            {

                print "Moving vdisk  $newVds[$j] to $altVds[$j], loop $i.      \n"; 
                                                          # src         dest
                %rsp = $ctlr->virtualDiskControl(0x00, $newVds[$j], $altVds[$j]);

                if (!%rsp)                        # no response
                {
                    print "\n";
                    logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                    return ERROR;
                }

                if ($rsp{STATUS} == 1)            # 1 is bad
                {
                    logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                    print "\n";
                    PrintError(%rsp);
                    return ERROR;
                }

            }

            # move back
            for ( $j = 0; $j < scalar(@newVds); $j++ )
            {

                print "Moving vdisk  $altVds[$j] to $newVds[$j], loop $i.      \n"; 
                                                          # src         dest
                %rsp = $ctlr->virtualDiskControl(0x00, $altVds[$j], $newVds[$j]);

                if (!%rsp)                        # no response
                {
                    print "\n";
                    logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                    return ERROR;
                }

                if ($rsp{STATUS} == 1)            # 1 is bad
                {
                    print "\n";
                    logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                    PrintError(%rsp);
                    return ERROR;
                }

            }

            print "\n";

            logInfo ("Move vdisk loop $i complete");
        
        }

        # let copy complete (if it hasn't already finished)
        $ret = WaitForCpComplete( $ctlr, $newVd1 );
        if ( $ret != GOOD ) { return ERROR; }

        # let copy complete (if it hasn't already finished)
        $ret = WaitForCpComplete( $ctlr, $newVd2 );
        if ( $ret != GOOD ) { return ERROR; }

     }


    # verify io at end 

#
#
#    #          10) verify IO
#    logInfo("Verify IO at end of the test");
#    $ret = VerifyIO( $coPtr,
#                     \@activeServers, 
#                     \@tMap, 
#                     \@initialVdisks,
#                     $snPtr
#                   );
#    if ( $ret != GOOD ) { return ERROR; }
#

    logInfo("End of BE stress test case 24..26, option = $option.");


    return GOOD;

}
###############################################################################

###############################################################################

=head2 ParityCase28 function

This test case fails a pdisk during a scrub. 
The test has these
basic steps...

     1) verify IO
     2) fail a pdisk
     3) verify IO
     4) wait for rebuild to end
     5) verify IO
     6) restore the failed pdisk
     7) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase28( $coPtr, $retIn, $snPtr , $pDFailMeans );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 28, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 78, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCase28
#
#        Inputs: $coPtr, $retIn, $snPtr, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                LIPs the BE loops  
#        
# Steps are 
#             1) verify IO
#             2) fail a pdisk
#             3) verify IO
#             4) wait for rebuild to end
#             5) verify IO
#             6) restore the failed pdisk
#             7) verify IO
#
##############################################################################
sub ParityCase28
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ses;
    my $slot;
    my $lid;
    my $port;


    my @pdds;
    my $ret;
    my %rsp;
    my $lc;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 28: Fail a pdisk during IO.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # loops to LIP the BE cards. 
    ######################################################################

    @pdds = GetDataDisks( $ctlr );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # Steps are 1) verify IO
    
 #   logInfo("Verify IO at start of the test");
 #   $ret = VerifyIO( $coPtr,
 #                    \@activeServers, 
 #                    \@tMap, 
 #                    \@initialVdisks,
 #                    $snPtr
 #                  );
 #   if ( $ret != GOOD ) { return ERROR; }





    #           3) fail a pdisk
    CtlrLogTextAll($coPtr, "Test Case 28: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }
    
    # the disk is failed, now some rebuilds will soon begin


    #           4) verify IO
    
    logInfo("Verify IO after failing a pdisk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }






    #           6) wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );
 
    #           7) verify IO
    
    logInfo("Verify IO after rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }




    #          12) restore the failed pdisk

    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    


    #          13) verify IO
    
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }



    logInfo("End of BE stress test case 28.");


    return GOOD;

}
###############################################################################

=head2 ParityCase31 function

This test case fails a pdisk during a scrub. 
The test has these
basic steps...

     1) verify IO
     2) fail a pdisk
     3) verify IO
     4) wait for rebuild to end
     5) verify IO
     6) restore the failed pdisk
     7) verify IO

=cut

=over 1

=item Usage:

 my $rc = ParityCase31( $coPtr, $retIn, $snPtr, $pDFailMeans );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 31, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will 
 probably spin the drive up and rebuild it. When invoked as test case
 31, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut


###############################################################################
sub ParityCase31
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlr;

    my @oldVds;
    my $newVd;
    my $ret;
    my $lc;
    my @pdds;
    my %rsp;
    my $ses;
    my $slot;
    my $lid;
    my $port;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 31: fail a pdisk wait for rebuilds  -----------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # With a defrag running, rediCP one of the first vdisks to a new one.
    # then delete the old one and start another defrag. 
    ######################################################################

    # setup - need to get a defrag running

    
    # verify IO is still good
    logInfo("IO check after beginning defrag");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    @pdds = GetDataDisks( $ctlr );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 31: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }
    
    # the disk is failed, now some rebuilds will soon begin

    
    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }





    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'
    
    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );
 

    # any rebuild stops a defrag, so there is no point in waiting for 
    # defrags to end (note, some defrags may continue if they don't 
    # crash into the rebuild)
    


    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    

    # verify IO
    logInfo("Confirm IO after test is done and disk restored.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 31.");


    return GOOD;

}
###############################################################################
###############################################################################


###############################################################################




###############################################################################


###############################################################################


###############################################################################
###############################################################################


###############################################################################

=head2 ParityCaseX function

This test case repeatedly LIPs the BE qlogic cards. 
The test has these
basic steps...






=cut

=over 1

=item Usage:

 my $rc = ParityCaseX( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut

##############################################################################
#
#          Name: ParityCaseX
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement. 
#
#                LIPs the BE loops  
#        




#
##############################################################################
sub ParityCaseX
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
#    my $newVd;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 7: Lots of LIPs on the BE Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);



    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }

    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # loops to LIP the BE cards. 
    ######################################################################


#add code here

    #   10) Verify IO
    
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 7.");


    return GOOD;

}
###############################################################################



###############################################################################

=head2 BEStressEntry function

The primary entry point for the Bigfoot BE stress tests.

A function used for debugging the code as a generic entry. The final 
parameter represents the test case to be run. A test case of 99 will
run most tests sequentially. There is no guarantee that the tests can actually 
run sequentially and give full coverage.

The test system should be configured as desired and IO from the 
servers should be running. Most likely this will mean a two-way system.
IO from the servers needs to be consistent over time or the IO validation
checks may fail. For the most part, RAIDs should be redundant as many tests 
will fail pdisks and require rebuilds. The test will hang if a drive 
becomes permanently degraded.

Tests can be run individually by specifying the test case number. ( 1...25+)
Not all test case numbers exist ( the list is not contiguous). Specifying 
an invalid number just means no test will be run. Test case 99 will run most
test cases sequentially. Test that are designed to cause a fatal condition 
will not be part of the 99 sequence.

Some test require a minimum of a 2 way configuration, others will run on 
1-way or n-way configurations.

Refer to the individual test cases for more information on the 
individual tests.

=cut

=over 1

=item Usage:

 my $rc = BEStressEntry($coPtr, $retIn, $snPtr, $moxaPtr, $mmPtr, $case );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaPtr is a pointer to a list of Moxa controller IP addresses
        $mmPtr is a pointer to a list of tha Moxa channel mappings
        $case is the test case to run

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the test(s)
           ran to completion without error. Test logs must be reviewed to
           ensure the test ran correctly.



=back

=cut


##############################################################################
#
#          Name: BEStressEntry
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub ParityEntry
{
    trace();
    my ( $coPtr,  $snPtr, $moxaIP, $mmPtr, $wwnPtr, $ipPtr, $case, $loopCount ) = @_;

    my $ret;
    my $autoLoop;

    $autoLoop = 0;
    $ret = GOOD;



    my @coList = @$coPtr;

    my $productID =  getMagProductID( 0, $coList[0]);

    if ( !$loopCount )
    {
        logInfo("LoopCount was not specified, default values will be used.");
        $autoLoop = 1;
    }

    if ( $case == 99 )
    {
        logInfo("All test cases selected, default loop count values will be used.");
        $autoLoop = 1;
    }


    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "                starting Parity Case $case. ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
 #   DelaySecs(300);

    StatsProcAll($coPtr);

    if ( $productID == 2750 )
    {
        #############################################
        #
        # These test cases fail a pisk via PDISKFAIL
        #
        #############################################
    
        if ( $autoLoop == 1 ) { $loopCount = 25; }
        if ( $case==1   || $case == 99 ) { $ret = ParityCase01(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKFAIL); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 10; }
        if ( $case==2   || $case == 99 ) { $ret = ParityCase02(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKFAIL ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==3   || $case == 99 ) { $ret = ParityCase03(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKFAIL ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==4   || $case == 99 ) { $ret = ParityCase04(  $coPtr, GOOD, $snPtr, PDISKFAIL ); }
        if ( $ret != GOOD ) { return $ret; }
    
        if ( $autoLoop == 1 ) { $loopCount = 25; }
        if ( $case==6   || $case == 99 ) { $ret = ParityCase06(  $coPtr, GOOD, $snPtr, $loopCount, PDISKFAIL ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==7   || $case == 99 ) { $ret = ParityCase07(  $coPtr, GOOD, $snPtr, $loopCount, PDISKFAIL ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==8   || $case == 99 ) { $ret = ParityCase08(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKFAIL ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==9   || $case == 99 ) { $ret = ParityCase09(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKFAIL ); }
        if ( $ret != GOOD ) { return $ret; }
    
    }
    else
    {
        #############################################
        #
        # These test cases fail a pisk via SPIN DOWN
        #
        #############################################

        if ( $case==28  || $case == 99 ) { $ret = ParityCase28( $coPtr, GOOD, $snPtr,  PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }
    

        if ( $case==0   || $case == 99 ) { $ret = ParityCase00(  $coPtr, GOOD, $snPtr,  PDISKSPINDOWN); }
        if ( $ret != GOOD ) { return $ret; }
     

        if ( $autoLoop == 1 ) { $loopCount = 25; }
        if ( $case==1   || $case == 99 ) { $ret = ParityCase01(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 10; }
        if ( $case==2   || $case == 99 ) { $ret = ParityCase02(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==3   || $case == 99 ) { $ret = ParityCase03(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==4   || $case == 99 ) { $ret = ParityCase04(  $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }
    
        #  (uses movevdisk which makes a mess - don't use with I/O running
        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==5  ) { $ret = ParityCase05(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN); }
        if ( $ret != GOOD ) { return $ret; }
    
        if ( $autoLoop == 1 ) { $loopCount = 25; }
        if ( $case==6   || $case == 99 ) { $ret = ParityCase06(  $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }
    
        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==7   || $case == 99 ) { $ret = ParityCase07(  $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==8   || $case == 99 ) { $ret = ParityCase08(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==9   || $case == 99 ) { $ret = ParityCase09(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==10  || $case == 99 ) { $ret = ParityCase10(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==11  || $case == 99 ) { $ret = ParityCase11( $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==12  || $case == 99 ) { $ret = ParityCase12( $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==13  || $case == 99 ) { $ret = ParityCase13( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }
    
        # 14 fails due to bug 7803. to be fixed for release 2. Till then, not in all.
        if ( $case==14   ) { $ret = ParityCase14( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==15  || $case == 99 ) { $ret = ParityCase15( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }
    
#       if ( $case==16  || $case == 99 ) { $ret = ParityCase16( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
#       if ( $ret != GOOD ) { return $ret; }
    
        if ( $case==17  || $case == 99 ) { $ret = ParityCase17( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }
    
#       if ( $case==18  || $case == 99 ) { $ret = ParityCase18( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
#       if ( $ret != GOOD ) { return $ret; }
    
        if ( $case==19  || $case == 99 ) { $ret = ParityCase19( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }
    
        if ( $case==20  || $case == 99 ) { $ret = ParityCase20( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }
    
        if ( $autoLoop == 1 ) { $loopCount = 3; }
        if ( $case==21  || $case == 99 ) { $ret = ParityCase21( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 3; }
        if ( $case==22  || $case == 99 ) { $ret = ParityCase22( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==23  || $case == 99 ) { $ret = ParityCase23( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
        if ( $ret != GOOD ) { return $ret; }
    
    
        if ( $autoLoop == 1 ) { $loopCount = 1000; }
        if ( $case==24   ) { $ret = ParityCase24( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 50; }
        if ( $case==25   ) { $ret = ParityCase25( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 50; }
        if ( $case==26   ) { $ret = ParityCase26( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
        if ( $ret != GOOD ) { return $ret; }


        if ( $case==31  || $case == 99 ) 
        { 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); 
        }
        if ( $ret != GOOD ) { return $ret; }
    
    

        #############################################
        #
        # These test cases fail a pisk via BYPASS
        #
        #############################################
    
    #   if ( $case==28  || $case == 99 ) { $ret = ParityCase28( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    #   if ( $ret != GOOD ) { return $ret; }
     

        if ( $case==51   || $case == 99 ) { $ret = ParityCase01(  $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }
    
        if ( $case==52   || $case == 99 ) { $ret = ParityCase02(  $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }
    
   #    if ( $case==53   || $case == 99 ) { $ret = ParityCase03(  $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
   #    if ( $ret != GOOD ) { return $ret; }
    

        if ( $case==54   || $case == 99 ) { $ret = ParityCase04(  $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }
    
   #    if ( $case==55   || $case == 99 ) { $ret = ParityCase05(  $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
   #    if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==56   || $case == 99 ) { $ret = ParityCase06(  $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==57   || $case == 99 ) { $ret = ParityCase07(  $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==58   || $case == 99 ) { $ret = ParityCase08(  $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==59   || $case == 99 ) { $ret = ParityCase09(  $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==60  || $case == 99 ) { $ret = ParityCase10( $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==61  || $case == 99 ) { $ret = ParityCase11( $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==62  || $case == 99 ) { $ret = ParityCase12( $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==63  || $case == 99 ) { $ret = ParityCase13( $coPtr, GOOD, $snPtr , PDISKBYPASS ); }
        if ( $ret != GOOD ) { return $ret; }
    
        # 14 fails due to bug 7803. to be fixed for release 2. Till then, not in all.
        if ( $case==64   ) { $ret = ParityCase14( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==65  || $case == 99 ) { $ret = ParityCase15( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }
    
   #    if ( $case==66  || $case == 99 ) { $ret = ParityCase16( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
   #    if ( $ret != GOOD ) { return $ret; }
    
        if ( $case==67  || $case == 99 ) { $ret = ParityCase17( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }
    
   #    if ( $case==68  || $case == 99 ) { $ret = ParityCase18( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
   #    if ( $ret != GOOD ) { return $ret; }
    
        if ( $case==69  || $case == 99 ) { $ret = ParityCase19( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }
    
        if ( $case==70  || $case == 99 ) { $ret = ParityCase20( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }
    
        if ( $autoLoop == 1 ) { $loopCount = 3; }
        if ( $case==71  || $case == 99 ) { $ret = ParityCase21( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 3; }
        if ( $case==72  || $case == 99 ) { $ret = ParityCase22( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==73  || $case == 99 ) { $ret = ParityCase23( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
        if ( $ret != GOOD ) { return $ret; }
    
    
        if ( $autoLoop == 1 ) { $loopCount = 1000; }
        if ( $case==74   ) { $ret = ParityCase24( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 50; }
        if ( $case==75   ) { $ret = ParityCase25( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 50; }
        if ( $case==76   ) { $ret = ParityCase26( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
        if ( $ret != GOOD ) { return $ret; }

                 
        if ( $case==81  || $case == 99 ) 
        { 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
            $ret = ParityCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); 
        }
        if ( $ret != GOOD ) { return $ret; }

    } #end of else for controller type check
        # special cases, not part of 'all'


    
        if ( $case == 115 ) 
        {
            while(1)
            {
                $ret = ParityCase15( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, PDISKSPINDOWN     ); 
            }
        }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case == 119 ) 
        {
            while(1)
            {
                $ret = ParityCase19( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, PDISKSPINDOWN     ); 
            }
        }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case == 116 ) 
        {
            while(1)
            {
                $ret = ParityCase15( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, PDISKSPINDOWN     );
                $ret = ParityCase19( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, PDISKSPINDOWN     );
             
            }
        }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case == 222 ) 
        {
            while(1)
            {
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
                $ret = ParityCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
             
            }
        }
        if ( $ret != GOOD ) { return $ret; }
        StatsProcAll($coPtr);

        CtlrLogTextAll( $coPtr, "------------------------------------------------------");
        CtlrLogTextAll( $coPtr, "                    Parity Case $case end. ");
        CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    #  DelaySecs(300);
 
    
    return $ret;

}


##############################################################################
#
#          Name: Support Functions
#
#  These are probably not exported.
#
##############################################################################

###############################################################################


###############################################################################


###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################


###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################




###############################################################################



###############################################################################





###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################

###############################################################################


##############################################################################


1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.2  2006/08/01 11:12:41  AnasuriG
# TBolt00015075
# Added changes for PDISKFAIL
#
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
# Revision 1.19  2004/12/16 19:47:19  KohlmeyerA
# Tbolt00000000:  Added mirror prep and validation functions to tests 1 thru 9.  Also replaced
# initial IO data gather functions with new single function call.
# Reviewed by Craig.
#
# Revision 1.18  2004/10/20 17:00:06  KohlmeyerA
# Tbolt00000000: Added check for number of controllers to test case 8 and 9.
# Reveiwed by Craig.
#
# Revision 1.17  2004/08/04 15:29:48  MenningC
# tbolt00000000: updates to allow unbypass in fabric, reviewed by Al
#
# Revision 1.16  2004/07/28 15:04:35  MenningC
# tbolt00000000: updates to support SATA and adrdress 4 way issues, reviewed by Al
#
# Revision 1.15  2004/07/12 15:28:27  MenningC
# tbolt00000000: enable parity case 5, but not in case 99; reviewed by Al
#
# Revision 1.14  2004/05/26 16:25:17  MenningC
# tbolt00000000: update some log entries . reviewed by Al
#
# Revision 1.13  2004/05/24 13:55:21  MenningC
# tbolt00000000: Detect errors failing items in failover nway, ignore R10 miscompare in parity scan, updates to logged info, detect inop raids in failover. . reviewed by Al
#
# Revision 1.12  2004/05/07 16:56:37  KohlmeyerA
# tbolt00000000:  Corrected case 09 to create vdisks from master instead of slave.  Reviewed by Craig
#
# Revision 1.11  2004/02/18 20:28:53  MenningC
# tbolt00000000:Fix defrag 5, timing on be14, etc., reviewed by Al
#
# Revision 1.10  2004/02/05 19:54:08  MenningC
# tbolt00000000: new power control script and related changes; reviewed by Al.
#
# Revision 1.9  2003/11/25 19:45:54  MenningC
# TBOLT00000000: Add new BEStress test #38 for debugging a bug. Reviewed by Jeff Williams.
#
# Revision 1.8  2003/11/12 19:17:03  MenningC
# tbolt00000000: Scrub fixes and some additional debug code. Reviewed by Olga
#
# Revision 1.7  2003/11/05 21:16:39  MenningC
# tbolt00000000: Added 5 minute delays before and after testing. Defrag case 1 got additional delays.  Reviewed by Olga
#
# Revision 1.6  2003/10/29 15:03:18  MenningC
# tbolt00000000: updates for TAS=LAS=0 bug, move rebuild check in unfailpdisk. Reviewed by Olga
#
# Revision 1.5  2003/10/08 14:21:37  WerningJ
# Tbolt00000000: changes to support defrag all, reveiwed by Eric
#
# Revision 1.4  2003/09/16 15:12:02  MenningC
# tbolt00000000: additional parity scan work, update for pdisks that automatically unhotspare themselves. Reviewed by Eric
#
# Revision 1.3  2003/08/20 15:17:52  MenningC
# tbolt00000000: check in current state of parity scan tests, adds parity scan to most BE stress tests, reviewed by Olgs
#
# Revision 1.2  2003/08/13 18:27:13  MenningC
# tbolt00000000: more parity tests, support for servermates(dual path). reviewed by Eric
#
# Revision 1.1  2003/07/25 18:39:35  MenningC
# tbolt00000000: support for the parity scan tests; reviewed by Eric
#
# Revision 1.24  2003/07/01 14:32:12  MenningC
# TBOLT00000000: Additional fixes for pdisklabels and removed a server assoc test from the regression suite. reviewed by Olga
#
# Revision 1.23  2003/06/26 18:04:28  MenningC
# TBOLT00000000: Changes to support unchanging drive labels during hotspare in R2 and R3; reviewed by Olga
#
# Revision 1.22  2003/06/06 21:05:07  MenningC
# TBOLT00000000: fixes for ses and slot for pdisk bypassing.
#
# Revision 1.21  2003/05/28 14:54:20  MenningC
# TBOLT00000000: Changes to support bypassing of drives, patch for servermates, fix a defrag case timing.; reviewed by JW
#
# Revision 1.20  2003/05/07 18:58:38  MenningC
# TBOLT00000000: New test case 31; reviewed by Olga
#
# Revision 1.19  2003/04/21 15:13:41  MenningC
# tbolt00000000: fix timeout in rmstate, fix bestress case22, fix defrag case 23; reviewed by JW
#
# Revision 1.18  2003/04/16 13:55:40  MenningC
# tbolt00000000: minor fixes reviewed by JW
#
# Revision 1.17  2003/04/14 14:31:48  MenningC
# tbolt00000000: adde PSDCheck; reviewed by JW
#
# Revision 1.16  2003/04/08 18:44:56  MenningC
# tbolt00000000: changed an error message; reviewed by JW
#
# Revision 1.15  2003/03/27 21:29:39  MenningC
# Fix BEPULL in failover, remove case14 in bestress; reviewed by JW
#
# Revision 1.14  2003/03/26 21:24:52  WerningJ
# Removed calls to unused modules
# Reviewed by Craig M
#
# Revision 1.13  2003/03/06 19:55:58  MenningC
# tbolt00000000 enhancement for JW and MS, reviewed by the other JW
#
# Revision 1.12  2003/03/03 23:03:29  MenningC
# tbolt00000000 fix for BEStress and new failover test case for Neal, reviewed by JW
#
# Revision 1.11  2003/02/25 22:01:24  MenningC
# tbolt00000000 updates for BEStress tests, reviewed by JW
#
# Revision 1.10  2003/02/25 21:56:00  MenningC
# tbolt00000000 updates for BEStress tests, reviewed by JW
#
# Revision 1.9  2003/01/29 17:16:13  MenningC
# Tbolt00000000:more debug of BEStress reviewed by Jeff Werning.
#
# Revision 1.8  2003/01/22 20:48:31  MenningC
# Tbolt00000000: fix for target maps. Reviewed by Jeff Werning.
#
# Revision 1.7  2003/01/22 17:03:53  MenningC
# Tbolt00000000: more debug of the BEstress tests, reviewed by J Werning
#
# Revision 1.6  2003/01/21 19:49:14  MenningC
# Tbolt00000000: more debug of the BEstress tests, reviewed by J Werning
#
# Revision 1.5  2003/01/17 16:36:26  MenningC
# Tbolt00000000: Additional updates to BEStress. Reviewed by Jeff Werning.
#
# Revision 1.4  2003/01/16 15:28:01  MenningC
# Tbolt00000000: more new code, not reviewed.
#
# Revision 1.3  2003/01/15 21:17:50  MenningC
# Tbolt00000000: amore new code, not reviewed.
#
# Revision 1.2  2003/01/15 15:58:07  MenningC
# Tbolt00000000: additional new code, reviewed by Olga
#
# Revision 1.1  2003/01/14 16:03:46  MenningC
# Tbolt00000000: new file. Reviewed by J Werning.
#
#
#
##############################################################################
