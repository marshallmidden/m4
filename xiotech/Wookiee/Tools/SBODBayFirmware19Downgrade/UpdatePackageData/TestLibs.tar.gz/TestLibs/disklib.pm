#!/usr/bin/perl -w
# $Header$
######################################################################################
## Perl modules to support drive configuration                                      ##
##								                                                    ##
##																					##
## Created by Olga Grigorenko     													##
##                                                                                  ##
##			  (change history at bottom)											##
######################################################################################


package XIOTech::disklib;

use IO::Socket;
use IO::Select;

use XIOTech::cmPDisk;
use XIOTech::cmVDisk;
use XIOTech::cmLogs;
use XIOTech::cmStats;
use XIOTech::cmVCG;
use XIOTech::cmServer;
use XIOTech::cmTarget;

#Setup inheritance
use XIOTech::initializeable;
@ISA = qw(XIOTech::initializeable);

use XIOTech::xiotechPackets;
use XIOTech::seqNumber;
use XIOTech::constants;
use XIOTech::error;
use XIOTech::cmdMgr;
use Math::BigInt;

use XIOTech::logMgr;

use strict;

 
##############################################################################
# Name:     Create_Raid_0_10_VD
#
# Desc:     Creates VD's raid 0 and 10
#
# In:       scalar $name - VD Name
#			scalar $raidType - VD Raid Type ( Raid 0 - 1 : Raid 10 - 4)
#			scalar $Space - Space in GB
#			scalar $stripeSize - VD Stripe Size
#			array  @physicalDisks - Group of Physical disks
#
#
# Returns:  array containing VD ID, VD Name, Result of the Function  
#
##############################################################################


sub Create_Raid_0_10_VD
{
 my ($self, $name, $raidType,  $Space, $stripeSize, @physicalDisks) = @_;
 my $requestedBytes;
 my @array;

 print "name $name, \n raid $raidType,  \n space $Space, \n stripe $stripeSize, \n disks @physicalDisks \n";

#print "enter a number to calc....";
#my   $dummy = <STDIN>;



 my %raidParms = $self->calcRaidParms(\@physicalDisks, $raidType);

 foreach my $name (sort keys %raidParms)
	{
#		print "Name: $name, Value: $raidParms{$name} \n";
		print " $name: $raidParms{$name} \n";
	}


#print "going to prepare... strpsz = $stripeSize , mdepth = $raidParms{MIRROR_DEPTH} , par = $raidParms{PARITY} \n"; 
#print "enter a number to prepare....";
#$dummy = <STDIN>;


 if($Space > 0)
	{
		$requestedBytes =  Math::BigInt->new( ($Space * 1024 * 1024 * 1024) / 512 );
		#need to change 
		print "requestedBytes  $requestedBytes \n";
	}

 my %calCap = $self->virtualDiskPrepare("+0",
										\@physicalDisks,
										0,
										$stripeSize,
										$raidParms{MIRROR_DEPTH},
										$raidParms{PARITY});
		
# my %calCap = $self->virtualDiskPrepare("$requestedBytes",
#										\@physicalDisks,
#										$raidType,
#										$stripeSize,
#										$raidParms{MIRROR_DEPTH},
#										$raidParms{PARITY});
#		


 foreach my $name (sort keys %calCap)
	{
#		print "Name: $name, Value: $calCap{$name} \n";
		print " $name: $calCap{$name} \n";
	}



 if ($name eq "VDM01")
	{ 
		print "Space $calCap{CAPACITY} \n"; 	
		$requestedBytes = ($calCap{CAPACITY} / 5) / 512;
	} 
 
 if ($name eq "VDS01")
	{
		print "Space $calCap{CAPACITY} \n"; 
		$requestedBytes = ($calCap{CAPACITY} / 512 );
	}

 if ($name eq "PERF")
	{ 
		print "Space $calCap{CAPACITY} \n"; 	
		$requestedBytes = ($calCap{CAPACITY} / 5) / 512;
	} 
		
#print "going to create... bytes = $requestedBytes , type = $raidType , mdepth = $raidParms{MIRROR_DEPTH} , par = $raidParms{PARITY} \n"; 
 print "Create VD $name \n";

#print "enter a number to create....";
#$dummy = <STDIN>;


 my %rc = $self->virtualDiskCreate(	$requestedBytes,
									\@physicalDisks,
									$raidType,	   		          													
									$stripeSize,
									$raidParms{MIRROR_DEPTH},
									$raidParms{PARITY}); 
 if (NoError(%rc))
 	{
		print " VDisk ID = $rc{VID} was created \n"; 
		$array[0] ="1 ";
		$array[1] ="Name $name";
		$array[2] =" VD ID ";
		$array[3] = $rc{VID};
		$array[4] = " - Was Created"; 
 	}

 else
 	{
		print ">>>>>>> Look for Error Above <<<<<<<\n";
		$array[0] ="0 ";
		$array[1] = "VD Name $name ";
			if (defined($rc{ERROR_CODE}))
				{
					$array[2] =" $rc{ERROR_CODE}";
		 		}
			else
				{
					$array[2] = " No error code defined";
				}
		$array[3] = " - Was not created ";
		if (defined($rc{MESSAGE}))
			{
				$array[4] = " $rc{MESSAGE} ";
		 	}
	}

 return @array;

}

##############################################################################
# Name:     Delete_Disks
#
# Desc:		Creates VDS for Delete_Deg Test      
#
# In:       scalar $name - VD Name
#			array  @physicalDisks - Group of Physical disks(All of the avaluable 
#									ph disks, but not unsafe and hot-spare)
#
#
# Returns:  array containing VD ID, VD Name, Result of the Function  
#
##############################################################################

sub Delete_Disks
{

 my ($self, $name, $raidType, $parity, $Space,  $stripeSize, @physicalDisks) = @_;
 
 my @array;

 my %raidParms = $self->calcRaidParms(\@physicalDisks, $raidType);
 
 foreach my $name (sort keys %raidParms)
	{
#		print "Name: $name, Value: $raidParms{$name} \n";
		print " $name: $raidParms{$name} \n";
	}

 my $requestedBytes =  Math::BigInt->new( ($Space * 1024 * 1024) / 512 );

 print "Space $requestedBytes \n", "Creating VD $name \n"; 

 my %rc = $self->virtualDiskCreate(	$requestedBytes,
									\@physicalDisks,
									$raidType,	   		          													
									$stripeSize,
									$raidParms{MIRROR_DEPTH},
									$parity); 

 if (NoError(%rc))
 	{
		print " VDisk ID = $rc{VID} was created \n"; 
		$array[0] ="1 ";
		$array[1] ="Name $name";
		$array[2] =" VD ID ";
		$array[3] = $rc{VID};
		$array[4] = " - Was Created"; 
 	}

 else
 	{
		print ">>>>>>> Look for Error Above <<<<<<<\n";
		$array[0] ="0 ";
		$array[1] = "VD Name $name ";
			if (defined($rc{ERROR_CODE}))
				{
					$array[2] =" $rc{ERROR_CODE}";
		 		}
			else
				{
					$array[2] = " No error code defined";
				}
		$array[3] = " - Was not created ";
		if (defined($rc{MESSAGE}))
			{
				$array[4] = " $rc{MESSAGE} ";
		 	}
	}
 

 return @array; 

}



##############################################################################
# Name:     Create_Raid_5_VD
#
# Desc:		Creates VDS raid 5 and 1    
#			
# In:       scalar $name - VD Name
#			scalar $raidType - Raid Type
#			scalar $parity - VD Parity
#			scalar $Space - VD Space GB
# 			scalar $$stripeSize - Stripe Size
#			array  @physicalDisks - Group of Physical disks
#
#
# Returns:  array containing VD ID, VD Name, Result of the Function  
#
##############################################################################

sub Create_Raid_5_VD
{

 my ($self, $name, $raidType, $parity, $Space,  $stripeSize, @physicalDisks) = @_;
 my @array;
 my %raidParms = $self->calcRaidParms(\@physicalDisks, $raidType);
 
 foreach my $name (sort keys %raidParms)
	{
#		print "Name: $name, Value: $raidParms{$name} \n";
		print " $name: $raidParms{$name} \n";
	}

 my $requestedBytes =  Math::BigInt->new( ($Space * 1024 * 1024 * 1024) / 512 );
 #need to change 
 print "Space $requestedBytes \n", "Creating VD $name \n"; 

#  print " going to create raid: $raidType , strip sz: $stripeSize , parity: $parity \n";

 my %rc = $self->virtualDiskCreate(	$requestedBytes,
									\@physicalDisks,
									$raidType,	   		          													
									$stripeSize,
									$raidParms{MIRROR_DEPTH},
									$raidParms{PARITY});				#  was   $parity); 

 if (NoError(%rc))
 	{
		print " VDisk ID = $rc{VID} was created \n"; 
		$array[0] ="1 ";
		$array[1] ="Name $name";
		$array[2] =" VD ID ";
		$array[3] = $rc{VID};
		$array[4] = " - Was Created"; 
 	}

 else
 	{
		print ">>>>>>> Look for Error Above <<<<<<<\n";
		$array[0] ="0 ";
		$array[1] = "VD Name $name ";
			if (defined($rc{ERROR_CODE}))
				{
					$array[2] =" $rc{ERROR_CODE}";
		 		}
			else
				{
					$array[2] = " No error code defined";
				}
		$array[3] = " - Was not created ";
		if (defined($rc{MESSAGE}))
			{
				$array[4] = " $rc{MESSAGE} ";
		 	}
	}

 return @array; 

}



##############################################################################
# Name:     delete_all
#
# Desc:	   Deletes all the VD's on the system     
#			
# In:		None      
#
# Returns:	Print Statments  
#
##############################################################################


sub delete_all
{
 my ($self) = @_;
 my %VIDs = $self->virtualDiskList();
 my $listsub = $VIDs{LIST};
 my @list = @$listsub; 
	
 if(scalar(@list))
	{
		for (my $i = 0; $i < scalar(@list); $i++)
			{  
				my %rc = $self->virtualDiskDelete($list[$i]);
				if (NoError(%rc))
					{
						print " VDisk ID =  $list[$i] was deleted \n";  
					}
			
				else
					{
						print ">>>>>>> Look for Error Above <<<<<<<\n";
					}
			}
	}	

 else
	{
		print "There are no VDisks to Delete \n";
	}

}


##############################################################################
# Name:     VDiskInit
#
# Desc:	    Initializes all VD's on the system 
#			
# In:		None      
#
# Returns:	Print Statements   
#
##############################################################################


sub VDiskInit
{
 
 my ($self) = @_;
 my %rc = $self->raidList();
 my $Sub_ArrayVD = $rc{LIST};
 my @Raid_Array = @$Sub_ArrayVD;
 if(NoError(%rc))
	{
		for(my $i = 0; $i < scalar(@Raid_Array); $i++)
			{
				%rc = $self->virtualDiskInit($Raid_Array[$i]);
				if(NoError(%rc))
					{
						print "Raid_ID $Raid_Array[$i] was initialized. \n"; 
					}
				else
					{
						print "ERROR --- Raid_ID $Raid_Array[$i] was NOT initialized. \n";
					}
			}
	}

}


##############################################################################
# Name:     Create_Any_VD
#
# Desc:		
#			
# In:		$name - Virtual disk name
#			$capacity	 - MB requested bytes in MB
#	       	@physicalDisks - Array of physical disks
#   	    $rtype - raid type
#       	$stripe - stripe size
#        	$depth - mirrow depth
#        	$parity - parity        
#
# Returns:	Print Statements   
#
##############################################################################

sub Create_Any_VD
{
 my ($self, $name, $capacity, $rtype, $stripe, $depth, $parity, @physicalDisks) = @_;
 my @array;

 my %raidParms = $self->calcRaidParms(\@physicalDisks, $rtype);

 foreach my $name (sort keys %raidParms)
	{
		#print "Name: $name, Value: $raidParms{$name} \n";
		print "$name : $raidParms{$name} \n";
	}
 print "Disks", scalar(@physicalDisks), "\n";

 if(($capacity != 0) && ($rtype != 0) && (scalar(@physicalDisks) != 0))
	{
		$capacity =  Math::BigInt->new( ($capacity * 1024 * 1024) / 512 );
	
 		if($stripe == 0)
 			{
 				$stripe = $raidParms{STRIPE_SIZE};
 			}

		if($depth == 0)
 			{
 				$depth = $raidParms{MIRROR_DEPTH}; 
 			}
		
		if($parity == 0)
 			{
 				$parity = $raidParms{STRIPE_SIZE};
 			}
	}
 
 else
 
	{
		print "Inseficiant resouces, check the function call \n";
	}

print "capacity $capacity, physicalDisks \@physicalDisks, rtype $rtype, stripe $stripe,depth $depth, parity $parity \n";




 my %rc = $self->virtualDiskCreate(	$capacity,
									\@physicalDisks,
									$rtype,	   		          													
									$stripe,
									$depth,
									$parity); 

 if (NoError(%rc))
 	{
		print " VDisk ID = $rc{VID} was created \n"; 
		$array[0] ="1 ";
		$array[1] ="Name $name";
		$array[2] =" VD ID ";
		$array[3] = $rc{VID};
		$array[4] = " - Was Created"; 
 	}

 else
 	{
		print ">>>>>>> Look for Error Above <<<<<<<\n";
		$array[0] ="0 ";
		$array[1] = "VD Name $name ";
			if (defined($rc{ERROR_CODE}))
				{
					$array[2] =" $rc{ERROR_CODE}";
		 		}
			else
				{
					$array[2] = " No error code defined";
				}
		$array[3] = " - Was not created ";
		if (defined($rc{MESSAGE}))
			{
				$array[4] = " $rc{MESSAGE} ";
		 	}
	}

 return @array;
}

##############################################################################
# Name:     Expand
#
# Desc:	    Checks for an error
#			
# In:		hash %ret - Returned hash from the a function        
#
# Returns:	Print Statements   
#
##############################################################################


sub Expand
{
 my ($self, $name, $vid, $capacity, $rtype, $stripe, $depth, $parity, @physicalDisks) = @_;
 my @array;

 my %raidParms = $self->calcRaidParms(\@physicalDisks, $rtype);

 foreach my $name (sort keys %raidParms)
	{
#		print "Name: $name, Value: $raidParms{$name} \n";
		print " $name: $raidParms{$name} \n";
	}

 if(($capacity != 0) && ($rtype != 0) && (scalar(@physicalDisks) != 0))
	{
		$capacity =  Math::BigInt->new( ($capacity * 1024 * 1024) / 512 );
	
 		if($stripe == 0)
 			{
 				$stripe = $raidParms{STRIPE_SIZE};
 			}

		if($depth == 0)
 			{
 				$depth = $raidParms{MIRROR_DEPTH}; 
 			}
		
		if($parity == 0)
 			{
 				$parity = $raidParms{STRIPE_SIZE};
 			}
	}
 
 else
 
	{
		print "Inseficiant resouces, check the function call \n";
	}

print "capacity $capacity, physicalDisks \@physicalDisks, rtype $rtype, stripe $stripe,depth $depth, parity $parity \n";

my $physicalDisks = @physicalDisks;
my %rc = $self->virtualDiskExpand(	$self,
        						$vid,
        						$capacity,
        						$physicalDisks,
								$rtype,
								$stripe,
								$depth,
    							$parity);


if (NoError(%rc))
	{
		print " VDisk ID = $rc{VID} was created \n";
		$array[0] = 1;
		$array[1] ="VD Name $name";
		$array[2] =" VD Name ID ";
		$array[3] = " - Was Expended";
	}
 else
	{
		print ">>>>>>> Look for Error Above <<<<<<<\n";
		$array[0] = 0;
		$array[1] ="VD Name $name";
			if (defined($rc{ERROR_CODE}))
				{
					$array[2] =" $rc{ERROR_CODE}";
		 		}
			else
				{
					$array[2] = " ";
				}
		$array[3] = " - Was not Expended ";
			if (defined($rc{MESSAGE}))
				{
					$array[4] =" $rc{MESSAGE}";
		 		}

	}
 
  return @array;
}


##############################################################################
# Name:     NoError
#
# Desc:	    Checks for an error
#			
# In:		hash %ret - Returned hash from the a function        
#
# Returns:	Print Statements   
#
##############################################################################

sub NoError
{
 my (%ret) = @_;
 my $ i = 0;

 if (%ret)
	{
		if ($ret{STATUS} == PI_GOOD)
			{
				$i = 1;
			}
		else
			{
				$i = 0;
				printf "Status Code: 0x%x\n", $ret{STATUS};
				printf "Error Code:  0x%x\n", $ret{ERROR_CODE};
				if (defined($ret{MESSAGE}))
					{
						print "\n";
						printf "Message:\n";
						print $ret{MESSAGE};
				 	}
			}
	}
	
 else
	{
		$i = 0;
		print "ERROR: Did not receive a response packet.\n";
	}

 return $i;

}


#===========================================================================================#
#====================================================================
#
# Change history (intentionally manual to facilitate merging)
#
#
#====================================================================
#
#
# 3/6/2002 craigm  Fixed some prints
#
