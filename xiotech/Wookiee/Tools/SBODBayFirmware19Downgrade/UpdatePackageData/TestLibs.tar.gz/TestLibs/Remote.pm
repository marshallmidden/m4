#! /usr/bin/perl s
# $Header$
##############################################################################
# File name:  TestLibs::Remote
#
# Desc: A set of library functions for working with remote server.
#
# Date: 12/13/2002
#
# Original Author:  Jeff Werning
#
# Last modified by  $Author: RysavyR $
# Modified date     $Date: 2005-05-04 13:53:47 -0500 (Wed, 04 May 2005) $
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
#
# See the following:
# http://perldoc.com/perl5.8.0/pod/perlipc.html#Bidirectional-Communication-with-Another-Process
#

package TestLibs::Remote;

#
# - perl compiler/interpreter flags 'n' things
#
#use strict;
use IO::Socket;
use strict;
use warnings;

use TestLibs::Logging;
use TestLibs::Constants;

BEGIN 
{
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      &IPCClient
                      &IPCMkDir
                      &RCP
                      &RemoteCmd
                      &RSH
                      &RSHdaemon
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;

##############################################################################
#
#          Name: IPCClient 
#
#        Inputs: Host Server IP or Name, Command string to send
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Will connect to the given server on the port sepified below 
#                Then send the command string to the server for execution
#                A Pipe will return the server output to the client
#
##############################################################################
sub IPCClient
{
    my ($host, $command) = @_;

    my $port = 7777;            # This port must match the one used by the server
    my $kidpid;                 # Process ID of the child process
    my $server;
    my $line;
    my $killCount;

    # color related variables
    my $win32 = 0;
    my $WINOUT;
    my $startColor;
    
    # create a tcp connection to the specified host and port
    $server = IO::Socket::INET->new(Proto     => "tcp",
                                    PeerAddr  => $host,
                                    PeerPort  => $port);
    if (!$server)
    {
        TestLibs::Logging::logWarning ("Error: can't connect to port $port on $host: $!");
        return ERROR;
    }

    $server->autoflush(1);      # so output gets there right away
    TestLibs::Logging::logInfo ("IPC CLient Connected to $host:$port");

    # split the program into two processes, identical twins
    $kidpid = fork();

    if (!defined($kidpid))
    {
        TestLibs::Logging::logWarning ("Error: IPC Client => Fork of Child process failed");
        return ERROR;
    }
    
    # the if{} block runs only in the parent process
    if ($kidpid) 
    {
        STDOUT->autoflush(1);
        STDERR->autoflush(1);
        # copy the socket to standard output
        my $byte;

        while (sysread($server, $byte, 1) == 1) 
        {
# Add logging
            print STDOUT $byte;
        }

        $killCount = kill("TERM", $kidpid);          # send SIGTERM to child

        if ($killCount)
        {        
            TestLibs::Logging::logInfo ("IPC Client => Kill Child:$kidpid Signal sent");
        }
        else
        {
            TestLibs::Logging::logWarning ("Error: IPC Client => Kill Child:$kidpid Signal failed");
        }
            

        return GOOD;
    }
    # the else{} block runs only in the child process
    else 
    {
        # copy standard input to the socket
# Add logging
        print $server $command;         # Send the command to the server
        print $server "\n \n";          # Send the termination string to the server (A blank line)

        while (1){ };                   # Wait here untill the parent kills us
    }  
}

##############################################################################
#
#          Name: RemoteCmd 
#
#        Inputs: Host Server IP or Name, Command string to send
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Scriptable interface to the PSExec program which allows commands to 
#                be executed remotely on Windows machines.  See the help text below.
#
#   PsExec v1.31 - execute processes remotely
#   Copyright (C) 2001-2002 Mark Russinovich
#   www.sysinternals.com
#   
#   PsExec executes a program on a remote system, where remotely executed console
#   applications execute interactively.
#   
#   Usage: psexec \\computer [-u user [-p psswd]][-s][-i][-c [-f]][-d] cmd [arguments]
#        -u         Specifies optional user name for login to remote
#                   computer.
#        -p         Specifies optional password for user name. If you omit this
#                   you will be prompted to enter a hidden password.
#        -s         Run the remote process in the System account.
#        -i         Run the program so that it interacts with the desktop on the
#                   remote system.
#        -c         Copy the specified program to the remote system for
#                   execution. If you omit this option the application
#                   must be in the system path on the remote system.
#        -f         Copy the specified program even if the file already
#                   exists on the remote system.
#        -d         Don't wait for process to terminate (non-interactive).
#        program    Name of application to execute.
#        arguments  Arguments to pass (note that file paths must be
#                   absolute paths on the target system).
#   
#   You can enclose applications that have spaces in their name with
#   quotation marks e.g. psexec \\marklap "c:\long name app.exe".
#   Input is only passed to the remote system when you press the enter
#   key, and typing Ctrl-C terminates the remote process.
#   
#   If you omit a user name the process will run in the context of your
#   account on the remote system, but will not have access to network
#   resources (because it is impersonating). Specify a valid user name
#   in the Domain\User syntax if the remote process requires access
#   to network resources or to run in a different account. Note that
#   the password is transmitted in clear text to the remote system.
#
##############################################################################
sub RemoteCmd
{
    my ($host, $command) = @_;

    my @args;

    # Execute command on remote host
    # PSExec \\computer [-u user [-p psswd]][-s][-i][-c [-f]][-d] cmd [arguments]
    @args = ('Common\PSexec.exe ' . "\\\\$host " . "$command");

    TestLibs::Logging::logInfo ("RemoteCmd: @args");
    my $systemReturn = system(@args);

    if ($systemReturn == 0)
    {
        TestLibs::Logging::logInfo ("System Command Successfull: @args");
    }
    else
    {
        my $shiftRC = $systemReturn/256;
        TestLibs::Logging::logError ("Failed to run Common\\PSexec.exe => Error Code:$shiftRC");
        print "\n";
        return ERROR;
    }


    return GOOD; 
}

##############################################################################
#
#          Name: IPCMkDir 
#
#        Inputs: Host Server IP or Name, Remote Directory to make, user, share 
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Will create a directory on the given server, share it with
#                the given share name, and give the specified user access 
#                to it (the user name is also the password is used).
#
#   Currently works on windoze OS only
#
##############################################################################
sub IPCMkDir
{
    my ($host, $dir, $user, $share) = @_;

    my $IPCreturn;

    # Check if this is a win32 OS
    if ("$^O" eq "MSWin32") 
    {
        # TBD - Check if directory exist
        $IPCreturn = IPCClient($host, "mkdir $dir");
        if ($IPCreturn != GOOD) {return $IPCreturn;}

        # TBD - Check if directory is shared
        $IPCreturn = IPCClient($host, "net share $share=$dir");
        if ($IPCreturn != GOOD) {return $IPCreturn;}

        # TBD - Check if user is added
        $IPCreturn = IPCClient($host, "net user $user $user /ADD /ACTIVE:YES  /COMMENT:\"Created via XTC\" /HOMEDIR:$dir /EXPIRES:NEVER");
        if ($IPCreturn != GOOD) {return $IPCreturn;}
    }
    return GOOD;
}

##############################################################################
#
#          Name: RSHdaemon 
#
#        Inputs: Host Server IP or Name, Shared Directory, User name, Share name
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Will set up remote shell daemon RSHD to run on the server
#                using the given directory and user.
#
#   Currently works on windoze OS only, unix servers usually have RSHD installed
#
##############################################################################
sub RSHdaemon
{
    my ($host, $dir, $user, $share) = @_;

    my $IPCreturn;

    # Check if this is a win32 OS
    if ("$^O" eq "MSWin32") 
    {
        # TBD - Check if RSHD is already running
        
        # Create a directory for the RSHD code
        $IPCreturn = IPCClient($host, "mkdir $dir\\rshd");
        if ($IPCreturn != GOOD) {return $IPCreturn;}

        # Copy the default rhosts permissions file to server
        print "copy common\\rshd\\.rhosts \\\\$host\\$share\n";
        print `copy common\\rshd\\.rhosts \\\\$host\\$share\n`;
        
        # Copy the rshd files to server
        print "copy common\\rshd\\\*\.\* \\\\$host\\$share\\rshd\n";
        print `copy common\\rshd\\\*\.\* \\\\$host\\$share\\rshd\n`;
        
        # Set the ACL for the rhosts file, this is required for RSHD to allow access
        $IPCreturn = IPCClient($host, "CACLS $dir\\.rhosts /E /G $user:F\n");
        if ($IPCreturn != GOOD) {return $IPCreturn;}

        # Remove the ACL for user Everyone from the rhosts file, this is required for RSHD to allow access
        $IPCreturn = IPCClient($host, "CACLS $dir\\.rhosts /E /R EveryOne\n");
        if ($IPCreturn != GOOD) {return $IPCreturn;}
        
        # Copy the default RSHD executible to server
        #print `copy common\\rsh\\\* $hosts\\$share\n`;
        
        # Install the RSHD service on the server
        $IPCreturn = IPCClient($host, "$dir\\rshd\\rshd /install\n");
        if ($IPCreturn != GOOD) {return $IPCreturn;}
        
        # Start the RSHD service on the server
        $IPCreturn = IPCClient($host, "$dir\\rshd\\rshd /rsh /rcp /L /d $dir\\rshd\\connect.log /start\n");
        if ($IPCreturn != GOOD) {return $IPCreturn;}
        
        # Add User to the RSHD service on the server
        $IPCreturn = IPCClient($host, "$dir\\rshd\\rshd /au $user/$user\n");
        if ($IPCreturn != GOOD) {return $IPCreturn;}
        
    }
    return GOOD;
}

##############################################################################
#
#          Name: RSH 
#
#        Inputs: Host Server IP or Name, User name, Command
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Will make a sytem call to RSH with the given inputs
#
##############################################################################
sub RSH
{
    my ($host, $user, $cmd) = @_;

    my $evalReturn = eval "print `rsh $host -l $user $cmd`";

    #
    # Check for errors returned from eval.
    #
    if ($@)
    {
        # Check to see if the command was found.
        if ($@ =~ /bareword "$cmd" not allowed/i)
        {
            TestLibs::Logging::logWarning("The specified command ($cmd) is not valid.");
        }
        else
        {
            # The command was found, but some other error occurred.
            TestLibs::Logging::logWarning("Eval Error Output: $@");
        }
        return ERROR;
    }
    
    # If the command failed, log an error.
    unless ( defined($evalReturn) && ($evalReturn == GOOD) )
    {
        TestLibs::Logging::logWarning ("Error Runnning Command: $cmd");
        return ERROR;
    };

    return GOOD;
}

##############################################################################
#
#          Name: RCP 
#
#        Inputs: Host Server IP or Name, User name, Source Files, Target Files, Options
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Will make a sytem call to RCP with the given inputs
#
#   Note: The target directory is relative to the home directory for the RCP user
#
# The following are options for rcp under windows (check your specific usage)
# 
# Copies files to and from computer running the RCP service.
#
# RCP [-a | -b] [-h] [-r] [host][.user:]source [host][.user:] path\destination
#
#  -a                 Specifies ASCII transfer mode. This mode converts
#                     the EOL characters to a carriage return for UNIX
#                     and a carriage
#                     return/line feed for personal computers. This is
#                     the default transfer mode.
#  -b                 Specifies binary image transfer mode.
#  -h                 Transfers hidden files.
#  -r                 Copies the contents of all subdirectories;
#                     destination must be a directory.
#  host               Specifies the local or remote host. If host is
#                     specified as an IP address OR if host name contains
#                     dots, you must specify the user.
#  .user:             Specifies a user name to use, rather than the
#                     current user name.
#  source             Specifes the files to copy.
#  path\destination   Specifies the path relative to the logon directory
#                     on the remote host. Use the escape characters
#                     (\ , ", or ') in remote paths to use wildcard
#                     characters on the remote host.
#
##############################################################################
sub RCP
{
    my ($host, $user, $source, $target, $options) = @_;

    print "rcp $options $source $host\.$user\:$target\n";
    my $evalReturn = eval {print `rcp $options $source $host\.$user\:$target`};

    #
    # Check for errors returned from eval.
    #
    if ($@)
    {
        TestLibs::Logging::logWarning("Eval Error Output: $@");
        return ERROR;
    }
    
    # If the command failed, log an error.
    unless ( defined($evalReturn) && ($evalReturn == GOOD) )
    {
        TestLibs::Logging::logWarning ("Error Runnning RCP Command.");
        return ERROR;
    };

    return GOOD;
}

###############################################################################

1;

__END__

=head1 NAME

TestLibs::Remote - Perl Functions to work with remote servers

$Id: Remote.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SYNOPSIS

    use TestLibs::Remote;

    # simple call from the client to the server(10.198.162.1)
    $return = IPCClient("10.198.162.1", "dir");

    # simple call from the client to the server(Lab1_server_13)
    $return = IPCClient("Lab1_server_13", "dir");

=head1 DESCRIPTION

Functions Available
    IPCClient

=head1 NAME

IPCClient - Client Side of a simple Server/Client application

$Id: Remote.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=over

=item Linux
=item Windows 

=back

=head1 SYNOPSIS

=head2 Server Side

    Run the following on the server:
    IPCServer.pl

=head2 Client Side

    On the client side, scripts can use the function IPCClient found in the 
    Remote.pm module to communicate with the server.

=head1 DESCRIPTION

This simple server/client application opens a TCP socket on the server listening on 
the port specified at the begining of the IPCServer.pl script.  The client sends commands via the
socket which get run on the servers command shell.  The standard output and stand
error are sent back to the client, which prints it to the local STDOUT.

This application has NO securtiy. Therfore, it should not be used on servers that may be compromised.

=cut
