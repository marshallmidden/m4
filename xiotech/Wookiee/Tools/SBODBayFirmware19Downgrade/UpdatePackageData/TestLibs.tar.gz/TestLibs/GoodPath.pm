#! /usr/bin/perl s
# $Header$
##############################################################################
# File name:  TestLibs::GoodPath
#
# Desc: A set of library functions for integration testing. These focus on
#       controller configuration changes.
#
# Date: 07/31/2002
#
# Original Author:  Craig Menning
#
# Last modified by  $Author: RysavyR $
# Modified date     $Date: 2005-05-04 13:53:47 -0500 (Wed, 04 May 2005) $
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::GoodPath - Perl Tests to do simple configuration regression

$Id: GoodPath.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    
    <LI>Linux</LI>

    <LI>Windows</LI>

</UL>

=end html

=head1 SYNOPSIS

This document describes use and function of several 'good path' or
'robustness' tests.

=head1 DESCRIPTION

Test Scripts Available:
        GoodPathIOTest(),  
        GoodPathSubset1(),  
        GoodPathSuperset(),  
        GoodPathTest(),
        InitUntilRaidsWait()

=cut

#                         
# - what I am
#

package TestLibs::GoodPath;

#
# - other modules used
#

use warnings;
use lib "../CCBE";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::IntegCCBELib;
#use TestLibs::IntegXMCLib;
#use XIOtech::sanscript;
use TestLibs::utility;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                      &GoodPathIOTest
                      &GoodPathSubset1
                      &GoodPathSuperset
                      &GoodPathTest

                      &InitUntilRaidsWait

                      &TBD5
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;

###############################################################################

=head1 Good Path Tests

The following tests are generic 'good path' tests. They check operation
of the various commands supported by the controller. If a command generates
an error, the test will stop.

=cut

###############################################################################

=head2 GoodPathIOTest

This test runs on a single controller. It can be run while IO is running
and will not destroy any existing configuration. It can be considered a 
replacement for the old robustness test.

=cut

=over 1

=item Usage:

 my $rc = GoodPathIOTest($ctlr, $option, $wwnList);
 
 where $ctkl is a pointer to a controller object
       $option is unused and should be set to 0
       $wwnList is pointer to a list of server WWNs and is
               currently unused

       

=item Returns:

       $rc will be GOOD if all tests pass or INVALID or ERROR if failed

=item Description:
 
 Calls GoodPathSubset1(), then
 Calls GPCreateExpandDelete() for 10 loops

    GPCreateExpandDelete creates, expands, starts initialzation and 
    then deletes vdisks. All are RAID 5.

    (If GPCreateExpandDelete2 is called, then the vdisks are RAID 10.)

=back

=cut

##############################################################################
#
#          Name: GoodPathIOTest
#
#        Inputs: controller object, (unused option), list of server wwns
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Controller tests that can be done while IO is running   
#
#
##############################################################################
sub GoodPathIOTest
{
    trace();
    my ($ctlr, $option, $wwnList) = @_;
    
    my $ret;
    my $loops1;
    my $loops2;
    my $i;

    $loops1 = 10;
    $loops2 = 10;

    ##################
    # basic good path
    ##################
    $ret =  GoodPathSubset1($ctlr, $option, $wwnList);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path subset  test <<<<<<<<");
        return (ERROR);
    }

    for ( $i = 0; $i < $loops1; $i++ )
    {
        ################################
        # create/expand/delete vdisks
        ################################

        $ret = GPCreateExpandDelete($ctlr);     # does several passes itself
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failure in create/expand/init/delete vdisk test <<<<<<<<");
            return (ERROR);
        }
    }
    return GOOD;
}
###############################################################################

=head2 GoodPathSubset1

This test runs on a single controller. It can be run while IO is running
and will not destroy any existing configuration. There should be some 
vdisks configured.  

=cut

=over 1

=item Usage:

 my $rc = GoodPathSubset1($ctlr, $option, $wwnList);
 
 where $ctlr is a pointer to a controller object
       $option is unused and should be set to 0
       $wwnList is pointer to a list of server WWNs and is
               currently unused. 

       

=item Returns:

       $rc will be GOOD if all tests pass or INVALID or ERROR if failed

=item Description:
 
 Calls GPModes()
          Gets and displays mode bits
          Sets the no suicide bits
          Gets and redisplays the mode bits

 Calls GPDeviceStatus()
          Get and display device status "VD" data
          Get and display device status "RD" data
          Get and display device status "PD" data

 Calls GPDiskBayCommands()
          Get and disply the disk bay count
          Get and display the disk bay list
          Get and display diskbay information for each disk bay
          Get and display diskbays data
          Get and display disk bay status

 Calls GPCaching()
          Gets a list of the vdisks
          For each vdisk...
              Gets vdisk info to display the current cacheing state
              Toggles the cache bit
              Toggles the cache bit again to return to the original state
          Reads global cache info to get its stats
          Toggle the cache bit
          Toggles the cache bit again to return to the original state

 Calls GPRaidCommands()
          Get and display the number of raid devices
          Get and display a list of raid devices
          For each raid device...
              Get and display raid info data
              (commented out) Perform raid beacon
          Get and dispaly 'raids' data
          Get and display server information for each server

 Calls GPServerCommands()
          Get and display the number of servers
          Get and display a list of the servers
          Get and display a list of vdisks
          Associate all vdisks to server (sid) 0
          Disassociate all vdisks from server 0
          Get and display 'servers' data


 Calls GPMiscCommands()
          Get and display the firmware version
          Do a memory read on each of the three processors
          Get and display the controller and group serial numbers
          Re-write the serial number and display it
          Set the MRP timeout to 400 seconds
          Set the MRP timeout to 30 seconds
          For each Qlogic card on each processor
              Get and display the device list

 Calls GPFidRead()
          Reads FID 2 and displays 1024 bytes

 Calls GPStatsCommands()
          Get and display environmental stats data
          Get a list of server IDs (may not be displayed)
          For each server id...
              Get and display statsserver data
          Get and display a list of vdisks
          For each vdisk...
              Get and display statscachedevices[vdisk] ddata
          Get and display BE statsPCI data
          Get and display FE statsPCI data
          Get and display BE statsProc data
          Get and display FE statsProc data
          For each QLogic card and processor...
              Get and dispaly statsloop data

 Calls GPLoggingTest()
          Reads and prints 50 log entries on the short format.
          Reads and prints 100 log entries in the long format.

 Calls GPMemoryLeakTest()
          Reads and prints memory leak data for the heap. Not checked.


=back

=cut

##############################################################################
#
#          Name: GoodPathSubset1
#
#        Inputs: controller object, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Emulation of the good_path.pl script, only those that 
#                won't trash concurrent IO (is this the new robustness 
#                script?)   
#
#
##############################################################################
sub GoodPathSubset1
{
    my ($ctlr, $option, $wwnList) = @_;
    
    my $ret;
    
    $ret = GPModes($ctlr);      # first, as it turns off no suicide bit
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path mode bits test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDeviceStatus($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path device status test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDiskBayCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Disk Bay Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPCaching($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path caching test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPRaidCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Raid Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPServerCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Server Commands test  <<<<<<<<");
        return (ERROR);
    }


    $ret = GPMiscCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path misc. Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPFidRead($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path FID read test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPStatsCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path statistics Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPLoggingTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Logging test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPMemoryLeakTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path memory leak test <<<<<<<<");
        return (ERROR);
    }

    return GOOD;
}

###############################################################################

=head2 GoodPathSuperset

This test runs on a single controller. The must be no I/O running and any
existing configuration will be destroyed. 

=over 1

=item Usage:

 my $rc = GoodPathSubset1($ctlr, $option, $wwnList);
 
 where $ctlr is a pointer to a controller object
       $option bitmapped as defined below.
       $wwnList is pointer to a list of server WWNs. 

       ($option is currently unused but should be set to 0)

=item Returns:

       $rc will be GOOD if all tests pass or INVALID or ERROR if failed

=item Description:
 
 to clean up the configuration...

 Calls DisassocAll()
           Removes all server and vlink associations

 Calls DeleteAllVdisks2()
           Deletes all vdisks and vlinks

 Calls LabelSingleDrive()
           To unlabel all pdisks
 
 then...

 Calls GoodPathTest()
 
 then, for 10 loops...   

 Calls GPReal1Way()
            Creates a 1 way configuration by first destroying 
            any current configuration, then labeling disks, creating
            vdisks, initializing them, associating them to servers 
            ( based on the WWN list) and then displaying the final 
            configuration.

 then, for 10 loops...

 Calls GPCreateExpandDelete()

    GPCreateExpandDelete creates, expands, starts initialzation and 
    then deletes vdisks. All are RAID 5.

    (If GPCreateExpandDelete2 is called, then the vdisks are RAID 10.)


 
 then, to show the final state of the controller...
 
 Calls ConfigView()
         Gets and displays powerupstate
         Rescans the BE
         Gets and displays targetstatus data
         Get and display datstat PD data
         Get and display vdisks data
         Get and display vcg info data 

 Calls DispVdisksRaids()
         Gets and display 'vdisks' data
         Gets and displays 'raids' data

=back

=cut


##############################################################################
#
#          Name: GoodPathSuperset
#
#        Inputs: controller object, (unused option), list of server wwns
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Extended version of good path, 1 way regression   
#
#
##############################################################################
sub GoodPathSuperset
{
    my ($ctlr, $option, $wwnList) = @_;
    
    my $ret;
    my $loops1;
    my $loops2;
    my $i;

    $loops1 = 10;
    $loops2 = 10;

    #########################################
    # clean up anything from previous tests
    #########################################

    $ret = DisassocAll ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to disassociate all servers <<<<<<<<");
        return (ERROR);
    }
    
    $ret = DeleteAllVdisks2 ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to delete all vdisks <<<<<<<<");
        return (ERROR);
    }

    $ret = LabelSingleDrive ( $ctlr, 0xffff, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to unlabel all drives <<<<<<<<");
        return (ERROR);
    }


    ##################
    # basic good path
    ##################
    $ret =  GoodPathTest($ctlr, $option, $wwnList);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path  test <<<<<<<<");
        return (ERROR);
    }
    
    for ( $i = 0; $i < $loops1; $i++ )
    {

        ################################
        # configure a 1 way many times
        ################################
        $ret = GPReal1Way($ctlr, $wwnList, 2);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failure creating 1 way configuration <<<<<<<<");
            return (ERROR);
        }
    }

    for ( $i = 0; $i < $loops2; $i++ )
    {

        ################################
        # create/expand/delete vdisks
        ################################

        $ret = GPCreateExpandDelete($ctlr);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failure in create/expand/init/delete vdisk test <<<<<<<<");
            return (ERROR);
        }
    }

#    ##########################
#    # basic good path - again    This will fail as the pdisks are labelled
#    ##########################
#    $ret =  GoodPathTest($ctlr, $option, $wwnList);
#    if ( $ret == ERROR )
#    {
#        logError(">>>>>>>> Failure in good path  test <<<<<<<<");
#        return (ERROR);
#    }
#



    #####################
    # show what is there
    #####################

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }

    $ret = DispVdisksRaids($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to display vdisks and raids <<<<<<<<");
        return (ERROR);
    }


    return GOOD;
}

###############################################################################

=head2 GoodPathTest

This test runs on a single controller. It assumes that the controller is 
unconfigured, but has a license.  

=cut

=over 1

=item Usage:

 my $rc = GoodPathTest($ctlr, $option, $wwnList);
 
 where $ctkl is a pointer to a controller object
       $option is unused and should be set to 0
       $wwnList is pointer to a list of server WWNs and is
               currently unused. 

       

=item Returns:

       $rc will be GOOD if all tests pass or INVALID or ERROR if failed

       Pass or fail id determined by successful execution of the commands
       and not on the content of the data returned.

=item Description:
 
 Calls GPModes()
          Gets and displays mode bits
          Sets the no suicide bits
          Gets and redisplays the mode bits

 Calls GPDeviceStatus()
          Get and display device status "VD" data
          Get and display device status "RD" data
          Get and display device status "PD" data

 Calls GPResetTest()
          One at a time...
              Reset each QLogic card on the FE
          One at a time...
              Reset each QLogic card on the BE
          Reset ALL QLogic cards on the FE
          Reset ALL QLogic cards on the BE
          Pause 10 seconds

 Calls GPMiscCommands()
          Get and display the firmware version
          Do a memory read on each of the three processors
          Get and display the controller and group serial numbers
          Re-write the serial number and display it
          Set the MRP timeout to 400 seconds
          Set the MRP timeout to 30 seconds
          For each Qlogic card on each processor
              Get and display the device list


 Calls GPDiskBayCommands()
          Get and disply the disk bay count
          Get and display the disk bay list
          Get and display diskbay information for each disk bay
          Get and display diskbays data
          Get and display disk bay status

 Calls GPPhysicalDiskCommands()
          Rescan the BE
          Get and display the number of pdisks
          Get and display a list of pdisks
          For each pdisk...
              (commented out) Do a pdisk beacon
              Get and display pdiskinfo data
              Label each drive as a data disk
          Unlabel all pdisks
          Make all drives data (as a group)
          Get and display devstat PD data
          Get and display pdisks data     
          For each of the raid types...
              Call calcraidparms
              Creates a vdisk
              Expands the vdisk
              Initializes the vdisk
              Gets vdisk information
          Calls GPVdiskMisc to do the following...
              Get and display a count of the vdisks
              Get and display the vdisk list
              Get and display the virtualdisks data (vdisks)


 Calls GPVirtualDiskCommands()
          Uses all raid types for in the following
          Unlabels all pdisks
          Labels all pdisks as data
          Get a list of pdisks (may not display)


 Calls GPRaidCommands()
          Get and display the number of raid devices
          Get and display a list of raid devices
          For each raid device...
              Get and display raid info data
              (commented out) Perform raid beacon
          Get and dispaly 'raids' data
          Get and display server information for each server

 Calls GPTargetCommands()
          Get and display the target count
          Get and display targetstatus data
          Get and display a target list
          Get and display target info for each target
          Get and display 'targets' data



 Calls GPServerCommands()
          Get and display the number of servers
          Get and display a list of the servers
          Get and display a list of vdisks
          Associate all vdisks to server (sid) 0
          Disassociate all vdisks from server 0
          Get and display 'servers' data


 Calls GPFidRead()
          Reads FID 2 and displays 1024 bytes

 Calls GPCaching()
          Gets a list of the vdisks
          For each vdisk...
              Gets vdisk info to display the current cacheing state
              Toggles the cache bit
              Toggles the cache bit again to return to the original state
          Reads global cache info to get its stats
          Toggle the cache bit
          Toggles the cache bit again to return to the original state

 Calls GPDeviceStatus()
          Get and display device status "VD" data
          Get and display device status "RD" data
          Get and display device status "PD" data

 Calls GPStatsCommands()
          Get and display environmental stats data
          Get a list of server IDs (may not be displayed)
          For each server id...
              Get and display statsserver data
          Get and display a list of vdisks
          For each vdisk...
              Get and display statscachedevices[vdisk] ddata
          Get and display BE statsPCI data
          Get and display FE statsPCI data
          Get and display BE statsProc data
          Get and display FE statsProc data
          For each QLogic card and processor...
              Get and dispaly statsloop data

 Calls GPLoggingTest()
          Reads and prints 50 log entries on the short format.
          Reads and prints 100 log entries in the long format.

 Calls GPMemoryLeakTest()
          Reads and prints memory leak data for the heap. Not checked.




=back

=cut


##############################################################################
#
#          Name: GoodPathTest
#
#        Inputs: controller object, option, wwn list pointer
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Emulation of the good_path.pl script   
#                Note: this must not require real servers to be attached
#                or their WWNs be known. THis requirement is for the code
#                building process for the CCB code
#
##############################################################################
sub GoodPathTest
{
    trace();
    my ($ctlr, $option, $wwnList) = @_;
    
    my $ret;
    

    $ret = GPModes($ctlr);      # first, as it turns off no suicide bit
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path mode bits test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDeviceStatus($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path device status test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPResetTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path QL reset test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPMiscCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path misc. Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDiskBayCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Disk Bay Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPPhysicalDiskCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Physical Disk test <<<<<<<<");
        return (ERROR);
    }
    
    $ret = GPVirtualDiskCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Virtual Disk test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPRaidCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Raid Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPTargetCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Target Commands test <<<<<<<<");
        return (ERROR);
    }


    $ret = GPServerCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Server Commands test  <<<<<<<<");
        return (ERROR);
    }
    
    $ret = GPFidRead($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path FID read test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPCaching($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path caching test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDeviceStatus($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path device status test <<<<<<<<");
        return (ERROR);
    }
    
#    $ret = GPReal1Way($ctlr, $wwnList, 2);       # may fail for missing SIDs 
#    if ( $ret == ERROR )
#    {
#        logError(">>>>>>>> Failure in good path 1 way config test <<<<<<<<");
#        return (ERROR);
#    }

    $ret = GPStatsCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Stats test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPLoggingTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Logging test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPMemoryLeakTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path memory leak test <<<<<<<<");
        return (ERROR);
    }






    return GOOD;
}
#################################################################################


##############################################################################
#
#          Name: InitUntilRaidsWait
#
#        Inputs: master controller object
#
#       Outputs: GOOD if no error, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Initializes raids on the VCG with the specified master until
#                some raids are waiting to begin initialization.  Once this 
#                occurs, the test waits until all initializations have 
#                completed.
#
##############################################################################
sub InitUntilRaidsWait
{ 
    my $ctlr = $_[0];

    my %ridsHash;

    my @initRaids;

    #
    # Get the vdisk list and see if an error occurred. 
    #
    logInfo("Getting a list of vdisks on the system...");
    my @vdiskList = GetVdiskList($ctlr);
    if ($vdiskList[0] == INVALID)
    {
        logInfo(">>>>>>>> Failed to get the list of vdisks on the system <<<<<<<<");
        return ERROR;    
    }

    if (@vdiskList > 0)
    {
        #
        # Get the RID's for each Vdisk now so that it doesn't take time to do
        # so later.
        #
        logInfo("Getting the RIDS for each vdisk in the system...");
        foreach my $vdisk (@vdiskList)
        { 
            my @rids = _getVdiskRIDS($ctlr, $vdisk);
            if ($rids[0] == INVALID)
            {
                logInfo(">>>>>>>> Error getting vdisk $vdisk <<<<<<<<");
                return ERROR;
            }
            else
            {
                $ridsHash{"$vdisk"} = \@rids;
            }
        }
        
        logInfo("Initializing vdisks until some raids are waiting for initialization...");
        my $continue = TRUE;
        while ($continue)
        {                                    
            #
            # Decide how many inits to do sequentially
            # This is done so that if possible, waiting for other raids
            # to start initialization happens faster.
            #
            my $sequentialInits = 1;
            if (@vdiskList >= 5)
            {
                $sequentialInits = 5;
            }
            elsif (@vdiskList >= 2)
            {
                $sequentialInits = 2;
            }

            my $initVdisk;
            for (my $inits = 0; $inits < $sequentialInits; $inits++)
            {
                #
                # Start a Vdisk initialization.
                #
                $initVdisk = shift @vdiskList;
                logInfo("\n==>Initializing vdisk $initVdisk...");
                if (InitVdiskRids($ctlr, $initVdisk) == ERROR)
                {
                    logInfo(">>>>>>>> Failed to initialize vdisk $initVdisk <<<<<<<<");
                    return ERROR;
                }

                #
                # Save the RID's that were initialized.
                #
                my @rids = @{$ridsHash{"$initVdisk"}};
                foreach my $rid (@rids)
                {
                    #
                    # If the item is not in the array, then add the item.
                    #
                    if (!_isInArray($rid, \@initRaids))
                    {
                        push @initRaids, $rid;    
                    }
                } 
            }       

            #
            # Check to see if any of the raids just initialized are waiting 
            # for their initialization to start.
            #
            my $waiting = _anyRaidsWaitingForInit($ctlr, $ridsHash{"$initVdisk"});
            if ($waiting == TRUE)
            {
                #
                # At least one raid is waiting for init.
                #
                logInfo("\nAt least one raid is waiting for initialization...");
                logInfo("");

                #
                # If possible, initialize another raids to increase the
                # number of waiting raids.
                #
                logInfo("If more uninitialized vdisks exist, some will be initialized to increase the number of waiting raids...");
                if (@vdiskList != 0)
                {
                    #
                    # Find out how many more vdisk should be initialized.
                    #
                    my $vdisksToInit = 1;
                    if (@vdiskList >= 2)
                    {
                        $vdisksToInit = 2;
                    }

                    for (my $i = 0; $i < $vdisksToInit; $i++)
                    {
                        #
                        # Initialize another vdisk.
                        #
                        my $initVdisk = shift @vdiskList;
                        logInfo("\n==>Initializing vdisk $initVdisk...");
                        if (InitVdiskRids($ctlr, $initVdisk) == ERROR)
                        {
                            logInfo(">>>>>>>> Failed to initialize vdisk $initVdisk <<<<<<<<");
                            return ERROR;
                        }

                        #
                        # Save the RID that was initialized.
                        #
                        my @rids = @{$ridsHash{"$initVdisk"}};
                        foreach my $rid (@rids)
                        {
                            #
                            # If the item is not in the array, then add the item.
                            #
                            if (!_isInArray($rid, \@initRaids))
                            {
                                push @initRaids, $rid;    
                            }
                        }
                    }            
                }

                $continue = FALSE;
            }
            elsif ($waiting == INVALID)
            {
                logInfo(">>>>>>>> Error trying to find out if any raids are waiting for initialization to start <<<<<<<<");
                return ERROR;
            }
            else
            {
                #
                # No raids are waiting for init yet.
                #
                if (@vdiskList == 0)
                {
                    logInfo(">>>>>>>> No raids are waiting for initialization to start and there are no raids left to initialize that haven't already been initialized <<<<<<<<");
                    logInfo(">>>>>>>> Add more raids to the system and try again or simply just try again <<<<<<<<");
                    return ERROR;
                }
            }
        }

        #
        # At this point, we just need to wait for the raids to finish their initialization.
        #
        logInfo("\nWaiting for any initialing raids to finish...");
        my $stillInit;
        do
        {
            if (_showRaidsInitProgess($ctlr, \@initRaids) == ERROR)
            {
                logInfo(">>>>>>>> Error showing the raids initializaion progress <<<<<<<<");
                return ERROR;
            }
            logInfo("");
            DelaySecs(5);
        }
        while ($stillInit = _areAnyRaidsInitializing($ctlr, \@initRaids) == TRUE);

        #
        # Check why the loop stopped.
        #
        if ($stillInit == INVALID)
        {
            logInfo(">>>>>>>> Error finding out if any raids are still initializing <<<<<<<<");
            return ERROR;
        }
        
        #
        # Show that the raids have finished initializing.
        #
        _showRaidsInitProgess($ctlr, \@initRaids);

        #
        # If we are at this point, then we are done.
        #  
        logInfo("\nAll raids have finished initializing.");
    }
    else
    {
        logInfo(">>>>>>>> No vdisks were found.  At least one vdisk is needed to run this test <<<<<<<<");
        return ERROR;
    }

    return GOOD;

    ##################### Subfunctions #########################

    ##############################################################################
    #
    #          Name: _showRaidsInitProgess
    #
    #        Inputs: controller object, reference to raid array
    #
    #       Outputs: GOOD if no error, ERROR otherwise
    #
    #  Globals Used: none
    #
    #   Description: Displays the current initialization status for each RID in
    #                the specified array.
    #
    ##############################################################################
    sub _showRaidsInitProgess
    {
        my $ctlr = $_[0];        # The controller.
        my $refRaids = $_[1];    # Reference to RID array.
    
        logInfo("Raid initialization progress...");
        my $percentLeft;
        foreach my $rid (@$refRaids)
        {
            $percentLeft = _checkRaidInitProgress($ctlr, $rid);
            if ($percentLeft == INVALID)
            {
                logInfo(">>>>>>>> Checking raid $rid initialization progress failed <<<<<<<<");
                return ERROR;    
            }

            logInfo("RID: $rid, " . $percentLeft . "% left to initialize");
        }

        return GOOD;
    }

    ##############################################################################
    #
    #          Name: _anyRaidsWaitingForInit
    #
    #        Inputs: controller object, reference to raid array
    #
    #       Outputs: TRUE if any raids in the specified list are waiting for an
    #                initialization to start (that is, their init has been deferred).
    #                INVALID if an error occurs, otherwise, FALSE.
    #
    #  Globals Used: none
    #
    #   Description: Finds out if any raid in the specifed array is waiting for an
    #                initialization to start.
    #
    ##############################################################################
    sub _anyRaidsWaitingForInit
    {
        my $ctlr = $_[0];        # The controller.
        my $refRaids = $_[1];    # Reference to RID array.

        my $waiting = FALSE;     
    
        #
        # Go through each raid in the array.
        #
        foreach my $rid (@$refRaids)
        {
            my $percentLeft = _checkRaidInitProgress($ctlr, $rid);

            if ($percentLeft == INVALID)
            {
                logInfo(">>>>>>>> Error getting raid $rid initialization progress <<<<<<<<");
                return INVALID;
            }

            if ($percentLeft == 100)
            {
                #
                # At least one raid was waiting...stop the loop.
                #
                $waiting = TRUE;
                last;
            }
        }

        return $waiting;
    }


    ##############################################################################
    #
    #          Name: _areAnyRaidsInitializing
    #
    #        Inputs: controller object, reference to raid array
    #
    #       Outputs: TRUE if any raids in the specified list are initializing
    #                INVALID if an error occurs, otherwise, FALSE.
    #
    #  Globals Used: none
    #
    #   Description: Finds out if any raid in the specifed array is still
    #                initializing.
    #
    ##############################################################################
    sub _areAnyRaidsInitializing
    {
        my $ctlr = $_[0];        # The controller.
        my $refRaids = $_[1];    # Reference to RID array.

        my $raidsStillInit = FALSE;     
    
        #
        # Go through each raid in the array.
        #
        foreach my $rid (@$refRaids)
        {
            my $percentLeft = _checkRaidInitProgress($ctlr, $rid);

            if ($percentLeft == INVALID)
            {
                logInfo(">>>>>>>> Error getting raid $rid initialization progress <<<<<<<<");
                return INVALID;
            }

            if ($percentLeft != 0)
            {
                #
                # At least one raid was initializing...stop the loop.
                #
                $raidsStillInit = TRUE;
                last;
            }
        }

        return $raidsStillInit;
    }


    ##############################################################################
    #
    #          Name: _getVdiskRIDS
    #
    #        Inputs: controller object, vdisk ID
    #
    #       Outputs: array of RIDS or INVALID as the first element if an error
    #                occurred
    #
    #  Globals Used: none
    #
    #   Description: Returns an array of the RID's that make up the specified
    #                vdisk.
    #
    ##############################################################################  
    sub _getVdiskRIDS
    {
        my $ctlr = $_[0];
        my $vdd = $_[1];
        my %ret;

        %ret = $ctlr->virtualDiskInfo($vdd);

        #
        # Check to see if there was a return from the call.
        #
        if ( ! %ret  )            
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
            return (INVALID);
        }

        #
        # Check to see if the call returned an error.
        #
        if ( $ret{STATUS} != PI_GOOD )     
        {
            logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
            PrintError(%ret);
            return (INVALID);
        }
    
        #
        # Put each raids ID in the return array.
        #
        my @raids;               
        my $totalRaids = $ret{RAIDCNT};    
        for (my $j = 0; $j < $totalRaids; $j++)
        {        
            $raids[$j] = $ret{RIDS}[$j];
        }
         
        return @raids;
    }


    ##############################################################################
    #
    #          Name: _getVdiskRIDS
    #
    #        Inputs: controller object, RID
    #
    #       Outputs: the percent complete that is occurring on the specified
    #                raid.  Note: INVALID is returned if an error occurred.
    #
    #  Globals Used: none
    #
    #   Description: Gets the init percent for the specified RID.
    #
    ############################################################################## 
    sub _checkRaidInitProgress
    {
        my $controller = $_[0];  # The controller to use.
        my $rid = $_[1];         # The RID to check init progress on.
    
        #
        # Get the raid info.
        #
        my %rsp = $controller->virtualDiskRaidInfo($rid);

        #
        # Check to see if there was a response.
        #
        if ( ! %rsp )
        {
            logInfo(">>>>>>>> Failed to get raidinfo status <<<<<<<<");
            return INVALID;
        }

        #
        # Check to see if the call returned an error.
        #
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error getting raidinfo status <<<<<<<<");
            return INVALID
        }

        return $rsp{PCTREM}; 
    }

    ##############################################################################
    #
    #          Name: _isInArray
    #
    #        Inputs: item to find, reference to array to search
    #
    #       Outputs: TRUE if the item was found, FALSE otherwise.
    #
    #  Globals Used: none
    #
    #   Description: Finds out if the specified item is in the specified array.
    #
    ##############################################################################
    sub _isInArray
    {
        my $itemToFind = $_[0];      # Item to find.
    
        my $refArrayToSearch = $_[1]; # Reference to the array to search.

        my $result = FALSE;          # This is set to true if the item was found.

        #
        # Search for the item.
        #
        my $index = 0;
        while ( ($result == FALSE) && ($index < @$refArrayToSearch) )
        {
            if ($$refArrayToSearch[$index] eq $itemToFind)
            {
                $result = TRUE;    
            }

            $index++;
        }

        return $result;
    }

    ################## End Subfunctions ########################
}


1;   # we need this for a PM

__END__

=head1 CHANGELOG

 $Log$
 Revision 1.1  2005/05/04 18:53:52  RysavyR
 Initial revision

 Revision 1.5  2002/08/22 15:14:31  ThiemannE
 Added InitUnitsRaidsWait function.
 Reviewed by Craigm.

 Revision 1.4  2002/08/08 19:19:00  MenningC
 TBOLT00000000 preldoc added

 Revision 1.3  2002/08/02 01:44:55  HouseK
 Added or corrected some POD (perldoc)

 Revision 1.2  2002/07/31 19:44:18  HouseK
 Result of merge from tag LOGGING_CHANGES

 Revision 1.1.2.1  2002/07/31 18:39:54  MenningC
 Tbolt00000000  new file

=cut
