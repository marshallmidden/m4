#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library
#
#   11/11/2005  XIOtech   Gopinadh Anasuri
#
#   A set of library functions for integration testing. 
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2005-2006 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::iscsi - Perl Tests to test iscsi feature

$Id: iscsi.pm 13583 2006-09-12 06:26:14Z AnasuriG $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing and setting iscsi.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones
               
               ConfigiSCSITargetParam
               ConfigiSCSIChapInfo
               GetiSCSIInfo
               GetiSCSIChapInfo
               GetiSCSIStats
               GetiSCSIServerStats
               long2ip
               ValidateTargetType 
        The less significant ones
               
               None   

=cut

#
# - what I am
#

package TestLibs::iscsi;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use XIOTech::cmVDisk;

use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;

use strict;

#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 13583 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker


    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &ConfigiSCSITargetParam
                        &ConfigiSCSIChapInfo
                        &GetiSCSIInfo
                        &GetiSCSIChapInfo
                        &GetiSCSIStats
                        &long2ip
                        &ValidateTargetType 
                        
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 13583 $);
}
    our @EXPORT_OK;

##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $objPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.


 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.


=back

=cut


###############################################################################

###############################################################################

=head2 GetiSCSIInfo function

This subroutine gets the iSCSI target information.

=cut

=over 1

=item Usage:

 my $rc = GetiSCSIInfo( $objPtr );
 
 where: $objPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controllers should be configured and Initiator should be started.
 
=back

=cut
##############################################################################
#
#          Name: GetiSCSIInfo
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine gets the iSCSI Target Information
#
##############################################################################
sub GetiSCSIInfo
{
    trace();

    my ( $objPtr, $targetid ) = @_;

    my $ctlr;
    my $master;
    my $msg;
    my %rsp;
    my @coList;

    #
    # Find the master controller
    #
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$objPtr;

    $ctlr = $coList[$master];

    if (!defined($targetid))
    {
        print "Invalid or missing Target ID.\n";
        return;
    }

    %rsp = $ctlr->iSCSITgtInfo($targetid);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            $msg = $ctlr->displayiSCSITgtInfo(%rsp);
            print "\n";
            print $msg;
        }
        else
        {
            my $msg = "Unable to get iSCSI target Info.";
            displayError($msg, %rsp);
        }
   }
    else
    {
        print "ERROR: Did not receive a response packet.\n";
        logout();
    }

    print "\n";
    
return GOOD;
}

###############################################################################

=head2 GetiSCSIChapInfo function

This subroutine gets the iSCSI chap information.

=cut

=over 1

=item Usage:

 my $rc = GetiSCSIChapInfo( $objPtr );
 
 where: $objPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controllers should be configured and Initiator should be started.
 
=back

=cut
##############################################################################
#
#          Name: GetiSCSIChapInfo
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine gets the iSCSI Target Chap User Information
#
##############################################################################
sub GetiSCSIChapInfo
{
    trace();

    my ( $objPtr, $targetid ) = @_;

    my $ctlr;
    my $master;
    my $msg;
    my %rsp;
    my @coList;

    #
    # Find the master controller
    #
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    @coList = @$objPtr;

    $ctlr = $coList[$master];
 

    if (!defined($targetid))
    {
        print "Invalid or missing Target ID.\n";
        return;
    }

    %rsp = $ctlr->iSCSIChapInfo($targetid);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            $msg = $ctlr->displayiSCSIChapInfo(%rsp);
            print "\n";
            print $msg;
        }
        else
        {
            my $msg = "Unable to get iSCSI target Chap Info.";
            displayError($msg, %rsp);
        }
   }
    else
    {
        print "ERROR: Did not receive a response packet.\n";
        logout();
    }

    print "\n";

    return GOOD;
}

###############################################################################

=head2 GetiSCSIStats function

This subroutine gets the iSCSI session information.

=cut

=over 1

=item Usage:

 my $rc = GetiSCSIStats( $objPtr );
 
 where: $objPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controllers should be configured and Initiator should be started.
 
=back

=cut
##############################################################################
#
#          Name: GetiSCSIStats
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine gets the iSCSI sessions statistics
#
##############################################################################
sub GetiSCSIStats
{
    trace();

    my ( $objPtr, $targetid ) = @_;

    my $ctlr;
    my $master;
    my $msg;
    my %rsp;
    my @coList;

    #
    # Find the master controller
    #
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    @coList = @$objPtr;

    $ctlr = $coList[$master];
 

    if (!defined($targetid))
    {
        print "Invalid or missing Target ID.\n";
        return;
    }

    %rsp = $ctlr->iSCSISessionInfo($targetid);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            $msg = $ctlr->displayiSCSIStats(%rsp);
            print "\nSession Stats:\n";
            print "\n TID : $targetid\n";
            print $msg;
        }
        else
        {
            my $msg = "Unable to get iSCSI session info.";
            displayError($msg, %rsp);
        }
   }
   else
   {
       print "ERROR: Did not receive a response packet.\n";
       logout();
   }

return GOOD;
}
    
###############################################################################

=head2 GetiSCSIServerStats function

This subroutine gets the iSCSI server statistics based on the server name.

=cut

=over 1

=item Usage:

 my $rc = GetiSCSIServerStats( $objPtr );
 
 where: $objPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controllers should be configured and Initiator should be started.
 
=back

=cut
##############################################################################
#
#          Name: GetiSCSIServerStats
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine gets the iSCSI server statistics
#
##############################################################################

sub GetiSCSIServerStats
{

    trace();

    my ( $objPtr, $sname ) = @_;

    my $ctlr;
    my $master;
    my $msg;
    my %rsp;
    my @coList;

    #
    # Find the master controller
    #
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    @coList = @$objPtr;

    $ctlr = $coList[$master];

    if (!defined($sname))
    {
        print "Invalid or missing Server Name.\n";
        return;
    }

    %rsp = $ctlr->iSCSIServerSessionInfo($sname);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            $msg = $ctlr->displayiSCSIStats(%rsp);
            print $msg;
        }
        else
        {
            my $msg = "Unable to get iSCSI Stats on server.";
            displayError($msg, %rsp);
        }
   }
    else
    {
        print "ERROR: Did not receive a response packet.\n";
        logout();
    }

    print "\n";
}
   
###############################################################################

=head2 ConfigiSCSITargetParam function

This subroutine sets the iSCSI target parameters.

=cut

=over 1

=item Usage:

 my $rc = ConfigiSCSITargetParam( $ctlr, $iscsiTargetId, 
                               $iscsiParamId, $iscsitargetParam ) ;
 
 where: $ctlr is a controller object
        $iscsiTargetId is Target Id to which IP Address has to be set
        $iscsiParamId is parameter Id of the value to be set
        $iscsitargetParam is the target parameter value

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controller needs to be configured and in powerupcomplete state.
 
=back

=cut
##############################################################################
#
#          Name: ConfigiSCSITargetParam
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine sets the iSCSI target parameters
#
##############################################################################

sub ConfigiSCSITargetParam()
{
    trace();

    my ( $ctlr, $iscsiTargetId, $iscsiParamId, $iscsiTargetParam ) = @_;

    my $tid;
    my $count;
    my $Ipcount = 0;
    my $IpAddressVal;
    my $IpVal;
    my $IpAddress;
    my %rsp;
    my %rsp1;
    my @targetId;
    my @paramId;
    my @targetParam;
    my @tIpAddress;
    my $targetParamVal;
    my $flag = 0;
    
    @targetId = @$iscsiTargetId;
    @paramId  = @$iscsiParamId;
    @targetParam = @$iscsiTargetParam;
    
    # 
    # Validate if ISCSI Target IP addresses are already configured with 
    # expected IP Addresses and if found return with out resetting IP 
    # Addresses again
    # 
    
    $count = scalar(@targetId);
    
    for ($tid = 0; $tid < $count; $tid++)
    { 
        # Validate port and check if it is ISCSI or FC based on which devicelist 
        # values are retrieved
        
        &TestLibs::iscsi::ValidateTargetType ($ctlr, $tid, \$flag); 
       
        if ( $flag == 0)
		{

        if($paramId[$tid] == 0 || $paramId[$tid] == 1 || $paramId[$tid] == 2)
        {
            %rsp = $ctlr->iSCSITgtInfo($targetId[$tid]);
    
            if($paramId[$tid] == 0)
            {
            	$IpAddress = long2ip(0,$rsp{ISCSITGTINFO}[0]{TGTIP});
            }
            elsif($paramId[$tid] == 1)
            {
                $IpAddress = long2ip(0,$rsp{ISCSITGTINFO}[0]{SUBNETMASK});
            }
            elsif($paramId[$tid] == 2)
            {
                $IpAddress = long2ip(0,$rsp{ISCSITGTINFO}[0]{GATEWAY});
            }

            my @tIpAddress = $ctlr->parseIP($targetParam[$tid]);
     
            my $l = @tIpAddress;

            if ($l != 4)
            {
                print "Invalid IP.\n";
                return;
            }
            if ($tIpAddress[0] >255 || $tIpAddress[1] >255 || $tIpAddress[2] >255 || $tIpAddress[3] >255)
            {
                print "Invalid IP.\n";
                return;
            }
        
            $IpAddressVal = ($tIpAddress[0]) + ($tIpAddress[1] << 8) + ($tIpAddress[2] << 16) + ($tIpAddress[3] << 24);
        
            my @IpAddr = $ctlr->parseIP($IpAddress);
        
            $IpVal = ($IpAddr[0]) + ($IpAddr[1] << 8) + ($IpAddr[2] << 16) + ($IpAddr[3] << 24);
        
            if ( $IpVal == $IpAddressVal )
            {
                $Ipcount++;
            }
        }
    }
    }
   
   # If found that IPAddress/GW/MASK are already configured with the values given 
   # in station file then return with out resetting the same values. 

   if ( $Ipcount == $count )
   {
        return GOOD; 
   }
   
   # Set respective targets with the target Param values 
   
    for ($tid = 0; $tid < $count; $tid++)
    {
        # Validate port and check if it is ISCSI or FC based on which devicelist 
        # values are retrieved
        
        &TestLibs::iscsi::ValidateTargetType ($ctlr, $tid, \$flag); 
       
        if ( $flag == 0)
		{
        if($paramId[$tid] == 0 || $paramId[$tid] == 1 || $paramId[$tid] == 2)
        {
            @tIpAddress = $ctlr->parseIP($targetParam[$tid]);
    
            my $m = @tIpAddress;
    
            if ($m != 4)
            {
                print "Invalid IP.\n";
                return;
            }
            if ($tIpAddress[0] >255 || $tIpAddress[1] >255 || $tIpAddress[2] >255 || $tIpAddress[3] >255)
            {
                print "Invalid IP.\n";
                return;
            }

            $targetParamVal = ($tIpAddress[0]) + ($tIpAddress[1] << 8) + ($tIpAddress[2] << 16) + ($tIpAddress[3] << 24);

        }
        else
        {
            $targetParamVal = $targetParam[$tid];
        }

        %rsp = $ctlr->iSCSISetTgtParam($targetId[$tid], $paramId[$tid], $targetParamVal);

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                logInfo("iSCSI parameter $paramId[$tid] for target $targetId[$tid] configured.\n");
            }
            else
            {
                logInfo(">>>>>>>> Unable to set iSCSI target parameter value. <<<<<<<<");
                return INVALID;
            }
        }
        else
        {
            print "ERROR: Did not receive a response packet.\n";
            logout();
        }
	}
        
    } # End of for loop
 
   return GOOD; 
    
}

###############################################################################

=head2 ConfigiSCSIChapInfo function

This subroutine sets the iSCSI CHAP information.

=cut

=over 1

=item Usage:

 my $rc = ConfigiSCSIChapInfo( $objPtr, $option, $iscsitargetid, 
                               $iscsiservername, $iscsisecret1, $iscsisecret2 );
 
 where: $objPtr is a pointer to a list of controller objects
        $option value is 0 to add secret and 1 to delete
        $iscsitargetid is Target Id to which CHAP will be configured
        $iscsiservername is name of server 
        $iscsisecret1 is a secret name for the server
        $iscsisecret2 is second secret name for the server

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controller needs to be configured and in powerupcomplete state.
 
=back

=cut
##############################################################################
#
#          Name: ConfigiSCSIChapInfo
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine configures iSCSI CHAP user information
#
##############################################################################

sub ConfigiSCSIChapInfo()
{
    trace();

    my ( $objPtr, $option, $iscsitargetid, $iscsiservername, $iscsisecret1, $iscsisecret2 ) = @_;

    my $ctlr;
    my $master;
    my $tid;
    my $count;
    my $scount = 0;
    my %rsp;
    my @opt;
    my @targetId;
    my @serverName;
    my @secret1;
    my @secret2;
    my @coList;
    my $secretval1;
    my $secretval2;
    my $sname;
    my $type;
   
    @opt         =  @$option;
    @targetId    =  @$iscsitargetid;
    @serverName  =  @$iscsiservername;
    @secret1     =  @$iscsisecret1;
    @secret2     =  @$iscsisecret2;
    
    # 
    # Find the master controller
    #
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    @coList = @$objPtr;

    $ctlr = $coList[$master];

    # 
    # Validate if ISCSI User CHAP information is already configured on targets
    # 
    
    $count = scalar(@targetId);
    
    # The check below will avoid the re-configuration of chap user information
    # if the same servername values are used in a station file for a target. 

    # If the count is more than one then values are passed from a station file 
    # else a single target is getting configured from single task menu which need 
    # not be verified before configuring.

    if ($count > 1) # This check is to allow the user to configure chap from single task Menu.
    {                
        for ($tid = 0; $tid < $count; $tid++)
        { 
            %rsp = $ctlr->iSCSIChapInfo($targetId[$tid]);

            $sname = $rsp{ISCSICHAPINFO}[0]{SNAME};

            if ($sname)
            {
                my @serverName1 = split /[\0]/, $sname;

                if ($serverName[$tid] eq $serverName1[0])
                {
                    $scount++;
                }
            }
        }
   
        # If found that targets are already configured with chap user information given
        # in the station file then return with out resetting the values.
        
        if ( $scount == $count )
        {
            return GOOD;
        }
    }
  
    for ($tid = 0; $tid < scalar(@targetId); $tid++) 
    {
        if($opt[$tid] == 0)
        {
            if (!defined($secret1[$tid]))
            {
                print "Invalid or missing secret.\n";
                return ERROR;
            }

            $secretval1 = $secret1[$tid];

            if(!defined($secret2[$tid]))
            {
                $type = 0;
                $secretval2 = "";
            }
            else
            {
                $type = 2;
                $secretval2 = $secret2[$tid];
            }
        }
        else
        {
            $type = 0;
            $secretval1 = "";
            $secretval2 = "";
        }

        %rsp = $ctlr->iSCSISetChap($opt[$tid], $targetId[$tid], $type, $serverName[$tid], $secretval1, $secretval2);

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                logInfo "CHAP User info configured on target ($targetId[$tid]).\n";
            }
            else
            {
                my $msg = "Unable to configure CHAP user info.";
                displayError($msg, %rsp);
            }
        }
        else
        {
            print "ERROR: Did not receive a response packet.\n";
            logout();
        }

        print "\n";
    }

    return GOOD;
}     
###############################################################################

=head2 ValidatetargetType

This subroutine validates the target type and then sets the flag as per the type.

This routine is created to make the scripts run for both iSCSI and FC only on FE. 
Since the ports 2 and 3 will be used for iSCSI on FE, The command devicelist will 
return error while trying to get the list of devices on port 2 and 3 when iSCSI is 
present.

=cut

=over 1

=item Usage:

 my $rc = ValidateTargetType ( $objPtr, $port, $flag);
 
 where: $objPtr is a pointer to a list of controller objects
        $port which needs to be validated for it type
        $flag is a reference variable which be returned a value calling subroutine

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controllers should be configured and targets present.
 
=back

=cut
##############################################################################
#
#          Name: ValidateTargetType
#
#        Inputs: controller, port, flag
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine validates the target type and sets the flag value 
#                as per the ISCSI (or) FC.
#
##############################################################################
sub ValidateTargetType 
{

   my( $ctlr, $port, $flag ) = @_;
   
   my $ttype;
   my %tgt;
    
    
        %tgt = $ctlr->targets();
    
        if ( ! %tgt  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from targets command <<<<<<<<");
            return ERROR;
        }
        
        if ( $tgt{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from targets command <<<<<<<<");
            PrintError(%tgt);
            return ERROR;
        }    
   
        for (my $i = 0; $i < $tgt{COUNT}; $i++)
        {
            if(($tgt{TARGETS}[$i]{TGD_OPT} & 0x80) > 0)
            {
                $ttype = "iSCSI";
            }
            else
            {
                $ttype = "FC";
            }    
   
            if ( $port == $tgt{TARGETS}[$i]{TGD_CHAN} )
            {
                if ($ttype eq "iSCSI")
                 {
                     $$flag = 0;
                     return GOOD;
                 }
                 elsif ($ttype eq "FC")
                 {
                     $$flag = 1;  
                     return GOOD;
                 }
                 else
                 {
                    logInfo(" Not iSCSI or FC Target");
                    return ERROR;
                 } 
            }

        } # for loop end
   return GOOD;
}

##############################################################################
# Name:     long2ip
#
# Desc:     Convert a long in network byte order to an IP address of
#           the form "X.X.X.X"
#
# Input:    long to be converted
#
# Return:   String IP address
##############################################################################
sub long2ip
{
    my ($self, $long) = @_;
    my $ip = "";

    if ((defined $long))
    {
        $ip = "" . (($long & 0xFF000000) >> 24) . "\." .
                   (($long & 0x00FF0000) >> 16) . "\." .
                   (($long & 0x0000FF00) >> 8) . "\." .
                   ($long & 0x000000FF) . "";
    }

    return $ip;
}

#########################################################################################################

##############################################################################

1;   # we need this for a PM

##############################################################################
=head1 CHANGE       LOG
        
##############################################################################
# Change log:
# $Log$
# Revision 1.8  2006/09/12 06:26:14  AnasuriG
# TBolt00015847 added iscsi targets configuration
#
# Revision 1.7  2006/05/31 11:21:21  AnasuriG
# updated as part of 750 changes
#
# Revision 1.6  2006/05/24 07:51:30  EidenN
# Moved from 750 Branch
#
# Revision 1.1.14.1  2006/02/24 14:17:25  MiddenM
#
# Merge from WOOKIEE_EGGS_GA_BR into MODEL750_BR
#
# Revision 1.5  2006/02/08 08:23:46  AnasuriG
# tBolt000000 Corrected Byte order for iSCSI
#
# Revision 1.4  2006/02/07 07:18:50  AnasuriG
# tBolt00013877: Fixed Host-to-Network order issue
#
# Revision 1.3  2006/01/27 08:43:38  AnasuriG
# Added ISCSICHAPSETINFO,ISCSICHAPGETINFO,ISCSISTATS commands configuration interface from XTC
#
# Revision 1.2  2006/01/23 11:40:10  AnasuriG
# Updated ISCSISETINFO command to set all parameters and added subroutines for ISCSICHAPGETINFO and ISCSISTATS
#
# Revision 1.1  2005/11/14 11:47:03  AnasuriG
# New file Created for iSCSI
#
##############################################################################
