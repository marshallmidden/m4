#! /usr/bin/perl s
# $Header$
####s##########################################################################
# File name:  TestLibs::Launcher
#
# Desc: A set of library functions for configuration of the XIOtech SAN device.
#
# Date: 07/26/2002
#
# Original Author:  Jeff Werning
#
# Last modified by  $Author: neal_eiden $
# Modified date     $Date: 2007-06-21 15:15:43 -0500 (Thu, 21 Jun 2007) $
#
#   It is expected that the user will write a perl script that calls 
#   these.  XTC.pl will be able to lanch these functions
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::Launcher - Perl Library to Launch Test Algorithms

$Id: Launcher.pm 25987 2007-06-21 20:15:43Z neal_eiden $

=head1 SYNOPSIS

This document describes usuage of a PERL Library to launch PERL Test scripts

=head1 DESCRIPTION

Launchers Available
    DefragTest

=cut

#                         
# - what I am
#

package TestLibs::Launcher;

#
# - other modules used
#

use warnings;
use TestLibs::BEUtils;
use TestLibs::UETest;
use TestLibs::BEStress;
use TestLibs::pdiskSpinDown;
use TestLibs::Parity;
use TestLibs::RediCp;
use TestLibs::Resync;
use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :CCBE :RAIDS :XSSA);
use TestLibs::IntegCCBELib;
use TestLibs::IntegXMCLib;
use TestLibs::Configure;
use TestLibs::defrag;
use TestLibs::ConfigTests;
use TestLibs::X1robust;
use TestLibs::Robustness;
use TestLibs::FailOver;
use TestLibs::WrtCache;
use TestLibs::Wookiee1;
use TestLibs::NoFailOver;
use TestLibs::XSSARobustness;
use TestLibs::BaseRegression;
use TestLibs::utility;
use TestLibs::XSSADefragAll;
use TestLibs::Workload;
use TestLibs::VdiskPriority;
use TestLibs::iscsi;
use TestLibs::GeoRaid;
use TestLibs::FeSimConfig;
use TestLibs::AnarchyCode;
use XIOtech::sanscript (port => 10000);
use XIOtech::sanscriptET;

use Dumpvalue;
use strict;

my $dumper = new Dumpvalue;

#
# - perl compiler/interpreter flags 'n' things
#


BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      &Anarchy
                      &CodeUpdateCCBE
                      &CreateMaxVDisks
                      &BEStressTests
                      &ParityTests
                      &DefragTest
                      &DSCResetAll
                      &CallDownFELoopLong
                      &CallDownFELoopLong2
                      &CallDownFELoopTemp
                      &CallDownFELoopTempRepeat
                      &CCBScrub
                      &WorkLoadTest
                      &VdiskPriorityTest
                      &GeoRaidTest
                      &EnablePorts
                      &FailOverNWay
                      &FECommunication
                      &FormatADrive
                      &FormatAllDrives
                      &GoodPathIO
                      &GoodPathSub1
                      &GoodPathSuper
                      &GoodPath
                      &CallHoldFEQlogicReset
                      &InitRaidsWait
                      &labelallengtest
                      &NWayConfigTest
                      &NoWaitPowerUp
                      &PowerCycleDriveBayTest
                      &CallRandomlyPullBECables
                      &CallRobustnessCreateDeleteExp
                      &CallRobustnessCreateMax
                      &CallRobustnessLabel
                      &REDICopy
                      &RemoteTestcase
                      &CallIPCEthernetFiberCom
                      &TestQLogicResetsLauncher
                      &X1Tests
                      &XSSACrExpAssocDel
                      &UnfailControllers
                      &vdcreateengtest
					  &W1Tests
                      &XSSACodeUpdate
                      &XSSADefrag
                      &XSSAErrorPath
                      &XSSAExpMaxBigfoot
                      &XSSAExpMaxMag
                      &XSSAGoodPath
                      &XSSALabel
                      &XSSAORT
                      &XSSAVdMax
                      


                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 25987 $);
}
    our @EXPORT_OK;

#############################################################################################
#
#           Name:  UnfailControllers
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library unfail all
#
#    Description:  Copyright 2003 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub UnfailControllers
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my $unFailReturn;
    my @unFailSNs;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    $returnValue = GetSerialFromMaster (\@ccbeObjArray, \@unFailSNs, \@{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}});
    if ($returnValue != GOOD)
    {
        TestLibs::Logging::logWarning ("Failed to get Serial Numbers from Master");
        return ERROR;
    }

    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}}");

    # Call the unFail function
    $unFailReturn = TestLibs::BEUtils::UnfailAll (\@ccbeObjArray,
                                                  \@unFailSNs,
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}
                                                  );
    if ($unFailReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from UnfailAll:$unFailReturn");
        return $unFailReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}


#############################################################################################
#
#           Name:  DefragTests
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub DefragTests
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my $defragReturn;
    my @defragSNs;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Get our controller SNs.
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $defragSNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
        if ( $defragSNs[$i] == INVALID )
        {
            TestLibs::Logging::logInfo("Failed to get serial number for controller $i.");
            return ERROR;
        } 
    }

    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}},
             curTestArgument:${$xtcDataPtr->{CURTESTARGUMENT}}");

    # Call the Defrag function
    $defragReturn = TestLibs::defrag::DebugEntry (\@ccbeObjArray,
                                                  \@defragSNs,
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                                  $xtcDataPtr->{SERVERS}->{$testGroup}->{'bigfoot'}->{'serverWWN'},
                                                  $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'},
                                                 ${$xtcDataPtr->{CURTESTARGUMENT}});
    if ($defragReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from Defrag:$defragReturn");
        return $defragReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}


#############################################################################################
#
#           Name:  NWayConfigTest
#
#         Inputs:  
#
#        Outputs:  
#
#    Description:  
#                 
#                  
#
#############################################################################################
sub NWayConfigTest
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};
    my $ret;
    my $nwayReturn;
    my @nwaySNs;
    my @ccbeObjArray;
    my $i;

    
    #
    # Connect to all controllers in the group
    #
#    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
#    TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 

    # Get our controller SNs.
#    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
#    {
#        $nwaySNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
#    }

    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}},
             curTestArgument:${$xtcDataPtr->{CURTESTARGUMENT}}");

    # Call the NWay Config Test function
    $nwayReturn = TestLibs::ConfigTests::NWayConfigLoopEntry (\@ccbeObjArray,              
                      \@nwaySNs,
                      $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                      $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                      $xtcDataPtr->{SERVERS}->{$testGroup}->{'windows'}->{'serverWWN'},
                      $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'},
                      ${$xtcDataPtr->{CURTESTARGUMENT}});
                      
    if ($nwayReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from NWayConfigLoopEntry:$nwayReturn");
        return $nwayReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}


#############################################################################################
#
#           Name:  BEStressTests
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub BEStressTests
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my $defragReturn;
    my @defragSNs;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Get our controller SNs.
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $defragSNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
        if ( $defragSNs[$i] == INVALID )
        {
            TestLibs::Logging::logInfo("Failed to get serial number for controller $i.");
            return ERROR;
        } 
    }

    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}},
             curTestArgument:${$xtcDataPtr->{CURTESTARGUMENT}}");

    # Call the BE Stress function
    $defragReturn = TestLibs::BEStress::BEStressEntry (\@ccbeObjArray,
                                                  \@defragSNs,
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                                  $xtcDataPtr->{SERVERS}->{$testGroup}->{'bigfoot'}->{'serverWWN'},
                                                  $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'},
                                                  ${$xtcDataPtr->{CURTESTARGUMENT}},
                                                  0);                     # last parm is a loop count, 0= autoset

    if ($defragReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from BEStress:$defragReturn");
        return $defragReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}

#############################################################################################
#
#           Name:  pdiskSpinDownTests
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub pdiskSpinDownTests
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my $spindownReturn;
    my @spindownSNs;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Get our controller SNs.
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $spindownSNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
        if ( $spindownSNs[$i] == INVALID )
        {
            TestLibs::Logging::logInfo("Failed to get serial number for controller $i.");
            return ERROR;
        } 
    }

    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}},
             curTestArgument:${$xtcDataPtr->{CURTESTARGUMENT}}");

    # Call the pdiskSpinDownEntry function
    $spindownReturn = TestLibs::pdiskSpinDown::pdiskSpinDownEntry (\@ccbeObjArray,
                                                  \@spindownSNs,
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                                  $xtcDataPtr->{SERVERS}->{$testGroup}->{'bigfoot'}->{'serverWWN'},
                                                  $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'},
                                                  ${$xtcDataPtr->{CURTESTARGUMENT}},
                                                  0);                     # last parm is a loop count, 0= autoset

    if ($spindownReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from pdsikSpinDown:$spindownReturn");
        return $spindownReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}

#############################################################################################
#
#           Name:  UETests
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  Does the selected test, returns GOOD or ERROR
#
#    Description:  Copyright 2002-2004 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub UETests
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my $defragReturn;
    my @defragSNs;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Get our controller SNs.
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $defragSNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
        if ( $defragSNs[$i] == INVALID )
        {
            TestLibs::Logging::logInfo("Failed to get serial number for controller $i.");
            return ERROR;
        } 
    }

    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}},
             curTestArgument:${$xtcDataPtr->{CURTESTARGUMENT}}");

    # Call the BE Stress function
    $defragReturn = TestLibs::UETest::UETestEntry (\@ccbeObjArray,
                                                  \@defragSNs,
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                                  $xtcDataPtr->{SERVERS}->{$testGroup}->{'bigfoot'}->{'serverWWN'},
                                                  $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'},
                                                  ${$xtcDataPtr->{CURTESTARGUMENT}},
                                                  0);                     # last parm is a loop count, 0= autoset

    if ($defragReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from UETests:$defragReturn");
        return $defragReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}
#############################################################################################
#
#           Name:  ParityTests
#
#         Inputs:  pointer to XTC data structure
#
#        Outputs:  
#
#    Description:  Copyright 2002-2004 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub ParityTests
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my $defragReturn;
    my @defragSNs;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Get our controller SNs.
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $defragSNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
        if ( $defragSNs[$i] == INVALID )
        {
            TestLibs::Logging::logInfo("Failed to get serial number for controller $i.");
            return ERROR;
        } 
    }

    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}},
             curTestArgument:${$xtcDataPtr->{CURTESTARGUMENT}}");

    # Call the BE Stress function
    $defragReturn = TestLibs::Parity::ParityEntry (\@ccbeObjArray,
                                                  \@defragSNs,
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                                  $xtcDataPtr->{SERVERS}->{$testGroup}->{'bigfoot'}->{'serverWWN'},
                                                  $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'},
                                                  ${$xtcDataPtr->{CURTESTARGUMENT}},
                                                  0);                     # last parm is a loop count, 0= autoset

    if ($defragReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from Parity:$defragReturn");
        return $defragReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}


#############################################################################################
#
#           Name:  X1Tests
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub X1Tests
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my $x1robustReturn;
    my @defragSNs;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray, X1PORT); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Get our controller SNs.
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $defragSNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
        if ( $defragSNs[$i] == INVALID )
        {
            TestLibs::Logging::logInfo("Failed to get serial number for controller $i.");
            return ERROR;
        } 
    }

    # Debug
    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}},
             curTestArgument:${$xtcDataPtr->{CURTESTARGUMENT}}");

    # Call the Defrag function
    $x1robustReturn = TestLibs::X1robust::X1Entry(\@ccbeObjArray,
                                                  \@defragSNs,
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                                  $xtcDataPtr->{SERVERS}->{$testGroup}->{'bigfoot'}->{'serverWWN'},
                                                  $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'},
                                                  ${$xtcDataPtr->{CURTESTARGUMENT}});
    if ($x1robustReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from X1robust:$x1robustReturn");
        return $x1robustReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}


#############################################################################################
#
#           Name:  NoWaitPowerUp
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub NoWaitPowerUp
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    my $returnValue;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Wait for controllers to reach a non-wait power up state
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $returnValue = TestLibs::Validate::Wait4NoWaitPowerUpState($ccbeObjArray[$i], ${$xtcDataPtr->{CURTESTARGUMENT}});
        if ($returnValue != GOOD)
        {
            TestLibs::Logging::logWarning ("Failed to find this controller in a good power up state within the timeout of ${$xtcDataPtr->{CURTESTARGUMENT}} secs.");
            return ERROR;
        }
    }

    return GOOD;
}

#############################################################################################
#
#           Name:  REDICopy
#
#         Inputs:  Array of IP Addresses, Current Test Argument from config file, pointer to current Test Parm Hash
#
#        Outputs:  Good or Error
#
#    Description:  Launcher for REDIcopy tests via the XTC
#                 
#############################################################################################
sub REDICopy
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $returnValue;
    my @ccbeObjArray;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }
    
    TestLibs::Logging::logInfo ("Launching REDI copy test with the following\n" .
                                "Loop Count:$testParms{'redicploopcount'}\n" .
                                " Increment:$testParms{'redicpincrement'}");

    # Start the REDI Copy Test
    $returnValue = TestLibs::RediCp::RCTest( \@ccbeObjArray,
                                             $testParms{"redicploopcount"},
                                             ${$xtcDataPtr->{CURTESTARGUMENT}},
                                             $testParms{"redicpincrement"});
    if ($returnValue != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad Return Code from REDI Copy Test:$returnValue");
        return ERROR;
    }

    return GOOD;
}

#############################################################################################
#
#           Name:  RemoteTestcase
#
#         Inputs:  Array of IP Addresses, Current Test Argument from config file, pointer to current Test Parm Hash
#
#        Outputs:  Good or Error
#
#    Description:  Launches an XTC test on a remote server
#
#   Currently works only under windoze os
#                 
#############################################################################################
sub RemoteTestcase
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    our $IPCreturn;
    my $remoteDir = "c:\\XTCremote";
    my $host = $testParms{"remoteserver"};
    my $user = "xiotech";
    my $share = "XTCremote";
    my $XTCargs;

    # Start the Remote Server Process, will return OK if already running
    $IPCreturn = TestLibs::Remote::RemoteCmd($host, "-c -f -i -d IPCServer.exe");
    CheckReturn();
    
    # Check for the remote directory


    # Make the Remote directory and share it
    $IPCreturn = TestLibs::Remote::IPCMkDir ($host, $remoteDir, $user, $share);
    CheckReturn();
    
    # Check for the RSH daemon



    # Start up the RSH daemon on the remote host
    $IPCreturn = TestLibs::Remote::RSHdaemon ($host, $remoteDir, $user, $share);
    CheckReturn();
    
    # Check for the test directory


    # Make the test directory on the remote Server
    $IPCreturn = TestLibs::Remote::IPCClient($host, "mkdir $remoteDir\\Test");
    CheckReturn();

    # Check for the Semaphore for the test scripts


    # Copy the contents of the test directory to the remote server
    $IPCreturn = TestLibs::Remote::RCP ($host, $user, "*", "\\Test", "-r");
    CheckReturn();

    # Start the Remote Test
    $XTCargs = $testParms{"cmdarguments"};
    $IPCreturn = TestLibs::Remote::IPCClient($host, "$XTCargs");
    CheckReturn();

    return GOOD;

    sub CheckReturn
    {
        if ($IPCreturn != GOOD)
        {
            TestLibs::Logging::logWarning ("Bad Return Code during Remote Test:$IPCreturn");
            return ERROR;
        }
    }
}

#######################################################################
### Function name: FormatAllDrives
###
### Purpose: Send SCSI Format command to PDisk via CCBE
##
##   INPUT: Controller IP Address
##   
## Outputs: GOOD or ERROR 
#######################################################################

sub FormatAllDrives
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my @ccbeObjArray;
    my $masterIndex;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Find the current Master of the group
    TestLibs::Logging::logInfo ("Find the current Master of the group");
    $masterIndex = TestLibs::IntegCCBELib::FindMaster(\@ccbeObjArray);
    if ($masterIndex == INVALID)
    {
        TestLibs::Logging::logError ("Failed to find the Master controller");
        return ERROR;
    }

#    TestLibs::Logging::logInfo ("Disable Failure Manager on All Controllers");
    $returnValue = TestLibs::IntegCCBELib::NoFailureManager(\@ccbeObjArray);
    if ( $returnValue == ERROR )
    {
        TestLibs::Logging::logError("Could not disable Failure Manager");
    }

    # Launch the Format
    $returnValue = TestLibs::Configure::FormatAllPDisks($ccbeObjArray[$masterIndex]);
    if ($returnValue == ERROR)
    {
        TestLibs::Logging::logError ("Failed to format all drives");
        return ERROR;
    }

    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}

#######################################################################
### Function name: FormatADrive
###
### Purpose: Send SCSI Format command to PDisk via CCBE
##
##   INPUT: Controller IP Address, PDisk PID
##   
## Outputs: GOOD or ERROR 
#######################################################################

sub FormatADrive
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my @ccbeObjArray;
    my $masterIndex;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Find the current Master of the group
    TestLibs::Logging::logInfo ("Find the current Master of the group");
    $masterIndex = TestLibs::IntegCCBELib::FindMaster(\@ccbeObjArray);
    if ($masterIndex == INVALID)
    {
        TestLibs::Logging::logError ("Failed to find the Master controller");
        return ERROR;
    }

    # Launch the Format
    $returnValue = TestLibs::Configure::FormatPDisk($ccbeObjArray[$masterIndex], ${$xtcDataPtr->{CURTESTARGUMENT}});
    if ($returnValue == ERROR)
    {
        TestLibs::Logging::logError ("Failed to format drive:${$xtcDataPtr->{CURTESTARGUMENT}}");
        return ERROR;
    }

    $returnValue = TestLibs::Configure::WaitFormatComplete($ccbeObjArray[$masterIndex], ${$xtcDataPtr->{CURTESTARGUMENT}});
    if ($returnValue == ERROR)
    {
        TestLibs::Logging::logError ("Failed Waiting for Format To Complete");
        return ERROR;
    }

    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}

#######################################################################
### Function name: CreateMaxVDisks
###
### Purpose: Launch the Create Max VDisks Test
##
##   INPUT: Controller IP Address, PDisk PID
##   
## Outputs: GOOD or ERROR 
#######################################################################

sub CreateMaxVDisks
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

# Local Variables
    my $returnValue;
    my @ccbeObjArray;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    TestLibs::Logging::logInfo ("Launching Create Max VDisks test with the following\n" .
                                " RAID Type:${$xtcDataPtr->{CURTESTARGUMENT}}\n" .
                                "Loop Count:$testParms{'createmaxloopcount'}");

    # Call the test (CCBE Object Array, RAID Type to Create, Loop Count)
    $returnValue = TestLibs::Robustness::CreateMaxVd (\@ccbeObjArray, ${$xtcDataPtr->{CURTESTARGUMENT}}, $testParms{'createmaxloopcount'});
    if ($returnValue != GOOD)
    {
        TestLibs::Logging::logError ("Failed Running Create Max VDisks Test");
        return $returnValue;
    }

    return GOOD;
}

#############################################################################################
#
#           Name:  PowerCycleDriveBay
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################

sub PowerCycleDriveBayTest
{
    #no strict 'refs';

    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;
    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};
    my $moxaother    = $xtcDataPtr->{POWEROTHER}->{$testGroup}->{'moxa'}->{'powerIP'};
    my $chanother    = $xtcDataPtr->{POWEROTHER}->{$testGroup}->{'moxa'}->{'powerChannel'};

    
    #
    # Local Variables
    #
    my $returnValue;
    my @ccbeObjArray;
    my $inLoops = 1;          # Loop count                 = 1 (Default)
    my $MoxaIP = $moxaother;
    my $Chan = $chanother;   
    my $FunctionReturn;
    
    #
    # Set number of Test Loops if defined in Station Profile (overwrites Default setting)
    #
    if ( defined ($testParms{"loopcount"}) )
    {
        $inLoops = $testParms{"loopcount"};
    }

    #
    # Connect to all the controllers in this VCG
    #
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    
#    for( my $i = 0; $i < scalar($xtcDataPtr->{POWEROTHER}->{$testGroup}->{'moxa'}); $i++)
#    {
        $FunctionReturn = PowerCycleDriveBay(   \@ccbeObjArray, 
                                                $MoxaIP,
                                                $Chan,
                                                ${$xtcDataPtr->{CURTESTARGUMENT}}, 
                                                $inLoops );
        if($FunctionReturn != GOOD)
        {
            logInfo(">>>> Test has failed ");
            return ERROR;
        }
        else
        {    
            logInfo(">>>> Test has passed ");
        }
#    }
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}

#############################################################################################
#
#           Name:  XSSACrExpAssocDel
#
#         Inputs: ${$xtcDataPtr->{CURSERIALNUMBER}} - CNC serial number 
#                 ${$xtcDataPtr->{CURTESTARGUMENT}} - Number of times to run the test
#
#        Outputs: ERROR, GOOD  
#
#    Description: Launches Create Expand Associate Delete 
#                 virtual disk test   
#                 
#                  
#
#############################################################################################

sub XSSACrExpAssocDel
{
    my ( $xtcDataPtr ) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms;
    
    if( $xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex] )
    {
        %testParms = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};
    }
    my @ccbeObjArray; 
    my $rc;         # Test function return code
    my $mes = "\n\n***** Starting Create Associate/Expand/Disassociate/Delete virtual disk test";
    
#    logInfo("");
#    logInfo("");
#    logInfo("");
#
#    foreach my $name (keys %testParms)
#    {
#        logInfo("$name $testParms{$name}");
#    }
#
    
    #
    # Setup logging
    #    
    debug($mes);
    
    $rc = CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray);
    if ( $rc != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    if(GOOD != CtlrLogTextAll(\@ccbeObjArray, $mes))    
    {
        logInfo("Unable to send message to debug console");
        return ERROR;   
    }

    
    #
    # Reserve the ICON
    #    
    if (ERROR == XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}}))
    { 
        return ERROR; 
    }

    #
    # Run the test
    #
    $rc = CrtExpAsDsaDlt( ${$xtcDataPtr->{CURTESTARGUMENT}},\%testParms );

    #
    # Release the reservation
    #
    if (ERROR == XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}))
    {
        logWarning("Failed to disconnect from VCG group " .
                   " ${$xtcDataPtr->{CURTESTGROUP}} with " .
                   "ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
    }

    #
    # Report test results
    #
    if(GOOD == $rc)
    {
        logInfo("Test has passed\n");
    }
    else
    {    
        logInfo(">>>> TEST HAS FAILED <<<<\n");
    }

    return $rc;

}

#############################################################################################
#
#           Name:  DSCResetAll
#
#         Inputs: ${$xtcDataPtr->{CURSERIALNUMBER}} - CNC serial number 
#                 ${$xtcDataPtr->{CURTESTARGUMENT}} - Number of times to run the test
#
#        Outputs: ERROR, GOOD  
#
#    Description: Launches Create Expand Associate Delete 
#                 virtual disk test   
#                 
#                  
#
#############################################################################################

sub DSCResetAll
{
    my ( $xtcDataPtr ) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my @ccbeObjArray; 
    my $return;         # Test function return 
    
    
    my $mes = "***** Starting reset all controller in DSC test case";
    
    TestLibs::Logging::debug($mes);
    
    $return = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray);
    if ( $return != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }
    
    $return = CtlrLogTextAll(\@ccbeObjArray, $mes);
    
    if($return != GOOD)    
    {
        logInfo("Unable to send message to debug console");
        return ERROR;   
    }

    
    $return = TestLibs::IntegXMCLib::XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}});  # Connect (VCG ID)
    
    if($return != GOOD) 
    { 
        return ERROR; 
    }

    $return = TestLibs::XSSARobustness::ResetAllControllers( \@ccbeObjArray,
                                                             ${$xtcDataPtr->{CURSERIALNUMBER}} );

    if($return != GOOD)
    {
        logInfo(">>>> Test has failed ");
        return ERROR;
    }
    else
    {    
        logInfo(">>>> Test has passed ");
    }

    if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
    {
        logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
    }

    return GOOD;

}




##############################################################################
#
#          Name: GoodPathIO
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: See corresponding function in GoodPath.pm for more information.
#
##############################################################################
sub GoodPathIO
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    my $ccbeConnection;
    my $serverWWN;
    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    # Get a Master CCBE connection & Login (IP Address)
    TestLibs::Logging::logInfo ("Get a Master CCBE connection & Login");
    $returnCode = ConnectMasterCCBE($xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \$ccbeConnection);

    if ($returnCode != GOOD)
    {
        TestLibs::Logging::logError ("Failed to find the Master controller");
        return $returnCode;
    }
    else
    { 
        # Run the Good Path Test
        $serverWWN = $xtcDataPtr->{SERVERS}->{$testGroup}->{'windows'}->{'serverWWN'};
        $returnCode = TestLibs::IntegCCBELib::GoodPathIOTest($ccbeConnection, 0, $serverWWN);
    }
        
    #
    # Disconnect from the currently connected controller.
    #
    if (TestLibs::IntegCCBELib::ccbe_disconnect($ccbeConnection) == ERROR)
    {
        TestLibs::Logging::logWarning("Failed to disconnect from controller");
    }

    return $returnCode;
}

##############################################################################
#
#          Name: CodeUpdateCCBE
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: See corresponding function in Robustness.pm for more information.
#
##############################################################################

sub CodeUpdateCCBE
{
    trace();

    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $funtionReturn = ERROR;
    my $obj;

    my @FwFiles;                #-Need this value from the user
    my $TimeToRunTheTest=1;     #-This will always be 1 - The loop count in the config file will be used for looping
    my $tempVar;                #-Temp variable to allow for push
    my @controllerList;         #-List of logged in controller objects

    my @SortBy = sort(keys( %testParms ));     
    for (my $ i = 0; $i < scalar( @SortBy ); $i++)
    {
        push (@FwFiles, $testParms{$SortBy[$i]} );
    } 

    #
    # Connect to each controller in the current VCG, creating array of objects 
    #
    $funtionReturn = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@controllerList); 
    if ( $funtionReturn != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    for (my $index = 0; $index < scalar (@controllerList); $index++)             
    {
        #---Set TimeOut
        $controllerList[$index]->{TIMEOUT} = CCBETIMEOUT;
    }
    
    #
    # Get and display some info
    #
    TestLibs::IntegCCBELib::ViewLicenseState( \@controllerList );

    #
    # If there already is License the next call is OK
    #
    $funtionReturn = TestLibs::IntegCCBELib::GimmieLicense( \@controllerList, 
                                                            $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, 
                                                            0);  
        
    if ( $funtionReturn == ERROR )
    {
        logInfo(">>>>>>>> Failed to get/set a license. <<<<<<<<");
        return ERROR;

    }

    TestLibs::IntegCCBELib::ViewLicenseState( \@controllerList );

    logInfo(" ");
    logInfo("************************************************");
    logInfo(" ");
    logInfo("Starting Code Update via CCBE Test ");
    logInfo(" ");
    logInfo("************************************************");

   
    $funtionReturn = TestLibs::Robustness::CodeUpdateMainLoop(\@controllerList, 
                                         \@FwFiles, 
                                         $TimeToRunTheTest, 
                                         $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                         $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                         );
    
    if( $funtionReturn != GOOD)
    {
        return ERROR;
    }
    

    #############################################################
    #############################################################


    # terminate controller connections
    for (my $p = 0; $p < scalar(@controllerList); $p++ )
    {
        if ( $controllerList[$p] )
        {
          #  getTrace($coList[$i], "C:\\temp\\fail".$i.".txt");
            $controllerList[$p]->logout();
        }

    }

    
    return GOOD;   # make sure it is good for now, may want to change later



}


##############################################################################
#
#          Name: GoodPathSub1
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: See corresponding function in GoodPath.pm for more information.
#
##############################################################################
sub GoodPathSub1
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    my $ccbeConnection;
    my $serverWWN;
    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    # Get a Master CCBE connection & Login (IP Address)
    TestLibs::Logging::logInfo ("Get a Master CCBE connection & Login");
    $returnCode = ConnectMasterCCBE($xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \$ccbeConnection);

    if ($returnCode != GOOD)
    {
        TestLibs::Logging::logError ("Failed to find the Master controller");
        return $returnCode;
    }
    else
    { 
        # Run the Good Path Test
        $serverWWN = $xtcDataPtr->{SERVERS}->{$testGroup}->{'windows'}->{'serverWWN'};
        $returnCode = TestLibs::IntegCCBELib::GoodPathSubset1($ccbeConnection, 0, $serverWWN);
    }
        
    #
    # Disconnect from the currently connected controller.
    #
    if (TestLibs::IntegCCBELib::ccbe_disconnect($ccbeConnection) == ERROR)
    {
        TestLibs::Logging::logWarning("Failed to disconnect from controller");
    }

    return $returnCode;
}


##############################################################################
#
#          Name: GoodPathSuper
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: See corresponding function in GoodPath.pm for more information.
#
##############################################################################
sub GoodPathSuper
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    my $serverWWN;
    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    my $controllerIP;
    my $controller;
    
    #
    # Get the IP address of the controller (first one if more than one)
    # and attempt to connect to it.
    #
    $controllerIP = $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}->[0];
    if ( ($controller = ccbe_connect($controllerIP)) != ERROR )
    { 
        $serverWWN = $xtcDataPtr->{SERVERS}->{$testGroup}->{'windows'}->{'serverWWN'};
        $returnCode = TestLibs::IntegCCBELib::GoodPathSuperset($controller, 0, $serverWWN);
        
        #
        # Disconnect from the currently connected controller.
        #
        logInfo("Logging out of controller $controllerIP...");
        if (ccbe_disconnect($controller) == ERROR)
        {
            logWarning("Failed to disconnect from controller IP $controller");
            return ERROR;
        }
    }
    else
    {
        logWarning("Failed to log in to controller IP $controllerIP");        
        return ERROR;
    }   

    return $returnCode;
}


##############################################################################
#
#          Name: GoodPath
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: See corresponding function in GoodPath.pm for more information.
#
##############################################################################
sub GoodPath
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    my $serverWWN;
    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    my $controllerIP;
    my $controller;
    
    
    #
    # Get the IP address of the controller (first one if more than one)
    # and attempt to connect to it.
    #
    $controllerIP = $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}->[0];
    if ( ($controller = ccbe_connect($controllerIP)) != ERROR )
    {
        $serverWWN = $xtcDataPtr->{SERVERS}->{$testGroup}->{'windows'}->{'serverWWN'};
        $returnCode = TestLibs::IntegCCBELib::GoodPathTest($controller, 0, $serverWWN);
        
        #
        # Disconnect from the currently connected controller.
        #
        logInfo("Logging out of controller $controllerIP...");
        if (ccbe_disconnect($controller) == ERROR)
        {
            logWarning("Failed to disconnect from controller IP $controller");
            return ERROR;
        }
    }
    else
    {
        logWarning("Failed to log in to controller IP $controllerIP");        
        return ERROR;
    }   

    return $returnCode;
}

##############################################################################
#
#          Name: TestQLogicResetsLauncher
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Does qlogic resets with the current VCG.
#
##############################################################################
sub TestQLogicResetsLauncher
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    #
    # Prepare the parameters for use in the test method.
    #
    my $qlogicType = uc(${$xtcDataPtr->{CURTESTARGUMENT}});
    my $type = uc($testParms{"qlogicresettype"});
    my $num = $testParms{"qlogicresetnum"}; 
    my $wait = randomInt($testParms{"qlogicresetwaitmin"}, $testParms{"qlogicresetwaitmax"});
    my $hold = randomInt($testParms{"qlogicresetholdmin"}, $testParms{"qlogicresetholdmax"});

    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    my @controllerList;
    $returnCode = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@controllerList);
    if ( $returnCode != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    #
    # Run the test.
    #
    $returnCode = TestQLogicResets(\@controllerList, $type, $num, $qlogicType, $wait, $hold, 1);

    #
    # Disconnect from any controllers that have been connected to.
    #
    for (my $i = 0; $i < @controllerList; $i++)
    {
        if (ccbe_disconnect($controllerList[$i]) == ERROR)
        {
            logWarning("Failed to disconnect from controller");
        }
    }

    return $returnCode;
}


#######################################################################
### Function name: FailOver
###
### Purpose: Process configuration data and then call FailOverLoop
##
## INPUT:    
## Outputs: GOOD, if successful, ERROR otherwise
#######################################################################

sub FailOver
{
    trace();                        # This allows function tracability

    my $msg;

    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    # Local Variables
    my $returnValue;
    my @groupCCBE;

    # the optional parms ( and their current default values )

    my $tld;                  # duration of the time line  = 120 sec
    my $rcd;                  # reconnect dealy            = 60 sec
    my $w4st;                 # wait for (good) state time = 360 sec
    my $inFlags;              # validation flags           = 0
    my $fmlc;                 # loops sent to FailOverLoop() = 1
    my $mrw;                  # mirror resync wait = 30;

    TestLibs::Logging::debug ("Find all controllers in the VCG");
    
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@groupCCBE);
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }
    
    $msg = sprintf("The current XTC loop count is %d\n", $xtcDataPtr->{CURRENTLOOP} ); 
    
    CtlrLogTextAll (\@groupCCBE, $msg);

    # set the optional parametes, or leave as undefined

    # print"Optional parms are defaulted\n";

    if ( defined ($testParms{"timelineduration"}) )
    {
        # print "updating tld\n";
        $tld = $testParms{"timelineduration"};
    }

    if ( defined ($testParms{"mirrorresyncwait"}) )
    {
        # print "updating mrw\n";
        $mrw = $testParms{"mirrorresyncwait"};
    }


    if ( defined ($testParms{"reconnectdelay"}) )
    {
        # print "updating rcd\n";
        $rcd = $testParms{"reconnectdelay"};
    }

    if ( defined ($testParms{"wait4statetime"}) )
    {
        # print "updating w4st\n";
        $w4st = $testParms{"wait4statetime"};
    }

    if ( defined ($testParms{"validationflags"}) )
    {
        # print "updating inFlags\n";
        $inFlags = $testParms{"validationflags"};
    }

    if ( defined ($testParms{"failovermidloopcount"}) )
    {
        # print "updating inFlags\n";
        $fmlc = $testParms{"failovermidloopcount"};
    }
    else
    {
        $fmlc = 1;                #  old default behavior
    }

    # Call the FailOverLoop function, this will fail/unfail a slave, then the master
        # my $rc = FailOverLoop($coPtr, $moxaIP, $moxaPtr, $failType, $loopCount, 
        #          $tld, $rcd, $w4st, $inFlags   );

    $returnValue = FailOverLoop (\@groupCCBE,
                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                  ${$xtcDataPtr->{CURTESTARGUMENT}},
                                  $fmlc, 
                                  $tld, 
                                  $rcd, 
                                  $w4st, 
                                  $inFlags,
                                  0,                               # fctlPtr 
                                  $xtcDataPtr,
                                  $mrw );

    if ($returnValue != GOOD)
    {
        return $returnValue;
    }
    

    foreach my $controllerCCBE (@groupCCBE)             # Disconnect from all controllers in this VCG
    {
        ccbe_disconnect($controllerCCBE);
    }

    TestLibs::utility::randomDelay($testParms{"failcontrollerwaitmin"}, $testParms{"failcontrollerwaitmax"});

    return GOOD;
}
#######################################################################
### Function name: FailOverNWay
###
### Purpose: Process configuration data and then call FailOverLoop
##
## INPUT:    
## Outputs: GOOD, if successful, ERROR otherwise
#######################################################################

sub FailOverNWay
{
    trace();                        # This allows function tracability

    my $msg;

    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my %parms;
    my @resources;

    # Local Variables
    my $returnValue;
    my @groupCCBE;

    # the optional parms ( and their current default values )

    my $tld;                  # duration of the time line  = 120 sec
    my $rcd;                  # reconnect dealy            = 60 sec
    my $w4st;                 # wait for (good) state time = 360 sec
    my $inFlags;              # validation flags           = 0
    my $fmlc;                 # loops sent to FailOverLoop() = 1


    TestLibs::Logging::debug ("Find all controllers in the VCG");
    
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@groupCCBE);
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    $msg = sprintf("The current XTC loop count is %d\n", $xtcDataPtr->{CURRENTLOOP} ); 
    
    CtlrLogTextAll (\@groupCCBE, $msg);

    # set the optional parametes, or leave as undefined

    # print"Optional parms are defaulted\n";


    if ( defined ($testParms{"mirrorresyncwait"}) )
    {
        # print "updating mrw\n";
        $parms{MIRRORRESYNCWAIT } = $testParms{"mirrorresyncwait"};
    }

    if ( defined ($testParms{"timelineduration"}) )
    {
        # print "updating tld\n";
        $parms{TIMELINEDUR } = $testParms{"timelineduration"};
    }

    if ( defined ($testParms{"reconnectdelay"}) )
    {
        # print "updating rcd\n";
        $parms{RECONNECTDEL } = $testParms{"reconnectdelay"};
    }

    if ( defined ($testParms{"wait4statetime"}) )
    {
        # print "updating w4st\n";
        $parms{WAIT4STIME } = $testParms{"wait4statetime"};
    }

    if ( defined ($testParms{"validationflags"}) )
    {
        # print "updating inFlags\n";
        $parms{FLAGS } = $testParms{"validationflags"};
    }

    if ( defined ($testParms{"failovermidloopcount"}) )
    {
        # print "updating inFlags\n";
        $parms{LOOPCOUNT } = $testParms{"failovermidloopcount"};
    }
    else
    {
        $parms{LOOPCOUNT }= 1;                #  old default behavior
    }

    $parms{FAILTYPE } = ${$xtcDataPtr->{CURTESTARGUMENT}};
    
    $returnValue = FailOverNWayLoop( \@groupCCBE, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}, 
                                     \@resources,          # pointer to resource array, can be empty array
                                     \%parms,              # misc parameter hash
                                     0,                    # (future) data for cable pull test
                                     $xtcDataPtr           # pointer to update a loop counter
                                   );
                                
    if ($returnValue != GOOD)
    {
        return $returnValue;
    }
    

    foreach my $controllerCCBE (@groupCCBE)             # Disconnect from all controllers in this VCG
    {
        ccbe_disconnect($controllerCCBE);
    }

    TestLibs::utility::randomDelay($testParms{"failcontrollerwaitmin"}, $testParms{"failcontrollerwaitmax"});

    return GOOD;
}
#######################################################################
### Function name: Resync1DscTest
###
### Purpose: Process configuration data and then call Resync1DscEntry
##           This is for resync test cases that use a single DSC
##
## INPUT:    
## Outputs: GOOD, if successful, ERROR otherwise
#######################################################################

sub Resync1DscTest
{
    trace();                        # This allows function tracability

    my $msg;

    my ($xtcDataPtr) = @_;

    #
    # The following indicate where the data for this test can be found in the 
    # xtcData hash.
    #

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my %parms;

    # Local Variables
    my $returnValue;
    my @groupCCBE;

    # the optional parms ( and their current default values )
    #
    # Resync will have different parms and default values.
    # Note that the defaults are not here, rather, they are in the test code.
    #
    

    my $tld;                  # duration of the time line  = 120 sec
    my $rcd;                  # reconnect dealy            = 60 sec
    my $w4st;                 # wait for (good) state time = 360 sec
    my $inFlags;              # validation flags           = 0
    my $fmlc;                 # loops sent to FailOverLoop() = 1


    TestLibs::Logging::debug ("Find all controllers in the VCG");
    
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@groupCCBE);
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    $msg = sprintf("The current XTC loop count is %d\n", $xtcDataPtr->{CURRENTLOOP} ); 
    
    CtlrLogTextAll (\@groupCCBE, $msg);

    # set the optional parametes, or leave as undefined

    # print"Optional parms are defaulted\n";


    # Add code here to manage your optiona parameters under [TestParms]. Your parameters
    # will have different names than what is shown here.


    if ( defined ($testParms{"mirrorresyncwait"}) )
    {
        # print "updating mrw\n";
        $parms{MIRRORRESYNCWAIT } = $testParms{"mirrorresyncwait"};
    }

    if ( defined ($testParms{"timelineduration"}) )
    {
        # print "updating tld\n";
        $parms{TIMELINEDUR } = $testParms{"timelineduration"};
    }

    if ( defined ($testParms{"reconnectdelay"}) )
    {
        # print "updating rcd\n";
        $parms{RECONNECTDEL } = $testParms{"reconnectdelay"};
    }

    if ( defined ($testParms{"wait4statetime"}) )
    {
        # print "updating w4st\n";
        $parms{WAIT4STIME } = $testParms{"wait4statetime"};
    }

    if ( defined ($testParms{"validationflags"}) )
    {
        # print "updating inFlags\n";
        $parms{FLAGS } = $testParms{"validationflags"};
    }

    if ( defined ($testParms{"failovermidloopcount"}) )
    {
        # print "updating inFlags\n";
        $parms{LOOPCOUNT } = $testParms{"failovermidloopcount"};
    }
    else
    {
        $parms{LOOPCOUNT }= 1;                #  old default behavior
    }

    $parms{FAILTYPE } = ${$xtcDataPtr->{CURTESTARGUMENT}};
    
    #
    # This is the call to do the test. All data needed by the test to run should
    # be passed. Passing xtcDataPtr is a bad thing to do. All data needed
    # shpould be extracted from xtcData nad passed (the test should be working
    # from a copy). In this example, all parameters specific to the test have
    # been passed in the parms hash. 
    #
    
    
    $returnValue = Resync1DscEntry( \@groupCCBE, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}, 
                                     \%parms,              # misc parameter hash
                                     0                    # (future) data for cable pull test
                                   );
                                
    if ($returnValue != GOOD)
    {
        return $returnValue;
    }
    

    foreach my $controllerCCBE (@groupCCBE)             # Disconnect from all controllers in this VCG
    {
        ccbe_disconnect($controllerCCBE);
    }

    return GOOD;
}

#######################################################################
### Function name: W1Tests
###
### Purpose: Process configuration data and then call W1TestEntry
##           This is the test case directed for linux compatibility
##
## INPUT:    
## Outputs: GOOD, if successful, ERROR otherwise
#######################################################################

sub W1Tests
{
    trace();                        # This allows function tracability

    my $msg;

    my ($xtcDataPtr) = @_;

    #
    # The following indicate where the data for this test can be found in the 
    # xtcData hash.
    #

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my %parms;


    # Local Variables
    my $returnValue;
    my @groupCCBE;
    my $initialPowerOffDelay; #How long to wait before first shutdown       = 10 sec
    my $finalPowerOffDelay;   #Final longest waiting time before shutdown   = 300 sec
    my $powerOffIncrement;    #How many seconds more to wait from previous  = 10 sec


    # the optional parms ( and their current default values )
    #
    # Resync will have different parms and default values.
    # Note that the defaults are not here, rather, they are in the test code.
    #
    

    my $tld;                  # duration of the time line  = 120 sec
    my $rcd;                  # reconnect dealy            = 60 sec
    my $w4st;                 # wait for (good) state time = 360 sec
    my $inFlags;              # validation flags           = 0
    my $fmlc;                 # loops sent to FailOverLoop() = 1

    my @snList;
    my $snPtr;
    my $i;
    TestLibs::Logging::debug ("Find all controllers in the VCG");
    
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@groupCCBE);
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    #
    # Build the Serial Number list
    #
    for ( $i = 0; $i < scalar( @groupCCBE); $i++)
    {
        $snList[$i] = $groupCCBE[$i]->{SERIAL_NUM};
    }
    
    $snPtr = \@snList;

    $msg = sprintf("The current XTC loop count is %d\n", $xtcDataPtr->{CURRENTLOOP} ); 
    
    CtlrLogTextAll (\@groupCCBE, $msg);

    # set the optional parametes, or leave as undefined

    # print"Optional parms are defaulted\n";

    if( defined( ${$xtcDataPtr->{CURTESTARGUMENT}})) {
        $testParms{testcase} = ${$xtcDataPtr->{CURTESTARGUMENT}};
    };
    
    #
    # This is the call to do the test. All data needed by the test to run should
    # be passed. Passing xtcDataPtr is a bad thing to do. All data needed
    # shpould be extracted from xtcData nad passed (the test should be working
    # from a copy). In this example, all parameters specific to the test have
    # been passed in the parms hash. 
    #
    
    $returnValue = W1TestEntry( \@groupCCBE,
                                     $snPtr, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}, 
                                     \%testParms,         # misc parameter hash
                                     0                    # (future) data for cable pull test
                                   );

    print "\nDone calling the W1TestCaseEntry.\n";
     
     
  #  $xtcDataPtr->{TESTLOOPS} = %parms{TESTLOOPS};
     
                                
    if ($returnValue != GOOD)
    {
        return $returnValue;
    }
    

    foreach my $controllerCCBE (@groupCCBE)             # Disconnect from all controllers in this VCG
    {
        ccbe_disconnect($controllerCCBE);
    }

    return GOOD;
}

#######################################################################
### Function name: ResyncNDscTest
###
### Purpose: Process configuration data and then call ResyncNDscEntry
###          THis is for resync tests that work on multiple DSCs
##
## INPUT:    
## Outputs: GOOD, if successful, ERROR otherwise
#######################################################################

sub ResyncNDscTest
{
    trace();                        # This allows function tracability

    my $msg;

    my ($xtcDataPtr) = @_;
    
    #
    # Note: the CURTESTGROUP only refers to a single DSC. Additional DSCs will
    # need to be passed as parameters.
    #

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my %parms;
    my @resources;

    # Local Variables
    my $returnValue;
    my @groupCCBE;

    # the optional parms ( and their current default values )
    #
    # Resync will have different parameters and defaults. Defaults are 
    # given values in the script and could vary by testcase.
    #

    my $tld;                  # duration of the time line  = 120 sec
    my $rcd;                  # reconnect dealy            = 60 sec
    my $w4st;                 # wait for (good) state time = 360 sec
    my $inFlags;              # validation flags           = 0
    my $fmlc;                 # loops sent to FailOverLoop() = 1


    TestLibs::Logging::debug ("Find all controllers in the VCG");
    
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    
    #
    # You will have to do this for each DSC. Based upon the sxample testcase file, 
    # you can identify the other DSCs by looking for hash keys with "aditionaldsc"
    # and push the pointers onto an array. Ditto for the Moxa data.
    #
    
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@groupCCBE);
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    $msg = sprintf("The current XTC loop count is %d\n", $xtcDataPtr->{CURRENTLOOP} ); 
    
    CtlrLogTextAll (\@groupCCBE, $msg);

    # set the optional parametes, or leave as undefined

    # print"Optional parms are defaulted\n";

    #
    # These lines manage the optional parameters that were specified in the 
    # testcase file.
    #
    if ( defined ($testParms{"mirrorresyncwait"}) )
    {
        # print "updating mrw\n";
        $parms{MIRRORRESYNCWAIT } = $testParms{"mirrorresyncwait"};
    }

    if ( defined ($testParms{"timelineduration"}) )
    {
        # print "updating tld\n";
        $parms{TIMELINEDUR } = $testParms{"timelineduration"};
    }

    if ( defined ($testParms{"reconnectdelay"}) )
    {
        # print "updating rcd\n";
        $parms{RECONNECTDEL } = $testParms{"reconnectdelay"};
    }

    if ( defined ($testParms{"wait4statetime"}) )
    {
        # print "updating w4st\n";
        $parms{WAIT4STIME } = $testParms{"wait4statetime"};
    }

    if ( defined ($testParms{"validationflags"}) )
    {
        # print "updating inFlags\n";
        $parms{FLAGS } = $testParms{"validationflags"};
    }

    if ( defined ($testParms{"failovermidloopcount"}) )
    {
        # print "updating inFlags\n";
        $parms{LOOPCOUNT } = $testParms{"failovermidloopcount"};
    }
    else
    {
        $parms{LOOPCOUNT }= 1;                #  old default behavior
    }

    $parms{FAILTYPE } = ${$xtcDataPtr->{CURTESTARGUMENT}};
    
    my @objLists;
#    $objLists[0] = \@groupCCBE;
#    $objLists[1] = \@groupCCBE2;
#    $objLists[2] = \@groupCCBE3;
#    $objLists[3] = \@groupCCBE4;
    
    #
    # The first three parameters for the following call are probably lists of 
    # pointers to lists. Data for each DSC is kept separate so that when a 
    # function is called you only pass data for the DSC you are doing something to.
    #

    
    $returnValue = ResyncNDscEntry( \@objLists, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}, 
                                     \%parms,              # misc parameter hash
                                     0                    # (future) data for cable pull test
                                   );
                                
    if ($returnValue != GOOD)
    {
        return $returnValue;
    }
    
    #
    # You will have to do this for each DSC. (Note: you remian logged in 
    # if the test fails. THis is not necessarily a good thing.
    #
    foreach my $controllerCCBE (@groupCCBE)             # Disconnect from all controllers in this VCG
    {
        ccbe_disconnect($controllerCCBE);
    }

    return GOOD;
}

##############################################################################
#
#          Name: FECommunication
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: This test removes the connection between controllers by
#                removing the zone that connects them. The connection is
#                lost for 2 minutes, then restored for 2 minutes.
#
##############################################################################
sub FECommunication
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $switchIPAddr;
    my $switchUser;
    my $switchPass; 
    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    #
    # Prepare the parameters for use in the test method.
    #
    my $switchNameToUse = $testParms{"switchname"};
    my $option = ${$xtcDataPtr->{CURTESTARGUMENT}};

    #
    # Find more information about the switch to use.
    #
    my $indexSwitch = 0;
    foreach my $switchName (@{$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchName'}})
    {
        if ($switchName eq $switchNameToUse)
        {
            # Get the current Switch Record
            $switchIPAddr  = ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchIP'}}[$indexSwitch];
            $switchUser  = ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchUsername'}}[$indexSwitch];
            $switchPass  = ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchPassword'}}[$indexSwitch];
            last;
        }
        $indexSwitch++;
    }

    #
    # Check to see if the switch was found in the current VCG.
    #
    if (!defined($switchIPAddr))
    {
        logInfo("The specified switch ($switchNameToUse) was not found in the current VCG.");
        return ERROR;
    }

    
    if ($option eq "setup")
    {
        #
        # Setup the switch for this test.
        # Note: 'SU' is for SetUp.
        #
        my @fakeArray = (undef);    # This is needed to pass an array reference.
        FECommunicationTest(\@fakeArray, $switchIPAddr, "SU")
    }
    elsif ($option eq "runtest")
    { 
        #
        # Connect to each controller in the VCG and create a list of the connected
        # controllers.
        #
        my @controllerList;
        $returnCode = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@controllerList);
        if ( $returnCode != GOOD )
        {
            TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
            return ERROR;
        }

        #
        # Run the test.
        #
        $returnCode = TestLibs::NoFailOver::FECommunicationTest(\@controllerList, $switchIPAddr, 1);

        #
        # Disconnect from any controllers that have been connected to.
        #
        for (my $i = 0; $i < @controllerList; $i++)
        {
            if (ccbe_disconnect($controllerList[$i]) == ERROR)
            {
                logWarning("Failed to disconnect from controller");
            }
        }
    }

    return $returnCode;
}

##############################################################################
#
#          Name: InitRaidsWait
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Initializes raids on the current VCG until
#                some raids are waiting to begin initialization.  Once this 
#                occurs, the test waits until all initializations have 
#                completed.
#
##############################################################################
sub InitRaidsWait
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};
    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    #
    # Connect to the master controller in the VCG.       
    #
    my $ctrl;

    if ( (ConnectMasterCCBE($xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \$ctrl)) == ERROR )
    {
        logInfo("Failed to login to the master controller of the current VCG");
        return ERROR;
    }   

    #
    # Run the test.
    #
    $returnCode = TestLibs::GoodPath::InitUntilRaidsWait($ctrl);

    #
    # Disconnect from the master controller.
    #
    logInfo("Logging out of controller ...");
    if (ccbe_disconnect($ctrl) == ERROR)
    {
        logWarning("Failed to disconnect from controller ");
    }    

    return $returnCode;
}


##############################################################################
#
#          Name: EnablePorts
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Enable all Ports given in the Config file
#
##############################################################################
sub EnablePorts
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    #
    # Prepare the parameters for use in the test method.
    #
    my $switchCommaList = $testParms{"switchlist"};
    my $portMap = $testParms{"portlist"};

    #
    # Split the comma separated lists into arrays.
    #
    my @switchNameList = split /[,]/, $switchCommaList;
    my @portList = split /[,]/, $portMap;

    #
    # Find out if the number of ports and number of switches are the same
    #
    if (@portList != @switchNameList)
    {
        logInfo("The number of ports (" . @portList . ") and the number of switches (" . @switchNameList . ") specified must be the same"); 
        return ERROR;
    }

    
    #
    # Find more information about the switches to use.
    #
    my @switchIPList;
    my @switchUserList;
    my @switchPWList;
    my @foundNameList;
    my $indexSwitch;

    foreach my $switchNameToUse (@switchNameList)
    {
        $indexSwitch = 0;
        foreach my $switchName (@{$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchName'}})
        {
            if ($switchName eq $switchNameToUse)
            {
                # Get the current Switch Record
                push @switchIPList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchIP'}}[$indexSwitch];
                push @switchUserList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchUsername'}}[$indexSwitch];
                push @switchPWList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchPassword'}}[$indexSwitch];
                push @foundNameList, $switchName;
                last;  
            }
            $indexSwitch++;
        }
    }

    return BSWEnablePorts (\@switchIPList, \@switchUserList, \@switchPWList, \@portList);

}
    
##############################################################################
#
#          Name: CallDownFELoopTempRepeat
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Downs the FE Loop for less than 10 seconds repeatedly.  A
#                failure is expected to occur.
#
##############################################################################
sub CallDownFELoopTempRepeat
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    #
    # Prepare the parameters for use in the test method.
    #
    my $switchCommaList = $testParms{"switchlist"};
    my $portMap = $testParms{"portlist"};

    #
    # Split the comma separated lists into arrays.
    #
    my @switchNameList = split /[,]/, $switchCommaList;
    my @portList = split /[,]/, $portMap;

    
    #
    # Find out if the number of ports and number of switches are the same
    #
    if (@portList != @switchNameList)
    {
        logInfo("The number of ports (" . @portList . ") and the number of switches (" . @switchNameList . ") specified must be the same"); 
        return ERROR;
    }

    #
    # Find more information about the switches to use.
    #
    my @switchIPList;
    my @foundNameList;
    my $indexSwitch;

    foreach my $switchNameToUse (@switchNameList)
    {
        $indexSwitch = 0;
        foreach my $switch (@{$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchName'}})
        {
            foreach my $switchName (@{$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchName'}})
            {
                if ($switchName eq $switchNameToUse)
                {
                    # Get the current Switch Record
                    push @switchIPList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchIP'}}[$indexSwitch];
#                    push @switchUserList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchUsername'}}[$indexSwitch];
#                    push @switchPWList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchPassword'}}[$indexSwitch];
                    push @foundNameList, $switch;
                    last;  
                }
            }
            $indexSwitch++;
        }
    }

    #
    # Check to see if the switches were found in the current VCG.
    #
    if (scalar(@switchIPList) != scalar(@switchNameList))
    {
        my $oldSeparator = $";
        $" = ", ";
        logInfo("Not all of the specified switches are part of the current VCG.");
        logInfo("Only these switches (@foundNameList) were found to be part of the current VCG.");
        $" = $oldSeparator;
        return ERROR;
    }
     
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    my @controllerList;
    $returnCode = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@controllerList);
    if ( $returnCode != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    #
    # Run the test.
    #
    $returnCode = TestLibs::FailOver::DownFELoopTempRepeat(\@controllerList,
                                                           \@switchIPList,
                                                           \@portList,
                                                           scalar(@controllerList),
                                                           1,
                                                           ${$xtcDataPtr->{QUIET}});

    #
    # Disconnect from any controllers that have been connected to.
    #
    for (my $i = 0; $i < @controllerList; $i++)
    {
        if (ccbe_disconnect($controllerList[$i]) == ERROR)
        {
            logWarning("Failed to disconnect from controller");
        }
    }


    return $returnCode;
}


##############################################################################
#
#          Name: CallDownFELoopLong
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Downs the FE Loop for greater than 10 seconds.  A
#                failure is expected to occur.
#
##############################################################################
sub CallDownFELoopLong
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    #
    # Prepare the parameters for use in the test method.
    #
    my $switchCommaList = $testParms{"switchlist"};
    my $portMap = $testParms{"portlist"};

    #
    # Split the comma separated lists into arrays.
    #
    my @switchNameList = split /[,]/, $switchCommaList;
    my @portList = split /[,]/, $portMap;

    
    #
    # Find out if the number of ports and number of switches are the same
    #
    if (@portList != @switchNameList)
    {
        logInfo("The number of ports (" . @portList . ") and the number of switches (" . @switchNameList . ") specified must be the same"); 
        return ERROR;
    }

    #
    # Find more information about the switches to use.
    #
    my @switchIPList;
    my @foundNameList;
    my $indexSwitch;

    foreach my $switchNameToUse (@switchNameList)
    {
        $indexSwitch = 0;
        foreach my $switchName (@{$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchName'}})
        {
            if ($switchName eq $switchNameToUse)
            {
                # Get the current Switch Record
                push @switchIPList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchIP'}}[$indexSwitch];
#                push @switchUserList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchUsername'}}[$indexSwitch];
#                push @switchPWList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchPassword'}}[$indexSwitch];
                push @foundNameList, $switchName;
                last;  
            }
            $indexSwitch++;
        }
    }

    #
    # Check to see if the switches were found in the current VCG.
    #
    if (scalar(@switchIPList) != scalar(@switchNameList))
    {
        my $oldSeparator = $";
        $" = ", ";
        logInfo("Not all of the specified switches are part of the current VCG.");
        logInfo("Only these switches (@foundNameList) were found to be part of the current VCG.");
        $" = $oldSeparator;
        return ERROR;
    }
     
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    my @controllerList;
    $returnCode = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@controllerList);
    if ( $returnCode != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    #
    # Run the test.
    #
    $returnCode = TestLibs::FailOver::DownFELoopLong(\@controllerList,
                                                     \@switchIPList, 
                                                     \@portList, 
                                                     scalar(@controllerList),
                                                     1,
                                                     \%testParms,
                                                     ${$xtcDataPtr->{QUIET}});

    #
    # Disconnect from any controllers that have been connected to.
    #
    for (my $i = 0; $i < @controllerList; $i++)
    {
        if (ccbe_disconnect($controllerList[$i]) == ERROR)
        {
            logWarning("Failed to disconnect from controller");
        }
    }

    return $returnCode;
}

##############################################################################
#
#          Name: CallDownFELoopLong2
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: On system with only two FE interfaces per controller.
#                Downs the FE Loop for greater than 10 seconds.  A
#                failure is expected to occur.
#
##############################################################################
sub CallDownFELoopLong2
{                 
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
#    if (validateDownFELoopLongRequirements() != GOOD) 
#    {
#        return ERROR;
#    }

    #
    # Prepare the parameters for use in the test method.
    #
    my $switchCommaList = $testParms{"switchlist"};
    my $portMap = $testParms{"portlist"};

    #
    # Split the comma separated lists into arrays.
    #
    my @switchNameList = split /[,]/, $switchCommaList;
    my @portList = split /[,]/, $portMap;

    
    #
    # Find out if the number of ports and number of switches are the same
    #
    if (@portList != @switchNameList)
    {
        logInfo("The number of ports (" . @portList . ") and the number of switches (" . @switchNameList . ") specified must be the same"); 
        return ERROR;
    }

    #
    # Find more information about the switches to use.
    #
    my @switchIPList;
    my @foundNameList;
    my $indexSwitch;

    foreach my $switchNameToUse (@switchNameList)
    {
        $indexSwitch = 0;
        foreach my $switchName (@{$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchName'}})
        {
            if ($switchName eq $switchNameToUse)
            {
                # Get the current Switch Record
                push @switchIPList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchIP'}}[$indexSwitch];
#                push @switchUserList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchUsername'}}[$indexSwitch];
#                push @switchPWList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchPassword'}}[$indexSwitch];
                push @foundNameList, $switchName;
                last;  
            }
            $indexSwitch++;
        }
    }

    #
    # Check to see if the switches were found in the current VCG.
    #
    if (scalar(@switchIPList) != scalar(@switchNameList))
    {
        my $oldSeparator = $";
        $" = ", ";
        logInfo("Not all of the specified switches are part of the current VCG.");
        logInfo("Only these switches (@foundNameList) were found to be part of the current VCG.");
        $" = $oldSeparator;
        return ERROR;
    }
     
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    my @controllerList;
    $returnCode = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@controllerList);
    if ( $returnCode != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }


    #
    # Run the test.
    #
    $returnCode = TestLibs::FailOver::DownFELoopLong2(\@controllerList, 
                                                      \@switchIPList, 
                                                      \@portList, 
                                                      scalar(@controllerList), 
                                                      1,
                                                      \%testParms,
                                                     ${$xtcDataPtr->{QUIET}});

    #
    # Disconnect from any controllers that have been connected to.
    #
    for (my $i = 0; $i < @controllerList; $i++)
    {
        if (ccbe_disconnect($controllerList[$i]) == ERROR)
        {
            logWarning("Failed to disconnect from controller");
        }
    }

    return $returnCode;
}


##############################################################################
#
#          Name: CallDownFELoopTemp
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Downs the FE Loop for less than 10 seconds.  A failure is
#                NOT supposed to occur.
#
##############################################################################
sub CallDownFELoopTemp
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    #
    # Prepare the parameters for use in the test method.
    #
    my $switchCommaList = $testParms{"switchlist"};
    my $portMap = $testParms{"portlist"};

    #
    # Split the comma separated lists into arrays.
    #
    my @switchNameList = split /[,]/, $switchCommaList;
    my @portList = split /[,]/, $portMap;

    #
    # Find out if the number of ports and number of switches are the same
    #
    if (@portList != @switchNameList)
    {
        logInfo("The number of ports (" . @portList . ") and the number of switches (" . @switchNameList . ") specified must be the same"); 
        return ERROR;
    }

    #
    # Find more information about the switches to use.
    #
    my @switchIPList;
    my @foundNameList;
    my $indexSwitch;

    foreach my $switchNameToUse (@switchNameList)
    {
        $indexSwitch = 0;
        foreach my $switchName (@{$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchName'}})
        {
            if ($switchName eq $switchNameToUse)
            {
                # Get the current Switch Record
                push @switchIPList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchIP'}}[$indexSwitch];
#                push @switchUserList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchUsername'}}[$indexSwitch];
#                push @switchPWList, ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchPassword'}}[$indexSwitch];
                push @foundNameList, $switchName;
                last;  
            }
            $indexSwitch++;
        }
    }

    #
    # Check to see if the switches were found in the current VCG.
    #
    if (scalar(@switchIPList) != scalar(@switchNameList))
    {
        my $oldSeparator = $";
        $" = ", ";
        logInfo("Not all of the specified switches are part of the current VCG.");
        logInfo("Only these switches (@foundNameList) were found to be part of the current VCG.");
        $" = $oldSeparator;
        return ERROR;
    }
     
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    my @controllerList;
    $returnCode = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@controllerList);
    if ( $returnCode != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }


    #
    # Run the test.
    #
    $returnCode = TestLibs::NoFailOver::DownFELoopTemporarly(\@controllerList, 
                                                             \@switchIPList, 
                                                             \@portList, 
                                                             scalar(@controllerList), 
                                                             1,
                                                             \%testParms,
                                                             ${$xtcDataPtr->{QUIET}});

    #
    # Disconnect from any controllers that have been connected to.
    #
    for (my $i = 0; $i < @controllerList; $i++)
    {
        if (ccbe_disconnect($controllerList[$i]) == ERROR)
        {
            logWarning("Failed to disconnect from controller");
        }
    }

    return $returnCode;
}


##############################################################################
#
#          Name: CallHoldFEQlogicReset
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Holds the FE QLogic cards reset to induce a failover.
#
##############################################################################
sub CallHoldFEQlogicReset
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    my @controllerList;
    $returnCode = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@controllerList);
    if ( $returnCode != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    #
    # Run the test.
    #
    $returnCode = TestLibs::FailOver::HoldFEQLogicReset(\@controllerList, scalar(@controllerList), 1);

    #
    # Disconnect from any controllers that have been connected to.
    #
    for (my $i = 0; $i < @controllerList; $i++)
    {
        if (ccbe_disconnect($controllerList[$i]) == ERROR)
        {
            logWarning("Failed to disconnect from controller");
        }
    }

    return $returnCode;
}


##############################################################################
#
#          Name: CallRandomlyPullBECables
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Does automated, random BE cable pulls via a hub.
#
##############################################################################
sub CallRandomlyPullBECables
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $hubIPAddr;
    my $hubPass; 
    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    #
    # Prepare the parameters for use in the test method.
    #
    my $driveBayPort = ${$xtcDataPtr->{CURTESTARGUMENT}};
    my $num = $testParms{"numberofevents"}; 
    my $wait = randomInt($testParms{"waitmin"}, $testParms{"waitmax"});
    my $hold = randomInt($testParms{"holdmin"}, $testParms{"holdmax"});
    my $hubNameToUse = $testParms{"hubname"};   

    #
    # Find more information about the hub to use.
    #
    my $indexHub = 0;
    foreach my $hubName (@{$xtcDataPtr->{HUBS}->{$testGroup}->{'vixel'}->{'hubName'}})
    {
        if ($hubName eq $hubNameToUse)
        {
            # Get the current Hub Record
            $hubIPAddr  = ${$xtcDataPtr->{HUBS}->{$testGroup}->{'vixel'}->{'hubIP'}}[$indexHub];
            $hubPass  = ${$xtcDataPtr->{HUBS}->{$testGroup}->{'vixel'}->{'hubPassword'}}[$indexHub];
            last;  
        }
        $indexHub++;
    }

    #
    # Check to see if the hub was found in the current VCG.
    #
    if (!defined($hubIPAddr))
    {
        logInfo("The specified hub ($hubNameToUse) was not found in the current VCG.");
        return ERROR;
    }
    
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    my @controllerList;
    $returnCode = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@controllerList);
    if ( $returnCode != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    #
    # Run the test.
    #
    $returnCode = TestBypassBEVixelHubPorts(\@controllerList, $hubIPAddr, $num, $wait, $hold, $driveBayPort, 1, undef, $hubPass);

    #
    # Disconnect from any controllers that have been connected to.
    #
    for (my $i = 0; $i < @controllerList; $i++)
    {
        if (ccbe_disconnect($controllerList[$i]) == ERROR)
        {
            logWarning("Failed to disconnect from controller");
        }
    }

    return $returnCode;
}


##############################################################################
#
#          Name: CallIPCEthernetFiberCom
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Via a hub, pull/inserts the ethernet connection to all the
#                controllers in the current VCG at the same time.
#
##############################################################################
sub CallIPCEthernetFiberCom
{
    trace();
    
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $powerIPAddr;
    my $powerChan;  
    my $returnCode = ERROR; # The return code that is returned (default, ERROR). 
    
    #
    # Prepare the parameters for use in the test method.
    #
    my $powerNameToUse = ${$xtcDataPtr->{CURTESTARGUMENT}};
    my $num = $testParms{"numberofevents"}; 
    my $wait = randomInt($testParms{"waitmin"}, $testParms{"waitmax"});
    my $hold = randomInt($testParms{"holdmin"}, $testParms{"holdmax"});  
     
    #
    # Find more information about the power switch to use
    #
    my $indexPower = 0;
    foreach my $powerName (@{$xtcDataPtr->{POWER}->{$testGroup}->{'brocade'}->{'powerName'}})
    {
        if ($powerName eq $powerNameToUse)
        {
            # Get the current Power Record
            $powerIPAddr  = ${$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'switchIP'}}[$indexPower];
            $powerChan  = ${$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}}[$indexPower];
            last;  
        }
        $indexPower++;
    }

    #
    # Check to see if the moxa was found in the current VCG.
    #
    if (!defined($powerIPAddr))
    {
        logInfo("The specified power switch ($powerNameToUse) was not found in the current VCG.");
        return ERROR;
    }
    
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    my @controllerList;
    $returnCode = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@controllerList);
    if ( $returnCode != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    #
    # Run the test.
    #
    $returnCode = TestIPCEthernetFiberCom(\@controllerList, $num, $powerIPAddr, $powerChan, $wait, $hold, 1);
       
    #
    # Disconnect from any controllers that have been connected to.
    #
    for (my $i = 0; $i < @controllerList; $i++)
    {
        if (ccbe_disconnect($controllerList[$i]) == ERROR)
        {
            logWarning("Failed to disconnect from controller");
        }
    }

    return $returnCode;
}


##############################################################################
#
#          Name: CallRobustnessLabel
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Re-labels the physical disks in the current VCG with their 
#                current label.
#
##############################################################################
sub CallRobustnessLabel
{
    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    my $returnCode = ERROR; # The return code that is returned (default, ERROR).
    my $ccbeConnection;
    
    #
    # Run the test.
    #
    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        #
        # Connect to the VCG.
        #
        if (XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logInfo("Failed to connect to VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
            return ERROR;
        }
    
        # Call RobustnessLabel with Loop count of 1
        $returnCode = TestLibs::Robustness::RobustnessLabel(1);

        #
        # Disconnect from the VCG.
        #                
    
        if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
        }           
    }
    else
    {
        # Get a CCBE connections & Login (IP Address)
        $returnCode = ConnectMasterCCBE($xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \$ccbeConnection);    
        if ( $returnCode != GOOD )
        {
            TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
            return ERROR;
        }

        $returnCode = TestLibs::IntegCCBELib::ReLabelPD($ccbeConnection, 1);
        # Disconnect from CCBE
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeConnection);
    }
    
    return $returnCode;
}




#############################################################################################
#
#           Name:  XSSAVdMax
#
#         Inputs:  CNC serial number
#                  Hash with release levels
#                  Pointer to the Bigfoot IP's 
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################


sub XSSAVdMax
{
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms;
    
    if( $xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex] )
    {
        %testParms = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};
    }
    my $return;
    my @ccbeObjArray;
    my $mes;
    
    
    $mes = "***** Starting XSSA Create Max Vd's test";
    
    TestLibs::Logging::debug($mes);
    
    $return = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray);
    if ( $return != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    $return = CtlrLogTextAll(\@ccbeObjArray, $mes);
    
    if($return != GOOD)    
    {
        logInfo("Unable to send message to debug console");
        return ERROR;   
    }


    TestLibs::Logging::debug ("Reserving device ${$xtcDataPtr->{CURSERIALNUMBER}}");

    if(XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}}) != GOOD)
    {
        logInfo("Unable to reserver CNC ${$xtcDataPtr->{CURSERIALNUMBER}} ");
        return ERROR;
    }
    
    
    if(XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}}) != GOOD)
    {
        logInfo("Unable to reserver CNC ${$xtcDataPtr->{CURSERIALNUMBER}} ");
        return ERROR;
    }
    
    $return = TestLibs::XSSARobustness::MaxVd(${$xtcDataPtr->{CURTESTARGUMENT}}, \%testParms);
    
    if( $return != GOOD)
    {
        logInfo("Test Failed");
        return ERROR;
    }
    
    
    $return = unreserve( ${$xtcDataPtr->{CURSERIALNUMBER}} );
    
    if($return != XMCGOOD)
    {
        logInfo("Unable to unreserve CNC ${$xtcDataPtr->{CURSERIALNUMBER}}");
        return ERROR;
    }

    return GOOD;    



}

#############################################################################################
#
#           Name:  XSSACodeUpdate
#
#         Inputs:  xtcDataPointer
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################


sub XSSACodeUpdate
{
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my @FwFiles;
    my $return;
    my @ccbeObjArray;
    my $mes;
    my $inFlags = 0;          # validation flags           = 0 (Default)
    my $inLoops = 1;          # Loop count                 = 1 (Default)
    my %parms;


    #
    # Build parms hash from $xtcData
    #
    $parms{CURTESTARGUMENT} = ${$xtcDataPtr->{CURTESTARGUMENT}};
    $parms{CURSERIALNUMBER} = ${$xtcDataPtr->{CURSERIALNUMBER}};
    $parms{VCGS}            = \@{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}};
    
    # default the type to scriptagent, if it is defined use config file value (also get IP)
    $parms{CONNECTION} = "scriptagent";
    if (defined($testParms{connection}))
    {
        $parms{CONNECTION} = $testParms{connection};
        logInfo("Connection: $testParms{connection}\n");
        if (defined($testParms{xwsip}) && $testParms{connection} eq "xws")
        {
            $parms{XWSIP} = $testParms{xwsip};
            logInfo("IP:        $testParms{xwsip}\n");
        }
        else
        {
            logError("No URL defined for test type XWS\n");
            return(ERROR);
        }
    }
    logInfo("Parms CONNECTION = $parms{CONNECTION}");
    logInfo("TestP connection = $testParms{connection}");
    
    # add some CTE params from the xtcDataPtr if necessary
    if (defined(${$xtcDataPtr->{CTE}{FID}}))
    {
        $parms{CTE}{FID}        = ${$xtcDataPtr->{CTE}{FID}};
        $parms{CTE}{SYSTEM}     = ${$xtcDataPtr->{CTE}{SYSTEM}};
    }

#parms->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}

    #
    # Set Validation Flag if defined in Station Profile (overwrites Default setting)
    #
    if ( defined ($testParms{"validationflags"}) )
    {
       $inFlags = $testParms{"validationflags"};
    }
    
    #
    # Set number of Test Loops if defined in Station Profile (overwrites Default setting)
    #
        if ( defined ($testParms{"loopcount"}) )
    {
       $inLoops = $testParms{"loopcount"};
    }
 
    #
    # Checks for existance of FirmWare Files in the Station Profile & passes the data to a list
    #
    if ( defined ($testParms{"fwk1"}) )
    {
       push (@FwFiles, $testParms{"fwk1"});
    }
    
    if ( defined ($testParms{"fwk2"}) )
    {
       push (@FwFiles, $testParms{"fwk2"}) ;
    }

    if ( defined ($testParms{"fwk3"}) )
    {
       push (@FwFiles, $testParms{"fwk3"}) ;
    }

    if ( defined ($testParms{"fwk4"}) )
    {
       push (@FwFiles, $testParms{"fwk4"}) ;
    }
    
    #
    #Get number of FW Files being passed
    #
    my $fwKitcnt = scalar(@FwFiles);

    TestLibs::Logging::debug ("Reserving device \%parms->{CURSERIALNUMBER}");

    #
    # Connect to CCBE
    #
    $return = TestLibs::IntegCCBELib::CcbeConnectAll($parms{VCGS}, \@ccbeObjArray);
    
    if ( $return != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }
    $mes = "Starting Rolling Code Update";

    #
    # Log start message to all controllers
    #
    $return = CtlrLogTextAll(\@ccbeObjArray, $mes);
    
    if($return != GOOD)    
    {
       logInfo("Unable to send message to debug console");
       return ERROR;   
    }
   
    #
    # Call Test wrapper
    #
    logInfo("Calling wrapper");
    if(CodeUpdateWrapper(\@FwFiles,
                        \@ccbeObjArray,
                        $inFlags,
                        $inLoops,
                        $fwKitcnt,
                        $testGroup,
                        $testRecord,
                        $recordGroup,
                        \%parms ) != GOOD)
    {
        logInfo("Test Failed to start Sub-TestCase");
        return ERROR;
    }   
    return GOOD;

}



#############################################################################################
#
#           Name:  XSSALabel
#
#         Inputs:  CNC serial number
#                  Pointer to the Bigfoot IP's
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################


sub XSSALabel
{
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};

    my $return;
    my @ccbeObjArray;
    my $TestLoop;

    my $mes = "***** Starting XSSA Label Robustness script";

    TestLibs::Logging::logInfo( $mes );

    $return = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray);
    if ( $return != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    $return = CtlrLogTextAll(\@ccbeObjArray, $mes);
    
    if($return != GOOD)    
    {
        logInfo("Unable to send message to debug console");
        return ERROR;   
    }

    TestLibs::Logging::logInfo("Reserving device ${$xtcDataPtr->{CURSERIALNUMBER}}");

    if(XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}}) != GOOD)
    {
        logInfo("Unable to reserver CNC ${$xtcDataPtr->{CURSERIALNUMBER}} ");
        return ERROR;
    }
    
    for($TestLoop = 0; $TestLoop < ${$xtcDataPtr->{CURTESTARGUMENT}}; $TestLoop++)
    {
        logInfo("*************************************************");
        logInfo(" ");
        logInfo(" Total loops - ${$xtcDataPtr->{CURTESTARGUMENT}}; Completed loops - $TestLoop");
        logInfo(" ");
                
        
        if( LabelRobustness( ${$xtcDataPtr->{CURSERIALNUMBER}} ) != GOOD )
        {   
            logInfo("Test faild while executing XSSA label robustness script ");
            return ERROR;
        }
    }
    
    $return = unreserve( ${$xtcDataPtr->{CURSERIALNUMBER}} );
    
    if($return != XMCGOOD)
    {
        logInfo("Unable to unreserve CNC ${$xtcDataPtr->{CURSERIALNUMBER}}");
    }
       
   
    return GOOD;
}



#############################################################################################
#
#           Name:  XSSAGoodPath
#
#         Inputs:  CNC serial number
#                  Pointer to the Bigfoot IP's
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################


sub XSSAGoodPath
{
    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    my $return;

    my $system;

    my $mes = "***** Starting XSSA Good Path script";

    TestLibs::Logging::logInfo( $mes );

    if(XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}}) != GOOD)
    {
        logInfo("Unable to reserver CNC ${$xtcDataPtr->{CURSERIALNUMBER}} ");
        return ERROR;
    }
    
    my @CtrInfo = XIOtech::sanscript::info();
    $system = "Magnitude 3D";


    
    if( $system =~ "Magnitude 3D" || $system == 1)
    {
        if( GoodPathBigfoot( ${$xtcDataPtr->{CURSERIALNUMBER}}, $system ) != GOOD )
        {   
            logInfo("Test failed while executing XSSA Bigfoot Good Path script ");
            return ERROR;
        }        
    }
    else
    {
        logInfo("Unknown Controller type - Expected Magnitude or Magnitude 3D     Actual Data: $system");
        return ERROR;
    }

    $return = unreserve( ${$xtcDataPtr->{CURSERIALNUMBER}} );
    
    if($return != XMCGOOD)
    {
        logInfo("Unable to unreserve CNC ${$xtcDataPtr->{CURSERIALNUMBER}}");
    }
    
    #MAGNITUDE
    # BIGFOOT

    return GOOD;
}

#############################################################################################
#
#           Name:  XSSAORT
#
#         Inputs:  xtcDataPointer
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################


sub XSSAORT
{
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my @FwFiles;
    my $return;
    my @ccbeObjArray;
    my $mes;
    my $inFlags = 0;          # validation flags           = 0 (Default)
    my $inLoops = 1;          # Loop count                 = 1 (Default)
    my %parms;


    #
    # Build parms hash from $xtcData
    #
    $parms{CURTESTARGUMENT} = ${$xtcDataPtr->{CURTESTARGUMENT}};
    $parms{CURSERIALNUMBER} = ${$xtcDataPtr->{CURSERIALNUMBER}};
    $parms{VCGS}             = \@{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}};

#parms->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}

    #
    # Set Validation Flag if defined in Station Profile (overwrites Default setting)
    #
    if ( defined ($testParms{"validationflags"}) )
    {
       $inFlags = $testParms{"validationflags"};
    }
    
    #
    # Set number of Test Loops if defined in Station Profile (overwrites Default setting)
    #
        if ( defined ($testParms{"loopcount"}) )
    {
       $inLoops = $testParms{"loopcount"};
    }
 
    #
    # Checks for existance of FirmWare Files in the Station Profile & passes the data to a list
    #
    if ( defined ($testParms{"fwk1"}) )
    {
       push (@FwFiles, $testParms{"fwk1"});
    }
    
    if ( defined ($testParms{"fwk2"}) )
    {
       push (@FwFiles, $testParms{"fwk2"}) ;
    }

    if ( defined ($testParms{"fwk3"}) )
    {
       push (@FwFiles, $testParms{"fwk3"}) ;
    }

    if ( defined ($testParms{"fwk4"}) )
    {
       push (@FwFiles, $testParms{"fwk4"}) ;
    }

    if ( defined ($testParms{"fwk5"}) )
    {
       push (@FwFiles, $testParms{"fwk5"}) ;
    }

    if ( defined ($testParms{"fwk6"}) )
    {
       push (@FwFiles, $testParms{"fwk6"}) ;
    }

    if ( defined ($testParms{"fwk7"}) )
    {
       push (@FwFiles, $testParms{"fwk7"}) ;
    }

    if ( defined ($testParms{"fwk8"}) )
    {
       push (@FwFiles, $testParms{"fwk8"}) ;
    }

    if ( defined ($testParms{"fwk9"}) )
    {
       push (@FwFiles, $testParms{"fwk9"}) ;
    }

    #
    #Get number of FW Files being passed
    #
    my $fwKitcnt = scalar(@FwFiles);

    TestLibs::Logging::debug ("Reserving device \%parms->{CURSERIALNUMBER}");

    #
    # Connect to CCBE
    #
    $return = TestLibs::IntegCCBELib::CcbeConnectAll($parms{VCGS}, \@ccbeObjArray);
    
    if ( $return != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }
    $mes = "Starting On-going Reliability test";

    #
    # Log start message to all controllers
    #
    $return = CtlrLogTextAll(\@ccbeObjArray, $mes);
    
    if($return != GOOD)    
    {
       logInfo("Unable to send message to debug console");
       return ERROR;   
    }
   
    #
    # Call Test wrapper
    #
    if(ORTWrapper(\@FwFiles,
                        \@ccbeObjArray,
                        $inFlags,
                        $inLoops,
                        $fwKitcnt,
                        $testGroup,
                        $testRecord,
                        $recordGroup,
                        \%parms ) != GOOD)
    {
        logInfo("Test Failed to start Sub-TestCase");
        return ERROR;
    }   
    return GOOD;

}


#############################################################################################
#
#           Name:  XSSAExpMaxBigfoot
#
#         Inputs:  CNC serial number
#                  Pointer to the Bigfoot IP's
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################


sub XSSAExpMaxBigfoot
{
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms;
    my $Return;

    if( $xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex] )
    {
        %testParms = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};
    }
   
    
    my $mes = "***** Starting XSSA Expand virtual disk maximun times script";

    TestLibs::Logging::logInfo( $mes );
    
    # reserve device
    
    if(XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}}) != GOOD)
    {
        logInfo("Unable to reserver CNC ${$xtcDataPtr->{CURSERIALNUMBER}} ");
        return ERROR;
    }
    

    # call the test funciton 
    
    $Return = MaxExpandBigfoot(${$xtcDataPtr->{CURTESTARGUMENT}}, \%testParms);

    if($Return != GOOD)
    {
        logInfo("Test failed....");
        return ERROR;
    }
    
    # unreserve the device
        
    $Return = unreserve( ${$xtcDataPtr->{CURSERIALNUMBER}} );
    
    if($Return != XMCGOOD)
    {
        logInfo("Unable to unreserve CNC ${$xtcDataPtr->{CURSERIALNUMBER}}");
    }
    

    return GOOD;
}

#############################################################################################
#
#           Name:  XSSAExpMaxMag
#
#         Inputs:  CNC serial number
#                  Pointer to the Bigfoot IP's
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################


sub XSSAExpMaxMag
{
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms;
    my $Return;

    if( $xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex] )
    {
        %testParms = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};
    }
   
    my $mes = "***** Starting XSSA Expand virtual disk maximun times script";

    TestLibs::Logging::logInfo( $mes );
    
    # reserve the device
    
    if(XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}}) != GOOD)
    {
        logInfo("Unable to reserver CNC ${$xtcDataPtr->{CURSERIALNUMBER}} ");
        return ERROR;
    }
   
    # call the test function 
    
    $Return = MaxExpandMagnitude(${$xtcDataPtr->{CURTESTARGUMENT}}, \%testParms);

    if($Return != GOOD)
    {
        logInfo("Test failed....");
        return ERROR;
    }
    
    # unreserve the device
    
    $Return = unreserve( ${$xtcDataPtr->{CURSERIALNUMBER}} );
    
    if($Return != XMCGOOD)
    {
        logInfo("Unable to unreserve CNC ${$xtcDataPtr->{CURSERIALNUMBER}}");
    }
    
    return GOOD;
}


#############################################################################################
#
#           Name:  XSSAErrorPath
#
#         Inputs:  CNC serial number
#                  Pointer to the Bigfoot IP's
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################


sub XSSAErrorPath
{
    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    my $return;

    my $mes = "***** Starting XSSA Error Path script";

    TestLibs::Logging::logInfo( $mes );

    if(XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}}) != GOOD)
    {
        logInfo("Unable to reserver CNC ${$xtcDataPtr->{CURSERIALNUMBER}} ");
        return ERROR;
    }

    
    if( SystemErrorPath( ${$xtcDataPtr->{CURTESTARGUMENT}} ) != GOOD )
    {   
        logInfo("Test faild while executing XSSA Bigfoot Good Path script ");
        return ERROR;
    }        

    $return = unreserve( ${$xtcDataPtr->{CURSERIALNUMBER}} );
    
    if($return != XMCGOOD)
    {
        logInfo("Unable to unreserve CNC ${$xtcDataPtr->{CURSERIALNUMBER}}");
    }
    
    return GOOD;
}



#############################################################################################
#
#           Name:  XSSADefrag
#
#         Inputs:  CNC serial number
#                  Pointer to the Bigfoot IP's
#                  Number of times to execute the test
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################


sub XSSADefrag
{
    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};

    my @VdId =(0, 1, 2, 3); 
    my @Raid = (10, 10, 10, 10);
    my @Capacity = (1024, 1024, 1024, 1024);
    my @DiskGroup = (23, 23, 23, 23);
    my @Name = ("Test1", "Test2", "Test3", "Test4");
    my @DataDr;
    my @WorkSet;
    my @Vblock;
    my @FreeWorkSet; 
    my @FreeVblock;
    my $TestLoop;


    my $return;
    my @ccbeObjArray;

    my $mes = "***** Starting XSSA Defrag test ";

    TestLibs::Logging::logInfo( $mes );

    $return = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray);
    if ( $return != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    $return = CtlrLogTextAll(\@ccbeObjArray, $mes);
    
    if($return != GOOD)    
    {
        logInfo("Unable to send message to debug console");
        return ERROR;   
    }

    TestLibs::Logging::logInfo("Reserving device ${$xtcDataPtr->{CURSERIALNUMBER}}");

    if(XSSA_Reserve(${$xtcDataPtr->{CURSERIALNUMBER}}) != GOOD)
    {
        logInfo("Unable to reserver CNC ${$xtcDataPtr->{CURSERIALNUMBER}} ");
        return ERROR;
    }

    logInfo("Looking for free vblocks and free worksets");

    $return = FindFreeWB(\@FreeVblock, \@FreeWorkSet);
    
    if($return != GOOD)
    {
        logInfo("Error occured while getting free vblocks and worksets");
        return ERROR;
    }
    
    if(scalar(@FreeVblock) == 0)
    {
        logInfo("There are no free vblocks available");
        return ERROR;
    }
    
    logInfo("Following vblock are free @FreeVblock ");

    if(scalar(@FreeWorkSet) == 0)
    {
        logInfo("There are no free worksets available");
        return ERROR;
    }
    logInfo("Following work sets are free @FreeWorkSet");
    # build arrays
    
    for(my $loop = 0; $loop < scalar(@Name); $loop++)
    {
        push(@WorkSet, $FreeWorkSet[0]);
        push(@Vblock, $FreeVblock[0]);
    }
    
    logInfo("Getting list of all data drives....");
    
    $return = PdList(\@DataDr, XSSADATATYPE);
    
    if($return != GOOD) # in case of error, first element is Invalid
    {
        logInfo("Unable get list of Pd Id labeled as ". XSSADATATYPE);
        return ERROR;   
    }
    
    if(scalar(@DataDr) == 0)
    {
        logInfo("There are no drive labeled as data");
        return ERROR;           
    }

    logInfo("Setting Disk Group to $DiskGroup[0]");
    
    $return = diskgroupSet( $DiskGroup[0] );
    
    if($return != XMCGOOD)
    {
        logInfo("Unable to set disk group N  $DiskGroup[0]");
        DumpXSSAError();
        return ERROR;       
    }

    logInfo("Adding all data drives to disk group N  $DiskGroup[0]");
    
    $return = diskgroupAdd(@DataDr);
    
    if($return != XMCGOOD)
    {
        logWarning("Unable to add Pd Ids: @DataDr to disk group N  $DiskGroup[0]");
        DumpXSSAError();
        return ERROR;
    }   
        
    #
    # Main loop
    #
    for($TestLoop = 0; $TestLoop < ${$xtcDataPtr->{CURTESTARGUMENT}}; $TestLoop++)
    {
        
        logInfo("*************************************************");
        logInfo(" ");
        logInfo(" Total loops - ${$xtcDataPtr->{CURTESTARGUMENT}}; Completed loops - $TestLoop");
        logInfo(" ");
        
        
        $return = PdDefrag( \@Name, 
                            \@VdId, 
                            \@Raid,
                            \@DiskGroup, 
                            \@Capacity, 
                            \@WorkSet, 
                            \@Vblock);

        if($return != GOOD)
        {
            print("Error: Defrag test failed");
            return ERROR;
        }
    }

    $return = unreserve( ${$xtcDataPtr->{CURSERIALNUMBER}} );
    
    if($return != XMCGOOD)
    {
        logInfo("Unable to unreserve CNC ${$xtcDataPtr->{CURSERIALNUMBER}} ");
        return ERROR;
    }

    return GOOD;
}



#############################################################################################
#
#           Name:  CCBScrub
#
#         Inputs:  Pointer to the Array 
#                  
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################


sub CCBScrub
{
    my ($xtcDataPtr) = @_;
    
    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};
    my @ccbeObjArray;
    my @serialNums;
    my $return;
    my $mes = " **** Starting Scrub test";

    $return = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray);
    if ( $return != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    $return = CtlrLogTextAll(\@ccbeObjArray, $mes);
    
    if($return != GOOD)    
    {
        logInfo("Unable to send message to debug console");
        return ERROR;   
    }

    $return = GetSerialFromMaster (\@ccbeObjArray, \@serialNums, \@{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}});
    
    if ($return != GOOD)
    {
        TestLibs::Logging::logWarning ("Failed to get Serial Numbers from Master");
        return ERROR;
    }

    $return = TestLibs::scrub::ScrubMain(\@ccbeObjArray, 
                                         \@serialNums, 
                                         ${$xtcDataPtr->{CURTESTARGUMENT}}, 
                                         $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}, 
                                         $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'});
    if($return != GOOD)
    {
        return ERROR;
    }
    logInfo("Scrub test complete...."); 
 
    
    return GOOD;
}
#############################################################################################
#
#           Name:  WorkLoadTest
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library
#
#    Description:  Copyright 2004-2005 XIOtech
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub WorkLoadTest
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my $workloadReturn;
    my @workloadSNs;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Get our controller SNs.
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $workloadSNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
        if ( $workloadSNs[$i] == INVALID )
        {
            TestLibs::Logging::logInfo("Failed to get serial number for controller $i.");
            return ERROR;
        } 
    }

    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray");

    # Call the Work Load main function
    $workloadReturn = &TestLibs::Workload::WorkLoadMain(\@ccbeObjArray,
                                                  \@workloadSNs,
                                                  $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, 0, 0 );

    if ($workloadReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from WorkLoad:$workloadReturn");
        return $workloadReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}

#############################################################################################
#
#           Name:  VdiskPriorityTest
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub VdiskPriorityTest
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

# Local Variables
    my $returnValue;
    my $VPriorityReturn;
    my @VPrioritySNs;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Get our controller SNs.
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $VPrioritySNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
        if ( $VPrioritySNs[$i] == INVALID )
        {
            TestLibs::Logging::logInfo("Failed to get serial number for controller $i.");
            return ERROR;
        } 
    }

    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}},
             curTestArgument:${$xtcDataPtr->{CURTESTARGUMENT}}");

    # Call the Defrag function
    $VPriorityReturn = TestLibs::VdiskPriority::VdiskPriorityEntry (\@ccbeObjArray,
                                                  \@VPrioritySNs,
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                                  $xtcDataPtr->{SERVERS}->{$testGroup}->{'windows'}->{'serverWWN'},
                                                  $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'},
                                                 ${$xtcDataPtr->{CURTESTARGUMENT}});
    if ($VPriorityReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from vdiskpriority:$VPriorityReturn");
        return $VPriorityReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}

#############################################################################################
#
#           Name:  GeoRaidTest
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library
#
#    Description:  Copyright 2005 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub GeoRaidTest
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    # Local Variables
    my $returnValue;
    my $GeoRaidReturn;
    my @GeoRaidSNs;
    my @ccbeObjArray;
    my $i;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    # Get our controller SNs.
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $GeoRaidSNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
        if ( $GeoRaidSNs[$i] == INVALID )
        {
            TestLibs::Logging::logInfo("Failed to get serial number for controller $i.");
            return ERROR;
        } 
    }

    # Debug
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}},
             curTestArgument:${$xtcDataPtr->{CURTESTARGUMENT}}");

    # Call the Defrag function
    $GeoRaidReturn = TestLibs::GeoRaid::GeoRaidTestEntry (\@ccbeObjArray,
                                                  \@GeoRaidSNs,
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                                  $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                                  $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'},
                                                  $xtcDataPtr->{SERVERS}->{$testGroup}->{'windows'}->{'serverWWN'},
                                                  ${$xtcDataPtr->{CURTESTARGUMENT}});
    if ($GeoRaidReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from GeoRaid:$GeoRaidReturn");
        return $GeoRaidReturn;
    }
    
    # Disconnect from all controllers in this VCG
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
 }   

#############################################################################################
#
#           Name:  RegressionNWay
#
#         Inputs:  Pointer to the Array 
#                  
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2004 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub RegressionNWay
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->
                                                        {'testsParms'}[$testIndex]};
    my @iscsiTargetId;
    my @iscsiParamId;
    my @iscsiTargetParam;
    

    if (defined (%{$xtcDataPtr->{ISCSIINTERFACE}->{$testGroup}->{'ethernet'}}))
    {
        @iscsiTargetId    = @{$xtcDataPtr->{ISCSIINTERFACE}->{$testGroup}->{'ethernet'}->{'iscsiTargetId'}};
        @iscsiParamId     = @{$xtcDataPtr->{ISCSIINTERFACE}->{$testGroup}->{'ethernet'}->{'iscsiParamId'}};
        @iscsiTargetParam = @{$xtcDataPtr->{ISCSIINTERFACE}->{$testGroup}->{'ethernet'}->{'iscsiTargetParam'}};
    }


    my $returnValue;
    my @ccbeObjArray;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->
                                                {'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }
    
    # NOTE: the keys used for the testParms must be listed as LOWER CASE, even 
    #       if mixed or upper case in the definition in the testcase.
    TestLibs::Logging::logInfo ("Launching RegressionNWay test with the ".
                                "following parameters:\n" .
                                "crtVCG    = $testParms{'crtvcg'}\n".
                                "dataDrvs  = $testParms{'datadrvs'}\n".
                                "unSfDrvs  = $testParms{'unsfdrvs'}\n".
                                "hotSpDrvs = $testParms{'hotspdrvs'}\n".
                                "loopCount = $testParms{'loopcount'}\n".
                                "flags     = $testParms{'flags'}\n");

    # Start the test
    $returnValue = TestLibs::BaseRegression::BaseRegressionNWay( 
                                            \@ccbeObjArray,
                                            $testParms{'crtvcg'},
                                            $testParms{'datadrvs'},
                                            $testParms{'unsfdrvs'},
                                            $testParms{'hotspdrvs'},
                                            $testParms{'loopcount'},
                                            $testParms{'flags'},
                                            \@iscsiTargetId,
                                            \@iscsiParamId,
                                            \@iscsiTargetParam,
                                            );
    if ($returnValue != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad Return Code from " .
                                       "BaseRegressionNWay: $returnValue");
        return ERROR;
    }

    return GOOD;
}

#######################################################################
### Function name: WCTests
###
### Purpose: Process configuration data and then call WCTestEntry
##           This is for resync test cases that use a single DSC
##
## INPUT:    
## Outputs: GOOD, if successful, ERROR otherwise
#######################################################################

sub WCTests
{
    trace();                        # This allows function tracability

    my $msg;

    my ($xtcDataPtr) = @_;


    #
    # The following indicate where the data for this test can be found in the 
    # xtcData hash.
    #

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %parms;
    
    if (defined (%{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]}))
    {
        %parms = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};
    }

    # Local Variables
    my $returnValue;
    my @groupCCBE;
    my @snList;
    my $snPtr;
    my $i;

    TestLibs::Logging::debug ("Find all controllers in the VCG");
    
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@groupCCBE);
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    #
    # Build the Serial Number list
    #
    for ( $i = 0; $i < scalar( @groupCCBE); $i++)
    {
        $snList[$i] = $groupCCBE[$i]->{SERIAL_NUM};
    }
    
    $snPtr = \@snList;

    $msg = sprintf("The current XTC loop count is %d\n", $xtcDataPtr->{CURRENTLOOP} ); 
    
    CtlrLogTextAll (\@groupCCBE, $msg);

    $parms{testcase } = ${$xtcDataPtr->{CURTESTARGUMENT}};
    
    #
    # This is the call to do the test. All data needed by the test to run should
    # be passed. Passing xtcDataPtr is a bad thing to do. All data needed
    # shpould be extracted from xtcData nad passed (the test should be working
    # from a copy). In this example, all parameters specific to the test have
    # been passed in the parms hash. 
    #
    
    
    $returnValue = WrtCacheTestEntry( \@groupCCBE,
                                     $snPtr, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}, 
                                     \%parms,              # misc parameter hash
                                     0                    # (future) data for cable pull test
                                   );
                                
    if ($returnValue != GOOD)
    {
        return $returnValue;
    }
    

    foreach my $controllerCCBE (@groupCCBE)             # Disconnect from all controllers in this VCG
    {
        ccbe_disconnect($controllerCCBE);
    }

    return GOOD;
}


#############################################################################################
#
#           Name:  QLResetsLauncher
#
#         Inputs:  Pointer to the Array 
#                  
#
#        Outputs:  ERROR, GOOD
#
#    Description:  Copyright 2004 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub QLResetsLauncher
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->
                                                        {'testsParms'}[$testIndex]};

    my $returnValue;
    my @ccbeObjArray;

    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->
                                                {'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }
    
    # NOTE: the keys used for the testParms must be listed as LOWER CASE, even 
    #       if mixed or upper case in the definition in the testcase.
    TestLibs::Logging::logInfo ("Launching QLResets test with the ".
                                "following parameters:\n" .
                                "loopCount = $testParms{'loopcount'}\n");

    # Start the test
    $returnValue = TestLibs::BaseRegression::QLResets( 
                                            \@ccbeObjArray,
                                            $testParms{'loopcount'});
    if ($returnValue != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad Return Code from " .
                                       "QLResets: $returnValue");
        return ERROR;
    }

    return GOOD;
}

=head2 XSSADefragAllTests function

This test case parses the profile information and passes it to the XSSADefragAllEntry point. 
     0) Parse data from profile
	 1) Send to Entry point
 
=cut

=over 1

=item Usage:

 my $rc = XSSADefragAllTests; }


 where:  Nothing passes

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:



=item Initial Conditions:


=back

=cut

# Put in Launcher.pm
#############################################################################################
#
#           Name:  XSSADefragAllTests
#
#
#    Description:  Copyright 2004 XIOtech Corporation
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub XSSADefragAllTests
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};
	
	#
    # Local Variables
    #
    my $return;
    my $XSSAdefragAllReturn;
    my @defragSNs;
    my @ccbeObjArray;
    my $i;

	#
    # Connect to all the controllers in this VCG
    #
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
   
    $return = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 

    if($return != GOOD)    
    {
        logInfo("Unable to log in to one or more Controllers");
        return ERROR;   
    }


    #
    # Get our controller SNs.
    #
    for ($i = 0; $i < scalar(@ccbeObjArray) ; $i++)
    {
        $defragSNs[$i] = TestLibs::IntegCCBELib::GetSerial($ccbeObjArray[$i]);
    }
	
	#
    # Debug
    #
    TestLibs::Logging::debug ("CCBE Objs:@ccbeObjArray,
             moxaIPs:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}},
             moxaChannels:@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}},
             curTestArgument:${$xtcDataPtr->{CURTESTARGUMENT}}");


    #
    # Call XSSADefragAll Test Case Function
    #
    $XSSAdefragAllReturn = XSSADefragAllEntry (\@ccbeObjArray,
                                                            \@defragSNs,
                                                            $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'},
                                                            $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'},
                                                            ${$xtcDataPtr->{CURTESTGROUP}},
                                                            ${$xtcDataPtr->{CURSERIALNUMBER}},
                                                            ${$xtcDataPtr->{CURTESTARGUMENT}},
                                                            0);                     # last parm is a loop count, 0= autoset

    if ($XSSAdefragAllReturn != GOOD)
    {
        TestLibs::Logging::logWarning ("Bad return code from XSSA Defrag All:$XSSAdefragAllReturn");
        return $XSSAdefragAllReturn;
    }
    
    #
    # Disconnect from all controllers in this VCG
    #
    TestLibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    return GOOD;
}
#######################################################################
### Function name: Anarchy
###
### Purpose: Process configuration data and then call Anarchyloop
##
## INPUT:    
## Outputs: GOOD, if successful, ERROR otherwise
#######################################################################

sub Anarchy
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;
    
    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

    my $msg;
    my %parms;
    my @resources;

    # Local Variables
    my $returnValue;
    my @groupCCBE;

    # the optional parms ( and their current default values )

    my $tld;                  # duration of the time line  = 120 sec
    my $rcd;                  # reconnect dealy            = 60 sec
    my $w4st;                 # wait for (good) state time = 360 sec
    my $inFlags;              # validation flags           = 0
    my $fmlc;                 # loops sent to FailOverLoop() = 1


    TestLibs::Logging::debug ("Find all controllers in the VCG");
    
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@groupCCBE);
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }

    $msg = sprintf("The current XTC loop count is %d\n", $xtcDataPtr->{CURRENTLOOP} ); 
    
    CtlrLogTextAll (\@groupCCBE, $msg);

    # set the optional parametes, or leave as undefined

    # print"Optional parms are defaulted\n";


    if ( defined ($testParms{"mirrorresyncwait"}) )
    {
        # print "updating mrw\n";
        $parms{MIRRORRESYNCWAIT } = $testParms{"mirrorresyncwait"};
    }

    if ( defined ($testParms{"timelineduration"}) )
    {
        # print "updating tld\n";
        $parms{TIMELINEDUR } = $testParms{"timelineduration"};
    }

    if ( defined ($testParms{"reconnectdelay"}) )
    {
        # print "updating rcd\n";
        $parms{RECONNECTDEL } = $testParms{"reconnectdelay"};
    }

    if ( defined ($testParms{"wait4statetime"}) )
    {
        # print "updating w4st\n";
        $parms{WAIT4STIME } = $testParms{"wait4statetime"};
    }

    if ( defined ($testParms{"validationflags"}) )
    {
        # print "updating inFlags\n";
        $parms{FLAGS } = $testParms{"validationflags"};
    }

    if ( defined ($testParms{"driveidcorrupt"}) )
    {
        # print "updating inFlags\n";
        $parms{DRIVEIDCORRUPT } = $testParms{"driveidcorrupt"};
    }
    
    if ( defined ($testParms{"failovermidloopcount"}) )
    {
        # print "updating inFlags\n";
        $parms{LOOPCOUNT } = $testParms{"failovermidloopcount"};
    }
    else
    {
        $parms{LOOPCOUNT }= 1;                #  old default behavior
    }

    $parms{FAILTYPE } = ${$xtcDataPtr->{CURTESTARGUMENT}};
    
    $returnValue = AnarchyEntry( \@groupCCBE, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}, 
                                     $xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}, 
                                     \%parms,              # misc parameter hash
                                     0                   # (future) data for cable pull test
                                     );
                                     
    $xtcDataPtr->{TESTLOOPS}=$parms{TESTLOOPS};                            
    if ($returnValue != GOOD)
    {
        return $returnValue;
    }
    

    foreach my $controllerCCBE (@groupCCBE)             # Disconnect from all controllers in this VCG
    {
        ccbe_disconnect($controllerCCBE);
    }

    TestLibs::utility::randomDelay($testParms{"failcontrollerwaitmin"}, $testParms{"failcontrollerwaitmax"});

    return GOOD;
}

###############################################################################

1;

#
#
# $Log$
# Revision 1.10  2006/12/15 17:54:45  PlasterE
# Added support for 750 RCU.  The directory Test/TestLibs/WsLib holds the DLLs
# needed in order to communicate to Ewok.
# TBolt00000000
#
# Revision 1.9  2006/09/12 06:26:14  AnasuriG
# TBolt00015847 added iscsi targets configuration
#
# Revision 1.8  2006/06/01 11:13:27  AnasuriG
# Replaced shortWWN by ServerWWN
#
# Revision 1.7  2006/05/24 07:51:30  EidenN
# Moved from 750 Branch
#
# Revision 1.5.2.2  2006/05/17 06:48:43  EidenN
# no message
#
# Revision 1.5.2.1  2006/03/10 13:58:26  HoltyB
# TBolt00000000:Merged with HEAD
#
# Revision 1.6  2006/02/24 08:57:24  AnasuriG
# Added code for FE simulator configuration
#
# Revision 1.5  2006/01/09 12:10:34  AnasuriG
# Added new subroutine to invoke georaid test cases
#
# Revision 1.4  2005/09/13 14:15:18  ElvesterN
# Added CTE parameter from station file.
# Reviewed by Neal Eiden.
#
# Revision 1.3  2005/08/16 09:45:59  BalemarthyS
# Removed unwanted characters
#
# Revision 1.2  2005/08/16 09:32:43  BalemarthyS
# Added pdiskspindown and vdiskpriority tests
#
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
# Revision 1.67  2005/04/01 15:50:53  EidenN
# Tbolt00000:  Added On-going reliability testcase
#
# Revision 1.66  2005/03/08 09:16:37  BalemarthyS
# Added WorkLoadTest Subroutine for Running Workload Test from SCM by Gopinadh
#
# Revision 1.65  2005/03/02 16:56:19  EidenN
# Tbolt0000000:  Fixed XSSACodeUpdate pointer deref - Reviewed By:  PalmiD
#
# Revision 1.64  2005/03/02 16:36:12  PalmiD
# TBolt00000000: Fixed WCTests which was corrupted by a faulty merge.
# Reviewed by Craig Menning (virtually).
#
# Revision 1.63  2005/02/23 20:26:32  AndersonD
# Tbolt00000000: Initial relase of the power cycling tests. Reviewed by Craig.
#
# Revision 1.62  2005/02/07 14:22:46  EidenN
# Tbolt0000:  Changed pass parms to XSSACodeupdate - Reviewed by: Cmenning
#
# Revision 1.61  2004/12/22 21:35:53  EidenN
# Tbolt:000000:  Re-write of PowerCycleDriveBay section - Reviewed By: CMenning
#
# Revision 1.60  2004/12/06 22:47:36  EidenN
# Tbolt0000: Re-write of  XSSACodeUpdate.  Added Validation Flags,  Test Loop count  and moved data to the proper place.  Reviewed by:  MenningC
#
# Revision 1.59  2004/12/01 19:25:58  PalmiD
# TBolt00000000: Added $snPtr to WrtCacheTestEntry.  Reviewed by
# Craig Menning.
#
# Revision 1.58  2004/11/22 21:58:23  PalmiD
# TBolt00000000: General cleanup of WCTests routine. Removed references to %testparms hash.  Reviewed by Craig Menning.
#
# Revision 1.57  2004/11/16 22:13:21  PalmiD
# TBolt00000000: Added a single pass of entire hash to elliminate need to add
# new parms in launcher.  Reviewed by Craig Menning
#
# Revision 1.56  2004/11/11 22:55:51  PalmiD
# TBolt00000000: Updated entry for write cashe tests (WrtCacheTestEntry).
# Reviewed by Craig Menning
#
# Revision 1.55  2004/11/08 17:33:34  MenningC
# Tbolt00000000: updates for wrtcache testing
#
# Revision 1.54  2004/11/08 14:53:10  MenningC
# tbolot00000000: additions for resync, wrtcache and wookiee specific tests, reviewed by Dave P.
#
# Revision 1.53  2004/10/26 22:35:08  MenningC
# Tbolt00000000: updates to support resync in Rel 3.1/Yeti. reviewed by Al
#
# Revision 1.52  2004/10/13 18:24:10  EidenN
# Tbolt0000:  Fixed eval error with wookie hardware
#
# Revision 1.51  2004/10/08 14:42:00  KohlmeyerA
# Tbolt00000000:  Gopinadh Anasuri commented out a call to a function that no longer exists
# in CallDownFELoopLong2.  Reviewed by Allen
#
# Revision 1.50  2004/10/03 18:06:30  EidenN
# Tbolt0000:  Fixed XSSAdefrag to create RAID 10 vdisk only for Yeti support of YM2.  Fixed eval error and wrong Defrag was being used.
#
# Revision 1.49  2004/09/02 21:21:19  KohlmeyerA
# Tbolt00000000:  Added missing checks of returns.
# Reviewed by Craig.
#
# Revision 1.48  2004/08/31 19:09:15  EidenN
# tbolt00000000:  Added XSSA Defrag All Test Suite   Reviewed by: Al
#
# Revision 1.47  2004/07/12 15:29:33  MenningC
# tbolt00000000: add orphan raids test.  reviewed by Al
#
# Revision 1.46  2004/06/15 21:26:51  MenningC
# tbolt00000000: fail when we can't connect to a controller at the start of failover. reviewed by Al
#
# Revision 1.45  2004/06/15 21:25:16  MenningC
# tbolt00000000: updates for tclaunch for eng test; reviewed by Al
#
# Revision 1.44  2004/06/08 22:25:23  KohlmeyerA
# Tbolt00000000:  Changes to allow the goodpath functions to be called from SCM or
# testcase file.  Reviewed by Craig.
#
# Revision 1.43  2004/06/02 19:53:36  MenningC
# tbolt00000000: fixed a warning
#
# Revision 1.42  2004/05/28 14:27:39  MenningC
# tbolt00000000: fix to FECommunication test, reviewed by Jeff W.
#
# Revision 1.41  2004/04/14 18:06:06  MenningC
# tbolt00000000: fixed a startup warning, reviewed by Al
#
# Revision 1.40  2004/02/25 21:27:44  VossO
# Tbolt00000000 added option 5 in code appay REV GM
#
# Revision 1.39  2004/02/05 21:48:21  SchibillaM
# TBolt00000000: Add NWayConfigTest
#
# Revision 1.38  2004/01/21 17:13:21  RysavyR
# TBolt00000000: Added "QLResets" test capability to XTC.
# Reviewed by Craig.
#
# Revision 1.37  2004/01/20 20:30:39  RysavyR
# TBolt00000000: New "RegressionNWay" and "QLResets" test capability both from a specific
# ".pl" and through XTC. Reviewed by Craig.
#
# Revision 1.36  2004/01/06 22:47:30  VossO
# Tbolt00000000 Edit the file
#
# Revision 1.35  2003/12/23 20:48:14  MenningC
# TBOLT00000000: Additions for the nway failover test. Reviewed by Olga
#
# Revision 1.34  2003/10/15 15:29:48  TeskeJ
# tbolt00009173 - raid-5 updates for release 3, mostly vdmax & crexpassocdel
# rev by Craig
#
# Revision 1.33  2003/09/29 20:42:13  ThiemanE
# Changed names to be compatible with linux
#
# Revision 1.32  2003/09/26 23:23:08  ThiemanE
# Changed name of some libraries that are lincluded to make the XTC linux compatible
#
# Revision 1.31  2003/09/26 23:22:39  ThiemanE
# Changed name of some libraries that are lincluded to make the XTC linux compatible
#
# Revision 1.30  2003/09/26 23:06:41  ThiemanE
# Updated include library names to make them Linux compatible
#
# Revision 1.29  2003/09/23 16:47:23  TeskeJ
# tbolt00009173 - Release 3 test code changes
# rev by Olga
#
# Revision 1.28  2003/09/09 19:32:58  GrigorenkoO
# Tbolt00000000 changed CrExpAssocDel script to handle empty hash being passed to it
#
# Revision 1.27  2003/09/05 18:51:33  GrigorenkoO
# Tbol00000000 Added reset all test / w code update case and reset all DSC test case
#
# Revision 1.26  2003/08/18 21:03:10  GrigorenkoO
# Tbolt moved function from Launcher to the lib rev Craig
#
# Revision 1.25  2003/08/18 18:14:05  GrigorenkoO
# Tbolt00000000 objects list to code update rev. Craig looked at it
#
# Revision 1.24  2003/07/25 18:39:35  MenningC
# tbolt00000000: support for the parity scan tests; reviewed by Eric
#
# Revision 1.23  2003/07/23 15:00:17  GrigorenkoO
# Tbolt00000000 Added new test cases
#
# Revision 1.22  2003/07/23 14:04:15  MenningC
# tbolt00000000: added support for an additional loop parameter, add initial parityscan support to failover; reviewed by Olga
#
# Revision 1.21  2003/07/17 19:51:53  MenningC
# Tbolt00000000: add support for optional failover parameters, reviewed by Olga
#
# Revision 1.20  2003/07/14 20:33:51  MenningC
# TBOLT00008741: added MP list to failover, added xtc loop count logging to failover. Reviewed by Chris
#
# Revision 1.19  2003/07/09 15:03:02  GrigorenkoO
# Tbolt00000000 Fixed FindFreeVB function
#
# Revision 1.18  2003/07/02 20:04:25  GrigorenkoO
# Tbolt00000000 Added scrub
#
# Revision 1.17  2003/05/29 12:55:19  WerningJ
# Rewrote all XTC data structures, added VLink support
# Reviewed by Craig M
#
# Revision 1.15  2003/03/27 17:36:35  WerningJ
# Removed calls XMC disconnect which are no longer required
# Reviewed by Olga
#
# Revision 1.14  2003/03/26 21:24:53  WerningJ
# Removed calls to unused modules
# Reviewed by Craig M
#
# Revision 1.13  2003/03/18 16:01:00  MenningC
# added BEStress.  reveiwed by JW
#
# Revision 1.12  2003/03/14 15:55:42  SchibillaM
# TBolt00000000: Check in a starting point for X1 packet testing using XTC.
# Reviewed by Craig.
#
# Revision 1.11  2003/03/05 20:15:04  WerningJ
# Use XIOTech::sanscript library
# Reviewed by Craig M
#
# Revision 1.10  2003/02/27 21:36:59  GrigorenkoO
# Tbolt0000000 Added XSSACrExpAssocDel function
#
#
##
#
