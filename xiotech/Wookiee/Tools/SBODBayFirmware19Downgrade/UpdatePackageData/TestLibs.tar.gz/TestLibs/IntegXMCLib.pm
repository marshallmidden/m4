#! /user/bin/perl -I ../lib  -w
# $Header$

##############################################################################
#  
#   CCBE Integration test library 
#
#   4/08/2002  XIOtech   Craig Menning
#
#   A set of library functions for integration testing. The first group
#   will be for basic configuration activity.
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::IntegXMCLib_Mod_1 - Perl commands, fuction and algorithms to manage and test XIOtech Storage Devices

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

This document describes basic usuage of the commands to manage and test a XIOtech Storage Device

=head1 DESCRIPTION

No user-servicable parts inside

=cut

############################################################################################
package TestLibs::IntegXMCLib;

use warnings;
#use FileHandle;
#use Text::Abbrev;
#use IO::Handle;
use strict;
#use POSIX; 

use Dumpvalue;
my $dumper = new Dumpvalue;
#$dumper->dumpValues(@pdiskinfolistarray);
my $dumper2 = new Dumpvalue;


#use lib '../../UMC/src/perl/scripting';

use lib "../CCBE";
use lib "../../CCBE";
use lib "../";

use XIOtech::sanscript (port => 10000);
use XIOtech::sanscriptET;
use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :XSSA);
use TestLibs::utility;

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 19301 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

#require      Exporter;
@ISA       = qw(Exporter);
@EXPORT    = qw(
                &AllVBList
                &AllVdList
                &AssociateVdisk

                &CheckInitProgress
                &CleanAll
                &CreateWorkport
                &CheckIfReady

                &DeleteSingleVD
                &DeleteVDAll
                &DeleteVBList
                &DeleteVDList
                &DeleteWPList
                &DisassocAll
                &DisassociateAllFromServer
                &DisassocOne
                &DisplayCNCInfo
                &DisplayPDisks
                &DisplayPdiskInfo
                &DisplayVdiskInfo
                &DumpXSSAError

                &FindWorkport
                &FindNewport
                &FindFreeWB

                &GetListOfAnyRaidType

                &LabelAllDrives
                &LabelList
                &LabelSingleDrive
                &LunsInUse
                
                &MakeSureCopyStarted

                &PdList
                &PdInfo
                &PdInfoList

                &WPList
                &SetWorkBlock
                &TargetLookup
                
                &UnUsedVd

                &VDCreate
                &VdInfoList
                &VdExpandSingle

                &WaitToRebuild
                &WaitCopyCompete

                &XSSA_DeviceList
                &XSSA_Reserve
                &XSSA_Unreserve
                &XSSAVersions

 
                );


    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 19301 $);
}
    our @EXPORT_OK;


##############################################################################
#
#          Name: LabelList
#
#        Inputs:  $IdList - pointer array of physical disk ids to be labeled
#                 $Label  - pointer array of labels 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:  Labels list of physical disks. If only one physical disk type 
#                 label  has been passed, then all physical disk on the list will 
#                 be labeled with the label passed into the function. 
#
##############################################################################
sub LabelList
{
    trace();
    my($IdList, $Label) = @_;
    my @Label = @$Label;
    
    if(scalar(@$Label) > 1)
    {
        for(my $i = 0; $i < min(scalar(@$IdList), scalar(@$Label)); $i++)
        {
            if(LabelSingleDrive($$Label[$i], $$IdList[$i]) == ERROR)
            {
                return ERROR;
            }
        }
    }
    
    if(scalar(@$Label) == 1)
    {
        for(my $i = 0; $i < scalar(@$IdList); $i++)
        {
            if(LabelSingleDrive($$Label[0], $$IdList[$i]) == ERROR)
            {
                return ERROR;
            }
        }
    }
    
    return GOOD;
}

=head2 LabelList

Labels list of physical disks. 
  
=over 4

=item Usage:

 my @PdId - array of physical disk ids to be labeled
 my @$Label - array of labels 
 
 my $rc = LabelList(\@PdId, \@Label); 
 
 if($rc)
 {
    print "Error:  Label physical disk has failed \n";
 }

 Notes:
 
 If only one physical disk type label  has been passed, then all physical 
disk on the list will be labeled with the label passed into the function. 

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name: LabelSingleDrive
#
#        Inputs: $PdID - physical disk id to be labeled
#                $Type - physical disk label type
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:  Labels sinle physical disk. 
#                 If only one physical disk type label  has been passed, 
#                 then all physical disk on the list will be labeled with 
#                 the label passed into the function. 
#
#
##############################################################################
sub LabelSingleDrive
{
    trace();
    my ($Type, $PdID) = @_;

    if(!(defined($PdID)))
    {
        logWarning("Drive PID not defined");
        return ERROR; 
    }
    
    if(!(defined($Type)))
    {
        logWarning("Drive Label Type not defined");
        return ERROR; 
    }       
    
# This is a Kludge because XSSA Scripting wants NOTSAFE but PDISK Info reports UNSAFE
#    my  $pdiskType;
#    $pdiskType = $Type;
#    if ($Type eq XSSAUNSAFETYPE)
#    {
#        $pdiskType = "NOTSAFE";
#    }
# End Kludge

    my $rc = pdiskLabel($PdID, $Type);

    delay(10);   # Need to wait if you want valid pdisk info to come back from the XSSA
        
    if(  $rc == XMCGOOD )
    {
        my %info = pdiskInfo($PdID);

        if(%info)
        {
            if(lc($Type) eq lc($info{PSTATE}))
            {
                logInfo("Mess:  PDID $PdID LABELED $info{PSTATE}");
                logInfo("Name $info{NAME} "); 
                return GOOD;                
            }
            else
            {
                logInfo("Warning: Device Label Mismatch ");
                logWarning(" > Attempted -> $Type Resulted -> $info{PSTATE} ");
                return ERROR;
            }
        }
        else
        {   
            logWarning(" PdiskInfo Failed ");
            DumpXSSAError();
            return ERROR;
        }   
    }
    else
    {
        DumpXSSAError();
        logWarning(" Did not Label PD ID:$PdID, as Type:$Type: ");
        return ERROR;
    }
}

=head2 LabelSingleDrive

Labels single physical disk. 
  
=over 4

=item Usage:

 my $PdId - physical disk id to be labeled
 my $Label - physical disk label type
 
 my $rc = LabelSingleDrive($Label, $PdId ); 
 
 if($rc)
 {
    print "Error:  Label physical disk has failed \n";
 }

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut


##############################################################################
#
#          Name: PdList
#
#        Inputs: pointer to PDiskID Array
#                type of PDisk to search for (data, hotspare, unsafe, etc)
#
#       Outputs: On success - updates array of physical disk Ids.
#                Returns GOOD on success, ERROR on failure.
#
#   Description: Retrieves Physical disk IDs.  
#
##############################################################################
sub PdList
{
    trace();
    
    my ($pdiskIDPtr, $Type) = @_;
    
    my @PDiskArray;
    my $Pointer = pdiskList();      # Get PDisk List from XSSA via sanscript

    if($Pointer)
    {
        if(!(scalar(@$Pointer)))
        {
            logInfo ("PDisklist command executed successfully but there are no Physical Disks");
            return GOOD;
        }
        
        if (uc $Type ne "ALL")
        {
            for(my $i = 0; $i < scalar(@$Pointer); $i++)
            {
                my %InfoHash = PdInfo($$Pointer[$i]); 
                if(%InfoHash)
                {
# debug             foreach my $name (sort keys %InfoHash)
#                   {
#                       print "$name -> $InfoHash{$name} $InfoHash{PSTATE} \n"; 
#                   }
                    if(lc($InfoHash{PSTATE}) eq lc($Type))
                    {
                        push (@PDiskArray, $$Pointer[$i]);
                    }
                }
            }
        }
        else
        {
            @PDiskArray = @$Pointer;    #- All Physical Disk IDS
        } 
    }
    else
    {
        DumpXSSAError();
        logWarning("ERROR: PDiskList command has failed");
        return ERROR;  
    }

    @$pdiskIDPtr = @PDiskArray;    #-Update Physical Disk IDS

    return GOOD;
}

=head2  PdList

Retrieves Physical disk IDs.
  
=over 4

=item Usage:
 
 my $returnValue = PdList(\@Array, "ALL"); 
 
 if($returnValue != GOOD)
 {
    print "Error: Error took place while Retrieving Physical disk ids \n";
 }
 else
 {
    print "Physical disk Ids @Array \n"; 
 }

 Notes:
 
 None

=item Returns:

 On success - Updates array of physical disk Ids, returns GOOD (0)
 On error - Returns ERROR (1)

=back

=cut
#############################################################################
#
#          Name: PdInfoList
#
#        Inputs: $PdInfoArrayRef - Pointer to PDiskInfo Array to Update, returns
#                                  a pointer to an array of hash pointers.
#                $PdIdRef - Pointer to PDisk List Array to use, if set to "ALL" will retrieve
#                           the PDisk List for all PDisks
#
#       Outputs: On success - Returns 0.
#                On error - Returns 1.
#
#  Globals Used: none
#
#   Description: Retrieves Physical disk information for a list of PDisks.
#
#
##############################################################################
sub PdInfoList
{
    my ($PdInfoArrayRef, $PdIdRef) = @_;
    
    my @ReturnArray;
    my $returnValue;

    # Get the list of all PDisks
    if (uc $PdIdRef eq "ALL")
    {
        my @pdiskArray;
        $PdIdRef = \@pdiskArray;

        $returnValue = PdList($PdIdRef, "ALL");
        if ($returnValue != GOOD) { return ERROR; }
    }

    for(my $i = 0; $i < scalar(@$PdIdRef); $i++)
    {
        my %InfoHash = PdInfo($$PdIdRef[$i]); 
        if(%InfoHash)
        {
            push(@ReturnArray, \%InfoHash);
        }
        else
        {
            logInfo("Unable to get Pd Id info $$PdIdRef[$i]");
            return ERROR;
        }
    }
    
    @$PdInfoArrayRef = @ReturnArray;

    return GOOD;
}


##############################################################################
#
#          Name: PdInfo
#
#        Inputs: $id - Physical Disk ID
#
#       Outputs: On success - Returns 0.
#                On error - Returns 1.
#
#  Globals Used: none
#
#   Description: Retrieves Physical disk information.
#
#
##############################################################################
sub PdInfo
{
    trace();
    my ($Id) = @_;
    my %Hash = pdiskInfo($Id);
    if(!(%Hash))
    {
        DumpXSSAError();
        logWarning("Error: pdiskInfo command for PD ID $Id Failed ");;
    }
    
    return %Hash;
}

=head2 PdInfo

Retrieves Physical disk information.
  
=over 4

=item Usage:
 
 my $Id - Physical Disk ID;
 my $rc = PdInfo($Id); 
 
 if($rc)
 {
    print "Error: Error took place while Retrieves Physical disk information \n";
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

#############################################################################
#
#          Name: GetListOfAnyRaidType
#
#        Inputs:  $foundRAIDsPtr - Pointer to found VDisks array to update
#                 $raidType - Virtual disk raid type to be retrieved   
#
#       Outputs:  On success - Updates a reference to an array of virtual disk Ids, Returns GOOD.
#                 On error - Returns ERROR.
#
#  Globals Used: none
#
#   Description: 
#               Retrieves List of Virtual disk ID of desired Raid Type.
#
##############################################################################

sub GetListOfAnyRaidType
{
    trace();
    my ($foundRAIDsPtr, $raidType ) = @_;

    my @VdInfo;
    my @ReturnVdId;
    my $returnValue;
    my @VdId;
    my @worksetArray;
    my @vblockArray;

    $returnValue = AllVdList(\@VdId, \@worksetArray, \@vblockArray);
    
    if( $returnValue == GOOD )
    { 
        for(my $i = 0; $i < scalar(@VdId); $i++)
        {
            # Setup the Logical Sets & Blocks we are forced to play with
            $returnValue = SetWorkBlock($worksetArray[$i], $vblockArray[$i]); 
            if ($returnValue != GOOD)
            {
                logWarning("Unable to set WorkSet to $worksetArray[$i] or VBlock to $vblockArray[$i]");
                return ERROR;
            }
            
            my %Info = vdiskInfo($VdId[$i]);
           
            if(%Info)
            {
                if(lc($Info{RAID_TYPE}) eq lc($raidType))
                {
                    push(@ReturnVdId, $Info{ID});                 
                }
            } 
            else
            {
                logWarning("Unable to Retrieve Virutal Disk ID $VdId[$i] Information");
                return ERROR;
            }   
        }
    }
    else
    {
        logWarning("Unable to Retrieve Virtual Disk Info List");
        return ERROR;
    }
    
    @$foundRAIDsPtr = @ReturnVdId;
            
    return GOOD;        
}



=head2 GetListOfAnyRaidType

Retrieves List of Virtual disk ID of desired Raid Type.
   
=over 4

=item Usage:

 The following constants can be used to select the RAID type
 
 RAID_NONE
 RAID_0 
 RAID_5 
 RAID_10

 my @ListOfVirtualDiskIds - Array of VDiskIDS to be updated    

 my $returnValue = GetListOfAnyRaidType( \@ListOfVirtualDiskIds, RAID_10); 
 
 if($returnValue == GOOD)
 {
    print "Virtual Disk Ids of desired Raid Type are @ListOfVirtualDiskIds \n"; 
 }

 Notes:
 
 None

=item Returns:

 On success - Updates a reference to an array of virtual disk Ids. Returns GOOD (0)
 On error - Returns ERROR (1).

=back

=cut

#############################################################################
#
#          Name: VdInfoList
#
#        Inputs: $VdInfoListPtr - pointer to VDisk array to update
#                $VdIdRef -  pointer to array of VDisk IDs to check  
#
#       Outputs:  On success - Returns a reference to an array of virtual disk Hashes.
#                 Returns GOOD.
#                 On error - Returns undef.
#
#  Globals Used: none
#
#   Description: 
#               Retrieves List of Virtual disk ID of desired Raid Type.
#
##############################################################################
sub VdInfoList
{
    trace();

    my ($VdInfoListPtr, $VdIdRef) = @_;
    
    my @allVdId;
    my @worksetArray;
    my @vblockArray;
    my @returnArray;
    my $returnValue;

    # Get the list of VDisks and associated baggage
    $returnValue = AllVdList(\@allVdId, \@worksetArray, \@vblockArray);

    if (uc $VdIdRef eq "ALL")
    {
        $VdIdRef = \@allVdId;
    }

    if($returnValue == GOOD)
    {
        for(my $i = 0; $i < scalar(@allVdId); $i++)
        {
            for(my $j = 0; $j < scalar(@$VdIdRef); $j++)
            {
                if ($allVdId[$i] == $$VdIdRef[$j])
                {
                    # Setup the Logical Sets & Blocks we are forced to play with
                    $returnValue = SetWorkBlock($worksetArray[$i], $vblockArray[$i]); 
                    if ($returnValue != GOOD) { return ERROR; }

                    my %Info = vdiskInfo($allVdId[$i]);
                    if(%Info)
                    {
                        push(@returnArray, \%Info);                 
                    } 
                    else
                    {
                        DumpXSSAError();
                        logInfo("Unable to Retrieve Virutal Disk ID $allVdId[$i] Information");
                        return ERROR;
                    }   
                }
            }
        }
    }
    else
    {
        return ERROR;
    } 
    
    @$VdInfoListPtr = @returnArray;

    return GOOD;
            
} 

##############################################################################
#
#          Name: VDCreate
#
#        Inputs: $Name       - Virtual disk name (string)  
#                $Capacity   - Virtual disk capacity (number) 
#                $RaidType   - Raid Type (0, 1, 10,5)
#
#
#       Outputs:  On success - Returns Hash containing virtual disk infomation.
#                 On error - Returns empty Hash.
#
#  Globals Used: none
#
#   Description: Create Virtual disks in MB rather then in GB, 
#                mostly used for test which do no requires Io 
#                executed to created virtual disks.
#
##############################################################################
sub VDCreate
{
    trace();
    my ($Name, $Capacity, $VDiskID, $RAID, $workSet, $vBlock, $DiskGroupID) = @_;
                
    my $returnValue;

    # Setup the Logical Sets & Blocks we are forced to play with
    $returnValue = SetWorkBlock($workSet, $vBlock, $DiskGroupID); 
    if ($returnValue != GOOD)
    {
        DumpXSSAError();
        logWarning("Unable to set WorkSet:$workSet, VBlock:$vBlock, or DiskGroup:$DiskGroupID");
        return ERROR;
    }
    
    # RaidType is now back in the create command, try to keep up
    $returnValue = vdiskCreate($VDiskID, $RAID, $Capacity);
    if( $returnValue == XMCGOOD )
    {
        logInfo("VD:$Name, ID:$VDiskID, Capacity:$Capacity MB - Was Created ");
    }
    else
    {
        DumpXSSAError();
        logWarning("VD:$Name, ID:$VDiskID, Capacity:$Capacity MB - Was NOT Created ");
        return ERROR;
    }
    
    # Wait before you try to name it or the ICON doesn't think the VDisk exists
    sleep(10);
    $returnValue = vdiskName($VDiskID, $Name);
    if( $returnValue != XMCGOOD )
    {
        DumpXSSAError();
        logWarning("Unable to Name VDisk ID:$VDiskID as $Name");
    }
    
    return GOOD;
}

=head2 VDCreate

Create Virtual disks in MB rather then in GB, 
mostly used for test which do no requires Io executed to created virtual disks.
  
=over 4

=item Usage:

 my $Name       - Virtual disk name (string)  
 my $Capacity   - Virtual disk capacity (number) 
 my $RaidType   - Raid Type (0, 1, 10,5)
 
 my %InfoHash = VDCreate($VDiskName, $Capacity, $VDiskID, $RaidType, $workSet, $vBlock, $DiskGroupID ); 
 
 if(%InfoHash)
 {
    foreach $name (sort keys %InfoHash)
    {
        print "$name -> $InfoHash{$name} \n";
    }
 }

 Notes:
 
 Create virtual disk for test purposes other then IO execution.
  
=item Returns:

 On success - Returns Hash containing virtual disk infomation.
 On error - Returns empty Hash.

=back

=cut


##############################################################################
#
#          Name: VdExpandSingle
#
#        Inputs: $ID         - Virtual disks ID
#                $Capacity   - Virtual disk Capacity in MB
#
#       Outputs:  On success - Returns 0.
#                 On error - Returns 1.
#
#
#  Globals Used: none
#
#   Description: Expands single virtual disk.
#
#
##############################################################################
sub VdExpandSingle
{
    trace();
    my ($ID, $Capacity) = @_;

    if((vdiskExpand($ID, $Capacity)) != XMCGOOD)
    {
        logInfo("ERROR: VD ID $ID was NOT Expanded by  $Capacity MB ");
        return ERROR;
    }

    logInfo("VD ID $ID was Expanded by  $Capacity MB "); 
    return GOOD;

}

=head2 VdExpandSingle

Expands single virtual disk.
  
=over 4

=item Usage:

 my $ID         - Virtual disks ID
 my $Capacity   - Virtual disk Capacity in MB
 
 my $rc = VdExpandSingle($ID, $Capacity); 
 
 if($rc)
 {
    print "Error: Failed to Expand virtual disk \n";
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name:  AllVBList
#
#        Inputs: $vblockArrayPtr - pointer to array of VBlocks to update
#                $worksetArrayPtr - pointer to array of corresponding worksets to update
#
#       Outputs:  On success - Updates Array refernece containing virtual block Ids and an array
#                              reference with corresponding Worksets, Returns GOOD .
#                 On error - Returns ERROR
#
#  Globals Used: none
#
#   Description: Retrieves list of virtual block ids present on the Bigfoot
#
#
##############################################################################
sub AllVBList
{
    trace();
    my ($vblockArrayPtr, $worksetArrayPtr) = @_;
    my %vdiskInfo;
    my $List;
    my $i;
    my $vbCount;
    my $returnValue;
    my $vblockList;

    # Empty the arrays
    undef @$worksetArrayPtr;
    undef @$vblockArrayPtr;

    logInfo("Pulling the VBlock List out of the XSSA, get yourself a cool drink - this may take awhile");
    for($i = 0; $i < WORKSETCOUNT; $i++)
    {
        # Must set the artificial workset to use    
        $vblockList = workset($i);
        if (!defined($vblockList)) 
        {
            DumpXSSAError();
            logWarning("Unable to Set Workset to $i");
            return ERROR;        
        }
        else
        {
            # Build the complete array
            push @$vblockArrayPtr, @$vblockList;
            for($vbCount = 0; $vbCount < @$vblockList; $vbCount++)
            {            
                # Need to remember the workset for each vblock found, bummer
                push @$worksetArrayPtr, $i;
            }
        }
    }    

    if(!@$vblockArrayPtr)
    {
        logWarning("There are No VBlocks on the Bigfoot");
    }

    return GOOD;
}

=head2 AllVBList

Retrieves list of virtual block ids present on the Bigfoot.
Along with the corresponding Workset and Vblock.

=over 4

=item Usage:

 my $rc = AllVdList(\@vdiskArray, \@worksetArray, \@vblockArray);;

 if ($rc == GOOD)
 {
     print("List of virtual disk IDs @vdiskArray \n");
 }
 else
 {
    print ("Error: Command has faild\n");
 }

=item Returns:

 On success - GOOD (0).
 On error - ERROR (1).

=back

=cut

##############################################################################
#
#          Name:  AllVdList
#
#        Inputs: $vdiskArrayPtr - pointer to array of VDisks to update (can be empty)
#                $vblockArrayPtr - pointer to array of corresponding  VBlocks to update (can be empty)
#                $worksetArrayPtr - pointer to array of corresponding worksets to update (can be empty)
#
#       Outputs:  On success - Updates Array refernece containing virtual disk Ids and an array
#                              reference with corresponding Worksets, VBlocks.
#                 On error - Returns ERROR
#
#  Globals Used: none
#
#   Description: Retrieves list of virtual disks ids present on the Bigfoot
#
#
##############################################################################
sub AllVdList
{
    trace();
    my ($vdiskArrayPtr, $worksetArrayPtr, $vblockArrayPtr) = @_;
    my %vdiskInfo;
    my $List;
    my $i;
    my $vdCount;
    my $returnValue;
    my $vblockList;

    logInfo("Pulling the VDisk List out of the XSSA, grab a snickers - this may take awhile");
    for($i = 0; $i < WORKSETCOUNT; $i++)
    {
        # Must set the artificial workset to use    
        $vblockList = workset($i);
        if (!defined($vblockList)) 
        {
            DumpXSSAError();
            logWarning("Unable to Set Workset to $i");
            return ERROR;        
        }
        else
        {
            foreach my $vblock (@$vblockList)
            {
                # Must set the artificial vblock to use    
                $returnValue = vblockSet($vblock);
                if (!defined($returnValue)) 
                {
                    DumpXSSAError();
                    logWarning("Unable to Set VBlock to $vblock");
                    return ERROR;        
                }

                $List = vdiskList();
                if ($List)
                {
                    # Build the complete array like we used to get from the XSSA
                    push @$vdiskArrayPtr, @$List;
                    for($vdCount = 0; $vdCount < @$List; $vdCount++)
                    {            
                        # Need to remember the workset & vblock for each VDisk found, bummer
                        push @$worksetArrayPtr, $i;
                        push @$vblockArrayPtr, $vblock;
                    }
                }
            }
            
        }
    }    

    if(!@$vdiskArrayPtr)
    {
        logWarning("There are No VDisks on the Bigfoot");
    }

    return GOOD;
}

=head2 AllVdList

Retrieves list of virtual disks ids present on the Bigfoot.
Along with the corresponding Workset and Vblock.

=over 4

=item Usage:

 my $rc = AllVdList(\@vdiskArray, \@worksetArray, \@vblockArray);;

 if ($rc == GOOD)
 {
     print("List of virtual disk IDs @vdiskArray \n");
 }
 else
 {
    print ("Error: Command has faild\n");
 }

=item Returns:

 On success - GOOD (0).
 On error - ERROR (1).

=back

=cut

##############################################################################
#
#          Name: XSSAVersions 
#
#        Inputs: none
#
#       Outputs: 
#               On success - Returns ponter to XSSA versions hash.
#               On error - Returns Value less then 0 (-999).
#
#  Globals Used: none
#
#   Description: This command retrieves XSSA server firmware versions.   
#
#
##############################################################################

sub XSSAVersions
{
    my ($version, $connection, $xwsObj, $dsc) = @_;
    
    # use the XWS method to retrieve values
    if (defined($connection) && $connection eq lc("xws"))
    {
        logInfo("DSC: ".$dsc);
        logInfo("xwsObj: $xwsObj");
        
        # put the info into the version hash as a formatted string for each controller
        # this is due to how the scriptAgent version is used in XSSARobustness.pm
        $version->{"$dsc:"} = $xwsObj->getVersionInformation($dsc);
        return GOOD;
    }
    else
    {
        %$version = XIOtechVersion(); 
        if (%$version)
        {
            return GOOD;
        }
        else
        {
            logInfo("Error retrieving XSSA versions ");
            DumpXSSAError();
            return ERROR;
        }
    }
}

=head2 XSSAVersions

This command retrieves XMC server firmware versions.
  
=over 4

=item Usage:

 my $versionPtr = XSSAVersions(); 
 
 if($versionPtr == INVALID)
 {
    print "Error: Failed to retrieves XMC firmware versions \n";
 }
 else
 {
        print("    XSSA Verision: $version{'XSSA'}\n");
        print("Firmware Verision: $version{'SYSTEM_RELEASE'}\n");
 }

 Notes:
 
 None

=item Returns:

 On success - Returns pointer to XSSA versions hash.
 On error - Returns INVALID (-999).

=back

=cut



##############################################################################
#
#          Name: DeleteAllVdisks
#
#        Inputs: none
#
#       Outputs: On success - Returns 0.
#                On error - Returns 1.#  Globals Used: none
#
#   Description: Deletes all virtual disk present on the Bigfoot.
#
#
##############################################################################
sub DeleteVDAll
{
    trace();
    my @vdiskArray;
    my @worksetArray;
    my @vblockArray;
    my $returnValue;
    
    $returnValue = AllVdList(\@vdiskArray, \@worksetArray, \@vblockArray);
    if($returnValue == GOOD)
    {
        for(my $i = 0; $i < scalar(@vdiskArray); $i++)
        {
            if(DeleteSingleVD($vdiskArray[$i], $worksetArray[$i], $vblockArray[$i]) != GOOD)
            {
                return ERROR;
            }
        }
    }
    else
    {
        return ERROR;
    }

    return GOOD;
}

=head2 DeleteVDAll
          
Deletes all virtual disk present on the Bigfoot.
     
=over 4

=item Usage:

 my $rc =  DeleteVDAll();

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut
 

##############################################################################
#
#          Name: DeleteVBList
#
#        Inputs: $VBListPtr - pointer to an array of workport ids to be delete
#                             if this parm = "ALL" then all workports will be deleted  
#                $worksetArrayPtr - pointer to an array of corresponding worksets
#
#       Outputs:  On success - Returns 0.
#                 On error - Returns 1.
#
#  Globals Used: none
#
#   Description: Deletes a list of virtual block ids passed into the function.
#
##############################################################################
sub DeleteVBList
{
    trace();
    my ($VBListPtr, $worksetArrayPtr) = @_;

    my $returnValue;

    if(uc $VBListPtr eq "ALL")
    {   
        my @VBList; 
        my @worksetArray;
         
        # If All is passed in, Grab the Lists
        $VBListPtr = \@VBList;
        $worksetArrayPtr = \@worksetArray;

        $returnValue = AllVBList($VBListPtr, $worksetArrayPtr);
        if ($returnValue != GOOD) { return ERROR; }
    }

    if($VBListPtr && $worksetArrayPtr)
    {
        for(my $i = 0; $i < scalar(@$VBListPtr); $i++)
        {
            SetWorkBlock($$worksetArrayPtr[$i]);

            logInfo("Removing VBlock:$$VBListPtr[$i]");
            $returnValue = vblockRemove($$VBListPtr[$i]);
            if ($returnValue != XMCGOOD)
            {
                DumpXSSAError();
                logWarning("Unable to delete VBlock:$$VBListPtr[$i]");
                return ERROR;
            }
        }
    }
    else
    {
        logWarning("Error: bad array reference has been passed into the function DeleteVBList");
        return ERROR;
    }
    return GOOD;
}

=head2 DeleteVBList
          
Deletes a list of VBlock ids passed into the function.  If "ALL" is passed
in for the list, all discovered VBlocks will be deleted.
     
=over 4

=item Usage:

 # delete an array of VBlock ids
 my $rc =  DeleteVBList(\@vbArray, \@worksetArray);

 # delete All Workport ids
 my $rc =  DeleteVBList("ALL");


=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name: DeleteWPList
#
#        Inputs: $WPListPtr - pointer to an array of workport ids to be delete
#                             if this parm = "ALL" then all workports will be deleted  
#                $worksetArrayPtr - pointer to an array of corresponding worksets
#
#       Outputs:  On success - Returns 0.
#                 On error - Returns 1.
#
#  Globals Used: none
#
#   Description: Deletes a list of virtual disk ids passed into the function.
#
##############################################################################
sub DeleteWPList
{
    trace();
    my ($WPListPtr, $worksetArrayPtr) = @_;

    my $returnValue;

    if(uc $WPListPtr eq "ALL")
    {   
        my @ServerArray; 
        my @worksetArray;
         
        # If All is passed in, Grab the Lists
        $WPListPtr = \@ServerArray;
        $worksetArrayPtr = \@worksetArray;

        $returnValue = WPList($WPListPtr, $worksetArrayPtr);
        if ($returnValue != GOOD) { return ERROR; }
    }

    if($WPListPtr && $worksetArrayPtr)
    {
        for(my $i = 0; $i < scalar(@$WPListPtr); $i++)
        {
            SetWorkBlock($$worksetArrayPtr[$i]);

            $returnValue = workportDelete($$WPListPtr[$i]);
            if ($returnValue != XMCGOOD)
            {
                DumpXSSAError();
                logWarning("Unable to delete Workport:$$WPListPtr[$i]");
                return ERROR;
            }
        }
    }
    else
    {
        logWarning("Error: bad array reference has been passed into the function DeleteWPList");
        return ERROR;
    }
    return GOOD;
}

=head2 DeleteWPList
          
Deletes a list of Workport ids passed into the function.  If "ALL" is passed
in for the list, all discovered Workports will be deleted.
     
=over 4

=item Usage:

 # delete an array of workport ids
 my $rc =  DeleteVDList(\@wpArray, \@worksetArray);

 # delete All workport ids
 my $rc =  DeleteVDList("ALL");


=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name: DeleteVDList
#
#        Inputs: $VDListPtr - pointer to an array of VDisk ids to be delete
#                $worksetArrayPtr - pointer to an array of corresponding worksets
#                $vblockArrayPtr - pointer to an array of corresponding vblocks
#
#       Outputs:  On success - Returns 0.
#                 On error - Returns 1.
#
#  Globals Used: none
#
#   Description: Deletes a list of virtual disk ids passed into the function.
#
##############################################################################
sub DeleteVDList
{
    trace();
    my ($VdListPtr, $worksetArrayPtr, $vblockArrayPtr) = @_;

    if($VdListPtr && $worksetArrayPtr && $vblockArrayPtr)
    {
        for(my $i = 0; $i < scalar(@$VdListPtr); $i++)
        {
            if(DeleteSingleVD($$VdListPtr[$i], $$worksetArrayPtr[$i], $$vblockArrayPtr[$i]) != GOOD)
            {
                return ERROR;
            }
        }
        return GOOD;
    }
    else
    {
        logWarning("Error: bad array reference has been passed into the fuction");
        return ERROR;
    }
}

=head2 DeleteVDList
          
Deletes all list of virtual disk ids passed into the function.
     
=over 4

=item Usage:

 my @VdIdList = (1,2,3,4,5...);     - build an array of virtual disk ids to delete
 my $PointerVdIdList = \@VdIdList;  - create pointer to the array 

 my $rc =  DeleteVDList($PointerVdIdList);

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name: DeleteSingleVD
#
#        Inputs: $vdiskBlockID - ID of the VDisk within a block to be deleted
#                $workset
#                $vblock
#
#       Outputs: On success - Returns 0.
#                On error - Returns 1.
#
#  Globals Used: none
#
#   Description: Deletes the virtual disk.
#               Note: there is no delay after the delete!!!
#
#
##############################################################################
sub DeleteSingleVD
{
    trace();
    my ($vdiskBlockID, $workset, $vblock) = @_;

    #
    # Setup the Logical Sets & Blocks we are forced to play with
    #
    SetWorkBlock($workset, $vblock);

    #
    # Delete the VDisk
    #
    if(XMCGOOD == vdiskDelete($vdiskBlockID))
    {
        logInfo("VDisk $vblock/$vdiskBlockID was deleted");
        return GOOD;
    }
    else
    {
        DumpXSSAError();
        logWarning("==> VDisk $vblock/$vdiskBlockID was NOT deleted");
        return ERROR;
    }
}

=head2 DeleteSingleVD
          
Deletes the virtual disk.
     
=over 4

=item Usage:

 my $VdId - Virtual Disk ID to be deleted.

 my $rc =  DeleteSingleVD($VdId, $workset, $vblock);

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut
 
##############################################################################
#
#          Name: AssociateVdisk
#
#        Inputs: WorkPort, Logical Unit Number, Virtual Disk ID
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Associates the specified vdisk to the specified server and 
#                lun.  Must call SetWorkBlock before calling this function to
#                get the logical mapping crap set first  
#
#
##############################################################################
sub AssociateVdisk
{
    trace();
    my ($workPort, $lun, $vDisk) = @_;  

    if (vdiskMask($workPort, $lun, $vDisk) == XMCGOOD)
    {
        logInfo("VD ID $vDisk is mapped using LUN $lun to Workport $workPort");
    }
    else
    {
        logInfo("Failed: Failed Associate VD ID $vDisk, via LUN $lun, via Server Workport $workPort ");
        DumpXSSAError();
        return ERROR;
    }

    return GOOD;
}


=head2 AssociateVdisk
          
Associates the Virtual Disk to the server.

=over 4

=item Usage:

 $rc = AssociateVdisk(Server ID, Logical Unit Number, Virtual Disk ID);

 if ($rc == 0)
 {
     print("Virtual disks hash been associated successfully \n");
 }
 else
 {
    print ("Error: Virtual disk association has failed \n");
 }

=item Returns:

 On success - Funciton return equals to 0.
 On error - function return equals to 1.

=back

=cut

##############################################################################
#
#          Name: DisassociateAllFromServer 
#
#        Inputs: $SID - Server / Workport ID
#                $workset - corresponding workset
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: disassociates all the vdisk from the specified server.
#
#
##############################################################################
sub DisassociateAllFromServer
{
    trace();
    my ($SID, $workset) = @_;

    my $VdiskID;
    my $VBlock;
    my $return; 

    # Setup the Logical Sets & Blocks we are forced to play with
    $return = workset($workset); 
    if (!$return)
    {
        DumpXSSAError();
        logWarning("Unable to set WorkSet to $workset");
        return ERROR;
    }
    logInfo("Workset is now $workset");

    my %Hash = LunsInUse($SID);

    if(defined $SID)
    {
        if($Hash{ERROR_CHECK} == GOOD)
        {
            my @VDID = keys(%Hash);
            for(my $t = 0; $t < scalar(@VDID); $t++)
            {
                if("$VDID[$t]" ne "ERROR_CHECK")
                {
                    # Play nice
                    # Get the VDisk ID within a VBlock, i.e. (VDiskID modulus VDiskCount)
                    $VdiskID = $VDID[$t] % XSSAVDISKCOUNT;
                    $VBlock = int($VDID[$t] / XSSAVDISKCOUNT);
#print "\nVDiskID:$VDID[$t] ===>>> VDisk Modulus VBlockCount:$VdiskID ===>>> VBlock:$VBlock\n";
                    SetWorkBlock($workset, $VBlock);
    
                    if(DisassocOne($SID, $VdiskID) != GOOD)
                    {
                        return ERROR;
                    }
                }  
            }
        }
        else
        {
            logWarning("Could not get Hash from LUNS in use");     
            return ERROR;
        }
    }
    else
    {
        logInfo("User Error: No Server ID Has Been Passed to the Function ");
        return ERROR;
    } 

    return GOOD;
}

=head2 DisassociateAllFromServer

Disassociate all virtual disks from the servers
   
=over 4

=item Usage:

 my $SID;    Server id;

 my $rc =  DisassociateAllFromServer($SID);

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name: LunsInUse
#
#        Inputs: $SID- Target ID
#
#       Outputs: 
#                 On success - Returns hash contaning information, 
#                 where keys Virtual disk ids and values lun
#                 On error - Returns empty hash.
#
#  Globals Used: none
#
#   Description: Builds hash of virtual disks associated to the workport. 
#
##############################################################################
sub LunsInUse
{
    trace();
    my ($SID) = @_;

    my %ReturnHash;

    if(defined ($SID))
    {
        my %Hash = workportInfo($SID);
        if(%Hash)
        {
            my $List = _listToHash($Hash{ASSOCIATIONS});
            my @Associations = @$List;
            if(scalar(@Associations))
            {
                $ReturnHash{ERROR_CHECK} = GOOD; 
                for(my $i = 0; $i < scalar(@Associations); $i++)
                {
                    $ReturnHash{${$Associations[$i]}{VDISK_ID}} = ${$Associations[$i]}{LUN}; 
                }
            }
            else
            {
                $ReturnHash{ERROR_CHECK} = GOOD;    
            }
        }
        else
        {
            logInfo("Failed to get server $SID info hash");
            $ReturnHash{ERROR_CHECK} = ERROR;
        }
    }
    else
    {
        logInfo ("User Error No Server ID has Been Passed into the Function ");
    }
  
    return %ReturnHash;
}

=head2 LunsInUse

Builds hash of virtual disks associated to the target.
  
=over 4

=item Usage:

 my $SID - Workport ID
 
 my %Hash = LunsInUse($SID); 
 
 if($Hash{ERROR_CHECK} = GOOD;)
 {
    foreach my $name (sort keys %Hash)
    {
        print "Vd Id -> $name, Lun -> $Hash{$name} \n";
    }
 }

 Notes:
 
 None

=item Returns:

 On success - Returns hash contaning information, where keys Virtual disk ids and values lun
 On error - Returns $Hash{ERROR_CHECK} = ERROR.

=back

=cut


##############################################################################
#
#          Name: CreateWorkport
#
#        Inputs: $nid - Newport ID to use to create a workport
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Creates a Workport from the newport ID
#
##############################################################################
sub CreateWorkport
{
    trace();
    my ($nId, $vPort) = @_;

    my $mes = "Creating Workport ID ... ";
    if(workportCreate($nId, $vPort) == XMCERROR)
    {
        DumpXSSAError();
        if(defined($vPort))
        {
            logWarning($mes." ". $nId." via vPort ".$vPort." Failed ");
        }
        else
        {
            logWarning($mes." ". $nId." Failed ");  
        }
        return ERROR;
    }
    else
    {
        if(defined($vPort))
        {
            logInfo($mes." ". $nId."via vPort ".$vPort." Done");
        }
        else
        {
            logInfo($mes." ". $nId." Done");    
        }
    }
    return GOOD;
}

=head2 CreateWorkport

Changers state of the server from Unmanaged to Managed
  
=over 4

=item Usage:
 
 my $SID - Server ID;
 my $rc = CreateWorkport($SID); 
 
 if($rc)
 {
    print "Error: Error took place while managing the servers \n";
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name: NameWorkport
#
#        Inputs: $nid - Newport ID to use to create a workport
#                $name - Workport name
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Creates a Workport from the newport ID
#
##############################################################################
sub NameWorkport
{
    trace();
    my ($nid, $name) = @_;

    my $mes = "Naming Workport ID ... ";
    if(workportName($nid, $name) == XMCERROR)
    {
        DumpXSSAError();
        logWarning($mes." ". $nid." Failed ");
        return ERROR;
    }
    else
    {
        logInfo($mes." ". $nid." Done");
    }
    return GOOD;
}


=head2 NameWorkport

Changes name of the server to the input string
  
=over 4

=item Usage:
 
 my $nid = Newport ID;
 my $name = 8 char string;
 my $rc = NameWorkport($nid, $name); 
 
 if($rc)
 {
    print "Error: Error took place while naming the server \n";
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut



##############################################################################
#
#          Name: WPList
#
#        Inputs: $serverArrayPtr - pointer to server array to update (can be empty)
#                $serverWorksetPtr - pointer to workset array to update (can be empty)
#
#       Outputs: 
#               On success - Returns array of server Ids.
#               On error - Returns first element in the array if less then 0 (-999).
#
#  Globals Used: none
#
#   Description: Retrieves Server Id list.
#
#
##############################################################################
sub WPList
{
    trace();

    my ($serverArrayPtr, $serverWorksetPtr) = @_;

    my $returnValue;
    my $List;
    my $i;
    my $j;
    
    logInfo("Pulling the Server List out of the XSSA, find a good book - this may take awhile");
    for($i = 0; $i < WORKSETCOUNT; $i++)
    {
        # Must set the artificial workset to use    
        $returnValue = workset($i);
        if (!defined($returnValue)) 
        {
            DumpXSSAError();
            logWarning("Unable to Set Workset to $i");
            return  ERROR;
        }

        $List = workportList();

        if (defined($List))
        {
            # Build the complete array like we used to get from the XSSA
            push @$serverArrayPtr, @$List;
            for($j = 0; $j < @$List; $j++)
            {
                # Need to save the workset corresponding to the workport, bummer
                push @$serverWorksetPtr, $i;
            }
        }
        else
        {
            logInfo("There are No Servers Attached to the Bigfoot on Workset $i ");
        }
    }    

    if(!@$serverArrayPtr)
    {
        logInfo("There are No Servers Attached to the Bigfoot");
    }

    return  GOOD;
}

=head2 WPList

Retrieves Server Id list
  
=over 4

=item Usage:
  
 my $ServerType - "a" = all, "m" = managed, "u" = unmanaged, "h" = hidden

 my $PointerToServerIdList = WPList(); 
 
 my @ServerIdList = @$PointerToServerIdList;
 
 if($ServerIdList >= 0)
 {
    print "Error: Error took place while Retrieves Server id list \n";
 }
 else
 {
    print "Server Id list @ServerIdList\n"; 
 }

 Notes:
 
 None

=item Returns:

 On success - Returns array of server Ids.
 On error - Returns first element in the array is less then 0 (-999).

=back

=cut


##############################################################################
#
#          Name: UnUsedVd
#
#        Inputs: Pointer to array of unmasked VDisks
#                Pointer to array of corresponding worksets
#                Pointer to array of corresponding vblocks
#
#       Outputs: Updated array of unmasked VDisks
#                Updated array of corresponding worksets
#                Updated array of corresponding vblocks
#                Returns GOOD on success, ERROR on failure
#
#   Description: Checks workport status to see if any vdisks are associated 
#                returns array of unmasked VDisk, along with 
#                workset and vblock arrays associated with VDisks.   
#
#
##############################################################################
sub UnUsedVd
{
    trace();
    my ( $UnusedVdiskArrayPtr, $worksetArrayPtr, $vblockArrayPtr ) = @_;

    my %LunId;
    my @UnUsedId;
    my @UnUsedWS;
    my @UnUsedVB;
    my @vdiskArray;
    my @worksetVdiskArray;
    my @vblockArray;
    my @serverArray;
    my @worksetServerArray;
    my @AllAssociatedVDid;
    my $returnValue;

    $returnValue = AllVdList(\@vdiskArray, \@worksetVdiskArray, \@vblockArray);
    if ($returnValue != GOOD) { return ERROR; }

    $returnValue = WPList(\@serverArray, \@worksetServerArray);
    if ($returnValue != GOOD) { return ERROR; }
    
    logInfo("Please wait: Getting list of Vdisk Id's in use");
    for(my $i = 0; $i < scalar(@serverArray); $i++)
    {
        %LunId = LunsInUse($serverArray[$i]);
        if($LunId{ERROR_CHECK} == GOOD)
        {
            my @ForServerIDVds = keys(%LunId);
            for(my $t = 0; $t < scalar(@ForServerIDVds); $t++)
            {                
                if("$ForServerIDVds[$t]" ne "ERROR_CHECK")
                {
                    push(@AllAssociatedVDid, $ForServerIDVds[$t]);
                } 
            } 
        }
        else
        {
            return ERROR;            
        }
    }

    my $match;
    
    if(scalar(@AllAssociatedVDid))
    {
        logInfo("Please wait: Getting list of Vdisk Id's that are not in use");
        for(my $num = 0; $num < scalar(@vdiskArray); $num++)
        {
            $match = 0;
            
            for(my $count = 0; $count < scalar(@AllAssociatedVDid); $count++)
            {
                if( $vdiskArray[$num] == $AllAssociatedVDid[$count])
                {
                    $match = 1;
                }    
            }
            
            if($match == 0)
            {
                push (@UnUsedId, $vdiskArray[$num]);    
                push (@UnUsedWS, $worksetVdiskArray[$num]);    
                push (@UnUsedVB, $vblockArray[$num]);    
            }
        }
    }
    else
    {
        @UnUsedId = @vdiskArray; #- No vd's associated to servers    
        @UnUsedWS = @worksetVdiskArray;   
        @UnUsedVB = @vblockArray;   
    }

    # Update the pointers for the calling routine
    @$UnusedVdiskArrayPtr = @UnUsedId;
    @$worksetArrayPtr = @UnUsedWS;
    @$vblockArrayPtr = @UnUsedVB;

    return GOOD;   

}

##############################################################################
#
#          Name: CleanAll
#
#        Inputs: @option - 3 Disassociate All Virtual Disks 
#                        - 2 Deletes All Virtual Disks
#                        - 0 or no option is passed Disassociates ALL Virtual Disks
#                            Deletes All Virtual Disks, Labels all physical disks 
#                            as Unlabeled
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Discomfitures Bigfoot: Disassociate all virtual disks, deletes 
#                all virtual disks, un-manages all servers, labels all physical 
#                disks as unlabeled       
#
# The following constants are in Constants.pm for use here:
#
#    UNMASKVDISKS   
#    DELETEVDISKS   
#    DELETEWORKPORTS
#    DELETEVBLOCKS  
#    UNLABELPDISKS  
#    CLEANALL       
#
##############################################################################
sub CleanAll
{
    trace();
    my( @option ) = @_;
    
    my @PdId;
    my $returnValue;

    # If no option was passed in, clean all
    if (!@option) {$option[0] = CLEANALL;}

    for(my $t = 0; $t < scalar(@option); $t++)
    {
        if( $option[$t] == UNMASKVDISKS || $option[$t] == CLEANALL)
        {
            # Disassociate / Unmask all vdisks
            if(DisassocAll() != GOOD)
            {
                return ERROR;    
            }  
        }
    
        if( $option[$t] == DELETEVDISKS || $option[$t] == CLEANALL)
        {
            # Delete all vdisks, may need to wait a little for config changes to complete
            sleep (10);
            if( DeleteVDAll() != GOOD)
            {
                return ERROR;
            }    
        }

        if( $option[$t] == DELETEWORKPORTS || $option[$t] == CLEANALL)
        {
            # Delete all workports
            if( DeleteWPList("ALL") != GOOD)
            {
                return ERROR;
            }
        }

        if( $option[$t] == DELETEVBLOCKS || $option[$t] == CLEANALL)
        {
            
            # Delete all vblocks, may need to wait a little for config changes to complete
            sleep (10);
            if( DeleteVBList("ALL") != GOOD)
            {
                return ERROR;
            }
        }

        if( $option[$t] == UNLABELPDISKS || $option[$t] == CLEANALL)
        {    
            # Get PDisk List
            $returnValue = PdList(\@PdId, "ALL");
            if($returnValue != GOOD) {return ERROR;}

            # Need to leave a single drive labeled for CNC config info
            pop @PdId;

            # Set label type to unlabeled
            my @PdLabel =  ( XSSAUNLABLEDTYPE );

            # Relabel all drives
            if(LabelList(\@PdId, \@PdLabel) != GOOD)
            {
                return ERROR;
            }
        }
    }

    return GOOD;      
}

=head2 CleanAll
          
Un-configures Controller.
     
=over 4

=item Usage:

 The following constants are exported in Constants.pm for use here:

    UNMASKVDISKS     - Disassociate All Virtual Disks 
    DELETEVDISKS     - Deletes All Virtual Disks
    DELETEWORKPORTS  - Deletes All Workports
    DELETEVBLOCKS    - Deletes All VBlocks
    UNLABELPDISKS    - Unlabels all physical disks 
    CLEANALL         - All of the above

 my @Action - List of Action Options; 

 @Action = (UNMASKVDISKS, DELETEVDISKS, DELETEWORKPORTS);
 my $rc = CleanAll(@Action);

 The following two function calls are equivalent:

 my $rc = CleanAll();

 @Action = (CLEANALL);
 my $rc = CleanAll(@Action);

 Notes:
 
 If no option is passed, defaults to option CLEANALL.

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut


##############################################################################
#
#          Name: DisassocOne
#
#        Inputs: SID - ServerID
#                VdId - Virtual Disk ID
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Disassociates One Virtual disk from the Server      
#
#
##############################################################################

sub DisassocOne
{
    trace();
    my ($sid, $VdId) = @_;

    my $i;
    
    my $msg = "Disassociating Vdisk $VdId from SID $sid . . . ";
    
    if(vdiskUnmask($sid, $VdId) == XMCGOOD)
    {
        logInfo($msg."done.");
        return GOOD;
    }
    else
    {
        DumpXSSAError();
        logWarning($msg."FAILED.");
        return ERROR;
    } 
}

=head2 DisassocOne

Disassociate the virtual disk from the server
   
=over 4

=item Usage:

 my $SID;    - Server id;
 my $VdId;   - Virtual Disk ID;

 my $rc =  DisassociateAllFromServer($SID, $VdId);

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut


##############################################################################
#
#          Name: _listToHash
#
#        Inputs: controller, SID, LUN
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Attempt to undo any existing configuration and restore
#                the controllers to a specific starting point. Ie., 
#                do wipe_clean even though we can't. Second controller
#                is optional    
#
#
##############################################################################
sub _listToHash
{
    my ($list) = @_;
    my @array = ();

    $list =~ /\[(.+)\]/;
    # remove the braces
    $list = $1;

    # Find the stuff within braces
    if( $list )
    {
        while ($list =~ /{([^{}]*)}/)
        {
            my @info = split(/, /, $1);
            my %hash;

            for (my $i = 0; $i < scalar(@info); $i++)
            {
                $info[$i] =~ /(.+):(.+)/;
                $hash{$1} = $2;
            }
            push(@array, \%hash);
            $list =~ s/{([^{}]*)}//;
        }
    }
    return (\@array);
}


##############################################################################
#
#          Name: DisassocAll
#
#        Inputs: none
#
#       Outputs: On success - Returns 0.
#                On error - Returns 1.
#
#  Globals Used: none
#
#   Description: Disassociates all associated virtual disks from all 
#                of the servers. Result of this function execution is no virtual 
#                disks are associated to any of the servers.    
#
#
##############################################################################
sub DisassocAll
{
    trace();

    my @serverArray;
    my @worksetArray;
    my $VdiskID;
    my $VBlock;

    my $returnValue = WPList(\@serverArray, \@worksetArray);
    
    if($returnValue == GOOD)
    {
        for(my $i = 0; $i < scalar(@serverArray); $i++)
        {
            # Unmask all VDisks on this workport
            $returnValue = DisassociateAllFromServer($serverArray[$i], $worksetArray[$i]);
            if($returnValue != GOOD) {return ERROR;}
        }
        logInfo("All existing virtual disks have been disassociated  ");     
    }
    else
    {
        logWarning("Failed to get Server List Workport list");
    }
    
    return GOOD; 
}  

=head2 DisassocAll

Disassociates all associated virtual disks from all of the servers. 
Result of this function execution is no virtual disks are associated to any of the servers
     
=over 4

=item Usage:

 my $rc =  DisassocAll();

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name: DisplayCNCInfo
#
#        Inputs: none
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Displays virtual controller group information.   
#
#
##############################################################################
sub DisplayCNCInfo
{
    trace();

    my %vcginfo;

    ########### vcginfo ################

    # get information from the XSSA
    logInfo("========= CNC Information ========");
                                  
    %vcginfo = XIOtech::sanscript::info();

    if ( ! %vcginfo  )
    {
        DumpXSSAError();
        logWarning( ">>>>>>>> Failed to get cncInfo from XSSA <<<<<<<<");
        return (ERROR);
    }

    if (%vcginfo)
    {
        while((my $k, my $v) = each %vcginfo)
        {
            logInfo( "$k = $v");
        }
    
    }

    logInfo("==================================");
    return GOOD;
}

=head2 DisplayCNCInfo

Displays virtual controller group information
   
=over 4

=item Usage:

 my $rc = DisplayCNCInfo();

 if($rc)
 {
    print "Error: Can not retrieve Virtual Controller Group Information \n"; 
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name: DisplayVdiskInfo
#
#        Inputs: none
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Displays all virtual disks information.    
#
#
##############################################################################
sub DisplayVdiskInfo
{
    trace();

    my $i;
    my $count;
    my $loop;
    my @VDInfoArray;
    my $returnValue;


#    logInfo("Pulling the VDisk Info out of the XSSA, if you've room for another snickers - this may take awhile");

    $returnValue = VdInfoList(\@VDInfoArray, "ALL");

    if ($returnValue != GOOD)
    {
        logWarning( ">>>>>>>> Failed to get Info List from VdInfoList <<<<<<<<");
        return ERROR;
    }

    $count = scalar(@VDInfoArray);

    logInfo("Number of virtual disks = $count");

    for ($i = 0; $i < $count; ++$i)
    {
        $loop = $i+1;
        logInfo(" ");
        logInfo("---- Virtual disk information ---- $loop of $count");
        while((my $k, my $v) = each %{$VDInfoArray[$i]})
        {
            logInfo("$k = $v");
        }
    }

    return GOOD;
}

=head2 DisplayVdiskInfo

Displays all virtual disks information.
   
=over 4

=item Usage:

 my $rc = DisplayVdiskInfo();

 if($rc)
 {
    print "Error: Can not retrieve Virtual disk Information \n"; 
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name: DisplayPdiskInfo
#
#        Inputs: none
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Displays information for all physical disks.   
#
#
##############################################################################
sub DisplayPdiskInfo
{
    trace();

    my $i;
    my $count;
    my $loop;
    my @PdInfoArray;
    my $returnValue;

    logInfo("Pulling the PDisk Info out of the XSSA, if you've room for another snickers - this may take awhile");
    $returnValue = PdInfoList(\@PdInfoArray, "ALL");

    if ($returnValue != GOOD)
    {
        logWarning( ">>>>>>>> Failed to get Info List from PdInfoList <<<<<<<<");
        return ERROR;
    }

    $count = scalar(@PdInfoArray);

    logInfo("Number of physical disks = $count");

    for ($i = 0; $i < $count; ++$i)
    {
        $loop = $i+1;
        logInfo(" ");
        logInfo("---- Physical disk information ---- $loop of $count");
        while((my $k, my $v) = each %{$PdInfoArray[$i]})
        {
            logInfo("$k = $v");
        }
    }

    return GOOD;
}

=head2 DisplayPdiskInfo

Displays information for all physical disks
   
=over 4

=item Usage:

 my $rc =  DisplayPdiskInfo();

 if($rc)
 {
    print "Error: No physical disks are present, or Bigfoot did not respond \n"; 
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut


##############################################################################
#
#          Name: DisplayPDisks
#
#        Inputs: none
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Displays physical disks ids.   
#
#
##############################################################################
sub DisplayPDisks
{
    trace();

    my $pdiskListRef;
    my $i;
        
    logInfo( "---- Physical disks present ---- ");

    $pdiskListRef = pdiskList();

    if ( ! @$pdiskListRef  )
    {
        logInfo( ">>>>>>>> Failed to get response from pdisklist <<<<<<<<");
        return ERROR;
    }
    else
    {
        $i = scalar(@$pdiskListRef);

        logInfo("Number of physical disks = $i");

        for ($i = 0; $i < scalar(@$pdiskListRef); $i++)
        {
            logInfo("ID = $$pdiskListRef[$i]");
        }
    }
    return GOOD;
}

=head2 DisplayPDisks

Displays physical disks ids
   
=over 4

=item Usage:

 my $rc = DisplayPDisks();

 if($rc)
 {
    print "Error: No physical disks are present, or Bigfoot did not respond \n"; 
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut


##############################################################################
#
#          Name:  LabelAllDrives
#
#        Inputs: $data      - Required -    Number of Data Drives
#                $unsafe    - Required -    Number of Unsafe Drives
#                $hotspare  - Required -    Number of Hot Spare Drives
#                $unlabel   - Required -    Number of Unlabeled Drives
#                $rest      - Optional -    Label Type For the Left Drives:
#                                           0 = unlabeled
#                                           1 = data
#                                           2 = hot spare
#                                           3 = unsafe
#
#                $option    - Optional -    0 : use all operational drives
#                                           1 : use half the opearational drives
#                                           2 : use only unlabeled drives  
#                                           Default - 0 : use all operational drives
#       Returns: GOOD, if successful, otherwise ERROR
#
#  Globals Used: none
#
#   Description: Labels drives attached to the Bigfoot 
#                Drives will labelled in the following manner: 
#                1st - label Number of Unsafe Drives as UNSAFE Type
#                2nd - label Number of Hot Spare Drives as HOTSPARE Type
#                3rd - label Number of Unlabeled Drives as unlabeled
#                4th - label Number of Data Drives as DATA Type
#                
#                Error Cases: 
#                               No Operational Disks found
#   
#
##############################################################################
sub LabelAllDrives
{
    trace();
    
    my ($data, $unsafe, $numspare, $unlabel, $option ) = @_;
    
    my $driveCount;      # number of physical drives
    my @driveList;       # array of valid drive numbers
    my $drivesToDo;      # counter
    my $ret;
    my %info;
    my %drives;
    my $drive;
    my $dsn;
    my $pdiskinfolist;
    my @pdiskinfolistarray;
    my @operational;            # All operational
    my @unlabel; 

       
    $ret = PdList(\@pdiskinfolistarray, "ALL");
    if($ret == GOOD)
    {
        for (my $i = 0; $i < scalar(@pdiskinfolistarray); $i++)     # for each drive
        {
            my %Info = pdiskInfo($pdiskinfolistarray[$i]);
            if(%Info)
            {
                if ((lc ($Info{DEVICE_STATUS}) eq "operational"))           # if drive is good
                {
                    $dsn = $Info{PSTATE};
                    push(@operational, $pdiskinfolistarray[$i]);
                    logInfo( "Drive $pdiskinfolistarray[$i] is $Info{PSTATE} and $Info{DEVICE_STATUS}");
                    if ( uc $dsn eq XSSAUNLABLEDTYPE )
                    {
                        push(@unlabel, $pdiskinfolistarray[$i]);
                    }
                }
            }
        }

        if($option == 2)
        {
            if(scalar(@unlabel))
            {
                $driveCount = scalar(@unlabel);
                @driveList = @unlabel;
            }
            else
            {
                $driveCount = 0;
            }
        }

        elsif ( $option == 1 )
        {
            # only half for option 1
            if (scalar(@unlabel))
            {
                $driveCount = scalar(@unlabel);
                @driveList = @unlabel;
                $driveCount = int( ($driveCount + 1) / 2 );
            }
            else
            {
                $driveCount = 0;
            }
        }

        else
        {
            $option = 0;
            if(scalar(@operational))
            {
                $driveCount = scalar(@operational);
                @driveList = @operational;
            }
            else
            {
                $driveCount = 0;
            }
        }

        if ($driveCount < 1)
        {
            logWarning(">>>>>>>> Failed to find any Good Drives <<<<<<<<");
            return (ERROR);
        }
   
        $drive = 0;                # index to $driveList

        while ( $driveCount > 0)
        {
            $drivesToDo = $unsafe;                   
            while ( ( $driveCount > 0 ) &&  ( $drivesToDo > 0 ) )
            {
                $ret = LabelSingleDrive(XSSAUNSAFETYPE, $driveList[$drive]);
                if ( $ret == ERROR )
                {
                    logWarning(">>>>>>>> Failed to label drive $driveList[$drive] as unsafe <<<<<<<<");
                    return (ERROR);                # bail on an error
                }
                $drive++;                          # incr drive index
                $drivesToDo--;                     # decr num unsafes to do
                $driveCount--;                     # decr num drives left to do
            }

            $drivesToDo = $numspare;                         
            while ( ( $driveCount > 0 ) &&  ( $drivesToDo > 0 ) )
            {
                $ret = LabelSingleDrive(XSSAHOTSPARETYPE, $driveList[$drive]);
                if ( $ret == ERROR )
                {
                    logWarning(">>>>>>>> Failed to label drive $driveList[$drive] as hot spare <<<<<<<<");
                    return (ERROR);
                }

                $drive++;                          
                $drivesToDo--;
                $driveCount--;
            }

            $drivesToDo = $unlabel;                      
            while ( ( $driveCount > 0 ) &&  ( $drivesToDo > 0 ) )
            {
                $ret = LabelSingleDrive(XSSAUNLABLEDTYPE, $driveList[$drive]);
                if ( $ret == ERROR )
                {
                    logWarning(">>>>>>>> Failed to unlabel drive $driveList[$drive]  <<<<<<<<");
                    return (ERROR);
                }

                $drive++;                       
                $drivesToDo--;
                $driveCount--;
            }

            $drivesToDo = $data;                       
            while ( ( $driveCount > 0 ) &&  ( $drivesToDo > 0 ) )
            {
                $ret = LabelSingleDrive(XSSADATATYPE, $driveList[$drive]);
                if ( $ret == ERROR )
                {
                    logWarning(">>>>>>>> Failed to label drive $driveList[$drive] as data  <<<<<<<<");
                    return (ERROR);
                }
                $drive++;                          
                $drivesToDo--;           
                $driveCount--;
            }
        } 
    } 
    else
    {
        logWarning(">>>>>>>> Failed to get a PDisk List  <<<<<<<<");
        return (ERROR);
    }

    return (GOOD);
}

=head2 LabelAllDrives

Labels drives attached to the Bigfoot 
    Drives will labelled in the following manner: 
        1st - label Number of Unsafe Drives as UNSAFE Type
        2nd - label Number of Hot Spare Drives as HOTSPARE Type
        3rd - label Number of Unlabeled Drives as unlabeled
        4th - label Number of Data Drives as DATA Type

   
=over 4

=item Usage:


 my $data      - Required -    Number of Data Drives
 my $unsafe    - Required -    Number of Unsafe Drives
 my $hotspare  - Required -    Number of Hot Spare Drives
 my $unlabel   - Required -    Number of Unlabeled Drives
 my $option    - Optional -     0 : use all operational drives
                                1 : use half the opearational drives
                                2 : use only unlabeled drives  
                                Default - 0 : use all operational drives


 my $rc = LabelAllDrives($data, $unsafe, $numspare, $unlabel, $option ); 
 
 if($rc)
 {
    print "Error:  Bigfoot did not respond \n";
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut


##############################################################################
#
#          Name: CheckInitProgress
#
#        Inputs: vdisk - virtual disk id
#
#       Outputs: 0 if done, else percent remaining to init
#
#  Globals Used: none
#
#   Description: Checks vdisk status to see if init is running. If so, 
#                returns amount left to do. Else returns 0 to indicate 
#                not running (not started, or done).   
#
#
##############################################################################
sub CheckInitProgress
{
    trace();
    my ($vdd) = @_;

    my $status;
    my $rtn;
    my %vdiskinfo;


    %vdiskinfo = vdiskInfo($vdd);

    if (%vdiskinfo)
    {
#        while((my $k, my $v) = each %vdiskinfo)
#        {
#            print "$k = $v\n";
#        }
    }
    else
    {
        logInfo(">>>>>>>> failed to get vdisk $vdd status <<<<<<<<");
        return 100;
    }

    $status = $vdiskinfo{STATUS};

    if ( lc ($status) eq "operational" )
    {
        logInfo(" Vdisk $vdd is ready for use       ");
        return 0 ;       # disk ready to use
    }

#print " dev stat = $status  ";

    # re got status, but it wasn't 'available' as desired. Now 
    # get the raid info to see how much is left to do

    $rtn = $vdiskinfo{UNINITIALIZED_CAPACITY};

#print " complt pc to go = $rtn ";

    # check it
    if ( $rtn > 0 )
    {
        # return if non-zero
        return $rtn;
    }

    # The vdisk wasn't operational, but we didn't find a raid doing init
    # return something to force us back thru the loop
    
    return 99;      #  return, not quite done        

}

=head2 CheckInitProgress
          
Checks if virtual disks initialization process has finished
     
=over 4

=item Usage:

 my $vdd - Virtual Disk ID 
 my $rc; - Percentage left to initialize  

 while ($rc != 0)
 {
    if($rc == 100)
    {
        print "Error: failed to get vdisk $vdd status ";
        return 1;
    }
    else
    {
        $rc = CheckInitProgress($vdd);
    }           
 }

 Notes:
 
 None

=item Returns:

 On success - Returns percentage left to initialize.
 On error - Returns 100.

=back

=cut

##############################################################################
#
#          Name: FindNewport
#
#        Inputs: Pointer to WWN
#
#       Outputs: Newport ID 
#               INVALID (-999) 
#
#   Description: Return the Newport ID for a given WWN  
#
#
##############################################################################
sub FindNewport
{
    trace();

    my ($shortWWN) = @_;
    
    my $newServersPtr;
    my $port;
    my %npi;
    my $newportWWNPtr;

    #-Make sure that the pointer is valid
    if( !($shortWWN) )
    {
        logInfo("User Error: No Server WWN has been passed into the FindNewport Function ");
        return INVALID;             
    }
        
    $newServersPtr = newportList();
    if(!$newServersPtr)
    {
        #-Server Info command Failed
        logWarning("Failed to get Newport list");
        return INVALID;                
    }
    foreach $port (@$newServersPtr)
    {
        %npi = newportInfo($port);
       
        $newportWWNPtr = ExtractWWN($npi{WWN});
        if ( CompareWWN ( $newportWWNPtr, $shortWWN ) == TRUE )
        {
            return $port;
        }
    }

    logWarning(sprintf("Failed to find Newport %8.8X%8.8X\n",
                        $shortWWN->{WWN_LO}, $shortWWN->{WWN_HI}) );
    return INVALID; 
}

=head2 FindNewport

Determines which Newport Corresponds to specific WWNs
   
=over 4

=item Usage:

    $ret = TestLibs::IntegXMCLib::FindNewport($worldWideNamePtr);
    # Check for Badness
    if ($ret == INVALID)
    {
        TestLibs::Logging::logError("Failed to Find Newport %{$worldWideNamePtr}");
    }

 Notes:
 
 None

=item Returns:

 On success - Returns matching Newport id.
 On error - Returns INVALID.

=back

=cut


##############################################################################
#
#          Name: FindWorkport
#
#        Inputs: Pointer to WWN
#
#       Outputs: Newport ID 
#                INVALID (-999) 
#
#   Description: Return the Newport ID for a given WWN  
#
#
##############################################################################
sub FindWorkport
{
    trace();

    my ($shortWWN) = @_;
    
    my $ServersPtr;
    my $port;
    my %portInfo;
    my $workportWWNPtr;
    
    #-Make sure that the pointer is valid
    if( !($shortWWN) )
    {
        logInfo("User Error: No Server WWN has been passed into the FindWorkport Function ");
        return INVALID;             
    }
        
    $ServersPtr = workportList();
    if(!$ServersPtr)
    {
        #-Server Info command Failed
        DumpXSSAError();
        logWarning("Failed to get Workport list");
        return INVALID;                
    }
    foreach $port (@$ServersPtr)
    {
        %portInfo = workportInfo($port);

        $workportWWNPtr = ExtractWWN($portInfo{WWN});
        if ( CompareWWN ( $workportWWNPtr, $shortWWN ) == TRUE )
        {
            return $port;
        }
#print "Port Info\n";
#$dumper->dumpValues(%portInfo);
    }

    logWarning(sprintf("Failed to find Workport %8.8X%8.8X\n",
                        $shortWWN->{WWN_LO}, $shortWWN->{WWN_HI}) );
    return INVALID; 
}

=head2 FindWorkport

Determines which Workport Corresponds to specific WWNs
   
=over 4

=item Usage:

    $ret = TestLibs::IntegXMCLib::FindWorkport($worldWideNamePtr);
    # Check for Badness
    if ($ret == INVALID)
    {
        TestLibs::Logging::logError("Failed to Find Workport %{$worldWideNamePtr}");
    }

 Notes:
 
 None

=item Returns:

 On success - Returns matching Workport id.
 On error - Returns INVALID.

=back

=cut


##############################################################################
#
#          Name: SetWorkBlock
#
#        Inputs: $workset, $vBlock, $diskGroupID
#
#       Outputs: GOOD on completion
#               ERROR on failure 
#
#   Description: Return the Newport ID for a given WWN  
#
#
##############################################################################
sub SetWorkBlock
{
    trace();

    my ($workSet, $vBlock, $diskGroupID) = @_;

    my $returnValue;
    my $vblockList;
    my $vblockFound;

    # Setup the Logical Sets & Blocks we are forced to play with
    $vblockList = workset($workSet); 
    if (!$vblockList)
    {
        DumpXSSAError();
        logWarning("Unable to set WorkSet to $workSet");
        return ERROR;
    }
    logInfo("Workset is now $workSet");

    if (defined($vBlock)) # If a vBlock was given
    {
        $vblockFound = 0;
        foreach my $vBlockCheck (@$vblockList)
        {
            if ($vBlockCheck == $vBlock)
            {
                $vblockFound = 1;   # Found the VBlock in this workset, OK
                last;
            }
        }

        if (!$vblockFound)
        {
            $returnValue = vblockAdd($vBlock);
            if ($returnValue != XMCGOOD)
            {
                DumpXSSAError();
                logWarning("Unable to add VBlock:$vBlock to Workset:$workSet");
                return ERROR;
            }
        }
        logInfo("VBlock is now $vBlock");

        $returnValue = vblockSet($vBlock);
        if ($returnValue != XMCGOOD)
        {
            DumpXSSAError();
            logWarning("Unable to set VBlock to $vBlock");
            return ERROR;
        }
    }


    if (defined($diskGroupID)) # If a diskgroup was given
    {
        $returnValue = diskgroupSet($diskGroupID);
        if ($returnValue != XMCGOOD)
        {
            DumpXSSAError();
            logWarning("Unable to set DiskGroup to $diskGroupID");
            return ERROR;
        }
        logInfo("DiskGroup is now $diskGroupID");
    }

    return GOOD; 
}

=head2 SetWorkBlock

Set the current Workset and VBlock to those given
   
=over 4

=item Usage:

    $returnValue = SetWorkBlock($workSet, $vBlock, $diskGroupID); 
    if ($returnValue == INVALID)
    {
        logWarning("Unable to set WorkSet:$workSet or VBlock:$vBlock or DiskGroup:$diskGroupID");
        return ERROR;
    }

 Notes:
 
 None

=item Returns:

 On success - Returns GOOD.
 On error - Returns INVALID.

=back

=cut


#######################################################################
# Function name: XSSA_DeviceList
#
# Purpose: connect SN from XMC
#
# INPUT:    Controller Serial Number
#
# OUTPUT:   NONE
#
# Return:   XTCGOOD on success, XTCFAIL otherwise
#######################################################################

sub XSSA_DeviceList
{
    trace();                        # This allows function tracability
    
    my $xdl;
    my $errorMsg;

    $xdl = XIOtech::sanscript::XIOdeviceList();

    if (!$xdl)
    {
        $errorMsg = errorString(); 
        TestLibs::Logging::logWarning("$errorMsg"); 
        TestLibs::Logging::logWarning ("Could not get device list from XSSA\n" . 
                 "Is the XSSA Script Agent operational?");
        return ERROR;
    }

    my $deviceCount = 0;
    foreach my $device (@$xdl)
    {
        logInfo("======== Device list $deviceCount ========");
        foreach my $key (keys %$device)
        {
            my $value = $$device{$key};
            logInfo("$key =>  $value");
        }
        $deviceCount++;
    }

    logInfo("==========================================");
    return GOOD;
}  

=head2 XSSA_DeviceList
          
Display XSSA Device List.
     
=over 4

=item Usage:

 my $rc = XSSA_DeviceList;

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut


#######################################################################
# Function name: XSSA_Reserve
#
# Purpose: connect SN from XMC
#
# INPUT:    Controller Serial Number
#
# OUTPUT:   NONE
#
# Return:   XTCGOOD on success, XTCFAIL otherwise
#######################################################################

sub XSSA_Reserve
{
    trace();                        # This allows function tracability
    my ($connectSN) = @_;
    
    my $returnValue;
    my $errorMsg;

    if(!($connectSN))
    {
        logInfo("User Error: No serial number passed into the function ");
        return ERROR;        
    }
    TestLibs::Logging::logInfo("XSSA Reserve Bigfoot Serial Number: $connectSN");
     
    if(XIOdeviceSet($connectSN) == XMCERROR)
    {
        TestLibs::Logging::logWarning("Could not Set XIOdevice to SN:$connectSN");
        # Get Error String from SANScript
        DumpXSSAError();
        return ERROR;
    }

    $returnValue = reserve($connectSN);     # Reserve XSSA

    if ($returnValue != XMCGOOD)
    {
        $errorMsg = errorString(); 
        TestLibs::Logging::logWarning("$errorMsg"); 
        TestLibs::Logging::logWarning ("Could not reserve device via the XSSA, Return Code:$returnValue\n" . 
                 "Is the XSSA Script Agent operational?");

        return ERROR;
    }

    return GOOD;
}  

=head2 XSSA_Reserve

Connect to the desired VCG allowing to execute commands against it.
  
=over 4

=item Usage:

 my $connectSN - Serial Number of the Controller;
 
 my $rc = XSSA_Reserve($connectSN); 
 
 if($rc)
 {
    print "Error: Failed to connect to the vcg $connectSN \n";
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut


#######################################################################
## Function name: XSSA_Unreserve
##
## Purpose: disconnect SN from XMC
##
## INPUT:    Controller Serial Number
## OUTPUT:   NONE
## Return:   GOOD on success, Error otherwise
#######################################################################

sub XSSA_Unreserve
{
    trace();                        # This allows function tracability
    my ($disconnectSN) = @_;
    
    my $i;
    my $xdl;
    my $disReturn;

    TestLibs::Logging::logInfo ("XSSA unreserve Device Serial Number: $disconnectSN"); 
    $disReturn = unreserve($disconnectSN); # Make sure XSSA is not reserved
    if ($disReturn != XMCGOOD)
    {
        $disReturn = unreserve($disconnectSN); # Retry if first attempt failed
        if ($disReturn != XMCGOOD)
        {
            DumpXSSAError();
            TestLibs::Logging::logError ("Failed to unreserve XSSA");
            return ERROR;
        }
        
    }

    return GOOD;
}
=head2 XSSA_Unreserve

Unreserves this session of XSSA for the CNC.
  
=over 4

=item Usage:

 my $UnreserveSN - Serial Number of the CNC;

 my $rc = XSSA_Unreserve($UnreserveSN); 
 
 if($rc)
 {
    print "Error: Failed to Unreserve the XSSA \n";
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0.
 On error - Returns 1.

=back

=cut

##############################################################################
#
#          Name: DumpXSSAError
#
#        Inputs: none
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: Dump Error Code and Error String from XSSA sanscript 
#
#
##############################################################################
sub DumpXSSAError
{
    trace();

    my $rc = errorCode();
    my $string;
    if( $rc )
    {
        logInfo("  Error Code: $rc");
        $string = errorString($rc); 
    }
    
    if( $string )
    {
        logInfo("Error String: $string ");
    }       
}


=head2 DumpXSSAError
          
Dump Error Code and Error String from XSSA sanscript.

=over 4

=item Usage:

 DumpXSSAError();

=back

=cut

##############################################################################
#
#          Name:  FindFreeWB
#
#        Inputs: $NotUsedVblock - referance to an array of vblocks
#                $NotUsedWorkSet - referance to an array of work sets
# 
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Finds and Updates references to array of unused vlocks
#                and work sets
#
##############################################################################

sub FindFreeWB
{
    my ( $NotUsedVblock, $NotUsedWorkSet ) = @_;
    
    my $ExtLoop;
    my $IntLoop;
    my $check;

    my @AllVblock = (0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15);
    my @AllWorkSet = (0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15);
    
    my @VblockInUse;
    my @WorkSetInUse;

    my $loop;

    my $return = AllVBList(\@VblockInUse, \@WorkSetInUse);
    
    if($return != GOOD)
    {
        logWarning("Discovering Vblocks in use failed");
        return ERROR;
    }
    
#    logInfo(" ");
#    logInfo("Used vlocks @VblockInUse");
#    logInfo(" ");
#   logInfo("Used work sets @WorkSetInUse");
#   logInfo(" ");
#
    for($ExtLoop = 0; $ExtLoop < scalar( @AllVblock ); $ExtLoop++)
    {   
        $check = TRUE;
        
        for($IntLoop = 0; $IntLoop < scalar( @VblockInUse ); $IntLoop++ )
        {
            if($AllVblock[$ExtLoop] == $VblockInUse[$IntLoop])
            {
                $check = FALSE;
                last;
            }
        }
        if($check == TRUE)
        {
            push(@$NotUsedVblock, $AllVblock[$ExtLoop]);
        }
    }

    for($ExtLoop = 0; $ExtLoop < scalar( @AllWorkSet ); $ExtLoop++)
    {
        $check = TRUE;

        for($IntLoop = 0; $IntLoop < scalar( @WorkSetInUse ); $IntLoop++ )
        {
            if($AllWorkSet[$ExtLoop] == $WorkSetInUse[$IntLoop])
            {
                $check = FALSE;
                last;
                
            }
        }
        if($check == TRUE)
        {
            push(@$NotUsedWorkSet, $AllWorkSet[$ExtLoop]);      
        }       
    }
    return GOOD;
}   

##############################################################################
#
#          Name: WaitToRebuild
#
#        Inputs:  None
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Waits for rebuild or defrag to complete on all the physical drives 
#
##############################################################################
sub WaitToRebuild
{
        
    my %PdInfo;
    my $done = 0;
    my $check = TRUE;
    my $Complete = FALSE;
    my $RebuidCompete = 0;
    my $PdiskList;
    my $loop;
    my $return;
    my @PdiskList;

    logInfo("Getting list of physical disks");
    
    $return = PdList(\@PdiskList, "ALL");
    
    if($return == GOOD)
    {
        if(scalar(@PdiskList) == 0)
        {
            logWarning("Physical disk list is empty");
            return ERROR;
        }
    }
    else
    {
        logWarning("Unable to get Physical disk list");
        return ERROR;
    }
    
    $Complete = FALSE;
    while($Complete == FALSE)
    { 
        $Complete = TRUE;
        
        logInfo(" ");
        DelaySecs(60);
        
        for($loop = 0; $loop < scalar(@PdiskList); $loop++ )
        {
            %PdInfo = pdiskInfo($PdiskList[$loop]);
            if(%PdInfo)                 
            {           
                if($PdInfo{PERCENT_REMAINING} != $RebuidCompete)
                {
                    # set flag if at least one drive hasn't finished rebuilding
                    $Complete = FALSE;
                    logInfo("For $PdiskList[$loop] % left to complete = $PdInfo{PERCENT_REMAINING} ");
                }
            }
            else
            {
                logWarning("pdiskInfo command failed for Pd Id $PdiskList[$loop]");
                DumpXSSAError();
                return ERROR;       
            }
        }
        
    }

    return GOOD; 
}

##############################################################################
#
#          Name: MakeSureCopyStarted
#
#        Inputs:  $DestenationId - copy destenation virtual disk id
#                 $Delay - seconds to wait
#                 $Retry - Number of retries  
#
#       Outputs: GOOD, if successful and copy started, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Makes sure the copy operation has started 
#
##############################################################################


sub MakeSureCopyStarted
{
    my ( $DestenationId, $Delay, $Retry ) = @_;
    
    if(!($Delay))
    {
        $Delay = 5;
    }
    if(!($Retry))
    {
        $Retry = 12;
    }
    
    my %Info;
    my $CopyStart = 0;
    my $check = FALSE;
    my $LoopCount = 0;
    
    # allow the information to get updated
    
    DelaySecs(5);
    
    while($check != TRUE)
    {
        DelaySecs($Delay);

        %Info = vdiskInfo($DestenationId);
        
        if(%Info)
        {                    
            if( $LoopCount != $Retry )
            {
               
                if($Info{COPY_PERCENT_COMPLETE} != $CopyStart)
                {
                    $check = TRUE;  
                    logInfo("Copy $Info{COPY_PERCENT_COMPLETE} % complete");
                }
                else
                {
                    $LoopCount++;
                }
            }
            else
            {
                my $Time = ($Retry * $Delay);
                logWarning("Copy to vd id $DestenationId did not start in  $Time sec");
                return ERROR;       
            }
        }
        else
        {
            logWarning("Unable get information for vd id $DestenationId ");
            DumpXSSAError();
            return ERROR;       
        }
    }

    return GOOD;
}

##############################################################################
# Name: CheckIfReady
#
# Desc: Checks to see if XSSA and Bigfoot are ready
#
# In:   $cnc - bigfoot serial
# 
# In Global: none
#             
# 
# Returns: GOOD, ERROR
#
##############################################################################
sub CheckIfReady
{
    my ( $cnc ) = @_;
    
    my $break = FALSE;
    my $lc = 0;         # loop count
    my $pointer; 
    
    logInfo("Checking XSSA and Bigfoot to make sure that both are ready");
    
    ##############################################################################
    ##
    ## After waiting for 2 min attempting to retrieve Device list from the XSSA
    ## if list is retrieve try to setdevice and reserver device, since device may be
    ## already set and reserved (No power cycle took place ), both commands may fail
    ## Get physical disk list
    ## if physical disk list command fails, wait for 1 min and try again
    ##

    while($break != TRUE)
    {
        DelaySecs(120);

        $pointer = XIOdeviceList();
        
        if (defined($pointer))
        {
            logInfo("XSSA is ready and operational ");
            $break = TRUE;
        }
        else
        {
            $lc++;  
        }
        if(($lc > 5) && ($break != TRUE))
        {
            logWarning("XSSA did not come on ready within 10 min");
            return ERROR;   
        }       
    }
    
    # reset $break  and loop count
    # check and wait for Bigfoot to come on ready
    # if we can get list of physical disk from the System that means
    # that power up state is compete
    #
    
    $break = FALSE;
    $lc = 0;

    while($break != TRUE)
    {
        # in case if XSSA has been rebooted Xio device has to be set again
        # as well as device has to be reserved
        # in case XSSA has not been rebooted both command will fail
        # that is why there's not check if command were sucsesfull
        
        DelaySecs(120);        
        
        XSSA_Reserve($cnc);
        
        $pointer = pdiskList();
        
        if(!($pointer))
        {
            $lc++;  
        }
        else
        {
            my @PdId = @$pointer;       #-Get The List of the PD ID'S
            if(!(scalar(@PdId)))
            {
                logWarning("There are no physical disks on the Bigfoot");
                return ERROR; 
            }
            else
            {
                logInfo("Bigfoot is operational and ready");
                $break = TRUE;
            }
        }
        if(($lc > 5) && ($break != TRUE))
        {
            logWarning("Bigfoot did not come on ready within 10 min");
            return ERROR;   
        }       
    }

    return GOOD;
}

##############################################################################
#
#          Name: WaitCopyCompete
#
#        Inputs:  $DestenationId - copy destenation virtual disk id
#                 $Delay - number of seconds to wait before retry
#                 $Retry - number of retries 
#
#       Outputs: GOOD, if successful and copy compete, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Waits for copy to complete
#
##############################################################################


sub WaitCopyCompete
{
    my ( $DestenationId, $Delay, $Retry ) = @_;
    
    # allow the information to get updated

    if(!($Retry))
    {
        $Retry = 12;
    }
    if(!($Delay))
    {
        $Delay = 5;
    }

    DelaySecs($Delay);
    
    my $LoopCount = 0;
    my $check = FALSE;
    my %Info;
    my $CopyComplete = 100;
    my $CopyStart = 0;
    my $CopyKick = FALSE; # check that indecates if copy has started 
    
    while($check != TRUE)
    {
        DelaySecs($Delay);
        
        %Info = vdiskInfo($DestenationId);
        
        if(%Info)
        {                    
            if( $LoopCount != $Retry )
            {
                
                if( ($Info{COPY_PERCENT_COMPLETE} > $CopyStart) && 
                    ( $CopyKick != TRUE)) 
                {
                    $CopyKick = TRUE;   
                }
                
                # Sometime copy complete % get stock on 100% sometimes 
                # never goes to 100% but after increase to %90 and over
                # % complete drops to 0, due to it need additional check
                # to make sure that the copy did start, in other words 
                # at one point was greate the 0.  Then the check for copy 
                # compete would check if compy started, if copy compete 
                # is 100% or already 0

                if($CopyKick == TRUE)
                {
                    if( ($Info{COPY_PERCENT_COMPLETE} == $CopyComplete) ||
                        ($Info{COPY_PERCENT_COMPLETE} == $CopyStart))
                    {
                        $check = TRUE;
                    }

                    logInfo("Copy $Info{COPY_PERCENT_COMPLETE} % complete");
                }
                $LoopCount++;
            }
            else
            {
                logWarning("Copy operation to $DestenationId did not finish in $Retry number of retries ");
                return ERROR;       
            }
        }
        else
        {
            logWarning("Unable get information for vd id $DestenationId ");
            DumpXSSAError();
            return ERROR;       
        }
    }

    return GOOD;
}


##############################################################################
#
#          Name: TargetLookup
#
#        Inputs:  $workset - workset used on the XSSA
#                 $targetListPtr - pointer to target list to update
#
#       Outputs: GOOD if successful
#                ERROR otherwise
#
#   Description: returns the XSSA target selection for a given workset
#
##############################################################################

sub TargetLookup
{
    my ( $workset, $targetListPtr ) = @_;
    
    # Workset assignments are modulus 8, at least for a 2-way
    $workset = $workset % 8;

    # Define the Target table vs workset number
    my @targets = (
                  # Target List           # Workset number
                  [0,2,1,3,4,6,5,7],      # 0
                  [1,3,4,6,5,7,0,2],      # 1
                  [4,6,4,6,5,7,0,2],      # 2
                  [4,6,5,7,0,2,1,3],      # 3
                  [4,6,5,7,0,2,1,3],      # 4
                  [5,7,0,2,1,3,4,6],      # 5
                  [0,2,1,3,4,6,5,7],      # 6
                  [0,2,1,3,4,6,5,7],      # 7
                  );

    @{$targetListPtr} = @{$targets[$workset]};
#print "workset:$workset\n";
#$dumper->dumpValues($targets[$workset]);

    return GOOD;
}

1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.2  2006/12/15 17:54:45  PlasterE
# Added support for 750 RCU.  The directory Test/TestLibs/WsLib holds the DLLs
# needed in order to communicate to Ewok.
# TBolt00000000
#
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
# Revision 1.82  2005/01/11 17:15:57  EidenN
# Tbolt000000:  Fixed info() call from SANScript Reviewed by: AllenK
#
# Revision 1.81  2004/04/30 19:50:19  KohlmeyerA
# Tbolt00000000 - Modified shortWWN to be a hash of full WWN to allow checking of all bytes of WWN and made changes to handle the possiblity of a different controller becoming master when a controller is added to vcg.  Reviewed by Craig
#
# Revision 1.80  2004/01/06 22:47:35  VossO
# Tbolt00000000 Edit the file
#
# Revision 1.79  2003/10/15 15:29:48  TeskeJ
# tbolt00009173 - raid-5 updates for release 3, mostly vdmax & crexpassocdel
# rev by Craig
#
# Revision 1.78  2003/10/02 19:35:46  GrigorenkoO
# Tbolt00000000 Fixed bug, rev JT
#
# Revision 1.77  2003/10/02 19:20:00  TeskeJ
# tbolt00009183 - RAID 5 changes in xssavdmax code and configuration file
# rev by Olga
#
# Revision 1.76  2003/09/29 20:42:13  ThiemanE
# Changed names to be compatible with linux
#
# Revision 1.75  2003/09/26 23:03:09  ThiemanE
# Updated include library names to make them Linux compatible
#
# Revision 1.74  2003/09/26 23:02:12  ThiemanE
# Updated include library names to make them Linux compatible
#
# Revision 1.73  2003/09/23 16:47:23  TeskeJ
# tbolt00009173 - Release 3 test code changes
# rev by Olga
#
# Revision 1.72  2003/09/05 21:08:06  GrigorenkoO
# Tbol00000000 Changed version fuction
#
# Revision 1.71  2003/08/18 18:14:44  GrigorenkoO
# Tbolt00000000 took out print from get versions function rev. Craig looked at it
#
# Revision 1.70  2003/07/23 15:00:23  GrigorenkoO
# Tbolt00000000 Added new test cases
#
# Revision 1.69  2003/07/14 19:20:11  GrigorenkoO
# Tbolt00000000 Changed number of vblocks and woksets
#
# Revision 1.68  2003/06/06 20:21:09  WerningJ
# Added TargetLookUp function to get target list the XSSA would use when
# assigning servers
# Reviewed by Craig M
#
# Revision 1.67  2003/05/29 14:54:04  WerningJ
# Deleted XSSACodeUpdate sub as it was unused in this library
# Reviewed by Olga
#
# Revision 1.66  2003/05/29 12:56:44  WerningJ
# Rewrote all XTC data structures
# Reviewed by Craig M
#
# Revision 1.65  2003/04/22 20:27:17  GrigorenkoO
# Tbolt00000000 removed the kludge for label unsafe - "Notsafe"
#
# Revision 1.64  2003/04/22 15:29:21  GrigorenkoO
# Tbolt00000000 Added function WaitCopyStart, WaitCopyCompete, CheckIfReady, WaitRebuildCompete
#
# Revision 1.63  2003/04/15 14:55:43  WerningJ
# Add back in the Klude for PDisk label NOTSAFE vs UNSAFE
# Reviewed by Craig M
#
# Revision 1.62  2003/03/27 17:37:31  WerningJ
# Major updates for the new TB XSSA
# Reviewed by Olga
#
# Revision 1.61  2002/11/11 21:26:38  WerningJ
# Now using constants from CONSTANT.pm for Drive types
# Reviewed by Craig M
#
# Revision 1.60  2002/10/01 19:28:49  WerningJ
# Single Word change to see if Kieth is still watching
# Reviewed by Craig M
#
# Revision 1.59  2002/09/30 21:16:06  GrigorenkoO
# Added library functions tbolt00000000
#
# Revision 1.58  2002/09/25 14:54:58  WerningJ
# Added error output messages and Server list returned as a pointer
# Reviewed by Craig M
#
# Revision 1.57  2002/08/26 14:42:17  WerningJ
# Corrected the call to loginfo to be logInfo, case specific.
#
# Revision 1.56  2002/08/22 19:32:42  GrigorenkoO
# Tbolt0000000 fixed bug
#
# Revision 1.55  2002/08/22 15:20:49  GrigorenkoO
# Tbolt00000000 Fixed Bug
#
# Revision 1.54  2002/08/21 13:34:35  GrigorenkoO
# Tbolt00000000 Modified most of the functions
#
# Revision 1.53  2002/08/16 15:42:05  GrigorenkoO
# Tbolt000000 Changed FindSIDs function
#
# Revision 1.52  2002/08/16 14:04:05  GrigorenkoO
# Tbolt000000 Changed VdExpandSingle function
#
# Revision 1.51  2002/08/16 14:01:16  GrigorenkoO
# Tbolt000000 Changed ManageServer function
#
# Revision 1.50  2002/08/16 14:00:07  GrigorenkoO
# Tbolt000000 Changed LabelSingleDrive function
#
# Revision 1.49  2002/08/16 13:57:53  GrigorenkoO
# *** empty log message ***
#
# Revision 1.48  2002/08/16 13:54:11  GrigorenkoO
# Tbolt0000000 Changed function  GetListOfAnyRaidType
#
# Revision 1.47  2002/08/16 13:51:32  GrigorenkoO
# Tbolt0000000 Changed function  DisassocOne
#
# Revision 1.46  2002/08/16 13:50:33  GrigorenkoO
# Tbolt0000000 Changed function  _FindTargets
#
# Revision 1.45  2002/08/16 13:49:01  GrigorenkoO
# Tbolt0000000 Changed function  DeleteSingleVD
#
# Revision 1.44  2002/08/16 13:47:13  GrigorenkoO
# Tbolt0000000 Changed function  AssociateVdRaid10
#
# Revision 1.43  2002/08/16 13:46:11  GrigorenkoO
# Tbolt0000000 Changed function  AssociateVdRaid1
#
# Revision 1.42  2002/08/16 13:40:28  GrigorenkoO
# Tbolt0000000 Changed function  AssociateVdRaid0
#
# Revision 1.41  2002/08/16 13:39:24  GrigorenkoO
# Tbolt0000000 Changed function  AssociateVdisk
#
# Revision 1.40  2002/08/16 13:38:14  GrigorenkoO
# Tbolt0000000 Added function AssociateVdCroupToServerGroup
#
# Revision 1.39  2002/08/15 21:45:59  GrigorenkoO
# no message
#
# Revision 1.38  2002/08/15 21:31:52  WerningJ
# Tbolt00000000 Changed Disconnect command
#
# Revision 1.37  2002/08/15 21:28:52  GrigorenkoO
# Tbolt0000000 Connect Disconnect
#
# Revision 1.36  2002/08/15 21:27:35  GrigorenkoO
# Tbolt0000000 Connect Disconnect
#
# Revision 1.35  2002/08/15 20:57:19  GrigorenkoO
# Tbolt0000000 Checked changes connected to VD
#
# Revision 1.34  2002/08/15 17:18:45  GrigorenkoO
# no message
#
# Revision 1.33  2002/08/15 13:08:02  GrigorenkoO
# Tbolt00000000 changed PdList and PdiskInfo
#
# Revision 1.32  2002/08/15 13:05:57  GrigorenkoO
# Tbolt00000000 changed LabelSingleDrive
#
# Revision 1.31  2002/08/15 13:03:35  GrigorenkoO
# Tbolt00000000 changed LabelList
#
# Revision 1.30  2002/08/15 13:01:27  GrigorenkoO
# Tbolt00000000 changed  ReLabelTheWayIsLabeled
#
# Revision 1.29  2002/08/15 12:58:06  GrigorenkoO
# Tbolt00000000 changed  LabelSingleDrive
#
# Revision 1.28  2002/08/14 22:10:29  WerningJ
# Changes to XMC Connect & Disconnect to go along with SANScript.pm changes
#
# Revision 1.27  2002/08/14 21:43:33  GrigorenkoO
# Tbolt00000000 changed LabelAllEngTest
#
# Revision 1.26  2002/08/14 21:40:04  GrigorenkoO
# Tbolt00000000 changed XSSA_Reserve command to set xiodeivice
#
# Revision 1.25  2002/08/12 14:18:09  GrigorenkoO
# Tbolt00000000 changed XSSA_Reserve command to set xiodeivice
#
# Revision 1.24  2002/08/07 19:31:17  GrigorenkoO
# no message
#
# Revision 1.23  2002/08/07 19:26:17  GrigorenkoO
# Tbolt00000000 Modified l_listToHash fuction by addting empty list case
#
# Revision 1.22  2002/08/07 19:24:35  GrigorenkoO
# Tbolt00000000 Rewrote  DisassocAll function in order for it to function
#
# Revision 1.21  2002/08/07 19:22:08  GrigorenkoO
# Tbolt00000000 Added AssociateVdRaid0, AssociateVdRaid1, AssociateVdRaid10
# functions
#
# Revision 1.20  2002/08/07 19:14:20  GrigorenkoO
# Tbolt00000000 Changed All Robustness function to take Number of Loops Option
#
# Revision 1.19  2002/08/06 20:00:48  GrigorenkoO
# Tbolt00000000 Added option 0 : use all operational drives in function
# LabelAllDrives
#
# Revision 1.18  2002/08/06 14:04:23  MenningC
# Fixed a couple compile time errors
#
# Revision 1.17  2002/08/05 21:23:45  GrigorenkoO
# Tbolt00000000 Modified  DisassociateAllFromServert function
#
# Revision 1.16  2002/08/05 21:19:07  GrigorenkoO
# Tbolt00000000 Modified  AssociateEngTest function
#
# Revision 1.15  2002/08/05 21:17:48  GrigorenkoO
# Tbolt00000000 Modified  _FindTargets function
#
# Revision 1.14  2002/08/05 21:16:37  GrigorenkoO
# Tbolt00000000 Modified DisassocOne function
#
# Revision 1.13  2002/08/05 19:34:54  GrigorenkoO
# Tbolt00000000 Modified Single Server Info Function
#
# Revision 1.12  2002/08/05 19:32:16  GrigorenkoO
# Tbolt00000000 Added LunsInUse Function
#
# Revision 1.11  2002/08/05 18:50:29  GrigorenkoO
# Tbolt00000000 Added GetVDRaid10InfoList  function
#
# Revision 1.10  2002/08/05 18:48:51  GrigorenkoO
# Tbolt00000000 Added GetVDRaid5InfoList  function
#
# Revision 1.9  2002/08/05 18:48:04  GrigorenkoO
# Tbolt00000000 Added GetVDRaid1InfoList function
#
# Revision 1.8  2002/08/05 18:47:10  GrigorenkoO
# Tbolt00000000 Added GetVDRaid0InfoList function
#
# Revision 1.7  2002/08/05 14:44:40  GrigorenkoO
# Tbolt00000000 Added ReLabelTheWayIsLabeled function
#
# Revision 1.6  2002/08/05 13:18:21  GrigorenkoO
# no message
#
# Revision 1.5  2002/07/31 19:44:18  HouseK
# Result of merge from tag LOGGING_CHANGES
#
# Revision 1.4.2.4  2002/07/31 17:53:38  GrigorenkoO
# Corrected LabelAllDrives function, removed Serial Numbers from function calls
#
# Revision 1.4.2.2  2002/07/30 18:48:57  MenningC
# Tbolt00000000 changes to facilitate compiling
#
# Revision 1.4.2.1  2002/07/30 18:18:32  GrigorenkoO
# no message
#
# Revision 1.2  2002/05/30 20:33:54  WerningJ
# Changed DEVICE_CLASS to DEVICE_LABEL to match what is now getting
# returned from the XMC on PDisk List.
#
# Revision 1.1  2002/05/08 19:03:00  WerningJ
# Initial Check in
#
#
##############################################################################
#
#  5/6/2002  craigm
#            convert to pm file to use as a library
#  5/5/2002  craigm
#            debugging complete for most fcns related to 2way creation
#  5/1/2002  craigm
#            Start conversion to XMC environment
#  4/30/2002 craigm
#            fixed setserverprop when there are more than 2 servers with 
#            associated disks
#  4/29/2002 craigm
#            added ability to get the SIDs based upon server WWN list
#            this made option 10 in basic config
#  4/28/2002 craigm
#            option 3 now builds a San Links configuration with a
#            shared drive bay
#  4/24/2002 craigm
#            added an option to view controller state
#  4/23/2002 craigm
#            debugged option selection menu and options 8,2,6,7,21,22,1
#  4/22/2002 craigm
#            numerous changes, vdisks use disk groups and more variation
#            in parameters, additional error checking. Will wait for 
#            raid initialization to complete. Some added functionality. 
#            Computes VCG serial number, updated vdisk creation options to
#            use all the arrays, remove debug prints (but not all). 
#  4/8/2002  craigm
#            added error checks in basicConfig and started on AssociateServers
#
#  4/6/2002  craigm
#            added more functionality, made it compile, still untested in 
#            real life.
#
#  3/28/2002 craigm
#            started with a clean slate. cut and paste from Keith's and
#            Olga's scripts. limited functionality, not compiled/tested
#
##############################################################################
