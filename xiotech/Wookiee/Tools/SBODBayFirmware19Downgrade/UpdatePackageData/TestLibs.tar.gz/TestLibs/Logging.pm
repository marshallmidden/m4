#$Id: Logging.pm 4298 2005-05-04 18:53:47Z RysavyR $
##############################################################################
# File name:  TestLibs::Logging
#
# Desc: A logging facility for trace and debug features.
#
# Date: 07/17/2002
#
# Original Author:  Keith House
#
# Last modified by  $Author: RysavyR $
# Modified date     $Date: 2005-05-04 13:53:47 -0500 (Wed, 04 May 2005) $
#
# Copyright XIOtech A Seagate Company 2001, 2002
#
##############################################################################
package TestLibs::Logging;

=head1 NAME

TestLibs::Logging - A logging facility for trace, debug and log features

$Id: Logging.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

 use TestLibs::Logging;
 use XIOTech::cmStats;
 use XIOTech::cmdMgr;

 debug("Here is some debug info")

 logInfo("Important info");

 logControl(trace => "true", debug => "true", error => "stop")

=head1 DESCRIPTION

trace() provides a method of capturing code execution

debug() provides a method of capturing specific information a developer
deems useful in debugging their Perl script.

trace() and debug() display to STDERR by default, but can be sent to a file by using
debug_to().

The logControl() function controls the level of detail being
logged.  For example, to turn on trace and debug:

    logControl(trace => "true", debug => "true");

trace and debug are off by default

Other control options are:

 warning : continue - do not pause on warnings (default)
 warning : pause    - pause on warnings
 error   : continue - do not pause or stop of errors (default)
 error   : pause    - pause on warnings
 error   : stop     - stop on errors

=over 4

=item logInfo($msg)

logs informational messags

$msg is required.

=item logWarning($msg)

logs warning messages

$msg is required.

=item logError($msg)

logs error messages

$msg is required.

=item trace($msg)

The trace() function is used for tracing function
calls. The file name, line number and calling subroutine name is
printed along with the passed argument. This should
be called at the start of every major function.

$msg is optional

=item debug($msg)

The debug() function is used for high-granularity
reporting of state in functions.

$msg is optional

=item logControl(key => value, ...)

logControl() changes the way Logging module works.  The allowed key-value pairs are:

 trace - true or false
 debug - true or false
 warning - continue or pause
 error - continue, pause, or stop
 verbose - true or false or no header
 stdout - true or false

 pause will prompt the user to continue
 stop will terminate the script
 verbose will display log messages to the screen if set to true, otherwise only
 the message will be displayed to the screen
 stdout will set the output to display on standard out ot not

=item debug_to(FILE_HANDLE)

debug_to() allows you to change where the trace() and debug() output will go.
The defaut is STDERR. If a file handle is passed, the user must ensure the file is open
and ready to be used.

=item log_to(FILE_HANDLE)

Same as debug_to(), except the default is STDOUT.

=back

=cut

require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(
             _time

             debug
             debug_to 
             log_to 
             logControl 
             logError
             logInfo
             logStatus
             logBinStatus
             logWarning 
             trace

             logDeviceList 
             logDeviceStatus
             logDiskBayInfo 
             logDiskBays 
             logDisplayList
             logEnvironmentalStats 
             logFirmwareVersion 
             logGlobalCacheInfo 
             logLogInfo 
             logModeDataInfo 
             logNoVersionList
             logNoSummary
             logObjectList 
             logPhysicalDiskInfo
             logPhysicalDisks 
             logRaids 
             logSerialNumbers 
             logServerInfo
             logServers 
             logStatsCacheDevices
             logStatsLoop
             logStatsPCI
             logStatsProc
             logStatsServer
             logSos 
             logTargetInfo 
             logTargets
             logTargetStatus
             logVCGInfo 
             logVersion 
             logVirtualDiskInfo 
             logVirtualDiskRaidInfo 
             logVirtualDisks 
             logVirtualLinkCreate 
             logVirtualLinkCtrlInfo 
             logVirtualLinkCtrlVDisks 
             );

use lib "../CCBE";
#use IO::Handle;
use Carp;
use TestLibs::Constants;
use XIOTech::PI_Constants;
use XIOTech::cmUtils;
use XIOTech::cmLogs;

use strict;
use warnings;

use constant _WARNING  => "WARN ";
use constant _ERROR    => "ERROR";
use constant _INFO     => "INFO ";
use constant _TRACE    => "TRACE";
use constant _DEBUG    => "DEBUG";
use constant _VERSION  => "VER  ";

my %current_level = ();

my $DEBUG_OUTPUT = \*STDERR;
my $LOG_OUTPUT   = \*STDOUT;
my $warnings = 0;
my $errors   = 0;
my @versionList;
my $versionListLogged = 0;
my $skipSummary = 0;

my %controlTable = ( verbose => "false",
                     stdout  => "true",
                     warning => "continue",
                     error   => "pause",
                     debug   => "false",
                     trace   => "false" );

BEGIN
{
    STDOUT->autoflush(1);
    STDERR->autoflush(1);
}

END
{
    my $time = _time();
    
    if ($versionListLogged == 0)
    {
        $versionListLogged = 1;
    }
    
    
    logInfo("PROGRAM EXITING");
    if(   $skipSummary == 0 )
    {
        logInfo("Total number of WARNINGS = $warnings");
        logInfo("Total number of ERRORS   = $errors");
        logInfo("Date/Time                = $time");
        logInfo("END OF LOG\n\n");
    }
}

logVersion(__PACKAGE__, q$Revision: 4298 $);

sub debug_to
{
    $DEBUG_OUTPUT = shift;

    if (!defined($DEBUG_OUTPUT))
    {
        Carp::croak("debug output file handle can not be undefined");
    }
    $DEBUG_OUTPUT->autoflush(1);
}


sub log_to
{
    $LOG_OUTPUT = shift;

    if (!defined($LOG_OUTPUT))
    {
        Carp::croak("log output file handle can not be undefined");
    }
    $LOG_OUTPUT->autoflush(1);
}

sub logInfo ($)
{
    return (_logThis(_INFO, shift @_));
}


sub logWarning ($)
{
    return (_logThis(_WARNING, shift @_));
}

sub logError ($)
{
    return(_logThis(_ERROR, shift @_));
}

#
# logStatus and logBinStatus - these functions are for entries that need
# to be propogated to the Director as well as the logfile.
#

sub logStatus ($)
{
    # This should usually be a text message to be logged
    my ($message) = @_;
    
    return (_logThis(_INFO, "XIOciser Update: " . $message));
}

sub logBinStatus ($)
{
    # This is a binary update which means we will need to add text before
    # we can send a copy to the logfile

    my ($message) = @_;

    
    return (_logThis(_INFO, $message));
}

sub logNoVersionList
{
    $versionListLogged = 1;
}
sub logNoSummary
{
    $skipSummary = 1;
}

sub _logThis
{
    my ($type, $message) = @_;
    my ($subr) = (caller(2))[3];
    my $time = _time();
    my $rc = GOOD;
    my $pause = 0;
    my $output;
    my $pauseMessage;

    if ($versionListLogged == 0)
    {
        $versionListLogged = 1;

        for(my $i = 0; $i < scalar(@versionList); $i++)
        {
            _logThis(_VERSION, $versionList[$i]);
        }
    }

    if (!defined($message))
    {
        croak("You must specify a message to use this logging command");
    }

    $output = "[$time][$type]";

    if (defined($subr))
    {
        my @parts = split("::", $subr);
        $subr = substr($parts[scalar(@parts - 1)], 0, 15);
        $output .= sprintf("[%-15s]", $subr);
    }

    $output .= " " .    $message;

    if ($output !~ /\n$/)
    {
        $output .= "\n";
    }

Log_Case:
    {
        $type eq _INFO && do
        {
            last Log_Case;
        };

        $type eq _WARNING && do
        {
            $warnings++;

            if ($controlTable{"warning"} eq "pause")
            {
                $output .= "PAUSING ON WARNING\n";
                $pauseMessage = "Hit Enter to continue\n";
                $pause = 1;
            }
            last Log_Case;
        };

        $type eq _ERROR && do
        {
            $errors++;  # keep running list for summary at the end

            if ($controlTable{"error"} eq "pause")
            {
                $output .= "PAUSING ON ERROR\n";
                $pauseMessage = "Hit Enter to continue\n";
                $pause = 1;
            }

            if ($controlTable{"error"} eq "stop")
            {
                $output .= "STOPPING ON ERROR\n";
                $rc = ERROR;
            }
            # continue on ERROR is implied
            last Log_Case;
        };

        $type eq _VERSION && do
        {
            $output = "[$time][$type]$message\n";
            last Log_Case;
        };
    }

    # make sure we don't print to STDOUT twice
    
    if ($LOG_OUTPUT != \*STDOUT)
    {

        if ($controlTable{verbose} eq "no header")
        {
            print $LOG_OUTPUT $message;
            if ($message !~ /\n$/)
            {
                print $LOG_OUTPUT "\n";
            }
        }
        else
        {
            print $LOG_OUTPUT $output;
        }

    }

    # Supress standard output if not enabled
    if ($controlTable{stdout} ne "false")
    {
        # verbose is on, print all to the screen
        if ($controlTable{verbose} eq "true")
        {
            print STDOUT $output;
        }
        else # verbose is off, print only the original message
        {
            if ($message !~ /\n$/)
            {
                $message .= "\n";
            }

            print STDOUT $message;
        }
    }

    if ($pause == 1)
    {
        print $pauseMessage;
        $pause = <STDIN>;
    }
    elsif ($rc == ERROR)
    {
        exit(ERROR);
    }

    return GOOD;
}

sub logControl
{
    my %hash = @_;
    my ($k, $v);

    while (($k, $v) = each %hash)
    {
        if (exists($controlTable{$k}))
        {
            $controlTable{$k} = $v;
        }
        else
        {
            croak("$k is an invalid logControl option");
        }
    }

    return (\%controlTable);
}

sub logVersion
{
    my ($package, $version) = @_;
    push(@versionList, " " . $package . "->" . $version);    
}

sub trace
{
    _debug(_TRACE, shift @_) if ($controlTable{'trace'} eq "true");
}

sub debug
{
    _debug(_DEBUG, shift @_) if ($controlTable{'debug'} eq "true");
} 

sub _debug
{
    my $type = shift;
    my $message = shift;
    my ($package, $file, $line) = caller(1);
    my ($subr) = (caller(2))[3];
    my $time = _time();
    my $output;

    $output = "[$time][$type]";

    if (defined($subr))
    {
        my @parts = split("::", $subr);
        $subr = substr($parts[scalar(@parts - 1)], 0, 15);
        $output .= sprintf("[%-15s]", $subr);
    }

    $output .= sprintf("[%.5d]", $line);

    if (defined($message))
    {
        $output .= " " .$message;
    }

    if ($output !~ /\n$/)
    {
        $output .= "\n";
    }

    print $DEBUG_OUTPUT $output;
}

sub _time
{
    my ($sec,
        $min,
        $hour,
        $mday,
        $mon,
        $year,
        $wday,
        $yday,
        $isdst) = CORE::localtime(time);

    return (sprintf("%.2d/%.2d/%d %.2d:%.2d:%.2d",
            $mon + 1,
            $mday,
            $year + 1900,
            $hour,
            $min,
            $sec));
}

sub logVirtualDiskInfo
{
    trace();

    my (%info) = @_;
    my $output;
    


    $output = XIOTech::cmdMgr::displayVirtualDiskInfo(0, %info);
    logInfo( $output."\n");



}

sub logVirtualDisks
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList(%info));


    $output = XIOTech::cmdMgr::displayVirtualDisks(0,  %info);

    logInfo( $output."\n");


}


sub logVCGInfo
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList(%info));


    $output = XIOTech::cmdMgr::displayVCGInfo(0,  %info);

    logInfo( $output."\n");
}

sub logObjectList
{
    trace();

    my (%info) = @_;
    my $msg;

    $msg = "\n";

    my $i;

    for $i (0..$#{$info{LIST}})
    {
        $msg .= "  " . $info{LIST}[$i] . "\n";
    }

    logInfo($msg);
}

sub _objectList2
{
    trace();
    # this one used ONLY for logObjectList()
    my (%info) = @_;
    my $output = "\n";

    while((my $k, my $v) = each %info)
    {
        if (!defined($v))
        {
            $v = "error: undefined";
            debug("The value in hash $k is undefined");
        }

        $output .= "$k = $v\n";

print "$k, $v \n";

        if (ref($v))
        {
            $output .= _arrayDump($v, $k);
        }
    }
    return($output);
}




sub _objectList
{
    trace();

    my (%info) = @_;
    my $output = "\n";

    while((my $k, my $v) = each %info)
    {
        if (!defined($v))
        {
           $v = "error: undefined";
           debug("The value in hash $k is undefined");
        }

        $output .= "$k = $v\n";

        if (ref($v))
        {
            if (ref($v) eq "HASH")
            {
                $output .= _hashDump($v, "$k:");
            }
            elsif (ref($v) eq "ARRAY")
            {
                $output .= _arrayDump($v, $k);
            }
        }
    }
    return($output);
}

sub _arrayDump
{
    trace();
    
    my ($array, $key) = @_;
    my $output = "";
    
    for (my $i = 0; $i < scalar(@$array); $i++)
    {
        $output .= "$key" . "[$i] = $array->[$i]\n";
        
        if (ref($array->[$i]))
        {
            if (ref($array->[$i]) eq "ARRAY")
            {
                $output .= _arrayDump($array->[$i], "$key" . "[$i]");
            }
            elsif (ref($array->[$i]) eq "HASH")
            {
                $output .= _hashDump($array->[$i], "$key" . "[$i]");
            }
        }
    }
    return ($output);
}

sub _hashDump
{
    trace();

    my ($hash, $key) = @_;
    my $output = "";

    while((my $k, my $v) = each %$hash)
    {
        if (!defined($v))
        {
           $v = "error: undefined";
           debug("The value in hash $key:$k is undefined");
        }
               
        $output .= "$key:$k = $v\n";
        
        if (ref($v))
        {
            if (ref($v) eq "HASH")
            {
                $output .= _hashDump($v, "$key:$k");
            }
            elsif (ref($v) eq "ARRAY")
            {
                $output .= _arrayDump($v, "$key:$k");
            }
        }
    }
    return ($output);
}

sub logDeviceStatus
{
    trace();

    my ($dev, $swtch, %info) = @_;
    my $i;
    my $output;

    debug("dev = $dev swtch = $swtch");
    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayDeviceStatus(0, $dev, $swtch, %info);
    
    logInfo($output . "\n");
}

sub logVirtualLinkCtrlInfo
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output  = "Virtual Link Controller Information:\n";
    $output .= sprintf("STATUS:                0x%x\n", $info{STATUS_MRP});
    $output .= sprintf("LEN:                   %lu\n", $info{LEN});
    $output .= sprintf("WWN:                   %8.8x%8.8x\n", $info{WWN_LO}, $info{WWN_HI});
    $output .= sprintf("CONTROLLER NAME:       %s\n", $info{CNAME});
    $output .= sprintf("LUNS:                  %hu\n", $info{LUNS});
    $output .= sprintf("CONTROLLER TYPE:       0x%x\n", $info{SCTYPE});
    $output .= sprintf("CLUSTER:               %hu\n", $info{CLUSTER});
    $output .= sprintf("IP ADDRESS:            %lu\n", $info{IPADDR});
    $output .= sprintf("SERIAL NUMBER:         %lu\n", $info{SERIAL_NUM});

    logInfo($output . "\n");
}

sub logVirtualLinkCtrlVDisks
{
    trace();

    my (%info) = @_;
    my $output;
    my $i;

    debug(_objectList(%info));

    $output = "Virtual Link Controller Virtual Disks:\n";
    $output .= sprintf("STATUS:                0x%x\n", $info{STATUS_MRP});
    $output .= sprintf("LEN:                   %lu\n", $info{LEN});
    $output .= sprintf("COUNT:                 %hu\n", $info{COUNT});
    $output .= "\n";

    $output .=  "ORDINAL  LUN  RTYPE  CLUSTER  ATTR  CAPACITY  SERIAL_NUM  VID1  VID2  SCNT  VLCNT  VDNAME\n";
    $output .=  "-------  ---  -----  -------  ----  --------  ----------  ----  ----  ----  -----  ------\n";

    for ($i = 0; $i < $info{COUNT}; ++$i)
    {
        $output .= sprintf("%7hu  %3hu  0x%x  %hu  0x%x",
                            $i,
                            $info{VDDS}[$i]{LUN},
                            $info{VDDS}[$i]{RTYPE},
                            $info{VDDS}[$i]{CLUSTER},
                            $info{VDDS}[$i]{ATTR});
        $output .= "  " . $info{VDDS}[$i]{DEVCAP};
        $output .= sprintf("  %lu  %hu  %hu  %hu  %hu",
                           $info{VDDS}[$i]{SSERIAL},
                           $info{VDDS}[$i]{VID1},
                           $info{VDDS}[$i]{VID2},
                           $info{VDDS}[$i]{SCNT},
                           $info{VDDS}[$i]{VLCNT});
        $output .= "  " . $info{VDDS}[$i]{VDNAME};
        $output .= "\n";
    }
    logInfo($output . "\n");
}

sub logServerInfo
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayServerInfo(0, %info);

    logInfo($output . "\n");
}

sub logVirtualLinkCreate
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = "\nVirtual Link Create Information:\n";
    $output .= sprintf("STATUS:                0x%x\n", $info{STATUS_MRP});
    $output .= sprintf("LEN:                   %lu\n", $info{LEN});
    $output .= sprintf("COUNT:                 %hu\n", $info{COUNT});
    $output .= sprintf("VID:                   %hu\n", $info{VID});
    $output .= sprintf("CONTROLLER_NAME:       %s\n", $info{CTRLNAME});
    $output .= sprintf("VDISK_NAME:            %s\n", $info{VDNAME});

    logInfo($output . "\n");
}

sub _getGoodFailStr
{
    my ($val) = @_;

    if ($val)
    {
        return("FAIL");
    }
    return("GOOD");
}

sub _getString_CLASS
{
    my ($class) = @_;
    my $fmt;

    if ($class == 0)
    {
        $fmt = "0x%x - UNLABELED";
    }
    elsif ($class == 1)
    {
        $fmt = "0x%x - DATA";
    }
    elsif ($class == 2)
    {
        $fmt = "0x%x - HOTSPARE";
    }
    elsif ($class == 3)
    {
        $fmt = "0x%x - UNSAFE";
    }
    else
    {
        $fmt = "0x%x";
    }

    return(sprintf($fmt, $class) . "\n");
}

sub logDiskBayInfo
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayDiskBayInfo(0, %info);

    logInfo("\n" . $output . "\n");
}

sub logDiskBays
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayDiskBays(0, %info);

    logInfo($output . "\n");
}

sub logGlobalCacheInfo
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayGlobalCacheInfo(0, %info);

    logInfo("\n" . $output . "\n");
}


sub logServers
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList(%info));
    
    $output = XIOTech::cmdMgr::displayServers(0,  %info);

    logInfo($output . "\n");
}

sub logPhysicalDiskInfo
{
    trace();
    
    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayPhysicalDiskInfo(0, %info);

    logInfo($output . "\n");
}

sub logPhysicalDisks
{
    trace();

    my ($dsptype, %info) = @_;
    my $output;

    debug("dsptype = $dsptype");
    debug(_objectList(%info));

    $output .= XIOTech::cmdMgr::displayPhysicalDisks(0, $dsptype, %info);


    logInfo($output . "\n");
}

sub logVirtualDiskRaidInfo
{
    trace();

    my (%info) = @_;
    my $output;
    my $i;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayVirtualDiskRaidInfo(0, %info);

    logInfo($output . "\n");
}

sub logRaids
{
    trace();
    
    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayRaids(0,  %info);

    logInfo($output . "\n");
}

sub logTargetInfo
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayTargetInfo(0,  %info);

    logInfo("\n" . $output . "\n");
}

sub logTargets
{
    trace();
    
    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayTargets(0,  %info);

    logInfo("\n" . $output . "\n");

}




sub logEnvironmentalStats
{
    trace();

    my ($ctlr, %envStats) = @_;
    my $output;

    debug(_objectList(%envStats));

    $output = XIOTech::cmdMgr::displayEnvironmentalStatsExtended(0, %envStats);

    logInfo($output . "\n");
}

sub logFirmwareVersion
{
    trace();
    
    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayFirmwareVersion(0,  %info);

    logInfo("\n" . $output . "\n");
}

sub logSerialNumbers
{
    trace();
    
    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output =XIOTech::cmdMgr::displaySerialNumbers(0, %info);

    logInfo($output . "\n");
}

sub logDeviceList
{
    trace();
    
    my (%info) = @_;
    my $output;
    my $i;

    debug(_objectList(%info));
    
    $output = XIOTech::cmdMgr::displayDeviceList(0, %info);

    logInfo($output . "\n");
}


sub logLogInfo
{
    trace();
    
    my ($mode, $gmt, %info) = @_;
    my $tmpFilename = " ";
    my $tmpFH;
    my $originalVerboseSetting;
    
    debug("mode = $mode gmt = $gmt");
    debug(_objectList(%info));

    #
    # create a temporary file for the log data.  Create it using tempfile()
    # to ensure we have a unique filename and prevent any race conditions.
    #
    ($tmpFH, $tmpFilename) = File::Temp::tempfile("loginfo_XXXXXXXX", DIR => File::Spec->tmpdir());
    if ($tmpFilename eq " ") 
    {
        logInfo(">>>>>>>> logLogInfo failed to create a temporary log file <<<<<<<<");
        return ERROR;
    }

    #
    # tempfile() leaves file open.  close it before calling displayLogInfo
    #
    unless (close $tmpFH)
    { 
        logInfo(">>>>>>>> logLogInfo failed to close temp file $tmpFilename <<<<<<<<");
        return ERROR;
    }

    #
    # call ccbe displayLogInfo and direct the output to a temp log file
    #
    XIOTech::cmdMgr::displayLogInfo(0, $tmpFilename, $mode, $gmt, 1, %info);
    
    #
    # open temp log file.  Pull out each line and put in xtc log file.
    #
    if (open(TMPLOGFILE, $tmpFilename))
    {
        local $_;
        
        logInfo("Log Information:");
        #
        # temporarily set verbose to no header so we don't get all the extra
        # info on every line of the log
        #
        $originalVerboseSetting = $controlTable{verbose}; 
        $controlTable{verbose} = "no header";
        
        #
        # pull each line out of temporary log file and log with logInfo
        #
        while (<TMPLOGFILE>) 
        {
            chomp;
            logInfo($_);        
        }          
        
        #
        # restore verbose to original setting
        #
        $controlTable{verbose} = $originalVerboseSetting; 

        #
        # Close and delete temporary file
        #
        unless (close TMPLOGFILE)
        { 
            logInfo(">>>>>>>> logLogInfo failed to close temp file $tmpFilename <<<<<<<<");
            return ERROR;
        }

        unless (unlink $tmpFilename)
        { 
            logInfo(">>>>>>>> logLogInfo failed to delete $tmpFilename <<<<<<<<");
            return ERROR;
        }
    }
    else 
    {
        logInfo(">>>>>>>> logLogInfo failed to open temp file $tmpFilename <<<<<<<<");
        return ERROR;
    }

    return GOOD;

}


sub logModeDataInfo
{
    trace();
    
    my (%info) = @_;
    my $output;

    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayModeDataInfo(0, %info);

    logInfo($output . "\n");
}

sub logSos
{
    trace();
    
    my (%info) = @_;
    my $output;

    $output = XIOTech::cmdMgr::displaySos(0, %info);

    logInfo($output . "\n");
}

sub logStatsServer
{
    trace();

    my (%info) = @_;
    my $output;

    debug(_objectList);
    
    $output = XIOTech::cmdMgr::statsServerDisplay(0,  %info);

    logInfo($output . "\n");
}

sub logStatsCacheDevices
{
    trace();

    my ($id, %info) = @_;
    my $output;

    debug("id = $id");


    $output = XIOTech::cmdMgr::statsCacheDevicesDisplay(0, $id, %info);

    logInfo($output . "\n");
}

sub logStatsPCI
{
    trace();

    my ($type, %info) = @_;
    my $output;

    debug("type = $type");
    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::statsPCIDisplay(0, $type, %info);

    logInfo($output . "\n");
}

sub logStatsProc
{
    trace();

    my ($type, %info) = @_;
    my $output;

    debug("type = $type");
    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::statsProcDisplay(0, $type, %info);

    logInfo($output . "\n");
}

sub logStatsLoop
{
    trace();

    my ($type, %info) = @_;
    my $output;

    debug("type = $type");
    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::statsLoopDisplay(0, $type, %info);

    logInfo($output . "\n");
}

sub logScrubInfo
{
    trace();
    
    my (%info) = @_;
    my $output;
    
    debug(_objectList(%info));

    $output = XIOTech::cmdMgr::displayScrubInfo(0, %info);

    logInfo($output . "\n");
}


=head1 AUTHOR

Keith A. House housek@xiotech.com

=head1 CHANGELOG

 $Log$
 Revision 1.1  2005/05/04 18:53:52  RysavyR
 Initial revision

 Revision 1.36  2005/02/15 17:48:14  MenningC
 tbolt00000000: suppress log summary, Reviewed by Al

 Revision 1.35  2004/09/14 20:23:15  MenningC
 tbolt00000000: added fcn to disable revision list at beginning; reviewed by Al

 Revision 1.34  2004/06/16 19:59:33  KohlmeyerA
 Tbolt00000000:  Changed logLogInfo to create temp file in local temp directory
 instead of current directory.  Reviewed by Craig.

 Revision 1.33  2004/06/08 22:11:11  KohlmeyerA
 Tbolt00000000:  Updated some more logging functions to call the ccbe display functions
 instead of repeating similar code. Reviewed by Craig.

 Revision 1.32  2003/11/11 20:26:53  SchibillaM
 TBolt00000000: Add support for FID 300 - VCG Info.

 Revision 1.31  2003/09/10 13:26:52  MenningC
 tbolt00000000: fix ictest menu, undace configs for n-way, improve 1 way support. reviewed by Olga

 Revision 1.30  2003/08/14 21:01:30  MenningC
 tbolt00000000: add timestamps for Tim. reviewed by Eric

 Revision 1.29  2003/06/03 19:47:36  MenningC
 TBOLT00000000: Changed many of the 'display' functions in the CCBCL to fill a string rather than print to the screen. The test scripts can now use these functions. Reviewed by Jeff W.

 Revision 1.28  2003/05/06 20:18:26  TeskeJ
 tbolt00008227 - scrubbing changes
 rev by Craig

 Revision 1.27  2003/04/08 18:47:02  MenningC
 tbolt00000000: suppress printing of library versions as script exits ; reviewed by JW

 Revision 1.26  2003/03/26 21:24:53  WerningJ
 Removed calls to unused modules
 Reviewed by Craig M

 Revision 1.25  2003/01/15 06:00:32  McmasterM
 TBolt00006728: Power supply failures no longer appear in logs
 TBolt00006673: Create startup hardware report (partial completion)
 Made changes to be more verbose on the monitor log messages.

 Revision 1.24  2003/01/07 20:17:12  McmasterM
 TBolt00006501: Add XCI gathering of PS Interface board data
 TBolt00006492: I2C monitor asserting error on boards without PCA9548 switch

 Revision 1.23  2002/12/23 19:40:52  MenningC
 Tbolt00000000: fixed a whole bunch of missing s letters on (s)printf; reveiwed by Max

 Revision 1.22  2002/12/18 22:07:46  McmasterM
 TBolt00006250: Add support for I2C switch device
 TBolt00006251: Add support for new I2C EEPROMs (component info collection)
 Full switch support and nearly all of the EEPROM support is in place.

 Revision 1.21  2002/12/18 21:54:45  McmasterM
 TBolt00006250: Add support for I2C switch device
 TBolt00006251: Add support for new I2C EEPROMs (component info collection)
 Full switch support and nearly all of the EEPROM support is in place.

 Revision 1.20  2002/12/11 22:04:11  MenningC
 tbolt00000000 fix up for M870 changes reveiewed by J Werning

 Revision 1.19  2002/12/06 21:10:59  MenningC
 TBOLT00000000: changes to handle the loss of default servers.
  reviewed by J Werning

 Revision 1.18  2002/12/05 15:31:14  MenningC
 TBOLT00000000: changes to accomodate product hash changes. reviewed by J Werning

 Revision 1.17  2002/11/21 22:01:17  MenningC
 tbolt00000000: fix for pdiskinfo structure changes, reviewed by J Werning

 Revision 1.16  2002/10/08 20:34:09  MenningC
 tbolt00000000 changes for defrag test and prequal scripts. Reviewed by JT

 Revision 1.15  2002/09/16 14:56:27  MenningC
 tbolt00000000 cmore changes
 ; reviewed by J Werning

 Revision 1.14  2002/09/12 19:42:28  WerningJ
 Added controll option to not output to stdout
 reviewed by Craig

 Revision 1.13  2002/09/10 19:35:54  MenningC
 tbolt00000000 support for controller data collection, reviewed by Jeff Werning

 Revision 1.12  2002/09/05 17:52:35  SchibillaM
 TBolt00005858: Correct problems in logEnvironmentalStats.
 Reviewed by Craig.

 Revision 1.11  2002/09/03 14:36:34  SchibillaM
 TBolt00005858: Changes to CCBCL files to allow a subset of function to be built
 for field use.  The tool BuildCCBCLSubset.pl builds the subset.  These changes
 also remove ENVSTATS which is replaced by STATSENV.
 Reviewed by Randy and Craig.

 Revision 1.10  2002/08/02 01:44:55  HouseK
 Added or corrected some POD (perldoc)

 Revision 1.9  2002/08/01 20:25:01  HouseK
 Update logDeviceStatus to a change in displayDeviceStatus
 in particular to the RD device

 Revision 1.8  2002/07/31 19:44:19  HouseK
 Result of merge from tag LOGGING_CHANGES

 Revision 1.7.2.10  2002/07/31 17:55:41  HouseK
 Additional cleaning up of the format of some of the logging functions

 Revision 1.7.2.9  2002/07/29 21:14:22  HouseK
 Fixed another problem with _objectList.
 Empty arrays were returning undef in _arrayDump
 Fixed bug in logDeviceStatus with an undefined parameter

 Revision 1.7.2.8  2002/07/29 17:53:14  HouseK
 Fixed problem with _objectList.  Added logScrubInfo.

 Revision 1.7.2.7  2002/07/28 19:07:47  MenningC
 Tbolt00000000 continued changes for logging

 Revision 1.7.2.6  2002/07/27 18:01:59  HouseK
 Undefined hash key values are debug messages instead of logWarnings

 Revision 1.7.2.5  2002/07/26 22:20:51  HouseK
 logInfo, logWarning, and logError will fail compilation if they are not called
 with a message
 Fixed logObjectList to generically dump out a hash of anything.

 Revision 1.7.2.4  2002/07/26 16:22:22  HouseK
 Removed tabs

 Revision 1.7.2.3  2002/07/26 01:36:29  HouseK
 Added an accidentally removed export

 Revision 1.7.2.2  2002/07/26 01:12:18  HouseK
 Added more display functions

 Revision 1.7.2.1  2002/07/25 19:27:27  HouseK
 Removed DOS eols

 Revision 1.7  2002/07/24 19:30:49  HouseK
 added display functions as log functions

 Revision 1.6  2002/07/22 20:04:23  HouseK
 Aligned and padded more of the formatting.
 Forcing a message to be used on the log commands.

 Revision 1.5  2002/07/22 17:30:49  HouseK
 Removed references to XTC.

 Revision 1.4  2002/07/22 17:19:14  HouseK
 A check in to expand keywords.

 Revision 1.3  2002/07/22 17:17:05  HouseK
 Added verbose option to turn off timestamps so interactive scripts look better.
 timestamp has a consistent size.

 Revision 1.2  2002/07/19 01:05:50  HouseK
 *** empty log message ***

 Revision 1.1  2002/07/18 19:26:00  HouseK
 Initial check in


=cut
