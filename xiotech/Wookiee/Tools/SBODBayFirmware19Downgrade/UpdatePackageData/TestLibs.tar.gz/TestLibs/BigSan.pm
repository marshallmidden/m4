#! /usr/bin/perl s
# $Header$
####s##########################################################################
#  
#   CCBE Integration test library - San Test functions
#
#   12/10/2002  XIOtech   Craig Menning
#
#   A set of library functions for integration testing. This set supports
#   testing of larger SAN configuration.
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002 XIOtech
#
#   For XIOtech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::BigSan  - library for testing SANs

$Id: BigSan.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This file covers functions specifically written for testing large SANs.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones
              
        The less significant ones

=cut


#                         
# - what I am
#

package TestLibs::BigSan;

#
# - other modules used
#

use warnings;
#use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

#use XIOTech::cmdMgr;
#use XIOTech::cmUtils;
#use XIOTech::constants;
#use XIOTech::errorCodes;
#use XIOTech::xiotechPackets;
#use XIOTech::PI_CommandCodes;
#use XIOTech::logMgr;

use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::utility;
use TestLibs::Configure;
use TestLibs::server;
#use TestLibs::Validate;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - Constants used
#



#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 4298 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point for ...
    # primary entry point for ...

    @ISA         = qw(Exporter);
    @EXPORT      = qw(





                     &DebugSanFunctions


                     &ShutdownAndCycle


                        

                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $serverIP: The IP address of the server. A text string in ###.###.###.###
         notation. 

 $serverName: The name of the server on the network. No leading slashes.

         
 $moxaIP: The IP address of the moxa power commander that the servers
          are attached to.
          
 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller. 

 $moxaChan: A specific channel parameter for the moxa. This is usually
            a single letter. For more simultaneous control, multiple letters
            may be passed. Sending 'A' will change only a single channel. 
            Sending 'AEF' will change the three indicated channels. The 
            parameter is passed directly to the moxapower.exe program and 
            no interpretation is done.      



=back

=cut


###############################################################################

=head2 DebugSanFunctions function

This is an entry for debugging the large san test scripts.


=cut

=over 1

=item Usage:

 my $rc = DebugSanFunctions( TBD );
 
 where: 

=item Returns:

       $rc will be GOOD or ERROR. The logs should be checked on error.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The Server needs to be logged into the XIOcorp domain. 




=back

=cut




##############################################################################
#
#          Name: DebugSanFunctions
#
#        Inputs:  
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description:  
#
##############################################################################
sub DebugSanFunctions
{
    trace();                       
#    my () = @_;
    
    my @servers;
    my @moxaList;
    my @moxaMap;
    
    my $i;
    my $ret;


    ############################################
    #Jim's lab 3
    ############################################
#    print ("###########################################################\n");
#    print ("##                                                       ##\n");
#    print ("##                                                       ##\n");
#    print ("##       Jim's configuration                             ##\n");
#    print ("##                                                       ##\n");
#    print ("##                                                       ##\n");
#    print ("###########################################################\n");

#    @moxaList = ("10.64.99.69","10.64.99.72");
#    @moxaMap = ('FG', 'ABEF');
#    $servers[0]="lab3_server_1";
#    $servers[1]="lab3_server_2";
#    $servers[2]="largesan1";
#    $servers[3]="largesan2";
#    $servers[4]="largesan5";
#    $servers[5]="largesan6";
#
#
#
#    $ret =  ShutdownAndCycle  (\@servers, 
#                               \@moxaList, 
#                               \@moxaMap, 
#                               5, 
#                               30, 
#                               180);



    ###########################################
    # Craig, lab 18
    ###########################################
    print ("###########################################################\n");
    print ("##                                                       ##\n");
    print ("##                                                       ##\n");
    print ("##       Craig's Configuration                           ##\n");
    print ("##                                                       ##\n");
    print ("##                                                       ##\n");
    print ("###########################################################\n");

    @moxaList = ("10.64.99.73","10.64.99.73");
    @moxaMap = ('aB', 'C');
    $servers[0]="lab18A_server_1";
    $servers[1]="lab18B_server_2";
    $servers[2]="qa_server_41";



    $ret =  ShutdownAndCycleXTCTest  (\@servers, 
                               \@moxaList, 
                               \@moxaMap, 
                               15, 
                               10, 
                               90);



    logInfo("  ShutdownAndCycle returned $ret ");


    return GOOD;
}

###############################################################################

=head2 ShutdownAndCycle function

Takes a group of servers, executes a shutdown and then power cycles them.
The number of cycles and the time duration for power on and power off
are user selected.


=cut

=over 1

=item Usage:

 my $rc = ShutdownAndCycle($serverPtr, 
                           $moxaPtr, 
                           $mmapPtr, 
                           $cycles, 
                           $delayOff, 
                           $delayOn);

         where:
           $serverPtr is a pointer to a list of server names
           $moxaPtr is a pointer to a list of moxa IP addresses
           $mmapPtr is a pointer to a list of moxa channels used
           $cycles is the number of cycles to do
           $delayOff is the time from turning off the power to restoring 
                    power to the servers (in seconds)
           $delayOn is the time the power is left on between cycles.
                    (in seconds)
           
           Notes: 
           1. Delays are minimum, loops will add additional delay of 
              several seconds.
           2. The $moxaPtr and $mmapPtr lists are used with the same index.
           3. The server and moxa lists do now need to be the same length.
              All of the entries in the servere list will be shut down. 
              Then all of the moxa entries will be cycled. (The two moxa
              lists do need to be tha same length.  
           4. Script pauses until the servers cease responding to a ping
              for the shutdown.


=item Returns:

       $rc will be GOOD or ERROR. The logs should be checked on error.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The Server needs to be logged into the XIOCorp domain. 




=back

=cut


##############################################################################
#
#          Name: ShutdownAndCycle
#
#        Inputs: several, see POD
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Does a shutdown and power cycle on servers.
#
##############################################################################
sub ShutdownAndCycle
{
    trace();
    my ($serverPtr, $moxaPtr, $mmapPtr, $cycles, $delayOff, $delayOn) =@_;


    my @servers = @$serverPtr;
    my @moxaList = @$moxaPtr;
    my @moxaMap = @$mmapPtr;

    my $i;
    my $j;
    my $cycle;
    my $ret;
    my $pingTimeout;
    my $retPing;

    logInfo("------------- checking for the servers to be available ------------------");

    for ( $i = 0; $i < scalar(@servers); $i++ )
    {
        print "\n";  #Newline in case an error message was returned from the system call
        $retPing = TestLibs::utility::pingWait($servers[$i], 300);    # Ping for 300 seconds
        if ($retPing != GOOD)
        {
            TestLibs::Logging::logInfo ("Server $servers[$i] was not ready before shutdown");
            return ERROR;
        }

    }
    

    for ( $j = 0; $j < $cycles; $j++ )
    {

        $i = $j +1;
        logInfo("------------------------------------  begin loop # $i -----------------------------------");


#        #
#        # ping the servers to make sure they are talking
#        #
#
#        logInfo("------------- checking for the servers to be available -----------------");
#
#        for ( $i = 0; $i < scalar(@servers); $i++ )
#        {
#            print "\n";  #Newline in case an error message was returned from the system call
#            $retPing = TestLibs::utility::pingWait($servers[$i], 300);    # Ping for 300 seconds
#            if ($retPing != GOOD)
#            {
#                TestLibs::Logging::logInfo ("Server $servers[$i] was not ready before shutdown");
#                return ERROR;
#           }
#        }
#

        logInfo("Waiting a while for the servers to (maybe) finish booting");
        DelaySecs(45);

        #
        # send shutdown to the servers
        #

        logInfo("------------- shutting down the servers ----------------------");


        for ( $i = 0; $i < scalar(@servers); $i++ )
        {
            $ret = ServerAction($servers[$i], "shutdown");
            if ( $ret != GOOD)
            {
                logInfo ("Error sending shutdown command to server $servers[$i]");
                return ERROR;
            }
            #DelaySecs(15);
        }

        #
        # allow time to shut down
        #

        logInfo("Giving computers time to shut down");
        DelaySecs(60);

        #
        # check to sse that they have shut down
        #
        
        logInfo("---------------- verifying shutdown state on servers -------------------");


        for ( $i = 0; $i < scalar(@servers); $i++ )
        {
            $pingTimeout = 0;
            $ret = GOOD;

            while ( $ret == GOOD && $pingTimeout < 30 )  # 5 minute timeout
            {
                # note: there is also a time delay in this fcn.
                $ret = ServerAction($servers[$i], "testping");

                if ( $ret == GOOD ) { DelaySecs(5); }

                $pingTimeout++;
            }

            if ( $pingTimeout >= 30 )
            {
                logInfo ("Error: one or more servers did not shut down in the time allowed");
                logInfo ("Server $servers[$i] is still responding to a ping.");
                return ERROR;
            }


        }


        #
        # turn off power on all
        #

        logInfo("----------------- turning off server power --------------------");

        for ( $i = 0; $i < scalar(@moxaList); $i++ )
        {
            logInfo("Remove power on channel $moxaMap[$i] on moxa IP $moxaList[$i] ");
            $ret = TestLibs::IntegCCBELib::PowerChange($moxaList[$i], $moxaMap[$i], 0);
            if ( $ret != GOOD)
            {
                logInfo ("Error powering down servers on channel $moxaMap[$i] on moxa $moxaList[$i].");
                return ERROR;
            }

        }
    
        #
        # off time delay
        #

        logInfo("");
        logInfo("Pause $delayOff seconds with the power OFF.");
        logInfo("");
        DelaySecs($delayOff);

        #
        # restore power to all
        #
        
        logInfo("---------------- Applying power to servers ---------------------");


        for ( $i = 0; $i < scalar(@moxaList); $i++ )
        {
            logInfo("Restore power on channel $moxaMap[$i] on moxa IP $moxaList[$i] ");
            $ret = TestLibs::IntegCCBELib::PowerChange($moxaList[$i], $moxaMap[$i], 1);
            if ( $ret != GOOD)
            {
                logInfo ("Error powering up servers on channel $moxaMap[$i] on moxa $moxaList[$i].");
                return ERROR;
            }

        }


        #
        # now see if they are sufficiently booted,(or wait until they are)
        #

        #
        # Wait for the server to shutdown and then wait for it 
        # to come back up by continuously pinging it.
        #
        
        #
        # on time delay
        #

        logInfo("");
        logInfo("Pause $delayOn seconds with the power ON, computers are rebooting.");
        logInfo("");
        DelaySecs($delayOn);

        logInfo("------------------ Looking for servers to come ready ---------------------");

        DelaySecs(15);   # some guaranteed minimal dalay         
        
        for ( $i = 0; $i < scalar(@servers); $i++ )
        {
            print "\n";  #Newline in case an error message was returned from the system call
            $retPing = TestLibs::utility::pingWait($servers[$i], 300);    # Ping for up to 300 seconds
            if ($retPing != GOOD)
            {
                TestLibs::Logging::logInfo ("Failed waiting for server $servers[$i] to come ready");
                return ERROR;
            }

        }


    }
        
    return GOOD;
    
    

}
###############################################################################

sub ShutdownAndCycleXTCTest
{
    trace();
    my ($serverPtr, $moxaPtr, $mmapPtr, $cycles, $delayOff, $delayOn) =@_;


    my @servers = @$serverPtr;
    my @moxaList = @$moxaPtr;
    my @moxaMap = @$mmapPtr;


    logInfo("##################################");
    logInfo("XTC test:");
    logInfo("  server list: @servers");
    logInfo("  moxa IPs: @moxaList");
    logInfo("  moxa map: @moxaMap");
    logInfo("  test cycles: $cycles");
    logInfo("  Off delay: $delayOff seconds");
    logInfo("  On dealy: $delayOn seconds");
    logInfo("##################################");

    return GOOD;
}













##############################################################################
#
#               Private Functions, but made public for debug
#
##############################################################################



##############################################################################
#
#          Name: Support Functions
#
#  These are probably not exported.
#
##############################################################################

###############################################################################

##############################################################################


1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.1  2005/05/04 18:53:52  RysavyR
# Initial revision
#
# Revision 1.2  2003/03/26 21:24:52  WerningJ
# Removed calls to unused modules
# Reviewed by Craig M
#
# Revision 1.1  2002/12/11 15:24:05  MenningC
# TBOLT00000000: new files for large SAN testing. reveiwed by J. Werning
#
#
#
##############################################################################
