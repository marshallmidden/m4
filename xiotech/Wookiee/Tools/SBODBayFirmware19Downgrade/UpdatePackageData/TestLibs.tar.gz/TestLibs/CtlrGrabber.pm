#! /usr/bin/perl s
# $Header$
##############################################################################
# File name:  TestLibs::CtlrGrabber
#
# Desc: Functions to allow us to grab useful debug information 
#       from a list of controllers.
#
# Date: 09/09/2002
#
# Original Author:  Craig Menning
#
# Last modified by  $Author: ElvesterN $
# Modified date     $Date: 2006-05-25 11:50:29 -0500 (Thu, 25 May 2006) $
#
#   It is expected that the user will write a perl script that calls   
#   these.
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::CtlrGrabber - Perl library to collect debug information

$Id: CtlrGrabber.pm 9787 2006-05-25 16:50:29Z ElvesterN $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS



=head1 DESCRIPTION

 
    

=cut

#                         
# - what I am
#

package TestLibs::CtlrGrabber;

#
# - other modules used
#

use warnings;
use lib "../CCBE";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use XIOTech::CmdCodeHashes;


#
# - other modules used
#

use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :GRABBER);
use TestLibs::BEUtils;
use TestLibs::dumpDecode;
use XIOTech::TracDec;
use XIOTech::decodeRings;
use XIOTech::decodeSupport;


#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

# constants


######################################

#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      
                      &CtlrLogText
                      
                      &GetMyLicense
                      &GetPowerUpState
                      &GimmieLicense
                      &GrabControllerData

                      &ViewLicenseState







                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 9787 $);
}
    our @EXPORT_OK;




########################################################################
######################### Public Functions #############################
########################################################################







###############################################################################

=head2 GrabControllerData function

This function get the requested data from each supplied controller. This
data is output to the screen and a log file. The data to be collected is 
specified in a list and woll be processed in the order listed. (There 
may be some additional information in the log files from the running
of this script.)

=cut

=over 1

=item Usage:

 my $rc = GrabControllerData( $coPtr. $dlPtr);
 
 where $coPtr is a pointer to a list of comtroller objects
       $dlPtr is a pointer to the list of data items to be collected

=item Returns:

       GOOD on success, ERROR if the requests could not be completed.
       There may also be error messages in the result file.

=item Description:
 
 Based upon the data list, collect and log the following data:
     
        ALLITEMS             does all of the items below

        ALLVERS              FW and BE device version info 

        DEVSTATUS            Displays device status information.
        ENVSTATS             Displays environmental statistics.
        FWVERSION            Displays firmware version information.
                             Also includes
                                POWERUPSTATE         Display the power-up state of this controller.
                                VCGINFO              Displays virtual controller group information.

        GENFUNCTION          Call PI_GenFunction with passed in parameters.
        GENMRP               Issue a generic MRP.
        GETREPORT            Retrieves various debug reports.

        SOSTABLE             Retrieve and print an SOS table.

        GLOBALCACHEINFO      Displays global cache information.

        LOGINFO              Displays the last N log messages.

        NVRAMREAD            Read NVRAM and dump it to a file.
        MEMREAD              Read memory on specified processor.
        FIDREAD              Read the specified file ID.

        STRUCTUREINFO        Displays a strucure from the CCB.

        MODEBITINFO          Displays mode bits.

        NETSTAT              Prints active TCP socket connection data (same as STRUCTUREINFO 2).

        SNMPPROPERTIES       Set or Get SNMP trap addresses on the ccb.

        PDISKS               Displays physical disk information for all physical disks.
                             Also includes
                                PDISKCOUNT           Displays the number of physical disks.
                                PDISKINFO            Displays physical disk information.
                                PDISKLIST            Displays a list of physical disk identifiers.

        DISKBAYS             Displays disk bay information for all disk bays.
                             Also includes
                                DISKBAYCOUNT         Displays the number of disk bays bypass cards.
                                DISKBAYLIST          Displays a list of disk bay identifiers.
                                DISKBAYINFO          Displays disk bay information.
                                DISKBAYSTATUS        Displays diskbays and associated PDisks.

        DEVICELIST           Displays the devices on the specified channel
        PORTLIST             List of ports (fibre channel adapters) on the front or back end
        BEDEVICEPATHS        Lists the Backend Device Paths

        SCRUBINFO            Displays the scrubbing information.

        SERIALNUMBERS        Displays the serial numbers for this controller.

        SERVERS              Displays server information for all servers.
                             Also includes
                                SERVERCOUNT          Displays the number of servers.
                                SERVERINFO           Displays server information.
                                SERVERLIST           Displays a list of servers identifiers.
        SERVERLOOKUP         Find a Server ID from a WWN and Target ID.

        STATSALL             includes the following:
                                STATSCACHEDEV        Displays statistics for a cache device.
                                STATSLOOP            Displays statistics for back end loop.
                                STATSPCI             Displays statistics for back end PCI.
                                STATSPROC            Displays statistics for back end proc.
                                STATSSERVER          Displays statistics for a server.
                                STATSVDISK           Displays statisitcs for virtual disks.
                                STATSENVIRONMENTAL   Displays environmental statistics.


        SNAPREADDIR          Read the snapshot directory.
        TARGETS              Displays target information for all targets.
                             Also includes
                                TARGETSTATUS         Displays the status of targets.
                                TARGETCOUNT          Displays the number of targets.
                                TARGETINFO           Displays target information.
                                TARGETLIST           Displays a list of target identifiers.
        TARGETRESLIST        Displays a list of resources associated with a Target ID.


        VCGELECTIONSTATE     Displays the state of an election.

        VDISKS               Displays virtual disk information for all virtual disks.
                             Also includes
                                VDISKINFO            Displays virtual disk information.

        VDISKCOUNT           Displays the number of virtual disks.
        VDISKLIST            Displays a list of virtual disk identifiers.
        VDISKOWNER           Displays the owners of a virtual disk.

        RAIDS                Displays raid information for all raids.
                             Also includes
                                RAIDCOUNT            Displays the number of raid devices.
                                RAIDLIST             Displays a list of raid device identifiers.
                                RAIDINFO             Displays raid information.


        VLINKCTRLCOUNT       Displays the count of remote controllers.
        VLINKCTRLINFO        Displays the information for a remote controller.
        VLINKCTRLVDISKS      Displays the virtual disks of a remote controller.
        VLINKINFO            Displays the information of a virtual link.

    
        CCBBACKTRACE




=back

=cut


##############################################################################
#
#          Name: GrabControllerData
#
#        Inputs: $cpPTr, $dlPtr
#
#       Outputs: GOOD or ERROR 
#
#  Globals Used: none, but uses many constants
#
#   Description: For each controller in the list, loop through the data
#                list and get the requested information from the 
#                controllers. Collect as much data as is possible, returning
#                ERROR is any request cannot be met.
#
#                
#
##############################################################################
sub  GrabControllerData
{
    trace();
    my ($coPtr, $dlPtr) = @_;

    my @coList;
    my @dataList;

    my $i;
    my $j;

    my $ctlr;
    my $item;

    my $ctlrCnt;
    my $dlCnt;

    my $ret;
    my $retFlag;
    my $retFlag2;

    my %rsp;

    my $errorCount;
    my $errorCount2;


    # convert pointers to arrays/lists
    @coList = @$coPtr;
    @dataList = @$dlPtr;

    $ctlrCnt = scalar(@coList);
    $dlCnt = scalar(@dataList);

    # init some other vars
    $retFlag = GOOD;
    $retFlag2 = GOOD;
    $errorCount2 = 0;

    # Say hello to the world...

    logInfo("");
    logInfo("##################################################################");
    logInfo("##################################################################");
    logInfo("                  Controller Information Dump");
    logInfo("##################################################################");
    logInfo("##################################################################");


    # loop through each controller in the list

    for ( $i = 0; $i < $ctlrCnt; $i++)
    {
        $ctlr = $coList[$i];

        # ID this contoller to the world
        logInfo("-----------------------------------------------------------------");
        logInfo("                  data for controller # ".$i);
        logInfo("-----------------------------------------------------------------");

        $errorCount = 0;

        # face it, we really need the serial numbers here, so do a VCGINFO now

        $ret = DispVcgInfo($ctlr);

        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting vcg information and serial numbers <<<<<<");
            $retFlag = ERROR;
            $errorCount++;
            $errorCount2++;
        }

        # now loop through the list of data items and get the info

        for ( $j = 0; $j < $dlCnt; $j++ )
        {
            # check each possible data item and do it if needed
            # this is gonna be ugly

            $ret = CollectSomeData($ctlr, $dataList[$j]);
            if ( $ret != GOOD )
            {
                $retFlag = ERROR;
                $errorCount++;
                $errorCount2++;
            }
        }

        logInfo("####################################################################");

        if ( $retFlag != GOOD )
        {
            $retFlag2 = ERROR;
            logInfo("      There were errors collecting data from this controller.");
            logInfo("          ".$errorCount." errors were recorded.");
        }
        else
        {
            logInfo("          All data collected successfully.");
        }

        logInfo("####################################################################");

        # go back and do the next controller
    }
    
    logInfo("   A total of ".$errorCount2." errors were recorded while collecting data.");

    if ( $errorCount2 != 0 )
    {
        print("\n---->  A total of ".$errorCount2." errors were recorded while collecting data.\n");
        print(  "---->  You may want to review the output file to see what data was missed.\n");
        print(  "---->  It may be possible to get the controller to a state where all the data \n");
        print(  "---->  can be collected. \n\n");
    } 
    return GOOD;
}


##############################################################################
#
#          Name: GetSerial
#
#        Inputs: controller
#
#       Outputs: INVALID in unable to get sn, otherwise the controller's sn
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################
sub GetSerial
{
    trace();
    my ($ctlr) = @_;

    my %rsp;

    %rsp = $ctlr->serialNumGet();

    if ( ! %rsp  )
    {
        logError("Controller timed out while getting serial number");
        return INVALID;
    }
    else
    {
        if ( $rsp{STATUS} == PI_GOOD )
        {
 
            debug("serialnumber :", %rsp, "\n",$rsp{2}{SERIAL_NUM}," \n" ,$rsp{1}{SERIAL_NUM} ," \n");
            return  $rsp{1}{SERIAL_NUM};

        }
        else
        {
            # we don't want to pause on this one.
            logInfo("Controller returned error while reading serial number");
            PrintError(%rsp);
            return INVALID;
        }
    }
}



##############################################################################
#
#          Name: GetMyLicense
#
#        Inputs: controller object, ip addr, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Checks  controller for a license, if none will
#                give it a license for itself.   
#
#
##############################################################################
sub GetMyLicense
{
    trace();
    my ( $ctlr, $ipAddr, $option) = @_;      

    my $i;
    my $state;
    my @coList;
    my @ipList;
    my @serialNums;
    my $sn;
    my @ipParts;
    my %rsp;

    $state = GetPowerUpState ($ctlr );

    if ($state == POWER_UP_COMPLETE )
    {
        # controller has a license, good enough for us
        return GOOD;
    }
    else
    {
        # master is without a license. Need to get ALL serial numbers
        # and put them into an array, Then apply the license.

        # get the serial number

        $sn = GetSerial( $ctlr );
        if ( $sn == INVALID )
        {
            return ERROR;
        }

        # add to array

        push ( @serialNums, $sn );


        # now get the group name. If we have an IP address, use it for
        # the group name. If no IP address, we just use the serial 
        # number for the controller.

        if ($ipAddr)
        {
            @ipParts = split( /\./, $ipAddr);

            logInfo("The server SNs: @serialNums");
            logInfo("The ip addr ($ipAddr) parts: @ipParts");

            # now the fcn call
        
            $sn =  $ipParts[3];

        }
        logInfo("Using group SN: $sn");

        %rsp = $ctlr->vcgApplyLicense( $sn, \@serialNums);

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from vcgApplyLicense <<<<<<<<");
            return INVALID;
        }
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to apply License. <<<<<<<<");
            PrintError(%rsp);
            return INVALID;
        }


    }
    return GOOD;

}


##############################################################################
#
#          Name: GimmieLicense
#
#        Inputs: ptr to controller object list, ptr to ip addr list, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Checks first controller for a license, if none will
#                give it a license for all controllers in the list. (First
#                one is the master, rest are slaves.)   
#
#
##############################################################################
sub GimmieLicense
{
    trace();
    my ( $coPtr, $ipPtr, $option) = @_;      

    my $i;
    my $state;
    my @coList;
    my @ipList;
    my $obj;
    my @serialNums;
    my $sn;
    my @ipParts;
    my %rsp;

    @coList = @$coPtr;
    @ipList = @$ipPtr;

    $state = GetPowerUpState ($coList[0] );

    if ($state == POWER_UP_COMPLETE )
    {
        # master has a license, good enough for us
        return GOOD;
    }
    else
    {
        # master is without a license. Need to get ALL serial numbers
        # and put them into an array, Then apply the license.

        for ( $i = 0; $i < scalar(@coList); $i++ )
        {
            # get the serial number

            $sn = GetSerial( $coList[$i] );
            if ( $sn == INVALID )
            {
                return ERROR;
            }

            # add to array

            push ( @serialNums, $sn );

        }

        # now get the group name

        #    @Select_Server_ID = split(/ /, $Server_IDs);
        
        @ipParts = split( /\./, $ipList[0]);

        logInfo("The server SNs: @serialNums");
        # logInfo("The ip addr ($ipList[0]) parts: @ipParts");

        $sn =  $ipParts[3];        # save master ip part

        if ( $ipList[1] )
        {
            @ipParts = split( /\./, $ipList[1]);

            #logInfo("The server SNs: @serialNums");
            #logInfo("The ip addr ($ipList[1]) parts: @ipParts");

            $sn =  $sn * 1000 + $ipParts[3];  # add slave ip part
        }

        # now the fcn call
        
        $obj = $coList[0];


        logInfo("Using group SN: $sn");

        %rsp = $obj->vcgApplyLicense( $sn, \@serialNums);

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from vcgApplyLicense <<<<<<<<");
            return INVALID;
        }
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to apply License. <<<<<<<<");
            PrintError(%rsp);
            return INVALID;
        }


    }
    return GOOD;

}

##############################################################################
#
#          Name: CtlrLogText
#
#        Inputs: controller object, test message(scalar string)
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: puts a message in the controller logs   
#
#
##############################################################################
sub CtlrLogText
{
    trace();
    my ($ctlr, $msg) = @_;

    my %rsp = $ctlr->logTextMessage($msg);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo("Log message sent successfully.");
        }
        else
        {
            logInfo(">>>>>>>> Failed to log the message  <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }
    else
    {
        logInfo(">>>>>>>> No response logging a message  <<<<<<<<");
        return ERROR;
    }

    return GOOD;
}



##############################################################################
#
#          Name: FirmwareVer
#
#        Inputs: Controller object list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Gets poweronstate and vcginfo on all controllers   
#
#
##############################################################################
sub FirmwareVer
{
    trace();

    my ( $ctlr ) = @_;

    my $ret;
    my %rsp;
    my $ccbVer;
    my $machAddr;

    logInfo("################ Viewing firmware versions #################### ");
           
    #####################
    #  Firmware Version
    #####################
    #logInfo("");
    debug("Testing firmware version operations... ");

    %rsp = $ctlr->fwVersion();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from fwVersion <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from fwVersion <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logFirmwareVersion(%rsp);

    # now get the mach version for the CCB

    ##########################################
    #
    #  this logic duplicated in CCBETrace()
    #
    #  DUAL MAINTENANCE!!!!
    #
    ##########################################


    $ccbVer = FW_VER_CCB_RUNTIME;

    $ccbVer =  $rsp{$ccbVer}{REVISION};


    if ( ( $ccbVer ge "M000" ) && ($ccbVer le "MZZZ" ) && ($ccbVer lt "M810" ) )
    {
        # the older mach address
        $machAddr = 0xFEF80003;
    }
    else
    {
        # the newer mach address
        $machAddr = 0xFEE80003;
    }



    # Go get the mach code levels (hack for now, until we change the 
    # way that fw levels are retrieved from the proc).
    if(1) 
    {
        my $revRaw;
        my $revCooked;
        my %data = $ctlr->ReadMemory($machAddr, 1, "CCB");
        if($data{STATUS} != 0) {
            logInfo("\nCouldn't read CCB Mach revision...\n");
        }
        else {
            $revRaw = unpack("C", $data{RD_DATA}) & 0xF;
            $revCooked = "?";
            $revCooked = "old"   if ($revRaw == 0x2);
            $revCooked = "rev A" if ($revRaw == 0x3);
            logInfo(sprintf( "CCB_MACH    %X (%s)\n", $revRaw, $revCooked));
        }
    
        %data = $ctlr->ReadMemory(0xFE400003, 1, "BE");
        if($data{STATUS} != 0) {
            logInfo( "\nCouldn't read BE Mach revision...\n");
        }
        else {
            $revRaw = unpack("C", $data{RD_DATA}) & 0xFF;
            $revCooked = "?";
            $revCooked = "5" if ($revRaw == 0x9);
            $revCooked = "6" if ($revRaw == 0xA);
            $revCooked = "A" if ($revRaw == 0xB);
            logInfo(sprintf ("BE_MACH     %X (rev %s)\n", $revRaw, $revCooked));
        }
    
        %data = $ctlr->ReadMemory(0xFE400003, 1, "FE");
        if($data{STATUS} != 0) {
            logInfo( "\nCouldn't read FE Mach revision...\n");
        }
        else {
            $revRaw = unpack("C", $data{RD_DATA}) & 0xFF;
            $revCooked = "?";
            $revCooked = "5" if ($revRaw == 0x9);
            $revCooked = "6" if ($revRaw == 0xA);
            $revCooked = "A" if ($revRaw == 0xB);
            logInfo(sprintf( "FE_MACH     %X (rev %s)\n", $revRaw, $revCooked));
        }
    
        logInfo( "-" x 22 . "\n");
    }




    logInfo("Completed testing firmware version operations");

    # get the powerupstate

    $ret = GetPowerUpState($ctlr);

    # do VCGInfo

    $ret = DispVcgInfo($ctlr ); 

    #

    return GOOD;

}




########################################################################
######################## Private Functions #############################
########################################################################



###############################################################################

=head2 CollectSomeData function

This function gets the requested data from the controller. This
data is output to the screen and a log file. 

=cut

=over 1

=item Usage:

 my $rc = CollectSomeData( $ctlr. $item);
 
 where $ctlr is a pointer to the comtroller object
       $item is the item to be collected

=item Returns:

       GOOD on success, ERROR if the request could not be completed.
       There may also be error messages in the result file.

=item Description:
 
 Figure out which item is being requested and call the functions
 to do so. (Basically a big switch statement.)
     





=back

=cut


##############################################################################
#
#          Name: CollectSomeData
#
#        Inputs: $ctlr, $item
#
#       Outputs: GOOD or ERROR 
#
#  Globals Used: none, but uses many constants
#
#   Description: Identify the data item to be collected and get it
#
#                
#
##############################################################################
sub  CollectSomeData
{

    trace();
    my ($ctlr, $item) = @_;
    
    my $ret;
    my %rsp;
    
# Look-up table to associate a label with a section of output in the dump file. 
my %itemTable;

$itemTable{ALLITEMS}            = "All_Items";
$itemTable{DEVSTATUS}           = "Device_Status";
$itemTable{FWVERSION}           = "Firmware_Versions";
$itemTable{SOSTABLE}            = "SOS_Table";
$itemTable{GLOBALCACHEINFO}     = "Global_Cache_Info";
$itemTable{LOGINFO}             = "Log_Info";
$itemTable{NVRAMREAD}           = "NVRAM_Read";
$itemTable{STRUCTUREINFO}       = "Structure_Info";
$itemTable{MODEBITINFO}         = "Mode_Bit_Info";
$itemTable{PDISKS}              = "Physical_Disks";
$itemTable{DISKBAYS}            = "Disk_bays";
$itemTable{DEVICELIST}          = "Device_List";
$itemTable{PORTLIST}            = "Port_List";
$itemTable{BEDEVICEPATHS}       = "Back_End_Device_Paths";
$itemTable{SCRUBINFO}           = "Scrub_Info";
$itemTable{SERIALNUMBERS}       = "Serial_Numbers";
$itemTable{SERVERS}             = "Servers";
$itemTable{STATSALL}            = "All_Statistics";
$itemTable{TARGETS}             = "Targets";
$itemTable{TARGETSTATUS}        = "Target_Status";
$itemTable{TARGETRESLIST}       = "Target_Resource_List";
$itemTable{VCGINFO}             = "VCG_Info";
$itemTable{VDISKS}              = "Virtual_Disks";
$itemTable{VDISKCOUNT}          = "Virtual_Disk_Count";
$itemTable{VDISKLIST}           = "Virtual_Disk_List";
$itemTable{VDISKOWNER}          = "Virtual_Disk_Owner";
$itemTable{RAIDS}               = "RAIDS";
$itemTable{VLINKCTRLCOUNT}      = "Virtual_Link_Controller_Count";
$itemTable{VLINKCTRLINFO}       = "Virtual_Link_Controller_Info";
$itemTable{VLINKCTRLVDISKS}     = "Virtual_Link_Controller_VDisks";
$itemTable{VLINKINFO}           = "Virtual_Link_Info";
$itemTable{CCBBACKTRACE}        = "CCB_Back_Trace";
$itemTable{BEDVERSION}          = "Back_End_Device_Firmware_Versions";
$itemTable{BEDCHECK}            = "Back_End_Device_Configuration";
$itemTable{PROCDATA}            = "Proc_data";
$itemTable{ALLVERS}             = "All_Firmware_Versions";
$itemTable{ENVSTATS}            = "Environmental_Statistics";
$itemTable{GENFUNCTION}         = "Generic_Function";
$itemTable{GENMRP}              = "Generic_MRP";
$itemTable{GETREPORT}           = "Get_Report";
$itemTable{MEMREAD}             = "Memory_Read";
$itemTable{FIDREAD}             = "FID_Read";
$itemTable{SNMPPROPERTIES}      = "SNMP_Properties";
$itemTable{SERVERLOOKUP}        = "Server_Lookup";
$itemTable{SNAPREADDIR}         = "Snapshot_Address_Directory";
$itemTable{VCGELECTIONSTATE}    = "VCG_Election_State";
$itemTable{ACTIVESERVERLIST}    = "Active_Server_List";
$itemTable{TARGETMAP}           = "Target_Map";
$itemTable{INITIALVDISKS}       = "Initial_Virtual_Disks";
$itemTable{SERIALNUMBERS2}      = "Serial_Numbers_2";
$itemTable{PDISKDATA}           = "Physial_Disk_Data";
$itemTable{VDISKDATA}           = "Virtual_Disk_Data";
$itemTable{RAIDDATA}            = "RAID_Data";

#    printf ("CollectSomeData - item=%s  itemTable[$item]=%s\n", 
#            $item, $itemTable{$item});
#
#    printf ("  itemTable[0]=%s  itemTable[1]=%s\n", 
#            $itemTable{FWVERSION}, $itemTable{CCBBACKTRACE});


    # Create a tag for each item that looks like a C function.  This
    # will allow each section to be found easily using the Outline
    # view in CodeWright.
#    my $itemName = "undefined";
    
#    if (defined ( $itemTable{$item} ))
#    {
#        $itemName = $itemTable{$item};
#    }   

    # need to convert item to a string (lookup table) 
#    logInfo("\nvoid $itemName( ) \n{\n}\n");
    
     
    ######################## VCGINFO ###############################
    if ( ($item == VCGINFO) || ($item == ALLITEMS) )
    {
        $ret = DispVcgInfo($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting VCG info data. <<<<<<");
            return ERROR;
        }
    }

    ######################## FWVERSION ########################
    if ( ($item == FWVERSION) || ($item == ALLITEMS) )
    {
        $ret = FirmwareVer($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting firmware version data. <<<<<<");
            return ERROR;
        }
    }

    ######################## VDISKS ###############################
    if (  ($item == VDISKS) || ($item == ALLITEMS) )
    {
        $ret = DispVdiskInfo($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting vdisks data. <<<<<<");
            return ERROR;
        }
    }

    ######################## DEVSTATUS ###############################
    if ( ($item == DEVSTATUS) || ($item == ALLITEMS) )
    {
        $ret = DeviceStatus($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting DEVSTAT data. <<<<<<");
            return ERROR;
        }
    }

    ######################## TARGETSTATUS ###############################
    if ( ($item == TARGETSTATUS) || ($item == ALLITEMS) )
    {
        $ret = TargetList($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting TargetStatus data. <<<<<<");
            return ERROR;
        }
    }

    ######################## DISKBAYS ###############################
    if ( ($item == DISKBAYS) || ($item == ALLITEMS) )
    {
        $ret = DiskBayCommands($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting DiskBay data. <<<<<<");
            return ERROR;
        }
    }

    ######################## PORTLIST ###############################
    if ( ($item == PORTLIST) || ($item == ALLITEMS) )
    {
        $ret = PortList($ctlr, "FE");
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting FE PORTLIST data. <<<<<<");
            return ERROR;
        }
        $ret = PortList($ctlr, "BE");
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting BE PORTLIST data. <<<<<<");
            return ERROR;
        }
    }

    ######################## DEVICELIST ###############################
    if ( ($item == DEVICELIST) || ($item == ALLITEMS) )
    {
        $ret = DeviceList($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting DEVICELIST data. <<<<<<");
            return ERROR;
        }
    }

    ######################## LOGINFO ###############################
    if ( ($item == LOGINFO) || ($item == ALLITEMS) )
    {
        $ret = LoggingTest($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting LOGINFO data. <<<<<<");
            return ERROR;
        }
    }

    ######################## STATSALL ###############################
    if ( ($item == STATSALL) || ($item == ALLITEMS) )
    {
        $ret = StatsCommands($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting statistics data. <<<<<<");
            return ERROR;
        }
    }

    ######################## SERIALNUMBERS ###############################
    if ( ($item == SERIALNUMBERS) || ($item == ALLITEMS) )
    {
        $ret = GetGroupSerial($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting SERIALNUMBERS data. <<<<<<");
            return ERROR;
        }
    }

    ######################## NVRAMREAD ###############################
    if ( ($item == NVRAMREAD) || ($item == ALLITEMS) )
    {
        $ret = DoNVRAM($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting NVRAMREAD data. <<<<<<");
            return ERROR;
        }
    }

    ######################## TARGETS ###############################
    if ( ($item == TARGETS) || ($item == ALLITEMS) )
    {
        $ret = TargetCommands($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting TARGETS data. <<<<<<");
            return ERROR;
        }
    }

    ######################## PDISKS ###############################
    if ( ($item == PDISKS) || ($item == ALLITEMS) )
    {
        $ret = PhysicalDiskCommands($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting PDISK data. <<<<<<");
            return ERROR;
        }
    }

    ######################## SERVERS ###############################
    if ( ($item == SERVERS) || ($item == ALLITEMS) )
    {
        $ret = ServerCommands($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting SERVERS data. <<<<<<");
            return ERROR;
        }
    }

    ######################## BEDEVICEPATHS ###############################
    if ( ($item == BEDEVICEPATHS) || ($item == ALLITEMS) )
    {
        $ret = BeDevPaths($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting BEDEVICEPATHS data. <<<<<<");
            return ERROR;
        }
    }

    ######################## RAIDS ###############################
    if ( ($item == RAIDS) || ($item == ALLITEMS) )
    {
        $ret = RaidCommands($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting RAIDS data. <<<<<<");
            return ERROR;
        }
    }

    ######################## STRUCTUREINFO ###############################
    if ( ($item == STRUCTUREINFO) || ($item == ALLITEMS) )
    {
        $ret = StructInfo($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting STRUCTUREINFO data. <<<<<<");
            return ERROR;
        }
    }

    ######################## MODEBITINFO ###############################
    if ( ($item == MODEBITINFO) || ($item == ALLITEMS) )
    {
        $ret = ModeBits($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting MODEBITINFO data. <<<<<<");
            return ERROR;
        }
    }

    ######################## GLOBALCACHEINFO ###############################
    if ( ($item == GLOBALCACHEINFO) || ($item == ALLITEMS) )
    {
        $ret = GlobCacheInfo($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting GLOBALCACHEINFO data. <<<<<<");
            return ERROR;
        }
    }

    ######################## SOSTABLE ###############################
    if ( ($item == SOSTABLE) || ($item == ALLITEMS) )
    {
        $ret = SosTables($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting SOSTABLE data. <<<<<<");
            return ERROR;
        }
    }

    ######################## CCBBACKTRACE ###############################
    if ( ($item == CCBBACKTRACE) || ($item == ALLITEMS) )
    {
        $ret = CcbTrace($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting CCBBACKTRACE data. <<<<<<");
            return ERROR;
        }
    }

    ######################## GETREPORT ###############################
    if ( ($item == GETREPORT) || ($item == ALLITEMS) )
    {
        $ret = GetReports($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting GETREPORT data. <<<<<<");
            return ERROR;
        }
    }

    ######################## BEDVERSION ###############################
    if ( ($item == BEDVERSION) || ($item == ALLITEMS) )
    {
        $ret = BedVersion($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting BEDVERSION data. <<<<<<");
            return ERROR;
        }
    }

    ######################## BEDCHECK ###############################
    if ( ($item == BEDCHECK) || ($item == ALLITEMS) )
    {
        $ret = BedCheck($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting BEDCHECK data. <<<<<<");
            return ERROR;
        }
    }

    ######################## PROCDATA ###############################
    if ( ($item == PROCDATA) || ($item == ALLITEMS) )
    {
# the directory is broken in 801
        $ret = ProcData2($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting PROCDATA data. <<<<<<");
            return ERROR;
        }
    }


    ######################## ALLVERS ###############################
    if ( ($item == ALLVERS) || ($item == ALLITEMS) )
    {
        $ret = GetAllVersions($ctlr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>> Error getting GetAllVersions data. <<<<<<");
            return ERROR;
        }
    }


###    ######################## WHATEVER ###############################
###    if ( ($item == WHATEVER) || ($item == ALLITEMS) )
###    {
###        $ret = GetWHATEVER($ctlr);
###        if ( $ret != GOOD )
###        {
###            logInfo(">>>>>> Error getting WHATEVER data. <<<<<<");
###            return ERROR;
###        }
###    }


###    ######################## WHATEVER ###############################
###    if ( ($item == WHATEVER) || ($item == ALLITEMS) )
###    {
###        $ret = GetWHATEVER($ctlr);
###        if ( $ret != GOOD )
###        {
###            logInfo(">>>>>> Error getting WHATEVER data. <<<<<<");
###            return ERROR;
###        }
###    }


###    ######################## WHATEVER ###############################
###    if ( ($item == WHATEVER) || ($item == ALLITEMS) )
###    {
###        $ret = GetWHATEVER($ctlr);
###        if ( $ret != GOOD )
###        {
###            logInfo(">>>>>> Error getting WHATEVER data. <<<<<<");
###            return ERROR;
###        }
###    }


    return GOOD;
}
##############################################################################
##############################################################################
##############################################################################

##############################################################################
#
#          Name: GetAllVersions
#
#        Inputs: Controller object 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Get FW and BE versions ( a macro on other calls )   
#
#
##############################################################################
sub GetAllVersions
{
    trace();

    my ( $ctlr ) = @_;

    my $ret;
    my %rsp;
    my $i;
    my $str;
    my $id;
    my %info;

    logInfo("Altitude: ######### Viewing all versions #################### ");
           
    #####################
    #  Firmware Version
    #####################
    #logInfo("");
    $ret = FirmwareVer( $ctlr );

    ##############
    # disk bays
    ##############
    %info = $ctlr->diskBays();
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from diskBays <<<<<<<<");
        return ERROR;
    }
    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get diskBay info <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logDiskBays( %info);


    #############
    #  PDISKLIST
    #############

    %rsp = $ctlr->physicalDiskList();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDiskList <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to physicalDiskList <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    $str = "Physical Disk List:";

    for $i (0..$#{$rsp{LIST}})
    {
        $str .=  " " . $rsp{LIST}[$i];
    }

    logInfo($str);
    logInfo("");
    

    logInfo ("Drive    Capacity Vend ID  FW Rev Prod ID            Serial         WWN          Slot(0)   ");
    logInfo ("-----  ---------- -------- ------ ----------      -----------   ---------------- -------  "); 
    #         1234xx12345678901x12345678x123456x123456789012x123456789012x
    #
    # we do the following for each physical drive
    #
    


    for $i (0..$#{$rsp{LIST}})
    {
        $id = $rsp{LIST}[$i];


        ##############
        #  PDISKINFO
        ##############
        #logInfo("Retrieving physical disk information for each disk");
        %info = $ctlr->physicalDiskInfo($id);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskInfo <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to physicalDiskInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        PhysicalDiskRevInfo(%info);
    }




    return GOOD;
}

##############################################################################
# Name:     PhysicalDiskRevInfo()
#
# Desc:     logs pdisk version info
#
# Input:    pdiskinfo data hash
#              
#      
##############################################################################


sub PhysicalDiskRevInfo
{
    trace();
    
    my (%info) = @_;
    my $output;

    # first line
    $output  = sprintf("%4d  " , $info{PD_PID});
    $output .= sprintf("%11d " , $info{CAPACITY});
    $output .= sprintf("%8s "  , $info{VENDID});
    $output .= sprintf("%6s "  , $info{PD_REV});
    $output .= sprintf("%12s " , $info{PS_PRODID});

    # second line
    $output .= sprintf("%12s " , $info{PS_SERIAL});
    $output .= sprintf("%8.8x%8.8x ", $info{WWN_LO}, $info{WWN_HI});
    $output .= sprintf("     %2d "  , $info{SLOT});
#    $output .= sprintf("   %2d"   , $info{OSLOT});

    logInfo($output . "\n");
}

##############################################################################
# Name:     ProcData2()
#
# Desc:     get the proc debug trace information
#
# Input:    controller object
#              
#      
##############################################################################

sub ProcData2
{
    my ($ctlr) = @_;

    my %rsp;

    my $i;
    my $address;
    my $length;
    my $theLabel;
    my @collection;
    my $str;
    my $format;
    my $proc;
    
    my $msg;
    my $item;
    my $buffer;


    my $dirLength;
    my $dirCRC;

    $dirLength = 0;
    $dirCRC = 0;

    $collection[0] = [ 0xA0001000,     16,   "Header ",           "header"     ];   # header (has # of following entries) 
    $collection[1] = [ 0xa0001010,      0,   "directory ",        "procDir"   ];   # directory to parse
#    $collection[2] = [ 0xA0010000,   8192,   "Error trap ",       "word"     ];   # Err trap
#    $collection[3] = [ 0xa0052ca4,    176,   "internal info ",    "K_II"     ];   # int info
#    $collection[4] = [ 0xa004fad0,   1024,   "defrag trace",      "defrag"     ];   # defrag trace

    $proc = "BE";

    logInfo("Altitude: #################### Reading memory from proc board $proc processor #####################");
    
    for $i (0,1)
    {
        
        
        $address  = $collection[$i][0];    
        $length   = $collection[$i][1];    
        $theLabel = $collection[$i][2];    
        $format   = $collection[$i][3];    


        if ( $format eq "procDir" ) { $length = $dirLength; }

        logInfo("\n------------- Back end Data collection($i): $theLabel -------------------");
        
        if ( $length == 0 ) {next;}
        
        %rsp = $ctlr->ReadMemory($address, $length, $proc);
        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from ReadMemory <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from ReadMemory <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }


        if ( $format eq "header" ) 
        { 
            # handle this one here so we can extract the directory length and dirCRC
            
            
            $buffer = $rsp{RD_DATA};

            #        ID   <w>
            $item = unpack "A4", $buffer;
            $buffer = substr $buffer, 4;
            $msg = sprintf("                        table ID: %4s \n",$item);


            #        .version     <w>
            $item = unpack "L" , $buffer ;
            $buffer = substr $buffer, 4;
            $msg .= sprintf("                  format version: 0x%08x \n",$item);

            #       Number of entres (not bytes)   <w>
            $item = unpack "L" , $buffer ;
            $dirLength = 16 * $item;                      # make number of bytes
            $buffer = substr $buffer, 4;
            $msg .= sprintf("   number of table entries/bytes: %d / %d \n", $item, $dirLength);

            #        .CRC      <w>
            $dirCRC = unpack "L" , $buffer ;
            $buffer = substr $buffer, 4;
            $msg .= sprintf("                CRC (unverified): 0x%08x \n",$dirCRC);

            logInfo("\n".$msg."\n");

        }
        elsif ($format eq "procDir")
        {
            #############################
            # processor data directory 
            #############################
            $msg = "Raw HEX version of the directory(1):\n";
            #FmtData($buffer, $address, "word", undef);
            $buffer = $rsp{RD_DATA};

            $msg .= FmtDataString( \$buffer, $address, "word", undef, 0);



            $msg .= "\n\n";
            logInfo( $msg);     # logs the header first

            $msg = "\n";

            # fetch and process all directory entries (logs them, too)
            $msg .= ProcessProcDir($ctlr, $proc, $buffer, $address, $format);

            
            logInfo( $msg);
    
        }
        else
        {
            $str = FmtProcData($ctlr, $proc, $rsp{RD_DATA}, $address, $format, undef);
            logInfo( $str);
        }

        logInfo(" ");


        logInfo(" ");


    }

    $proc = "FE";

    logInfo("Altitude: ################### Reading memory from proc board $proc processor #####################");
    
    for $i (0,1)
    {
        
        
        $address  = $collection[$i][0];    
        $length   = $collection[$i][1];    
        $theLabel = $collection[$i][2];    
        $format   = $collection[$i][3];    


        if ( $format eq "procDir" ) { $length = $dirLength; }

        logInfo("\n------------- Front end Data collection($i): $theLabel -------------------");
        
        if ( $length == 0 ) {next;}
        
        %rsp = $ctlr->ReadMemory($address, $length, $proc);
        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from ReadMemory <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from ReadMemory <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }


        if ( $format eq "header" ) 
        { 
            # handle this one here so we can extract the directory length and dirCRC
            
            
            $buffer = $rsp{RD_DATA};

            #        ID   <w>
            $item = unpack "A4", $buffer;
            $buffer = substr $buffer, 4;
            $msg = sprintf("                        table ID: %4s \n",$item);


            #        .version     <w>
            $item = unpack "L" , $buffer ;
            $buffer = substr $buffer, 4;
            $msg .= sprintf("                  format version: 0x%08x \n",$item);

            #       Number of entres (not bytes)   <w>
            $item = unpack "L" , $buffer ;
            $dirLength = 16 * $item;                      # make number of bytes
            $buffer = substr $buffer, 4;
            $msg .= sprintf("   number of table entries/bytes: %d / %d \n", $item, $dirLength);

            #        .CRC      <w>
            $dirCRC = unpack "L" , $buffer ;
            $buffer = substr $buffer, 4;
            $msg .= sprintf("                CRC (unverified): 0x%08x \n",$dirCRC);

            logInfo("\n".$msg."\n");

        }
        elsif ($format eq "procDir")
        {
            #############################
            # processor data directory 
            #############################
            $msg = "Raw HEX version of the directory(2):\n";
            #FmtData($buffer, $address, "word", undef);
            $buffer = $rsp{RD_DATA};

            $msg .= FmtDataString( \$buffer, $address, "word", undef, 0);



            $msg .= "\n\n";
            logInfo( $msg);     # logs the header first

            $msg = "\n";


            # fetch and process all directory entries
            $msg .= ProcessProcDir($ctlr, $proc, $buffer, $address, $format);
            logInfo( $msg);
        }
        else
        {
            $str = FmtProcData($ctlr, $proc, $rsp{RD_DATA}, $address, $format, undef);
            logInfo( $str);
        }



        logInfo(" ");


    }



    return GOOD;
}

##############################################################################
#
#          Name: BedCheck
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: gets the configuration of the BE devices   
#
##############################################################################
sub BedCheck
{
    trace();
    my ($ctlr) = @_;
    my $ret;

    # Collect and display the data that shows how the BE is plumbed
    
    $ret = DeviceList($ctlr);
    if ( $ret != GOOD )
    {
        logInfo(">>>>>> Error getting DEVICELIST data. <<<<<<");
        return ERROR;
    }


    return GOOD;

}

##############################################################################
#
#          Name: BedVersion
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: gets the code version of the pdisks and disk bays   
#
##############################################################################
sub BedVersion
{
    trace();
    my ($ctlr) = @_;

    # This culls the FW version from the device bays and pdisks. 

    my %bays;
    my %disks;
    
    logInfo("Altitude: ############# Storage Device Versions ##################");

    %bays = $ctlr->diskBays();

    if (%bays)
    {
        if ($bays{STATUS} == PI_GOOD)
        {

            # from 'bays' data, get the bay versions 
            logDiskBays( %bays);


            %disks = $ctlr->physicalDisks();

            if (%disks)
            {
                if ($disks{STATUS} == PI_GOOD)
                {
                    
                    # now log the version of the drive FW
                    logPhysicalDisks("FWV", %disks);
                    

                }
                else
                {
                    logInfo (">>>>>>>> Error executing pdisks command <<<<<<<< ");
                    PrintError(%disks);
                    return ERROR;
                }
            }
            else
            {
                logInfo (">>>>>>>> No response from pdisks command <<<<<<<< ");
                return ERROR ;
            }    
            
        }
        else
        {
            logInfo (">>>>>>>> Error executing disk bays command <<<<<<<< ");
            PrintError( %bays) ;
            return ERROR;
        }
    }
    else
    {
        logInfo (">>>>>>>> No response from disk bays command <<<<<<<< ");
        return ERROR;
    }

    return GOOD;
}


##############################################################################
# Name:     GetReports
#
# Desc:     Retrieves a debug report.
#
# Input:    Which report (one of: HEAP, TRACE, PCB, PROFILE)
#           -l link-map       Name of linker map file
#           -f filename       Name of file to write output to
##############################################################################
sub GetReports
{
    my ($ctlr) = @_;

    my $i;
    my $report;
    my $format;


    logInfo("Altitude: ############ GETREPORT #########################");

    # type of data: t.s. fwv     trace        serial       callstack
    my @rptType   = ( "HEAP",    "TRACE",      "PCB",     "PROFILE" );
#    my @lengths = (        160,        8192,        8192,        1024 );
#    my @labels  = ( "FWV/regs",     "trace",    "serial",  "callstack");
    my @fmts    = (     "word",     "trace",      "text",       "text");
    # handler        text/hex        script         text         text

#    if (!defined($report) || $report !~ /^HEAP$|^TRACE$|^PCB$|^PROFILE$/i) 
#    {
#        print "\n";
#        print "Invalid or missing report identifier.\n";
#        return;
#    }

#    # see if an output goes to a file
#    my $outfile;
#    if ($opt_f) { 
##        print "opt_f=$opt_f\n";
#        $outfile = $opt_f;
#    }

# Not used at this time
#    # see if a link-map specified
#    my $linkmap;
#    if ($opt_l) { 
#        print "opt_l=$opt_l\n";
#        if (! -r $linkmap) {
#            print "-l must reference an existing linker map file\n";
#            return;
#        }
#        else {
#            $linkmap = $opt_l;
#        }
#    }

    for $i ( 0, 0 )
    {

        $report = $rptType[$i];
        $format  = $fmts[$i];
        
        logInfo("\nGetting report type: $report \n\n");

        my %rsp = $ctlr->generic2Command($report);

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                FmtHeapData($rsp{DATA} ) if $report =~ /^HEAP$/i;

#                # This is TEMPORARY until we get the TracDec.pl stuff wired in here...
#                if ($report =~ /^TRACE$/i) {
#                    if (! defined($outfile)) {
#                        print "You must specify a file to write the trace data to (for now...)\n";
#                        return;
#                    }
#                    print "Writing trace data to $outfile ...\n";
#                    my $rc = open OF, ">$outfile";
#                    if (!$rc) {
#                        print "Couldn't open $outfile ...\n";
#                    }
#                    else {
#                        binmode OF;
#                        print OF $rsp{DATA};
#                        close OF;
#                    }
#                }
            
#                # This is TEMPORARY until we get the PCBDec.pl stuff wired in here...
#                if ($report =~ /^PCB$/i) {
#                    if (! defined($outfile)) {
#                        print "You must specify a file to write the PCB data to (for now...)\n";
#                        return;
#                    }
#                    print "Writing PCB data to $outfile ...\n";
#                    my $rc = open OF, ">$outfile";
#                    if (!$rc) {
#                        print "Couldn't open $outfile ...\n";
#                    }
#                    else {
#                        binmode OF;
#                        print OF $rsp{DATA};
#                        close OF;
#                    }
#                }

#                # This is TEMPORARY until we get the ProfDec.pl stuff wired in here...
#                if ($report =~ /^PROFILE$/i) {
#                    if (! defined($outfile)) {
#                        print "You must specify a file to write the PROFILE data to (for now...)\n";
#                        return;
#                    }
#                    print "Writing PROFILE data to $outfile ...\n";
#                    my $rc = open OF, ">$outfile";
#                    if (!$rc) {
#                        print "Couldn't open $outfile ...\n";
#                    }
#                    else {
#                        binmode OF;
#                        print OF $rsp{DATA};
#                        close OF;
#                    }
#                }
            }
            else
            {
                logInfo("Unable to retrieve $report report data.");
                PrintError( %rsp);
                return ERROR;
            }
        }
        else
        {
            logInfo( "ERROR: Did not receive a response packet.\n");
            return ERROR;
        }

    }  #end of for loop

    logInfo("");
    return GOOD;
}


##############################################################################
# Name:     FmtHeapData
#
# Desc:     Parses the heap report data retrieved from the CCB
#
# Input:    Which command (for a report, one of: HEAP, TRACE, PCB, PROFILE)
##############################################################################
sub FmtHeapData()
{
    my ( $data ) = @_;

#    # open the output file if one was requested
#    my $fh = *STDOUT;
#    if (defined $filen) {
#        $fh = *FH;
#        open $fh, ">$filen" or $fh = *STDOUT;
#    }
   
    my $filename;

    #
    # First read the heap control block
    #
    my ($fm_org, $fm_s0len, $fm_align, $fm_cur_avl, $fm_max_avl, $fm_min_avl, 
     $fm_waits, $fm_wait_stat, $fm_count) = unpack "LLLLLLLLL", $data;
    $data = substr $data, 36;

    #
    # Other local vars
    #
    my @hits;
    my @hits2;
    my $total;
    my $i;

    #
    # The read each allocation record
    #
    while(length $data >= 16) {

        my ($length, $fileName, $lineNum, $tag) = unpack "LA8SS", $data;


        # round up to multiple of 16 and add 16. This
        # gets us to the actual allocation in the malloc code.
        $length = ((int(($length + 15) / 16)) * 16) + 16;

        # Post-process the parameters even further than what is
        # done in PI_generic.c.
        if (!(($fileName =~ /^RIP=/) or  ($fileName =~ /^[a-zA-Z]{1}[\w]{0,7}[ ]{0,7}$/))) 
        {
            
            #print "did # 1 \n";
            
            $data = substr $data, 16;
            next;
        }
        else
        {
            #print "skipped # 1 \n";
        }

        if ($fileName =~ /^RIP=/) 
        {
            #print "did # 2 \n";
            my $rip;
            ($length, $fileName, $rip, $lineNum, $tag) = unpack "LA4LSS", $data;
            $lineNum = $rip;
        }
        else
        {
            #print "skipped # 2 \n";
        }

        $data = substr $data, 16;

        my $found = 0;
        for($i=0; $i<@hits; $i++) 
        {
            # array def:  0:fileName  1:lineNum  2:count 3:totAlloc
            if($hits[$i][0] eq $fileName  &&  $hits[$i][1] == $lineNum)
            {
                $hits[$i][2]++;
                $hits[$i][3] += $length;
                $found = 1;
                last;
            }
        }

        if($found == 0) {   
            push @hits, [($fileName, $lineNum, 1, $length)];
        }

        $total++;
    }

    #
    # Create another array that can now be sorted
    #
    for($i=0; $i<@hits; $i++) {
        my $templ;
        if($hits[$i][1] < 0xa0000000) {
            $templ = "%-8s %8u %5u %8u";
        }
        else {
            $templ = "%-8s %8x %5u %8u";
        }
        push @hits2, sprintf $templ, 
        $hits[$i][0], $hits[$i][1], 
        $hits[$i][2], $hits[$i][3]; 
    }
    @hits2 = sort @hits2;

    #
    # Print out the results
    #
    logInfo("");
    logInfo(sprintf(  "Base Addr       = 0x%08X\n", $fm_org));
    logInfo(sprintf(  "Heap Size         = %8u\n", $fm_max_avl));
    logInfo(sprintf(  "Cur Available     = %8u\n", $fm_cur_avl));
    logInfo(sprintf(  "Low Water Mark    = %8u\n", $fm_min_avl));
    logInfo(sprintf(  "Wait Count        = %8u\n", $fm_waits));
    logInfo(sprintf(  "Wait State        = %8u\n", $fm_wait_stat));
    logInfo(sprintf(  "Malloc's Reported = %8u\n", $fm_count));
    logInfo(sprintf(  "Malloc's Found    = %8u\n", $total));
    logInfo(sprintf(  "Total Malloc'd    = %8u\n", $fm_max_avl-$fm_cur_avl));
    logInfo("");

    logInfo("filename     line  count   total");
    logInfo("--------------------------------");
    for($i=0; $i<@hits2; $i++) {
        logInfo("$hits2[$i]");
    }
    logInfo("");

}


##############################################################################

##############################################################################
# Name:     CcbTrace()
#
# Desc:     get the ccbe debug trace information
#
# Input:    controller object
#              
#      
##############################################################################

sub CcbTrace
{
    my ($ctlr) = @_;

    my %rsp;

    my $i;
    my $address;
    my $length;

    my $machAddr;
    my $ccbVer;
    my %data;
    my $revRaw;
    my $revCooked;

    my $format;

    my @addrs;  
    my @lengths;
    my @labels; 
    my @fmts;   


#    # type of data: t.s. fwv     trace        serial       callstack
#    my @addrs   = ( 0xFEF92050,  0xFEF925A0,  0xFEF945A0,  0xFEF92190 );
#    my @lengths = (        160,        8192,        8192,        1024 );
#    my @labels  = ( "FWV/regs",     "trace",    "serial",  "callstack");
#    my @fmts    = (   "header",     "trace",      "text",       "text");
    # handler        text/hex        script         text         text
    
    
#    Here's what I think the matrix is Craig (my table lines up better with a fixed width font...):
#
# FW Ver    Mach Ver    Mach Rev Loc     NVRAM Base 
# --------------------------------------------------------------------------------------------
# <  810      !4          FEF80003        FEF90000  (original location)
# <  810      4           FEF80003        FEFB8000  (after mach update and new NVRAM on 10/28)
# >= 810      4           FEE80003        FEEB8000  (yest another mach update)
# 
#The Pre-810 mach level 4 and the 810 mach level 4 are really different mach code loads 
#(couldn't they use another version identifier??), so be careful.
#    
#                                                           

    # need to adjust the data map for the various versions of the code. This
    # is driven by the CCB FW version and the MACH version. So, we need to 
    # do  FWV on the controller and get the versions.

    # get the FW version for the CCB runtime

    %rsp = $ctlr->fwVersion();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from fwVersion <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from fwVersion <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    ##########################################
    #
    #  this logic duplicated in FirmwarVer()
    #
    #  DUAL MAINTENANCE!!!!
    #
    ##########################################


    $ccbVer = FW_VER_CCB_RUNTIME;

    $ccbVer =  $rsp{$ccbVer}{REVISION};

    logInfo("The CCB runtime code version is $ccbVer ");

    # now get the mach version for the CCB

    if ( ( $ccbVer ge "M000" ) && ($ccbVer le "MZZZ" ) && ($ccbVer lt "M810" ) )
    {
        # the older mach address
        $machAddr = 0xFEF80003;
    }
    else
    {
        # the newer mach address
        $machAddr = 0xFEE80003;
    }




    %data = $ctlr->ReadMemory($machAddr, 1, "CCB");
    if ( ! %data  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from readMemory <<<<<<<<");
        return ERROR;
    }
    if($data{STATUS} != 0) 
    {
        logInfo "Couldn't read CCB Mach revision...";
        return ERROR;
    }
    else 
    {
        $revRaw = unpack("C", $data{RD_DATA}) & 0xF;
        $revCooked = "?";
        $revCooked = "old"   if ($revRaw == 0x2);
        $revCooked = "rev A" if ($revRaw == 0x3);
        logInfo(sprintf ("CCB_MACH    %X (%s)\n", $revRaw, $revCooked));
    }

    # now sort out the revision stuff

    if ( ( $ccbVer ge "M000" ) && ($ccbVer le "MZZZ" ) && ($ccbVer lt "M810" ) )
    {
        # the older 'M' code, now test the mach
        
        if ( $revRaw == 4 )
        {
            # new mach, older ccb (interim mess)
            # NVRAM base = FEFB8000

            # type of data: t.s. fwv     trace        serial       callstack
            @addrs   = ( 0xFEFBA050,  0xFEFBA5A0,  0xFEFBA5A0,  0xFEFBA190 );
            @lengths = (        550,        8192,        8192,        1024 );
            @labels  = ( "FWV/regs",     "trace",    "serial",  "callstack");
            @fmts    = (   "header",     "trace",      "text",       "text");
            # handler        text/hex        script         text         text
        
            logInfo("Using the interim set of addresses ");

            
        }
        else
        {
            # older (or possibly newer) mach, older ccb code
            # this original place
            # NVRAM base = FEF90000

            # type of data: t.s. fwv     trace        serial       callstack
            @addrs   = ( 0xFEF92050,  0xFEF925A0,  0xFEF945A0,  0xFEF92190 );
            @lengths = (        550,        8192,        8192,        1024 );
            @labels  = ( "FWV/regs",     "trace",    "serial",  "callstack");
            @fmts    = (   "header",     "trace",      "text",       "text");
            # handler        text/hex        script         text         text

            logInfo("Using the original set of addresses ");

        }
    }
    elsif ( ( $ccbVer ge "M810" ) && ($ccbVer le "M820" )  )
    {
        # M810, M820 only
        # NVRAM base = FEEB8000
        
        # type of data: t.s. fwv     trace        serial       callstack
        @addrs   = ( 0xFEEBA050,  0xFEEBA5A0,  0xFEEBC5A0,  0xFEEBA190 );
        @lengths = (        550,        8192,        8192,        1024 );
        @labels  = ( "FWV/regs",     "trace",    "serial",  "callstack");
        @fmts    = (   "header",     "trace",      "text",       "text");
        # handler        text/hex        script         text         text
        
        logInfo("Using the addresses for M810 and M820 ");

    }
    # drop in some elsif clauses here when more 'M###' specific 
    # interim type versions are known

    else
    {
        # the newest stuff by default goes here  

        # type of data: t.s. fwv     trace        serial       callstack

        @addrs   = ( 0xFEEB4050,  0xFEEB45A0,  0xFEEB95A0,  0xFEEB4190 );
        @lengths = (        550,       20480,       20480,        1024 );
        @labels  = ( "FWV/regs",     "trace",    "serial",  "callstack");
        @fmts    = (   "header",     "trace",      "text",       "text");
        # handler        text/hex        script         text         text

        logInfo("Using the default (new) set of addresses ");
    }



    logInfo("Altitude: ################# Reading memory for CCB ##############################");
    
    for $i (0, 1, 2, 3)
    {
        
        $address = $addrs[$i];
        $length  = $lengths[$i];
        $format  = $fmts[$i];

        logInfo("-------------------- Data collection($i): $labels[$i] -------------------");
        
        %rsp = $ctlr->ReadMemory($address, $length, "CCB");
        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from ReadMemory <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from ReadMemory <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
        
        FmtData($rsp{RD_DATA}, $address, $format, undef);

        logInfo(" ");

    }
}
##############################################################################
# Name:     FormatData()
#
# Desc:     Format binary data in various formats to STDOUT or a file
#
# Input:    data
#           address (that is came from)
#           format (byte/short/word/binary)
#           filename (if output to go to a file; undef otherwise)
#           reqLength - requested data length (0 = all available data)   
#      
##############################################################################
sub FmtData
{
    my ( $buffer, $address, $format, $filen, $reqLength) = @_;

    my $str;

    $str =  FmtDataStringCG( $buffer, $address, $format, $filen, $reqLength);

    logInfo( $str); 


}


##############################################################################
# Name:     ProcessProcDir()
#
# Desc:     Walk the processor directory and output results
#
# Input:    $ctlr, $proc, $buffer, $address, $format
#
#      
##############################################################################
sub ProcessProcDir
{
    my ( $ctlr, $proc, $buffer, $addressIn, $formatIn)  = @_;

    my $msg;
    my $item;
    my $i;
    my $name;

    my %rsp;

    my $address;
    my $length;
    my $theLabel;
    my @collection;
    my $str;
    my $format;

    
    my $dirLength;
    my $dirCRC;


    logInfo("Altitude: ################## Reading memory from proc board $proc processor #####################");
    
    

    #for ($i = 0; $i < length($buffer); $i += 16)
    while  ( 16 <= length($buffer))
    {
        
        # Identify a data block to work with 
        
        $theLabel = unpack "A8", $buffer;    
        $buffer = substr $buffer, 8;

        $address = unpack "L" , $buffer ;
        $buffer = substr $buffer, 4;

        $length = unpack "L" , $buffer ;
        $buffer = substr $buffer, 4;

        $format = $theLabel;

        # print it
        
        #$msg = sprintf("Checking %8s: %5d bytes from address 0x%08x", $theLabel, $length, $address);
        #logInfo($msg);

        # qualify it - the length must be finite, not 0, address can't be 0

        if ( $length  <  1) { next;}
        if ( $address == 0) { next;}

        # print it
        $msg = "----------------------------------------------------------------------------";
        $msg .= "----------------------------------------------------------------------------";
        logInfo($msg);
        
        $msg = sprintf("( Fetching %8s: %5d bytes from address 0x%08x )", $theLabel, $length, $address);
        logInfo($msg);


        logInfo("\nAltitude: #-------- $proc Processor Data collection: $theLabel -------------------");

       
        %rsp = $ctlr->ReadMemory($address, $length, $proc);
        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from ReadMemory <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from ReadMemory <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }


        if ( $format eq "header" ) 
        { 

        }
        else
        {
            # This handles the ones not above
            $str = "";
            $str .= FmtProcData($ctlr, $proc, $rsp{RD_DATA}, $address, $format, undef);
            logInfo( $str);
        }

        logInfo(" ");
      #  logInfo("Raw HEX version:");
      #  FmtData($rsp{RD_DATA}, $address, "word", undef);


        logInfo(" ");


    }


    return ("Data collection from $proc processor complete....");;


}

##############################################################################
# Name:     FmtDefragData()
#
# Desc:     Format defgra debug data  into a string
#
# Input:    data
#               typedef struct defragDebugRec
#               {
#                    UINT8       step;
#                    UINT8       repeat;
#                    UINT16      sosstep;
#                    UINT16      nvrecflag;
#                    UINT16      eflag;
#                    UINT16      oflag;
#                    UINT16      action;
#                    UINT16      sdahi;
#                    UINT16      sdalo;
#               } DDR, *pDDR;
#
#      
##############################################################################
sub FmtDefragData
{
    my ( $buffer) = @_;
    my $i;
    my $msg;
    my $item;
    
    $msg  = "Defrag Debug Records:\n";
    $msg .= "step repeat SOSstep nvrecflag eflag oflag action  sdahi    sdalo\n";
    $msg .= "---- ------ ------- --------- ----- ----- ------ ---------- -------\n";



    for ( $i = 0; $i < 128; $i++ )
    {

            #       step      <b>
            $item = unpack "C" , $buffer;
            $buffer = substr $buffer, 1;
            $msg .= sprintf(" %4d", $item);

            #        repeat    <b>
            $item = unpack "C" , $buffer;
            $buffer = substr $buffer, 1;
            $msg .= sprintf(" %6d",$item);


            #       sosstep      <s>
            $item = unpack "S" , $buffer;
            $buffer = substr $buffer, 2;
            $msg .= sprintf(" %7d",$item);

            #        nvrecflag    <s>
            $item = unpack "S" , $buffer;
            $buffer = substr $buffer, 2;
            $msg .= sprintf(" %9d",$item);

            #        eflag    <s>    
            $item = unpack "S" , $buffer;
            $buffer = substr $buffer, 2;
            $msg .= sprintf(" %5d",$item);



            #        oflag    <s>    
            $item = unpack "S" , $buffer;
            $buffer = substr $buffer, 2;
            $msg .= sprintf(" %5d",$item);


            #       action      <s>
            $item = unpack "S" , $buffer;
            $buffer = substr $buffer, 2;
            $msg .= sprintf(" %6d",$item);

            #        sdahi    <s>
            $item = unpack "S" , $buffer;
            $buffer = substr $buffer, 2;
            $msg .= sprintf(" 0x%08x",$item);

            #        sdalo    <s>    
            $item = unpack "S" , $buffer;
            $buffer = substr $buffer, 2;
            $msg .= sprintf("%08x \n",$item);

    }

    return $msg;

}

##############################################################################
# Name:     FormatDataStringCG()
#
# Desc:     Format binary data in various formats to a string
#
# Input:    data
#           address (that is came from)
#           format (byte/short/word/binary)
#           filename (if output to go to a file; undef otherwise)
#           reqLength - requested data length (0 = all available data)   
#      
##############################################################################
sub FmtDataStringCG
{
    my ( $buffer, $address, $format, $filen, $reqLength) = @_;

    # String to store output
    my $str = "";
    

    if ( $format eq "text" )
    {
        ###
        ## Remove the unprintable characters.
        ## The negated list is ' ' through '~' (which is the class of printables)
        ## and we'll allow linefeeds and tabs (but not carriage returns).
        ###
        $buffer =~ s/[^ -~\n\t]//g;

        return $buffer;
    }

    if ( $format eq "trace" ) {return CCBDecoder($buffer); }
    if ( $format eq "header" ) {return CCBErrorSnapshotDecoder($buffer); }

    # set up the byte count and templates based upon output format requested
    my $addrTpl = "%08X  ";
    my $asciiTpl = "  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n";
    my $byteTpl = "CCCC CCCC CCCC CCCC";
    my $unpackTpl = "L L L L";
    my $printfTpl = "%08X %08X  %08X %08X";
    
    if ($format =~ /^byte$/i) {
        $unpackTpl = $byteTpl;
         $printfTpl = "%02X %02X %02X %02X %02X %02X %02X %02X  " .
             "%02X %02X %02X %02X %02X %02X %02X %02X"; 
    }
    elsif ($format =~ /^short$/i) {
        $unpackTpl = "SS SS SS SS";
        $printfTpl = "%04X %04X %04X %04X  %04X %04X %04X %04X";
    }
    elsif ($format =~ /^text$/i) {
        $unpackTpl = "SS SS SS SS";
        $printfTpl = "%04X %04X %04X %04X  %04X %04X %04X %04X";
    }


    # get the overall length of the data buffer
    my $length = length $buffer;


    # if the requested length is defined return only the amount requested.
    if (defined $reqLength)
    {
        $length = $reqLength;
    }

    my $i;
    my @rowData;
    my @asciiData;
    my $padLen = 0;
    
    for ($i=0; $i<$length; $i+=16) {

        @rowData = ();
        @asciiData = ();

        # Getting the final line to display properly when not an even multiple
        # of 16 bytes is not easy given the way that this routine has been 
        # structured. So as a kludge, we pad the data out to the proper length
        # with 0xAA's, and then warn the caller that we did this.
        if ($i+16 > $length) {
            $padLen = ($i+16) - $length;
            $buffer .= pack "C$padLen", 
            0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 
            0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA;
        }
        
        push @rowData, unpack $unpackTpl, $buffer;

        my $tmp;
        foreach $tmp (unpack $byteTpl, $buffer) {
            if ($tmp < 0x20 or $tmp >= 0x7f) {
                $tmp = 0x2e; # '.'
            }
            push @asciiData, $tmp;
        }

        $str .= sprintf  $addrTpl.$printfTpl.$asciiTpl, $address, @rowData, @asciiData;
        
        if ($padLen) {
            $str .= sprintf  
            "\nNote: Since the amount of data to display ($length bytes) is not an even\n".
            "multiple of 16, the final \"AA's\" displayed MAY NOT BE YOUR ACTUAL DATA!\n";
        }
        
        if (length($buffer) > 16) {
            $buffer = substr $buffer, 16;
        }
        $address += 16;
    }

    return $str;

}




##############################################################################
#
#          Name: SosTables
#
#        Inputs: controller object, pdd number
#
#       Outputs: prints sos table
#
#  Globals Used: none
#
#   Description: .
#
##############################################################################

sub SosTables
{
    trace();
    my ($ctlr, $pdd) = @_;

    my %info;
    my %rsp;
    my $i;

    logInfo("Altitude: ##############  SOS tables ############################");

    %rsp = $ctlr->physicalDiskList();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDiskList <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to physicalDiskList <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    for $i (0..$#{$rsp{LIST}})
    {
        $pdd = $rsp{LIST}[$i];

        print "Retrieving SOS Table for disk $pdd.      \r";
        %info = $ctlr->getSos($pdd);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from getSos <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> ERROR: Could not retrieve SOS table ($pdd) <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logSos(%info);
    }

    return GOOD;
    
    # return 
}




##############################################################################
#
#          Name: GlobCacheInfo
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################
sub GlobCacheInfo
{
    trace();
    my ($ctlr) = @_;
    my %data;
    
    logInfo("Altitude: ###############  GlobalCacheInfo ##############################");
    
    %data = $ctlr->globalCacheInfo();

    if ( ! %data  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from globalCacheInfo <<<<<<<<");
        return ERROR;
    }
    if ( $data{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from globalCacheInfo <<<<<<<<");
        PrintError(%data);
        return ERROR;
    }

    # After data read up, format it appropriately.

    logInfo "Global Information:\n";
    logInfo(sprintf ("  STATUS:                %hu\n", $data{STATUS_MRP}));
    logInfo(sprintf ("  LEN:                   %lu\n", $data{LEN}));
    logInfo(sprintf ("  CA_STATUS:             0x%x\n", $data{CA_STATUS}));
    logInfo(sprintf ("  CA_BATTERY:            0x%x\n", $data{CA_BATTERY}));
    logInfo(sprintf ("  CA_STOPCNT:            %lu\n", $data{CA_STOPCNT}));
    logInfo(sprintf ("  CA_SIZE                %lu\n", $data{CA_SIZE}));
    logInfo(sprintf ("  CA_MAXCWR              %lu\n", $data{CA_MAXCWR}));
    logInfo(sprintf ("  CA_MAXSGL              %lu\n", $data{CA_MAXSGL}));
    logInfo(sprintf ("  CA_NUMTAGS             %lu\n", $data{CA_NUMTAGS}));
    logInfo(sprintf ("  CA_TAGSDIRTY           %lu\n", $data{CA_TAGSDIRTY}));
    logInfo(sprintf ("  CA_TAGSRESIDENT        %lu\n", $data{CA_TAGSRESIDENT}));
    logInfo(sprintf ("  CA_TAGSFREE            %lu\n", $data{CA_TAGSFREE}));
    logInfo(sprintf ("  CA_TAGSFLUSHIP         %lu\n", $data{CA_TAGSFLUSHIP}));
    logInfo(sprintf ("  CA_NUMBLKS             %lu\n", $data{CA_NUMBLKS}));
    logInfo(sprintf ("  CA_BLOCKSDIRTY         %lu\n", $data{CA_BLOCKSDIRTY}));
    logInfo(sprintf ("  CA_BLOCKRESIDENT       %lu\n", $data{CA_BLOCKRESIDENT}));
    logInfo(sprintf ("  CA_BLOCKFREE           %lu\n", $data{CA_BLOCKFREE}));
    logInfo(sprintf ("  CA_BLKSFLUSHIP         %lu\n", $data{CA_BLKSFLUSHIP}));

    return GOOD;
}


##############################################################################
#
#          Name: ModeBits
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################
sub ModeBits
{
    trace();
    my ($ctlr) = @_;
    my %data;
    
    logInfo("Altitude: ################  mode bits ##############################");
    
    %data = $ctlr->modeDataGet();

    if ( ! %data  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from modeDataGet <<<<<<<<");
        return ERROR;
    }
    if ( $data{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from modeDataGet <<<<<<<<");
        PrintError(%data);
        return ERROR;
    }

    # After data read up, format it appropriately.
    logInfo(  "Mode bits:");
    logInfo(sprintf( "  CCB bits:              0x%08x\n", $data{CCB_MODE_BITS1}));
    logInfo(sprintf( "  PROC bits 1:           0x%08x\n", $data{PROC_MODE_BITS1}));
    logInfo(sprintf( "  PROC bits 2:           0x%08x\n", $data{PROC_MODE_BITS2}));
    logInfo(sprintf( "  PROC bits 3:           0x%08x\n", $data{PROC_MODE_BITS3}));
    logInfo(sprintf( "  PROC bits 4:           0x%08x\n", $data{PROC_MODE_BITS4}));


    return GOOD;
}


##############################################################################
#
#          Name: StructInfo
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################
sub StructInfo
{
    trace();
    my ($ctlr) = @_;
    
    my %data;
    my $badCount = 0;
    my $i;
    ###################
    # STRUCTUREINFO
    ###################
    
    logInfo("Altitude: ########### STRUCTUREINFO ##########################");

    for ($i =1; $i < 6; $i++)
    {
        %data = $ctlr->structureInfo($i);

        if ( ! %data  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from structureinfo <<<<<<<<");
            return ERROR;
        }
        if ( $data{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from structureinfo <<<<<<<<");
            PrintError(%data);
            return ERROR;
        }

        if (!defined $data{RD_DATA} )
        {
            logInfo("For item $i, no data was returned");
            $badCount++;

          #  print("For item $i, no data was returned\n");
          #  print %data; 
          #  sleep(5);

        }
        else
        {
            # After data read up, format it appropriately.
            logInfo("\n Data for item # $i.....\n".$data{RD_DATA});
        }
    }

    if ( $badCount > 0 )
    {
        return ERROR;
    }
    else
    {
        return GOOD;
    }

}



##############################################################################
#
#          Name: RaidCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of RDD related functions.   
#
##############################################################################
sub RaidCommands
{
    trace();
    my ($ctlr) = @_;

    my %rtn;
    my $ret;
    my %info;
    my $i;


    logInfo("Altitude: ############ RAID COMMANDS #######################");

    ############
    # RAIDCOUNT
    ############

    %info = $ctlr->raidCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raidCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raidCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logInfo("Number of raid devices $info{COUNT}");

    ############
    # RAIDLIST
    ############

    %info = $ctlr->raidList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raidList <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raidList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    my $string = $info{LIST};
    my @array_Raid = @$string;        
    logInfo("List of raid devices @array_Raid");


    #
    # tests on individual RDDs
    #

    for ( $i = 0; $i < scalar(@array_Raid); $i++ )
    {
        my $id = $array_Raid[$i];

    
        ##############
        # RAIDINFO
        ##############
        
        
        %info = $ctlr->virtualDiskRaidInfo($id);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskRaidInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskRaidInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
     
        logVirtualDiskRaidInfo(%info);

        
     


    }


    
    ############
    # RAIDS
    ############
 
    %info = $ctlr->raids();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
     
    logRaids(%info);

    
    

    return GOOD;
}





##############################################################################
#
#          Name: ServerCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of disk bay related functions   
#
#
##############################################################################


sub ServerCommands
{
    trace();
    my ($ctlr) = @_;

    my %rsp;
    my $i;
    my $r;
    my @vdisks;

    logInfo("Testing server operations");

    my $sid = 0;
    my $lun = 0;

    ################
    # server count
    ################

    %rsp = $ctlr->serverCount();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from serverCount <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from serverCount <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }
    
    logInfo("Server Count: $rsp{COUNT}");

    ################
    # server list
    ################

    logInfo("Server List");

    %rsp = $ctlr->serverList();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from serverList <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from serverList <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }
    
    my $str = "  ";
     
    for $i (0..$#{$rsp{LIST}})
    {
        $str .=  $rsp{LIST}[$i] . "  "  ;
    }

    logInfo($str);

    logInfo("Retrieving server information for each server.");

    for $i (0..$#{$rsp{LIST}})
    {
        
        ###################
        # server info
        ###################
        my $id = $rsp{LIST}[$i];
        my %info = $ctlr->serverInfo($id);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from serverInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from serverInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logServerInfo(%info);
    }
    
    #
    # need an array of vdisk ids for the following
    #

    ######################
    # vdisk list
    ######################

    %rsp = $ctlr->getObjectList(PI_VDISK_LIST_CMD);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from PI_VDISK_LIST_CMD <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Virtual Disk List");
    logObjectList(%rsp);
    # in here is my list of disks.. now how do i extract it?
    # need to build this array >>>> @vdisklistarray = @$vdisklist;       # make an array

    # put drives into an array
    for ( $r=0; $r< $rsp{COUNT}; $r++)
    {
        push  @vdisks, $rsp{LIST}[$r];
    }
     
    #$numVDDs = $rsp{COUNT};  # of drives available to map

    
    

    #############
    #  SERVERS
    #############
    logInfo("Servers Command");
    %rsp = $ctlr->servers();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from Servers <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get Servers info <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logServers(%rsp);

    logInfo("Completed testing server operations");
    
    return GOOD;
}



##############################################################################
#
#          Name: TargetCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of target related functions.   
#
##############################################################################
sub TargetCommands
{
    trace();
    my ($ctlr) = @_;

    my %rtn;
    my $ret;
    my %info;
    my $id;
    my %rsp;
    my $i;

    logInfo("Altitude: ################## TARGET information ######################");

    #####################
    # TARGETCOUNT
    #####################
    %info = $ctlr->targetCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from targetCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from targetCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
     
    logInfo("Number of Targets $info{COUNT}");



    #####################
    # TARGETLIST
    #####################
    %info = $ctlr->targetList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from targetList <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from targetList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
     
    my $string = $info{LIST};
    my @array_Targets = @$string;         
    logInfo("List of Targets @array_Targets");


    #
    # tests on individual targets
    #


    for ( $i = 0; $i < scalar(@array_Targets); $i++ )
    {
        $id = $array_Targets[$i];


        #####################
        # TARGETINFO
        #####################
        %info = $ctlr->targetInfo($id);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from targetInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from targetInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
     
        logTargetInfo(%info);
    }
 
    #####################
    #  TARGETS
    #####################

    %rsp = $ctlr->targets();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from targets command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from targets command <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }
     
    logTargets(%rsp);


    return GOOD;
}




##############################################################################
#
#          Name: DoNVRAM
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: prints nrvam data   
#
##############################################################################

sub DoNVRAM
{
    my ($ctlr) = @_ ;
    trace();

    logInfo("Altitude: ################## nvram dump FE ########################");
    nvramRead( $ctlr, "FE");
    logInfo("Altitude: ################## nvram dump BE ########################");
    nvramRead( $ctlr, "BE");
    #logInfo("Altitude: ################## nvram dump ?? ########################");
    #nvramRead( $ctlr, "");

    return GOOD;

}


##############################################################################
# Name:     nvramRead()
#
# Desc:     Read memory from specified processor
#
# Input:    Address
#           length
#           -p BE|FE  (processor)
#           -f filename  (output filename)
#           -l long display
##############################################################################
sub nvramRead
{
    trace();

    my ($ctlr, $proc) = @_;    
    my $displayMode;

    my $mem_start  = 0xFE800000; 
    my $mem_length = 0xFE970000;
    
  #  my $proc = "BE";
    
    my $out_file = "nvrmdmp";
    my $increment = 0x8000;
    my $mem_data;

    my $i;

    logInfo("");

    if ( $proc eq "BE" )
    {
        
        
        $mem_length = 0xFE830000;
        # Read the data
        my %data = $ctlr->ReadMemory(0xFE80800C, 4, $proc);
        if($data{STATUS} != 0)
        {
            logInfo("");
            logInfo("The memory read failed...");
            return ERROR;
        }
        else
        {
            my $buffer;
            $buffer = unpack ( "L",$data{RD_DATA});
            $mem_length = 0xFE808000 + $buffer;

            # print " data read $buffer \n";
            # printf ("new end addr 0x%08x \n", $mem_length );

        }

        $displayMode = $proc;
    }



    if ( $proc eq "FE" )
    {
        $mem_length = 0xFE810000;
        $displayMode = $proc;

    }
    
    $displayMode = $proc;


    for($i = $mem_start; $i <= ($mem_length-1); $i = ($increment + $i))
    {
        # Read the data
        my %data = $ctlr->ReadMemory($i, $increment, $proc);
        if($data{STATUS} != 0)
        {
            logInfo("");
            logInfo("The memory read failed...");
            return ERROR;
        }
        else
        {
            $mem_data .= $data{RD_DATA};
        }   
    }

    # After data read up, format it appropriately.
    my $open_file = $ctlr->writeMemToFile($mem_data, $out_file);

    if(defined($open_file))
    {
        my $rc = 0;
        
        logInfo( "Wrote initial Dump to:\n  $open_file");
    
        $rc = NvramDump($open_file, $displayMode);
        
    }   
    else
    {
        logInfo( "Error Writing initial Dump File");
    }


    logInfo("");
}

##############################################################################
#
#          Name: ReadBase
#
#        Inputs: file handel
#
#       Outputs: list of three items
#
#  Globals Used: none
#
#   Description:    
#
##############################################################################

sub ReadBase
{
    #my ($fh) = @_;
    my $rec_length;
    my $rec_type;
    my $rec_status;

    # Record length             <s>
    read NVRAM, $rec_length, 2;
    $rec_length = unpack "S", $rec_length;
    
    # Record type               <b>
    read NVRAM, $rec_type, 1;
    $rec_type = unpack "C", $rec_type;

    # Status                    <b>
    read NVRAM, $rec_status, 1;
    $rec_status = unpack "C", $rec_status;

    return($rec_length, $rec_type, $rec_status);

}

##############################################################################
#
#          Name: CGReadingFWHeader
#
#        Inputs: filehandle
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of misc functions.   
#
##############################################################################

sub CGReadingFWHeader
{
    #my (NVRAM) = @_;
    
    my $blanks;
    
    read NVRAM, $blanks, 32;

    # magicNumber               static      0x08
    my $magicNumber;
    read NVRAM, $magicNumber, 4;
    $magicNumber = unpack "L", $magicNumber;
    logInfo(sprintf( "magicNumber: 0x%08x\n", $magicNumber));

    # rsvd1                     
    my $rsvd1;
    read NVRAM, $rsvd1, 4;
    $rsvd1 = unpack "L", $rsvd1;
    logInfo(sprintf( "rsvd1: 0x%08x\n", $rsvd1));

    # productID   (1000=Tbolt)  
    my $productID;
    read NVRAM, $productID, 4;
    $productID = unpack "L", $productID;
    logInfo(sprintf( "productID: 0x%08x\n", $productID));

    # target      (1=emc)       
    my $target;
    read NVRAM, $target, 4;
    $target = unpack "L", $target;
    logInfo(sprintf( "target: 0x%08x\n", $target));
            
    # revision                  
    my @revision_a;
    my $revision;
    read NVRAM, $revision, 4;   
    @revision_a = unpack "A4", $revision;
    logInfo( sprintf "revision: @revision_a\n");

    # revCount                  
    my @revCount_a;
    my $revCount;
    read NVRAM, $revCount, 4;
    @revCount_a = unpack "A4", $revCount;
    logInfo( sprintf "revCount: @revCount_a\n");

    # buildID                   
    my @buildID_a;
    my $buildID;
    read NVRAM, $buildID, 4;
    @buildID_a = unpack "A4", $buildID;
    logInfo(sprintf "buildID: @buildID_a\n");

    # vendorID                  
    my $vendorID;
    read NVRAM, $vendorID, 4;
    $vendorID = unpack "L", $vendorID;
    logInfo(sprintf( "vendorID: 0x%08x\n", $vendorID));

            
    # timestamp.year            
    my $year;
    read NVRAM, $year, 2;
    $year = unpack "S", $year;

    # timestamp.month           
    my $month;
    read NVRAM, $month, 1;
    $month = unpack "C", $month;

    # timestamp.date            
    my $date;
    read NVRAM, $date, 1;
    $date = unpack "C", $date;

    # timestamp.day             
    my $day;
    read NVRAM, $day, 1;
    $day = unpack "C", $day;

    # timestamp.hours                 
    my $hours;
    read NVRAM, $hours, 1;
    $hours = unpack "C", $hours;

    # timestamp.minutes         
    my $minutes;
    read NVRAM, $minutes, 1;
    $minutes = unpack "C", $minutes;

    # timestamp.seconds         
    my $seconds;
    read NVRAM, $seconds, 1;
    $seconds = unpack "C", $seconds;

    logInfo(sprintf ("Build Date: %x/%x/%x ", $month, $day, $year));
    logInfo(sprintf ( "%02x:%02x:%02x\n", $hours, $minutes, $seconds));

    # rsvd2                     
    my $rsvd2;
    read NVRAM, $rsvd2, 4;
    $rsvd2 = unpack "L", $rsvd2;
    logInfo(sprintf( "rsvd2: 0x%08x\n", $rsvd2));
    
    # burnSequence              
    my $burnSequence;
    read NVRAM, $burnSequence, 4;
    $burnSequence = unpack "L", $burnSequence;
    logInfo(sprintf( "burnSequence: 0x%08x\n", $burnSequence));

    # loadID.emcAddrA
    my $emcAddrA;
    read NVRAM, $emcAddrA, 4;
    $emcAddrA = unpack "L", $emcAddrA;
    logInfo(sprintf( "emcAddrA: 0x%08x\n", $emcAddrA));

    # loadID.emcAddrB           
    my $emcAddrB;
    read NVRAM, $emcAddrB, 4;
    $emcAddrB = unpack "L", $emcAddrB;
    logInfo(sprintf( "emcAddrB: 0x%08x\n", $emcAddrB));

    # loadID.targAddr           
    my $targAddr;
    read NVRAM, $targAddr, 4;
    $targAddr = unpack "L", $targAddr;
    logInfo(sprintf( "targAddr: 0x%08x\n", $targAddr));

    # loadID.length             
    my $length;
    read NVRAM, $length, 4;
    $length = unpack "L", $length;
    logInfo(sprintf( "length: 0x%08x\n", $length));

    # loadID.checksum           
    my $checksum;
    read NVRAM, $checksum, 4;
    $checksum = unpack "L", $checksum;
    logInfo(sprintf( "checksum: 0x%08x\n", $checksum));

    # loadID.compatibilityID    
    my $compatibilityID;
    read NVRAM, $compatibilityID, 4;
    $compatibilityID = unpack "L", $compatibilityID;
    logInfo(sprintf( "compatibilityID: 0x%08x\n", $compatibilityID));

    # rsvd3[0]                  
    my $rsvd30;
    read NVRAM, $rsvd30, 4;
    $rsvd30 = unpack "L", $rsvd30;
    logInfo(sprintf( "rsvd30: 0x%08x\n", $rsvd30));

    # rsvd3[1]                  
    my $rsvd31;
    read NVRAM, $rsvd31, 4;
    $rsvd31 = unpack "L", $rsvd31;
    logInfo(sprintf("rsvd31: 0x%08x\n", $rsvd31));

    # rsvd3[2]                  
    my $rsvd32;
    read NVRAM, $rsvd32, 4;
    $rsvd32 = unpack "L", $rsvd32;
    logInfo(sprintf( "rsvd32: 0x%08x\n", $rsvd32));

    # rsvd3[3]
    my $rsvd33;
    read NVRAM, $rsvd33, 4;
    $rsvd33 = unpack "L", $rsvd33;
    logInfo(sprintf( "rsvd33: 0x%08x\n", $rsvd33));

    # rsvd3[4]                  
    my $rsvd34;
    read NVRAM, $rsvd34, 4;
    $rsvd34 = unpack "L", $rsvd34;
    logInfo(sprintf( "rsvd34: 0x%08x\n", $rsvd34));

    # hdrCksum                  
    my $hdrCksum;
    read NVRAM, $hdrCksum, 4;
    $hdrCksum = unpack "L", $hdrCksum;
    logInfo(sprintf( "hdrCksum: 0x%08x\n\n", $hdrCksum));

}



##############################################################################
#
#          Name: NvramDump
#
#        Inputs: controller object, data to print, format
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of misc functions.   
#
##############################################################################

sub NvramDump
{
    my ( $in_file,  $proc) = @_;

    my $nvr_file;
    my $blanks;
    my $rec_length;
    my $rec_type;
    my $rec_status;
    #open NVRAM, $in_file or die "Can't open file: $in_file";
    #binmode NVRAM;


    my $msg;
    my $buffer;
    my $string;
    my $length;
    my $ret;

    $ret = ReadFileToBuffer ($in_file, \$buffer, \$string);

    if ( $ret != GOOD)
    {
        logInfo($string);
        return ERROR;
    }

    $length = length $buffer;

    $ret = FmtNvramDump( \$msg, \$buffer, 0x7800, $length, $proc, 0 );
    
    logInfo($msg);

    logInfo("\n\n--------------------- END OF NVRAM DUMP ----------------------------------------\n");


    # the following is history

    return GOOD;

}



##############################################################################
#
#          Name: StatsCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of stats related functions.   
#
##############################################################################
sub StatsCommands
{
    trace();
    my ($ctlr) = @_;

    my %rtn;
    my $ret;
    my %rsp;
    my %info;
    my $i;
    my $r;
    my @vdisks;
    my $msg;


    logInfo("Altitude: #################  Statistics data #########################");

    ###################
    # envStats
    ###################

    %info = $ctlr->environmentalStatsExtended();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from environmentalStatsExtended <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from environmentalStatsExtended <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    #logEnvironmentalStats($ctlr, %info);
  
    $msg = $ctlr->displayEnvironmentalStatsExtended(%info);
    logInfo ($msg);



    my @serverIDs;
    
    # find SIDs based on wwn list
    @serverIDs = GetSIDs( $ctlr, 0);
    


    # the next line generates an error if no matching servers were found.
    # need to bail out in that case, or go into prompt mode.

    if ( INVALID == $serverIDs[0] )
    {
        logInfo(">>>>>>>> Failed to get server number(s) <<<<<<<<");
        return ERROR;
    }

    for ( $i = 0; $i < scalar(@serverIDs); $i++ )
    {

        ###################
        # STATSSERVER                # need a loop thru servers
        ###################

        logInfo("Getting statistics for server $serverIDs[$i]");
        %info = $ctlr->statsServer($serverIDs[$i]);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from statsServer <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            if ( $info{ERROR_CODE} == 0x2f )
            {
                logInfo("Not my server");
            }
            else
            {
                logInfo(">>>>>>>> Error from statsServer <<<<<<<<");
                PrintError(%info);
                return ERROR;
            }
        }

        if ( $info{STATUS} == PI_GOOD )      # if call returned an error
        {
            logStatsServer(%info);
        }
    }

    #
    # need an array of vdisk ids for the following
    #

    ######################
    # vdisk list
    ######################
 
    
    %rsp = $ctlr->getObjectList(PI_VDISK_LIST_CMD);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from PI_VDISK_LIST_CMD <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Virtual Disk List:");
    logObjectList(%rsp);
    # in here is my list of disks.. now how do i extract it?
    # need to build this array >>>> @vdisklistarray = @$vdisklist;       # make an array

    # put drives into an array
    for ( $r=0; $r< $rsp{COUNT}; $r++)
    {
        push  @vdisks, $rsp{LIST}[$r];
    }
     
#    $numVDDs = $rsp{COUNT};  # of drives available to map

    for ( $i = 0;  $i < scalar(@vdisks); $i++ )
    {
        ###################
        # STATSCACHEDEV              # need a loop thru vdisks
        ###################

        %info = $ctlr->statsCacheDevices($vdisks[$i]);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from statsCacheDevices <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from statsCacheDevices <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logStatsCacheDevices($vdisks[$i],%info);
    }

    ###################
    # STATSPCI
    ###################
    %info = $ctlr->statsPCI("BE");
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from statsPCI <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from statsPCI <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logStatsPCI("BE", %info);

    %info = $ctlr->statsPCI("FE");
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from statsPCI <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from statsPCI <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logStatsPCI("FE", %info);

    ###################
    # STATSPROC
    ###################


    %info = $ctlr->statsProc("BE");
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from statsProc <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from statsProc <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logStatsProc("BE", %info);


    %info = $ctlr->statsProc("FE");
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from statsProc <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from statsProc <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logStatsProc("FE", %info);

    ###################
    # STATSLOOP
    ###################

    my @option = ("BE", "FE");
    my $j;
    for my $i (0..1)
    {
        logInfo("Stats Loop ($option[$i]) :");
        %info = $ctlr->statsLoop($option[$i] );
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from statsLoop <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            if ( $info{ERROR_CODE} != $ctlr->PI_ERROR_INV_CHAN )
            {
                logInfo(">>>>>>>> Error from statsLoop <<<<<<<<");
                PrintError(%info);
                return ERROR;
            }
            else
            {
                logInfo("No card on channel ");
            }
        }
        else
        {
            logStatsLoop($option[$i], %info);
        }
    }


    ###################
    # STATSVDISK
    ###################

    %rsp = $ctlr->statsVDisk();     # get the initial reading
    
    if ( ! %rsp  )
    {
        logInfo("No response from statsVDisk");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("Error returned from statsVdisk ");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo  "Virtual Disk Statistics ($rsp{COUNT} disks):";
    logInfo  "";
    logInfo  " VID       RPS        AVGSC         RREQ           WREQ         SPRC        SPSC   ";
    logInfo  "-----  ----------  ----------  -------------  -------------  ----------  ----------";


    for (my $i = 0; $i < $rsp{COUNT}; $i++)
    {
        $msg = "";
        $msg .= sprintf "%5hu  ",  $rsp{VDISKS}[$i]{VID};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{RPS};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{AVGSC};
        $msg .= sprintf "%13s  ",  $rsp{VDISKS}[$i]{RREQ};
        $msg .= sprintf "%13s  ",  $rsp{VDISKS}[$i]{WREQ};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{SPRC};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{SPSC};
        logInfo($msg);
    }

    logInfo("");

    ###################
    #
    ###################


    ###################
    #
    ###################

    return GOOD;
}


##############################################################################
#
#          Name:  TargetList
#
#        Inputs:  $ctlr1
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: display 'targetstatus'
#
##############################################################################
sub TargetList
{
    trace();
    # disable cache in global config.

    my( $ctlr1 ) = @_;
    
    my %rsp;
    my $ret;
    logInfo("Altitude: ########### TARGETSTATUS #######################");

    logInfo("Target Status");
    
    ############ target status ###############

    %rsp = GetTargetStatus($ctlr1);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from targetStatus <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get target status <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    LogTargetStatus(%rsp);        # print it

    return GOOD;
}

##############################################################################
#
#          Name: GetTargetStatus
#
#        Inputs: controller object
#
#       Outputs: Hash with the data
#                INVALID  on error
#
#  Globals Used: none
#
#   Description: This function gets the TARGETSTATUS information from the
#                controller. The data is returned in a hash that matches that
#                used internally in the the CCBCL.
#
##############################################################################
sub GetTargetStatus
{
    my($ctlr) = @_;

    my $serverCount = 0;
    my $targetCount = 0;
    my @servers;
    my @targets;
    my %info1;
    my %info2;
    my %info3;
    my %info4;
    my $rc;
    my $i;
    my $j;
    my $k;

    # get all the targets
    %info1 = $ctlr->targetList();

    $rc = 1;
    
    $info4{STATUS} = PI_GOOD;
    $info4{ERROR_CODE} = 0;

    if (%info1)
    {
        if ($info1{STATUS} == PI_GOOD)
        {
            for $i (0..$#{$info1{LIST}})
            {
                #if (defined($tid))
                #{
                #    $info1{LIST}[$i] = $tid;
                #}
                    
                %info2 = $ctlr->targetInfo($info1{LIST}[$i]);
                if (%info2)
                {
                    if ($info2{STATUS} == PI_GOOD)
                    {
                        $targets[$targetCount]{STATUS_MRP}  = $info2{STATUS_MRP};
                        $targets[$targetCount]{LEN}         = $info2{LEN};
                        $targets[$targetCount]{TGD_TID}     = $info2{TGD_TID};
                        $targets[$targetCount]{TGD_CHAN}    = $info2{TGD_CHAN};
                        $targets[$targetCount]{TGD_OPT}     = $info2{TGD_OPT};
                        $targets[$targetCount]{TGD_ID}      = $info2{TGD_ID};
                        $targets[$targetCount]{TGD_POWNER}  = $info2{TGD_POWNER};
                        $targets[$targetCount]{TGD_OWNER}   = $info2{TGD_OWNER};
                        $targets[$targetCount]{TGD_CLUSTER} = $info2{TGD_CLUSTER};
                        $targets[$targetCount]{TGD_PNAME}   = $info2{TGD_PNAME};
                        $targets[$targetCount]{TGD_PNAME_LO}= $info2{TGD_PNAME_LO};
                        $targets[$targetCount]{TGD_PNAME_HI}= $info2{TGD_PNAME_HI};
                        $targets[$targetCount]{TGD_NNAME}   = $info2{TGD_NNAME};
                        $targets[$targetCount]{TGD_NNAME_LO}= $info2{TGD_NNAME_LO};
                        $targets[$targetCount]{TGD_NNAME_HI}= $info2{TGD_NNAME_HI};
                        $targetCount++;
 
                        #if (defined($tid))
                        #{
                        #    last;
                        #}
                    }
                    else
                    {
                        $rc = 0;
                        logInfo( "error getting target info");
                        $info4{STATUS} = $info2{STATUS};
                        $info4{ERROR_CODE} = $info2{ERROR_CODE};
                    }
                }
                else
                {
                    $rc = 0;
                }
            }
        }
        else
        {
            $rc = 0;
            logInfo( "error getting target list");
            $info4{STATUS} = $info1{STATUS};
            $info4{ERROR_CODE} = $info1{ERROR_CODE};
        }
    }
    else
    {
        $rc = 0;
    }
    
    if ($rc)
    {
        
        %info1 = $ctlr->serverList();
    }
    
    if (%info1 && $rc)
    {
        if ($info1{STATUS} == PI_GOOD)
        {
            for $i (0..$#{$info1{LIST}})
            {
                #print "getting server info on $i \n";
                %info2 = $ctlr->serverInfo($info1{LIST}[$i]);
                if (%info2)
                {
                    if ($info2{STATUS} == PI_GOOD)
                    {
                        $servers[$serverCount]{STATUS_MRP}  = $info2{STATUS_MRP};
                        $servers[$serverCount]{LEN}         = $info2{LEN};
                        $servers[$serverCount]{SID}         = $info2{SID};
                        $servers[$serverCount]{NLUNS}       = $info2{NLUNS};
                        $servers[$serverCount]{TARGETID}    = $info2{TARGETID};
                        $servers[$serverCount]{SSTATUS}     = $info2{SSTATUS};
                        $servers[$serverCount]{PRI}         = $info2{PRI};
                        $servers[$serverCount]{ATTRIB}      = $info2{ATTRIB};
                        $servers[$serverCount]{SESSION}     = $info2{SESSION};
                        $servers[$serverCount]{OWNER}       = $info2{OWNER};
                        $servers[$serverCount]{LUNMAP}      = $info2{LUNMAP};
                        $servers[$serverCount]{REQCNT}      = $info2{REQCNT};
                        $servers[$serverCount]{WWN}         = $info2{WWN};
                        $servers[$serverCount]{WWN_HI}      = $info2{WWN_HI};
                        $servers[$serverCount]{WWN_LO}      = $info2{WWN_LO};
                        $serverCount++;
                    }
                    else
                    {
                        $rc = 0;
                        logInfo( "error getting server info");
                        $info4{STATUS} = $info2{STATUS};
                        $info4{ERROR_CODE} = $info2{ERROR_CODE};
                    }
                }
                else
                {
                    $rc = 0;
                }
            }
        }
        else
        {
            $rc = 0;
            logInfo( "error getting server list");
            $info4{STATUS} = $info1{STATUS};
            $info4{ERROR_CODE} = $info1{ERROR_CODE};
        }
    }

    #print "\ntargets:\n";
    #print @targets;
    #print "\nservers:\n";
    #print @servers;
    #print "done\n";

    $info4{SERVERS} = \@servers;
    $info4{TARGETS} = \@targets;

    return %info4;


}


##############################################################################
#
#          Name: LogTargetStatus
#
#        Inputs: targetStatus hash
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: This function just prints the targetstatus hash.
#
##############################################################################
sub LogTargetStatus
{
    my (%info) = @_;

    my $targetCount;
    my @targets;
    my @servers;
    my $i;
    my $j;
    my $k;
    my $msg;
    my $linecount;

    my $targPtr = $info{TARGETS};
    my $servPtr = $info{SERVERS};
    
    @targets = @$targPtr;
    @servers = @$servPtr;

    #print "\ntargets:\n";
    #print @targets;
    #print "\nservers:\n";
    #print @servers;

    logInfo("\n");

    $targetCount = scalar(@targets);

    # print @targets;

    # now print the stuff to the log

    logInfo( " TID  Channel   Owner       Port WWN      SID        WWN         LUN  VID ");
    logInfo( " ---  -------  -------  ----------------  ---  ----------------  ---  --- ");
    for ($i = 0; $i < $targetCount; ++$i)
    {
        $msg = "";
        #print " i = $i, \n";
        $msg .= sprintf( " %2hu     %3lu    %6lu   %8.8x%8.8x",
                                      $targets[$i]{TGD_TID}, 
                                      $targets[$i]{TGD_CHAN}, 
                                      $targets[$i]{TGD_OWNER},
                                      $targets[$i]{TGD_PNAME_LO},
                                      $targets[$i]{TGD_PNAME_HI});
        $linecount = 0;
               
        for ($j = 0; $j < scalar(@servers); ++$j)
        {
            if ($targets[$i]{TGD_TID} == $servers[$j]{TARGETID})
            {
                if ($linecount++ >= 0)
                {
                    logInfo($msg);
                    $msg = "                                        ";
                }
                $msg .= sprintf( "  %2hu   %8.8x%8.8x", 
                                              $servers[$j]{SID}, 
                                              $servers[$j]{WWN_LO}, 
                                              $servers[$j]{WWN_HI});  
                
                if ($servers[$j]{NLUNS} > 0)
                {
                    for ($k = 0; $k < $servers[$j]{NLUNS}; ++$k)
                    {
                        if ($k > 0)
                        {
                            logInfo($msg);
                            $msg = "                                                               ";
                        }
                        $msg .= sprintf( "   %2hu  %3hu", 
                                                $servers[$j]{LUNMAP}[$k]{LUN},
                                                $servers[$j]{LUNMAP}[$k]{VID});
                    }
                }   
            }
        }
        logInfo($msg);
        logInfo(""); 
    }
    logInfo("");
}


##############################################################################
#
#          Name: GetPowerUpState
#
#        Inputs: Controller object
#
#       Outputs: state, or INVALID on error
#
#  Globals Used: none
#
#   Description: Gets power up state, this is somewhat bitmapped.   
#                Caller should check against INVALID before testing
#                the bits.
#
##############################################################################
sub GetPowerUpState
{
    trace();
    my ($ctlr) = @_;
    my %rsp;
    my $msg;

    %rsp = $ctlr->powerUpState();
    
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from powerUpState <<<<<<<<");
        return INVALID;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve Power Up State. <<<<<<<<");
        PrintError(%rsp);
        return INVALID;
    }

    $msg = "Power-up State: ";
    $msg .= XIOTech::cmdMgr::_getString_POWERUP($rsp{STATE});

    logInfo($msg ); 

    return $rsp{STATE};
}


##############################################################################
#
#          Name: DeviceStatus
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes DEVSTAT function with its options.   
#
##############################################################################
sub DeviceStatus
{
    trace();
    my ($ctlr) = @_;

    logInfo("Altitude: ############ DEVSTAT PD RD VD #######################");

    my $i;
    my $rc = 1;
    my %rsp;
    my $swtch;
    my @arr_dev;
    $arr_dev[0] = "VD";
    $arr_dev[1] = "RD";
    $arr_dev[2] = "PD";

    for $i (0..2)
    {
        ######################
        # device status
        ######################
 

        %rsp = $ctlr->deviceStatus($arr_dev[$i]);
        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from deviceStatus <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from deviceStatus <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
       
        logInfo("Printing device status for ($arr_dev[$i]):");
        logDeviceStatus($arr_dev[$i], "N", %rsp);
        logDeviceStatus($arr_dev[$i], "S", %rsp);
    }

    logInfo("Completed testing device status operations");

    return GOOD;
}






##############################################################################
#
#          Name: DispVdiskInfo
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################


sub DispVdiskInfo
{
    trace();
    my ($ctlr1) = @_;

    my %rsp;
    my $i;
    my $r;
    my @ar;
    my $vdisklist;
    my @vdisklistarray;
    my $numVDDs;
    my $ap;
    my %vd;
    my %info;

    logInfo("Altitude: ############ VDISKS #######################");

    %rsp = $ctlr1->virtualDisks();

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks <<<<<<<<");
        return ERROR;
    }

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            if ($rsp{COUNT} > 0)
            {
                logVirtualDisks(%rsp);
            }
            else
            {
                logInfo("No virtual disks present");
            }
        }
        else
        {
            logInfo(">>>>>>>> Unable to retrieve  virtual disk information. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }

    
    #####################
    # VDISK information
    #####################


    for (my $i = 0; $i < $rsp{COUNT}; $i++)
    {
        logInfo("Get Vdisk Information for vdisk ".$rsp{VDISKS}[$i]{VID}."  ");

        %info = $ctlr1->virtualDiskInfo($rsp{VDISKS}[$i]{VID});
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logVirtualDiskInfo(%info);

    }


    return GOOD;
}

##############################################################################
#
#          Name: BeDevPaths
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################
sub BeDevPaths
{
    trace();

    my ($ctlr1) = @_;

    my %rsp;
    my $realFormat;
    my $realType;
    my $i;
    my $msg;

    logInfo("Altitude: ########## BE Device path information #######################");


    $realFormat = $ctlr1->FORMAT_PID_PATH_ARRAY;

    for  $realType ( $ctlr1->PATH_PHYSICAL_DISK,
                     $ctlr1->PATH_MISC_DEVICE, 
                     $ctlr1->PATH_ENCLOSURES  )
    {


        %rsp = $ctlr1->beDevicePaths($realType, $realFormat);

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get vcginfo from master <<<<<<<<");
            return (ERROR);
        }

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                #$ctlr1->displayDevicePath(%rsp);

                if ($rsp{SIZE} == 8)
                {
                    logInfo("  PID   COUNT  PATH[0]  PATH[1]  PATH[2]  PATH[3]");
                    logInfo(" -----  -----  -------  -------  -------  -------");
                    for ($i = 0; $i < $rsp{NDEVS}; ++$i)
                    {
                        logInfo(sprintf( " %04X   %04X     %02X       %02X       %02X       %02X", 
                            $rsp{LIST}[$i]{PID},
                            $rsp{LIST}[$i]{PATH_COUNT},
                            $rsp{LIST}[$i]{PATH1},
                            $rsp{LIST}[$i]{PATH2},
                            $rsp{LIST}[$i]{PATH3},
                            $rsp{LIST}[$i]{PATH4}));
                    }
                }
                else
                {
                    logInfo("  PID   BIT_PATH ");
                    logInfo(" -----  -------- ");
                    for ($i = 0; $i < $rsp{NDEVS}; ++$i)
                    {
                        logInfo(sprintf (" %04X     %04X", 
                            $rsp{LIST}[$i]{PID},
                            $rsp{LIST}[$i]{BIT_PATH}));
                    }
                }




            }
            else
            {
                logInfo(">>>>>>>> Error getting vcginfo from master <<<<<<<<");
                PrintError(%rsp);
            }
        }

    }


    return GOOD;
}
    
    


##############################################################################
#
#          Name: DispVcgInfo
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################
sub DispVcgInfo
{
    trace();

    my ($ctlr1) = @_;

    my %vcginfo;

    ########### vcginfo ################

    # get information from the master controller
    logInfo("Altitude: ########## VCG information #######################");

    %vcginfo = $ctlr1->vcgInfo(0);

    if ( ! %vcginfo  )
    {
        logInfo(">>>>>>>> Failed to get vcginfo from master <<<<<<<<");
        return (ERROR);
    }

    if (%vcginfo)
    {
        if ($vcginfo{STATUS} == PI_GOOD)
        {
            logVCGInfo(%vcginfo);
        }
        else
        {
            logInfo(">>>>>>>> Error getting vcginfo from master <<<<<<<<");
            PrintError(%vcginfo);
        }
    }
    return GOOD;
}
##############################################################################
#
#          Name: DeviceList
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################
sub DeviceList
{
    trace();

    my ($ctlr1) = @_;
    my $i;
    my $j;
    my $type;
    my $flag = 0;
    
    my %rsp;


    # get information from the master controller
    logInfo("Altitude: ########## Device List #######################");

    my @proc = ("BE", "FE");

    for ($i = 0; $i < 2; $i++ )
    {

        $type = $proc[$i];

        for ( $j = 0; $j < 4; $j++ )
        {
            if ( $proc[$i] eq "FE" )
            {
                # Validate port and check if it is ISCSI or FC based on which devicelist 
                # values are retrieved
                
                &TestLibs::iscsi::ValidateTargetType ($ctlr1, $j, \$flag);
            }

            if ( ($flag == 1) || ($proc[$i] eq "BE" ) )
            { 
            logInfo("----------------------------------------------------------------");
            %rsp = $ctlr1->deviceList($type, $j);

            if ( ! %rsp  )
            {
                logInfo(">>>>>>>> Failed to get device list info <<<<<<<<");
                return (ERROR);
            }

            if (%rsp)
            {
                if ($rsp{STATUS} == PI_GOOD)
                {
                    logInfo("Device list for ".$type." processor, port ".$j."   ");
                    dispDeviceList(%rsp);
                }
                else
                {
                    logInfo(">>>>>>>> Error getting device list (proc = ".$type." chan = ".$j."  <<<<<<<<");
                    PrintError(%rsp);
                    logInfo("Continuing...");
                    }
                }
            }
        }
    }
    return GOOD;
}
##############################################################################
# Name: dispDeviceList
#
# Desc: print the device list information
#
# In:   device list Information Hash
##############################################################################
sub dispDeviceList
{
    my ( %info) = @_;

    
    logInfo("");
    logInfo("Device List Count: $info{NDEVS}\n\n"); 
    
    my $i;
    logInfo("  LID   MST  SST  PORT_ID       PORT_WWN            NODE_WWN  ");
    logInfo(" -----  ---  ---  -------  ------------------  ------------------ ");
    for ($i = 0; $i < $info{NDEVS}; ++$i)
    {
        logInfo(sprintf ("  %02X    %02X   %02X   %06X    %8.8x%8.8x    %8.8x%8.8x\n", 
            $info{LIST}[$i]{LID},
            $info{LIST}[$i]{MST},
            $info{LIST}[$i]{SST},
            $info{LIST}[$i]{PORT_ID},
            $info{LIST}[$i]{PORT_WWN_LO},
            $info{LIST}[$i]{PORT_WWN_HI},
            $info{LIST}[$i]{NODE_WWN_LO},
            $info{LIST}[$i]{NODE_WWN_HI} ));
    }
}

##############################################################################
#
#          Name: PrintError
#
#        Inputs: ret (hash returned from a command)
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: Just prints the error fields in a has. This is frequently 
#                used code.   
#
#
##############################################################################
sub PrintError
{
    trace();
    my (%ret) = @_;

    logInfo(sprintf("Status Code: 0x%02x\n", $ret{STATUS}));

    if (defined($ret{STATUS_MSG}))
    {
        logInfo("$ret{STATUS_MSG}");
    }
    logInfo(sprintf("Error Code: 0x%02x ", $ret{ERROR_CODE}));
 
    if (defined($ret{ERROR_MSG}))
    {
        logInfo($ret{ERROR_MSG});
    }
    return;
}



##############################################################################
#
#          Name: PhysicalDiskCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of PDD related functions   
#
#
##############################################################################
sub PhysicalDiskCommands
{
    trace();
    my ($ctlr) = @_;

    my %rsp;
    my %info;
    my $i;
    my $id;
    my $ret;
    my $dur;

    logInfo("Altitude: ######### physical disk data ############################");

    #######################
    #  RESCAN DEVICE  (BE)
    #######################
    
#    $ret = RescanBE( $ctlr );          
#    if( $ret == ERROR )
#    {
#        logInfo(">>>>>>>> Failed to rescan drives. <<<<<<<<");
#        return (ERROR);
#    }
    
    ###############
    #  PDISKCOUNT
    ###############
    
    %rsp = $ctlr->physicalDiskCount();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDiskCount <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to physicalDiskCount <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Physical Disk Count: $rsp{COUNT}");

    #############
    #  PDISKLIST
    #############

    %rsp = $ctlr->physicalDiskList();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDiskList <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to physicalDiskList <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    my $str = "Physical Disk List:";

    for $i (0..$#{$rsp{LIST}})
    {
        $str .=  " " . $rsp{LIST}[$i];
    }

    logInfo($str);
    
    #
    # we do the following for each physical drive
    #
    
    for $i (0..$#{$rsp{LIST}})
    {
        logInfo("Testing physical disk $rsp{LIST}[$i]");
        $id = $rsp{LIST}[$i];


        ##############
        #  PDISKINFO
        ##############
        logInfo("Retrieving physical disk information for each disk");
        %info = $ctlr->physicalDiskInfo($id);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskInfo <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to physicalDiskInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logPhysicalDiskInfo(%info);
    }


    #############
    #  PDISKS
    #############
    logInfo("Physical Disks Command");
    %info = $ctlr->physicalDisks();
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDisks <<<<<<<<");
        return ERROR;
    }
    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get physicalDisks info <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logPhysicalDisks("STD", %info);


    logInfo("Completed testing physical disk operations");

    return GOOD;
}

##############################################################################
#
#          Name: RescanBE
#
#        Inputs: controllerID
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Rescans the back end to see if the status of the drives has 
#                changed, This makes sure we are dealing with current 
#                information.  
#
#
##############################################################################
sub RescanBE
{
    trace();
    my ($ctlr) = @_;
    my %rsp;

    debug("Scanning the drives");

    %rsp = $ctlr->rescanDevice("LIST");
    
    if ( ! %rsp  )
    {
        logInfo(">>>>> No response rescanning the BE <<<<<");
        return (ERROR);
    }

    if ( $rsp{STATUS} != PI_GOOD )
    {
        logInfo(">>>>> Failed to rescan the drives <<<<<");
        
        PrintError(%rsp);

        return (ERROR);
    }

    return (Wait4Ses($ctlr, 45));
}





##############################################################################
#
#          Name: DiskBayCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of disk bay related functions   
#
#
##############################################################################


sub DiskBayCommands
{
    trace();
    my ($ctlr) = @_;

    my %rsp;
    my %info;
    my $i;

    logInfo("Altitude: ##############  disk bay data #########################");

    ###################
    # disk bay count
    ###################
    %rsp = $ctlr->diskBayCount();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from diskBayCount <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get disk bay count <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Disk Bay Count: " . $rsp{COUNT});



    ###################
    # disk bay list
    ###################
    %rsp = $ctlr->diskBayList();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from diskBayList <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get disk bay list <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    my $str = "Disk Bay List:";

    for $i (0..$#{$rsp{LIST}})
    {
        $str .= "  " . $rsp{LIST}[$i] ;
    }
    logInfo($str);

    #######################
    # disk bay information
    #######################
    logInfo("Retrieving disk bay information for each bay");

    for $i (0..$#{$rsp{LIST}})
    {
        my $id = $rsp{LIST}[$i];
        my %info = $ctlr->diskBayInfo($id);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from diskBayInfo <<<<<<<<");
            return ERROR;
        }

        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to get disk bay info <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logDiskBayInfo(%info);     # this shouldn't have problems
    }

    ##############
    # disk bays
    ##############
    logInfo("DiskBays Command");
    %info = $ctlr->diskBays();
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from diskBays <<<<<<<<");
        return ERROR;
    }
    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get diskBay info <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logDiskBays( %info);


    ###################
    # disk bay status
    ###################

    %rsp = DiskBaySts($ctlr);
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from diskBayStatus <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get diskBayStatus <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Completed testing disk bay operations");
    return GOOD;
}

##############################################################################
# Name:     DiskBaySts
#
# Desc:     display diskbay Status.
#
# In:       NONE
#
# Returns:
##############################################################################
sub DiskBaySts
{
    my ($ctlr) = @_;

    my %bays;
    my %disks;
    my @sortBays;
    my @sortDisks;
    my @pdisks;
    my @dbays;
    my $msg;
    
    logInfo("");

    %bays = $ctlr->diskBays();

    if (%bays)
    {
        if ($bays{STATUS} == PI_GOOD)
        {
            %disks = $ctlr->physicalDisks();

            if (%disks)
            {
                if ($disks{STATUS} == PI_GOOD)
                {
                    my $i;
                    my $j;
                
                    for ($i = 0; $i < $bays{COUNT}; ++$i)
                    {
                        
                        
                        $dbays[$i]{PD_PID} = $bays{BAYS}[$i]{PD_BID};
                        $dbays[$i]{WWN_HI} = $bays{BAYS}[$i]{WWN_HI};
                        $dbays[$i]{WWN_LO} = $bays{BAYS}[$i]{WWN_LO};
                        $dbays[$i]{PD_REV} = $bays{BAYS}[$i]{PD_REV};
                        my $count = 0;
                        for ($j = 0; $j < $disks{COUNT}; ++$j)
                        {



                            if($bays{BAYS}[$i]{PD_BID} == $disks{PDISKS}[$j]{SES})
                            {

                                $pdisks[$i][$count]{PD_PID} = $disks{PDISKS}[$j]{PD_PID};
                                $pdisks[$i][$count]{WWN_HI} = $disks{PDISKS}[$j]{WWN_HI};
                                $pdisks[$i][$count]{WWN_LO} = $disks{PDISKS}[$j]{WWN_LO};
                                $pdisks[$i][$count]{SLOT} = $disks{PDISKS}[$j]{SLOT};
                              #  $pdisks[$i][$count]{OSLOT} = $disks{PDISKS}[$j]{OSLOT};
                                $count++;
                            }
                        }



                        $dbays[$i]{PD_COUNT} = $count;
                        $dbays[$i]{PDISKS} = $pdisks[$i];



                    }


                    my $i2;
                    my $j2 = -1;
                    my $loc = 0;
                    for ($i = 0; $i < $bays{COUNT}; ++$i)
                    {

                        $i2 = 9999999;
                        for ($j = 0; $j < $bays{COUNT}; ++$j)
                        {

                            if($dbays[$j]{PD_PID} < $i2 && $dbays[$j]{PD_PID} > $j2)
                            {
                                $loc = $j;
                                $i2 = $dbays[$j]{PD_PID};
                            }
                        }


                        $sortBays[$i] = $dbays[$loc];

                        $j2 = $i2;
                        
                        my $k;
                        my $k1;
                        my $l;
                        my $l1 = -1;
                        my $loc1;


                        for ($k = 0; $k < $sortBays[$i]{PD_COUNT}; ++$k)
                         {



                            $k1 = 9999999;
                            for ($l = 0; $l < $sortBays[$i]{PD_COUNT}; ++$l)
                            {

                                if($sortBays[$i]{PDISKS}[$l]{SLOT} < $k1 && $sortBays[$i]{PDISKS}[$l]{SLOT} > $l1)
                                {
                                    $loc1 = $l;
                                    $k1 = $sortBays[$i]{PDISKS}[$l]{SLOT};
                                }
                            }



                            $pdisks[$k] = $sortBays[$i]{PDISKS}[$loc1];
                            $l1 = $k1;
                        }


                        $sortBays[$i]{PDISKS} = [@pdisks];
                    }
                    
                    logInfo(" BayID       BayWWN      BayRev  PDiskSlot    PDiskID       PDiskWWN");
                    logInfo("------- ---------------- ------ ----------- ----------- ------------------");
                    
                    for ($i = 0; $i < $bays{COUNT}; ++$i)
                    {
                        $msg =sprintf( " %3d    %8.8x%8.8x  %3s", 
                                                          $sortBays[$i]{PD_PID}, 
                                                          $sortBays[$i]{WWN_LO},
                                                          $sortBays[$i]{WWN_HI},
                                                          $sortBays[$i]{PD_REV});
                    
                        for ($j = 0; $j < $sortBays[$i]{PD_COUNT}; ++$j)
                        {
                            if ($j > 0)
                            {
                                $msg = "                              ";
                            }
                            $msg .= sprintf ("     %3d         %3d       %8.8x%8.8x", 
                                                                     $sortBays[$i]{PDISKS}[$j]{SLOT},
                                                                     $sortBays[$i]{PDISKS}[$j]{PD_PID},
                                                                     $sortBays[$i]{PDISKS}[$j]{WWN_LO},
                                                                     $sortBays[$i]{PDISKS}[$j]{WWN_HI});
                            logInfo($msg);
                            $msg = "";
                        }
                        logInfo($msg);
                    }
                }
                else
                {
                    return %disks;
                }
            }
            else
            {
                return ;
            }    
            
        }
        else
        {
            return %bays;
        }
    }
    else
    {
        return ;
    }
    
    return %bays;
}


##############################################################################
#
#          Name: LoggingTest
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of misc functions.   
#
##############################################################################
sub LoggingTest
{
    trace();
    my ($ctlr) = @_;

    logInfo("Altitude: #############  Controller Logs - last 1000 entries #######################");

    my $rc = 1;
    my %rsp;
    my %i;


    ######################
    # LOG INFO
    ######################


    %rsp = $ctlr->logInfo(1000, 0x12, 0);
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from logInfo <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from logInfo <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }
     

    logLogInfo(2, 0, %rsp);

    #logInfo("Completed testing logging operations");

    return GOOD;
}



##############################################################################
#
#          Name: GPFidRead
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################
sub GPFidRead
{
    trace();
    my ($ctlr) = @_;
    
    my %data;


    ###################
    # FID READ
    ###################
    
    logInfo("Reading file system (may be slow)");

    %data = $ctlr->ReadFID(2);
    if ( ! %data  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from ReadFID <<<<<<<<");
        return ERROR;
    }
    if ( $data{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from ReadFID <<<<<<<<");
        PrintError(%data);
        return ERROR;
    }

    # After data read up, format it appropriately.
    $ctlr->FormatData($data{RD_DATA}, 0, "byte", undef, 1024);



    return GOOD;


}



##############################################################################
#
#          Name: FindQL
#
#        Inputs: Controller object, processor
#
#       Outputs: QL list array if OK, INVALID as 1st member on failure
#
#  Globals Used: none
#
#   Description: Find the valid QL cards on the specific proc   
#
#
##############################################################################

sub FindQL
{
    trace();
    my ($ctlr, $proc ) = @_;

    my @List;
    my $commandCode;
    my %rsp;
    my $i;
    my $count;

    if ($proc eq "BE")
    {
        $commandCode = PI_PROC_BE_PORT_LIST_CMD;
    }
    elsif ($proc eq "FE")
    {
        $commandCode = PI_PROC_FE_PORT_LIST_CMD;
    }
    else
    {
        logInfo(">>>>>>>> UNDEFINED COMMAND CODE $proc <<<<<<<<");
    }

    %rsp = $ctlr->getPortList($commandCode, 0);

    if (%rsp)
    {
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error getting QL list <<<<<<<<");
            PrintError(%rsp);
            push ( @List, INVALID);
            return @List;
        }
    }
    else
    {
        logInfo(">>>>>>>> Did not receive a response packet (getPortList) <<<<<<<<");
        push ( @List, INVALID);
        return @List;
    }

    $count = 0;
    for $i (0..$#{$rsp{LIST}})
    {
        push ( @List, $rsp{LIST}[$i] );
        $count++;
    }

    if ( $count < 1 )
    {
        logInfo(">>>>>>>> No QL cards were seen <<<<<<<<");
        push ( @List, INVALID);
        return @List;
    }  
    
    # must be good
    logInfo("Found these QL cards @List");
    return @List;
}


##############################################################################
#
#          Name: PortList
#
#        Inputs: controller object for master, sample duration
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub PortList
{
    my ($ctlr, $proc) = @_;

    my %rsp;
    my $i;
    my $j;
    my @mx;
    my $sz;
    my $commandCode;

    logInfo("Altitude: ######################## ".$proc." PORT List #######################");
    for ( $i = 0; $i < 4; $i++ )
    {
        # clear mx array
        $mx[$i] = 0;
    }
    
    if ($proc eq "BE")
    {
        $commandCode = PI_PROC_BE_PORT_LIST_CMD;
    }
    elsif ($proc eq "FE")
    {
        $commandCode = PI_PROC_FE_PORT_LIST_CMD;
    }


    for ( $i = 0; $i < 6; $i++ )
    {
        
        %rsp = $ctlr->getPortList($commandCode, $i);

        if ( ! %rsp )
        {
            # no response
            return ERROR;
        }
        elsif ($rsp{STATUS} == 1)             # 1 is bad
        {
            logInfo(">>>>>>>> Failed: getPortList returned an error <<<<<<<<");
            PrintError(%rsp);
            logInfo("Failure in FEPortMatrix");
            return ERROR;
        }

        $sz = 1 + $#{$rsp{LIST}};

        #print "list type, = $i, size = $sz \n";

        for ( $j = 0; $j< $sz; $j++ )
        {
            
            #print "list has $rsp{LIST}[$j] \n";

            $mx[$rsp{LIST}[$j]] |= 1 << $i;
        }
    }

    
    my $msg = $proc." QL: ";
    for ( $i = 0; $i < scalar(@mx); $i++ ) 
    {
        $msg .= sprintf("%02x ", $mx[$i]);
    }
    logInfo($msg);

    return GOOD;
}



##############################################################################
#
#          Name: GetSIDs
#
#        Inputs: controller, startSID
#
#       Outputs: and array of SIDs, INVALID otherwise
#
#  Globals Used: none
#
#   Description: Lists the servers starting at startSID to allow the user
#                to select SIDs for associating.    
#
#    How called: $ret = ListSIDs($master, 0);
#
##############################################################################
sub GetSIDs
{
    trace();
    my $numSIDs;
    my @SIDarray;
    my $r;
    my $sWWN;
    my @sidList;

    my ($controller, $startSID) = @_;

    # get list of servers (serverlist)
    my %rsp = $controller->getObjectList(PI_SERVER_LIST_CMD);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            debug("Got server list successfully");
        }
        else
        {
            logInfo(">>>>> Failed to get server list <<<<<");
            PrintError(%rsp);
            push (@sidList, INVALID); 
            return @sidList;
        }
    }
    else
    {
        logInfo("Did not receive a response packet getting server list");
        push (@sidList, INVALID); 
        return @sidList;
    }

    debug("serverlist info    " . %rsp);

    $numSIDs = $rsp{COUNT};

    for ( $r=0; $r < $numSIDs; $r++ )
    {
        push @SIDarray, $rsp{LIST}[$r];
    }

    debug("this many sids: $numSIDs, here they are @SIDarray");

    # bounds check startSID (can be past end of SID list) 
    if ( $numSIDs <= $startSID )
    {
        # return 'no match'
        push (@sidList, INVALID); 
        return @sidList;
    }
    # for each SID

    debug("sid scan fron  $startSID  to  $numSIDs");
    
    for ( $r = $startSID; $r < $numSIDs; $r++ )
    {
        # do serverinfo
        %rsp = $controller->serverInfo($r);
    
        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                debug("Got server info $r successfully");
            }
            else
            {
                logInfo(">>>>> Failed to get server info $r <<<<<");
                PrintError(%rsp);
                push (@sidList, INVALID); 
                return @sidList;
            }
        }
        else
        {
            logInfo("Did not receive a response packet getting server info $r");
            push (@sidList, INVALID); 
            return @sidList;
        }
        debug("server info    " . %rsp);

        logInfo(sprintf " Server(SID) %3d has WWN %8.8x%8.8x  (TID=%3d)", $r, 
                $rsp{WWN_LO}, $rsp{WWN_HI},  $rsp{TARGETID});

        push (@sidList, $r); 
    }
        
    # ran out of SIDs, done
    return @sidList;
}

##############################################################################
# Get Trace Info                                                          
##############################################################################
sub getTrace
{
    my($obj, $outfile) = @_;


    my %rsp = $obj->generic2Command("TRACE");

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {

            print "Writing trace data to $outfile ...\n";
            my $rc = open OF, ">$outfile";
            if (!$rc) {
                print "Couldn't open $outfile ...\n";
            }
            else {
                binmode OF;
                print OF $rsp{DATA};
                close OF;
            }
        }
    }

}



##############################################################################
#
#          Name: GetGroupSerial
#
#        Inputs: controller
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  serial number of VCG is returned.  
#
#
##############################################################################
sub GetGroupSerial
{
    trace();
    my ($ctlr) = @_;

    my %rsp;

    logInfo("Altitude: ##################  controller serial numbers ######################");

    %rsp = $ctlr->serialNumGet();

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get the controller's serial number <<<<<");
        return ERROR;
    }
    else
    {
        if ( $rsp{STATUS} == PI_GOOD )
        {
 
            logInfo(" serialnumbers:\n         GROUP: ".$rsp{2}{SERIAL_NUM}." \n    controller: " .$rsp{1}{SERIAL_NUM} ." \n");
            return GOOD;

        }
        else
        {
            logInfo(">>>>> Failed get serial number from controller <<<<<");
            return ERROR;
        }
    }
}


##############################################################################
#
#          Name: CCBErrorSnapshotDecoder
#
#        Inputs: buffer
#
#       Outputs: formatted string
#
#  Globals Used: none
#
#   Description: Decodes a portion of the CCB NVRAM.  This is legacy stuff
#                to support BFDump.  Its life is short...
#
#
##############################################################################
sub CCBErrorSnapshotDecoder
{
    my ($buffer) = @_;
    my $outStr = "";
    my @dayNames = ("Not Set","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
    my $unpackString = "";

    ##
    # Build the unpack string for the data to be decoded
    ##
    $unpackString .= "SCCCCCCL";                            # TIMESTAMP timestamp
    $unpackString .= "A4A4A4SCCCCCC";                       # FW_DATA firmwareRevisionData
    $unpackString .= "LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL";    # ERRORTRAP_DATA_CPU_REGISTERS cpuRegisters
    $unpackString .= "CCCCCCCC";                            # MACH machRegisters
    $unpackString .= "CCCCCCCC";                            # UINT8 machRegistersPad[]
    $unpackString .= "C";                                   # ERRORTRAP_DATA_I960_TRACE_REGISTERS traceRegisters (8-bit)
    $unpackString .= "CCCCCCCCCCCCCCC";                     # ERRORTRAP_DATA_I960_TRACE_REGISTERS traceRegisters.reserved0 (padding) 
    $unpackString .= "SSSSSSSSS";                           # ERRORTRAP_DATA_I960_TRACE_REGISTERS traceRegisters (16-bit)
    $unpackString .= "CCCCCCCCCCCCCC";                      # ERRORTRAP_DATA_I960_TRACE_REGISTERS traceRegisters.reserved1 (padding)
    $unpackString .= "LLLLLLLLLLLLLLLLLLLLL";               # ERRORTRAP_DATA_I960_TRACE_REGISTERS traceRegisters (32-bit)
    $unpackString .= "CCCCCCCCCCCC";                        # ERRORTRAP_DATA_I960_TRACE_REGISTERS traceRegisters.reserved2 (padding)

#   TIMESTAMP timestamp;
#     UINT16  year;
#     UINT8   month;
#     UINT8   date;
#     UINT8   day;
#     UINT8   hours;
#     UINT8   minutes;
#     UINT8   seconds;
#     UINT32  systemSeconds;
    my ($traceYear, $traceMonth, $traceDate, $traceDay, $traceHours, $traceMinutes, $traceSeconds, $traceSystemSeconds,
#  FW_DATA firmwareRevisionData;
#    UINT32 revision;
#    UINT32 revCount;
#    UINT32 buildID;
#    FW_HEADER_TIMESTAMP timeStamp;
#      UINT16 year;
#      UINT8  month;
#      UINT8  date;
#      UINT8  day;
#      UINT8  hours;
#      UINT8  minutes;
#      UINT8  seconds;
        $fwRevision, $fwRevCount, $fwBuildID, $fwYear, $fwMonth, $fwDate, $fwDay, $fwHours, $fwMinutes, $fwSeconds,
#   ERRORTRAP_DATA_CPU_REGISTERS cpuRegisters;
#     UINT32 rRegisters[16];
#     UINT32 gRegisters[16];
        $r0, $r1, $r2, $r3, $r4, $r5, $r6, $r7, $r8, $r9, $r10, $r11, $r12, $r13, $r14, $r15,
        $g0, $g1, $g2, $g3, $g4, $g5, $g6, $g7, $g8, $g9, $g10, $g11, $g12, $g13, $g14, $g15,
#   MACH machRegisters;
#     UINT8 systemStatus0;
#     UINT8 diagSwitchesStatus;
#     UINT8 flashSwitchesStatus;
#     UINT8 boardMachRevStatus;
#     UINT8 frontPanelControl;
#     UINT8 miscControl;
#     UINT8 heartbeatToggleControl;
#     UINT8 watchDogReTriggerControl;
#   UINT8 machRegistersPad[8];
        $systemStatus0, $diagSwitchesStatus, $flashSwitchesStatus, $boardMachRevStatus,
        $frontPanelControl, $miscControl, $heartbeatToggleControl, $watchDogReTriggerControl,
        $machPad1, $machPad2, $machPad3, $machPad4, $machPad5, $machPad6, $machPad7, $machPad8,
#   ERRORTRAP_DATA_I960_TRACE_REGISTERS traceRegisters;
#     /* 8-bit registers */
#     UINT8 statusGpodReg;
#     UINT8 reserved0[15];
        $statusGpodReg,
        $byteReserved1,  $byteReserved2,  $byteReserved3,  $byteReserved4,  $byteReserved5,
        $byteReserved6,  $byteReserved7,  $byteReserved8,  $byteReserved9,  $byteReserved10,
        $byteReserved11, $byteReserved12, $byteReserved13, $byteReserved14, $byteReserved15,
#     /* 16-bit registers */
#     UINT16 nmiPatusrReg;
#     UINT16 nmiSatusrReg;
#     UINT16 nmiPcrReg;
#     UINT16 nmiBcrReg;
#     UINT16 nmiPsrReg;
#     UINT16 nmiSsrReg;
#     UINT16 nmiSderReg;
#     UINT16 nmiPatucmdReg;
#     UINT16 nmiSatucmdReg;
#     UINT8  reserved1[14];
        $nmiPatusrReg, $nmiSatusrReg, $nmiPcrReg, $nmiBcrReg,
        $nmiPsrReg, $nmiSsrReg, $nmiSderReg, $nmiPatucmdReg, $nmiSatucmdReg,
        $shortReserved1,  $shortReserved2,  $shortReserved3,  $shortReserved4,  $shortReserved5,
        $shortReserved6,  $shortReserved7,  $shortReserved8,  $shortReserved9,  $shortReserved10,
        $shortReserved11, $shortReserved12, $shortReserved13, $shortReserved14,
#     /* 32-bit registers */
#     UINT32 nmiIsrReg;
#     UINT32 nmiPatuimrReg;
#     UINT32 nmiSatuimrReg;
#     UINT32 nmiAtucrReg;
#     UINT32 nmiMcisrReg;
#     UINT32 nmiPatuisrReg;
#     UINT32 nmiSatuisrReg;
#     UINT32 nmiPbisrReg;
#     UINT32 nmiSbisrReg;
#     UINT32 nmiCsr0Reg;
#     UINT32 nmiCsr1Reg;
#     UINT32 nmiCsr2Reg;
#     UINT32 nmiIisrReg;
#     UINT32 nmiAsrReg;
#     UINT32 nmiBiuisrReg;
#     UINT32 nmiEccrReg;
#     UINT32 nmiEctstReg;
#     UINT32 nmiElog0Reg;
#     UINT32 nmiElog1Reg;
#     UINT32 nmiEcar0Reg;
#     UINT32 nmiEcar1Reg;
#     UINT8  reserved2[12];
        $nmiIsrReg,     $nmiPatuimrReg,  $nmiSatuimrReg,  $nmiAtucrReg,
        $nmiMcisrReg,   $nmiPatuisrReg,  $nmiSatuisrReg,  $nmiPbisrReg,
        $nmiSbisrReg,   $nmiCsr0Reg,     $nmiCsr1Reg,     $nmiCsr2Reg,
        $nmiIisrReg,    $nmiAsrReg,      $nmiBiuisrReg,   $nmiEccrReg,
        $nmiEctstReg,   $nmiElog0Reg,    $nmiElog1Reg,    $nmiEcar0Reg, $nmiEcar1Reg,
        $wordReserved1, $wordReserved2,  $wordReserved3,  $wordReserved4,
        $wordReserved5, $wordReserved6,  $wordReserved7,  $wordReserved8,
        $wordReserved9, $wordReserved10, $wordReserved11, $wordReserved12) = 
        unpack( $unpackString, $buffer );

    $outStr .= sprintf( "\n" );
    $outStr .= sprintf( "Saved on %s, %02x/%02x/%02x at %02x:%02x:%02x (GMT)\n",
        $dayNames[$traceDay & 0x07], $traceMonth, $traceDate, $traceYear, $traceHours, $traceMinutes, $traceSeconds );
    $outStr .= sprintf( "  with $fwRevision/$fwRevCount built by $fwBuildID on %s, %02x/%02x/%02x at %02x:%02x:%02x (Local)\n",
        $dayNames[$fwDay & 0x07], $fwMonth, $fwDate, $fwYear, $fwHours, $fwMinutes, $fwSeconds );
    $outStr .= sprintf( "\n" );

    $outStr .= sprintf( "---- Register Values ----\n" );
    $outStr .= sprintf( "G0: 0x%08x  G1: 0x%08x  G2: 0x%08x  G3: 0x%08x\n", $g0,  $g1,  $g2,  $g3 );
    $outStr .= sprintf( "G4: 0x%08x  G5: 0x%08x  G6: 0x%08x  G7: 0x%08x\n", $g4,  $g5,  $g6,  $g7 );
    $outStr .= sprintf( "G8: 0x%08x  G9: 0x%08x  G10:0x%08x  G11:0x%08x\n", $g8,  $g9,  $g10, $g11 );
    $outStr .= sprintf( "G12:0x%08x  G13:0x%08x  G14:0x%08x  G15:0x%08x\n", $g12, $g13, $g14, $g15 );
    $outStr .= sprintf( "\n" );

    $outStr .= sprintf( "R0: 0x%08x  R1: 0x%08x  R2: 0x%08x  R3: 0x%08x\n", $r0,  $r1,  $r2,  $r3 );
    $outStr .= sprintf( "R4: 0x%08x  R5: 0x%08x  R6: 0x%08x  R7: 0x%08x\n", $r4,  $r5,  $r6,  $r7 );
    $outStr .= sprintf( "R8: 0x%08x  R9: 0x%08x  R10:0x%08x  R11:0x%08x\n", $r8,  $r9,  $r10, $r11 );
    $outStr .= sprintf( "R12:0x%08x  R13:0x%08x  R14:0x%08x  R15:0x%08x\n", $r12, $r13, $r14, $r15 );
    $outStr .= sprintf( "\n" );

    $outStr .= sprintf( "---- Mach Registers ----\n" );
    $outStr .= sprintf( "systemStatus0:            0x%02x\n", $systemStatus0 );
    $outStr .= sprintf( "diagSwitchesStatus:       0x%02x\n", $diagSwitchesStatus );
    $outStr .= sprintf( "flashSwitchesStatus:      0x%02x\n", $flashSwitchesStatus );
    $outStr .= sprintf( "boardMachRevStatus:       0x%02x\n", $boardMachRevStatus );
    $outStr .= sprintf( "frontPanelControl:        0x%02x\n", $frontPanelControl );
    $outStr .= sprintf( "miscControl:              0x%02x\n", $miscControl );
    $outStr .= sprintf( "heartbeatToggleControl:   0x%02x\n", $heartbeatToggleControl );
    $outStr .= sprintf( "watchDogReTriggerControl: 0x%02x\n", $watchDogReTriggerControl );
    $outStr .= sprintf( "\n" );

    $outStr .= sprintf( "---- i960 Registers ----\n" );
    $outStr .= sprintf( "NISR:    0x%08x\n", $nmiIsrReg );
    $outStr .= sprintf( "PATUIMR: 0x%08x\n", $nmiPatuimrReg );
    $outStr .= sprintf( "SATUIMR: 0x%08x\n", $nmiSatuimrReg );
    $outStr .= sprintf( "ATUCR:   0x%08x\n", $nmiAtucrReg );
    $outStr .= sprintf( "MCISR:   0x%08x\n", $nmiMcisrReg );
    $outStr .= sprintf( "PATUISR: 0x%08x\n", $nmiPatuisrReg );
    $outStr .= sprintf( "SATUISR: 0x%08x\n", $nmiSatuisrReg );
    $outStr .= sprintf( "PBISR:   0x%08x\n", $nmiPbisrReg );
    $outStr .= sprintf( "SBISR:   0x%08x\n", $nmiSbisrReg );
    $outStr .= sprintf( "CSR0:    0x%08x\n", $nmiCsr0Reg );
    $outStr .= sprintf( "CSR1:    0x%08x\n", $nmiCsr1Reg );
    $outStr .= sprintf( "CSR2:    0x%08x\n", $nmiCsr2Reg );
    $outStr .= sprintf( "IISR:    0x%08x\n", $nmiIisrReg );
    $outStr .= sprintf( "ASR:     0x%08x\n", $nmiAsrReg );
    $outStr .= sprintf( "BIUISR:  0x%08x\n", $nmiBiuisrReg );
    $outStr .= sprintf( "ECCR:    0x%08x\n", $nmiEccrReg );
    $outStr .= sprintf( "ECTST:   0x%08x\n", $nmiEctstReg );
    $outStr .= sprintf( "ELOG0:   0x%08x\n", $nmiElog0Reg );
    $outStr .= sprintf( "ELOG1:   0x%08x\n", $nmiElog1Reg );
    $outStr .= sprintf( "ECAR0:   0x%08x\n", $nmiEcar0Reg );
    $outStr .= sprintf( "ECAR1:   0x%08x\n", $nmiEcar1Reg );
    $outStr .= sprintf( "PATUSR:  0x%04x\n", $nmiPatusrReg );
    $outStr .= sprintf( "SATUSR:  0x%04x\n", $nmiSatusrReg );
    $outStr .= sprintf( "PCR:     0x%04x\n", $nmiPcrReg );
    $outStr .= sprintf( "BCR:     0x%04x\n", $nmiBcrReg );
    $outStr .= sprintf( "PSR:     0x%04x\n", $nmiPsrReg );
    $outStr .= sprintf( "SSR:     0x%04x\n", $nmiSsrReg );
    $outStr .= sprintf( "SDER:    0x%04x\n", $nmiSderReg );
    $outStr .= sprintf( "PATUCMD: 0x%04x\n", $nmiPatucmdReg );
    $outStr .= sprintf( "SATUCMD: 0x%04x\n", $nmiSatucmdReg );
    $outStr .= sprintf( "GPOD:    0x%02x\n", $statusGpodReg );
    $outStr .= sprintf( "\n" );

    return $outStr;
}



#################################################################


1;



#################################################################

=head1 CHANGELOG

 $Log$
 Revision 1.5  2006/05/25 16:50:29  ElvesterN
 Removed diff markers

 Revision 1.4  2006/05/24 07:51:30  EidenN
 Moved from 750 Branch

 Revision 1.2.4.1  2006/02/24 14:17:25  MiddenM
 Merge from WOOKIEE_EGGS_GA_BR into MODEL750_BR

 Revision 1.3  2006/01/16 15:01:59  EidenN
 Tbolt0000000:   Fixed Trace error during compile

 Revision 1.3  2006/01/16 15:01:59  EidenN
 Tbolt0000000:   Fixed Trace error during compile

 Revision 1.2  2005/11/14 11:49:58  AnasuriG
 Changes done as part of iSCSI scripting for Integration testing

 Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
 import CT1_BR to shared/Wookiee

 Revision 1.46  2004/02/23 17:33:42  RysavyR
 Added CCBErrorSnapshotDecoder() back into CtlrGrabber.pm (from
 XIOtech\TracDec.pm) to support legacy BFDumps.

 Revision 1.45  2003/12/04 19:06:01  SchibillaM
 TBolt00009629: Add decoder support for Worksets and GeoPools.  Reformat NVRAM
 decode.

 Revision 1.44  2003/11/07 21:20:12  SchibillaM
 TBolt00000000: Changes to decoders for FID 296 (FW Versions) and 256 (CCB
 Trace Buffer) to make them look more like the BFDump versions.  Move TracDec.pm
 from Test\TestLib to CBE\XIOTech.  Reviewed by Craig.

 Revision 1.43  2003/08/05 18:03:50  NigburC
 TBolt00008575 - Change the name of two power-up states (BE_READY and
 DISCOVERY) to make them more descriptive for what they do and added
 three additional power-up states for the updated RAID 5 processing.  Added
 a new function to convert the power-up state to a string value.
 Reviewed by Craig Menning.

 Revision 1.42  2003/08/05 14:53:58  MenningC
 tbolt00000000: changes for nvram part 1; reviewed by Eric

 Revision 1.41  2003/07/28 21:02:23  MenningC
 TBOLT00000000: fixed handling of of size of NVRAM pt 2; reviewed by Eric

 Revision 1.40  2003/06/16 19:09:49  MenningC
 TBOLT00000000: import ddrdecode formatters into ccbcl; Reviewed by  Erc

 Revision 1.39  2003/06/05 15:09:46  MenningC
 TBOLT00000000: fixes for nvram pt1 selection and failover timeline changes;
  reviewed by Eric.

 Revision 1.38  2003/06/03 19:47:36  MenningC
 TBOLT00000000: Changed many of the 'display' functions in the CCBCL to fill a string rather than print to the screen. The test scripts can now use these functions. Reviewed by Jeff W.

 Revision 1.37  2003/05/21 21:34:59  MenningC
 Tbolt00000000:more FIDs added to decoders; reveiwed by JW

 Revision 1.36  2003/05/12 16:53:20  MenningC
 Tbolt00000000:fix for stats env version dependency. reviewed by Jeff W

 Revision 1.35  2003/03/26 21:24:52  WerningJ
 Removed calls to unused modules
 Reviewed by Craig M

 Revision 1.34  2003/03/20 17:02:46  MenningC
 added decoding of redrr EQ and PCB.  reveiwed by JW

 Revision 1.33  2003/03/05 21:06:58  MenningC
 tbolt00000000 patch for bad structureinfo data, reviewed by JW

 Revision 1.32  2003/03/05 20:07:53  MenningC
 tbolt00000000 updates to run under Linux, reviewed by JW

 Revision 1.31  2003/02/18 19:05:54  MenningC
 Tbolt00000000 fix flt rec header, reviewed by JT

 Revision 1.30  2003/02/14 16:10:11  MenningC
 fix some nvram stuff; reveiwed by Brett

 Revision 1.29  2003/02/10 22:21:14  MenningC
 Added more decode rings

 Revision 1.28  2003/02/07 17:24:33  MenningC
 Tbolt00000000: updates for SES changes. reveiwed by Jeff Werning.

 Revision 1.27  2003/02/05 22:46:14  MenningC
 Tbolt00000000:added delay after rescan. reviewed by Jeff Werning

 Revision 1.26  2003/01/30 16:14:56  McmasterM
 TBolt00000000: Added CCB backtrace header decoder
 Reviewed by Craig Menning

 Revision 1.25  2003/01/29 18:48:55  MenningC
 Tbolt00000000:only do stats loop once per processor; reviewed by JT

 Revision 1.24  2003/01/27 21:02:48  McmasterM
 TBolt00000000: Fixed another decode problem with proc NVRAM backtrace.
 The PATUCMD register was deing decoded as a word, not a short.

 Revision 1.23  2003/01/27 17:27:52  McmasterM
 TBolt00000000: Fixed another decode problem with proc NVRAM backtrace.

 Revision 1.22  2003/01/27 16:36:45  McmasterM
 TBolt00000000: Fixed incorrect decode of FE and BE NVRAM backtrace data

 Revision 1.21  2003/01/24 22:12:33  McmasterM
 TBolt00006902: Serial data sometimes incomplete on CCB errortrap/NMI
 Changed FmtDataString's text handler to filter out unprintable characters.

 Revision 1.20  2003/01/02 21:18:34  MenningC
 Tbolt00000000:Fixed a typo that was driving Swatosh and Rysavy up the wall., reviewed by Jeff Werning

 Revision 1.19  2002/12/05 15:31:14  MenningC
 TBOLT00000000: changes to accomodate product hash changes. reviewed by J Werning

 Revision 1.18  2002/11/22 15:38:21  MenningC
 tbolt00000000: fix diskbaystatus related problems, reviewed by Max.

 Revision 1.17  2002/11/22 15:25:41  MenningC
 tbolt00000000: fix diskbaystatus related problems, reviewed by Olga.

 Revision 1.16  2002/11/19 16:29:32  MenningC
 tbolt00000000: Updates to redicp, defrag and ctlrgrabber. Reviewed by Olga

 Revision 1.15  2002/11/12 22:34:43  MenningC
 TBOLT00000000: update for M830 CCB code. Randy saw the output.

 Revision 1.14  2002/11/12 20:54:19  MenningC
 TBOLT00000000: Version info for Manufacturing. Reviewed by J Werning

 Revision 1.13  2002/11/01 17:04:37  MenningC
 tbolt00000000  fix for ccbe dump move,  reviewed by R Rysavy

 Revision 1.11  2002/10/01 18:52:54  MenningC
 tbolt00000000 added decoding of Brett's directory Reviewed by Werning.

 Revision 1.10  2002/09/30 21:04:41  MenningC
 tbolt00000000 added decoding of Brett's directory Reviewed by Werning.

 Revision 1.9  2002/09/19 19:25:01  WerningJ
 Added CtlrLogTest function for use by BFDump
 Reviewed by Craig M

 Revision 1.8  2002/09/18 18:54:18  MenningC
 tbolt00000000 updates to handle a null string better; reviewed by J Werning

 Revision 1.6  2002/09/16 14:56:27  MenningC
 tbolt00000000 cmore changes
 ; reviewed by J Werning

 Revision 1.5  2002/09/12 21:49:26  MenningC
 TBOLT000000, fix for diskbaysts, reviewed by Bryan

 Revision 1.4  2002/09/12 19:36:26  MenningC
 TBOLT000000, more stuff; reviewed by Werning

 Revision 1.3  2002/09/11 19:20:06  MenningC
 tbolt00000000 added ccbtrace, some cleanup, reviewed by Jeff Werning

 Revision 1.2  2002/09/11 15:31:42  MenningC
 tbolt00000000 continued development, reviewed by Jeff Werning

 Revision 1.1  2002/09/10 19:35:24  MenningC
 tbolt00000000 new file, per JT's request



=cut
