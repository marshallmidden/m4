#! /usr/bin/perl 
# $Header$
##############################################################################
#  
#   Vlinks Integration test library 
#
#   4/18/2003  Xiotech   Jeff Werning
#
#   A set of library functions for integration testing of Virtual Links
#   between XIOtech products.
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2003-2006 Xiotech Corporation. All rights reserved.
#
#   For Xiotech internal use only.
#
##############################################################################

#                         
# - what I am
#

package TestLibs::VlinksLibs;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

#use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
#use XIOTech::logMgr;

use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::IntegCCBELib;
#use TestLibs::Fibre;
#use TestLibs::Validate;

use Dumpvalue;
my $dumper = new Dumpvalue;


use strict;

#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    #$VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    $VERSION = do { my @r = (q$Revision: 13469 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        
                        &BreakVlink
                        &CreateVlink
                        
                        &FindVlinkCluster
                        &FindVlinkVDisk

                        &VlinkControllerCount
                        &VlinkControllerInfo
                        &VlinkControllerVDisks

                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 13469 $);
}
    our @EXPORT_OK;


##############################################################################
#
#      Name: BreakVlink
#
#    Inputs: CCBE Object, VID
#
#   Outputs: GOOD if successful, ERROR otherwise
#
##############################################################################
sub BreakVlink
{
    trace();

    my ($currentMgr, $vid) = @_;

    my %response;
    my $returnValue;
    
    #
    #   Break the VLink
    #

    debug ("Attempt VLink Break Lock VID:$vid");

    %response = $currentMgr->virtualLinkBreakLock($vid);

    if (%response)
    {
        if ($response{STATUS} != PI_GOOD)
        {
            my $msg = "Unable to complete VLink Break Lock request.";
            TestLibs::scrub::displayError($msg, %response);
            
            logWarning("Unable to break vlock VID:$vid");
        }
    }
    else
    {
        logWarning ("ERROR: Did not receive a response packet from virtualLinkBreakLock");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#      Name: CreateVlink
#
#    Inputs: CCBE Object, cluster #, lun #, VID for remote system, Vlink name
#
#   Outputs: GOOD if successful, ERROR otherwise
#
##############################################################################
sub CreateVlink
{
    trace();

    our ($currentMgr, $cluster, $lun, $remoteVID, $name) = @_;

    my %response;
    my $returnValue;
    my $controllerOrdinal;
    my $vdiskOrdinal;
    
    #
    #   Find the required indexes for this VLink
    #

    $returnValue = FindVlinkCluster($currentMgr, $cluster, \$controllerOrdinal);
    if ($returnValue != GOOD) { ErrorExit(); return ERROR;}

    $returnValue = FindVlinkVDisk($currentMgr, $controllerOrdinal, $lun, \$vdiskOrdinal);
    if ($returnValue != GOOD) { ErrorExit(); return ERROR;}
    
    #
    #   Create the VLink
    #

    logInfo("Creating VLink on Cluster:$cluster, LUN:$lun, remote VID:$remoteVID, name:$name");
    logInfo("Controller Ordinal:$controllerOrdinal, VDisk Ordinal:$vdiskOrdinal");
    
    %response = $currentMgr->virtualLinkCreate($controllerOrdinal, $vdiskOrdinal, $remoteVID);

    if (%response)
    {
#$dumper->dumpValues(%response);

        if ($response{STATUS} != PI_GOOD)
        {
            logWarning("Unable to create Vlink => Error Message:$response{ERROR_MSG}");
            TestLibs::IntegCCBELib::DispVdiskInfo($currentMgr);
            return ERROR;
        }
    }
    else
    {
        logWarning ("ERROR: Did not receive a response packet from virtualLinkCreate");
        return ERROR;
    }

    return GOOD;

#
# Emergency Exit Routine
#
    sub ErrorExit
    {
        TestLibs::Logging::logWarning ("Failed to Create the VLink => Cluster:$cluster, LUN:$lun, Remote VID:$remoteVID, Name:$name");
    }
}

##############################################################################
#
#      Name: FindVlinkCluster
#
#    Inputs: CCBE Object, cluster #, pointer to variable to update with Controller Ordinal
#
#   Outputs: GOOD if successful, ERROR otherwise
#
##############################################################################
sub FindVlinkCluster
{
    trace();

    my ($currentMgr, $cluster, $controllerOrdinalPtr) = @_;

    my %response;
    my $returnValue;
    my $controllerCount;
    my %vlControllerInfo;
    
    #
    #   Find the controller ordinal with this cluster
    #

    $returnValue = VlinkControllerCount($currentMgr, \$controllerCount);
    if ($returnValue != GOOD) {return ERROR;}

    for (my $ordinal = 0; $ordinal < $controllerCount; $ordinal++)
    {
        $returnValue = VlinkControllerInfo($currentMgr, $ordinal, \%vlControllerInfo);
        if ($returnValue != GOOD) {return ERROR;}
#$dumper->dumpValues(%vlControllerInfo);

        if ($vlControllerInfo{"CLUSTER"} ==  $cluster)
        {
            # Found it, update the variable
            $$controllerOrdinalPtr =  $ordinal;
            return GOOD;  # leave the function
        }
    }

    logWarning(" Unable to find the Controller ID for Cluster:$cluster");
    return ERROR;
}

##############################################################################
#
#      Name: FindVlinkVDisk
#
#    Inputs: CCBE Object, cluster #, pointer to variable to update with Controller Ordinal
#
#   Outputs: GOOD if successful, ERROR otherwise
#
##############################################################################
sub FindVlinkVDisk
{
    trace();

    my ($currentMgr, $controllerOrdinal, $lun, $vdiskOrdinalPtr) = @_;

    my %response;
    my $returnValue;
    my %vlinkVdisks;
    my $vdiskOrdinal = 0;
    
    #
    #   Find the vdisk ordinal for given controller and lun
    #

    $returnValue = VlinkControllerVDisks($currentMgr, $controllerOrdinal, \%vlinkVdisks);
    if ($returnValue != GOOD) {return ERROR;}

#$dumper->dumpValues(%vlinkVdisks);
    foreach my $vdiskEntry (@{$vlinkVdisks{VDDS}})
    {
        if ($lun == $$vdiskEntry{'LUN'})
        {
            # Found it, update the variable
            $$vdiskOrdinalPtr =  $vdiskOrdinal;
            return GOOD;  # leave the function
        }
            $vdiskOrdinal++;
    }

    logWarning(" Unable to find the VDisk ID for Controller:$controllerOrdinal, LUN:$lun");

    return ERROR;
}

##############################################################################
#
#      Name: VlinkControllerInfo
#
#    Inputs: CCBE Object, controller ordinal, pointer to Info Hash to update
#
#   Outputs: GOOD if successful, ERROR otherwise
#
##############################################################################
sub VlinkControllerInfo
{
    trace();

    my ($currentMgr, $controllerOrdinal, $controllerInfoPtr) = @_;

    my %response;
    
    %response = $currentMgr->virtualLinkCtrlInfo($controllerOrdinal);

    if (%response)
    {
        if ($response{STATUS} != PI_GOOD)
        {
            logWarning("Unable to retrieve remote controller information");
            return ERROR;
        }
    }
    else
    {
        logWarning("ERROR: Did not receive a response packet for virtualLinkCtrlInfo");
        return ERROR;
    }

    %$controllerInfoPtr = %response;

    return GOOD;
}

##############################################################################
#
#      Name: VlinkControllerCount
#
#    Inputs: CCBE Object, Pointer to Controller Count variable to update
#
#   Outputs: GOOD if successful, ERROR otherwise
#
##############################################################################
sub VlinkControllerCount
{
    trace();

    my ($currentMgr, $countPtr) = @_;

    my %response;
    
    %response = $currentMgr->virtualLinkCtrlCount();

    if (%response)
    {
        if ($response{STATUS} != PI_GOOD)
        {
            logWarning("Unable to retrieve remote controller count");
            return ERROR;
        }
    }
    else
    {
        logWarning("ERROR: Did not receive a response packet for virtualLinkCtrlCount");
        return ERROR;
    }

    $$countPtr = $response{COUNT};

    return GOOD;
}

##############################################################################
#
#      Name: VlinkControllerVDisks
#
#    Inputs: CCBE Object, Controller Ordinal, pointer to VlinkVdisk Hash to update
#
#   Outputs: GOOD if successful, ERROR otherwise
#
##############################################################################
sub VlinkControllerVDisks
{
    trace();

    my ($currentMgr, $controller, $vlinkVdiskPtr) = @_;

    my %response;
    
    %response = $currentMgr->virtualLinkCtrlVDisks($controller);

    if (%response)
    {
        if ($response{STATUS} != PI_GOOD)
        {
            logWarning("Unable to retrieve remote controller:$controller vdisks");
            return ERROR;
        }
    }
    else
    {
        logWarning("ERROR: Did not receive a response packet for virtualLinkCtrlVDisks");
        return ERROR;
    }

    %$vlinkVdiskPtr = %response;

    return GOOD;
}

##############################################################################


1;   # we need this for a PM

