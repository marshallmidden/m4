#! /usr/bin/perl 
# $Header$
##############################################################################
#  
#   CCBE Integration test library - Back End Test utility functions
#
#   10/1/2002  XIOtech   Craig Menning
#
#   A set of library functions for integration testing. This set support
#   testing of the controller's back end function
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::BEUtils - Perl Library for BE testing

$Id: BEUtils.pm 22101 2007-04-11 10:35:38Z gopinadh_anasuri $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This library contains functions to support testing of the controller 
Back End functions.



=head1 DESCRIPTION

Test Functions Available (exported)

            CheckAndWait4RediCp
            CheckSosTables
            CopyProgress
            CreateMultiRaidVdisk
            CreateReplacementVdisk
            CreateSimilarVdisk
            
            DefragAll
            DefragAllBegin
            DefragAllOneAtATime
            DefragBegin
            DefragRemain
            DefragWait
            DeleteUnusedVdisks
            DisassocVdisk
            DispSOSTables

            ExpandVdisks
            
            FailMyOwner
            FailPdisk
            FailPdiskNoWait
            FindEarlyVdisk
            FindFirstNew
            FindIsolatedPdds
            FindMovingVdisks
            FindPdId
            FindUnusedVdds
            FindVdiskForEachController
            FindVdiskOwner
            FirstVdiskOnCtlr
            
            FixPdiskLabels

            GetRandomVdisks
            GetSesAndSlot
            GetTargetMap
            getTrace
            
            InitNewerVdisks

            LocateRaidXVdisks

            MoveOwner

            PdiskBypass
            PdiskIdBypass
            PdiskIdUnbypass

            PScanCheck
            PScanCount
            PScanResults
            PScanStart
            PScanStop
            PScanWait

            PSDCheck
            
            RCPControllerActiveVdiskListPart1
            RCPControllerActiveVdiskListPart2
            RediCpVdisks
            ResetBELoop
            
            ScrubSet
            ShortPdiskInfo
            ShortVdiskInfo
            ShortVdisks
            StartCopyOp
            StartSingleDefrag
            StopDefrag
            
            UnfailAll
            UnfailPdisk

            VerifyIO
            VRinfo
            
            Wait4Ses
            WaitForCpComplete
            WaitOnNewerInits
            WaitRebuild

=cut


#                         
# - what I am
#

package TestLibs::BEUtils;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;

use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :CCBE :REDI);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOverSupport;
use TestLibs::Validate;
use TestLibs::scrub;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - Constants used
#



#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 22101 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(


                    &CheckAndWait4RediCp
                    &CheckSosTables
                    &CopyProgress
                    &CreateMultiRaidVdisk
                    &CreateReplacementVdisk
                    &CreateSimilarVdisk
                    
                    &DefragAll
                    &DefragAllBegin
                    &DefragAllOneAtATime
                    &DefragBegin
                    &DefragRemain
                    &DefragWait
                    &DeleteUnusedVdisks
                    &DeleteVdiskList
                    &DisassocVdisk
                    &DispSOSTables

                    
                    &FailMyOwner
                    &FailPdisk
                    &FailPdiskNoWait
                    &FindEarlyVdisk
                    &FindFirstNew
                    &FindIsolatedPdds
                    &FindMovingVdisks
                    &FindPdId
                    &FindUnusedVdds
                    &FindVdiskOwner
                    &FirstVdiskOnCtlr
                    &FixPdiskLabels
                    
                    &GetRandomVdisks
                    &GetSesAndSlot
                    &GetTargetMap
                    &getTrace

                    &InitNewerVdisks
                    
                    &LIPDrive
                    &LocateRaidXVdisks

                    &MoveOwner

                    &PdiskBypass
                    &PdiskIdBypass
                    &PdiskIdUnbypass
                    
                    &PScanCheck
                    &PScanCount
                    &PScanResults
                    &PScanStart
                    &PScanStop
                    &PScanWait
                    
                    &PSDCheck

                    
                    &RCPControllerActiveVdiskListPart1
                    &RCPControllerActiveVdiskListPart2
                    &RediCpVdisks
                    &RemoveMirrors
                    &ResetBELoop
                    
                    &SataBayLogSense
                    &ScrubSet
                    &ServerPropSpin
                    &ShortPdiskInfo
                    &ShortVdiskInfo
                    &ShortVdisks
                    &StartCopyOp
                    &StartSingleDefrag
                    &StopDefrag
                    
                    &UnfailAll
                    &UnfailPdisk

                    &VerifyIO
                    &VRinfo
                    
                    &Wait4Ses
                    &WaitForCpComplete
                    &WaitOnNewerInits
                    &WaitRebuild

                        

                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 22101 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.
         
 $moxaIP: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.
          
 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller. 

 $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be 
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the 
          attached servers. When configuring systems, this list determines 
          which WWNs will be associated with vdisks. If an entry in this 
          list is not found on the system, it will be ignored. A WWN 
          found on the system that is not included in the list will not 
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.
       



=back

=cut


###############################################################################

=head2 SAMPLE function



=cut

=over 1

=item Usage:


=item Returns:


=item Things to look for:
 

=item Initial Conditions:





=back

=cut



##############################################################################

###############################################################################

=head2 CheckSosTables function

A key function to verify the defrag operation. However, it is not complete.



=cut

=over 1

=item Usage:

 my $rc = CheckSosTables($coPtr, $expected );
 
 where: $coPtr is a pointer to a list of controller objects
        $expected the state we expect to find in the data

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the 
           expected state is found.



=back

=cut


##############################################################################
#
#          Name: CheckSosTables
#
#        Inputs: controller object pointer and other data
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Reads the sos tables and gets their state from both 
#                controllers. The tables will indicate the following
#               
#                1) There are no defrags running
#                2) Defrags are running on one or more controllers
#                   (there may be activity on all controllers)
#                3) Defrags are running on ALL controllers
#                4) No activity and debris laying around.
#                5) No activity and no debris.
#
#                When called, we expect to find one of these conditions. 
#                We find out what is currently there and see if there is
#                a match.
#
#                The state is bit mapped:  
#
#                  bit 0:  Disks (0) are NOT fragmented, (1) ARE fragmented
#                  bit 1:  Defrag not running and debris present
#                  bit 2:  debris is present
#                  bit 3:
#                  bit 4:
#                  bit 5:
#                  bit 6:
#                  bit 7:
#                  bit 8:
#    
#
##############################################################################
sub CheckSosTables
{
    my ($coPtr, $expected) = @_;

    my @coList;
    my $ret;
    my $thisState;
    my $ourState;
    my $i;
    my $j;
    my $k;
    my $msg;
    my @PDDs;
    my $ctlr;
    my %info;
    my $pdd;
    my $gapFound;
    my $raid5Found;
    my $bigGapFound;
    my $raid5Fragmented;
    my $nonRaid5Fragmented;
    my $master;
    my @raidIDs;
    my $raidIDsPtr = \@raidIDs;
    my $raid5Exists;
    my $r5EnabledFlag;

    @coList = @$coPtr;
    $ourState = 0;
    $raid5Fragmented = 0;
    $nonRaid5Fragmented = 0;
    $bigGapFound = 0;
                   
    logInfo("      Checking SOS tables ");


    # for each controller in the list
    for ( $i = 0; $i < scalar(@coList); $i++ )
    {
        $ctlr = $coList[$i];

        #
        # wake up the controller if we haven't talked to it for a while
        # This function will leave all controllers with a valid connection
        #

        $ret = TestNReconnect($ctlr);
        if ( $ret != GOOD ) { return ERROR; }
        
        # 
        # get the RIDs of all the raid5s 
        #
        $ret = GetRaidIDs($ctlr, RAID_5, $raidIDsPtr);
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> CheckSosTables: GetRaidIDs Failed <<<<<<<<");
            return ERROR;
        }
        
        #
        # set flag indicating if there are any Raid5s
        #
        $raid5Exists = 0;
        if ( $ret == GOOD )
        {
            $raid5Exists = 1;
        }
        
        #
        # We try to determine if this is the master. We do it each time as
        # the master may have time-out the connection and we don't want to
        # fail the function if we have not yet done the master. We will
        # collect and post the data so that it can be looked at later, but
        # failure flags will only be set for the master controller.
        #
        
        $master = FindMaster($coPtr);
        # if ( $master == INVALID ) { return ERROR; } 


        # get a list of PDDs
    
        @PDDs = GetDataDisks($ctlr, PD_DT_ALL);

        if ( $PDDs[0] == INVALID )
        {
            return ERROR;
        }

        # for each PDD in the list
        for ( $j = 0; $j < scalar(@PDDs); $j++ )
        {
            $pdd = $PDDs[$j];
        
            # get the SOS table

            %info = $ctlr->getSos($pdd);
            if ( ! %info  )
            {
                logInfo(">>>>>>>> Failed to get response from getSos <<<<<<<<");
                return ERROR;
            }
            if ($info{STATUS} != PI_GOOD)
            {
                logInfo(">>>>>>>> ERROR: Could not retrieve SOS table ($pdd) <<<<<<<<");
                PrintError(%info);

                $msg = "(Bad) SOS table for PDD $PDDs[$j]:   \n";
                $msg .= sprintf("NEXT:       0x%08X\n",      $info{NEXT});
                $msg .= sprintf("PID:        %d\n",          $info{PID});
                $msg .= sprintf("FLAGS:      0x%04X\n",      $info{FLAGS});
                $msg .= sprintf("REMAIN:     0x%08X\n",      $info{REMAIN});
                $msg .= sprintf("TOTAL:      0x%08X\n",      $info{TOTAL});
                $msg .= sprintf("PDD:        0x%08X\n",      $info{PDD});
                $msg .= sprintf("OWNER:      0x%08X\n",      $info{OWNER});
                $msg .= sprintf("COUNT:      %d\n",          $info{COUNT});
                $msg .= sprintf("CURRENT:    %d\n",          $info{CURRENT});
                $msg .= sprintf("PCB:        0x%08X\n",      $info{PCB});
    
                $msg .= sprintf "\n";

                $msg .= sprintf "  GAP_SIZE      SDA         LEN         RID\n";
                $msg .= sprintf " ----------  ----------  ----------  ----------\n";
                for ($j = 0; $j < $info{COUNT}; ++$j)
                {
                    $msg .= sprintf " 0x%08X  0x%08X  0x%08X  0x%08X\n", 
                        $info{LIST}[$j]{GAP_SIZE},
                        $info{LIST}[$j]{SDA},
                        $info{LIST}[$j]{LEN},
                        $info{LIST}[$j]{RID};
                }

                logInfo($msg);

                return ERROR;
            }

            # walk the table, looking to determine the current state

            $thisState = 0;

            #    > sostable 4
            #
            #    SOS TABLE:
            #
            #    NEXT:       0x00000000    (next table)
            #    PID:        0             (PID for the defrag drive)
            #    FLAGS:      0x0000        ( see below )
            #    REMAIN:     0x0049D800    (blocks remaining)
            #    TOTAL:      0x0000BD0A    (total blocks to copy )
            #    PDD:        0x00000000    (PDD being defraged)
            #    OWNER:      0x00000000    (alternate SDA)
            #    COUNT:      27            (number of entries)
            #    CURRENT:    0             (current entry number)
            #    PCB:        0x00000000    (task pcb)
            #
            #   ( now is PSD )
            #      GAP_SIZE      SDA         LEN         RID
            #     ----------  ----------  ----------  ----------
            #     0x00000000  0x00040000  0x00031000  0x00000000
            #     0x00000000  0x00071000  0x00031000  0x00000001
            #     0x00000000  0x000A2000  0x00031000  0x00000002
            #     0x00000000  0x000D3000  0x00031000  0x00000003
            #     0x00000000  0x00104000  0x00031000  0x00000004
            #     0x00000000  0x00135000  0x00031000  0x00000005
            #     0x00000000  0x00166000  0x00031000  0x00000006
            #     0x00000000  0x00197000  0x00031000  0x00000007
            #     0x00000000  0x001C8000  0x00031000  0x00000008
            #     0x00000000  0x001F9000  0x00031000  0x00000009
            #     0x00000000  0x0022A000  0x00031000  0x0000000A
            #     0x00000000  0x0025B000  0x00031000  0x0000000B
            #     0x00000000  0x0028C000  0x00031000  0x0000000C
            #     0x00000000  0x002BD000  0x00031000  0x0000000D
            #     0x00000000  0x002EE000  0x00031000  0x0000000E
            #     0x00000000  0x0031F000  0x00031000  0x0000000F
            #     0x00000000  0x00350000  0x00031000  0x00000010
            #     0x00000000  0x00381000  0x00031000  0x00000011
            #     0x00000000  0x003B2000  0x00031000  0x00000012
            #     0x00000000  0x003E3000  0x00031000  0x00000013
            #     0x00000000  0x00414000  0x00031000  0x00000014
            #     0x00000000  0x00445000  0x00031000  0x00000015
            #     0x00000000  0x00476000  0x00031000  0x00000016
            #     0x00000000  0x004A7000  0x00031000  0x00000017
            #     0x00000000  0x004D8000  0x00002800  0x00000018
            #     0x00000000  0x004DA800  0x00001800  0x00000019
            #     0x00000000  0x004DC000  0x00001800  0x0000001A

            #       
            #    Flags definitions
            #    .set    sofcancel,0             # Cancel this defrag
            #    .set    sofstepdone,1           # This step was completed
            #    .set    sofsteprec,2            # This step was recorded
            #    .set    sofrestart,3            # Restart the SOS
            #    .set    sofactive,5             # This SOS is active on this controller
            #    .set    sofprepared,6           # SOS is ready to process
            #    .set    softerminate,7          # Cannot continue defragmentation
            #    .set    sofincomplete,8         # Error in processing of read/writes

            # we start by just printing the table
        #    logInfo("**********************************************");
        #    logSos(%info);      # this will go away
        #    logInfo("**********************************************");


        
            # combine this PDDs state into the aggregate state

        
            # the test to see if any of the drives are fragmented

            $gapFound = 0;
            $raid5Found = 0;

            for ( $k = 0; $k < $info{COUNT}; $k++ )
            {
                #
                # check for Raid5 segment 
                #
                if ( $raid5Exists )
                {
                    if ( IsInList( $info{LIST}[$k]{RID}, $raidIDsPtr ) )
                    {
                        $raid5Found = 1;
                    }
                }
                
                #
                # skip last entry for gap check
                #
                last if ( $k == ($info{COUNT}-1) );
                
                # look for a gap
                if ( $info{LIST}[$k]{GAP_SIZE} != 0 )
                {
                    # PDD is fragmented
                    # print "Gap found: size = $info{LIST}[$k]{GAP_SIZE}, RID = $info{LIST}[$k]{RID} \n";
                    $gapFound = 1;
                }


                # look for a really big gap
                if ( $info{LIST}[$k]{GAP_SIZE} > 0x40000000 )
                {
                    # SOS table is probably messed up                       
                    logInfo("Big Gap on pdisk $info{PID}, line $k, raid $info{LIST}[$k]{RID}, size $info{LIST}[$k]{GAP_SIZE}.");
                    logInfo("Big Gap on pdisk $info{PID}, line $k, start $info{LIST}[$k]{SDA}, length $info{LIST}[$k]{LEN}.");

                


                    # display the table(if it exists) 
                
                    my $j1;
                       
                    $msg = "\nSOS table for $pdd:   \n\n";
                    $msg .= sprintf("NEXT:       0x%08X\n",      $info{NEXT});
                    $msg .= sprintf("PID:        %d\n",          $info{PID});
                    $msg .= sprintf("FLAGS:      0x%04X\n",      $info{FLAGS});
                    $msg .= sprintf("REMAIN:     0x%08X\n",      $info{REMAIN});
                    $msg .= sprintf("TOTAL:      0x%08X\n",      $info{TOTAL});
                    $msg .= sprintf("PDD:        0x%08X\n",      $info{PDD});
                    $msg .= sprintf("OWNER:      0x%08X\n",      $info{OWNER});
                    $msg .= sprintf("COUNT:      %d\n",          $info{COUNT});
                    $msg .= sprintf("CURRENT:    %d\n",          $info{CURRENT});
                    $msg .= sprintf("PCB:        0x%08X\n",      $info{PCB});
    
                    $msg .= sprintf "\n";

                    $msg .= sprintf "  GAP_SIZE      SDA         LEN         RID\n";
                    $msg .= sprintf " ----------  ----------  ----------  ----------\n";
                    for ($j1 = 0; $j1 < $info{COUNT}; ++$j1)
                    {
                        $msg .= sprintf " 0x%08X  0x%08X  0x%08X  0x%08X\n", 
                            $info{LIST}[$j1]{GAP_SIZE},
                            $info{LIST}[$j1]{SDA},
                            $info{LIST}[$j1]{LEN},
                            $info{LIST}[$j1]{RID};
                    }
                
                    logInfo($msg);
                    logInfo("");


                    if ( $i == $master )
                    {
                        # only on the master
                        $bigGapFound = 1;
                    }
                }
            }

            # only set for the master
            if ( ($gapFound != 0) && ($i == $master) )
            {
                if ( $raid5Found )
                {
                    $raid5Fragmented = 1;
                
                }
                else 
                {
                    $nonRaid5Fragmented = 1;
                } 
            }

 # got some work to do here ... accumulate more data








            # log the pertinent information
            logInfo(sprintf("   PDD: %3d, Flags: 0x%04x, has gap?:%1x, num PSDs: %3d,  ", 
                  $pdd, $info{FLAGS}, $gapFound, $info{COUNT})); 



        }  # end of pdd loop
    
    # compare the expected state with the observed state, 
    # something we will do later
    

    }      # end of controller loop

    $msg = "No drives are fragmented.";
    if ( $raid5Fragmented || $nonRaid5Fragmented  )
    { 
        $msg = "One or more drives are fragmented.";
    }
    logInfo("     ". $msg );

    #
    # If any of the fragmented drives have Raid 5 segments and 
    # raid 5 defrag is not enabled and we are not expecting 
    # segmented, log some additional info
    #
    if (  $ctlr->{CONTROLLER_TYPE} == CTRL_TYPE_BIGFOOT  )
    {
        $r5EnabledFlag = RAID5_DEFRAG_ENABLED_BIGFOOT;
    }
    else
    {
        $r5EnabledFlag = RAID5_DEFRAG_ENABLED_WOOKIEE;
    } 
       
    #
    if ( $raid5Fragmented && !$r5EnabledFlag 
                          && !($expected & ISFRAGMENTED ) )
    {
        $msg = " of the fragmented drives have Raid 5 segments"; 
        if ( $nonRaid5Fragmented  )
        {
           $msg = "Some".$msg;
        }
        else
        {
           $msg = "All".$msg;
        }
        logInfo("     ". $msg );
        
        logInfo("     Raid 5 defrag is disabled.");
        logInfo("     Fragmented drives with Raid 5 segments are ignored.");
    }
    

    # logInfo("     SOS table validation complete, but nothing validated");

    
    if ($bigGapFound != 0 )
    { 
        $msg = "A really big gap was found. This is considered an error.";
        logInfo("     ". $msg );
        return ERROR;
    }

 # got some work to do here ... process the accumulated data and test 
 # against the expected state


 #
 # Have to make some assumptions here because we don't know if the calling
 # routine is trying to verify fragmentation after fragmenting a pdisk
 # or after defragmenting a pdisk.  The special case of raid5 only applies
 # to the defrag function.
 #
 
   

    if ( $expected & ISFRAGMENTED ) 
    {
        # 
        # if caller expected pdisk to be fragmented, then for now we will
        # assume that something was done to fragment the pdisks and consider
        # both Raid5 and non-Raid5 pdisks.
        #
        if ( $raid5Fragmented || $nonRaid5Fragmented )
        {
            logInfo("     SOS table validation complete, fragment conditions matched");
            $ret = GOOD;
        
        }   
        else
        {
            logInfo("Validation failed:  No fragments found, expected fragmented. ");
            $ret = ERROR;
        }
    }
    else
    {
        # 
        # caller expected pdisks NOT to be fragmented, then for now we will
        # assume that something was done to defragment the pdisks and will
        # have to take into account the RAID5_DEFRAG_ENABLED flag.
        #
        if (  $ctlr->{CONTROLLER_TYPE} == CTRL_TYPE_BIGFOOT  )
        {
            $r5EnabledFlag = RAID5_DEFRAG_ENABLED_BIGFOOT;
        }
        else
        {
            $r5EnabledFlag = RAID5_DEFRAG_ENABLED_WOOKIEE;
        } 
           
        #
        if ( ($r5EnabledFlag && $raid5Fragmented) || $nonRaid5Fragmented )
        {
            logInfo("Validation failed:  Unexpected fragments found. ");
            $ret = ERROR;
        }   
        else
        {
            logInfo("     SOS table validation complete, fragment conditions matched");
            $ret = GOOD;
        }
    }

    if ( ($expected & SKIPVALIDATIONFAILURE) && ($ret == ERROR) )
    {
        logInfo("Failure skipped, script allowed to continue");
        $ret = GOOD;             
    }

    return $ret;
}

###############################################################################

=head2 GetTargetMap function

This function generates a list of bitmaps that represent the location of
the targets on the controllers. Failover or moving a target will cause
this mapping to change.



=cut

=over 1

=item Usage:

 my @rc = GetTargetMap($coPtr, $snPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $snPtr a pointer to a list of serial numbers

=item Returns:

       @rc will be a list representing the target map. The first 
           element will be INVALID on a failure to generate the data.



=back

=cut


##############################################################################
#
#          Name: GetTargetMap
#
#        Inputs: controller object pointer and other data
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Using the pre-collected data in a manner similar to
#                other IO verification routines, verify that the same
#                basic level of IO is still running. This should include
#                server and vdisk IO.
#
##############################################################################
sub GetTargetMap
{
    my ( $coPtr, $snPtr ) = @_;


    my @coList;
    my %info1;
    my @startingTmap;
    my $master;
    my @badAr;

    @coList = @$coPtr;

    $badAr[0] = INVALID;

    #
    # get the initial/starting target map
    #
    
    $master = FindMaster($coPtr);
    if ( $master == INVALID ) { return(@badAr); } 

    logInfo("Getting the target status, then building the target map");
    
    %info1 = GetTargetStatus($coList[$master]);

    if ( ! %info1  )              # if no data from call
    {
        logInfo(">>>>>>>> Failed to get a response from GetTargetStatus <<<<<<<<");
        return @badAr;
    }

    if ( $info1{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from GetTargetStatus <<<<<<<<");
        PrintError(%info1);
        return @badAr;
    }
    
    @startingTmap = CreateTargetMap($snPtr, %info1);
    
    PrintTargetMap (\@startingTmap);

    return @startingTmap;

}

###############################################################################

=head2 VerifyIO function

This function is used to verify that IO is still running on all vdisks and
servers. It can also verify target mapping. Currently it is just a pass-thru
to the TestSystemState1 function.



=cut

=over 1

=item Usage:

 my $rc = VerifyIO($coPtr, $asPtr, $tlPtr, $vlPtr, $snPtr);
 
 where: $coPtr is a pointer to a list of controller objects
        $asPtr a pointer to an active server information list
        $tlPtr a pointer to a target map list
        $vlPtr a pointer to an active vdisk list
        $snPtr a pointer to a list of serial numbers

=item Returns:

       $rc will be GOOD if the IO is OK, ERROR will be returned if the
          current state of the IO is other than expected.



=back

=cut

##############################################################################
#
#          Name: VerifyIO
#
#        Inputs: controller object pointer and other data
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Using the pre-collected data in a manner similar to
#                other IO verification routines, verify that the same
#                basic level of IO is still running. This should include
#                server and vdisk IO.
#
##############################################################################
sub VerifyIO
{
    my ( $coPtr, $asPtr, $tlPtr, $vlPtr, $snPtr) = @_;
    my $ret;
        

    logInfo("      Verify ongoing IO ");

    TestNReconnectAll($coPtr);          # refresh any connections
    
    
    # this checks the server and vdisk IO    
    $ret = &TestLibs::Validate::TestSystemState1($coPtr, $asPtr, $tlPtr, $vlPtr, $snPtr);

    # this checks the status on the back end and can't be called 
    # if a defrag is in progress
    #$ret = TestSystemState2($ctlr, $pdaPtr, $vdaPtr, $rdaPtr);


    if ( $ret != GOOD )
    {
        logInfo(" IO checks have failed. ");
#        return GOOD;
    }

    
    return $ret;
}


###############################################################################

=head2 DeleteUnusedVdisks function

This function identifies all vdisks that are currently NOT mapped to any
server. These vdisks are then deleted. The caller may pass in a list 
of disks to exclude for the deletion process.



=cut

=over 1

=item Usage:

 my $rc = DeleteUnusedVdisks($ctlr, $slPtr );
 
 where: $ctlr is the controller (object) to use
        $slPtr is a pointer to a list of vdisk that are NOT to be deleted
               $slPtr may be 0 if there is no list


=item Returns:

       $rc will be GOOD is vdisks were all deleted. ERROR or INVALID may
          be returned on failure.



=back

=cut

##############################################################################
#
#          Name: DeleteUnusedVdisks
#
#        Inputs: controller object, pointer to skip list 
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Identify all the unmapped vdisks and delet them. If a vdisk
#                is not associated with a server, then it is considered unused.
#                Use vdisklist, vdiskowner and vdiskdelete. To not use
#                a skip list, set the pointer to 0.
#
##############################################################################
sub DeleteUnusedVdisks
{
    my ( $ctlr, $slPtr ) = @_;

    my %rsp;
    my %rspp;
    my $str;
    my $i;
    my $j;
    my $matched;
    my @ArrayVirtual;
    my $string;
    my @skipList;

    my %info;

    logInfo("      Deleting vdisks that are not associated. ");

    if ( $slPtr )
    {
        @skipList = @$slPtr;
    }


    # get a list of vdisks

    ##############
    # VDISK List
    ##############

    %info= $ctlr->virtualDiskList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskList <<<<<<<<");
        return ERROR;
    }

    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
    
    $string = $info{LIST};

    @ArrayVirtual = @$string;         
    
    logInfo("List of Virtual disks @ArrayVirtual");

    # for each drive in the list

    for ( $i = 0; $i < scalar(@ArrayVirtual); $i++ )
    {

        # see if it is in our skip list


        $matched = 0;

        if ( $slPtr )
        {
            for ( $j = 0; $j < scalar(@skipList); $j++ )
            {
                if ( $ArrayVirtual[$i] == $skipList[$j] )
                {
                    $matched = 1;       # the vdisk is in the skip list
                }
            }
        }

        if ( $matched == 1 ) {next;}     # if in list, do not delete
        
        # see if it has an owner

        # print ("checking owner of vdisk $ArrayVirtual[$i] \n");

        #
        # Get Disk Owner Info
        #
        %rsp = $ctlr->virtualDiskOwner($ArrayVirtual[$i]);
        
        if ( ! %rsp  )
        {
            logInfo(">>>>> Failed to get response from virtualDiskOwner <<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>> Unable to retrieve virtual Disk Owner for vdisk $ArrayVirtual[$i]. <<<<<");
            PrintError(%rsp);
            return ERROR;
        }


        #
        # Get Vdisk Info
        #
        %rspp = $ctlr->virtualDiskInfo($ArrayVirtual[$i]);

        if ( ! %rspp  )
        {
            logInfo(">>>>> Failed to get response from virtualDiskInfo <<<<<");
            return ERROR;
        }

        if ($rspp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>> Unable to retrieve virtual Disk Info for vdisk $ArrayVirtual[$i]. <<<<<");
            PrintError(%rspp);
            return ERROR;
        }


        # Check for Vdisk that is mirrored first, then if associated.
        # if mirrored, skip
        # if not, delete it

        if (   $rspp{MIRROR} == 0 ) 
        {
            if (   $rsp{NDEVS} == 0 )
            {
     
                if ( ERROR == DeleteSingleVdisk($ctlr, $ArrayVirtual[$i]) ) 
                {
                    logInfo("Failed to delete  $ArrayVirtual[$i] ");
                    return ERROR;
                }
                else
                {
                    logInfo ("Vdisk $ArrayVirtual[$i] deleted.");
                }
     
            }

        }
        
    }  # for each vdisk
    # done

    return GOOD;
}

###############################################################################

=head2 DeleteVdiskList function

This function deletes all vdisks in a list provided by the caller. If any disk 
is in-use, this will retry until the disk is available to be deleted.



=cut

=over 1

=item Usage:

 my $rc = DeleteVdiskList($ctlr, $lPtr );
 
 where: $ctlr is the controller (object) to use
        $lPtr is a pointer to a list of vdisks to be deleted


=item Returns:

       $rc will be GOOD is vdisks were all deleted. ERROR or INVALID may
          be returned on failure.



=back

=cut

##############################################################################
#
#          Name: DeleteVdiskList
#
#        Inputs: controller object, pointer to vdisk list 
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Identify all the unmapped vdisks and delet them. If a vdisk
#                is not associated with a server, then it is considered unused.
#                Use vdisklist, vdiskowner and vdiskdelete. To not use
#                a skip list, set the pointer to 0.
#
##############################################################################
sub DeleteVdiskList
{
    my ( $ctlr, $slPtr ) = @_;

    my $i;
    my @diskList;
    my $retVal = GOOD;
    my $keepGoing;
    my $loopCount;
    my %rsp;

    @diskList = @$slPtr;
    logInfo("      Deleting the following vdisks: @diskList . ");


    $keepGoing = 1;
    $loopCount = 0;

    while (($keepGoing != 0) && ($retVal == GOOD))
    {
        $keepGoing = 0;
        $loopCount += 1;

        # for each drive in the list, delete it
        
        print "\rDelete vdisk loop, pass # $loopCount         ";
        
        for ( $i = 0; $i < scalar(@diskList); $i++ )
        {

            if ( $diskList[$i] != INVALID)
            {
                #logInfo("Deleting $vid");
                %rsp = $ctlr->virtualDiskDelete($diskList[$i]);

                if ( ! %rsp  )
                {
                    logInfo(">>>>> Failed to get response from virtualDiskDelete <<<<<");
                    $retVal =  ERROR;
                }

                if ($rsp{STATUS} != PI_GOOD)
                {
                    if ( $rsp{ERROR_CODE} != 0x09  )     # PI_ERROR_DEV_USED
                    {
                        logInfo(">>>>> In loop $loopCount, unable to delete virtual disk $diskList[$i]. <<<<<");
                        PrintError(%rsp);
                        $retVal =  ERROR;
                    }
                    else
                    {
                        # error was 'in use' so we ignore it and keep looping
                        $keepGoing = 1;
                    }    
                }
                else 
                {
                    # report success
                    logInfo("\nVdisk $diskList[$i] deleted in pass $loopCount");
                    
                    # remove vdisk from list
                    $diskList[$i] = INVALID;
                    
                }

            }
        }  
    
    }
    
    # done

    return $retVal;
}


###############################################################################

=head2 FindMovingVdisks function

This function attempts to identify vdisks that are currently being moved by
defrag. It will return up to the requested number of vdisks.



=cut

=over 1

=item Usage:

 my @rc = FindMovingVdisks($ctlr, $request );
 
 where: $ctlr is the controller (object) to use
        $request is the desired number of vdisks to return

=item Returns:

       @rc will be a list of the vdisks found. The first entry will be
           INVALID on failure.  An empty list would imply no vdisks were
           found to be moving.



=back

=cut

##############################################################################
#
#          Name: FindMovingVdisks
#
#        Inputs: controller object pointer, number of vdisks to get
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Using raidinfo, locate the desired number of vdisks
#                that are currently being defragged. Hint:
#                in raidinfo, psstatus will be 0x13.
#
##############################################################################
sub FindMovingVdisks
{
    my ( $ctlr, $request ) = @_;

    my @invAr;
    my %info;
    my $string;
    my @array_Raid;
    my $j;
    my $i;
    my $k;
    my $vid;
    my $notNew;
    my $numSelected;
    my @selected;

    logInfo("      Finding $request 'moving' vdisks. ");

    $invAr[0] = INVALID;
    
    # make one pass thru the raids, return the first "$request" vdisks
    # that seem to be moving.

    # get the list of raids

    %info = $ctlr->raidList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raidList <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raidList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    $string = $info{LIST};
    @array_Raid = @$string;        


    #
    # go thru each raid and look for defrag activity.
    #

    $numSelected = 0;

    for ( $i = 0; $i < scalar(@array_Raid); $i++ )
    {
        my $id = $array_Raid[$i];

        # RAIDINFO
        
        %info = $ctlr->virtualDiskRaidInfo($id);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskRaidInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskRaidInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
     
        # got the raidinfo data, now look at it

        
        for ($j = 0; $j < $info{PSDCNT}; $j++)
        {
              # printf "    %5hu               0x%02x         0x%02x\n",
              #        $info{PIDS}[$j]{PID},
              #        $info{PIDS}[$j]{PSD_STATUS},
              #        $info{PIDS}[$j]{PSD_ASTATUS};

            if (  0x13 == $info{PIDS}[$j]{PSD_STATUS} )
            {
                # we got one that is defragging
                $vid =  $info{VID};

                # is it new?
                $notNew = 0;

                for ( $k = 0; $k < scalar(@selected); $k++ )
                {
                    if ($vid == $selected[$k] )
                    {
                        $notNew = 1;
                    }
                }
                if ( $notNew == 1  )
                {
                    # this pdd is already in the list, skip rest of this raid
                    last;
                }
                
                # it is new, put in array

                $selected[$numSelected] = $vid;
                $numSelected++;
                
                # do we have enough now?
                if ( $numSelected >= $request )
                {    
                    # if so, we can return to caller
                    return @selected;
                }
                
                
                # go to next raid to look for another vdisk
                
                last;                          # done with this raid
            }

        # done with this psd
        }
    
    
    # done with this raid                         
    }


    
    # didn't return earlier, means we didn't find as many as requested
    # return with what we have.

    if ( scalar(@selected) == 0 )
    {
        logInfo(" In FindMovingVdisks, none were found.");
    }
    

    return @selected;


}


###############################################################################

=head2 GetRandomVdisks function

This function selects the requested number of vdisks at random. The selection
is done by 'sampling without replacement' to generate the list. The 
requested number must not exceed the number of available vdisks. The 
vdisks returned are unsorted (it is random selection). Any error will
cause the function to return with INVALID as the first element of the list.


=cut

=over 1

=item Usage:

 my @rc = GetRandomVdisks($ctlr, $request );
 
 where: $ctlr is the controller (object) to use
        $request is the desired number of vdisks to return

=item Returns:

       @rc will be a list of the vdisks found. The first entry will be
           INVALID on failure.  


=back

=cut

##############################################################################
#
#          Name: GetRandomVdisks
#
#        Inputs: controller object pointer, number of vdisks to get
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Get the requested number f random vdisks.
#
##############################################################################
sub GetRandomVdisks
{
    my ( $ctlr, $request ) = @_;

    my @invAr;
    my $listSize; 
    my $i; 
    my $vd; 
    my $j; 
    my $gotOne;
    my $didntGet; 
    my @selected;
    my @vdList;
    my $ret;
    my @Array_Virtual;

    $invAr[0] = INVALID;

    logInfo("      Selecting $request random vdisks. ");
    
    my %info;
    # get a list of vdisks

    %info= $ctlr->virtualDiskList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskList <<<<<<<<");
        return @invAr;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskList <<<<<<<<");
        PrintError(%info);
        return @invAr;
    }
    
    my $string = $info{LIST};
    @vdList = @$string;         

    # remove any vlinks from the list

    $ret = RemoveVlinks($ctlr, \@vdList, \@Array_Virtual );
    
    # print " \ngetRandom vdisks: \n";
    # print " starting list:  @vdList \n";
    # print "   ending list:  @Array_Virtual \n";

    if ( $ret != GOOD )
    {
        return @invAr;
    }


    # validate the requested number

 #   if ( $request >= scalar(@Array_Virtual) )
 #   {
 #       logInfo("There are not enough vdisks to satisfy the request for $request vdisks.");
 #       return @invAr; 
 #   }


    # this method is 'random selection without replacement'

    $listSize =  scalar(@Array_Virtual);

    # makes this work with systems that are 50% mirror destinations
    
    $request = int( min( $request, (0.9 * $listSize) ) );
    
    
    # for each requested disk
    for ( $i = 0; $i < $request; $i++ )
    {
        # select a random number
        $vd = randomInt(0, ($listSize - 1));

        # remove it from the list
        $gotOne = 0;                          # clear flag
        $didntGet = 0;                        

        for ( $j = 0; $j <$listSize; $j++)
        {
            if ( $j == $vd )
            {
                # we are at the chosen index
                $gotOne = 1;                # set flag
                $selected[$i] = $Array_Virtual[$j];  # get the vd
            }
            else
            {
                # this isn't the one we wanted
                if ( $gotOne != 0 )
                {
                    # copy the one after the selected item up one position
                    $Array_Virtual[$j-1] = $Array_Virtual[$j];
                }
            }


        }

        $listSize--;

        # rebuild the list - already done.
    }

    # return the list
    return @selected;

}


###############################################################################

=head2 FailMyOwner function

This function takes the supplied vdisk and determines which controller
currently owns this disk. That controller is then failed using the 
'fail controller' command.


=cut

=over 1

=item Usage:

 my $rc = FailMyOwner($coPtr, $snPtr, $vdd );
 
 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of corresponding serial numbers
        $vdd is the vdisk numbere to use

=item Returns:

       $rc will be GOOD if a controller was found and successfully failed.
           The result will be ERROR or INVALID on a failure.  


=back

=cut


##############################################################################
#
#          Name: FailMyOwner
#
#        Inputs: controller object list pointer, vdisk number
#
#       Outputs: GOOD or ERROR or INVALID
#
#  Globals Used: none
#
#   Description: Find the first vdisk owned by the controller
#
##############################################################################
sub FailMyOwner
{
    my ($coPtr, $snPtr, $vdd) = @_;
    
    my $ret;
    my $snIndex;
    my $target;
    my @snList;

    @snList = @$snPtr;
    
    logInfo("      Failing the controller that owns vdisk $vdd.");
     
    # Determine which controller owns the vdisk
    
    ($snIndex, $target) = FindVdiskOwner($coPtr, $snPtr, $vdd);

    if ( $snIndex == INVALID )
    {
        return INVALID;
    }
    
    # fail it
    logInfo("      Failing controller ( s/n = $snList[$snIndex] ) using FC.");

    $ret = FailOverController($coPtr, $snIndex, "FC" );
    
    logInfo("Pause for 40 seconds to allow the failover to finish");

    DelaySecs(40);       # allows for electsions and failover to occur

    return $ret;

}

###############################################################################

=head2 UnfailAll function

This function looks at the VCGINFO on the master (after finding it) and
creates a list of FAILED controllers. Each controller in the list is then
unfailed. A two minute pause is done at the end to allow the system to 
stabilize.


=cut

=over 1

=item Usage:

 my $rc = UnfailAll($coPtr, $snPtr, $moxaIP, $moxaPtr  );
 
 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of corresponding serial numbers
        $moxaIP is the IP address of the Moxa power commander
        $moxaPtr is a pointer to the moxa channel map list

=item Returns:

       $rc will be GOOD all failed controllers are successfully unfailed.
           ERROR or INVALID will be returned on failure.  


=back

=cut

##############################################################################
#
#          Name: UnfailAll
#
#        Inputs: controller object list pointer, serial number list ptr
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Find the first vdisk owned by the controller
#
##############################################################################
sub UnfailAll
{
    my ($coPtr, $snPtr, $moxaIP, $moxaPtr ) = @_;

    my @deadOnes;
    my $master;
    my $ctlr;
    my %info;
    my $j;
    my @snList;
    my $ret;
    my @moxaMap;
    my @moxaList;
    my @coList;
    my $i; 
    my $found;

    @moxaList = @$moxaIP;
    @moxaMap = @$moxaPtr;
    @coList = @$coPtr;
    @snList = @$snPtr;

    logInfo("      Locating and unfailing all failed controllers.");

    # find the master
    $master = FindMaster($coPtr);

    if ( $master == INVALID ) 
    { 
        logInfo("Could not identify the master controller. Controllers may still be failed.");
        return(ERROR); 
    } 

    # from vcginfo on the master, identify all failed controllers
    $ctlr = $coList[$master];
    
    %info = $ctlr->vcgInfo(0);
    
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get vcginfo from controller (no resp, index: $i) <<<<<<<<");
        return (ERROR);
    }


    if ($info{STATUS} == PI_GOOD)
    {
       
        # if sn match with max controllers > 1 and master

        # check max controllers
        if (  $info{VCG_MAX_NUM_CONTROLLERS} > 1)            
        {
            # check each controller listed
            for ( $j = 0; $j < $info{VCG_MAX_NUM_CONTROLLERS}; $j++ )   
            {
                if ( ($info{CONTROLLERS}[$j]{FAILURE_STATE} == FD_STATE_INACTIVATED) || 
                     ($info{CONTROLLERS}[$j]{FAILURE_STATE} == FD_STATE_FAILED)  )   
                {
                    # save the serial number of the failed controller
                    push( @deadOnes, $info{CONTROLLERS}[$j]{SERIAL_NUMBER} );

                }
            }
        }
                
    }
    else
    {
        logInfo(">>>>>>>> Error getting vcginfo from controller (error returned, index: $i) <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    if ( scalar( @deadOnes) < 1 )
    {
        # there were no failed controllers
        logInfo("No failed controllers were found.");
        return GOOD;
    }

    # unfail each
    for ( $i = 0; $i < scalar( @deadOnes); $i++ )
    {   
        # need to map the serial numbers to the moxa index
        $found = 0;
        for ( $j = 0; $j < scalar(@snList); $j++ )
        {   
            if ( $snList[$j] == $deadOnes[$i] )
            {
                # found it ...  Use $j as the index
                $found = 1;
                last;
            }
        }
        
        #
        # Verify we found a serial number match.
        # If not, return with error.
        #
        if ( !$found )
        {
            logInfo(">>>>>>>> Failed controller ($deadOnes[$i]) not found in serial number list. <<<<<<<<");
            return ERROR;
        }
        
        logInfo("      Power cycling controller $snList[$j] ");

        # first cycle power
        $ret = TestLibs::IntegCCBELib::PowerCycle($moxaList[$j], $moxaMap[$j]);
        if ( $ret != GOOD ) { return ERROR; };


        # need to reconnect to the controller
        if ($coList[$j])
        {
            logInfo("Pause for 60 seconds and reconnect to controller $deadOnes[$i] ");
            $ret = TestLibs::IntegCCBELib::Reconnect( $coList[$j], 60 );
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> Failed to reconnect to the controller    <<<<<<<<");
                return ERROR;

            }
            # wait for the controller to sufficiently boot

            # logInfo("      Reconnect complete. Checking power up state. ");

            &TestLibs::Validate::Wait4MinPowerUpState($coList[$j], POWER_UP_FAILED, 480);          

            # logInfo("      Power up state verified. ");

        }
        else
        {
            logInfo("Pause for 200 seconds to allow controller to power up ");
            DelaySecs(200);
        }

        #
        # unfail the controller
        #
        
        logInfo("Unfailing the controller ($deadOnes[$i])  ");
        $ret = TestLibs::IntegCCBELib::UnFailController( $coList[$master], $deadOnes[$i] );
        if (  $ret == ERROR )
        {
            logInfo(">>>>>>>> Failed to restore the controller to active duty  <<<<<<<<");
            return ERROR;
        }


    }

    # delay about 2 minutes to allow the world to settle down
    logInfo("Wait for 120 seconds to allow the system to stabilize.");
    DelaySecs(120);

    return GOOD;

}


###############################################################################

=head2 FirstVdiskOnCtlr function

This function gets a list of all vdisks on the system. It searches the 
list until it finds a vdisk that is associated to ( owned by) the specified
controller. The controller to find is speified using its index in the 
controller object list.

=cut

=over 1

=item Usage:

 my $rc = FirstVdiskOnCtlr($coPtr, $vdPtr, $index, $snPtr  );
 
 where: $coPtr is a pointer to a list of controller objects
        $vdPtr is a pointer to a list of vdisks to use
        $index is the index into the coList and snList lists to use
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be the vdisk number of the first vdisk in the list that 
           is associated to the server. INVALID will be returned on a
           failure to find a matching vdisk.  


=back

=cut

##############################################################################
#
#          Name: FirstVdiskOnCtlr
#
#        Inputs: controller object pointer, ptr to list of vdd, index to controller
#
#       Outputs: a vdisk number or INVALID
#
#  Globals Used: none
#
#   Description: Find the first vdisk owned by the controller
#
##############################################################################
sub FirstVdiskOnCtlr
{
    my ($coPtr, $vdPtr, $index, $snPtr) = @_;

    my @vdisks;
    my $i;
    my $snIndex;
    my $target;
    

    @vdisks = @$vdPtr;

    logInfo("      Finding the first vdisk on the controller. ");
    logInfo("      Searching the following vdisks: @vdisks ");

    # for each vdisk
    for ( $i = 0; $i < scalar(@vdisks); $i ++ )
    {
        
        # find its owner
        ($snIndex, $target) = FindVdiskOwner($coPtr, $snPtr, $vdisks[$i]);


        # does it match the request?
        if ( ($target != INVALID) && ($index == $snIndex) )
        {
            # if so, return the vdisk number
            return  ($vdisks[$i]);
        }
    }

    # we got no match.
    return INVALID;

}

###############################################################################

=head2 FindVdiskOwner function

This function returns the index into the controller object list that
corresponds to the owner of the supplied vdisk.

=cut

=over 1

=item Usage:

 my ($rc1, $rc2) = FindVdiskOwner($coPtr, $snPtr, $vdd  );
 
 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $vdd is the vdisk to use

=item Returns:

       $rc1 will be the index into the controller object list. INVALID 
           will be returned on a failure to find a match. 
       $rc2 will be the target number. INVALID will be returned on a 
           failure. 


=back

=cut

##############################################################################
#
#          Name: FindVdiskOwner
#
#        Inputs: ptr to object list, ptr to serial number list, vdisk number
#
#       Outputs: a list index or INVALID, target number or INVALID
#
#  Globals Used: none
#
#   Description: Find the controller that owns the vdisk
#
##############################################################################
sub FindVdiskOwner
{
    my ($coPtr, $snPtr, $vdd) = @_;

    my @coList;
    my $ctlr;
    my $master;
    my $i;
    my $j;
    my $k;
    my $target;
    my $index;
    my %info;
    my @targets;
    my @servers;
    my $targPtr;
    my $servPtr;
    my $owner;
    my $targetCount;
    my @snList;
    my @VdList;

    @snList = @$snPtr;

    @coList = @$coPtr;

    logInfo("      Finding the owner for vdisk $vdd. ");

    $master = FindMaster($coPtr);
    
    if ( $master == INVALID ) { return(INVALID, INVALID); } 

    $ctlr = $coList[$master];
    
    
    # get targetst data
    %info = GetTargetStatus($ctlr);

    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from targetStatus <<<<<<<<");
        return (INVALID, INVALID);
    }

    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get target status <<<<<<<<");
        PrintError(%info);
        return (INVALID, INVALID);
    }

    # search hash for the vdisk
    
    $target = INVALID;                  # used as a flag


    $targPtr = $info{TARGETS};
    $servPtr = $info{SERVERS};
    
    @targets = @$targPtr;
    @servers = @$servPtr;


    $targetCount = scalar(@targets);

    # gotta love searching big hashes
    # get the controller SN, target number
    for ($i = 0; $i < $targetCount; ++$i)
    {
        for ($j = 0; $j < scalar(@servers); ++$j)
        {
            if ($targets[$i]{TGD_TID} == $servers[$j]{TARGETID})
            {
                
                if ($servers[$j]{NLUNS} > 0)
                {
                    for ($k = 0; $k < $servers[$j]{NLUNS}; ++$k)
                    {

                        if ( $servers[$j]{LUNMAP}[$k]{VID} == $vdd )
                        {
                            # found the vdisk
                            $target = $targets[$i]{TGD_TID};     # the target number
                            $owner =  $targets[$i]{TGD_OWNER};   # the serial number 
                        }
                    }
                }   
            }
        }
    }

    # get index from serial number
    if ( $target == INVALID )
    {
        # we did not match, this vdisk is not owned 
        # declare the master to own it
        # get list of vd ids find vd id, if not there return (INVALID, INVALID)
        # if there means master owes it return ( Master, INVALID);
        
        logInfo("Could not find the vdisk on any targets. ");
        logInfo("Looking for unassociated vdisk on master.");
        
        @VdList = GetVdiskList( $ctlr );
        
        # no virtual disks created

        if(scalar(@VdList) == 0)
        {
            return (INVALID, INVALID);
        }
        
        # check if there was error

        if($VdList[0] == INVALID)
        {
            return (INVALID, INVALID);  
        } 

        for(my $o = 0; $o < scalar(@VdList); $o++)
        {
            if( $VdList[$o] == $vdd)
            {
                # Found vd id, vd is exists

                return ($master, INVALID);  
            }
        }
        
        # did not find vd id, vd id invalid

        return (INVALID, INVALID);
    }

    # find the index in the SN array 
    for ( $i = 0; $i < scalar(@snList); $i++ )
    {
        if ( $snList[$i] == $owner )
        {
            # found it, have target and sn index
            return ($i, $target );
        }
    }


    # return as failed


    return (INVALID, INVALID);
}


###############################################################################

=head2 FindEarlyVdisk function

This function returns a list of early vdisks. Early means they are at
lower LBA numbers on the physical disks. The disks are selected from the
vdisks that have RAIDs on the first data disk. The list may be empty if 
there are no vdisks using the first data disk. If there are not enough 
vdisks to satisy the request, a smaller list will be returned.

=cut

=over 1

=item Usage:

 my ($rc) = FindEarlyVdisk($ctlr, $request  );
 
 where: $ctlr is the controller object
        $request is the number of vdisks to return

=item Returns:

       @rc is a list of vdisks. The first element wiil be INVALID on
           error. This list may be empty. 


=back

=cut

##############################################################################
#
#          Name: FindEarlyVdisk
#
#        Inputs: controller object pointer, number of vdisks to get
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Using the ability find where a raid starts, find the
#                vdisk that begins at the lowest block number. THis 
#                function can return one or more vdisks, so it will
#                return an array. The locations of the raids comes from
#                sos tables.
#
##############################################################################
sub FindEarlyVdisk
{
    my ( $ctlr, $request ) = @_;
    my @pdds;
    my $drive;
    my @raids;
    my $i;
    my $j;
    my $numRaids;
    my @vdisks;
    my @vdisks2;
    my %rsp;
    my %info;
    my @badAr;
    my $gotOne;
    my $count; 
    my $candidate;    
    my $ret;
    my %vdisks;  

    $vdisks2[0] = INVALID;   # in the event we don't first a match
    $badAr[0] = INVALID;     # in the event we return bad    
    
    
    #
    # Get list of all Vdisks
    #
    %vdisks = $ctlr->virtualDisks();    # get the follow-up reading
    
    if ( ! %vdisks  )
    {
        logInfo(">>>>>>>> Failed to get response from vdisks <<<<<<<<");
        return ERROR;
    }

    if ($vdisks{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get vdisks <<<<<<<<");
        TestLibs::IntegCCBELib::PrintError(%vdisks);
        return ERROR;
    }
    
    
    logInfo("      Locate $request 'early' vdisks ");
    
    
    # use the following steps

    # devstat PD - gives us a list of disks and their label type
    
    @pdds = GetDataDisks($ctlr, PD_DT_ALL);
    
    # select a data disk ( the first one ) This is arbitrary.
    if ( $pdds[0] == INVALID )
    {
        # could not get the list
        logInfo("Did not get any disks to work with");
        return @badAr;
    }
    else
    {
        $drive = $pdds[0];
    }

    # do "sostable pdd" to get the sos table, in there is a list
    # of raids, ordered by block address

    %info = $ctlr->getSos($drive);
    if( ! %info )
    {
        logInfo(">>>>>>>> Failed to get SOS information. <<<<<<<<");
        return @badAr;
    }

    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from getSOS command <<<<<<<<");
        PrintError(%info);
        return @badAr;
    }

    # extract the list of ordered raids

    $numRaids = $info{COUNT};

    if ( $numRaids == 0 )
    {
        # we shouldn't be here if there are no raids
        return @badAr;
    }

    for ( $i = 0; $i < $numRaids; $i++ )
    {
        if ( $info{LIST}[$i]{RID} < 2048 )
        {
            push (@raids, $info{LIST}[$i]{RID});
        }
    }    


    # do "raids" to get a list of raids and their corresponding vdisks

    %info = $ctlr->raids();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return @badAr;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%info);
        return @badAr;
    }
     
#    logRaids(%info);



    # map vdisks to the ordered raids
    for ( $i = 0; $i < scalar(@raids); $i++ )
    {
        $gotOne = 0;       # a flag
        
        for ( $j = 0; $j < $info{COUNT}; $j++ )
        {
            if ( $raids[$i] ==  $info{RAIDS}[$j]{RID} )
            {
                $vdisks[$i] =  $info{RAIDS}[$j]{VID};
                $gotOne = 1;
            }
        }
    
        if ( $gotOne == 0 )
        {
            logInfo("Couldn't match a Vdisk to RDD $raids[$i] ");
            return @badAr;
        }
    }


    # now, remove the extra entries for vdisks that have multiple raids
    # (The list will now have vdisks sorted by the location of their
    #  raid that appears first in the list.)
    # Also extract extract and return the first 'n' requested entries
    
    $count = 0;

    for ( $i = 0; $i < scalar(@raids); $i++ )
    {
        $candidate = $vdisks[$i];

        $gotOne = 1;

        for ( $j = 0; $j < $count; $j++ )
        {
            if ($candidate == $vdisks2[$j] )
            {
                # this guy is already in the list, we can't use it
                $gotOne = 0;
            }
            
        }
        
        #
        # Check if Vdisk is a mirror.  If so, skip add to list
        #
        
        if ($gotOne != 0)
        {        
            $ret =  TestLibs::Validate::IsVdiskMirrorDest($candidate, \%vdisks );

                    
            if ($ret == 1)
            {
                $gotOne = 0;
            }
        }
        #
        # Add to list
        #
        if ( $gotOne == 1 )
        {
            # $candidate is not already in the list, add it
            $vdisks2[$count] = $candidate;
            $count++;
            if ( $count == $request )
            {
                # if we have enough, we are done
                return @vdisks2;
            }

        }

        # we have checked this raid and added it to the list if unique
    }

    # we went thru the list, found all that we could but
    # have not yet found enough, return with what we did find

    return @vdisks2;
}




###############################################################################

=head2 RediCpVdisks function

This function begins a redi-copy operation of the controller. It will
use COPY SWAP for the operation.

=cut

=over 1

=item Usage:

 my ($rc1) = RediCpVdisks($ctlr, $src, $dest  );
 
 where: $ctlr is the controller object
        $src is the source vdisk number
        $dest is the destination vdisk number

=item Returns:

       $rc1 will be the GOOD or ERROR. 


=back

=cut

##############################################################################
#
#          Name: RediCpVdisks
#
#        Inputs: controller object, src vdisk, dest vdisk 
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Starts the specified redi-copy operation on the controller
#                simile to  redicp::StartCopyOp() but is always copy-swap
#
##############################################################################
sub RediCpVdisks
{
    my ($ctlr, $src, $dest) = @_;
    trace();

    logInfo("      Starting a redi-copy operation ");
    logInfo("        with ctlr = $ctlr->{HOST}, src = $src, dest = $dest");

    my %rsp = $ctlr->virtualDiskControl(0x02, $src, $dest);

    if (!%rsp)                        # no response
    {
        logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != GOOD )            # 0 is good
    {
        logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    return GOOD;
}


##############################################################################
#
#          Name: MoveOwner
#
#        Inputs: master object, owner object, src vdisk number
#
#       Outputs: GOOD, if the owner is correct, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Checks the number of raids in the vdisk to see if it meets
#                the requirement for multiple of single raid testing
#
##############################################################################


sub MoveOwner
{
    my ( $ctlrM, $ctlrO, $src) = @_;

#         $coList[$ourMaster]
#         $coList[$owner]
    my %rsp;
    my $serial;
    my $targPtr;
    my $servPtr;
    my @servers;
    my @targets;
    my $targetCount;
    my $newTarget;
    my $newChannel;
    my $i;
    my $j;
    my $k;
    

    # get desired owner's serial number
    $serial = GetSerial($ctlrO);
    
    if ($serial == INVALID)
    {
        # bad serial number
        return ERROR;
    }

    # find the target number and the current owner's serial number

    # get target mapping info (via targetstatus)
    %rsp = GetTargetStatus($ctlrM);
    if ( $rsp{STATUS} !=GOOD)
    {
        # bad targetstatus information 
        return ERROR;
    }

    # find the vdisk in this data and see if it is attached to
    # this serial number

    $targPtr = $rsp{TARGETS};
    $servPtr = $rsp{SERVERS};
    @targets = @$targPtr;
    @servers = @$servPtr;
    $targetCount = scalar(@targets);

    print ("Checking that controller $serial owns vdisk $src \n");

    # drill down to the VIDs and check the owners serial for a match
    for ($i = 0; $i < $targetCount; ++$i)
    {
        for ($j = 0; $j < scalar(@servers); ++$j)
        {
            if ($targets[$i]{TGD_TID} == $servers[$j]{TARGETID})
            {
                if ($servers[$j]{NLUNS} > 0)
                {
                    for ($k = 0; $k < $servers[$j]{NLUNS}; ++$k)
                    {
                        if ( $src == $servers[$j]{LUNMAP}[$k]{VID})
                        {
                            # we found the matching vdisk
        
                            $newTarget = $i;         # save the target number

                            if ( $serial == $targets[$i]{TGD_OWNER} )
                            {
                                # serial number matched for this vdisk
                                print " Vdisk is already on the correct controller\n";
                                return GOOD;
                            }

                            # we are going to fail, state what was actually found
                            logInfo("Vdisk $src is owned by controller $targets[$i]{TGD_OWNER}");
                        }
                    }
                }   
            }
        }
    }

    
    # if current owner serial number is not correct,
    # move the target to the desired owner

    # get the current channel
    %rsp = $ctlrM->virtualDiskOwner($src);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from virtualDiskOwner in VRinfo <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Unable to retrieve virtual Disk Owner. <<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    if ( 1 == $rsp{NDEVS})
    {
        $newChannel =  $rsp{OWNERS}[0]{CHANNEL};
    }
    else
    {
        logInfo("Incorrect number of owners ($rsp{NDEVS}) for vdisk ($src) ");
        return ERROR;
    }

    # now move the target
    print " moving target $newTarget to controller $serial channel $newChannel \n";
    
    %rsp = $ctlrM->targetMove($newTarget, $serial, $newChannel);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from targetMove in MoveOwner <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Unable to move the vdisk to the correct owner. <<<<<");
        PrintError(%rsp);
        return ERROR;
    }


    return GOOD;
}

##############################################################################
sub ServerPropSpin
{
    my ( $ctlr, $count ) = @_;


    my $i;
    my @SIDarray;

    # serverlist
    my %rsp = $ctlr->getObjectList(PI_SERVER_LIST_CMD);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            debug("Got server list successfully");
        }
        else
        {
            logInfo(">>>>> Failed to get server list <<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }
    else
    {
        logInfo("Did not receive a response packet getting server list");
        return ERROR;

    }


    my $numSIDs = $rsp{COUNT};

    for ( $i=0; $i < $numSIDs; $i++ )
    {
        push @SIDarray, $rsp{LIST}[$i];
    }

    # loop $count times
    while ( $count-- )
    {

        # loop each server
        for ( $i = 0; $i < $numSIDs; $i++ )
        {
            # serverprop <s> 0 0
            SetServerProp( $ctlr, $SIDarray[$i] );
        }

    }

    #  done

}



###############################################################################

=head2 WaitForCpComplete function

This function loops until the specified redi-copy operation is 
complete. It then returns GOOD. If the operation never completes, the
system will hang.

=cut

=over 1

=item Usage:

 my ($rc1) = WaitForCpComplete($ctlr, $vid  );
 
 where: $ctlr is the controller object
        $vid is the destination vdisk number

=item Returns:

       $rc1 will be the GOOD. 


=back

=cut


##############################################################################
#
#          Name: WaitForCpComplete
#
#        Inputs: controller object, vdisk number
#
#       Outputs: progress completion amount, or INVALID 
#
#  Globals Used: none
#
#   Description: gets progress from vdiskinfo, calling loop may hang if 
#                errors persist
#
##############################################################################
sub WaitForCpComplete
{
    my ($ctlr, $vid ) = @_;
    trace();

    my $progress;

    logInfo("      Waiting for redi-copy to complete on drive $vid. ");

    # pause to allow the copy to really start
    sleep 10;
    
    # are we there yet?
    $progress = CopyProgress( $ctlr, $vid  );


    # if not done
    while ( ( $progress > 0 ) && ( $progress < 100 ) )
    {
        
        sleep(2);
        
        # update progress to see if we do it again  
        $progress = CopyProgress( $ctlr, $vid );
              
    }   # end of while  (progress)

    logInfo("");

    
    CheckAndWait4RediCp($ctlr, $vid, 120);      # up to 120 additional seconds
    
    return GOOD;
}


###############################################################################

=head2 CopyProgress function

This function get the progress indication for a redi-copy operation.
The progress indicator value is returned. On error the returned value
will be 99.

=cut

=over 1

=item Usage:

 my ($rc1) = CopyProgress($ctlr, $vid  );
 
 where: $ctlr is the controller object
        $vid is the destination vdisk number

=item Returns:

       $rc1 will be the progress value. 


=back

=cut


##############################################################################
#
#          Name: CopyProgress
#
#        Inputs: controller object, vdisk number
#
#       Outputs: progress completion amount, or INVALID 
#
#  Globals Used: none
#
#   Description: gets progress vrom vdiskinfo, calling loop may hang if 
#                errors persist
#
##############################################################################
sub CopyProgress
{
    my ($ctlr, $vid) = @_;
    trace();
    my $serial;

    # the progress indicator is in vdiskinfo

    my %rsp = $ctlr->virtualDiskInfo($vid);

    if (!%rsp)                        # no response
    {
        logInfo(">>>>> Failed to receive a response from virtualDiskInfo($vid) <<<<<");
        return 99;
    }
    elsif ($rsp{STATUS} != 0)            # 0 is good, anything else is bad
    {
        logInfo(">>>>> ERROR: virtualDiskInfo($vid) returned an error <<<<<");
        PrintError(%rsp);
        return 99;
    }

    # get and print the serial number
    $serial = GetSerial($ctlr);

    printf( "  Copy Progress, on ctlr %5d, (from %4d to %4d)=  %hu\r",
                $serial, $rsp{SCORVID}, $vid, $rsp{SCPCOMP});


    if (  ($rsp{SCPCOMP} == 0) && ( 1 ==  $rsp{MIRROR} )  )
    {
        # this handles a pending copy that has not started
        # without this we can ET to BE and cause other scritp problems
        return 1;
    }

    return $rsp{SCPCOMP};
}



###############################################################################

=head2 StartSingleDefrag function

This function starts defrag on a single pdisk.

=cut

=over 1

=item Usage:

 my $rc = StartSingleDefrag( $ctlr, $pdd  );
 
 where: $ctlr is a controller object
        $pdd is the pdisk to defrag

=item Returns:

       $rc will be GOOD or ERROR 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut


##############################################################################
#
#          Name: StartSingleDefrag
#
#        Inputs: controller object pointer and other data
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Starts a defrag on the specified pdd.
#
##############################################################################
=head2 StartSingleDefrag function

This function starts defrag on a single pdisk.

=cut

=over 1

=item Usage:

 my $rc = StartSingleDefrag( $ctlr, $pdd  );
 
 where: $ctlr is a controller object
        $pdd is the pdisk to defrag

  pdiskid              Identifier of the physical disk.
                       ALL or 0xFFFF - Defrag all physical disks
                       STOP or 0xFFFE - Stop all defrag operation
                       ORPHAN or 0xFFFD - Terminate all orphans
                       PID - Physical disk identifier

=item Returns:

       $rc will be GOOD or ERROR 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut


##############################################################################
#
#          Name: StartSingleDefrag
#
#        Inputs: controller object pointer and other data
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Starts a defrag on the specified pdd.
#
##############################################################################
sub StartSingleDefrag
{
    my ($ctlr, $id) = @_;
   
    print "\n";

    if (uc($id) eq "ALL")
    {
        $id = 0xFFFF;
    }
    elsif (uc($id) eq "STOP")
    {
        $id = 0xFFFE;
    }
    elsif (uc($id) eq "ORPHAN")
    {
        $id = 0xFFFD;
    }

    if (defined($id) && $id =~ /^0x/i)
    {
        $id = oct $id;
    }

    if (!defined($id) || uc($id) eq "STATUS" || $id < 0)
    {
        pdiskDefragStatus();
    }
    else
    {
        my %rsp = $ctlr->physicalDiskDefrag($id);

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                if ($id == 0xFFFF)
                {
                    $id = "ALL";
                }
                elsif ($id == 0xFFFE)
                {
                    $id = "STOP";
                }
                elsif ($id == 0xFFFD)
                {
                    $id = "ORPHAN";
                }

                print "Physical disk ($id) is defragmenting.\n";
            }
            else
            {
                my $msg = "Unable to defragment physical disk ($id).";
                TestLibs::scrub::displayError($msg, %rsp);
            }

           if ($rsp{STATUS} != PI_GOOD)
            {
                if ( ( $rsp{ERROR_CODE} ==  0x2d ) ||       # 0x2d = Active rebuild
                     ( $rsp{ERROR_CODE} ==  0x13 ) )        # 0x13 = Active defragmentation
                {
                    logInfo("Defrag already running on drive $id.");
                }
                elsif ( $rsp{ERROR_CODE} ==  0x20  )   # deinsuffredund,   0x20  
                                                       # insufficent redundancy exists
                {
                    logInfo("Insufficient redundancy exists for PDD $id. Cannot defrag.");
                    ConfigView( $ctlr, 0, 0 );      # show current config
                    GPRaidCommands($ctlr);          # show raid information
                                                    # we will allow this to continue
                }
                else
                {
                    logInfo(">>>>>>>> Unable to start defrag on drive $id. <<<<<<<<");
                    PrintError(%rsp);
                    return ERROR;
                } 

            }
            else
            {
               # display message
                logInfo("Defrag started on drive $id."); 
            }
        }
    }
    return GOOD;
}


###############################################################################

=head2 WaitRebuild function

This function waits for rebuild to finish on the specified controller.

=cut

=over 1

=item Usage:

 my $rc = WaitRebuild( $ctlr  );
 
 where: $ctlr is a controller object

=item Returns:

       $rc will be GOOD or ERROR 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut

##############################################################################
#
#          Name: WaitRebuild
#
#        Inputs: controller object pointer and other data
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Waits until all rebuilds are complete
#
##############################################################################
sub WaitRebuild
{
    my ($ctlr ) = @_;
    my $ret;
    my $lc;

    #############################
    # wait for rebuild to finish
    #############################
    # rebuild is done if no drives are 'degraded'

    logInfo("      polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0; 
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }

print("\n");

        DelaySecs( 15 );
    
    }
    
    PSDCheck($ctlr);    # see if all psds are operational

    return GOOD;
}


###############################################################################
sub PSDCheck
{
    # does a devstat RD and scans PSD_STATUS on all PSDs
    # logs the result, but always returns good. Written for bug 6825
    my ($ctlr) = @_;
 
    my %info;
    my $i;   
    my $pi;
    my $status = 0;
    my $astatus = 0;


    ########### devstat RD ################

    logInfo("Physical disk information");

    %info = $ctlr->deviceStatus("RD");

    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from deviceStatus <<<<<<<<");
        return ERROR;
    }

    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get device status <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    for $i (0..$#{$info{LIST}})
    {
 
        for ($pi = 0; $pi < $info{LIST}[$i]{PSDCNT}; $pi++)
        {

            $status  |= $info{LIST}[$i]{PIDS}[$pi]{PSD_STATUS};
            $astatus |= $info{LIST}[$i]{PIDS}[$pi]{PSD_ASTATUS};

        }    

    }
 
    logInfo("Accumulated PDS status is PSD_STATUS= $status, PSD_ASTATUS= $astatus."); 
    
    return GOOD;
}        
###############################################################################

=head2 Wait4Ses function

This function waits for SES infoi to be updated on the BE.

=cut

=over 1

=item Usage:

 my $rc = Wait4Ses( $ctlr, $timeout  );
 
 where: $ctlr is a controller object
        $timeout is the max time to wait (seconds)

=item Returns:

       $rc will be GOOD when all good drives have SES info
                or INVALID if there are some missing SES info 
                           after the timeout
                or ERROR is an error happens

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut

##############################################################################
#
#          Name: Wait4Ses
#
#        Inputs: controller object pointer timeout
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Waits until all rebuilds are complete
#
##############################################################################
sub Wait4Ses
{
    my ($ctlr, $timeout ) = @_;
    my %pdisks;
    my $noSesCount;
    my $goodCount;
    my $i;
    my $happyCount;

    #############################
    # wait for rebuild to finish
    #############################
    # rebuild is done if no drives are 'degraded'

    logInfo("Polling for good SES data on $ctlr->{HOST}");

    $happyCount = 0;

    while ( $timeout-- > 0 )
    {
        
        %pdisks = $ctlr->physicalDisks();
        
        if (! %pdisks )        
        {
            logInfo (">>>>>>>>>> no response from pdisks in Wait4Ses <<<<<<<<<<<");
            sleep 1;
            next;
            #return ERROR;
        }

        if ( $pdisks{STATUS} != PI_GOOD )
        {
            logInfo (">>>>>>>>>> Error from pdisks in Wait4Ses <<<<<<<<<<<");
            PrintError(%pdisks);
            sleep 1;
            next;
            #return ERROR;
        }

        # data is good, now scan it

        $noSesCount = 0;
        $goodCount = 0;

        for ( $i = 0; $i <$pdisks{COUNT} ; $i++ )
        {
        if (
            ($pdisks{PDISKS}[$i]{PD_DEVSTAT} == 0x10) ||           # if drive is good, or
               (($pdisks{PDISKS}[$i]{PD_DEVSTAT} == 0x01) &&       # if drive is inop AND
                ($pdisks{PDISKS}[$i]{PD_POSTSTAT} == 0x27))        # no rsvd area
           )
            {
                $goodCount++;

                if ( $pdisks{PDISKS}[$i]{SES} == 0xffff )
                {
                    $noSesCount++;
                }
            }
        }

        if ( ($noSesCount == 0) && ($goodCount > 0) )
        {

            # since multiple passes may be done, look for three 
            # consecutive good ones

            $happyCount++;

            if ( $happyCount > 5 )
            {
                logInfo("Good SES poll complete");
                
                return GOOD;
            }
            
        }
        else
        {
            # reset good count if we get a bad one
            $happyCount = 0;
        }    
            
        sleep 1;
    }
    
    logInfo(" Wait for SES: timed out. Number good drives = $goodCount. Number with no SES = $noSesCount.");
    
    return INVALID;
}
        
###############################################################################

=head2 FailPdisk function

This function simulates a pdisk failure by either sending a SCSI stop unit 
command to a pdisk or bypassing both ports on a pdisk.  Function then waits
for a rebuild to start.  Once a rebuild has started, function returns.

=cut

=over 1

=item Usage:

 my $rc = FailPdisk( $ctlr, $pdd, $pDFailMeans );
 
 where: $ctlr        Pointer to controller object array
        $pdd         Pdisk to be failed
        $pDFailMeans The method to use to fail pdisk (optional)
                     - PDISKSPINDOWN     SCSI stop unit cmd (default)
                     - PDISKBYPASS       Bypass both ports on pdisk
                     - PDISKFAIL         fail a pdisk using ccbe command

=item Returns:

       $rc will be GOOD or ERROR 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=item Initial Conditions:

 It would be good to have a hotspare in the system as this will probably cause 
 a rebuild to start. It is also a bad idea to do this on a pdisk that is part
 of a RAID 0 or RAID 1 drive. 

=back

=cut


##############################################################################
#
#          Name: FailPdisk
#
#        Inputs: controller object pointer and other data
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Uses some method to fail a pdisk (probably spin down).
#
##############################################################################
sub FailPdisk
{
    my ( $coPtr, $pdd, $pDFailMeans ) = @_;
    my $cdb;
    my $ctlr;
    my $slave;
    my %pdisks;
    my %rsp;
    my @deviceID;
    my $ret;
    my $mIdx;
    my $sIdx;
    my %info;
    my @coList = @$coPtr;

    #
    # Make sure we are working with at least two controller setup
    # identifies the master and slave
    #
    # sIdx is chosen at random when N>=2
    #
    ($mIdx, $sIdx) = FindMasterPickSlave($coPtr);

    if ( ($mIdx == INVALID) || ($sIdx == INVALID) )
    {
        logInfo(">>>>>>>>> Error: could not find at least two controllers " . 
                "destined Master and Slave.");
        return ERROR;
    }

    $ctlr = $coList[$mIdx];
    $slave = $coList[$sIdx];
    
    # default 3rd parm to spin down, this is the orig method.

    if ( !$pDFailMeans ) { $pDFailMeans = PDISKSPINDOWN; }
    
    
    if ( PDISKBYPASS == $pDFailMeans )
    {

        logInfo("     Failing physical drive $pdd  using FC PORT BYPASS ");

        $ret = PdiskIdBypass( $ctlr, $pdd, undef);  # bypass both ports
        
        if  ( $ret != GOOD )
        {
            # bypass failed
            return $ret;
        }

    }
    elsif ( PDISKPULL == $pDFailMeans )
    {

        logInfo("      Failing physical drive $pdd using MANUAL DRIVE PULL.");

        logInfo("           Physical Disk Beacon (pdisk $pdd): ");
        %info = $ctlr->physicalDiskBeacon($pdd, 1200);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskBeacon <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to physicalDiskBeacon <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }


        print  "\n";
        print  "*****************************************\n";
        print  "*                                       *\n";
        printf("*  Manually remove beaconing drive %3d  *\n",$pdd);
        print  "*                                       *\n";
        print  "*  Wait two minutes, reinstall drive.   *\n";
        print  "*                                       *\n";
        print  "*  Then, press return to continue.      *\n";
        print  "*                                       *\n";
        print  "*****************************************\n";
        print  "\n";
        
        
        my $dummy = <STDIN>;
        print "\n Thanks. \n\n";
        
        # stop the beacon
        %info = $ctlr->physicalDiskBeacon($pdd, 1);
        
        logInfo("Manual drive pull complete.");
        return (GOOD);

    }
    elsif ( PDISKFAIL == $pDFailMeans )
    {
        logInfo("      Failing physical drive $pdd  using PDISK FAIL command");

        %info = $ctlr->physicalDiskFail($pdd, 0, 4);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskFail <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to physicalDiskFail <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
        
        if ( POWER_UP_COMPLETE == GetStatePOQ( $ctlr ) )
        {
            logInfo("now rescanning BE from master controller." );

            $ret = RescanBE($ctlr);
        
            if ( $ret == ERROR )
            {
                return ERROR;
            }
        }
        
        if ( POWER_UP_COMPLETE == GetStatePOQ( $slave ) )
            {
            logInfo("now rescanning BE from slave controller." );

            $ret = RescanBE($slave);
        
            if ( $ret == ERROR )
            {
                return ERROR;
            }
        }

    }
    else
    
    {
        logInfo("      Failing physical drive $pdd  using SPINDOWN");

        #######################
        # Fail the drive
        #######################

        #
        # The failing will be "simulated" by sending a stop unit SCSI command.
        #

        $cdb = AsciiHexToBin("1B0100000000", "byte");

        #
        # Retrieve WWN/LUN from the specified physical disk
        #
        %pdisks = $ctlr->physicalDiskInfo($pdd);
        if (%pdisks)
        {
            if ($pdisks{STATUS} == PI_GOOD)
            {
                $deviceID[0]{WWN_LO} = $pdisks{WWN_LO};
                $deviceID[0]{WWN_HI} = $pdisks{WWN_HI};
                $deviceID[0]{PD_LUN} = $pdisks{PD_LUN};
            }
            else
            {
                logInfo(">>>>>>>> Unable to retrieve pdisk info <<<<<<<<");
                PrintError(%pdisks);
                return ERROR;
            }
        }
        else
        {
            logInfo(">>>>>>>> ERROR: Did not receive a response packet from physicalDiskInfo() <<<<<<<<");                       return ERROR;
        }

        #
        # Send the SCSI cmd.
        #
        %rsp = $ctlr->scsiCmd($cdb, "", @deviceID);  

        if (%rsp)
        {
            #
            # If successful, tell the user
            #
            if ($rsp{STATUS} == PI_GOOD)
            {
                logInfo("Stop unit SCSI command successful");
            }
            #
            # If failure, display sense data
            #
            else
            {
                logInfo(">>>>>>>> SCSI cmd failed <<<<<<<<");
                PrintError(%rsp);

                logInfo(sprintf("Sense Key:      0x%02X\n", $rsp{SENSE_KEY}));
                logInfo(sprintf("Sense Code:     0x%02X\n", $rsp{ADTL_SENSE_CODE}));
                logInfo(sprintf("Sense Code Qual:0x%02X\n", $rsp{ADTL_SENSE_CODE_QUAL}));
                return ERROR;
            }
        }
        else
        {
            logInfo(">>>>>>>> ERROR: Did not receive a response packet <<<<<<<<");
            return ERROR;
        }
    
    }  # end of if ($pDFailMeans...)
    
    
    ######################
    # start the rebuild 
    ######################
    # this should be automatic, allow 150 secs to get rolling

    logInfo("waiting up to 150 seconds for the rebuild to start");
    
    my $dCheck;
    my $checkTimeout;
    
    $checkTimeout = 150;                   # timeout after 2.5 minutes
    $dCheck = DegradeCheckRunning($ctlr);  # get current rebuild state
                                                  
                                                 
    while ( ( $checkTimeout > 0 ) &&          # not timed out and
         ( $dCheck != INVALID) )              # not running
    {
        #
        # wait a second, decrement timeout and do 
        # another check
        #
        sleep 1;                           # wait a second
        $checkTimeout--;
        $dCheck = DegradeCheckRunning($ctlr);
    }
   
    #
    # Check the last return code for error
    #
    if ( $dCheck == ERROR )
    {
        logInfo(">>>>>>>> Failure occurred while checking for rebuild status <<<<<<<<");
        return ERROR;
    }
        
    # we are exiting while the rebuild is going (or we just timed out).

    return GOOD;
}



###############################################################################

=head2 FailPdiskNoWait function

This function simulates a pdisk failure by either sending a SCSI stop unit 
command to a pdisk or bypassing both ports on a pdisk.  Returns immediately
after failing pdisk.

=cut

=over 1

=item Usage:

 my $rc = FailPdiskNoWait( $ctlr, $pdd, $pDFailMeans );
 
 where: $ctlr        Pointer to controller object array
        $pdd         Pdisk to be failed
        $pDFailMeans The method to use to fail pdisk (optional)
                     - PDISKSPINDOWN     SCSI stop unit cmd (default)
                     - PDISKBYPASS       Bypass both ports on pdisk

=item Returns:

       $rc will be GOOD or ERROR 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=item Initial Conditions:

 It would be good to have a hotspare in the system as this will probably cause 
 a rebuild to start. It is also a bad idea to do this on a pdisk that is part
 of a RAID 0 or RAID 1 drive. 

=back

=cut



##############################################################################
#
#          Name: FailPdiskNoWait
#
#        Inputs: controller object pointer and other data
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Uses some method to fail a pdisk (probably spin down).
#
##############################################################################
sub FailPdiskNoWait
{
    my ( $ctlr, $pdd, $pDFailMeans ) = @_;
    my $cdb;
    my %pdisks;
    my %rsp;
    my @deviceID;
    my $ret;
    my %info;

    # default 3rd parm to spin down, this is the orig method.

    if ( !$pDFailMeans ) { $pDFailMeans = PDISKSPINDOWN; }
    
    if ( PDISKBYPASS == $pDFailMeans )
    {

        logInfo("      Failing physical drive $pdd  using FC PORT BYPASS");

        $ret = PdiskIdBypass( $ctlr, $pdd, undef);  # bypass both ports
        
        if  ( $ret != GOOD )
        {
            # bypass failed
            return $ret;
        }

    }
    elsif ( PDISKPULL == $pDFailMeans )
    {

        logInfo("      Failing physical drive $pdd using MANUAL DRIVE PULL.");

        logInfo("           Physical Disk Beacon (pdisk $pdd): ");
        %info = $ctlr->physicalDiskBeacon($pdd, 1200);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskBeacon <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to physicalDiskBeacon <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }


        print  "\n";
        print  "*****************************************\n";
        print  "*                                       *\n";
        printf("*  Manually remove beaconing drive %3d  *\n",$pdd);
        print  "*                                       *\n";
        print  "*  Wait two minutes, reinstall drive.   *\n";
        print  "*                                       *\n";
        print  "*  Then, press return to continue.      *\n";
        print  "*                                       *\n";
        print  "*****************************************\n";
        print  "\n";
        
        
        my $dummy = <STDIN>;
        print "\n Thanks. \n\n";
        
        # stop the beacon
        %info = $ctlr->physicalDiskBeacon($pdd, 1);
        
        logInfo("Manual drive pull complete.");
        return (GOOD);

    }
    else
    {
        logInfo("      Failing physical drive $pdd  using SPINDOWN");

        #######################
        # Fail the drive
        #######################

        #
        # The failing will be "simulated" by sending a stop unit SCSI command.
        #

        $cdb = AsciiHexToBin("1B0100000000", "byte");

        #
        # Retrieve WWN/LUN from the specified physical disk
        #
        %pdisks = $ctlr->physicalDiskInfo($pdd);
        if (%pdisks)
        {
            if ($pdisks{STATUS} == PI_GOOD)
            {
                $deviceID[0]{WWN_LO} = $pdisks{WWN_LO};
                $deviceID[0]{WWN_HI} = $pdisks{WWN_HI};
                $deviceID[0]{PD_LUN} = $pdisks{PD_LUN};
            }
            else
            {
                logInfo(">>>>>>>> Unable to retrieve pdisk info <<<<<<<<");
                PrintError(%pdisks);
                return ERROR;
            }
        }
        else
        {
            logInfo(">>>>>>>> ERROR: Did not receive a response packet from physicalDiskInfo() <<<<<<<<");                       return ERROR;
        }

        #
        # Send the SCSI cmd.
        #
        %rsp = $ctlr->scsiCmd($cdb, "", @deviceID);  

        if (%rsp)
        {
            #
            # If successful, tell the user
            #
            if ($rsp{STATUS} == PI_GOOD)
            {
                logInfo("Stop unit SCSI command successful");
            }
            #
            # If failure, display sense data
            #
            else
            {
                logInfo(">>>>>>>> SCSI cmd failed <<<<<<<<");
                PrintError(%rsp);

                logInfo(sprintf("Sense Key:      0x%02X\n", $rsp{SENSE_KEY}));
                logInfo(sprintf("Sense Code:     0x%02X\n", $rsp{ADTL_SENSE_CODE}));
                logInfo(sprintf("Sense Code Qual:0x%02X\n", $rsp{ADTL_SENSE_CODE_QUAL}));
                return ERROR;
            }
        }
        else
        {
            logInfo(">>>>>>>> ERROR: Did not receive a response packet <<<<<<<<");
            return ERROR;
        }
    
    }  # end of if ($pDFailMeans...)
 
    return GOOD;
}

=head2 StopDefrag function

This function starts defrag on a single pdisk.

=cut

=over 1

=item Usage:

 my $rc = StopDefrag( $ctlr );
 
 where: $ctlr is a controller object

Stops all defrag operations on all PDD's

=item Returns:

       $rc will be GOOD or ERROR 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut

##############################################################################
#
#          Name: StopDefrag
#
#        Inputs: controller object pointer and other data
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: For the controller, stop defrag on the supplied list of 
#                pdisks.
#
##############################################################################
sub StopDefrag
{
    trace();
    my ($ctlr ) = @_;
    my $ret;
 
        
        #################
        # STOP Defrag
        #################
        
        $ret = StartSingleDefrag($ctlr, "STOP");

        if ( $ret != GOOD )
        {
            return ERROR;
        }
      
    
    return GOOD;
}


###############################################################################

=head2 StopOrphanDefrag function

This function starts defrag on a single pdisk.

=cut

=over 1

=item Usage:

 my $rc = StopOrphanDefrag( $ctlr );
 
 where: $ctlr is a controller object

Stops all Orphan defrag operations on all PDD's

=item Returns:

       $rc will be GOOD or ERROR 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut

##############################################################################
#
#          Name: StopOrphanDefrag
#
#        Inputs: controller object pointer and other data
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: For the controller, stops all orphan defrags on all pdisks.
#
##############################################################################
sub StopOrphanDefrag
{
    trace();
    my ($ctlr ) = @_;
    my $ret;
 
        
        #################
        # ORPHAN Defrag
        #################
        
        $ret = StartSingleDefrag($ctlr, "ORPHAN");

        if ( $ret != GOOD )
        {
            return ERROR;
        }
      
    
    return GOOD;
}


###############################################################################





=head2 CreateReplacementVdisk function

This function builds a new vdisks that is an equivalent to the supplied 
vdisk. The final RAID is made slightly larger so that it may be used as
a destination for redi-copy.

=cut

=over 1

=item Usage:

 my $rc = CreateReplacementVdisk( $ctlr, $oldVdisk  );
 
 where: $ctlr is a controller object
        $oldVdisks is the vdisk to clone

=item Returns:

       $rc will be GOOD or ERROR 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut



##############################################################################
#
#          Name: CreateReplacementVdisk
#
#        Inputs: controller object pointer and other data
#
#       Outputs: new vdisk number or INVALID
#
#  Globals Used: none
#
#   Description: Given a supplied controller and existing vdisk number
#                Create a new vdisk that is similar, but slightly larger.
#                These two vdisks will be used as the source and destination 
#                of a rediCP operation. If the disk is multiple raids, then
#                the replacement disk will also be multiple raids, with the 
#                last raid slightly larger. (Hint: all raids in a vdisk are
#                the same as far aas raid type, mirror depth(=2), parity, etc. 
#
##############################################################################
sub CreateReplacementVdisk
{
    my ($ctlr, $oldVdisk ) = @_;
    my $newVdisk;
    my $numRIDs;
    my @RIDarray;
    my $r;
    my $i;
    my @pdd;       
    my $capacity;
    my $ret;    
    my $rtype; 
    my $stripe; 
    my $depth; 
    my $parity; 
    my $remaining; 
    my $initRequired = 0;   
    my $cacheEnabled = FALSE;
    my %rsp;

    logInfo("      Creating the 'replacement' vdisk for vdd $oldVdisk");

    $newVdisk = 0;
    
    # get info for current vdisk
    #    vdiskinfo gives the IDs for the RAIDS

    %rsp = $ctlr->virtualDiskInfo($oldVdisk);

    if ( ! %rsp )
    {
        logInfo(">>>>> Failed to get vdisk status for vdisk $oldVdisk <<<<<");
        return (INVALID);          # 
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Error getting vdisk status for vdisk $oldVdisk <<<<<");
        PrintError(%rsp);
        return (INVALID);          # 
    }

    # get the raid numbers 

    $numRIDs = $rsp{RAIDCNT};    #Number of RIDs

    # put raids into an array
    for ( $r = 0; $r < $numRIDs; $r++)
    {
        push  @RIDarray, $rsp{RIDS}[$r];
    }

    #
    # Check if cache is enabled on this virtual disk and if it is set the
    # cache enabled flag to signal we need to enable cache on the new
    # virtual disk.
    #
    if (($rsp{ATTR} & 0x100) > 0)
    {
        $cacheEnabled = TRUE;
    }

    for ( $i = 0; $i < $numRIDs; $i++ )
    {
        # get this info for each raid

        # get raidinfo
        my %rsp = $ctlr->virtualDiskRaidInfo($RIDarray[$i]);

        if ( ! %rsp )
        {
            logInfo(">>>>> Failed to get raidinfo status <<<<<");
            return (INVALID);          # 
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>> Error getting raidinfo status <<<<<");
            return (INVALID);          # 
        }
    
        # increase the size a bit for the last raid only

        if ( ( 1 + $i ) == $numRIDs )
        {
            # this is the last raid for the drive
            $capacity = 100 + $rsp{ CAPACITY };
        }
        else 
        {
            # all but the last
            $capacity =  $rsp{ CAPACITY };
        }

        # get the rest of the needed data
       
        $rtype  = $rsp{TYPE};
        $stripe = $rsp{SPS};
        $depth  = $rsp{DEPTH};      # should be 2 for baby alpha
        $parity = $rsp{DEPTH};
        
        # now the list of pdisks
        for ( $r = 0; $r < $rsp{PSDCNT}; $r++ )
        {
            $pdd[$r] = $rsp{PIDS}[$r]{PID}
        }     

        if ( $rtype == RAID_5 || $rtype == RAID_10 )
        {
            $initRequired = 1; 
        }   

        # create/expand the new vdisk
#if ( $depth == 0 ) { $depth = 2; }         # fix for cl bug 6202
                      
        if ( $i == 0 )
        {
            

            # the first raid is always a create
            print " creating: $capacity \n";
            print "           @pdd \n";
            print "           $rtype \n";
            print "           $stripe \n";
            print "           $depth \n";
            print "           $parity \n";


            %rsp = $ctlr->virtualDiskCreate(  $capacity,
                                    \@pdd,
                                    $rtype,                                                                     
                                    $stripe,
                                    $depth,
                                    $parity,       # parity
                                    undef,          # vid to use (can be undef)
                                    4,             # maxraids
                                    10,            # threshold
                                    0,             # flags
                                    0              # minPD
                                    );         

            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>> Failed to get response from virtualDiskCreate <<<<<");
                return INVALID;
            }

            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>> Error from virtualDiskCreate <<<<<");
                PrintError(%rsp);
                return INVALID;
            }

            $newVdisk =  $rsp{VID}


        }
        else
        {
            # not first raid, so it is an expand
            print " expanding: $newVdisk \n";
            print "            $capacity \n";
            print "            @pdd \n";
            print "            $rtype \n";
            print "            $stripe \n";
            print "            $depth \n";
            print "            $parity \n";


            %rsp = $ctlr->virtualDiskExpand( $newVdisk,   #  vdd to expand
                                             $capacity,   #  $capacity,
                                             \@pdd,       #  $pdPointer,
                                             $rtype,      #  $rtype,                                                                     
                                             $stripe,     #  $stripe,
                                             $depth,      #  $depth,
                                             $parity,
                                             4,
                                             10,
                                             0,
                                             0);

            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>> Failed to get response from virtualDiskExpand <<<<<");
                return INVALID;
            }

            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>> Error from virtualDiskExpand <<<<<");
                PrintError(%rsp);
                return INVALID;
            }

        }

    # repeat for all raids in the vdisk
    }

    # we need the raids to be initialized for the test, so start the inits now

    # JW asked me not to init raids for his debug. This may break raid 5
    # testing in the future.  (CM: 7/17/03 - it did!)

    if ( $initRequired == 1 )
    {
        # need to init raid 5 drives

        $ret = InitVdiskRids($ctlr, $newVdisk);
        if ( $ret != GOOD )
        {
            # well, we couldn't start the inits, bail out
            return INVALID;
        }    
    
        logInfo("Pause to allow inits to start");

        DelaySecs(5);

        # now wait for the inits to complete (just starting isn't enough)
        if ( 0 != CheckInitProgress($ctlr, $newVdisk ) )
        {
            logInfo("Waiting for vdisk $newVdisk to become operational");
    
            while ( 0 != ( $remaining = CheckInitProgress($ctlr, $newVdisk ) ) )
            {
                print " $remaining percent left to initialize \r";
                # pause for a second or 2
                sleep 2;
            }
        }
    }
    
    #
    # If cache is supposed to be enabled, send the request to enable it.
    #
    if ($cacheEnabled)
    {
        %rsp = $ctlr->virtualDiskSetCache($newVdisk, 0x1);

        if (!%rsp)
        {
            logInfo(">>>>> Failed to get response from virtualDiskSetCache <<<<<");
            return INVALID;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>> Error from virtualDiskSetCache <<<<<");
            PrintError(%rsp);
            return INVALID;
        }
    }

    # return the new vdisk number
    return $newVdisk;
}


###############################################################################

=head2 DispSOSTables function

This function displays the SOS table for each PDD on a controller.

=cut

=over 1

=item Usage:

 my $rc = DispSOSTables( $ctlr );
 
 where: $ctlr is a controller object

=item Returns:

       $rc will be GOOD or ERROR 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut



##############################################################################
#
#          Name: DispSOSTables
#
#        Inputs: controller object
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Displays the sos tables for each PDD
#
##############################################################################
sub DispSOSTables
{
    trace();
    my ( $ctlr ) = @_;

    my %info;
    my @drives;
    my $i;
    my $j;
    my $msg;

    logInfo("      Display current SOS tables ");

    #  get a list of physical disks
    @drives = GetPddList( $ctlr );
    if ( $drives[0] == INVALID )
    {
        return ERROR; 
    }


    # for each PDD
    for ( $i = 0; $i < scalar(@drives); $i++ )
    {


        # get the SOS table
        %info = $ctlr->getSos($drives[$i]);
        if( ! %info )
        {
            logInfo(">>>>>>>> Failed to get SOS information from PDD $drives[$i]. <<<<<<<<");
            return ERROR;
        }

        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from getSOS command <<<<<<<<");
            PrintError(%info);
            # if the error code is three print it anyway
            if ($info{STATUS} != 3) { return ERROR; }     
        }
       
        # display the table(if it exists) 
           
        $msg = "SOS table for PDD $drives[$i]:   \n\n";
        $msg .= sprintf("NEXT:       0x%08X\n",      $info{NEXT});
        $msg .= sprintf("PID:        %d\n",          $info{PID});
        $msg .= sprintf("FLAGS:      0x%04X\n",      $info{FLAGS});
        $msg .= sprintf("REMAIN:     0x%08X\n",      $info{REMAIN});
        $msg .= sprintf("TOTAL:      0x%08X\n",      $info{TOTAL});
        $msg .= sprintf("PDD:        0x%08X\n",      $info{PDD});
        $msg .= sprintf("OWNER:      0x%08X\n",      $info{OWNER});
        $msg .= sprintf("COUNT:      %d\n",          $info{COUNT});
        $msg .= sprintf("CURRENT:    %d\n",          $info{CURRENT});
        $msg .= sprintf("PCB:        0x%08X\n",      $info{PCB});
        
        $msg .= sprintf "\n";
    
        $msg .= sprintf "  GAP_SIZE      SDA         LEN         RID\n";
        $msg .= sprintf " ----------  ----------  ----------  ----------\n";
        for ($j = 0; $j < $info{COUNT}; ++$j)
        {
            $msg .= sprintf " 0x%08X  0x%08X  0x%08X  0x%08X\n", 
                $info{LIST}[$j]{GAP_SIZE},
                $info{LIST}[$j]{SDA},
                $info{LIST}[$j]{LEN},
                $info{LIST}[$j]{RID};
        }

        logInfo($msg);

        # now if the error was 3, return ERROR to stop the test
        if ($info{STATUS} == 3) { return ERROR; }     


    }

    logInfo("");

    return GOOD;
}

###############################################################################

=head2 FindFirstNew function

This function finds the first new vdisks on the controller. A list of older
vdisks (supplied by caller) is compared to the current vdisk list. The first
current vdisk that does not appear in the older list is returned.

=cut

=over 1

=item Usage:

 my $rc = FindFirstNew( $ctlr, $listPtr );
 
 where: $ctlr is a controller object
        $listPtr points to a list of older vdisks

=item Returns:

       $rc will be a vdisk number or INVALID 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=item Initial Conditions:

 Ideally, there are some current vdisks and the input list is not empty. 

=back

=cut


##############################################################################
#
#          Name: FindFirstNew
#
#        Inputs: controller object, vdisklist list
#
#       Outputs: VDD of first new vdisk if successful, INVALID otherwise
#
#  Globals Used: none
#
#   Description: Gets a list of vdisks, returns first one that is not
#                in the supplied list.
#
##############################################################################
sub FindFirstNew
{
    trace();

    my ( $ctlr, $listPtr ) = @_;

    my @oldList;
    my @newList;
    my $numOld;
    my $numVDDs;
    my $i;
    my $j;
    my $match;

    logInfo("      Finding first 'new' vdisk ");

    debug(" in find first new with $ctlr, $listPtr ");
    
    @oldList = @$listPtr;

    $numOld = scalar(@oldList);

    # first get a list of existing vdisks
    @newList = GetVdiskList( $ctlr );
    if ( $newList[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return INVALID;
    }
    $numVDDs = scalar (@newList);  # of drives available

    #
    # compare the lists
    #

    for ( $i = 0; $i < $numVDDs; $i++ )
    {
        # compare each one in the new list
        $match = ERROR;
        for ( $j = 0; $j < $numOld; $j++ )
        {
            # compare to each one in the old list
            if ( $oldList[$j] == $newList[$i] )
            {
                $match = GOOD;   # if they match, indicate it, 
                                 # as we can't use this one
            }
        }
        
        if ( $match == ERROR )
        {
            # the new one wasn't in the old list. we want this one.
            return $newList[$i];
        }        

    }

    # if here, they all matched, or one of the lists was empty
    return INVALID;
}


###############################################################################

=head2 DefragWait function

This function waits for defrag to complete on one or more drives. If a pointer 
to a list of drives is passed to the function, it checks those drives only.  If 
no pointer is passed, or is INVALID, the function gets a list of all drives and 
checks all drives.  

The function checks the status in a loop that repeats until defrag is complete 
on the drive. It then goes on to the next drive. 

=cut

=over 1

=item Usage:

 my $rc = DefragWait( $ctlr, $drivesPtr );
 
 where: $ctlr is a controller object
        $drivesPtr is a ptr to a list of drives (optional)

=item Returns:

       $rc will be a GOOD or INVALID. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 This can get caught in a loop if we are unable to get information from 
 the controller.


=back

=cut


##############################################################################
#
#          Name: DefragWait
#
#        Inputs: controller object
#                pointer to list of drives (optional)
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Wait for defrag to be complete on drives
#                  
#
##############################################################################
sub DefragWait
{
    trace();
    my ( $ctlr, $drivesPtr ) = @_;

    my @drives;
    my $i;
    my $numDrives;
    my $toDo;
    my $drem;
    my $timeOut;
    my %rsp;

    logInfo("      Waiting for defrag to complete on physical disks.    ");

    #
    # Check $drivesPtr.  If not passed or INVALID, then get a list of all pdds.
    # If $drivesPtr exists, use only the drives passed.
    #
    if ( (!defined($drivesPtr)) || ( $drivesPtr == INVALID)  )
    {
        @drives = GetPddList( $ctlr );
        if ( $drives[0] == INVALID )
        {
            logInfo(">>>>>>>> GetPddList failed <<<<<<<<");
            return ERROR; 
        }
    }
    else
    {
        @drives = @$drivesPtr;
    }

    $numDrives = scalar(@drives);

    # We want to go several seconds without finding a drive that is actively 
    # doing defrag to declare the defrags to be complete. THis is done by 
    # requiring 5 loops to complete without finding any drives actively doing
    # defrag. So, we set the initial keepChecking value to 5, decrement 1 each
    # time we complete a pass thru all drives, and set it back to 5 if we ever 
    # find a drive running defrag.

    my $keepChecking = 5;


    while ( $keepChecking > 0 )
    {

        # for each pdd in list
        for ( $i = 0; $i < $numDrives; $i++ )
        {
        
            while ($drem = DefragRemain($ctlr, $drives[$i]) )
            {
                # This will stick in a loop if we can't get good data from drive.
                print "$drem percent remaining to defrag on PDD $drives[$i].        \r";
                sleep(20);

                $keepChecking = 5;  # reset counter
                
                
                # if LAS != TAS we get 101 for %remaining This one may not be
                # actively defragging. Since it may be on a queue, we don't 
                # need to time it out anymore. Rather, skip it and go on to 
                # the next drive

                if( $drem == 101 ) 
                {
                    last; 
                }
            }

        }

        #
        # If the controller status indicates a defrag is running
        # we keep looking. This helps in the case where the last 
        # defrag is on a different controller and would otherwise be 
        # missed. (Also this could be the only thing we check if
        # we didn't want to show some sort of progress indicator.
        #

        %rsp = $ctlr->physicalDiskDefragStatus();

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                if ($rsp{FLAGS} != 0)
                {
                    # defrag is active, keep looking
                    $keepChecking = 5;  # reset counter
                }
            }
            else
            {
                # Unable to retrieve physical disk defrag status.
                logInfo(">>>>>>>> Bad response from physicalDiskDefragStatus command <<<<<<<<");
                logInfo(">>>>>>>> Info only.  Failure ignored.  Test continuing.     <<<<<<<<");
                PrintError(%rsp);
                $keepChecking = 5;  # reset counter
            }
        }
        else
        {
            # Did not receive a response packet.
            logInfo(">>>>>>>> No response from physicalDiskDefragStatus command <<<<<<<<");
            logInfo(">>>>>>>> Info only.  Failure ignored.  Test continuing.    <<<<<<<<");
            $keepChecking = 5;  # reset counter
        }
        
        # finished a pass thru all drives. Decrement count and try again
        # 1 second pause so that we don't run too fast thru 5 counts. (Although
        # that shouldn't be a problem with the above loop.)

        $keepChecking -= 1;
        sleep(1);
    }
    #finish up 
    
    logInfo("Defrag complete on all drives.");

    return GOOD;
}

###############################################################################


###############################################################################

=head2 DefragRemain function

This function gets the amount of space left to be defragged on a pdisk. 

=cut

=over 1

=item Usage:

 my $rc = DefragRemain( $ctlr, $pdd  );
 
 where: $ctlr is a controller object
        $pdd is the pdd to use


=item Returns:

       $rc will be a valid percent remaining or INVALID. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.



=back

=cut



##############################################################################
#
#          Name: DefragRemain
#
#        Inputs: controller object, pdd number
#
#       Outputs: returns percent remaining if OK, INVALID otherwise
#
#  Globals Used: none
#
#   Description: See how much is left to defrag.
#
##############################################################################
sub DefragRemain
{
    trace();
    my ($ctlr, $pdd) = @_;

    my %info;
    my $ret;
    my $r5EnabledFlag;

    # do pdiskinfo
    #print "Retrieving physical disk information for each disk.      \r";
    %info = $ctlr->physicalDiskInfo($pdd);
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDiskInfo <<<<<<<<");
        return INVALID;
    }
    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to physicalDiskInfo on PDD $pdd) <<<<<<<<");
        PrintError(%info);
        return INVALID;
    }

    if ( $info{TAS} < $info{LAS} )
    {
        # there is no way that the largest space can be bigger than the 
        # total space. This is an error. Post it and return something
        # to indicate it.
        logInfo("LAS( $info{LAS} ) is greater than TAS ( $info{TAS} ) on drive $pdd. This is incorrect.");
                    
        DispSOSTables( $ctlr );                    
                    
        return (110);
    }

    # get PCTREM

    if ( $info{PCTREM} == 0 )
    {
        if ( $info{PD_CLASS} == CCBEDATATYPE )
        {
            
            if ( $info{TAS} == $info{LAS} )
            {
                if ( $info{LAS} == 0 )
                {
                    logInfo("---------------------------------------------------------------------------------");
                    logInfo("NOTE: TAS and LAS on drive $pdd are both zero. This is possible, but unexpected.");
                    logInfo("---------------------------------------------------------------------------------");
                }
                
                return 0;
            }
            else
            {
                if (  $ctlr->{CONTROLLER_TYPE} == CTRL_TYPE_BIGFOOT  )
                {
                    $r5EnabledFlag = RAID5_DEFRAG_ENABLED_BIGFOOT;
                }
                else
                {
                    $r5EnabledFlag = RAID5_DEFRAG_ENABLED_WOOKIEE;
                } 
                   
                #
                if ( !$r5EnabledFlag )
                {
                    #
                    # check if this pdisk has any Raid 5 segments 
                    # if it does, then considered the defrag on this pdd done 
                    # 
                    #
                    $ret = PdiskGotRaid($ctlr, $pdd, RAID_5);
                    if ( $ret == INVALID )
                    {
                        logInfo(">>>>>>>> PdiskGotRaid Failed for PDD $pdd) <<<<<<<<");
                        return INVALID;
                    }

                    if ( $ret == TRUE )
                    {
                        return 0;
                    }
                }
                
                #
                # if we got here, something unexpected is wrong
                #
                return 101;
            }
        }
    }
    
    return $info{PCTREM} % 128;
    
    # return it

}


###############################################################################

=head2 DefragBegin function

This function starts defrag on all data disks. 

=cut

=over 1

=item Usage:

 my $rc = DefragBegin( $ctlr  );
 
 where: $ctlr is a controller object

=item Returns:

       $rc will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.



=back

=cut


##############################################################################
#
#          Name: DefragBegin
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Start defrag on all pdds.
#
##############################################################################
sub DefragBegin
{
    trace();
    my ($ctlr ) = @_;
    my @drives;
    my $i;
    my $numDrives;
    my %rsp;
    my $ret;

    #  get a list of physical disks
    @drives = GetDataDisks($ctlr, PD_DT_ALL);
    if ( $drives[0] == INVALID )
    {
        return ERROR; 
    }

    $numDrives = scalar(@drives);

    # for each pdd in list
    for ( $i = 0; $i < $numDrives; $i++ )
    {

        $ret = StartSingleDefrag($ctlr, $drives[$i]);

        if ( $ret != GOOD )
        {
            return ERROR;
        }

    }
    
       
    #finish up 


    return GOOD;

}

###############################################################################
##############################################################################
sub DefragAllBegin
{
    trace();
    my ($ctlr ) = @_;
    my @drives;
    my $i;
    my $numDrives;
    my %rsp;
    my $ret;

    #  get a list of physical disks
    @drives = GetDataDisks($ctlr, PD_DT_ALL);
    if ( $drives[0] == INVALID )
    {
        return ERROR; 
    }
    $numDrives = scalar(@drives);

    # for each pdd in list
    $ret = StartSingleDefrag($ctlr, "ALL");

    if ( $ret != GOOD )
    {
        return ERROR;
    }

    
       
    #finish up 


    return GOOD;

}

###############################################################################
###############################################################################

=head2 DefragAllOneAtATime function

This function defrags all data disks, one at a time. THis is slower than
doing them in parallel.

=cut

=over 1

=item Usage:

 my $rc = DefragAllOneAtATime( $ctlr  );
 
 where: $ctlr is a controller object

=item Returns:

       $rc will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.


=back

=cut



##############################################################################
#
#          Name: DefragAllOneAtATime
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################
sub DefragAllOneAtATime
{
    trace();
    my ($ctlr ) = @_;
    my @drives;
    my $i;
    my $numDrives;
    my $drem;
    my $timeOut;
    my $ret;

    #  get a list of physical disks
    @drives = GetDataDisks($ctlr, PD_DT_ALL);
    if ( $drives[0] == INVALID )
    {
        return ERROR; 
    }

    $numDrives = scalar(@drives);

    # for each pdd in list
    for ( $i = 0; $i < $numDrives; $i++ )
    {

        
        #################
        # Begin a defrag
        #################
        
        $ret = StartSingleDefrag($ctlr, $drives[$i]);

        if ( $ret != GOOD )
        {
            return ERROR;
        }

        DelaySecs(20);      # Make sure the defrag has started
                            # so we won't think it is complete 
                            # before it starts. Note: it may finish
                            # within the 20 seconds but tho' unlikely
                            # that isn't a problem.

        #####################
        # wait for it to end
        #####################

        logInfo("Waiting for defrag to finish on drive $drives[$i].        ");

        # get pdiskinfo
        # look at PCTREM
        # while pctrem != 0
            # display amount to do on drive of drives
            # get pctrem
        
        $timeOut = 60;
        
        while ($drem = DefragRemain($ctlr, $drives[$i]) )
        {
            # This will stick in a loop if we can't get good data from drive.
            print "$drem percent remaining to defrag on PDD $drives[$i].        \r";
            sleep(2);
            
            if( $drem == 101 ) 
            {
                $timeOut = $timeOut - 1; 
            }

            if ( $drem == INVALID )
            {
                logInfo("Error while waiting for defrag to finish on drive $drives[$i] ");
                return ERROR;
            }
            
            if ( $drem == 110 )
            {
                # LAS > TAS error
                return ERROR;
            }
            
            
            if ( $timeOut < 0 )
            {
                logInfo("We appear to have a stuck defrag on drive $drives[$i]. Check for complete fails.");
                return ERROR;
            }


        }

        print "\n";

        # drive is done, go on to next one

        # allow a few seconds for the controller to be able to receive
        # a new defrag command after one completes

        sleep(10);

    }
    
       
    #finish up 


    return GOOD;

}
################################################################################
sub DefragAll
{
    trace();
    my ($ctlr ) = @_;
    my @drives;
    my $i;
    my $numDrives;
    my $drem;
    my $timeOut;
    my $ret;


    # this starts a defrag-all command.

    $ret = DefragAllBegin($ctlr);
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to start defragAll. <<<<<<<<");
        return (ERROR);
    }

    # wait for something to start
    sleep(10);

    # now wait for the defrags to end

    $ret = DefragWait( $ctlr );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed waiting for defrags to end. <<<<<<<<");
        return (ERROR);
    }


    #finish up 


    return GOOD;

}


###############################################################################

=head2 WaitOnNewerInits function

This function waits for the inits on newer vdisks to complete. It gets a list
of all current vdisks and compares it to a supplied list. Any current vdisks 
that are not on the older list are checked to see if init is complete. The
function loops on the check until the vdisk is complete.

=cut

=over 1

=item Usage:

 my $rc = WaitOnNewerInits( $ctlr, $origVdPtr  );
 
 where: $ctlr is a controller object
        $origVdPtr is a pointer to a list of older vdisks

=item Returns:

       $rc will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.


=back

=cut



##############################################################################
#
#          Name: WaitOnNewerInits
#
#        Inputs: controller object, pointer to list of older vdisks
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################
sub WaitOnNewerInits
{
    trace();
    my ($ctlr, $origVdPtr ) = @_;

    my @oldVds;
    my @nowVds;
    my @newVds;
    my $j;
    my $i;
    my $foundIt;
    my $ret;
    my $numVDDs;
    my $remaining;

    logInfo("      Wait for init to complete on newer vdisks ");

    @oldVds = @$origVdPtr;

    # first get a list of current vdisks
    @nowVds = &TestLibs::IntegCCBELib::GetVdiskList( $ctlr );
    if ( $nowVds[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@nowVds);  # of drives currently available

    # now find which are new vdisks

#print ("the old vdisks: @oldVds \n");
#print ("the now vdisks: @nowVds \n");


    for ( $i = 0; $i < $numVDDs; $i++ )
    {
        $foundIt = 0;

        for ( $j = 0; $j < scalar(@oldVds); $j++ )
        {
            if ( $oldVds[$j] == $nowVds[$i] )
            {
                $foundIt = 1;
            }
        }

        if ( $foundIt == 0 )
        {
            push (@newVds, $nowVds[$i]);
        }
    }

#print "the new vdisks..... @newVds \n";


    # wait for init to complete on those new vdisks
    for ( $i = 0; $i < scalar(@newVds); $i++ )
    {

        $remaining = &TestLibs::IntegCCBELib::CheckInitProgress($ctlr, $newVds[$i] ) ;

#print "checking init status on vdisk $newVds[$i], $remaining percent remaining \n";       

        # first, is this disk ready for use. (devstat = 0x10)
        if ( 0 != $remaining ) 
        {
            logInfo("Waiting for vdisk $newVds[$i] to become operational");
        
            while ( 0 != ( $remaining = &TestLibs::IntegCCBELib::CheckInitProgress($ctlr, $newVds[$i] ) ) )
            {
                print " $remaining percent left to initialize on vdisk $newVds[$i]    \r";
#print " $remaining percent left to initialize on vdisk $newVds[$i]   \n";
                # pause for a second or 2
                sleep 2;
            }
        }

print"\n";

    }

    return GOOD;
}

###############################################################################

=head2 InitNewerVdisks function

This function is used to initialize the raids on newly created vdisks. The 
function gets a list of the current vdisks and compares it to the supplied
list of earlier vdisks. Any new ones will get their raids initialized.

=cut

=over 1

=item Usage:

 my $rc = InitNewerVdisks( $ctlr, $origVdPtr  );
 
 where: $ctlr is a controller object
        $origVdPtr is a pointer to a list of older vdisks

=item Returns:

       $rc will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.


=back

=cut



##############################################################################
#
#          Name: InitNewerVdisks
#
#        Inputs: controller object, pointer to older vdisk list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################
sub InitNewerVdisks
{
    trace();
    my ($ctlr, $origVdPtr ) = @_;

    my @oldVds;
    my @nowVds;
    my @newVds;
    my $j;
    my $i;
    my $foundIt;
    my $ret;
    my $numVDDs;

    logInfo("      Start init on newer vdisks ");

    @oldVds = @$origVdPtr;



    # first get a list of current vdisks
    @nowVds = GetVdiskList( $ctlr );
    if ( $nowVds[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@nowVds);  # of drives currently available

    # now find which are new vdisks

    for ( $i = 0; $i < $numVDDs; $i++ )
    {
        $foundIt = 0;

        for ( $j = 0; $j < scalar(@oldVds); $j++ )
        {
            if ( $oldVds[$j] == $nowVds[$i] )
            {
                $foundIt = 1;
            }
        }

        if ( $foundIt == 0 )
        {
            push (@newVds, $nowVds[$i]);
        }
    }


    # init those new vdisks

    if ( scalar(@newVds) > 0 )
    {
        $ret = InitializeSomeVdisks( $ctlr, \@newVds );
        if ( $ret != GOOD )
        {
            return ERROR;
        }
    }
    else
    {
        logInfo("HUH?: There were no new vdisks to initialize.");
    }

    return GOOD;
}

###############################################################################

###############################################################################


##############################################################################
###############################################################################

=head2 StartCopyOp function

This is a smaple entry used for code debug and should not be used.

=cut

=over 1

=item Usage:

 my $rc = StartCopyOp(($ctlr, $src, $dest, $opType));
 
     where:
        $ctlr is a pointer to a controller object
        $src is a source vdisk number
        $dest is the destination vdisk
        $opType is the type of copy operation to perform and is one of these 

            { COPY_BREAK }           
            { COPY_CONTINUOUS }      
            { COPY_SWAP }            

            { ABORT_COPY }           
            { PAUSE_COPY }           
            { RESUME_COPY }          
            { BREAK_SPECIFIED_COPY } 
            { BREAK_ALL_COPIES }     
            { COPY_FLIP }            



=item Returns:

       $rc = GOOD or ERROR.

=item Description:
 
 This just calles virtualdiskcontrol with the correct parameters. Mapping
 of the above opTypes to the correct parameter is done in this function.    

=back

=cut




##############################################################################
#
#          Name: StartCopyOp
#
#        Inputs: $ctlr, $src, $dest, $opTyp
#
#       Outputs:  ERROR or GOOD 
#
#  Globals Used: none
#
#   Description: starts a redi copy op using vdiskcontrol fcn
#
##############################################################################

sub StartCopyOp
{
    my ($ctlr, $src, $dest, $opType) = @_;
    trace();
    my $op;
    my %opTable;
    my $serial;

print("     DEBUG: starting copy operation      source = $src, dest = $dest, opType = $opType \n");

# get and print the serial number
    $serial = GetSerial($ctlr);
print("            using controller $serial \n");






if ( $opType eq COPY_FLIP ) {return GOOD;}






    # map the names used to numbers
    #  operation          Control operation to perform.
    #                       MOVE_VDISK              0x00
    #                       COPY_BREAK              0x01
    #                       COPY_SWAP               0x02
    #                       COPY_CONTINUOUS         0x03
    #                       APPEND_SRC_TO_DEST      0x04
    #                       BREAK_SPECIFIED_COPY    0x05
    #                       PAUSE_COPY              0x06
    #                       RESUME_COPY             0x07
    #                       ABORT_COPY              0x08
    #                       BREAK_ALL_COPIES        0x0E
    #
    #
    
    $opTable{ COPY_BREAK }            = 0x01;
    $opTable{ COPY_CONTINUOUS }       = 0x03;
    $opTable{ COPY_SWAP }             = 0x02;

    $opTable{ ABORT_COPY }            = 0x08;
    $opTable{ PAUSE_COPY }            = 0x06;
    $opTable{ RESUME_COPY }           = 0x07;
    $opTable{ BREAK_SPECIFIED_COPY }  = 0x05;
    $opTable{ BREAK_ALL_COPIES }      = 0x0E;
    $opTable{ COPY_FLIP }             = 0x0E; # need new number from JW
    
    $op = 0xff;        # we can fail if no match to the above.


    $op = $opTable{$opType};

    CtlrLogText($ctlr, "Beginning copy operation from $src to $dest using $opType ($op)");


    my %rsp = $ctlr->virtualDiskControl($op, $src, $dest);

    if (!%rsp)                        # no response
    {
        logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)      # bad response
    {
        logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
        PrintError(%rsp);
        return ERROR;
    }




    return GOOD;
}

##########################################################

##############################################################################

##############################################################################
#
#          Name: DisassocVdisk
#
#        Inputs: controller object , vdisk number
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: disassociates a specific vdisk on a controller    
#
#
##############################################################################
sub DisassocVdisk
{
    my ($ctlr, $id) = @_;

    my %rsp;
    my $lun;
    my $sid;
    my $ret;




    # use vdiskowner to get the sid and lun for the drives to release


    #print" working on $id \n";

    %rsp = $ctlr->virtualDiskOwner($id);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from virtualDiskOwner <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Unable to retrieve virtual Disk Owner. <<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    #print  "  Owners (channel, tid, lun, sid):\n";
    #for ($i = 0; $i < $rsp{NDEVS}; $i++)
    #{
    #    printf "    0x%x  0x%x  0x%x  0x%x\n",
    #            $rsp{OWNERS}[$i]{CHANNEL},
    #            $rsp{OWNERS}[$i]{TID},
    #            $rsp{OWNERS}[$i]{LUN},
    #            $rsp{OWNERS}[$i]{SID};
    #}


    if (   $rsp{NDEVS} == 1)
    {
        $sid = $rsp{OWNERS}[0]{SID};
        $lun = $rsp{OWNERS}[0]{LUN};
    }
    else
    {
        if (   $rsp{NDEVS} > 1)
        {
            logInfo("Incorrect number of owners ($rsp{NDEVS}) for vdisk, something is configured wrongly.");
            return ERROR;
        }
        return GOOD;   # # of owners must be 0 which is OK   
    }

    $ret = DisassocOne( $ctlr, $sid, $lun, $id);
    if ( $ret == ERROR )
    {
        return ERROR;
    }




    return GOOD;

} 



##############################################################################

##############################################################################
#
#          Name: VRinfo
#
#        Inputs: controller object, vdisk number, message string
#
#       Outputs: GOOD or ERROR 
#
#  Globals Used: none
#
#   Description: For the specified vdisk, prints the raids used, current
#                sid, target and lun if mapped, size, etc.
#
##############################################################################
sub  VRinfo
{
    my ($ctlr, $vd, $str) = @_;
    
    my $msg;
    my $ret;
    my %rsp;
    my $i;
    my $j;
    my $totalRaids;
    
    
    logInfo("");

    # first, raids for the vdisk
    
    $msg = " For the ". $str . " VDISK (# $vd), the following RAIDs are used:";
    
    # get the vdisk info
    %rsp = $ctlr ->virtualDiskInfo($vd);

    # extract raids to array
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>> Failed to get response from virtualDiskInfo in VRinfo <<<<<");
        return ERROR;
    }

    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        
        if ( $rsp{ERROR_CODE} != $ctlr ->PI_ERROR_INV_VID )
        {
            # handle errors EXCEPT invalid vdisk (it is considered OK)
            logInfo(">>>>> Error from virtualDiskInfo <<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }
    else
    {
        # good path, display the data
        $totalRaids = $rsp{RAIDCNT} + $rsp{DRAIDCNT};

        #my $str =  "Raid IDs: ";
        for ($j = 0; $j < $totalRaids; $j++)
        {
            $msg .= sprintf " %hu", $rsp{RIDS}[$j];
        }
    }
    
    logInfo($msg);
    

    # now do the owner and target info

    $msg = " For the ". $str . " VDISK, here are the owners\n";

    %rsp = $ctlr->virtualDiskOwner($vd);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from virtualDiskOwner in VRinfo <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Unable to retrieve virtual Disk Owner. <<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    for ($i = 0; $i < $rsp{NDEVS}; $i++)
    {
        $msg .= sprintf( "      channel = 0x%x, TID = 0x%x, LUN = 0x%x, SID = 0x%x\n",
                        $rsp{OWNERS}[$i]{CHANNEL},
                        $rsp{OWNERS}[$i]{TID},
                        $rsp{OWNERS}[$i]{LUN},
                        $rsp{OWNERS}[$i]{SID});
    }

    if ( $rsp{NDEVS} == 0 )
    {
        $msg .= "      <no owners>";
    }

    logInfo($msg);

    logInfo("");

    return GOOD;
} 

##############################################################################
###############################################################################



###############################################################################

=head2 CheckAndWait4RediCp function

This function checks each vdisk to see if the mirror state, schead and 
sctail values are 0. It loops through all vdisks and will repeat until 
all are zero on all vdisks. This allows the program to wait until the
system is really ready to do the test.

=cut

=over 1

=item Usage:

 my $rc = CheckAndWait4RediCp( $ctlr, $timeout  );
 
 where: $ctlr is a controller object
       

=item Returns:

       $rc will be GOOD or ERROR. GOOD indicates all is ready.
           ERROR indicates we had a problem.
       $timeout is a timeout value, if NON-ZERO we will give up
           after that number of seconds.

=item Things to look for:
 
 Any error message posted..

=item Initial Conditions:

 It is assumed that the controller will eventually show all drives 
 as being ready.


=back

=cut


##############################################################################
#
#          Name: CheckAndWait4RediCp
#
#        Inputs: controller object , Vdisk number , timeout
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Makes sure there is a valid connection to the controller.
#                Test a command and if it times out reconnects to the controller.
#                Makes the connection using the existing controller object.   
#
#
##############################################################################
sub CheckAndWait4RediCp
{
    trace();
    my ($ctlr, $vid, $duration ) = @_;
    

    my %info;
    my $i;
    my $flag;
##    my $vid;
    my $time1;
    my $time2;
    my $string;
    my @Array_Virtual;
    
    logInfo("      Check and wait for redi-copy operations to be complete");
    
    # get a list of vdisks

    %info= $ctlr->virtualDiskList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskList <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
    
    $string = $info{LIST};
    @Array_Virtual = @$string;         

    $flag = 1;

    $time1 = time;

    $time2 = $time1;

    while ( ($flag == 1) && (($time1 + $duration) > $time2) )
    {
        # a loop that repeats until all vdisks are ready

        $flag = 0;         # a flag to indicate ready


            
        $time2 = time;

        print (" checking vdisk info on $vid     \r");

        my %rsp = $ctlr->virtualDiskInfo($vid);

        if (!%rsp)                        # no response
        {
            logInfo(">>>>> Failed to receive a response from virtualDiskInfo($vid) <<<<<");
            return ERROR;
        }
        elsif ($rsp{STATUS} != 0)            # 0 is good, anything else is bad
        {
            logInfo(">>>>> ERROR: virtualDiskInfo($vid) returned an error <<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        # now look at the 3 items. if any is not 0, set the flag


        if ( $rsp{SCHEAD} != 0)
        {
            $flag = 1;
        }

        if ( $rsp{SCTAIL} != 0)
        {
            $flag = 1;
        }

        if ( $rsp{MIRROR} != 0)
        {
            $flag = 1;
        }



    }
    
    print ("                                               \n");

    # got here, so the flag is 0 and all drives are done with any rediCP
    # OR, we timed out and flag is still set

    if ( $flag != 0 )
    {
        logInfo("Timeout: Redi-copy still seems to be running after $duration seconds.");
        return ERROR;       # timed out
    }

    logInfo("      No redi-copy operations are running");

    return GOOD;
}


###############################################################################
            
##############################################################################
#
#          Name: RCPControllerActiveVdiskListPart1
#
#        Inputs: controller object 
#
#       Outputs: data from statsvdisk
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub RCPControllerActiveVdiskListPart1
{
    trace();
    my ($coPtr,  $noise) = @_;

    my %rsp;
    my $activity;
    my @activeList;
    my @badList;
    my $numVdisks;
    my $msg;
    my $val1;
    my $val2;
    my @coList;
    my %data;
    my $i;
    my $j;
    my $k;
    my $v;
    my $thisDrive;
    my $ctlr;
    my $matched;

    @coList = @$coPtr;

    if ( ! $noise )
    {
        $noise = "Q";
    }
    
    $data{STATUS} = PI_GOOD;
    $data{ERROR_CODE} = 0;

    for ( $i = 0; $i < scalar(@coList); $i++)
    {
        # get the controller object
        $ctlr = $coList[$i];

        # get the data for the first sample
        %rsp = $ctlr->statsVDisk();     # get the initial reading
    
        if ( ! %rsp  )
        {
            if ( $noise ne "Q" )
            {
                logInfo("No response from statsVDisk");
            }
            $data{STATUS} = PI_ERROR;
            $data{ERROR_CODE} = 0;
        
            return %data;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            if ( $noise ne "Q" )
            {
                logInfo("Error returned from statsVdisk ");
            }
            TestLibs::IntegCCBELib::PrintError(%rsp);
            return %data;
        }
    
        # dig out the data, put in a <vdisk>:<total count> hash

        for ( $j = 0; $j < $rsp{COUNT}; $j++ )
        {
            # get the vdisk number
            $thisDrive = $rsp{VDISKS}[$j]{VID};   


            # look to see if there is a matching record for this drive
            $matched = 0;
            while((my $k, my $v) = each %data)
            {
                if ( $k eq $thisDrive )
                {
                    $matched = 1;
                }
            }

            if ( $matched == 1 )
            {
                # we already have a record for this vdisk, update
                # the contents
                $data{$thisDrive} += $rsp{VDISKS}[$j]{RREQ} +
                                     $rsp{VDISKS}[$j]{WREQ};
            }
            else
            {
                # we had no record, we can now create it
                $data{$thisDrive} = $rsp{VDISKS}[$j]{RREQ} +
                                    $rsp{VDISKS}[$j]{WREQ};
            }

        }

    }

#    $msg =  "Virtual Disk Activity on this system (data):\n";
#    $msg .= "\n";
#    $msg .= " VID        total   \n";
#    $msg .= "-----  -----------  \n";
#    logInfo($msg);
#    while((my $k, my $v) = each %data)
#    {
#        logInfo(sprintf("%4d  %12d",$k, $v));
#    }

    return %data;
}





##############################################################################
#
#          Name: RCPControllerActiveVdiskListPart2
#
#        Inputs: controller object 
#
#       Outputs: list of active vdisks, list may be empty
#                INVALID  as 1st element on error
#
#  Globals Used: none
#
#   Description: This functions does a vdisk info on the controller to
#                determine is a significant amount of writes and reads are
#                seen. Two readings, taken a few seconds apart should show
#                a change in the number of read and write requests.
#
#
##############################################################################
sub RCPControllerActiveVdiskListPart2
{
    trace();
    my ($coPtr, $firstSample, $duration, $threshold, $noise) = @_;

    # $duration is unused
    
    my $i;
    my $j;
    my %rsp;
    my %rsp2;
    my $activity;
    my @activeList;
    my @badList;
    my $numVdisks;
    my $msg;
    my $val1;
    my $val2;
    my %initData;
    my @coList;
    my $s;
    my $e;
    my $ctlr;
    my $thisDrive;
    my $matched;
    my %newData;

    @coList = @$coPtr;

    %initData = %$firstSample;
    
#    $msg =  "Virtual Disk Activity on this system (initData):\n";
#    $msg .= "\n";
#   $msg .= " VID        total   \n";
#    $msg .= "-----  -----------  \n";
#    logInfo($msg);
#    while((my $k, my $v) = each %initData)
#    {
#        logInfo(sprintf("%4d  %12d",$k, $v));
#    }


    if ( ! $noise )
    {
        $noise = "Q";
    }
    
    push (@badList, INVALID);       # set up the error return array
    
    for ( $i = 0; $i < scalar(@coList); $i++)
    {
        # get the controller object
        $ctlr = $coList[$i];


        %rsp2 = $ctlr->statsVDisk();    # get the follow-up reading
    
        if ( ! %rsp2  )
        {
            logInfo(">>>>>>>> Failed to get response from statsVDisk <<<<<<<<");
            return @badList;
        }

        if ($rsp2{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to get statsVDisk <<<<<<<<");
            TestLibs::IntegCCBELib::PrintError(%rsp2);
            return @badList;
        }

    

        # dig out the data, edit the <vdisk>:<total count> hash

        for ( $j = 0; $j < $rsp2{COUNT}; $j++ )
        {
            # get the vdisk number
            $thisDrive = $rsp2{VDISKS}[$j]{VID};   

            # look to see if there is a matching record for this drive
            $matched = 0;
            while((my $k, my $v) = each %newData)
            {
                if ( $k eq $thisDrive )
                {
                    $matched = 1;
                }
            }

            if ( $matched == 1 )
            {
                # we already have a record for this vdisk, update
                # the contents
                $newData{$thisDrive} += $rsp2{VDISKS}[$j]{RREQ} +
                                        $rsp2{VDISKS}[$j]{WREQ};
            }
            else
            {
                # we had no record, we can now create it
                $newData{$thisDrive} =  $rsp2{VDISKS}[$j]{RREQ} +
                                         $rsp2{VDISKS}[$j]{WREQ};
            }

        }

    }

    # the %data hash now contains the activity count for all drives
    # printi it, but there hopefully are not any negative numbers



    # first display the data
    
    if ( $noise ne "Q" ) 
    { 
        logInfo("");
    }

    $msg =  "Virtual Disk Activity on this system:\n";
    $msg .= "\n";
    $msg .= " VID        total   \n";
    $msg .= "-----  -----------  \n";
    if ( $noise ne "Q" ) 
    { 
        logInfo($msg);
    }

    $s = "STATUS";
    $e = "ERROR_CODE";

    while((my $k, my $v) = each %newData)
    {

        if ( ($k ne $s) && ($k ne $e) )        # skip info records
        {
            $matched = 0;

            while((my $k2, my $v2) = each %initData)
            {
                if ( $k2 eq $k )
                {
                    $matched = 1;
                }
            }

            if ( $matched == 1 )                   # we have now and initial data
            {

                $newData{$k} -= $initData{$k};     # compute actual transfers
            
                $msg = sprintf("%4d  %12d",$k, $newData{$k});

                if ( $newData{$k} > $threshold )   # a threshold for minimum activity
                {
                    # there is enough activity, add it to the list
                   
                    push (@activeList, $k);
                }


                if ( $noise ne "Q" ) 
                { 
                    logInfo($msg);
                }

            }
            else
            {
                # gads, something is wrong as there is a new vdisk
                logInfo("Warning: $k is a new vdisk. This is unexpected!");
            }
        }
    }






    
    # got to sort this list  ??

    return @activeList;
}

    
    




##############################################################################
sub LIPDrive
{
    my ($ctlr, $drive) = @_;

    my %rsp;
    
    #############################################################
    #  send a LIP reset MRP
    #############################################################

    %rsp = $ctlr->genericMRP($ctlr->MRBELOOPPRIMITIVE,
                             8, 
                             AsciiHexToBin(DecToAsciiHexData($drive, "short") .
                             DecToAsciiHexData(MLPSIDPIDRES, "short") . "0000000000000000") );   
                                           
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get a response from Loop Primitive (LIP Reset) MRP. <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to send a LIP Reset to drive $drive. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    return GOOD;
}

##############################################################################
sub UnfailPdisk
{
    my ($coPtr, $drive, $ses, $slot, $flags, $lid, $port) = @_;
    
    my %rsp;
    my $ret;
    my %pdiski;
    my $useLidFlag = TRUE;

    my $method = 0;
    my $mIdx;
    my $sIdx;
    my $ctlr;
    my $slave;
    my @coList = @$coPtr;

    #
    # Make sure we are working with at least two controller setup
    # identifies the master and slave
    #
    # sIdx is chosen at random when N>=2
    #

    ($mIdx, $sIdx) = FindMasterPickSlave($coPtr);

    if ( ($mIdx == INVALID) || ($sIdx == INVALID) )
    {
        logInfo(">>>>>>>>> Error: could not find at least two controllers " . 
                "destined Master and Slave.");
        return ERROR;
    }

    $ctlr = $coList[$mIdx];
    $slave = $coList[$sIdx];

    if ( (!defined( $lid) ) || (!defined( $port)) )
    {
        logInfo("Port and LID are not specified.");
        $useLidFlag = FALSE;
    }
    
    #
    # make sure flags is defined
    #

    if ( !defined($flags) )
    {
        $flags = 0;
    }
    
    # There are three possibilities here. 1) The drive was spun down and
    # then hotspared out. 2) The drive was spun down and automatically
    # spun up and rebuilt. 3) The drive was bypassed. 
    
    # If the drive is still spun down, then it has a fail flag and needs
    # to be restored and turned into a hotspare

    # if the drive was spun up and rebuilt, then nothing needs to be done.

    # If the drive was bypassed, then unbypass it and ???. A bypassed drive 
    # has the bit for 0x40 for MISCSTAT set. SES and SLOT are also messed up.
    # Once the rebuild starts, it also gets removed as a PDD (pdiskinfo fails
    # and devstat PD doesn't show it.)

    # do a rescan to update all BE data
    
    $ret = RescanBE( $ctlr);
    if ( $ret == ERROR )
    {
        return ERROR;
    }

    # Add a delay to allow the BE to do some quorum clean-up

    DelaySecs(20);

    
    
    
    # now get pdiskinfo

    %pdiski = $ctlr->physicalDiskInfo($drive);

    if (%pdiski)
    {
        if ($pdiski{STATUS} == PI_GOOD)
        {
            # if OK status, then we need do nothing
            #    PID  DevStat  MiscStat  PostStat
            #    ---  -------  --------  --------
            #      0    0x10     0x00      0x10
            #
            # Ignore bits 0 and 1 of MiscStat.  If disk is rebuilding
            # or needs to rebuild, that is ok.
            #
            if ( ( $pdiski{PD_MISCSTAT} & 0xFC ) == 0x00  &&
                   $pdiski{PD_DEVSTAT} == 0x10   &&
                   $pdiski{PD_POSTSTAT} == 0x10  )
            {
                # nothing to do
                
                logInfo("Drive is already operational.");
                return GOOD;
            }

            # bypassed may  get
            #    SES:                   65535
            #    SLOT:                  255
            #    PD_MISCSTAT:           0x40    (look for the bit)
            elsif ( $pdiski{PD_MISCSTAT} & 0x40 &&
                    $pdiski{SES} == 65535 &&
                    $pdiski{SLOT} == 255 )
            {
                # unbypass required
                logInfo("Drive is missing.  Must have been bypassed.");
                $method = 2;
            }
            elsif ( ( $pdiski{PD_MISCSTAT} == 0x20  &&
                   $pdiski{PD_DEVSTAT} == 0x01   &&
                   $pdiski{PD_POSTSTAT} == 0x2C  ) )
            {
                # need to restore
                logInfo(" Need to restore drive.");
                logInfo("PD_DEVSTAT:  $pdiski{PD_DEVSTAT}     PD_MISCSTAT:  $pdiski{PD_MISCSTAT}     ".
                        "PD_POSTSTAT:  $pdiski{PD_POSTSTAT}");            
                $method = 1;
		    }
            # if bad status, then we have work to do
            else 
            {
                #print "Pdisk status - M: $pdiski{PD_MISCSTAT}, ".
                #      "D: $pdiski{PD_DEVSTAT}, ".
                #      "P: $pdiski{PD_POSTSTAT}, ".
                #      "C: $pdiski{PD_CLASS} \n";

                # need to restore
                logInfo("Other status.  Need to restore drive.");
                logInfo("PD_DEVSTAT:  $pdiski{PD_DEVSTAT}     PD_MISCSTAT:  $pdiski{PD_MISCSTAT}     ".
                        "PD_POSTSTAT:  $pdiski{PD_POSTSTAT}");            
                $method = 1;
            }

            # if something else, we are toast
            #logInfo("Unable to determine how the disk can be unfailed.")
            #return ERROR;    


        }
        else
        {
            # if bypassed may get
            #    Status Code:    0x01   "Error occurred"         PI_ERROR
            #    Error Code:     0x32   "Invalid PID number"     PI_ERROR_INV_PID
            if ( $pdiski{STATUS} == PI_ERROR &&
                 $pdiski{ERROR_CODE} == 0x32 )
            {
                # unbypass required
                logInfo("Invalid PID Number error.  Must have been bypassed.");
                $method = 2;

            }
            

            # otherwise we are toast
            else
            {
                logInfo("Unable to determine how the disk can be unfailed.");
                return ERROR;    
            }

        }
    }
    else
    {
        logInfo(">>>>>>>> ERROR: Did not receive a response packet from physicalDiskInfo() <<<<<<<<");
        return ERROR;
    }

    # print "unfail method: $method, flags = $flags \n";

    if ( $method == 1)
    {
        ########################
        # 'restore' the drive
        ########################
    
        logInfo("restoring physical drive $drive");
        %rsp = $ctlr->physicalDiskRestore($drive);
        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskRestore <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to restore drive $drive. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        if ( POWER_UP_COMPLETE == GetStatePOQ( $ctlr ) )
        {
            logInfo("now rescanning BE from master controller." );
            $ret = RescanBE( $ctlr);
            if ( $ret == ERROR )
            {
                return ERROR;
            }
        }
        
        if ( POWER_UP_COMPLETE == GetStatePOQ( $slave ) )
        {
            logInfo("now rescanning BE from slave controller." );
            $ret = RescanBE( $slave);
            if ( $ret == ERROR )
            {
                return ERROR;
            }
        }
    }

    if ( $method == 2)
    {
        ######################
        # unbypass the drive
        ######################
        
        
        
#       Found you a workaround to the bypass issue, I think.  
#       Worked the one time I tried it.
#
# Do a loop primitive option 1, which does a LIP 
# Reset to that device on a loop.  I had bypassed the device on port 0, 
# then did a "loopprim be 1 <pid> <0=path> <lid>" and the device reappeared in 
# the nameserver and the controller was also notified of this change.
#
# I haven't tried this for the case of bypassing both ports of a device - you 
# might have to hit it with a LIP Reset on both paths in that case.
#
# If there was a loop primitive case that allowed a simple LIP on the remote 
# switch port, that might work also, but that's something I would need to 
# add - it would probably be useful long-term.  You'd definitely have to 
# issue that for both ports, though. 
#

        if  ( !defined($slot) || !defined($ses) )
        {
            logInfo("Error, bypassed drive, but no ses/slot information.");
            return ERROR;
        } 

        logInfo("Unbypassing drive at slot $slot, ses $ses.");

        %rsp = $ctlr->physicalDiskBypass($ses, $slot, 0);    # 0 is unbypass
       
        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskBypass <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to restore drive $drive. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
        
        # now this takes a few seconds, so let's wait for ses

        DelaySecs(15);
        
        if ( $useLidFlag == TRUE )
        {
            logInfo("LIP reset on the drive.");
            # we have a loop id to use, send a LIP to the device 
            $ret = LipResetDevice( $ctlr, $drive, $port, $lid);
        }
        
        DelaySecs(10);

        Wait4Ses(  $ctlr, 15 );

        $drive = FindPdId( $ctlr, $ses, $slot );
        
        if($drive == INVALID)
        {
            logInfo(">>>>>>>> Unable to determine Pid for drive SES = $ses, Slot = $slot. <<<<<<<<");  
            return ERROR;
        }



    }



    # delay after the un hot spare finishes.
    DelaySecs(15);



    #
    # if there is a flag that tells us not to relabel the drive we are done
    # (Some tests require the label to be unchanged.)
    #

    if ( $flags & NORELABEL )
    {
        return GOOD;
    }



    ##################################
    # Label the drive as a hotspare
    ##################################

    #
    # We can't relabel a drive that is actively being used, so we need 
    # to check to see if relabeling will be OK.
    #
    
    $ret = IsPdiskUsed($ctlr, $drive);
    
    if ( $ret == INVALID )
    {
        # got an error checking the pdisk
        return ERROR;
    }
    
    if ( $ret == 1 )
    {
        # the pdisk is in use, can't relabel
        # (assume this is a good situation)
        return GOOD;
    }

    # pdisk is not in use, we can make it a hotspare.
    
    $ret = LabelSingleDrive( $ctlr, $drive, CCBEUNLABLEDTYPE);
    if ( $ret == ERROR )
    {
        return ERROR;
    }
    $ret = LabelSingleDrive( $ctlr, $drive, CCBEHOTSPARETYPE);
    if ( $ret == ERROR )
    {
        return ERROR;
    }
    
    # we need to wait for any rebuild that occurs after unfailing the drive
    # The controller will unhotspare the drive so a rebuild will start. 
    # Check the rebuild on the specific drive. $drive is either the drive 
    # number passed in ( spin down case) or the drive where the unbypassed
    # drive showed up.

    #
    # require 5 samples of the rebuild being done to fall out of the next loop.
    # This is so we don't miss the rebuild and go on to the next activity 
    # while a rebuild is happening.
    #

    my $again = 30;

    logInfo("Wait for the unfailed pdisk ($drive)to be unhotspared and rebuilt.");

    while ( $again > 0 )
    {

        %rsp = $ctlr->physicalDiskInfo($drive);

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskInfo <<<<<<<<");
            return ERROR;
        }
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to physicalDiskInfo <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        if (  $rsp{PD_DEVSTAT} == 0x10  )
        {
            #
            # Check to see if the drive is degraded
            #
            if ( ( $rsp{PD_MISCSTAT} & 0x03 ) != 0 )
            {
                logInfo ("PDD # $drive is still rebuilding".
                      " (MISCSTAT = $rsp{PD_MISCSTAT})".
                      " (CLASS = $rsp{PD_CLASS}) ");
                $again = 5;
                sleep(15);
            }
            else
            {
 
                logInfo(" Pdisk $drive is not rebuilding.". 
                    " (MISCSTAT = $rsp{PD_MISCSTAT} ".
                    " CLASS = $rsp{PD_CLASS}) (to go = $again)");
                $again = $again - 1;
                sleep(5);
            }

        }

    }

    logInfo("The unfailed pdisk ($drive) is ready for use.");



    return GOOD;



}

##############################################################################
#
#          Name: LipResetDevice
#
#        Inputs: controller object, pdisk number , BE port, loop id
#
#       Outputs:GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Does a LIP reset to the pdisk specified in the 
#                call. Does both ports that the pdisk may appear on.    
#
#
##############################################################################
sub LipResetDevice
{
    my ( $ctlr, $pid, $port, $lid)= @_;
    
    my %info;
    
    %info = $ctlr->loopPrimitiveBE(1, $pid, $port, $lid);
    
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from loopPrimitiveBE <<<<<<<<");
        return ERROR;
    }

    #
    # if the sos data is good, scan the raids
    #

    if ($info{STATUS} != PI_GOOD)
    {

        #
        # sos data gave an error, return with a bad indication
        #
        
        logInfo(">>>>>>>> Error returned from loopPrimitiveBE on pdd $pid, port $port, lid, $lid <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
    
    return GOOD;
    
    
        
}    

##############################################################################
#
#          Name: IsPdiskUsed
#
#        Inputs: controller object, pdisk number
#
#       Outputs: 1 if being used, 0 if not being used
#
#  Globals Used: none
#
#   Description: Checks the sos table for raids    
#
#
##############################################################################

sub IsPdiskUsed
{
    my ($ctlr, $pdd) = @_;

    my $capacity;
    my $available;
    my $used;


    #
    # get the SOS table
    #
    
    my %info = $ctlr->getSos($pdd);


    #
    # if no sos data, return indicating bad data (INVALID)
    #

    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from getSos <<<<<<<<");
        return INVALID;
    }

    #
    # if the sos data is good, scan the raids
    #

    if ($info{STATUS} == PI_GOOD)
    {

        for (my $j = 0; $j < $info{COUNT}; ++$j)
        {

            if ( $info{LIST}[$j]{RID} != 0xffff )
            {
                #
                # we have a raid other than the reserved ares, this 
                # disk is used. Return with used/TRUE/1
                #

                return(1);
            }

        }

        #
        # We got here with pdiskinfo saying wwere are unused, sos
        # table says the same thing, So, we can return as
        # UNUSED/false/0.
        #

        return(0);
    }
    else
    {
        #
        # sos data gave an error, return with a bad indication
        #
        
        logInfo(">>>>>>>> Error returned from getSos on pdd $pdd <<<<<<<<");
        PrintError(%info);

        return(INVALID);
    }
            


    #
    # If we got here, we didn't figure out if the drive was used or not
    # due to some error. Exit appropriately.
    #


    logInfo(">>>>>>>> Unable to get pdisk info for the drive <<<<<<<<");
    

    return INVALID;


}

##############################################################################
#
#          Name: RequiresDataType
#
#        Inputs: controller object, pdisk number
#
#       Outputs: 1 if needs to be DATA, 0 for UNSAFE only, INVALID on error
#
#  Globals Used: none
#
#   Description: Checks SOStable and raidinfo    
#
#
##############################################################################

sub RequiresDataType
{
    my ($ctlr, $pdd) = @_;

    my $needsData = 0;

    my %sos = $ctlr->getSos($pdd);

    if (%sos)
    {
        if ($sos{STATUS} == PI_GOOD)
        {

            #
            # walk the sos table getting the raid number and type
            # for each valid raid.
            #

            for (my $j = 0; $j < $sos{COUNT}; ++$j)
            {

                if ( $sos{LIST}[$j]{RID} != 0xffff )
                {


                    #
                    # This is a valid raid, now do a raidInfo to see
                    # what type it is.
                    #

                    my %raidInf =  $ctlr->virtualDiskRaidInfo($sos{LIST}[$j]{RID});

                    if ( %raidInf )
                    {
                        if ($raidInf{STATUS} == PI_GOOD)
                        {
                                      
                            # RAID constants are RAID_NONE RAID_0 RAID_1 RAID_5 RAID_10
                        
                            
                            if (
                                 $raidInf{TYPE} == 5
                               )
                            {
                                #
                                # This is a sanity check, type = 5 is a 
                                # VLINK and should never appear on the SOS 
                                # table.
                                #

                                return INVALID;
                            }
                        
                            if (
                                 $raidInf{TYPE} ==  RAID_10 || 
                                 $raidInf{TYPE} ==  RAID_5 || 
                                 $raidInf{TYPE} ==  RAID_1 
                               )
                            {
                                #
                                # need DATA, since all we need is on of these 
                                # declare the drive mu be data, we can quit
                                # checking the rest of the raids.
                                #

                                return 1;
                            }

                        }
                        else
                        {
                            logInfo("Error getting Raid Information on raid $sos{LIST}[$j]{RID} ");
                            PrintError(%raidInf);
                            return INVALID;
                        }
                    }
                    else
                    {
                        logInfo("Failed to get Raid Information on raid $sos{LIST}[$j]{RID} ");
                        return INVALID;




                    }
    
                }
                else
                {
                    logInfo("Skipping raid $sos{LIST}[$j]{RID} ");
                    # return INVALID;

                }

            }

            #
            # Checked all raids, didn't find the need for a 
            # DATA drive, return indicating UNSAFE is OK
            #

            return 0;
        
        }
    }
    # we got here, so there must have been a problem

    return INVALID;

}


##############################################################################
#
#          Name: FixPdiskLabels
#
#        Inputs: master controller object, flags
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Checks each pdisk to see if the label reasonably matches its
#                current use. Will relabel to match use.     
#
#
##############################################################################
sub FixPdiskLabels
{
    trace();
    my ($ctlr, $flags) = @_;

    my @pdisks;
    my $i;
    my $pdisk;
    my $currLabel;
    my $ret;
    my $used;

    
    DelaySecs(5);
    
    #
    # get a list of the drives
    #

    @pdisks = GetPddList ($ctlr);

    if ( scalar(@pdisks) > 0 )
    {
        if ( $pdisks[0] == INVALID )
        {
            # we couldn't get a list of pdisks this is bad
            return ERROR;
        }
    }

    #
    # walk thru the list of drives
    #
    
    for  ( $i = 0; $i < scalar(@pdisks); $i++ )
    {

        $pdisk = $pdisks[$i];

        #
        # get the drive's label
        #

        # Get the disk's information (type)
        my %diskhash = $ctlr->physicalDiskInfo($pdisk);
    
        if ( ! %diskhash )            # No response from the controller
        {
            logInfo(">>>>>>>> Failed to get pdisk info (no response) <<<<<<<<");
            return ERROR;
        }
        else                          # Got a response from the controller
        {
            if ( $diskhash{STATUS} != PI_GOOD )
            {
                # Got an error, report it and bail
                logInfo(">>>>>>>> Failed getting pdisk info <<<<<<<<");
                PrintError(%diskhash);
                return ERROR;
            }
        }

        $currLabel = $diskhash{PD_CLASS};


        #
        # see if the drive is used for data
        #

        $used = IsPdiskUsed($ctlr, $pdisk);

        if ( $used == INVALID )
        {
            return ERROR;
        }

#print "drive $pdisk has label $currLabel and used = $used \n";


        #
        # if necessary, change the drive label
        #

        #
        #  if the drive is unused, and the label is DATA or UNSAFE
        #  and the DONTMAKEHOTSPARE bit/flag is clear, make the 
        #  drive a hotspare
        #
        
        if ( $used == 0  &&
             ( $currLabel == CCBEDATATYPE     ||  
               $currLabel == CCBEUNSAFETYPE ) &&
             ( $flags & DONTMAKEHOTSPARE ) == 0
           )
        {
            # need to make hotspare

            logInfo ("Relabel drive $pdisk as HOTSPARE");

            $ret = LabelSingleDrive( $ctlr, $pdisk, CCBEUNLABLEDTYPE);
            if ( $ret == ERROR )
            {
                return ERROR;
            }
            $ret = LabelSingleDrive( $ctlr, $pdisk, CCBEHOTSPARETYPE);
            if ( $ret == ERROR )
            {
                return ERROR;
            }
 
        }

        #
        # if the drive is used, and the label is HOTSPARE turn the drive
        # into the appropriate type (DATA or UNSAFE)
        #

        if ( $used == 1  &&
             $currLabel == CCBEHOTSPARETYPE 
           )
        {
            # need to make DATA or UNSAFE. First figure out which

            if ( RequiresDataType( $ctlr, $pdisk ) )
            {
                # label as DATA
                
                logInfo ("Relabel drive $pdisk as DATA");

                $ret = LabelSingleDrive( $ctlr, $pdisk, CCBEDATATYPE);
                if ( $ret == ERROR )
                {
                    return ERROR;
                }
            }
            else
            {
                # label as UNSAFE

                logInfo ("Relabel drive $pdisk as UNSAFE");

                $ret = LabelSingleDrive( $ctlr, $pdisk, CCBEUNSAFETYPE);
                if ( $ret == ERROR )
                {
                    return ERROR;
                }
            }
        }

        #
        # if the drive is used and the label is DATA or UNSAFE, 
        # don't change it
        #

        if ( $used == 1  &&
             ( $currLabel == CCBEDATATYPE     ||  
               $currLabel == CCBEUNSAFETYPE ) 
           )
        {
            # label is OK

            next;
        }

        #
        # if the drive is UNLABELED, don't change it, return ERROR 
        # if USED
        #
        if ( $currLabel == CCBEUNLABLEDTYPE )
        {
            if ( $used == 0 )
            {
                # label is OK
                next;
            }
            else
            {
                # we have aused, unlabeled drive. This is bad.
                return ERROR;
            }
        }

        # 
        # if the drive is HOSPARE and unused, leave it.
        #

        if ( $used == 0  &&
             $currLabel == CCBEHOTSPARETYPE 
           )
        {
            # label is OK

            next;
        }

    }

    #
    # return with appropriate value
    #


    return GOOD;    


}
##############################################################################
#
#          Name: CreateMultiRaidVdisk
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Create Vdisks, expands uses 4 raids     
#
#
##############################################################################
sub CreateMultiRaidVdisk
{
    trace();
    my ($ctlr, $size, $rtype) = @_;
    my $ret;
    my $i;
    my @pddList;
    my %info;
    my %rtn;
    my $stripe = 0;
    my $depth = 0;
    my $parity = 0;
    my $numPDs = 0;

    #
    # create an array of the PDDs so we know what are working with
    #

    ######################
    # pdisk list                      # need to use only the data disks
    ######################
 
    @pddList = GetDataDisks($ctlr, FC_PREFERRED);

    if ( $pddList[0] == INVALID )
    {
        logInfo(">>>>>>>> Not enough drives for C/E/I/D test  <<<<<<<<");
        return (ERROR);
    }
        


    
    
    # Name:     calcRaidParms
    # Desc:     Based on the raid type passed in and how many disk we have
    #           returns the correct parameters to be used in the create vdisk
    #           packet
     

    ####################
    # calc Raid Parms
    ####################

    my $requestedBytes =  Math::BigInt->new((($size/4) * 1024 * 1024 ) / 512 );

    my $rtn = ValidateVdiskParams( \$depth, \$rtype, \$stripe, \$parity, \@pddList );

    my $str = "";


    # all parameters are ready for the call to create the vdisk
    $str .= "CAPACITY: $requestedBytes blocks  ";
    $str .= "RAID: $rtype  ";
    $str .= "STRIPE SIZE: $stripe  ";
    $str .= "MIRROR DEPTH: $depth  ";
    $str .= "PARITY: $parity  "; 
    $numPDs = scalar(@pddList);
    $str .= "NUMBER of PDs: $numPDs  ";   # second line
    $str .= "PD IDs:  @pddList \n";

    logInfo($str);


    if ( $rtn == INVALID )
    {
        logInfo("Parameters for creating the vdisk are invalid.");
        return INVALID;
    }


 
      
    ###############
    # VDISK create
    ###############

    %rtn = $ctlr->virtualDiskCreate(   $requestedBytes,
                                        \@pddList,
                                        $rtype,                                                                     
                                        $stripe,
                                        $depth,
                                        $parity,
                                        undef,          # vid to use (can be undef)
                                        4,             # maxraids
                                        10,            # threshold
                                        0,             # flags
                                        0              # minPD
                                        );         


    if ( ! %rtn  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskCreate <<<<<<<<");
        return ERROR;
    }
    if ( $rtn{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskCreate <<<<<<<<");
        PrintError(%rtn);
        return ERROR;
    }


    ###############
    # VDISK expand #1
    ###############
    %info = $ctlr->virtualDiskExpand($rtn{VID}, 
                                    $requestedBytes, 
                                    \@pddList, 
                                    $rtype,
                                    $stripe,
                                    $depth,
                                    $parity,
                                    4,             # maxraids
                                    10,            # threshold
                                    0,             # flags
                                    0              # minPD
                                    );         


    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
    ###############
    # VDISK expand #2
    ###############
    %info = $ctlr->virtualDiskExpand($rtn{VID}, 
                                    $requestedBytes, 
                                    \@pddList, 
                                    $rtype,
                                    $stripe,
                                    $depth,
                                    $parity,
                                    4,             # maxraids
                                    10,            # threshold
                                    0,             # flags
                                    0              # minPD
                                    );         

    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
    ###############
    # VDISK expand  #3
    ###############
    %info = $ctlr->virtualDiskExpand($rtn{VID}, 
                                    $requestedBytes, 
                                    \@pddList, 
                                    $rtype,
                                    $stripe,
                                    $depth,
                                    $parity,
                                    4,             # maxraids
                                    10,            # threshold
                                    0,             # flags
                                    0              # minPD
                                    );         

    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }



    return GOOD;


}

##############################################################################
#
#          Name: PdiskIdBypass
#
#        Inputs: $obj  - master controller objects
#                $ses  - pdisk bay SES 
#                $slot - pdisk slot with in the bay
#                $setting - command setting
#                   0x0 = Unbypass
#                   0x4 = Bypass - B
#                   0x8 = Bypass - A
#                   0xC = Bypass - A and B
#
#
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Bypasses, unbypasses physical disk   
#
#
##############################################################################

sub PdiskIdBypass
{
    my($obj, $pdiskid, $port ) = @_;

    my $setting; # setting for bypass

    my %PdiskInfo; # pdiskinfo hash
    
    my $ses;        # pdisk bay ses 
    my $slot;       # pdisk slot 
    my $return;     # return from the function
    
    ##################################################################
    # Figure out the setting for bypass, in other words find bypass mode
    # Bypass avaluable modes:
    #       
    #       0x4 = Bypass - B
    #       0x8 = Bypass - A
    #       0xC = Bypass - A and B

    if( $port )
    {
        if( lc($port) eq "b" )    # bypass on port B
        {
            $setting = 0x4; 
        }
        elsif( lc($port) eq "a" )     # bypas on port A
        {
            $setting = 0x8; 
        }
        else
        {
            logInfo("Invalid option $port");
            return ERROR;
        } 
    }
    else
    {
        $port = "A, B";
        $setting = 0xC;          # bypass physical drive on both ports 
    }
    
    ###################################################################
    # Get physical disk info and extract bay SES pdisk slot 
    #
    #

    # status is good, extract the data
    
    %PdiskInfo = $obj->XIOTech::cmdMgr::physicalDiskInfo($pdiskid);
    
    if (%PdiskInfo)
    {
        if ($PdiskInfo{STATUS} == PI_GOOD)
        {
            $ses = $PdiskInfo{SES};
            $slot = $PdiskInfo{SLOT};  
        }
        else
        {
            my $msg = "Unable to retrieve pdisk id $pdiskid info.";
            TestLibs::scrub::displayError($msg, %PdiskInfo);
            return ERROR;
        }
    }
    else
    {
        logInfo("ERROR: Did not receive a response packet for pdisk $pdiskid");
        return ERROR;
    }

    $return = PdiskBypass($obj, $ses, $slot, $setting);
    
    if($return != GOOD)
    {
        logInfo("ERROR: unable to bypass drive id    - $pdiskid, ");
        logInfo("                        bay SES     - $ses, ");
        logInfo("                        slot        - $slot, ");
        logInfo("                        on port(s)  - $port");
        return ERROR;
    }

    return GOOD;

}

##############################################################################
#
#          Name: PdiskIdUnbypass
#
#        Inputs: $obj  - master controller objects
#                $ses  - pdisk bay SES 
#                $slot - pdisk slot with in the bay
#                $setting - command setting
#                   0x0 = Unbypass
#                   0x4 = Bypass - B
#                   0x8 = Bypass - A
#                   0xC = Bypass - A and B
#
#
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Bypasses, unbypasses physical disk   
#
#
##############################################################################

sub PdiskIdUnbypass
{
    my($obj, $pdiskid) = @_;

    my $ses;
    my $slot;
    my %PdiskInfo;
    my $return;
    my $setting = 0x0;


    ###################################################################
    # Get physical disk info and extract bay SES pdisk slot 
    #
    #

    # status is good, extract the data
    
    %PdiskInfo = $obj->XIOTech::cmdMgr::physicalDiskInfo($pdiskid);
    
    if (%PdiskInfo)
    {
        if ($PdiskInfo{STATUS} == PI_GOOD)
        {
            $ses = $PdiskInfo{SES};
            $slot = $PdiskInfo{SLOT};  
        }
        else
        {
            my $msg = "Unable to retrieve pdisk id $pdiskid info.";
            TestLibs::scrub::displayError($msg, %PdiskInfo);
            return ERROR;
        }
    }
    else
    {
        logInfo("ERROR: Did not receive a response packet for pdisk $pdiskid");
        return ERROR;
    }

    $return = PdiskBypass($obj, $ses, $slot, $setting);
    
    if($return != GOOD)
    {
        logInfo("ERROR: unable to bypass drive id    - $pdiskid, ");
        logInfo("                        bay SES     - $ses, ");
        logInfo("                        slot        - $slot, ");
        logInfo("                        on port(s)  - A, B");
        return ERROR;
    }

    return GOOD;

}


##############################################################################
#
#          Name: PDiskBypass
#
#        Inputs: $obj  - master controller objects
#                $ses  - pdisk bay SES 
#                $slot - pdisk slot with in the bay
#                $setting - command setting
#                   0x0 = Unbypass
#                   0x4 = Bypass - B
#                   0x8 = Bypass - A
#                   0xC = Bypass - A and B
#
#
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Bypasses, unbypasses physical disk   
#
#
##############################################################################

sub PdiskBypass
{
    my ($obj, $ses, $slot, $setting) = @_;

    logInfo(" ");
    
    my $PrintString;

    
    if($setting == 0x0)
    {
        $PrintString = "Unbypass";
    }
    
    if($setting == 0x4)
    {
        $PrintString = "Bypass port - B";
    }
    
    if($setting == 0x8)
    {
        $PrintString = "Bypass port - A";
    }

    if($setting == 0xC)
    {
        $PrintString = "Bypass port - A and B";
    }

    logInfo("Attempting to $PrintString pdisk bay SES $ses slot $slot.");



    #if ($setting =~ /^0x/i)
    #{
    #    $setting = oct $setting;
    #}

    #################################################################
    ##  0x0 = Unbypass
    ##  0x4 = Bypass - B
    ##  0x8 = Bypass - A
    ##  0xC = Bypass - A and B
    

    my %return = $obj->physicalDiskBypass($ses, $slot, $setting);

    if (%return)
    {
        if ($return{STATUS} == PI_GOOD)
        {
            logInfo("Pdisk at SES $ses slot $slot is $PrintString .");
            return GOOD;
        }
        else
        {
            
            my $msg = "Unable to bypass pdisk bay SES $ses slot $slot.";
            TestLibs::scrub::displayError($msg, %return);
            return ERROR;
        }
    }
    else
    {
        logInfo(" ");
        logInfo("ERROR: Did not receive a response packet.");
        logInfo("Failed to $PrintString at SES $ses slot $slot.");
        return ERROR;
    }

}

##############################################################################
##############################################################################
#
#          Name: ResetBELoop
#
#        Inputs: controller object, loops, , eight, data
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Executes a generic MRP
#   
#
#
##############################################################################
sub ResetBELoop
{
    trace();
    my ($ctlr, $loop ) = @_;

    my %rsp;

    


    %rsp = $ctlr->loopPrimitiveBE(0, 0, $loop, 0);


                                           
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get a response from loopPrimitiveBE. <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD && $rsp{ERROR_CODE} == 0x36)
    {
        # missing card, 
        return INVALID;
    }

    if ($rsp{STATUS} != PI_GOOD && $rsp{ERROR_CODE} == 0x3d)
    {
        # card present, but unconnected 
        return INVALID;
    }



    if ($rsp{STATUS} != PI_GOOD && $rsp{ERROR_CODE} != 0x36)
    {
        logInfo(">>>>>>>> Error from loopPrimitiveBE. <<<<<<<<");
        PrintError(%rsp);

        return ERROR;
    }

    return GOOD;
}



##############################################################################

=head2 ScrubSet
          
Sets scrub state on the master controller in the VCG.

=over 4

=item Usage:

 my $FuctionReturn = ScrubSet  (    $scrub_control, 
                                    $paritycontrol, 
                                    $raidid, 
                                    $ObjListRef
                                );    
 
 where: $scrub_control - scrub control
        $paritycontrol - parity control
        $raidid - raid id
        $ObjListRef - Reference to the list of controller objects  

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error - Returns 1 (ERROR).

=back

=cut


##############################################################################
#
#          Name:  ScrubSet 
#
#        Inputs: 
#                   $scrub_control - scrub control
#                   $paritycontrol - parity control
#                   $raidid - raid id
#                  $ObjListRef - Reference to the list of controller objects  
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Sets scrub state on the master controller in the VCG
#
#
##############################################################################

sub ScrubSet
{
    my ($scrub_control, $paritycontrol, $raidid, $ObjListRef) = @_;
    
    my @ObjList = @$ObjListRef;
    my $MasterPoss;
    my $MasterControllerObj;
    my %rsp;

    
    #
    # Check for scrub state
    #

    if (uc($scrub_control) eq "ENABLE")
    {
        $scrub_control = SCRUB_ENABLE;
    }
    
    elsif (uc($scrub_control) eq "DISABLE")
    {
        $scrub_control = SCRUB_DISABLE;
    }
    
    else
    {
        logInfo("Invalid scrubbing control option");
        logInfo("Valid options:");
        logInfo("  ENABLE     = Enable scrubbing");
        logInfo("  DISABLE    = Disable scrubbing");
        return ERROR;
    }

    #
    # Get parity cotnrol
    #

    if ($paritycontrol =~ /^0x/i)
    {
        $paritycontrol = oct $paritycontrol;
    }
    else
    {
        my $pc = 0x80000000;
        my @parts = split /\|/, $paritycontrol;

        for (my $i = 0; $i < scalar(@parts); ++$i)
        {
            my $part = $parts[$i];


            if (uc($part) eq "DEFAULT")                               
            {
                $pc |= SCRUB_PC_DEFAULT_MASK;
            }
            elsif (uc($part) eq "MARKED")                             
            {
                $pc |= SCRUB_PC_MARKED_MASK;
            }
            elsif (uc($part) eq "CORRUPT")                            
            {
                $pc |= SCRUB_PC_CORRUPT_MASK;
            }
            elsif (uc($part) eq "SPECIFIC")                           
            {
                $pc |= SCRUB_PC_SPECIFIC_MASK;
            }
            elsif (uc($part) eq "CLEARLOGS")                          
            {
                $pc |= SCRUB_PC_CLEARLOGS_MASK;
            }
            elsif (uc($part) eq "1PASS")                              
            {
                $pc |= SCRUB_PC_1PASS_MASK;
            }
            elsif (uc($part) eq "CORRECT")                            
            {
                $pc |= SCRUB_PC_CORRECT_MASK;
            }
            elsif (uc($part) eq "ENABLE")                             
            {
                $pc |= SCRUB_PC_ENABLE_MASK;
            }
            elsif (uc($part) eq "DISABLE")                            
            {
                $pc &= SCRUB_PC_DISABLE_MASK;
            }

        }

        $paritycontrol = $pc;
    }

    if (!defined($raidid) && ($paritycontrol & SCRUB_PC_SPECIFIC_MASK))
    {
        print "Missing raid identifier, parameter required when parity\n";
        print "control option for a specific raid is specified.\n";
        return ERROR;
    }
    else
    {
        $raidid = 0;
    }

    @ObjList = @$ObjListRef;
        
    #
    # - Find Master controller
    #
    
    
    $MasterPoss = TestLibs::IntegCCBELib::FindMaster( $ObjListRef );
    
    if ( $MasterPoss == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller  <<<<<<<<");
        return ERROR; 
    }
    
    $MasterControllerObj = $ObjList[ $MasterPoss ]; 
    
    #
    # Set scrub state
    #

    %rsp = $MasterControllerObj->scrubSet($scrub_control, $paritycontrol, $raidid);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            $MasterControllerObj->displayScrubInfo(%rsp);
        }
        else
        {
            my $msg = "Unable to set the scrubbing options.";
            TestLibs::scrub::displayError($msg, %rsp);
            return ERROR;
        }
    }
    else
    {
        logInfo(">>>>>>>> Did not receive a response packet  <<<<<<<<");
        return ERROR
    }

    return GOOD;

}


##############################################################################
##############################################################################
sub SetScrubState
{
    my ($ctlr, $scrub_control, $paritycontrol, $raidid ) = @_;

    my $ret;
    my %rsp;

    # sets the current state of scrubbing for this controller
    if ($scrub_control & SCRUB_ENABLE)
    {
        # must turn on scrub change bit
        $scrub_control |= 0x80000000;
    }

    %rsp = $ctlr->scrubSet($scrub_control, $paritycontrol, $raidid);


    if ( !%rsp )
    {
        logInfo(">>>>>>>> Did not receive a response packet from scrubSet  <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} == PI_GOOD)
    {
        logInfo("Scrub State change sent");
        return GOOD;
    }
    else
    {
        logInfo(">>>>>>>> Error returned  from scrubSet  <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

}
##############################################################################
##############################################################################
sub GetScrubState
{
    my ($ctlr, $dPtr ) = @_;

    my $ret;
    my %rsp;

    # gets the current state of scrubbing for this controller

    %rsp = $ctlr->scrubInfo();


    if ( !%rsp )
    {
        logInfo(">>>>>>>> Did not receive a response packet from scrubInfo  <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} == PI_GOOD)
    {
        $$dPtr = $rsp{SSTATE};    # this is the data that gets sent to scrubset
        return GOOD;
    }
    else
    {
        logInfo(">>>>>>>> Error returned  from scrubInfo  <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

}
##############################################################################

=head2 Parity Scan Functions
          
Function for starting, stopping a looking at the results of parity scan.

=over 4

=item Usage:

There are several functions in this group. 

    PScanStart   ( $objPtr, $option, $raid )
    PScanStop    ( $objPtr )
    PScanCheck   ( $objPtr, $option, $raid )      <-- most valuable
    PScanWait    ( $objPtr, $option, $raid )
    PScanResults ( $objPtr, $option, $raid, $ptr )  

The function will return GOOD, ERROR, or INVALID based upon the
success or failure of the function. 
 
 where: $objPtr - pointer to a list of controller objects. All objects
                  must be valid connections.
        $option - the specific control option for the function.
                  Values are the binary bits used for parityControl on 
                  the CCBE setscrub command. (not the text strings)
        $raid - raid id if doing a specific raid
        $data - pointer to a block of data  

 Notes:
 
 Parity scans are only done by the controller owning the raid. Also,
 any results are also contoller specific. So, to do a complete scan of
 the system one must start scans on all controllers and check results
 on all controllers.

=item Returns:

 On success - Returns 0 (GOOD).
 On error - Returns 1 (ERROR).
 If the returned data is invalid, but no error reported - Returns INVALID.

=back

=cut

##############################################################################
#>What can you tell me about the difference between the 
#>     MISCOMP field in raidinfo and  -----------   R10 and R5 miscompares 
#>     MISCOMP field in pdisk info and ---------  only R5 miscompares
#>     R10_MISCOMP field in pdiskinfo --------- only R10 miscompares
#>
#
#######################
#
# 3 or 4 - they are independent.
# Scrub change have to be sent to the master
# miscompare checks must be sent to each controller though
# >JT,
# >To use parity scan, what is the proper value for 'scrub_control' in the call
# >
# >   1) must enable
# >   2) must disable
# >   3) doesn't matter
# >   4) set to its current state
# >
# >In other words, are the two( scrub and parity scan)  independent?
#
#######################
# Are the following true 
# 
# A parity scan sent to a controller that does not specify a specific raid 
# will do all raids that are owned by the controller - TRUE
# 
# A pdiskinfo will report the total number of errors seen by any/all controller(s)? FALSE
# ONLY THE CURRENT CONTROLLER - THE COUNTS AREN'T PROPOGATED
# 
# Raidinfo will only show errors on the owning controller? (or all/any controller) TRUE
# 
# Clearing the logs will clear all the logs for
#       That one controller TRUE
#       All controllers FALSE
# 
# I'm asking too many questions. FALSE:)
#
########################
# How Am I going to determine the state in a parity scan of a single 
#  raid if I am doing all raids? you can't
#
# If I am running continuous scans, how would I know that all raids 
#  have been scanned at least once? you can't
#
# Or at least once since some previous point in time? you can't
# 
# Key need: I start a scan of all raids, one pass. I need to know when 
# all raids are finished. hahaha
# you can start a continuous scan and once it gets to '2' you can 
# disable it to stop immediately
#
# Do multiple raids run in parallel, or are they run sequentuially? sequentially
#
#
#####################
# start a continuous and wait for the count to be '2'.
#
##############################################################################

sub PScanStart
{
    my ( $oPtr, $options, $raid ) = @_;

    
    # This function starts parity scan on all controllers. If a raid id is
    # specified, only that raid will be done. Parity logs are cleared at the 
    # start of the test. Srubbing state is preserved.  

    # Allows starting of a scrub and then running a test in parallel.
    # Although currently that is not recommended. Do this only when
    # the system is stable w.r.t. configuration changes.

    my $i;
    my $ret;
    my $curScrub;
    my $parityControl;
    my $testRaid = 0;
    my $msg;
    my $master;


#     # for each controller, first clear the logs 
#     for ( $i = 0; $i < scalar(@$oPtr); $i++ )
#     {
#
#         if ( POWER_UP_COMPLETE != GetStatePOQ( $$oPtr[$i] ) }
#         {
#             # if the controller is not power up complete, skip it
#             next;
#         }
#
#         # get the current scrub state
#         $ret = GetScrubState($$oPtr[$i], \$curScrub);
#         if ($ret != GOOD )
#         {
#             logInfo("Failure starting scan on controller at index $i");
#             return ERROR;
#         }
# 
#         # now build the parms for the setscrub call (parity options)
# 
# 
#         $parityControl = SCRUB_PC_CLEARLOG_MASK;   # clear logs
# 
#         $parityControl |= 0x80000000;             # new command bit
#         $parityControl |= SCRUB_PC_ENABLE_MASK;   # enable parity scan
#                 
#         # finally, make the call to set scrub/parity
#         CtlrLogText($$oPtr[$i], "Parity scan start begin");
#         $ret = SetScrubState($$oPtr[$i], $curScrub, $parityControl, 0);;
#         if ($ret != GOOD )
#         {
#             logInfo("Failure starting scan on controller at index $i");
#             return ERROR;
#         }
#         else
#         {
#             CtlrLogText($$oPtr[$i], "Parity scan clear log sent");
#             print  "Scan logs cleared - curscrub = $curScrub \n";
#             printf "               parityControl = 0x%08x \n", $parityControl;
#             print  "                        raid = $testRaid \n";
#             print  "            controller index = $i \n";
#         }
# 
#     }
# 
#     PScanLogWait($oPtr, 0, 0);          # wait for the logs to clear




    PScanClrLogs($oPtr);


#    DelaySecs(10);  # give tome for the logs to clear.

    # get the vdisk associated with the raid 
    $master = TestLibs::IntegCCBELib::FindMaster( $oPtr );
    if ( $master == INVALID )
    {
        logInfo(">>>>>>>> Failed to find the master controller  <<<<<<<<");
        return ERROR;
    }

    #
    # Start the scan on the master
    #

    $ret = PScanStartCtlr($oPtr, $master, $options, $raid);
    if ($ret != GOOD )
    {
        logInfo("Failure starting scan on master controller.");
        return ERROR;
    }


    #
    # for each slave controller, now start the pscan
    #

    for ( $i = 0; $i < scalar(@$oPtr); $i++ )
    {
        if ( POWER_UP_COMPLETE != GetStatePOQ( $$oPtr[$i] ) )
        {
            # if the controller is not power up complete, skip it
            next;
        }

        if ( $i == $master )
        {
            # if the controller is the master, we've already done it
            next;
        }


        PScanStartCtlr($oPtr, $i, $options, $raid);
        

    }

    return GOOD;
}
##############################################################################
sub PScanStartCtlr
{

    my($oPtr, $i, $options, $raid) = @_;

    my $curScrub;
    my $ret;
    my $parityControl;
    my $testRaid;
    
    
    # get the current scrub state
    $ret = GetScrubState($$oPtr[$i], \$curScrub);
    if ($ret != GOOD )
    {
        logInfo("Failure starting scan on controller at index $i");
        return ERROR;
    }

    # now build the parms for the setscrub call (parity options)

    $parityControl = $options;        # this will get more involved

    $parityControl |= SCRUB_PC_ENABLE_MASK;   # enable parity scan

    $parityControl |= SCRUB_PC_CLEARLOG_MASK;   # clear logs again

    $parityControl |= 0x80000000;             # new command bit
            
    # add in the specific raid bit if a raid has been specified
    
    # 1st make sure the bit is cleared
    $parityControl &=  ~SCRUB_PC_SPECIFIC_MASK;

    # now set it if necessary
    if ( defined ($raid) )
    {
        if ( $raid >= 0 ) 
        {
            $parityControl |=  SCRUB_PC_SPECIFIC_MASK;
            $testRaid = $raid;
        }
        else
        {
            $testRaid = 0;
        }
    }

    # finally, make the call to set scrub/parity
    CtlrLogText($$oPtr[$i], "Parity scan start begin");
    $ret = SetScrubState($$oPtr[$i], $curScrub, $parityControl, $testRaid);;
    if ($ret != GOOD )
    {
        logInfo("Failure starting scan on controller at index $i");
        return ERROR;
    }
    else
    {
        CtlrLogText($$oPtr[$i], "Parity scan start sent");
        print  "Scan started - curscrub = $curScrub \n";
        printf "          parityControl = 0x%08x \n", $parityControl;
        print  "                   raid = $testRaid \n";
        print  "       controller index = $i \n";
    }

    return GOOD;
}
##############################################################################
sub PScanClrLogs
{
    my ( $oPtr ) = @_;

    # This function clears the pass count and logs on each controller.

    my $i;
    my $ret;
    my $curScrub;
    my $parityControl;
    my $flag;
    my $loopCount;
    my $count;
    my $mode;

    # for each controller
    for ( $i = 0; $i < scalar(@$oPtr); $i++ )
    {
        if ( POWER_UP_COMPLETE != GetStatePOQ( $$oPtr[$i] ) )
        {
            # if the controller is not power up complete, skip it
            next;
        }

        # get the current scrub state
        $ret = GetScrubState($$oPtr[$i], \$curScrub);
        
        if ($ret != GOOD )
        {
            logInfo("Failure getting scrub/parity scan state on controller at index $i");
            return ERROR;
        }

        #
        # seet the clr logs bit and enable (Brett may change this)
        #

        $parityControl = SCRUB_PC_CLEARLOG_MASK;   # clear logs

        $parityControl |= 0x80000000;             # new command bit
        $parityControl |= SCRUB_PC_ENABLE_MASK;   # enable parity scan

        # finally, make the call to set scrub/parity
        $ret = SetScrubState($$oPtr[$i], $curScrub, $parityControl, 0);;
        
        if ($ret != GOOD )
        {
            logInfo("Failure stopping parity scan on controller at index $i");
            return ERROR;
        }

        #
        # now wait for that controller's pass count to go to zero
        #

        $flag = 1;                            # 1 means keep waiting
        $loopCount = 0;

        while ( $flag != 0 )
        {
            $loopCount++;

            sleep 1;
print "\r";
            $flag = 0;                        # 0 means we are  done waiting
    
            # get the current scrub state
            $ret = PScanCount($$oPtr[$i], \$count, \$mode);



print "Loop: $loopCount   Controller $$oPtr[$i]->{HOST}, pass count $count     ";

            if ( $count > 1 )
            {
                # pass count has been cleared.
                $flag = 1;

                if ( $count >= 10 )
                {
                    $ret = SetScrubState($$oPtr[$i], $curScrub, $parityControl, 0);;
                }

            }

        }
print "\n";



        #
        # now disable the parity scan
        #
        $parityControl = SCRUB_PC_CLEARLOG_MASK;   # clear logs

        $parityControl |= 0x80000000;             # new command bit

        # finally, make the call to set scrub/parity
        $ret = SetScrubState($$oPtr[$i], $curScrub, $parityControl, 0);;
        
        if ($ret != GOOD )
        {
            logInfo("Failure stopping parity scan on controller at index $i");
            return ERROR;
        }

        # now wait for that controller's pass count to go to zero


    }

    return GOOD;
}
##############################################################################



##############################################################################
sub PScanStop
{
    my ( $oPtr ) = @_;

    # This function stops any running parity scan on all controllers. 
    # It must read the current scrub settings to make sure we don't mess
    # with scrubbing.

    my $i;
    my $ret;
    my $curScrub;
    my $parityControl;

    # for each controller
    for ( $i = 0; $i < scalar(@$oPtr); $i++ )
    {

        if ( POWER_UP_COMPLETE != GetStatePOQ( $$oPtr[$i] ) )
        {
            # if the controller is not power up complete, skip it
            next;
        }


        # get the current scrub state
        $ret = GetScrubState($$oPtr[$i], \$curScrub);
        
        if ($ret != GOOD )
        {
            logInfo("Failure getting scrub/parity scan state on controller at index $i");
            return ERROR;
        }

        # finally, make the call to set scrub/parity
        $ret = SetScrubState($$oPtr[$i], $curScrub, 0x80000000, 0);;
        
        if ($ret != GOOD )
        {
            logInfo("Failure stopping parity scan on controller at index $i");
            return ERROR;
        }

    }

    return GOOD;
}
##############################################################################


##############################################################################
sub PScanCheck
{
    my ( $oPtr, $options, $raid ) = @_;
    
    
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
#logInfo("Parity scan bypassed for debug purposes.");
#return GOOD;
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
    #   DEBUG     DEBUG     DEBUG      DEBUG      do not check in
    

    # This function does a parity scan of all raids of type 5 or 10 on
    # the system. It goes to each controller and does invokes a scan on
    # all raids. Then it waits for the scans to finish on all controllers.
    # Finally, it checks the results of the scan and returns. Any error
    # indications will be logged. Return is GOOD if no errors, ERROR if 
    # there were data errors, INVALID if any command issued to the controllers
    # generated an error (meaning, we could not determine of parity was 
    # good or bad). 
    
    # The current stae of scrub(bing) is unchanged. The parity scan logs 
    # are cleared at the start of the test. They are not cleared afterward.

    # This would be called between tests that create potential errors.


    my $i;
    my $ret;

    # we want this to always clear that logs, so let us set the clear bit

    $options |=  SCRUB_PC_CLEARLOG_MASK;


    # start the scan(s)
    $ret =  PScanStart( $oPtr, $options, $raid );
    
    if ($ret != GOOD )
    {
        logInfo("Failure starting scans for the parity check");
        return ERROR;
    }

    # now wait for the scans to finish
    $ret =  PScanWait( $oPtr, $options, $raid );
    
    if ($ret != GOOD )
    {
        logInfo("Failure while waiting for scans to finish in the parity check");
        return ERROR;
    }

    # stop the scan(s).  Not needed if we did a single pass, but
    # harmless even if we did.
    $ret =  PScanStop( $oPtr ); 
       
    if ($ret != GOOD )
    {
        logInfo("Failure stopping scans for the parity check");
        return ERROR;                                                              
    }

    # now that the raids have finished, see if there were any errors
    $ret =  PScanResults( $oPtr, $options, $raid, undef );
    
    if ($ret != GOOD )
    {
        logInfo("Errors seen during the parity scan");
        return ERROR;                                                              
    }

    # we have run the scan and know if the scan was good or bad
    # return appropriately



    return GOOD;
}
##############################################################################

##############################################################################
sub PScanLogWait
{
    my ( $oPtr, $options, $raid ) = @_;


    # This function polls the controllers to wait for the pass count
    # to be cleared. 


    # if a raid number is provided, this will only poll the controller
    # that owns the specific raid.

    my $i;
    my $ret;
    my $flag;
    my $method = 0;   # 0 is all controllers are checked, 1 is single
    my $master;
    my %info;
    my @snList;
    my $index;
    my $targ;
    my $vd;
    my $loopCount = 0;
    my $count;
    my $mode;
                
#    if ( defined ($raid) )
#    {
#       if ( $raid >= 0 ) 
#        {
#            $method = 1;
#        }
#    }

    if ( $method == 0 )
    {
        # ALL controllers are checked

        $flag = 1;                            # 1 means keep waiting
        $loopCount = 0;
        print "\n";

        while ( $flag != 0 )
        {
            sleep 1;
            $loopCount++;
            $flag = 0;                        # 0 means we are  done waiting
        
print "           \rLoop: $loopCount   ";

            for ( $i = 0; $i < scalar(@$oPtr); $i++ )
            {

                if ( POWER_UP_COMPLETE != GetStatePOQ( $$oPtr[$i] ) )
                {
                    # if the controller is not power up complete, skip it
                    next;
                }

                # get the current scrub state
                $ret = PScanCount($$oPtr[$i], \$count, \$mode);

print "Controller $i, pass count $count ($mode)    ";

                if ( $count != 0 )
                {
                    # not yet cleared, set the flag to continue waiting
                    $flag = 1;
                }
            }

        }
print "\n";

    }
    else
    {
        # single raid - only check the owning controller

        # get the vdisk associated with the raid 
        $master = TestLibs::IntegCCBELib::FindMaster( $oPtr );
        if ( $master == INVALID )
        {
            logInfo(">>>>>>>> Failed to find the master controller  <<<<<<<<");
            return ERROR;
        }

        %info = $$oPtr[$master]->virtualDiskRaidInfo($raid);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskRaidInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskRaidInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        $vd = $info{VID};

        # find the owner of the vdisk

        # (first build a serial number list)
        for ( $i = 0; $i < scalar(@$oPtr); $i++ )
        {
         
            if ( POWER_UP_COMPLETE != GetStatePOQ( $$oPtr[$i] ) )
            {
                # if the controller is not power up complete, skip it
                next;
            }

            # get the current scrub state
            $ret = GetSerial($$oPtr[$i]);

            if ( $ret != INVALID )
            {
                # save serial number in list
                $snList[$i] = $ret;;
            }
            else
            {
                logInfo("Failed to complete the serial number list.");
                return ERROR;
            }
        }

        ($index, $targ) = FindVdiskOwner ($oPtr, \@snList, $vd);
        if ( $index == INVALID ) { return ERROR; }
        if ( $targ == INVALID ) { return ERROR; }


        # loop similar to above, using index to select a specific controller
        $flag = 1;                            # 1 means keep waiting

        while ( $flag != 0 )
        {

            sleep 1;

            $flag = 0;                        # 0 means we are  done waiting
    
            # get the current scrub state
            $ret = PScanCount($$oPtr[$i], \$count, \$mode);
            
print "Controller $index, pass count $count ($mode)   \n ";

            if ( $count < 2 )
            {
                # we are still on the first pass, set the flag to continue waiting
                $flag = 1;
            }

        }


    }

    return GOOD;
}
##############################################################################

##############################################################################
sub PScanWait
{
    my ( $oPtr, $options, $raid ) = @_;


    # This function polls the controllers to wait for any running parity 
    # scans to finish. (There are two options: 1) keep checking the logs
    # and 2) use (not yet existing) data in scrubinfo. Code A2A0 should have
    # this data in the packet.

    # This actually waits until all controllers have started pass 2. To
    # use, the caller should clear the scrub logs and then start the scrub.
    # This way, we can poll until all have finished the first pass.

    # if a raid number is provided, this will only poll the controller
    # that owns the specific raid.

    my $i;
    my $ret;
    my $flag;
    my $method = 0;   # 0 is all controllers are checked, 1 is single
    my $master;
    my %info;
    my @snList;
    my $index;
    my $targ;
    my $vd;
    my $count;
    my $pcount;
    my $mode;
    my $eCount = 0;
    my @errorCounts;
    
    #
    # intialize error counts array
    #
    
    for ( $i = 0; $i < scalar(@$oPtr); $i++ )
    {
        $errorCounts[$i] = 0;
    }
    
                
    if ( defined ($raid) )
    {
        if ( $raid >= 0 ) 
        {
            $method = 1;
        }
    }

    if ( $method == 0 )
    {
        # ALL controllers are checked

        $flag = 1;                            # 1 means keep waiting
print "\n";

        while ( $flag != 0 )
        {
            sleep 1;

            $count++;
            
            $flag = 0;                        # 0 means we are  done waiting
        
print "                 \rLoop: $count  ";

            for ( $i = 0; $i < scalar(@$oPtr); $i++ )
            {
                if ( POWER_UP_COMPLETE != GetStatePOQ( $$oPtr[$i] ) )
                {
                    # if the controller is not power up complete, skip it
                    next;
                }

                # get the current scrub state and pass count
                $ret = PScanCount($$oPtr[$i], \$pcount, \$mode);
                
                # get the number of errors seen so far
                $ret = PScanErrorCount  ( $$oPtr[$i], \$eCount);
                
                
print "Controller $$oPtr[$i]->{HOST}, pass ct $pcount ($mode), errors  $eCount  ";

                if ( $eCount != INVALID )
                {
                    if ( $eCount != $errorCounts[$i] )
                    {
                        #
                        # the count for this controller has changed, update array and
                        # move output to the next line so it can be seen, also log this
                        #
                        print "\n";
                        logInfo("Error count for controller $$oPtr[$i]->{HOST} now $eCount (was $errorCounts[$i])");
                        $errorCounts[$i] = $eCount;
                 
                 
                        #
                        # location to add parallel port trigger to analyzer
                        #
                 
                 
                    }
                }   

                #
                # There are rebuild paths in the controller that will change the scrub setting
                # to single. This breaks the test. Assuming that the change in scrub setting
                # is normal and OK, then we can just change it back to what the test needs.
                # (We should consider that whatever caused the rebuild may 
                # itself be an error.)
                #
                if ( $mode eq "SINGLE" )
                {
                    print "\n";                       # preserves line with single status
                    logInfo("   >>>>>>> Mode detected as single, changing back to continuous.");
                    PScanStartCtlr($oPtr, $i, $options, $raid);
                }

                if ( $pcount < 2 )
                {
                    # we are still on the first pass, set the flag to continue waiting
                    $flag = 1;
                }
            }

        }
print "\n";

    }
    else
    {
        # single raid - only check the owning controller

        # get the vdisk associated with the raid 
        $master = TestLibs::IntegCCBELib::FindMaster( $oPtr );
        if ( $master == INVALID )
        {
            logInfo(">>>>>>>> Failed to find the master controller  <<<<<<<<");
            return ERROR;
        }

        %info = $$oPtr[$master]->virtualDiskRaidInfo($raid);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskRaidInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskRaidInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        $vd = $info{VID};

        # find the owner of the vdisk

        # (first build a serial number list)
        for ( $i = 0; $i < scalar(@$oPtr); $i++ )
        {
            if ( POWER_UP_COMPLETE != GetStatePOQ( $$oPtr[$i] ) )
            {
                # if the controller is not power up complete, skip it
                next;
            }

            # get the current scrub state
            $ret = GetSerial($$oPtr[$i]);

            if ( $ret != INVALID )
            {
                # save serial number in list
                $snList[$i] = $ret;;
            }
            else
            {
                logInfo("Failed to complete the serial number list.");
                return ERROR;
            }
        }

        ($index, $targ) = FindVdiskOwner ($oPtr, \@snList, $vd);
        if ( $index == INVALID ) { return ERROR; }
        if ( $targ == INVALID ) { return ERROR; }


        # loop similar to above, using index to select a specific controller
        $flag = 1;                            # 1 means keep waiting

        while ( $flag != 0 )
        {

            sleep 1;

            $flag = 0;                        # 0 means we are  done waiting
    
            # get the current scrub state
            $ret = PScanCount($$oPtr[$i], \$pcount, \$mode);

print "Controller $index, pass count $pcount  ($mode)  \n ";

            if ( $pcount < 1 )
            {
                # we are still on the first pass, set the flag to continue waiting
                $flag = 1;
            }

        }


    }

    return GOOD;
}
##############################################################################
sub PScanErrorCount
{
    my ( $ctlr, $countPtr) = @_;
    
    my $i;
    
    # a function to get the count of errors from the raids.
    
    my $totalErrors = 0;
    my %raidsHash;
    
    #
    # invalidate return value in case we get an error\
    #
    
    $$countPtr = INVALID;
    
    #
    # do a raids command to get the data for all raids at onec.
    # if we get the data, then sum the MISCOMP counts for 
    # all raids
    #
    
    %raidsHash =  $ctlr->raids();
    
    if (%raidsHash)
    {
        if ($raidsHash{STATUS} == PI_GOOD)
        {
            for ($i = 0; $i < $raidsHash{COUNT}; $i++)
            {
    
                $totalErrors +=  $raidsHash{RAIDS}[$i]{MISCOMP};
        
            }
            
            #
            # Put the total in the desired location, then return
            #
            $$countPtr = $totalErrors;
            
            return (GOOD);
        }
        else
        {
            logInfo("Unable to retrieve the raids information.");
            PrintError(%raidsHash);
        }
    }
    else
    {
        LogInfo( "ERROR: Did not receive a response packet from raids.");
    }
 
    return (ERROR);   
}
##############################################################################
sub PScanCount
{
    my ($obj, $countPtr, $statePtr) = @_;

    # this function gets the parity scan count from a controller
    # on error, INVALID is returned otherwise the count is returned.

    $$statePtr = INVALID;
    $$countPtr = INVALID;

    my %rsp = $obj->scrubInfo();

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            # the scrub info data is valid. However, this is really pointless 
            # if scrub is not running, so make the appropriate checks and
            # return INVALID if the parity scan is not running.

#  my $msg = XIOTech::cmdMgr::displayScrubInfo(0, %rsp);
#  print "\n$msg \n\n";

            $$statePtr = $rsp{PC_1PASS};
            $$countPtr = $rsp{PASSES};

  # need to get a new thing from JT to check for this
            
            if(  $rsp{PC_ENABLE} eq "ENABLED" )
            {
                
                
                # pscan is enabled so return pass count
                return GOOD;
            }
            else
            {
                
                logInfo("ERROR: the current state of PC_ENABLE is $rsp{PC_ENABLE} \n\n");
                return ERROR;
            }
        }
        else
        {
            logInfo("Unable to retrieve the scrubbing information.");
            PrintError(%rsp);
        }
    }
    else
    {
        LogInfo( "ERROR: Did not receive a response packet from scrubinfo.");
    }
 
    return ERROR;

}

##############################################################################
sub PScanResults
{
    my ( $oPtr, $options, $raid, $aPtr ) = @_;

    # This function gets the scrub error counts for all raids and pdisks 
    # on all controllers. The function fills the data arrays at the location
    # provided by the data pointer(s). Mainly a collection of raidinfo and 
    # pdiskinfo calls on all controllers

    my $i;
    my @pdisks;
    my $msg;
    my $j;
    my %info;
    my $retval = GOOD;

    # for each controller
    for ( $i = 0; $i < scalar(@$oPtr); $i++ )
    {

        if ( POWER_UP_COMPLETE != GetStatePOQ( $$oPtr[$i] ) )
        {
            # if the controller is not power up complete, skip it
            next;
        }

        # get a list of pdisks
        
        @pdisks = GetPddList( $$oPtr[$i] );
        if ( $pdisks[0] == INVALID )
        {
            logInfo( "Failed to get a pdisk list from controller $i");
            return INVALID;
        }
        
        # list on a single line
        logInfo("PScanResults: Current pdisk list: @pdisks ");

        # for each pdisk
        for ( $j = 0; $j < scalar(@pdisks); $j++ )
        {
            # check number of  R5 and R10 miscompares (two values)
            # MISCOMP field in pdisk info and ---  only R5 miscompares
            # R10_MISCOMP field in pdiskinfo --- only R10 miscompares
            
            %info = $$oPtr[$i]->physicalDiskInfo($pdisks[$j]);
            if ( ! %info  )
            {
                logInfo(">>>>> Failed to get response from physicalDiskInfo <<<<<");
                return INVALID;
            }
            if ($info{STATUS} != PI_GOOD)
            {
                logInfo(">>>>> Unable to physicalDiskInfo <<<<<");
                PrintError(%info);
                return INVALID;
            }


            # put the counts in the provided array


 # add code here (uses aPtr )



            # only print if data show errors

            if ( ($info{MISCOMP} > 0) || ($info{R10_MISCOMP} > 0) )
            {
                logInfo("   Parity scan errors seen on PID $info{PD_PID}");
                logInfo("       R5  errors:  $info{MISCOMP} ");
                logInfo("       R10 errors:  $info{R10_MISCOMP} ");

                # set 'failure' flag if any errors ---> THIS ONLY CATCHES RAID 5 ERRORS.
                if ($info{MISCOMP} > 0)
                {
                    # set failure for R5 errors only, ignore RAID 10
                    $retval = ERROR;
                }
            }
        
        
        } # pdisk loop

        # get a list of raids
        %info = $$oPtr[$i]->raidList();
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from raidList <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from raidList <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        $j = $info{LIST};
        @pdisks = @$j;        

        # list on a single line
        logInfo("PScanResults: Current raids list: @pdisks ");


        # for each raid
        for ( $j = 0; $j < scalar(@pdisks); $j++ )
        {
            
            %info = $$oPtr[$i]->virtualDiskRaidInfo($pdisks[$j]);
            if ( ! %info  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from virtualDiskRaidInfo <<<<<<<<");
                return ERROR;
            }
            if ( $info{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from virtualDiskRaidInfo <<<<<<<<");
                PrintError(%info);
                return ERROR;
            }


            # check number of miscompares (also show raid type)
            # put the counts in the provided array

 # add code here (uses aPtr )


            # only print info if data shows error
            if ( $info{MISCOMP} > 0 )
            {
                logInfo("   Parity scan errors seen on raid $pdisks[$j]");
                logInfo("       R5/R10  errors:  $info{MISCOMP} ");
                logInfo("       Raid type: $info{TYPE} ");

                # set 'failure' flag if any errors ON RAID 5
                if ( $info{TYPE} == RAID_5 )
                {
                    $retval = ERROR;
                }
            }

        } # raid loop
    
    } # controller loop

    return $retval;

#    return GOOD;             # this means we can't fail
}

##############################################################################
sub GetSesAndSlot
{
    my ($ctlr, $pdd, $sesPtr, $slotPtr, $lidPtr, $portPtr) = @_;

    # this function does a pdisk info on the specified pdd and extracts
    # the ses and slot information. We need this to be able to unbypass
    # a drive.

    if ( !defined $lidPtr )
    {
        $lidPtr = 0;
    }
    
    if ( !defined $portPtr )
    {
        $portPtr = 0;
    }

    my %pdiski = $ctlr->physicalDiskInfo($pdd);
    
    if ($pdiski{STATUS} == PI_GOOD)
    {
        $$sesPtr = $pdiski{SES};
        $$slotPtr = $pdiski{SLOT};
        if ( $lidPtr )
        {
            $$lidPtr = $pdiski{PD_ID};
        }    
        if ( $portPtr )
        {
            $$portPtr = $pdiski{PD_CHANNEL};
        }    
        return GOOD;
    }

    logInfo(">>>>>>>> ERROR: Could not retrieve slot/ses via pdisk information <<<<<<<<");
    PrintError(%pdiski);

    return ERROR;
}

#############################################################################    
#
#          Name:  FindPdId 
#
#        Inputs: 
#                   $scrub_control - scrub control
#                   $paritycontrol - parity control
#                   $raidid - raid id
#                  $ObjListRef - Reference to the list of controller objects  
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Sets scrub state on the master controller in the VCG
#
#
##############################################################################

sub FindPdIdOLD
{
    my ( $ctlr, $ses, $slot ) = @_; 

    my %PdInfo;

    my @PdList = GetPddList( $ctlr);
    
    if ( $PdList[0] == INVALID )
    {
        return INVALID; 
    }

    for(my $i = 0; $i < scalar(@PdList); $i++)
    {
        %PdInfo = $ctlr->physicalDiskInfo($PdList[$i]);
    
        if ( ! %PdInfo  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskInfo <<<<<<<<");
            return INVALID;
        }
        
        if ($PdInfo{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to physicalDiskInfo on PDD $PdList[$i]) <<<<<<<<");
            PrintError(%PdInfo);
            return INVALID;
        }
        
        if( ($PdInfo{SES} == $ses) && ($PdInfo{SLOT} == $slot))
        {
            return $PdInfo{PD_PID};
        }
    }

    return INVALID; 
}

##############################################################################


sub FindPdId
{
    my ( $ctlr, $ses, $slot ) = @_; 
    
    my $i;
    my $okData = 0;
    my $badDataCount = 0;

    while ( $okData == 0 )
    {
        
        # have we been down this path too many times?
        if ( $badDataCount > 30 )
        {
            logInfo(" Failure: Too many attempts for getting SES data. ");
            return INVALID;
        }
        
        
        my %drives = $ctlr->physicalDisks();  # get list of drives present

        if ( ! %drives  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDisks, retrying <<<<<<<<");
            $badDataCount++;
            next;
        }
        if ($drives{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error from physicalDisks, retrying <<<<<<<<");
            $badDataCount++;
            next;
        }

        $okData = 1;


        print "Looking for SES $ses and SLOT $slot on $drives{COUNT} drives\n";

        for ( $i = 0; $i < $drives{COUNT}; $i++)     # for each drive
        {
            print "Checking drive $i, PID $drives{PDISKS}[$i]{PD_PID},";
            print " SES $drives{PDISKS}[$i]{SES}, SLOT $drives{PDISKS}[$i]{SLOT} \n";
        
            
            # make sure we have valid SES/SLOT information, if not, retry
            if (  ( 65535  == $drives{PDISKS}[$i]{SES})  ||   ( 255  == $drives{PDISKS}[$i]{SLOT} ) )
            {
                # data was bad, SES info not ready, try again
                
                $badDataCount++;
                
                logInfo(" SES data was not ready, pause and retry ");
                sleep (1);
                $okData = 0;
                last;
            }
        
        
            if (($drives{PDISKS}[$i]{SES} == $ses) && ($drives{PDISKS}[$i]{SLOT} == $slot))  # if drive is good
            {
                print "found it!\n";
                return $drives{PDISKS}[$i]{PD_PID} ;
            }
        }

    }
    return INVALID; 
}


#############################################################################    
#
#          Name:  FindIsolatedPdds 
#
#        Inputs: 
#                   $ctlr - pointer to controller object
#                   $pPtr - pointer to list of pdds (for output)
#                   $count - number of requested pdds in list
#
#       Outputs: GOOD, ERROR, filled in @$pPtr list
#
#  Globals Used: none
#
#   Description: Identifies a list a pdisks that do not share any raids.
#                Uses the SOS tables to determine what is on each pdd.
#
#
##############################################################################
sub FindIsolatedPdds
{
    my ( $ctlr, $pPtr, $count) = @_;

    my %info;

    my @raidList;
    my @pddList;

    my $i;
    my $j;
    my $k;

    my @pdisks;

    my $noMatch;
    my $thisRaid;

    #
    # Get a list of current pdisks
    #

    @pdisks = GetDataDisks($ctlr, PD_DT_ALL);
    if ( $pdisks[0] == INVALID )
    {   
        return ERROR;
    }

    #
    # for each pdisk
    #

    for ($i = 0; $i <scalar(@pdisks); $i++)
    {



print ("Checking pdisk $pdisks[$i] for isolation.\n");

        #
        # get the sos table
        #

        %info = $ctlr->getSos($pdisks[$i]);

        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from getSos <<<<<<<<");
            return ERROR;
        }

        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error getting SOS table <<<<<<<<");
            return ERROR;
        }


        #
        # see if any raids are in the raid list
        #

        $noMatch = 1;

        for ( $j = 0; $j < $info{COUNT}; $j++)
        {
            $thisRaid = $info{LIST}[$j]{RID};

            if ( $thisRaid < 2000 )          # not the reserved one
            {
            
                for ( $k = 0; $k < scalar(@raidList); $k++ )
                {
                    if ( $thisRaid == $raidList[$k] )
                    {
                        # raid was in the list, we cannot use this pdisk
  
#  print ("   Raid $thisRaid matched  $raidList[$k] .\n");

                        $noMatch = 0;
                    }
                    else
                    {

#  print ("   Raid $thisRaid did not match $raidList[$k] .\n");


                    }
                }
            }

        }

        if ( $noMatch == 1 )
        {

            #
            # if not, add raids to the raid list and pdisk to the
            # output pdisk list (there must be raids defined on the
            # pdisk to be useful)
            #
            for ( $j = 0; $j < $info{COUNT}; $j++)
            {
                $thisRaid = $info{LIST}[$j]{RID};

                if ( $thisRaid < 2000 )          # not the reserved one
                {
                    push (@raidList, $thisRaid);
                }

            }

print ("Added $pdisks[$i] to the isolated list.\n");
        
            push( @pddList, $pdisks[$i] );
        }
        
        #
        # stop if we have enough disks, return list
        #

        if ( scalar(@pddList) >= $count )
        {
            for ( $j = 0; $j < scalar(@pddList); $j++)
            {
                $$pPtr[$j] = $pddList[$j];
            }

            return GOOD;
        }
    
    }

    #
    #  return the list we created, may be smaller than requested
    #


    for ( $j = 0; $j < scalar(@pddList); $j++)
    {
        $$pPtr[$j] = $pddList[$j];
    }



    return GOOD;
}



##############################################################################

=head2 RemoveMirrors

This function takes in an array of vdisks and returns the array of vdisks
with all the mirror destination vdisks removed.  

=cut

=over 1

=item Usage:

 my $rc = RemoveMirrors($ctlr, $source, $dest);
 
 where:  $ctlr      - ptr to controller object
         $source    - ptr to input array of Vdisks
         $dest      - ptr to output array to store non mirror dest vdisks

=item Returns:

         GOOD       - Function successful.  The resulting vdisk array is 
                      stored at $dest.    
         ERROR      - Function failed.  
         
=item Things to look for:
 
 None

=item Initial Conditions:

 None

=back

=cut
##############################################################################
sub  RemoveMirrors
{
    my ( $ctlr, $source, $dest ) = @_;

    my $i;
    my %vdi;
    my $count = 0;

    #
    # for each vdisk in the source list
    #
    for ( $i = 0; $i < scalar(@$source); $i++ )
    {
        #
        # get vdisk info for the disk
        #
        %vdi = $ctlr->virtualDiskInfo( $$source[$i] );

        if (!%vdi)                        # no response
        {
            logInfo(">>>>> Failed to receive a response from virtualDiskInfo($$source[$i]) <<<<<");
            return ERROR;
        }
        elsif ($vdi{STATUS} != 0)            # 0 is good, anything else is bad
        {
            logInfo(">>>>> ERROR: virtualDiskInfo($$source[$i]) returned an error <<<<<");
            PrintError(%vdi);
            return ERROR;
        }

        #
        # if vdisk is not a mirror dest, add to dest and increment count 
        #        
        if ( $vdi{MIRROR} == 0 ) 
        {
            $$dest[$count] = $$source[$i];
            $count++;
        }
    }


    return GOOD;


}


##############################################################################
sub  RemoveVlinks
{
    my ( $ctlr, $source, $dest ) = @_;

    my $i;
    my $raid;
    my $rType;
    my %vdi;
    my %ri;
    my $count = 0;

    # for each vdisk in the source list;
    for ( $i = 0; $i < scalar(@$source); $i++ )
    {
        # get vdisk info for the disk
        %vdi = $ctlr->virtualDiskInfo( $$source[$i] );

        if (!%vdi)                        # no response
        {
            logInfo(">>>>> Failed to receive a response from virtualDiskInfo($$source[$i]) <<<<<");
            return ERROR;
        }
        elsif ($vdi{STATUS} != 0)            # 0 is good, anything else is bad
        {
            logInfo(">>>>> ERROR: virtualDiskInfo($$source[$i]) returned an error <<<<<");
            PrintError(%vdi);
            return ERROR;
        }

        $raid = $vdi{RIDS}[0] ;

        # get the raid info for the first raid

        %ri = $ctlr->virtualDiskRaidInfo($raid);

        if (!%ri)                        # no response
        {
            logInfo(">>>>> Failed to receive a response from virtualDiskRaidInfo($raid) <<<<<");
            return ERROR;
        }
        elsif ($ri{STATUS} != 0)            # 0 is good, anything else is bad
        {
            logInfo(">>>>> ERROR: virtualDiskRaidInfo($raid) returned an error <<<<<");
            PrintError(%ri);
            return ERROR;
        }

        $rType =  $ri{TYPE};

        # if raid is less than 5
        
        if (( $rType < 5 ) ) 
        {
            # this is a real raid type, not a vlink
            # add vdisk to the dest list

            $$dest[$count] = $$source[$i];

            # bump counter/index

            $count++;

        }

    }


    return GOOD;


}

##############################################################################
sub ShortVdisks
{
    trace();
    my ($ctlr1) = @_;

    my %rsp;
    my $i;
    my $r;
    my @ar;
    my $vdisklist;
    my @vdisklistarray;
    my $numVDDs;
    my  $ap;
    my  %vd;
    my $msg;

    %rsp = $ctlr1->virtualDisks();

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks <<<<<<<<");
        return ERROR;
    }

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            if ($rsp{COUNT} > 0)
            {
                $msg = "\nVdisk Status\n Vdisk: ";
                
                # first line is the vdisk number
                for ($i = 0; $i < $rsp{COUNT}; $i++)
                {
                    $msg .= sprintf( " %3hu  ", $rsp{VDISKS}[$i]{VID});
                }

                $msg .="\nStatus: ";

                # second line is its status
                for ($i = 0; $i < $rsp{COUNT}; $i++)
                {
                    $msg .= sprintf( "0x%02x  ", $rsp{VDISKS}[$i]{DEVSTAT});
                }

                $msg .= "\n";

                logInfo ($msg);
                
            }
            else
            {
                logInfo("No virtual disks present");
            }
        }
        else
        {
            logInfo(">>>>>>>> Unable to retrieve  virtual disk information. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }

    return GOOD;
}
##############################################################################
sub ShortPdiskInfo
{
    trace();
    my ($ctlr1) = @_;
    my %rsp;
    my $msg = "";
    my $i;
    my $bad;
    my $outerLoops;
    my $outer;
    my $inner;
    my $innerLoops;
    my $innerStart;
    my $innerEnd;

    ########### devstat PD ################

    %rsp = $ctlr1->deviceStatus("PD");

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from deviceStatus <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get device status <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    # display it

    use constant ENTRIES => 14;

    $outerLoops = 1+ int( $#{$rsp{LIST}} / ENTRIES );

    for ( $outer = 0; $outer < $outerLoops; $outer++ )
    {

        $innerStart = $outer * ENTRIES;

        $innerEnd = $innerStart + ENTRIES;

        if ( $innerEnd > (1+$#{$rsp{LIST}}) ) { $innerEnd = 1 + $#{$rsp{LIST}}; }
        
        
        # the First two lines have the pdisk number
        
        $msg .=  "\nPdisk status:\n PID: ";  
        for ( $i = $innerStart; $i < $innerEnd; $i++ )
        {
            if ($rsp{LIST}[$i]{PD_DEVSTAT} != 0x10 ||
                $rsp{LIST}[$i]{PD_MISCSTAT} != 0x00 ||
                $rsp{LIST}[$i]{PD_POSTSTAT} != 0x10)
            {
                $bad = "*";
            }
            else
            {
                $bad = " ";
            }

            $msg .= sprintf ("%3hu%1s  ", $rsp{LIST}[$i]{PD_PID}, $bad);
        }

        # the next line is the device status
        
        $msg .=  "\n Dev: ";  
        for ( $i = $innerStart; $i < $innerEnd; $i++ )
        {
            $msg .= sprintf ("0x%02x  ", $rsp{LIST}[$i]{PD_DEVSTAT});
        }

        # followed by the Misc status
        
        $msg .=  "\nMisc: ";  
        for ( $i = $innerStart; $i < $innerEnd; $i++ )
        {
            $msg .= sprintf ("0x%02x  ", $rsp{LIST}[$i]{PD_MISCSTAT});
        }

        
        # and the power on status
        
        $msg .=  "\nPost: "; 
        for ( $i = $innerStart; $i < $innerEnd; $i++ )
        {
            $msg .= sprintf ("0x%02x  ", $rsp{LIST}[$i]{PD_POSTSTAT});
        }
    
        $msg .= "\n";
    
    }
    
    $msg .= "\n";

    logInfo($msg);

    return (GOOD);
}

#############################################################################    
sub LocateRaidXVdisks
{
    my ($ctlr, $vddPtr, $count, $rtype) = @_;

    # this function finds vdisks of the specified raid type. Only the first 
    # raid is checked against the type.
    
    my %rsp;
    my %info;
    my $i;
    my $added = 0;

#print ("LocateRaidXVdisks: input is $ctlr, $vddPtr, $count, $rtype \n");

    # get a list of vdisks
    %rsp = $ctlr->virtualDisks();

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks <<<<<<<<");
        return ERROR;
    }

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            if ($rsp{COUNT} > 0)
            {
#                $msg = "\nVdisk Status\n Vdisk: ";
#                
#                # first line is the vdisk number
#                for ($i = 0; $i < $rsp{COUNT}; $i++)
#                {
#                    $msg .= sprintf( " %3hu  ", $rsp{VDISKS}[$i]{VID});
#                }
#
#                $msg .="\nStatus: ";
#
#                # second line is its status
#                for ($i = 0; $i < $rsp{COUNT}; $i++)
#                {
#                    $msg .= sprintf( "0x%02x  ", $rsp{VDISKS}[$i]{DEVSTAT});
#                }
#
#                $msg .= "\n";
#
#                logInfo ($msg);
                
            }
            else
            {
                logInfo("No virtual disks present");
                return ERROR;
            }
        }
        else
        {
            logInfo(">>>>>>>> Unable to retrieve  virtual disk information. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }


    # for each vdisk
    for ( $i = 0; $i < $rsp{COUNT}; $i++ )
    {
        # get raidinfo

        %info = $ctlr->virtualDiskRaidInfo($rsp{VDISKS}[$i]{RIDS}[0]);

        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskRaidInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskRaidInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        # check against its raid type
        
        # print ("Checking VID $rsp{VDISKS}[$i]{VID}, RAID $rsp{VDISKS}[$i]{RIDS}[0]. Type is $info{TYPE}. \n");

        if ( $info{TYPE} == $rtype )
        {
            # if match, add to list
            # logInfo("Adding vdisk $rsp{VDISKS}[$i]{VID} to the list.");
            push( @$vddPtr, $rsp{VDISKS}[$i]{VID} );
            $added++;
        }
        
        # check count, quit if done.
        if ( $added >= $count )
        {
            return GOOD;
        }
    }

    # if we got here, there were no matching raids, return indicating error

    logInfo("Insufficient vdisks found with TYPE = $rtype.");

    return INVALID;
}

##############################################################################
##############################################################################
sub  FindUnusedVdds
{
    my ( $ctlr, $uVdds, $count ) = @_;

    # identify $count vdd numbers that are not currently in use
    
    my %info;
    my $i;
    my $found = 0;
    
    
    # get a list of vdisks
    %info= $ctlr->virtualDiskList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskList <<<<<<<<");
        return ERROR;
    }

    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
    

    # until the list is full
    for ( $i = 0; $i < 512; $i++ )
    {

        # pick a number
        # see if it is already used
        if ( 0 == IsInList($i, $info{LIST}) )
        {

            # if not
            # add to out list
            push ( @$uVdds, $i );

            # up the count
            $found++;

            # see if we are done
            if ( $found >= $count )
            {
                return GOOD;
            }
        }
    }

    return INVALID;      # didn't meet the request
}


###############################################################################

=head2 CreateSimilarVdisk function

This function builds a new vdisk that is the same size as the supplied 
vdisk. The raid trype, mirror depth and parity of the new disk are 
provided by the caller.

=cut

=over 1

=item Usage:

 my $rc = CreateReplacementVdisk( $ctlr, $oldVdisk, $raid, $parity, $mirror  );
 
 where: $ctlr is a controller object
        $oldVdisks is the vdisk to clone
        $raid is the raid type of the new vdisk
        $parity for the new vdisk
        $mirror for the new vdisk

=item Returns:

       $rc will be GOOD or ERROR 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut



##############################################################################
#
#          Name: CreateSimilarVdisk
#
#        Inputs: controller object pointer and other data
#
#       Outputs: new vdisk number or INVALID
#
#  Globals Used: none
#
#
##############################################################################
sub CreateSimilarVdisk
{
    my ($ctlr, $oldVdisk, $newRaid, $newParity, $newMirror ) = @_;
    my $newVdisk;
    my $numPDDs;
    my @pdd;       
    my $capacity;
    my $ret; 
    my $remaining;   
    my $cacheEnabled = FALSE;
    my %rsp;

    logInfo("      Creating the 'similar replacement' vdisk for vdd $oldVdisk");

    $newVdisk = 0;
    
    
    ###########################################
    # get info for current vdisk
    #    vdiskinfo gives the capacity needed
    ###########################################

    %rsp = $ctlr->virtualDiskInfo($oldVdisk);

    if ( ! %rsp )
    {
        logInfo(">>>>> Failed to get vdisk status for vdisk $oldVdisk <<<<<");
        return (INVALID);          # 
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Error getting vdisk status for vdisk $oldVdisk <<<<<");
        PrintError(%rsp);
        return (INVALID);          # 
    }

    #
    # Check if cache is enabled on this virtual disk and if it is set the
    # cache enabled flag to signal we need to enable cache on the new
    # virtual disk.
    #
    if (($rsp{ATTR} & 0x100) > 0)
    {
        $cacheEnabled = TRUE;
    }

    $capacity = $rsp{CAPACITY}/2048;    # size of new disk

    #
    # now determine the vdisks to use, we need to get the right type
    # and number of disks to staisfy the requirements
    #

    if ( ($newRaid == RAID_10) || ($newRaid == RAID_5) )
    {
        # raid 5 and 10 use data disks
        @pdd = GetTheseDisks($ctlr, CCBEDATATYPE);
    }
    else
    {
        # others get unsafe
        @pdd = GetTheseDisks($ctlr, CCBEUNSAFETYPE);
    }

    # check to see if we got a good list
    if ( $pdd[0] == INVALID )
    {
        logInfo("Unable to get pdisks to meet the test requirements");
        logInfo("Looking for drives to make a raid type $newRaid vdisk.");
        return INVALID;
    }


    # rules for the vdisk we will create
    # raid 0: Two or more unsafe pdisks
    # raid 1: depth = # pdisks >= 2
    # raid 5: parity <= # pdisks
    # raid 10: mirror < # pdisks

    # check to see if we have enough pdisks
    
    $numPDDs = scalar(@pdd);

    if ( ( ($newRaid == RAID_0 ) && ($numPDDs < 2) ) ||
         ( ($newRaid == RAID_1 ) && (($numPDDs < $newMirror ) || ($numPDDs < 2) )) ||
         ( ($newRaid == RAID_5 ) && ($numPDDs < $newParity) ) ||
         ( ($newRaid == RAID_10 ) && ($numPDDs < $newMirror) ))
    {
        # not the right number of disks
        logInfo("Not enough pdisks to build a RAID $newRaid, PARITY $newParity, MIRROR $newMirror vdisk.");        
        logInfo("    We have $numPDDs pdisks.");
        return INVALID;
    }

    # other checks may be needed...


    # enough disks, try to create the vdisk

    $newVdisk = CreateSingleVdisk($ctlr, "none", $capacity, $newRaid, 0, $newMirror, $newParity, \@pdd, undef);

    if ( $newVdisk == INVALID )
    {
        # failed to create the vdisk
        logInfo("Failed to create the vdisk.");
        return INVALID;
    }

    # now, init the drive

    $ret = InitVdiskRids($ctlr, $newVdisk);
    if ( $ret != GOOD )
    {
        # well, we couldn't start the inits, bail out
        return INVALID;
    }    

    logInfo("Pause to allow inits to start");

    DelaySecs(5);

    # now wait for the inits to complete (just starting isn't enough)
    if ( 0 != CheckInitProgress($ctlr, $newVdisk ) )
    {
        logInfo("Waiting for vdisk $newVdisk to become operational");

        while ( 0 != ( $remaining = CheckInitProgress($ctlr, $newVdisk ) ) )
        {
            print " $remaining percent left to initialize \r";
            # pause for a second or 2
            sleep 2;
        }
    }

    #
    # If cache is supposed to be enabled, send the request to enable it.
    #
    if ($cacheEnabled)
    {
        %rsp = $ctlr->virtualDiskSetCache($newVdisk, 0x1);

        if (!%rsp)
        {
            logInfo(">>>>> Failed to get response from virtualDiskSetCache <<<<<");
            return INVALID;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>> Error from virtualDiskSetCache <<<<<");
            PrintError(%rsp);
            return INVALID;
        }
    }

    return $newVdisk;

}

##############################################################################
sub ShortVdiskInfo
{
    trace();
    my ($ctlr, $vdd) = @_;
        
    my %ret;
    my %info;

    my $j;
    my $k;

    # Get vdiskInfo for the first part, plus the raids list
   
    %ret = $ctlr ->virtualDiskInfo($vdd);

    if ( ! %ret  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
        return ERROR;
    }

    if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
        PrintError(%ret);
        return ERROR;
    }
    
    my $totalRaids = $ret{RAIDCNT} + $ret{DRAIDCNT};

    my $str = "    Vdisk $ret{VID}: capacity: $ret{CAPACITY}, number of raids: $totalRaids\n";
    
    for ($j = 0; $j < $totalRaids; $j++)
    {

        # now get raidinfo to get the pdisks

        %info = $ctlr->virtualDiskRaidInfo($ret{RIDS}[$j]);
        if ( ! %info  )              # if no return from call
        {
            
            logInfo($str);
            logInfo(">>>>>>>> Failed to get response from virtualDiskRaidInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo($str);
            logInfo(">>>>>>>> Error from virtualDiskRaidInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
        
        $str .= "        Raid $info{RID}: type: $info{TYPE}, size: $info{CAPACITY}, pdisks used:";

        for ( $k = 0; $k < $info{PSDCNT}; $k++ )
        {
            $str .= " $info{PIDS}[$k]{PID}";
        }

        $str .= "\n";

    }
    
    $str .= "\n";

    logInfo($str);

    return GOOD;
}





##############################################################################
# Get Trace Info                                                          
##############################################################################
sub getTrace
{
    my($obj, $outfile) = @_;


    my %rsp = $obj->generic2Command("TRACE");

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {

            print "Writing trace data to $outfile ...\n";
            my $rc = open OF, ">$outfile";
            if (!$rc) {
                print "Couldn't open $outfile ...\n";
            }
            else {
                binmode OF;
                print OF $rsp{DATA};
                close OF;
            }
        }
    }

}


##############################################################################
# Function to find a vdisk on each controller. Uses Targetstatus to 
# get the first vdisk associated to each controller                                                         
##############################################################################


sub FindVdiskForEachController
{

    my ($coPtr, $vdPtr) = @_; 
    
    
    my $master;
    my $ret;
    my %rsp;
    my $i;
    my @vdisks;
    my $owner;

    # init destination array
    
    for ($i = 0; $i < scalar(@$coPtr); $i++ )
    {
        $$vdPtr[$i] = INVALID;
    }


    # find master
    
    $master = FindMaster($coPtr);
    if ( $master == INVALID ) { return ERROR; } 

    # get a list of vdisks

    @vdisks = GetVdiskList ($$coPtr[$master]);
    
    if ( $vdisks[0] == INVALID )
    {
        return ERROR;
    }
    
VDISKLOOP:  
    for ( $i = 0; $i < scalar(@vdisks); $i++ )
    {
        
        logInfo("Look to see if vdisk $vdisks[$i] is owned, and who owns it.");

        # get the owner
        %rsp = $$coPtr[$master]->virtualDiskOwner($vdisks[$i]);
        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskOwner <<<<<<<<");
            return ERROR;
        }
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to retrieve virtualDiskOwner. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        if ( $rsp{NDEVS} >= 1 )
        {
            # have an owned vdisk, see who owns it
            $owner = int ($rsp{OWNERS}[0]{TID} / 4);
            
            if ( $$vdPtr[$owner] == INVALID )
            {
                # this owner needs a vdisk
                $$vdPtr[$owner] = $vdisks[$i];
                next VDISKLOOP;
            }    
                
        }
     }


    # return
    return GOOD;
}

##############################################################################

=head2 SataBayLogSense

This test case runs a QLogic reset test across 1-N conrollers

=cut

=over 1

=item Usage:

 my $rc = SataBayLogSense($coPtr, $delay, $flag);
 
 where:  $coPtr     - ptr to a list of controller objects
         $delay     - seconds between sample loops
         $loops     - number of loops to do
         $flag      - 0 = single drive from bay
                      1 = use all drives in bay

=item Returns:

       $rc will be GOOD or ERROR. The sense data is in the logs.

=item Things to look for:
 
 The function will skip an entry if the sense command fails.

=item Initial Conditions:

 None

=back

=cut
######################################################################
sub SataBayLogSense
{
    my ($coPtr, $delay, $loops, $flag) = @_;
    
    # do DiskBays to get a list of sata bays
    # build list of sata bays
    # once every 5 minutes, 
        # for each sata bay
            # get the data
            # put in csv file
    # close file
    # exit

    my %info;
    my $i;
    my $ctlr;
    my $master;
    my @coList = @$coPtr;
    my @sataBays;
    my $again;
    my $ret;
    my $wwnHi;
    my $wwnLo;
    my $logBuffer;
    my $lun;
    my $cdb;
    my $msg;
    my %rsp;
    my $offset;
    my $item1;
    my $item2;
    my $item3;
    my $item4;            
    my $fmt;
    my @mList0;
    my @mList1;
    my $hBI; 
    my $lBI; 
    #my $result;
    
    my $j;    
    my $shelf;
    my $found;
    my $sample;
    
    my @sataList;
    
    
    my $timeDelay = 30;
    
    if (defined($delay) )
    {
        if ( $delay > 0 )
        {
            $timeDelay = $delay;
        }
    }
           
    my $onlyOne = 1;
    if (defined($flag) )
    {
        $onlyOne = $flag;
    }

    my $loopsToDo = 1000;
    if (defined($loops) )
    {
        $loopsToDo = $loops;
    }


    #
    # do pdisks to get a list os pdisks and then identify one
    # in each sata bay
    #
    
    $master = FindMaster($coPtr);                     # need the master
    $ctlr = $coList[$master];
    
    
    
    logInfo("Physical Disks Command");
    %info = $ctlr->physicalDisks();
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDisks <<<<<<<<");
        return ERROR;
    }
    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get physicalDisks info <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logPhysicalDisks("STD", %info);


    #
    # build list of sata bays (actually, find one pdisk per sata bay)
    #
    for ($i = 0; $i < $info{COUNT}; $i++)
    {

        #
        # for each sata drive, get its bay id
        #
        
        # sata is PD_DT_SATA                 
                
        if ( PD_DT_SATA == $info{PDISKS}[$i]{PD_DEVTYPE} )
        {
        
            #
            # have a sata drive, check list to see if we already have one for this shelf
            #
            $shelf = $info{PDISKS}[$i]{SES};
            
            $found = 0;
            for ($j = 0; $j < scalar(@sataBays); $j++ )
            {
                if ( $shelf == $info{PDISKS}[$sataBays[$j]]{SES} )
                {
                    #
                    # we already have this shelf, so mark it found
                    # and go on to the next drive
                    #
                    $found = 1;
                    last;
                }
            }   
                
            if ($found == 0)
            {
                #
                # this is a new shelf, add it to the list
                #
                push (@sataBays, $i);
                logInfo("Added pdisk $info{PDISKS}[$i]{PD_PID} to the SATA bay list.");
            }
            
        }            
                
    }

    if ( $onlyOne == 1 )
    {
        #
        # only doing a single drive per bay, copy the array
        #
        for ($i = 0; $i < scalar(@sataBays); $i++ )
        {
            push (@sataList, $sataBays[$i]);
        }
    }
    else
    {
        #
        # all drives in each bay, resacn the pdisks and sort by bays.
        #
        for ($i = 0; $i < scalar(@sataBays); $i++ )
        {
            for ($j = 0; $j < $info{COUNT}; $j++)
            {
                #
                # in same bay as reference?
                #
                if ($info{PDISKS}[$j]{SES} == $info{PDISKS}[$sataBays[$i]]{SES})
                {
                    #
                    # add the index to use to the list
                    #
                    push (@sataList, $j);
                }
            }
        }
    }

    #
    # once every 5 minutes,
    #
    $again = 1;
    $sample = 0;
    
    $msg  = "\nTimestamp, Sample, shelf, slot, port, ";
    $msg .= "Time Since Reset, Transmitted Frames, ";
    $msg .= "Received Frames, Transmitted Words, ";
    $msg .= "Received Words, LIP Count, ";
    $msg .= "NOS Count, Error Frames, ";
    $msg .= "Dumped Frames, Link Failure Count, ";
    $msg .= "Loss of Sync Count, Loff of Signal Count, ";
    $msg .= "Primitive Sequence Error Count, Invalid Transmitted Word Count, ";
    $msg .= "Invalid CRC Count, FCP Initiator IO Count, ";
    
    logInfo($msg);

    while ($loopsToDo > 0)
    { 
        
        $sample++;
        $loopsToDo--;
        #
        # for each sata bay
        #
        
        for ( $i = 0; $i < scalar(@sataList); $i++ )
        {
            #
            # get the data
            #
            $cdb = "4d003200000000010400";
            $wwnHi = $info{PDISKS}[$sataList[$i]]{WWN_HI};
            $wwnLo = $info{PDISKS}[$sataList[$i]]{WWN_LO};
            $lun = 0;
            
            
            #print "wwnhi = $wwnHi \n";
            #print "wwnlo = $wwnLo \n";
            #print "  cdb = $cdb \n";
            #print "  lun = $lun \n";
            #print " ctlr = $ctlr \n";
            $mList0[$i] = " ";
            $mList1[$i] = " ";
            
            
            ($ret, %rsp) = TestLibs::SCSI::SCSICommand($ctlr, $wwnHi, $wwnLo, $lun, $cdb, \$logBuffer, undef);
            
            if ($ret != GOOD)
            {
                logInfo("Error executing scsi command on pdisk $info{PDISKS}[$sataList[$i]]{PD_PID}");
                PrintError(%rsp);
                next;
            }
            
            
    
            # put in csv file
            $offset = 4;

            #
            # port 0 data
            #
            $msg = sprintf(", $sample, %2d, %2d, %2d, ",$info{PDISKS}[$sataList[$i]]{SES},
                       $info{PDISKS}[$sataList[$i]]{SLOT}, 0);      # line start, with bay/shelf number
            for ( $j = 0; $j < 16; $j++ )
            {
            
                $fmt = sprintf("x%d NN ",$offset);      # generate the format string
                ($item1, $item2 ) = unpack $fmt , $logBuffer;
                
                my $hBI = Math::BigInt->new($item1);
                my $lBI = Math::BigInt->new($item2);
                my $result = $lBI | ($hBI << 32 );
                
                #print "$offset : $item1, $item2, $hBI, $lBI, $result \n";
                 
                # $msg .= sprintf(" 0x%08x%08x,", $item1, $item2);       # 
                $msg .= sprintf(" %12lu, ", $result);       # 
                $offset += 8;       
            }
            
            $mList0[$i] = $msg;
            
            
            #
            # port 1 data
            #
            $msg = sprintf(", $sample, %2d, %2d, %2d, ",$info{PDISKS}[$sataList[$i]]{SES},
                       $info{PDISKS}[$sataList[$i]]{SLOT}, 1);      # line start, with bay/shelf number
            for ( $j = 0; $j < 16; $j++ )
            {
            
                $fmt = sprintf("x%d NN ",$offset);      # generate the format string
                ($item1, $item2 ) = unpack $fmt , $logBuffer;
                
                my $hBI = Math::BigInt->new($item1);
                my $lBI = Math::BigInt->new($item2);
                my $result = $lBI | ($hBI << 32 );
                
                #print "$offset : $item1, $item2, $hBI, $lBI, $result \n";
                 
                # $msg .= sprintf(" 0x%08x%08x,", $item1, $item2);       
               # $msg .= sprintf(" $result,");       # 
                $msg .= sprintf(" %12lu, ", $result);       # 
                $offset += 8;       
            }
            
            $mList1[$i] = $msg;
            
            
        }
        
        
        #
        # now post all the data
        #
        for ( $i = 0; $i < scalar(@sataList); $i++ )
        {        
            logInfo($mList0[$i]);
        }
        for ( $i = 0; $i < scalar(@sataList); $i++ )
        {        
            logInfo($mList1[$i]);
        }
                
        DelaySecs($timeDelay);        
    }
    
    
            
    # close file
    # exit

    
    
}
##############################################################################




##############################################################################





1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.6  2006/08/28 18:36:10  WilliamsJ
# TBolt00015574 - Changed call to DisplayError to reference the full path.
#
# Revision 1.5  2006/08/01 11:12:41  AnasuriG
# TBolt00015075
# Added changes for PDISKFAIL
#
# Revision 1.4  2006/06/30 10:25:57  AnasuriG
# TBolt00014557
# In startSingleDefrag routine removed ERROR return for success case
#
# Revision 1.3  2006/06/27 19:49:08  EidenN
# TBOLT00000000
# Modified StartSingleDefrag to support STOP all defrags and terminate ORPHANS.  Added StopDefrag and StopOrphanDefrag to support these features.
#
# Revision 1.2  2005/11/14 12:17:27  AnasuriG
# Updated while iSCSI changes, Added Absolute path
#
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
# Revision 1.95  2005/03/09 19:34:27  PalmiD
# TBolt00000000: Added MANUAL DRIVE PULL section from FailPdisk to FailPdiskNoWait.
# Reviewed by Craig Menning.
#
# Revision 1.94  2005/03/01 14:56:28  BalemarthyS
# TBolt00000000 - 20 secs delay in DefragWait for BE Fabric fix
#
# Revision 1.93  2005/02/21 20:43:42  MenningC
# tbolt00000000: wait 10 sec before checking for copy complete. Reviewed by Neal.
#
# Revision 1.92  2005/02/21 19:24:05  KohlmeyerA
# tbolt00000000:  Removed null character.  Reviewed by Craig.
#
# Revision 1.91  2005/01/28 20:05:56  PalmiD
# TBolt00000000: Added Inactivated state to UnfailAll.
# Reviewed by Craig Menning.
#
# Revision 1.90  2005/01/12 20:16:03  MenningC
# tbolt0012094: Fix deleting vdisks in defrag 9; reviewed by Al
#
# Revision 1.89  2005/01/04 17:24:12  KohlmeyerA
# Tbolt00000000:  Added some additional error logging to DefragWait.
# Reviewed by Craig.
#
# Revision 1.88  2004/12/08 16:35:34  KohlmeyerA
# Tbolt00000000:  Updated for RediCopyTest to handle full WWNs and work without using the
# move vdisks command that is no supported.
# Reviewed by Craig.
#
# Revision 1.87  2004/12/07 21:54:27  MenningC
# tbolt00000000: Fix defragWait() reviewed by Al
#
# Revision 1.86  2004/11/22 19:42:45  NigburC
# TBolt00011442 - Added code to setup the similar and replacement virtual
# disks such that they have the same write caching attribute as the originals.
# Reviewed by Craig Menning.
#
# Revision 1.85  2004/11/17 21:26:36  KohlmeyerA
# Tbolt00000000:  Added config options 55.  Reviewed by Craig.
#
# Revision 1.84  2004/11/16 16:04:10  MenningC
# TBOLT00000000:gone again, Reviewed by Al
#
# Revision 1.83  2004/11/16 15:59:18  MenningC
# TBOLT00000000:Add back mirror check Reviewed by Al
#
# Revision 1.82  2004/11/10 19:07:33  MenningC
# tbolt00011693: fix to avoid 'not enough vdisks'  message, reviewed by Al
#
# Revision 1.81  2004/11/04 16:40:51  KohlmeyerA
# Tbolt00000000:  Modified unfailpdisk to ignore rebuild bits in misc stat when checking
# disk status.  Also modified failpdisk to check for error after waiting for rebuild to
# start.  Reviewed by Craig.
#
# Revision 1.80  2004/11/03 23:01:12  MenningC
# tbolt00000000; backed out previous change
#
# Revision 1.79  2004/11/03 17:32:56  MenningC
# tbolt00000000: exclude mirror destinations when excluding vlinks. reviewed by Neal
#
# Revision 1.78  2004/10/22 18:01:00  EidenN
# Tbolt0000:  Added IsVdiskMirrorDest for mirror checking in the defrag test.  Reviewed by Menning
#
# Revision 1.77  2004/10/20 16:59:20  KohlmeyerA
# Tbolt00000000: Added log of status to unfailpdisk if other status is detected.
# Reveiwed by Craig.
#
# Revision 1.76  2004/10/20 16:56:09  EidenN
# Tbolt0000:  Added MIRROR checking to deleteUnusedVdisks function.  Allen K,  Reviewed
#
# Revision 1.75  2004/10/20 16:36:38  EidenN
# Tbolt0000:  Added MIRROR checking to deleteUnusedVdisks function.  Allen K,  Reviewed
#
# Revision 1.74  2004/10/20 15:55:27  EidenN
# Tbolt0000:  Added MIRROR checking to deleteUnusedVdisks function.  Allen K,  Reviewed
#
# Revision 1.73  2004/09/09 13:35:20  MenningC
# tbolt00000000:fix looping in defrag remain to loop thru all drives rather than sit on one. reviewed by Al
#
# Revision 1.72  2004/08/31 21:13:19  MenningC
# Tbolt00000000: Add raid 5 defrag enabled flag for wookiee; reviewed by Al
#
# Revision 1.71  2004/08/30 19:33:31  KohlmeyerA
# Tbolt00000000:  Added active defrag error code check to StartSingleDefrag.
# Reviewed by Craig.
#
# Revision 1.70  2004/08/18 21:51:19  MenningC
# tbolt00000000:fix typos; reviewed by Al
#
# Revision 1.69  2004/08/18 15:22:03  MenningC
# tbolt00000000:continued defrag updates; reviewed by Al
#
# Revision 1.68  2004/08/09 20:06:50  MenningC
# tbolt00000000: improve robustness when unbypassing a pdisk, reviewed by Chris
#
# Revision 1.67  2004/08/04 15:29:48  MenningC
# tbolt00000000: updates to allow unbypass in fabric, reviewed by Al
#
# Revision 1.66  2004/07/30 20:50:42  KohlmeyerA
# Tbolt00000000:  Modified DefragWait to accept array of pdisks to check as
# an optional parameter.  Reviewed by Craig.
#
# Revision 1.65  2004/07/28 15:04:35  MenningC
# tbolt00000000: updates to support SATA and adrdress 4 way issues, reviewed by Al
#
# Revision 1.64  2004/07/16 20:34:41  KohlmeyerA
# Tbolt00000000:  Added some additional error logging to unfailpdisk.
# Reviewed by Craig.
#
# Revision 1.63  2004/06/30 19:42:40  MenningC
# tbolt00000000: added sata log sense function for Jeff W.
#
# Revision 1.62  2004/06/22 21:33:11  KohlmeyerA
# Tbolt00000000:  Fixed problem with unfail serial number search loop in unfailall.
# Reviewed by Craig.
#
# Revision 1.61  2004/05/26 15:55:39  KohlmeyerA
# Tbolt00000000:  Added flag and modified DefragRemain and CheckSosTables
# to handle Raid 5 no longer being defragmented.  Also did some cleanup of multiple defragwait and defragremain functions.
# Reviewed by Craig
#
# Revision 1.60  2004/05/24 13:55:21  MenningC
# tbolt00000000: Detect errors failing items in failover nway, ignore R10 miscompare in parity scan, updates to logged info, detect inop raids in failover. . reviewed by Al
#
# Revision 1.59  2004/05/20 19:25:14  MenningC
# tbolt00000000: Added reporting of error counts while waiting on parity scans. reviewed by Al
#
# Revision 1.58  2004/05/10 21:26:34  MenningC
# tbolt00000000: Fix for rebuilds turning parity scan to single pass
# (just set it back to continuous); reviewed by Al
#
# Revision 1.57  2004/04/15 18:49:34  KohlmeyerA
# Tbolt00000000 - Added additional parm to GetDataDisks calls due to changes for SATA.  Reviewed by Craig
#
# Revision 1.56  2004/04/09 19:09:58  KohlmeyerA
# Tbolt00000000 - Added a FailPdiskNoWait function.  Reviewed by Craig
#
# Revision 1.55  2004/03/22 21:34:05  MenningC
# tbolt00000000: Fixes to BE41. Reviewed by Jim
#
# Revision 1.54  2004/03/19 22:32:17  MenningC
# tbolt00000000: Check the appropriate bits to determine that a rebuild has started when failing a pdisk. Also enhance the prints when checking raid state. Reviewed by Al.
#
# Revision 1.53  2004/02/18 20:28:54  MenningC
# tbolt00000000:Fix defrag 5, timing on be14, etc., reviewed by Al
#
# Revision 1.52  2003/11/12 19:17:02  MenningC
# tbolt00000000: Scrub fixes and some additional debug code. Reviewed by Olga
#
# Revision 1.51  2003/10/29 15:03:18  MenningC
# tbolt00000000: updates for TAS=LAS=0 bug, move rebuild check in unfailpdisk. Reviewed by Olga
#
# Revision 1.50  2003/10/22 13:57:04  MenningC
# tbolt00000000: fupdates to support Raid 5 testing and removing the checks on the SOS tables for slaves; reviewed by Olga
#
# Revision 1.49  2003/10/13 15:02:53  MenningC
# tbolt00000000: change parity pass count form 2 to 1; reviewed by Eric
#
# Revision 1.48  2003/10/08 14:21:37  WerningJ
# Tbolt00000000: changes to support defrag all, reveiwed by Eric
#
# Revision 1.47  2003/09/30 20:51:04  MenningC
# tbolt00000000: Fix for empty vdisk list and initial fixes for one defrag at a time. Reviewed by Eric.
#
# Revision 1.46  2003/09/16 15:12:03  MenningC
# tbolt00000000: additional parity scan work, update for pdisks that automatically unhotspare themselves. Reviewed by Eric
#
# Revision 1.45  2003/09/10 13:26:53  MenningC
# tbolt00000000: fix ictest menu, undace configs for n-way, improve 1 way support. reviewed by Olga
#
# Revision 1.44  2003/09/08 18:40:27  MenningC
# tbolt00000000: rewrite FIndPDID. reviewed by Olga
#
# Revision 1.43  2003/08/29 18:45:11  MenningC
# tbolt00000000: numerous changes to vdisk creation to ensure the correct raid parameters are used. reviewed by Olga
#
# Revision 1.42  2003/08/27 13:02:20  MenningC
# tbolt00000000: updates to handle geo raid, n=1 and recent vdiskcreate changes  reviewed by Olgs
#
# Revision 1.41  2003/08/20 15:17:53  MenningC
# tbolt00000000: check in current state of parity scan tests, adds parity scan to most BE stress tests, reviewed by Olgs
#
# Revision 1.40  2003/08/13 18:27:13  MenningC
# tbolt00000000: more parity tests, support for servermates(dual path). reviewed by Eric
#
# Revision 1.39  2003/08/12 13:53:51  MenningC
# TBOLT00000000: check in test cases for TIm's testing; reviewed by  Eric
#
# Revision 1.38  2003/08/11 14:51:35  MenningC
# TBOLT00000000: check in test cases for TIm's testing; reviewed by Tim
#
# Revision 1.37  2003/08/05 13:50:25  MenningC
# tbolt00000000: removed vlinks from random vdisk selection. Tested and reviewed by Olga
#
# Revision 1.36  2003/07/25 18:39:35  MenningC
# tbolt00000000: support for the parity scan tests; reviewed by Eric
#
# Revision 1.35  2003/07/23 14:04:16  MenningC
# tbolt00000000: added support for an additional loop parameter, add initial parityscan support to failover; reviewed by Olga
#
# Revision 1.34  2003/07/18 15:26:03  MenningC
# tbolt00000000: moved wait4ses call when unbypassing a drive. reviewed by Eric
#
# Revision 1.33  2003/07/17 19:52:22  MenningC
# Tbolt00000000: add support for raid 5 testing, reviewed by Olga
#
# Revision 1.32  2003/07/08 15:23:17  GrigorenkoO
# Tbolt00000000 Created new funciton FindPdId
#
# Revision 1.31  2003/07/01 14:32:12  MenningC
# TBOLT00000000: Additional fixes for pdisklabels and removed a server assoc test from the regression suite. reviewed by Olga
#
# Revision 1.30  2003/06/26 18:04:28  MenningC
# TBOLT00000000: Changes to support unchanging drive labels during hotspare in R2 and R3; reviewed by Olga
#
# Revision 1.29  2003/06/24 15:53:38  MenningC
# TBOLT00000000: Changes to support scrub testing; reviewed by Olga
#
# Revision 1.28  2003/06/12 19:02:12  MenningC
# TBOLT00000000: fixes for ses and slot for pdisk bypassing. reviewed by Eric
#
# Revision 1.27  2003/06/06 21:05:07  MenningC
# TBOLT00000000: fixes for ses and slot for pdisk bypassing.
#
# Revision 1.26  2003/05/28 14:54:20  MenningC
# TBOLT00000000: Changes to support bypassing of drives, patch for servermates, fix a defrag case timing.; reviewed by JW
#
# Revision 1.25  2003/05/14 20:18:46  MenningC
# TBOLT00000000: removed another S from CLEARLOG constant; reviewed by JW
#
# Revision 1.24  2003/05/14 18:53:31  MenningC
# TBOLT00000000: changes for debugging defrag case 11; reviewed by JW
#
# Revision 1.23  2003/05/12 16:52:35  MenningC
# Tbolt00000000:support for decofing of new FIDs. reviewed by Jeff W
#
# Revision 1.22  2003/05/09 13:05:12  MenningC
# Tbolt00000000: fix SCRUB_PC_CLEARLOGS_MASK
#
# Revision 1.21  2003/05/06 20:19:55  MenningC
# TBOLT00000000: JT changed a constant - he owes us pastries!
#
# Revision 1.20  2003/04/30 19:13:16  MenningC
# tbolt00000000: changes to support debug of a miscompare problem. Reviewed by Olga
#
# Revision 1.19  2003/04/21 15:13:41  MenningC
# tbolt00000000: fix timeout in rmstate, fix bestress case22, fix defrag case 23; reviewed by JW
#
# Revision 1.18  2003/04/15 19:11:46  MenningC
# tbolt00000000: broke failover into two parts, fixed links; reviewed by JW
#
# Revision 1.17  2003/04/15 14:52:41  WerningJ
# Increase time delay to 200 secs in unfail
# Reviewed by Craig m
#
# Revision 1.16  2003/04/14 14:31:48  MenningC
# tbolt00000000: adde PSDCheck; reviewed by JW
#
# Revision 1.15  2003/04/08 18:45:19  MenningC
# tbolt00000000: major changes to unfailpdd ; reviewed by JW
#
# Revision 1.14  2003/04/03 15:41:52  MenningC
# TBOLT00000000: look for bad las/tas; reviewed by JW
#
# Revision 1.13  2003/03/26 21:25:59  WerningJ
# Removed calls to unused modules
# Cleaned Up Constants
# Moved SetScrub to BEUtils from scrub.pm
# Reviewed by Craig M
#
# Revision 1.12  2003/03/03 23:03:29  MenningC
# tbolt00000000 fix for BEStress and new failover test case for Neal, reviewed by JW
#
# Revision 1.11  2003/02/25 21:56:00  MenningC
# tbolt00000000 updates for BEStress tests, reviewed by JW
#
# Revision 1.10  2003/02/24 22:20:38  GrigorenkoO
# Tbolt00000000 Added functions PdiskBypass, PdiskIdBypass, PdiskIdUnbypass
#
# Revision 1.9  2003/02/19 22:14:36  MenningC
# Tbolt00000000 fixes for m970, driven by previous wipe_clean changes, reviewed by Chris
#
# Revision 1.8  2003/02/07 17:24:33  MenningC
# Tbolt00000000: updates for SES changes. reveiwed by Jeff Werning.
#
# Revision 1.7  2003/01/29 17:17:07  MenningC
# Tbolt00000000: more debug of the BEstress tests, reviewed by J Werning
#
# Revision 1.6  2003/01/24 16:30:20  MenningC
# Tbolt00000000:fix ccbet failover. reviewed by Jeff Werning.
#
# Revision 1.5  2003/01/21 19:49:14  MenningC
# Tbolt00000000: more debug of the BEstress tests, reviewed by J Werning
#
# Revision 1.4  2003/01/17 16:36:26  MenningC
# Tbolt00000000: Additional updates to BEStress. Reviewed by Jeff Werning.
#
# Revision 1.3  2003/01/15 15:58:07  MenningC
# Tbolt00000000: additional new code, reviewed by Olga
#
# Revision 1.2  2003/01/14 16:20:47  WerningJ
# Allowed for undef objs in UnfailAll
# Reviewed by Craig M
#
# Revision 1.1  2003/01/14 15:27:56  MenningC
# Tbolt00000000: new file. Reveiewed by J Werning.
#
#
#
##############################################################################
