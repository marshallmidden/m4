#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library
#
#   Desc : A set of library functions for integration testing. 
#
#   Original Author:  Gopinadh Anasuri
#
#   Last modified by  $Author: ElvesterN $
#   
#   Modified date     $Date: 2006-05-25 11:52:07 -0500 (Thu, 25 May 2006) $
#   
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2005-2006 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::GeoRaid - Perl Tests to test Georaid feature

$Id: GeoRaid.pm 9788 2006-05-25 16:52:07Z ElvesterN $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing and setting Georaid.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones
               
               GetGeoLocation
               ConfigGeoLocation
               GeoRaidTestEntry
               GeoRaidCase1 
               GeoRaidCase2 
               GeoRaidCase3 
               MakeGeoVdisks 
               GeoVdiskMenu
               GeoConfig
               GeoLocationConfig
        The less significant ones
               
               None   

=cut

#
# - what I am
#

package TestLibs::GeoRaid;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use XIOTech::cmVDisk;

use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::Validate;
use TestLibs::BEUtils;

use strict;
use POSIX;

# Constants used

use constant GL_ID1       =>  111;
use constant GL_ID2       =>  222;
use constant INVALID_SES  =>  65535;

#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.4;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 9788 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker


    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &GetGeoLocation
                        &ConfigGeoLocation
                        &GeoRaidTestEntry
                        &GeoRaidCase1 
                        &GeoRaidCase2 
                        &GeoRaidCase3 
                        &MakeGeoVdisks
                        &GeoVdiskMenu
                        &GeoConfig
                        &GeoLocationConfig
                        
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 9788 $);
}
    our @EXPORT_OK;

##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $objPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.


 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.


=back

=cut


###############################################################################
###############################################################################

=head2 GetGeoLocation function

This subroutine gets the Geolocation set on available diskbays.

=cut

=over 1

=item Usage:

 my $rc = GetGeoLocation( $ctlr );
 
 where: $ctlr is a controller

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controllers should be configured.
 
=back

=cut
##############################################################################
#
#          Name: GetGeoLocation
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine gets the geolocation of available diskbays
#
##############################################################################
sub GetGeoLocation
{
    trace();

    my ( $ctlr ) = @_;

    my $master;
    my $msg;
    my %rsp;
    my @coList;

    %rsp = $ctlr->geoLocationStatus();

    if (%rsp)
    {
        if ($rsp{STATUS} != PI_GOOD)
        {
            my $msg = "Unable retrieve Geo Location Status.";
            displayError($msg, %rsp);
        }
    }
    else
    {
        print "ERROR: Did not receive a response packet.\n";
        logout();
    }

    print "\n";

    return GOOD;
}

###############################################################################
###############################################################################

=head2 ConfigGeoLocation function

This subroutine sets the Geolocation on a diskbay.

=cut

=over 1

=item Usage:

 my $rc = ConfigGeoLocation( $ctlr, $bayId, $locationId );
 
 where: $ctlr is a controller
        $bayId  is Id of diskbay 
        $locationId is geolocation Id of a diskbay 

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controller should be configured.
 
=back

=cut
##############################################################################
#
#          Name: ConfigGeoLocation
#
#        Inputs: controller, bayID, locationId
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine sets the geolocation for a specified diskbay
#
##############################################################################
sub ConfigGeoLocation
{
    trace();

    my ( $ctlr, $bayId, $locationId ) = @_;

    my $master;
    my $msg;
    my %rsp;
    my @coList;

    if ((!defined($bayId)) && (!defined($locationId))) 
    {
        print "Missing Bay ID and location Identity.\n";
        return;
    }

    if (!defined($bayId))
    {
        print "Missing Bay ID.\n";
        return;
    }

    if (!defined($locationId))
    {
        print "Missing location Identity.\n";
        return;
    }

    %rsp = $ctlr->setBayGeoLocation($bayId, $locationId);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            print "Successfully set the Geo location of the Bay ($bayId).\n";
        }
        else
        {
            print "Unable to set the Geo location of the Bay ($bayId).\n";
            print "No provision of hotspare matching location code.\n";
        }
    }
    else
    {
        print "ERROR: Did not receive a response packet.\n";
        logout();
    }

    print "\n";
 
    return GOOD;
}

###############################################################################
###############################################################################

=head2 GeoRaidTestEntry function

A function used for debugging the code as a generic entry. The final 
parameter represents the test case to be run. There is no guarantee that 
the tests can actually run sequentially and give full coverage.


=cut

=over 1

=item Usage:

 my $rc = GeoRaidTestEntry($coPtr, $snPtr, $moxaIP, $moxaChan, $ipPtr, $wwnPtr, $case );
 
 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is the IP address of the Moxa controller
        $moxaChan is the channel to control
        $ipPtr is pointer to ipaddress of controller
        $wwnPtr is a pointer to a list WWNs
        $case is the test case to run

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the 
           expected state is found.


=back

=cut


##############################################################################
#
#          Name: GeoRaidTestEntry
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
##############################################################################
sub GeoRaidTestEntry
{
    trace();
    my ( $coPtr,  $snPtr, $moxaIP, $moxaChan, $ipPtr, $wwnPtr, $case ) = @_;

    my $ret;
    $ret = GOOD;

    my @coList = @$coPtr;

    TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "                starting Georaid Case $case. ");
    TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");


        if ( $case == 1   || $case == 99 ) { $ret = GeoRaidCase1( $coPtr, GOOD, $snPtr, $moxaIP, $moxaChan, $ipPtr, $wwnPtr); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case == 2   || $case == 99 ) { $ret = GeoRaidCase2( $coPtr, GOOD, $snPtr, $moxaIP, $moxaChan, $ipPtr, $wwnPtr); }
        if ( $ret != GOOD ) { return $ret; }
        
        if ( $case == 3   || $case == 99 ) { $ret = GeoRaidCase3( $coPtr, GOOD, $snPtr, $moxaIP, $moxaChan, $ipPtr, $wwnPtr); }
        if ( $ret != GOOD ) { return $ret; }
        
    PeriodicDataGather($coPtr);

    TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "                 Georaid test case $case ends. ");
    TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    
    return $ret;
}

###############################################################################
###############################################################################

=head2 GeoRaidCase1 function

This test case checks the basic georaid functionality.

Test Steps...

     1) Collect system Information
     2) Power down drive bay
     3) Verify I/O
     4) Power up drive bay
     5) Verify I/O.

=cut

=over 1

=item Usage:

 my $rc = GeoRaidCase1 ( $objPtr, $retIn, $snPtr, $MoxaIP, $Chan, $ipPtr );
 
 where: $objPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr  is a pointer to a list of controller serial numbers
        $MoxaIP is array of Moxa Ip address
        $Chan is array of Channel to power cycle
        $ipPtr is a pointer to ip addresses

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 System needs to be configured and pdisks labelled, make sure there is a 
 hotspare in each drivebay. 

*NOTE 
 
 This test needs to be called for two different georaid vdisk configurations.

 Configuration 1 :-
 ------------------
 
 Configure source vdisks on geolocation and destination (Mirror) vdisks
 on a different geolocation.
 
 
 User needs to use following options from XTC to create this configuration.
  
 To create source vdisks use following options..... 
 
 ictest(8)->Single Task Menu(51)-> Georaid Vdisk Menu(39)-> option (1)
 
 Associate source vdisks to servers and start I/O.
 
 To create destination (Mirror) vdisks use following options..... 
 
 ictest(8)->Single Task Menu(51)-> Georaid Vdisk Menu(39)-> option (3) -> option (1)
 

 Configuration 2 :-
 ------------------
 
 Configure source vdisks on multiple geolocations and similarly their destination 
 (Mirror) vdisks on multiple geolocations, Source and destination will be in 
 different geolocations always.
 
 User needs to use following options from XTC to create this configuration.
  
 To create source vdisks use following options..... 
 
 ictest(8)->Single Task Menu(51)-> Georaid Vdisk Menu(39)-> option (3)
 
 Associate source vdisks to servers and start I/O.
 
 To create destination (Mirror) vdisks use following options..... 
 
 ictest(8)->Single Task Menu(51)-> Georaid Vdisk Menu(39)-> option (3)-> option(2)

 Moxa/APC related care
 ---------------------
 
 I use two variables to powercycle drivebay remotely thru moxa/apc, In config file
 make sure the moxa details are entered.
 
 If a moxa/apc is already present for controller then Index should be +1
 
 Array index for these Moxa[] and Chan[] should be modified based upon the config file 
 and channel connections.
 
 $MoxaIP[Index], $Chan[Index].
 
=back

=cut

##############################################################################
#
#          Name: GeoRaidCase1
#
#        Inputs: controller, wwn pointer
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
##############################################################################
sub GeoRaidCase1
{
    trace();

    my ( $objPtr, $retIn, $snPtr, $MoxaIP, $Chan, $ipPtr, $wwnPtr ) = @_;

    my $i = 0;
    my $j = 0;
    my $k = 0;
    my $r = 0;
    my $ret;
    my $cnt;
    my $master;
    my $ctlr;
    my $loopcount = 0;
    my $numCtlrs = 0;
    my $sidcnt1 = 0;
    my $sidcnt2 = 0;
    my @coList;
    my @serialNums;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @VDiskList;
    my @vpripairs;
    my $msg;
    my $msg0;
    my %rsp;
    my %rsp1;
    my %info;
    my @vdd;
    my $ExtraCheckRet;
    my $DebugMes = 0;
    my $MasterObj = 0;
    my $FunctionRet;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    @coList = @$objPtr;
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    $ctlr = $coList[$master];
    
    $msg = "----------------------- Test Case 1: Verifies Georaid functionality ------------------------";
    $msg0 = "-------------------------------------------------------------------------------------------";
    
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($objPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    DispPdiskInfo($ctlr);
    
    # get measure of the current IO

    $ret = VerifyIOGather($objPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
    
        #
        # Power Cycle drive bay via Moxa/APC
        #
        
        $DebugMes = "Georaid test case 1 drivebay : Power Off ";
    
        $FunctionRet = CtlrLogTextAll($objPtr, $DebugMes);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to send message to debug console <====");
            return ERROR;   
        }

        #
        # Send Power OFF command to the MOXA/APC
        #    
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[2], 0);
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[3], 0);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to power off drive bay <====");
            return ERROR;
        }

        #
        # delay 300 seconds for I/O to restore and auto swaps to complete
        #
        
        DelaySecs(300);
         
        logInfo("Verify IO with drivebay turned off");
        
        $ret = TestSystemState1( $objPtr,
                                 \@activeServers,
                                 0,
                                 \@initialVdisks,
                                 $snPtr
                               );
        if ( $ret != GOOD ) { return ERROR; }
        
        $DebugMes = "Georaid test case 1 drivebay : Power On ";
    
        #
        # Send Power On message to the controller logs
        #
        $FunctionRet = CtlrLogTextAll($objPtr, $DebugMes);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to send message to debug console <====");
            return ERROR;   
        }
                  
        #
        # Send Power ON command to the MOXA/APC
        #
    
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[2], 1);
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[3], 1);
        
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to power on drive bay <====");
            return ERROR;
        }
            
        logInfo("Drive bay has been power cycled");
    
        #
        # Check for Good SES data before procedding
        #
        my $check = TRUE;                                                       
        my $count = 0;

        logInfo("Waiting for drive bay to power up...");
    
        DelaySecs(45);

        logInfo(" ");
        logInfo("Waiting for SES to come on ready....");
        logInfo(" ");
    
        #
        # Find Master controller
        #
        
       $MasterObj = &TestLibs::IntegCCBELib::FindMaster($objPtr);

       if($MasterObj == INVALID)
       {
           logInfo("    ====> Test failed: unable to find master controller... <====");
           return ERROR;
       }
        
       $FunctionRet = Wait4Ses($coList[$MasterObj], 120);
    
       if($FunctionRet != GOOD)
       {
           logInfo("    ====> Timed out while waiting for SES to come ready <====");
           return ERROR;
       }  
        
       #
       # Start Check loop; Check for rebuilds to start and then monitor progress
       #
       
       while( $check == TRUE )
       {
        
           #
           # Allow drive bay to come on ready
           #
           logInfo("Waiting for rebuild to start...");
           DelaySecs(30);

           $FunctionRet = DegradeCheck($coList[$MasterObj]);
       
        
           if($FunctionRet == ERROR)
           {
               logInfo("    ====> ERROR: occured while checking physical disk status <====");
               return ERROR;
           }

           if($count < 10 )
           {
               if($FunctionRet == INVALID)
               {
                   logInfo("Rebuild started....");
                   $check = FALSE; 
               }
               elsif($FunctionRet == GOOD)
               {
                   logInfo("Rebuild Completed before function called (Increase number of Vdisks with I/O).");
                   $check = FALSE; 
               }

           }
           else
           {
               logInfo("    ====> Rebuild did not start after 5 min <====");
               return ERROR;
           }

           $count++;
       }
   
        #
        # Test for CCBTIMEOUT and re-login if needed
        #
        
        $FunctionRet = TestNReconnectAll(\@coList);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to reconnect to one or more of the controllers. <====");
            return ERROR;
        }
        
        #
        # delay 300 seconds for I/O to restore and swap backs to complete
        #
        
        DelaySecs(300);
        
        logInfo("Verify IO with drivebay turned on");
        
        $ret = TestSystemState1( $objPtr,
                                 \@activeServers,
                                 0,
                                 \@initialVdisks,
                                 $snPtr
                               );
        if ( $ret != GOOD ) { return ERROR; }
        
        # This section will search for the mirror of mirror vdisks which will be 
        # in user paused state and resumes copy on those vdisks
    
       	%info = $ctlr->resyncData(1);

        if (%info)
        {
            if ($info{STATUS} == PI_GOOD)
            { 
                for ($i = 0; $i < $info{COUNT}; $i++)
                {
                    if ($info{DTLCPY}[$i]{VMIRROR} == 3) # Check if the vdisk is in user pause state 
                    {
                        if ($info{DTLCPY}[$i]{VATTR} == 30) # make sure that the source vdisk is a mirror by it self 
                        {
                            %rsp1 = $ctlr->virtualDiskControl(0x07, $info{DTLCPY}[$i]{RCSDV}, $info{DTLCPY}[$i]{RCDDV});

                            if (!%rsp1)                        # no response
                            {
                                print "\n";
                                logInfo(">>>>> Failed to receive a response from virtualdiskcontrol while resuming copy <<<<<");
                                return ERROR;
                            }
                            elsif ($rsp1{STATUS}  != PI_GOOD)            # 1 is bad
                            {
                                logInfo("Resuming copy on mirror disk $info{DTLCPY}[$i]{RCDDV} has Failed. \n");
                                print "\n";
                                TestLibs::IntegCCBELib::PrintError(%rsp1);
                                return ERROR;
                            }
                            else
                            {
                                logInfo("Copy has been resumed on mirror vdisk $info{DTLCPY}[$i]{RCDDV}\n");
                                $ret = WaitForCpComplete($ctlr, $info{DTLCPY}[$i]{RCDDV});
                                if ( $ret != GOOD ) { return ERROR; }
                            }
                        }
                    	else 
                    	{
                        	print "\n";
                        	logWarning("Source vdisk is not a mirror");
                    	}

                    }
                }   
            } 
            else
            {
                my $msg = "Unable to retrieve the resync data.";
                displayError($msg, %info);
            }
        }  
        else
        {
            print "ERROR: Did not receive a response packet from function resyncData.\n";
            return ERROR;
        } 

        #
        # check the back end state, vdisk status, pdisk status, raid status
        #
        $ret = TestLibs::Validate::TestSystemState3($coList[$master], \%mirrorData);
        if ( ($ret == ERROR))
        {
            logInfo("    ====> Validations have failed <====");
            return ERROR;
        }
        
        logInfo("Verify IO at end of the test");
        $ret = VerifyIO( $objPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                      );
        if ( $ret != GOOD ) { return ERROR; }

    
        $ret = TestEndMirrorCheck($objPtr, $MRWTimeout, \%mirrorData );   
        if ( $ret != GOOD ) { return ERROR; }
    
    return GOOD;
}

###############################################################################
###############################################################################

=head2 GeoRaidCase02 function

Basic steps involved in this test are...

            1) Locate a master controller
            2) verify IO
            3) turn off a drive bay 
            4) verify IO
            5) for 'n' loops
                  turn off current master controller
                  wait 2 minute (timeline?)
                  verify IO
                  turn on powered down controller
                  wait 2 minutes (timeline?)
                  verify IO
                  reconnect and unfail
                  wait 2 minutes (timeline?)
                  verify IO
           6) turn on the powered down drive bay 
           7) verify IO.
=cut

=over 1

=item Usage:

 my $rc = GeoRaidCase02 ( $objPtr, $retIn, $snPtr, $MoxaIP, $Chan, $ipPtr, $wwnPtr );

 where: $objPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr  is a pointer to a list of controller serial numbers
        $MoxaIP is array of Moxa Ip address
        $Chan is array of Channel to power cycle
        $ipPtr is a pointer to ip addresses

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.

NOTE* This test is not to be to run for this release as controller failover with 
      geolocation failure is not supported. 

=back

=cut

##############################################################################
#
#          Name: GeoRaidCase2
#
#        Inputs: controller, wwn pointer
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
# Steps are 1) Locate a master controller
#           2) verify IO
#           3) turn off a drive bay 
#           4) verify IO
#           5) for 'n' loops
#                 turn off current master controller
#                 wait 2 minute (timeline?)
#                 verify IO
#                 turn on powered down controller
#                 wait 2 minutes (timeline?)
#                 verify IO
#                 reconnect and unfail
#                 wait 2 minutes (timeline?)
#                 verify IO
#           6) turn on the powered down drive bay 
##############################################################################
sub GeoRaidCase2
{
    trace();

    my ( $objPtr, $retIn, $snPtr, $MoxaIP, $Chan, $ipPtr, $wwnPtr ) = @_;

    my $i = 0;
    my $j = 0;
    my $k = 0;
    my $r = 0;
    my $Key = 0;
    my $ret;
    my $cnt;
    my $master;
    my $ctlr;
    my $loopCount = 4;
    my $numCtlrs = 0;
    my $sidcnt1 = 0;
    my $sidcnt2 = 0;
    my @coList;
    my @serialNums;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @VDiskList;
    my @vpripairs;
    my $msg;
    my $msg0;
    my %rsp;
    my %info;
    my @vdd;
    my $ExtraCheckRet;
    my $DebugMes = 0;
    my $MasterObj = 0;
    my $PrevMaster = 0;
    my $FunctionRet;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    @coList = @$objPtr;
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    $ctlr = $coList[$master];
    
    $msg = "------------------ Test Case 2: Fail drive bay and failover controller ---------------------";
    $msg0 = "-------------------------------------------------------------------------------------------";
    
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);
    
    # check the number of controllers
    if ( scalar(@$objPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($objPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    DispPdiskInfo($ctlr);
    
    # get measure of the current IO

    $ret = VerifyIOGather($objPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
    
        #
        # Power Cycle drive bay via Moxa/APC
        #
        
        $DebugMes = "Georaid test case 2 drivebay : Power Off ";
    
        $FunctionRet = CtlrLogTextAll($objPtr, $DebugMes);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to send message to debug console <====");
            return ERROR;   
        }

        #
        # Send Power OFF command to the MOXA/APC
        #    
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[2], 0);
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[3], 0);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to power off drive bay <====");
            return ERROR;
        }
         
        #
        # delay 300 seconds for I/O to restore and auto swaps to complete
        #
        
        DelaySecs(300);
         
        logInfo("Verify IO with drivebay turned off");
        
        $ret = TestSystemState1( $objPtr,
                                 \@activeServers,
                                 0,
                                 \@initialVdisks,
                                 $snPtr
                               );
        if ( $ret != GOOD ) { return ERROR; }


    ######################################################################
    # power cycles on the controller.
    ######################################################################

        for ( $i = 0; $i < $loopCount; $i++ )
        {
    
           #                 Locate a master controller
       
          $MasterObj = &TestLibs::IntegCCBELib::FindMaster($objPtr);

            if($MasterObj == INVALID)
            {
                logInfo("    ====> Test failed: unable to find master controller... <====");
                return ERROR;
            }
        
            #                 turn off the current master controller

            CtlrLogTextAll($objPtr, "Test Case 2: now turning off $$objPtr[$MasterObj]->{HOST}" );
            $ret = PowerChange($$MoxaIP[$MasterObj], $$Chan[$MasterObj], 0);
            if ( $ret != GOOD ) { return ERROR; }
    
            $MasterObj = &TestLibs::IntegCCBELib::FindMaster($objPtr);

            if($MasterObj == INVALID)
            {
                logInfo("    ====> Test failed: unable to find master controller... <====");
                return ERROR;
            }
        
            #                 failover timeline from current master

            $ret = FailOverTimeLine($MasterObj, 120, $snPtr, 0 );
            if ( $ret != GOOD ) { return ERROR; }


            #                 verify IO
            
            logInfo("Verify IO after failing the slave controller");
            $ret = TestSystemState1( $objPtr,
                                     \@activeServers,
                                     0,
                                     \@initialVdisks,
                                     $snPtr
                                   );
            if ( $ret != GOOD ) { return ERROR; }
       
            #                 find the failed controller 
       
            if ($MasterObj == 1)
            { 
                $PrevMaster = 0;
            }
            else 
            {
                $PrevMaster = 1;
            }

            #                 turn on failed controller controller
            CtlrLogText($$objPtr[$MasterObj], "Test Case 2: now turning on $$objPtr[$PrevMaster]->{HOST}" );
        
            $ret = PowerChange($$MoxaIP[$PrevMaster], $$Chan[$PrevMaster], 1);
            if ( $ret != GOOD ) { return ERROR; }

            #                 wait 2 minute (timeline?)
                $ret = FailOverTimeLine($MasterObj, 120, $snPtr, 0 );
            if ( $ret != GOOD ) { return ERROR; }

            #                 unfailing the failed controller
            CtlrLogText($$objPtr[$MasterObj], "Test Case 2: unfailing failed controller" );

            #                 reconnect and unfail
            $ret = UnfailAll($objPtr, $snPtr, $MoxaIP, $Chan );
            if ( $ret != GOOD ) { return ERROR; }
        
            #                 wait 2 minute (timeline?)
            $ret = FailOverTimeLine($MasterObj, 120, $snPtr, 0 );
            if ( $ret != GOOD ) { return ERROR; }
        
            #                 verify IO
            logInfo("Verify IO with slave turned on. Loop $i");
            $ret = TestSystemState1( $objPtr,
                                    \@activeServers,
                                    0,
                                    \@initialVdisks,
                                    $snPtr
                                   );
            if ( $ret != GOOD ) { return ERROR; }

        }


        $DebugMes = "Georaid test case 2 drivebay : Power On ";
    
        #
        # Send Power On message to the controller logs
        #
        $FunctionRet = CtlrLogTextAll($objPtr, $DebugMes);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to send message to debug console <====");
            return ERROR;   
        }
                  
        #
        # Send Power ON command to the MOXA/APC
        #
    
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[2], 1);
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[3], 1);
        
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to power on drive bay <====");
            return ERROR;
        }
            
        logInfo("Drive bay has been power cycled");
    
        #
        # Check for Good SES data before procedding
        #
        my $check = TRUE;                                                       
        my $count = 0;

        logInfo("Waiting for drive bay to power up...");
    
        DelaySecs(45);

        logInfo(" ");
        logInfo("Waiting for SES to come on ready....");
        logInfo(" ");
    
        #
        # Find Master controller
        #
        
       $MasterObj = &TestLibs::IntegCCBELib::FindMaster($objPtr);

       if($MasterObj == INVALID)
       {
           logInfo("    ====> Test failed: unable to find master controller... <====");
           return ERROR;
       }
        
        $FunctionRet = Wait4Ses($coList[$MasterObj], 120);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Timed out while waiting for SES to come ready <====");
            return ERROR;
        }  
        
        #
        # Start Check loop; Check for rebuilds to start and then monitor progress
        #
        while( $check == TRUE )
        {
        
            #
            # Allow drive bay to come on ready
            #
            logInfo("Waiting for rebuild to start...");
            DelaySecs(30);

            $FunctionRet = DegradeCheck($coList[$MasterObj]);
        
        
            if($FunctionRet == ERROR)
            {
                logInfo("    ====> ERROR: occured while checking physical disk status <====");
                return ERROR;
            }

            if($count < 10 )
            {
                if($FunctionRet == INVALID)
                {
                    logInfo("Rebuild started....");
                    $check = FALSE; 
                }
                elsif($FunctionRet == GOOD)
                {
                    logInfo("Rebuild Completed before function called (Increase number of Vdisks with I/O).");
                    $check = FALSE; 
                }

            }
            else
            {
                logInfo("    ====> Rebuild did not start after 5 min <====");
                return ERROR;
            }

            $count++;
        }
    
        #
        # Depending on the key wait for rebuild to finish
        #
        if($Key == TRUE)
        {
            $check = TRUE;
        
            while( $check == TRUE )
            {
        
                #
                # Allow time for drive to rebuild
                #
                logInfo("Waiting for rebuild to complete ");
            
                DelaySecs(90);

                $FunctionRet = WaitRebuild($coList[$MasterObj]);          
            
                if($FunctionRet == ERROR)
                {
                    logInfo("    ====> ERROR: occured while checking physical disk status <====");
                    return ERROR;
                }
            
                if($FunctionRet == GOOD)
                {
                    logInfo("Rebuild finished / Double Checking....");
                }
            
                DelaySecs(30);

                #
                # Let's double check that all rebuilds have completed
                #
                $ExtraCheckRet = WaitRebuild($coList[$MasterObj]);

                if($ExtraCheckRet == ERROR)
                {
                    logInfo("    ====> ERROR: occured while checking physical disk status <====");
                    return ERROR;
                }

            
                if($ExtraCheckRet == GOOD) 
                {
                    logInfo("Rebuilds finished....");
                    $check = FALSE;
                }
                else
                {
                    logInfo("Rebuilds have not yet completed.  Continue checking...");
                }
                                                              
            }
        }

        #
        # Test for CCBTIMEOUT and re-login if needed
        #
        $FunctionRet = TestNReconnectAll(\@coList);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to reconnect to one or more of the controllers. <====");
            return ERROR;
        }
        
        #
        # delay 300 seconds for I/O to restore and swap backs to complete
        #
        
        DelaySecs(300);
        
        #
        # check the back end state, vdisk status, pdisk status, raid status
        #
        $ret = TestLibs::Validate::TestSystemState3($coList[$master], \%mirrorData);
        if ( ($ret == ERROR))
        {
            logInfo("    ====> Validations have failed <====");
            return ERROR;
        }
        
        logInfo("Verify IO at end of the test, after restoring the pdisk");
        $ret = VerifyIO( $objPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                      );
        if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($objPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    return GOOD;
}
 
###############################################################################
###############################################################################

=head2 GeoRaidCase03 function

Basic steps involved in this test are...

            1) Locate a master controller
            2) verify IO
            3) turn off a drive bay 
            4) verify IO
            5) fail a pdisk on destination geolocation
            6) fail a pdisk on destination geolocation
            7) turn on the powered down drive bay 
            8) verify IO.

=cut

=over 1

=item Usage:

 my $rc = GeoRaidCase03 ( $objPtr, $retIn, $snPtr, $MoxaIP, $Chan, $ipPtr, $wwnPtr );

 where: $objPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr  is a pointer to a list of controller serial numbers
        $MoxaIP is array of Moxa Ip address
        $Chan is array of Channel to power cycle
        $ipPtr is a pointer to ip addresses

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.

=back

=cut

##############################################################################
#
#          Name: GeoRaidCase3
#
#        Inputs: controller, wwn pointer
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
# Steps are 1) Locate a master controller
#           2) verify IO
#           3) turn off a drive bay 
#           4) verify IO
#           5) for 'n' loops
#                 turn off current master controller
#                 wait 2 minute (timeline?)
#                 verify IO
#                 turn on powered down controller
#                 wait 2 minutes (timeline?)
#                 verify IO
#                 reconnect and unfail
#                 wait 2 minutes (timeline?)
#                 verify IO
#           6) turn on the powered down drive bay 
##############################################################################
sub GeoRaidCase3
{
    trace();

    my ( $objPtr, $retIn, $snPtr, $MoxaIP, $Chan, $ipPtr, $wwnPtr ) = @_;

    my $i = 0;
    my $j = 0;
    my $k = 0;
    my $r = 0;
    my $lc = 0;
    my $Key = 0;
    my $ret;
    my $cnt;
    my $master;
    my $ctlr;
    my $loopCount = 4;
    my $numCtlrs = 0;
    my $sidcnt1 = 0;
    my $sidcnt2 = 0;
    my @coList;
    my @serialNums;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @VDiskList;
    my @vpripairs;
    my $msg;
    my $msg0;
    my %rsp;
    my %rsp1;
    my %info;
    my @vdd;
    my @destPdds;
    my @destHpdds;
    my @pdds;
    my $ExtraCheckRet;
    my $DebugMes = 0;
    my $MasterObj = 0;
    my $PrevMaster = 0;
    my $FunctionRet;
    my $ourSN;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my $ses;
    my $slot;
    my $lid;
    my $port;
    my $failedDisk;

        # $retIn coming in is a flag to do the test or not
        if ($retIn != GOOD)
        {
            return $retIn;
        }
    
    
        @coList = @$objPtr;
    
        $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

        if ( $master == INVALID ) { return(ERROR); } 

        $ctlr = $coList[$master];
   
        $msg = "------------------- Test Case 3: Fail pdisk on destination geolocation  --------------------";
        $msg0 = "-------------------------------------------------------------------------------------------";
    
        logInfo($msg0);
        logInfo($msg);
        logInfo($msg0);
        
        # check the number of controllers
        
        if ( scalar(@$objPtr) < 2 )
        {
            logInfo("This test case requires multiple controllers. Test case is skipped.");
            return ($retIn);
        }
        
        #
        # Get our serial number
        #
        
        $ourSN = GetGroupSerial( $ctlr );
        
        if ( INVALID == $ourSN  )
        {
        logInfo(">>>>>>>> Failed to get controller's serial number <<<<<<<<");
        return ERROR;
        }
 
        #
        # Execute cleanup and data collection at start
        #
        
        $ret = TestPrep4MirrorCheck($objPtr, $master, $MRWTimeout, \%mirrorData);
        if ( $ret != GOOD ) { return ERROR; }

        DispPdiskInfo($ctlr);
    
        #get measure of the current IO

        $ret = VerifyIOGather($objPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
    
        #
        # Power Cycle drive bay via Moxa/APC
        #
        
        $DebugMes = "Georaid test case 3 drivebay : Power Off ";
    
        $FunctionRet = CtlrLogTextAll($objPtr, $DebugMes);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to send message to debug console <====");
            return ERROR;   
        }

        #
        # Send Power OFF command to the MOXA/APC
        #    
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[2], 0);
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[3], 0);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to power off drive bay <====");
            return ERROR;
        }

        #
        # delay 300 seconds for I/O to restore and auto swaps to complete
        #
        
        DelaySecs(300);
         
        logInfo("Verify IO with drivebay turned off");
        
        $ret = TestSystemState1( $objPtr,
                                 \@activeServers,
                                 0,
                                 \@initialVdisks,
                                 $snPtr
                               );
        if ( $ret != GOOD ) { return ERROR; }
         
        my %pdisks = $ctlr->physicalDisks();

        if ( ! %pdisks )     # no response from controller
        {
            logInfo(">>>>> Failed to get pdisk list (no response) <<<<<");
           return ERROR;
        }
        else                          # got a response
        {
            if ( $pdisks{STATUS} == PI_GOOD )
            {
                logInfo("disk list is good, now walking it");
            }
            else
            {
                # got an error, report it, bail
                logInfo(">>>>> Failed getting pdisk list <<<<<");
                PrintError(%pdisks);
                return ERROR;
            }
        }
        
        # loop through the available pdisks and if the pdisk has a valid SES
	    # then push it in to array of destination pdisks. check for valid SES 
        # is done as the source geolocation is down and all pdisk at source
        # will have invalid SES.
         
        for(my $i = 0; $i < $pdisks{COUNT}; ++$i)
        {
            # compare to our SN, if match we can use
            if ( $ourSN == $pdisks{PDISKS}[$i]{PD_SSERIAL} )
            {
                # add data drive which has a valid SES to array
                if ($pdisks{PDISKS}[$i]{SES} != INVALID_SES )
                {
                    if ($pdisks{PDISKS}[$i]{PD_CLASS} == CCBEDATATYPE)
                    {
                        push(@destPdds, $pdisks{PDISKS}[$i]{PD_PID});
                    }
                    
                    if ($pdisks{PDISKS}[$i]{PD_CLASS} == CCBEHOTSPARETYPE)
                    {
                        push(@destHpdds, $pdisks{PDISKS}[$i]{PD_PID});
                    }
                }
            }
        }     

        $failedDisk = $destPdds[1];
  
        CtlrLogTextAll($objPtr, "Test Case 3: now failing pdd $failedDisk" );
        
        #
        # Fail a pdisk from destination geolocation 
        #

    	GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);

        $ret = FailPdisk( $ctlr, $failedDisk, PDISKBYPASS );
        if ( $ret != GOOD ) { return ERROR; }
        
        # the disk is failed, now some rebuilds will soon begin

    	# verify IO is still good
    	logInfo("Verify IO with the failed PDD");
    	$ret = VerifyIO( $objPtr,
        	             \@activeServers,
            	         \@tMap,
                	     \@initialVdisks,
                    	 $snPtr
                   	   );
	    if ( $ret != GOOD ) { return ERROR; }
    
    	# wait for rebuild to end
    	# rebuild is done if no drives are 'degraded'
    	
    	logInfo("polling until rebuild finishes");
        $ret = INVALID;

        $lc = 0;
        
        while ( $ret != GOOD )
        {
            $lc++;
            logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

            $ret = GeoDegradeCheck( $ctlr );
            if ( $ret == ERROR )
            {
                return ERROR;
            }
            DelaySecs( 15 );
        }

        PSDCheck( $ctlr );

        # verify IO is still good
    	logInfo("Confirm IO after copy and rebuilds are done");
        $ret = VerifyIO( $objPtr,
                        \@activeServers,
                        \@tMap,
                        \@initialVdisks,
                        $snPtr
                       );
        
    	# unfail the drive
        $ret = UnfailGeoPdisk($ctlr, $failedDisk, \@destPdds, $ses, $slot, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        $ret = FixPdiskLabels ($ctlr, 0);
        if ( $ret != GOOD ) { return ERROR; }

        # verify IO
        logInfo("Confirm IO after disk restored.");
        $ret = VerifyIO( $objPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        $ret = CheckSosTables( $objPtr, ( NOTFRAGMENTED) );
        if ( $ret != GOOD ) { return ERROR; }
 
        $DebugMes = "Georaid test case 3 drivebay : Power On ";
    
        #
        # Send Power On message to the controller logs
        #
        $FunctionRet = CtlrLogTextAll($objPtr, $DebugMes);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to send message to debug console <====");
            return ERROR;   
        }
                  
        #
        # Send Power ON command to the MOXA/APC
        #
    
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[2], 1);
        $FunctionRet = PowerChange($$MoxaIP[2], $$Chan[3], 1);
        
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to power on drive bay <====");
            return ERROR;
        }
            
        logInfo("Drive bay has been power cycled");
    
        #
        # Check for Good SES data before procedding
        #
        my $check = TRUE;                                                       
        my $count = 0;

        logInfo("Waiting for drive bay to power up...");
    
        DelaySecs(45);

        logInfo(" ");
        logInfo("Waiting for SES to come on ready....");
        logInfo(" ");
    
        #
        # Find Master controller
        #
        
        $MasterObj = &TestLibs::IntegCCBELib::FindMaster($objPtr);

        if($MasterObj == INVALID)
        {
            logInfo("    ====> Test failed: unable to find master controller... <====");
            return ERROR;
        }
        
        $FunctionRet = Wait4Ses($coList[$MasterObj], 120);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Timed out while waiting for SES to come ready <====");
            return ERROR;
        }  
        
        #
        # Start Check loop; Check for rebuilds to start and then monitor progress
        #
        
        while( $check == TRUE )
        {
        
            #
            # Allow drive bay to come on ready
            #
            logInfo("Waiting for rebuild to start...");
            DelaySecs(30);

            $FunctionRet = DegradeCheck($coList[$MasterObj]);
        
        
            if($FunctionRet == ERROR)
            {
                logInfo("    ====> ERROR: occured while checking physical disk status <====");
                return ERROR;
            }

            if($count < 10 )
            {
                if($FunctionRet == INVALID)
                {
                    logInfo("Rebuild started....");
                    $check = FALSE; 
                }
                elsif($FunctionRet == GOOD)
                {
                    logInfo("Rebuild Completed before function called (Increase number of Vdisks with I/O).");
                    $check = FALSE; 
                }

            }
            else
            {
                logInfo("    ====> Rebuild did not start after 5 min <====");
                return ERROR;
            }

            $count++;
        }
    
        # Test for CCBTIMEOUT and re-login if needed
        #
        $FunctionRet = TestNReconnectAll(\@coList);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to reconnect to one or more of the controllers. <====");
            return ERROR;
        }
        
        #
        # delay 300 seconds for I/O to restore and swap backs to complete
        #
        
        DelaySecs(300);
        
        logInfo("Verify IO with drivebay turned on");
        
        $ret = TestSystemState1( $objPtr,
                                 \@activeServers,
                                 0,
                                 \@initialVdisks,
                                 $snPtr
                               );
        if ( $ret != GOOD ) { return ERROR; }
        
        # This section will search for the mirror of mirror vdisks which will be 
        # in user paused state and resumes copy on those vdisks 
   
        %info = $ctlr->resyncData(1);

        if (%info)
        {
            if ($info{STATUS} == PI_GOOD)
            { 
                for ($i = 0; $i < $info{COUNT}; $i++)
                {
                    if ($info{DTLCPY}[$i]{VMIRROR} == 3) # Check if the vdisk is in user pause state 
                    {
                        if ($info{DTLCPY}[$i]{VATTR} == 30) # make sure that the source vdisk is a mirror by it self 
                        {
                            %rsp1 = $ctlr->virtualDiskControl(0x07, $info{DTLCPY}[$i]{RCSDV}, $info{DTLCPY}[$i]{RCDDV});

                            if (!%rsp1)                        # no response
                            {
                                print "\n";
                                logInfo(">>>>> Failed to receive a response from virtualdiskcontrol while resuming copy <<<<<");
                                return ERROR;
                            }
                            elsif ($rsp1{STATUS}  != PI_GOOD)            # 1 is bad
                            {
                                logInfo("Resuming copy on mirror disk $info{DTLCPY}[$i]{RCDDV} has Failed. \n");
                                print "\n";
                                TestLibs::IntegCCBELib::PrintError(%rsp1);
                                return ERROR;
                            }
                            else
                            {
                                logInfo("Copy has been resumed on mirror vdisk $info{DTLCPY}[$i]{RCDDV}\n");
                                $ret = WaitForCpComplete($ctlr, $info{DTLCPY}[$i]{RCDDV});
                                if ( $ret != GOOD ) { return ERROR; }
                            }
                        }
                    	else 
                    	{
                        	print "\n";
                        	logWarning("Source vdisk is not a mirror");
                    	}

                    }
                }   
            } 
            else
            {
                my $msg = "Unable to retrieve the resync data.";
                displayError($msg, %info);
            }
        }  
        else
        {
            print "ERROR: Did not receive a response packet from function resyncData.\n";
            return ERROR;
        } 
        
        # check the back end state, vdisk status, pdisk status, raid status
        #
        $ret = TestLibs::Validate::TestSystemState3($coList[$master], \%mirrorData);
        if ( ($ret == ERROR))
        {
            logInfo("    ====> Validations have failed <====");
            return ERROR;
        }
        
        logInfo("Verify IO at end of the test, after restoring the pdisk");
        $ret = VerifyIO( $objPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                      );
        if ( $ret != GOOD ) { return ERROR; }

        $ret = TestEndMirrorCheck($objPtr, $MRWTimeout, \%mirrorData );   
        if ( $ret != GOOD ) { return ERROR; }
    
    return GOOD;
}
     
##############################################################################
#
#          Name: MakeGeoVdisks
#
#        Inputs: controllerID, strategy, option, numVdisks,
#                source geolocation, destination geolocation (optional) 
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Makes a group of vdisks based upon a strategy. There
#                is the ability to pass an option to a strategy. Will
#                use data and unsafe drives as appropriate.
#                
#                Currently this script supports only two Geolocations.
#                
#                Stragtegies :
#                
#                1. Creates Source Vdisks on drivebays at a geolocation.
#                2. Creates 20 source vdisks which are distributed across two geolocations.
#                3. Creates Destination [Mirror] Vdisks on drivebays at a geolocation. 
#                4. Creates 20 destination vdisks which are distributed across two geolocations.
#                7. This startegy will be invoked by basicconfig subroutine to create mirrors.
#
##############################################################################
sub MakeGeoVdisks
{
    trace();
    
    my ($objPtr, $strategy, $option, $numVdisks, $srcgeoid, $destgeoid ) = @_;

    my $ret;
    my $bay;
    my $srcgeoloc = 0;
    my $destgeoloc = 0;
    my @newVdisks;
    my %rsp;
    my $maxSize;
    my @VDMName;
    my @Capacity;
    my @Type;
    my @Stripe;
    my @Parity;
    my @Disks;
    my @Depth;
    my $numberToCreate;

    # discover what PDDs are there and how they are labeled (devstat)
    # assume there are some physical drives for the moment


    # group drives, possibly according to strategy - just data manipulation

    my $ourSN;

    my $i;
    my @ourDataGeo1Entries;       # indices to pdisks
    my @ourDataGeo2Entries;       # indices to pdisks
    my @ourUnsafeGeo1Entries;
    my @ourUnsafeGeo2Entries;

    my @bays1;
    my @driveBays;

    my $bayFlag;
    my $drivesInAllGeo1Data;
    my $drivesInAllGeo1Unsafe;
    my $drivesInGr3Geo1Data;
    my $drivesInAllGeo2Data;
    my $drivesInAllGeo2Unsafe;
    my $drivesInGr3Geo2Data;
    my $msg;

    my $count;
    my $j;
    my $drvCount;
    my $pdd;
    my $skipped;

    my @bayPtr;
    my $UseArrays;
    my $autogrouping = 0;

    my @coList;
    my $controller;
    my $master;
    my @geoLocationId; 
    my @geoLocations; 


    #
    # Arrays for source fibre drives
    #
    my @evenDataGeo1 = ();
    my @oddDataGeo1 = ();
    my @allDataGeo1 = ();
    my @allUnsafeGeo1 = ();
    my @Gr3DataGeo1 = ();
    my @Gr5DataGeo1 = ();
    my @Gr9DataGeo1 = ();

    #
    # arrays for source sata drives
    #
    my @evenDataSataGeo1 = ();
    my @oddDataSataGeo1 = ();
    my @allDataSataGeo1 = ();
    my @allUnsafeSataGeo1 = ();
    my @Gr3DataSataGeo1 = ();
    my @Gr5DataSataGeo1 = ();
    my @Gr9DataSataGeo1 = ();


    #
    # pointers to the source drive arrays
    #
    my $evenDataPtrGeo1;
    my $oddDataPtrGeo1;
    my $allDataPtrGeo1;
    my $allUnsafePtrGeo1;
    my $Gr3DataPtrGeo1;

    my $evenDataSataPtrGeo1;
    my $oddDataSataPtrGeo1;
    my $allDataSataPtrGeo1;
    my $allUnsafeSataPtrGeo1;
    my $Gr3DataSataPtrGeo1;

    #
    # Arrays for destination fibre drives
    #
    my @evenDataGeo2 = ();
    my @oddDataGeo2 = ();
    my @allDataGeo2 = ();
    my @allUnsafeGeo2 = ();
    my @Gr3DataGeo2 = ();

    #
    # arrays for destination sata drives
    #
    my @evenDataSataGeo2 = ();
    my @oddDataSataGeo2 = ();
    my @allDataSataGeo2 = ();
    my @allUnsafeSataGeo2 = ();
    my @Gr3DataSataGeo2 = ();


    #
    # pointers to the destination drive arrays
    #
    my $evenDataPtrGeo2;
    my $oddDataPtrGeo2;
    my $allDataPtrGeo2;
    my $allUnsafePtrGeo2;
    my $Gr3DataPtrGeo2;

    my $evenDataSataPtrGeo2;
    my $oddDataSataPtrGeo2;
    my $allDataSataPtrGeo2;
    my $allUnsafeSataPtrGeo2;
    my $Gr3DataSataPtrGeo2;


    my $fcCountGeo1 = 0;
    my $sataCountGeo1 = 0;

    my $fcCountGeo2 = 0;
    my $sataCountGeo2 = 0;
    
    my $bayflag;
    my $driveCnt;
    my $numDrives;
    my $masterIndex;


    @coList = @$objPtr;
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);
    
    if ( $master == INVALID ) { return(ERROR); } 

    $controller = $coList[$master];

    if ( $controller == 0 )
    {
        logWarning(">>>>> Failed, need a valid controller object. <<<<<");
        return (ERROR);
    }


    logInfo("     MakeVdisks: strategy # $strategy.");

    # get our serial number, used to see if we will own a drive

    $ourSN = GetGroupSerial( $controller );
    
    if ( INVALID == $ourSN  )
    {
        logWarning(">>>>> Failed to get controller's serial number <<<<<");
        return (ERROR);
    }

    logInfo("============ Disks Group and Drive Information ==========");

    my %bays = $controller->diskBays();
    
    my $baycount = $bays{COUNT};
    
    for ($i = 0; $i < $baycount; $i++)
    {
        $geoLocations[$i]  = $bays{BAYS}[$i]{GL_ID};
    }

    my $geoloccnt =  scalar (@geoLocationId);

    @geoLocationId = &TestLibs::utility::SortAndRemoveDups(@geoLocations);

    #
    # check if geolocation was passed in.  
    # If it was, use it.
    # If not, get configured geolocations from controller.
    #

    if ( $srcgeoid != 0 )
    {  
        # Validate if the user supplied source geolocation is already configured one 
        # if not return error 
        
        for ( $i = 0; $i < $geoloccnt; $i++ )
        {
            if ( $geoLocationId[$i] == $srcgeoid)
            {
                # If found set the flag
                $srcgeoloc = 1;
            }
        }     
            
        if ($srcgeoloc == 1)
        {
            $geoLocationId[0] = $srcgeoid; 
            $geoLocationId[1] = $destgeoid; 
            $autogrouping = 0;
            logInfo "source gelocation passed from user is : $srcgeoid\n";
        }    
        else
        {
            logError(">>>>> The geolocation $srcgeoid is a non existent geolocation <<<<<");
            return ERROR;
        }
    }
    elsif ( $destgeoid != 0 )
    {
        # Validate if the user supplied destination geolocation is already configured one 
        # if not return error 
        
        for ( $i = 0; $i < $geoloccnt; $i++ )
        {
            if ( $geoLocationId[$i] == $destgeoid)
            {
                # If found set the flag
                $destgeoloc = 1;
            }
        }     
            
        if ($destgeoloc == 1)
        {
            $geoLocationId[0] = $srcgeoid; 
            $geoLocationId[1] = $destgeoid; 
            $autogrouping = 0;
            logInfo "destination gelocation passed from user is : $destgeoid\n";
        }
        else
        {
            logError(">>>>> The geolocation $destgeoid is a non existent geolocation <<<<<");
            return ERROR;
        }
    }
    else 
    {   
        if ( $geoLocationId[0] == 0 || $geoLocationId[1] == 0 )
        {
            logError (">>>>> geolocation not set on drivebays <<<<<");
            return ERROR;
        }
        else
        {
            logInfo "Auto grouping will be done as there is no user choice\n";
            $autogrouping = 1;
        }    
    }
    
    # When autogrouping is selected there shall be only two geolocations
    # make sure that there are only two geolocations irrespective of number
    # of drivebays available

    if ( ( $geoloccnt > 2 ) && ( $autogrouping == 1) )
    {
       logError (">>>>> There are more than 2 geolocations when autogrouping selected <<<<<");
       return ERROR;
    }
    
    ###########################################
    #          Get pdisk related information
    ###########################################


    my %pdisks = $controller->physicalDisks();

    if ( ! %pdisks )     # no response from controller
    {
        logInfo(">>>>> Failed to get pdisk list (no response) <<<<<");
        return ERROR;
    }
    else                          # got a response
    {
        if ( $pdisks{STATUS} == PI_GOOD )
        {
            logInfo("disk list is good, now walking it");
        }
        else
        {
            # got an error, report it, bail
            logInfo(">>>>> Failed getting pdisk list <<<<<");
            PrintError(%pdisks);
            return ERROR;
        }
    }

    for(my $i = 0; $i < $pdisks{COUNT}; ++$i)
    {

        # These are the data items we will use

        #    $pdisks{COUNT}
        #    $pdisks{PDISKS}[$i]{PD_PID}
        #                [$i]{SES},
        #                [$i]{SLOT},
        #                [$i]{PD_CLASS},
        #                [$i]{PD_SSERIAL},
        #                [$i]{GL_ID},
 
        # go thru the disk list and count the data and unsafe disks. keep
        # an array of each


        # let's see if we 'own' this disk. To own it, the serial number
        # must be ours.


        # compare to our SN, if match we can use
        
        if ( $ourSN == $pdisks{PDISKS}[$i]{PD_SSERIAL} )
        {
            # OK to use this drive - put in right group

            # add unsafe drive index to array
            if ($pdisks{PDISKS}[$i]{PD_CLASS} == CCBEUNSAFETYPE)
            {
                if ($geoLocationId[0] != 0 || $autogrouping == 1)
                {
                    if ($pdisks{PDISKS}[$i]{GL_ID} == $geoLocationId[0])
                    {
                        push(@ourUnsafeGeo1Entries, $i);
                    }
                }  
                
                if ($geoLocationId[1] != 0 || $autogrouping == 1)
                {
                    if ($pdisks{PDISKS}[$i]{GL_ID} == $geoLocationId[1])
                    {
                        push(@ourUnsafeGeo2Entries, $i);
                    }    
                }
            }  
            elsif($pdisks{PDISKS}[$i]{PD_CLASS} == CCBEDATATYPE)
            {
              # add data drive index to array
                if ($geoLocationId[0] != 0 || $autogrouping == 1)
                {
                    if ($pdisks{PDISKS}[$i]{GL_ID} == $geoLocationId[0])
                    {
                        push(@ourDataGeo1Entries, $i);
                    }
                }  
                
                if ($geoLocationId[1] != 0 || $autogrouping == 1)
                {
                    if ($pdisks{PDISKS}[$i]{GL_ID} == $geoLocationId[1])
                    {
                        push(@ourDataGeo2Entries, $i);
                    }    
                }
            }    
        }
        
        # While we are walking the list, lets count drive bays
        # We do this because a one or two drive bay system may
        # cause a problem in some configurations. Collect a bay
        # list here. The same drive bay will be pushed multiple
        # times onto the stack since we are walking the PDISKS here.
        # A separate call to remove duplicates is outside the loop.

        push(@bays1, $pdisks{PDISKS}[$i]{SES});

        #
        # count fibre vs. sata drives in both geolocations independently
        #
        
        if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$i]{PD_DEVTYPE} )  # fibre
        {
                if ($geoLocationId[0] == $pdisks{PDISKS}[$i]{GL_ID})
                {
                    $fcCountGeo1++;
                }
                
                if ($geoLocationId[1] == $pdisks{PDISKS}[$i]{GL_ID})
                {
                    $fcCountGeo2++;
                }
        }
        elsif ( PD_DT_SATA == $pdisks{PDISKS}[$i]{PD_DEVTYPE} )  # sata
        {
                if ($geoLocationId[0] == $pdisks{PDISKS}[$i]{GL_ID})
                {
                    $sataCountGeo1++;
                }
                
                if ($geoLocationId[1] == $pdisks{PDISKS}[$i]{GL_ID})
                {
                    $sataCountGeo2++;
                }
        }    
    }


    @driveBays = &TestLibs::utility::SortAndRemoveDups(@bays1);

    #
    # Now we have list of pdisk pointers that we own for data and
    # unsafe type. Using the appropriate SES/SLOT info we can break
    # the disks into several groups. We also know how many bays we have.
    #

    # Establish the number of drives for each disk group we will use

    # If there are less than 3 bays, make the number of drives even for
    # all groups. For the "all" groups reduce the count if needed. For the
    # subsets, increase the count if needed.

    $bayFlag = 0;                          # 0 = lots of bays
    
    if ( scalar( @driveBays ) < 3 ) {$bayFlag = 1; }

    if($geoLocationId[0] != 0 || $autogrouping == 1)
    {
        logInfo("Found $fcCountGeo1 Fibre drives and $sataCountGeo1 SATA drives at geolocation $geoLocationId[0].");
        
        $drivesInAllGeo1Data   = scalar(@ourDataGeo1Entries);
        $drivesInAllGeo1Unsafe = scalar(@ourUnsafeGeo1Entries);
        
        if ($bayFlag )
        {
            $drivesInAllGeo1Data   = $drivesInAllGeo1Data   - $drivesInAllGeo1Data   % 2;
            $drivesInAllGeo1Unsafe = $drivesInAllGeo1Unsafe - $drivesInAllGeo1Unsafe % 2;
        }    
    
        # the adjustments are based upon raid 5 requirements (this correction
        # may go away)

        $drivesInGr3Geo1Data = 3 + $bayFlag;
        
        #
        # Now validate the group sizes. If we didn't have enough pdisks to
        # start with, we will have trouble creating some configurations. In
        # this case, rather than looking at what drives were are going to
        # create per the requested strategy, we are just looking at our
        # ability to create the disk groupings.
        #

        # We really only need to check a few as that will cover the rest.
        # (This still won't guarantee success because we haven't looked
        # at what labels are on the drive by bay.)

        if ( $drivesInGr3Geo1Data > scalar(@ourDataGeo1Entries) 
             || $drivesInAllGeo1Unsafe < 2 )
        {
            $msg =  "There does not appear to be enough pdisks with the right labels\n";
            $msg .= "to build the necessary configuration. You will need to relabel\n";
            $msg .= "your drives, or add more drives or bays.\n\n";
            $msg .= "Group:      Drives needed:     Drives available:\n";
            $msg .= "9 data              $drivesInGr3Geo1Data                  $drivesInAllGeo1Data \n";
            $msg .= "unsafe              2                    $drivesInAllGeo1Unsafe  \n";
            logInfo($msg);
        }

        logInfo (" Putting source drives into groups.\n");

        #
        # Now we build the individual disk arrays. We do our best to spread
        # them across the bays. (This may be ugly.)
        #

        # do the easy ones first - most/all data

        for ( $i = 0; $i < $drivesInAllGeo1Data; $i++ )
        {
            if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_DEVTYPE} )  # fibre
            {
                push( @allDataGeo1, $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_PID} );
            }
            elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_DEVTYPE} )  # sata
            {
                push( @allDataSataGeo1, $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_PID} );
            }
        }

        print "      all data groups done \n";

        # most/all of the unsafes

        for ( $i = 0; $i < $drivesInAllGeo1Unsafe; $i++ )
        {

            if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourUnsafeGeo1Entries[$i]]{PD_DEVTYPE} )  # fibre
            {
                push( @allUnsafeGeo1, $pdisks{PDISKS}[$ourUnsafeGeo1Entries[$i]]{PD_PID} );
            }
            elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourUnsafeGeo1Entries[$i]]{PD_DEVTYPE} )  # sata
            {
                push( @allUnsafeSataGeo1, $pdisks{PDISKS}[$ourUnsafeGeo1Entries[$i]]{PD_PID} );
            }

        }

        print "      all unsafe groups done \n";


        # now the odd/evens

        for ( $j = 0; $j < scalar( @driveBays ); $j++ )
        {
            $count = 0;

            for ( $i = 0; $i < $drivesInAllGeo1Data; $i++ )
            {
                if ( $driveBays[$j] ==  $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{SES} )
                {
                    # same bay, select odd/even

                    if ( ($count % 2) == 0 )
                    {
                        if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_DEVTYPE} )  # fibre
                        {
                            push( @evenDataGeo1, $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_PID} );
                        }
                        elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_DEVTYPE} )  # sata
                        {
                            push( @evenDataSataGeo1, $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_PID} );
                        }
                    }
                    else
                    {
                        if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_DEVTYPE} )  # fibre
                        {
                            push( @oddDataGeo1, $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_PID} );
                        }
                        elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_DEVTYPE} )  # sata
                        {
                            push( @oddDataSataGeo1, $pdisks{PDISKS}[$ourDataGeo1Entries[$i]]{PD_PID} );
                        }
                    }

                    $count++;
                }
            }
        }

        print "      odd and even groups done \n";

        if ($fcCountGeo1 > 0 )
        {

            #
            # now the raid 5 data ones. First do all the FC drives, then repeat
            # for all the SATA drives.
            #

            # make/init some Ptr for each bay. These are the index for the last
            # pdisk used from the bay.

            for ( $i = 0; $i < scalar( @driveBays ); $i++ )
            {
                $bayPtr[$i]=0;
            }

            #
            # first the parity 3 group
            #

            $bay = 0;
            $pdd = 0;

            $driveCnt = 0;

            while ($driveCnt <  $drivesInGr3Geo1Data)
            {

                if (
                    ( $pdisks{PDISKS}[$ourDataGeo1Entries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                    ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataGeo1Entries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                    ( 0 == IsInList($pdisks{PDISKS}[$ourDataGeo1Entries[$pdd]]{PD_PID}, \@Gr3DataGeo1 ) )  # not in list
                   )
                {
                    # add drive to list
                    push ( @Gr3DataGeo1, $pdisks{PDISKS}[$ourDataGeo1Entries[$pdd]]{PD_PID} );
                    $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                    $bay++;                                # switch to next bay
                    $bay = $bay  % scalar(@driveBays);     # wrap bay number

                    $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                    $driveCnt++;                           # show we got another one
                    $skipped = 0;                          # reset skipped counter

                }
                else
                {
                    # skip drive, bay mismatched, or was in list
                    $pdd++;
                    $skipped++;
                    if($skipped > scalar(@ourDataGeo1Entries) )
                    {
                        # we've skipped enough drives that we can't find
                        # any more in this bay, go on to the next bay
                        # and search for the next drive
                        $bay++;
                        $skipped = 0;
                    }
                }

                # wrap pointers if necessary

                $pdd = $pdd % scalar(@ourDataGeo1Entries);
                $bay = $bay % scalar(@driveBays);

            }

            print "      R5P3 FC group done \n";

        }
        
        #
        # Now do the above for the SATA drives. Same code, different variables.
        #
        # first the parity 3 group
        #

        if ( $sataCountGeo1 > 0 )
        {

            # make/init some Ptr for each bay. These are the index for the last
            # pdisk used from the bay.

            for ( $i = 0; $i < scalar( @driveBays ); $i++ )
            {
                $bayPtr[$i]=0;
            }

            $bay = 0;
            $pdd = 0;

            $driveCnt = 0;

            while ($driveCnt <  $drivesInGr3Geo1Data)
            {

                if (
                     ( $pdisks{PDISKS}[$ourDataGeo1Entries[$pdd]]{SES} == $driveBays[$bay] ) &&          # bay matches and
                     ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataGeo1Entries[$pdd]]{PD_DEVTYPE} ) &&            # drive type matches and
                     ( 0 == IsInList($pdisks{PDISKS}[$ourDataGeo1Entries[$pdd]]{PD_PID}, \@Gr3DataSataGeo1 ) )   # not in list
                   )
                {
                    # add drive to list
                    push ( @Gr3DataSataGeo1, $pdisks{PDISKS}[$ourDataGeo1Entries[$pdd]]{PD_PID} );
                    $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                    $bay++;                                # switch to next bay
                    $bay = $bay  % scalar(@driveBays);     # wrap bay number

                    $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                    $driveCnt++;                           # show we got another one
                    $skipped = 0;                          # reset skipped counter

                }
                else
                {
                    # skip drive, bay mismatched, or was in list
                    $pdd++;
                    $skipped++;
                    if($skipped > scalar(@ourDataGeo1Entries) )
                    {
                        # we've skipped enough drives that we can't find
                        # any more in this bay, go on to the next bay
                        # and search for the next drive
                        $bay++;
                        $skipped = 0;
                    }
                }

                # wrap pointers if necessary

                $pdd = $pdd % scalar(@ourDataGeo1Entries);
                $bay = $bay % scalar(@driveBays);

            }
            print "      R5P3 SATA group done \n";
        }

        #
        # Drives are sorted into groups, but some groups may be empty based
        # upon the number and type of bays.
        #


        $bay = scalar(@driveBays) ;

        my $str = "\nI think there are $bay bay(s). (@driveBays) \n";

        $str .=  "------------- disk groupings ----- step 1 --------\n";

        # fibre ones
        $str .= sprintf "                Gr3DataGeo1[%3d",scalar(@Gr3DataGeo1);
        $str .=  "]:  @Gr3DataGeo1 \n";

        $str .= sprintf "                allDataGeo1[%3d",scalar(@allDataGeo1);
        $str .=  "]:  @allDataGeo1 \n";

        $str .= sprintf "              allUnsafeGeo1[%3d",scalar(@allUnsafeGeo1);
        $str .=  "]:  @allUnsafeGeo1 \n";

        $str .= sprintf "               evenDataGeo1[%3d",scalar(@evenDataGeo1);
        $str .=  "]:  @evenDataGeo1 \n";

        $str .= sprintf "                oddDataGeo1[%3d",scalar(@oddDataGeo1);
        $str .= "]:  @oddDataGeo1 \n";

        # sata ones

        $str .= sprintf "            Gr3DataSataGeo1[%3d",scalar(@Gr3DataSataGeo1);
        $str .=  "]:  @Gr3DataSataGeo1 \n";

        $str .= sprintf "            allDataSataGeo1[%3d",scalar(@allDataSataGeo1);
        $str .=  "]:  @allDataSataGeo1 \n";

        $str .= sprintf "          allUnsafeSataGeo1[%3d",scalar(@allUnsafeSataGeo1);
        $str .=  "]:  @allUnsafeSataGeo1 \n";

        $str .= sprintf "           evenDataSataGeo1[%3d",scalar(@evenDataSataGeo1);
        $str .=  "]:  @evenDataSataGeo1 \n";

        $str .= sprintf "            oddDataSataGeo1[%3d",scalar(@oddDataSataGeo1);
        $str .= "]:  @oddDataSataGeo1 \n";

        $str .=  " -----------------------------------------\n";
        logInfo($str);

        #
        # Groups are filled with the drives we have. Now setup pointers that will be used
        # for the rest of the function. If an array is empty, the pointer will point to
        # the corresponding array for the other drive type. (We can have one type of bay
        # or mixed and this should all work.
        #

        $evenDataPtrGeo1 = \@evenDataGeo1;
        $oddDataPtrGeo1 = \@oddDataGeo1;
        $allDataPtrGeo1 = \@allDataGeo1;
        $allUnsafePtrGeo1 = \@allUnsafeGeo1;
        $Gr3DataPtrGeo1 = \@Gr3DataGeo1;

        $evenDataSataPtrGeo1 = \@evenDataSataGeo1;
        $oddDataSataPtrGeo1 = \@oddDataSataGeo1;
        $allDataSataPtrGeo1 = \@allDataSataGeo1;
        $allUnsafeSataPtrGeo1 = \@allUnsafeSataGeo1;
        $Gr3DataSataPtrGeo1 = \@Gr3DataSataGeo1;

        #
        # Now deal with pointers that may be references to empty arrays.
        # Same chunk of code replicated 14 times.
        #

        # first the fibre ones

        if (scalar(@evenDataGeo1) == 0 )
        {
            if (scalar(@evenDataSataGeo1) > 0)
            {
                $evenDataPtrGeo1 = \@evenDataSataGeo1;
            }
            else
            {
                logInfo(" Not enough 'even data' drives ");
                return ERROR;
            }
        }

        if (scalar(@oddDataGeo1) == 0 )
        {
            if (scalar(@oddDataSataGeo1) > 0)
            {
            $oddDataPtrGeo1 = \@oddDataSataGeo1;
            }
            else
            {
               logInfo(" Not enough 'odd data' drives ");
                return ERROR;
            }   
        }
    
    
        if (scalar(@allDataGeo1) == 0 )
        {
            if (scalar(@allDataSataGeo1) > 0)
            {
                $allDataPtrGeo1 = \@allDataSataGeo1;
            }
            else
            {
                logInfo(" Not enough 'all data' drives ");
                return ERROR;
            }
        }
    

        if (scalar(@allUnsafeGeo1) == 0 )
        {
            if (scalar(@allUnsafeSataGeo1) > 0)
            {
               $allUnsafePtrGeo1 = \@allUnsafeSataGeo1;
            }
            else
            {
                logInfo(" Not enough 'all Unsafe' drives ");
                return ERROR;
            }
        }
    

        if (scalar(@Gr3DataGeo1) == 0 )
        {
            if (scalar(@Gr3DataSataGeo1) > 0)
            {
                $Gr3DataPtrGeo1 = \@Gr3DataSataGeo1;
            }
            else
            {
                logInfo("  I am Here Not enough 'group 3 data' drives ");
                return ERROR;
            }
        }
    

       # now the sata ones
    
        if (scalar(@evenDataSataGeo1) == 0 )
        {
            if (scalar(@evenDataGeo1) > 0)
            {
                $evenDataSataPtrGeo1 = \@evenDataGeo1;
            }
            else
            {
                logInfo(" Not enough 'even data sata' drives ");
                return ERROR;
            }
        }
    
       if (scalar(@oddDataSataGeo1) == 0 )
        {
           if (scalar(@oddDataGeo1) > 0)
            {
                $oddDataSataPtrGeo1 = \@oddDataGeo1;
            }
            else
            {
               logInfo(" Not enough 'odd data sata' drives ");
               return ERROR;
            }
        }
    
        if (scalar(@allDataSataGeo1) == 0 )
        {
            if (scalar(@allDataGeo1) > 0)
            {
                $allDataSataPtrGeo1 = \@allDataGeo1;
            }
            else
            {
                logInfo(" Not enough 'all data sata' drives ");
                return ERROR;
            }
        }


        if (scalar(@allUnsafeSataGeo1) == 0 )
        {
            if (scalar(@allUnsafeGeo1) > 0)
            {
                $allUnsafeSataPtrGeo1 = \@allUnsafeGeo1;
            }
            else
            {
                logInfo(" Not enough 'all Unsafe sata' drives ");
                return ERROR;
            }
        }


        if (scalar(@Gr3DataSataGeo1) == 0 )
        {
            if (scalar(@Gr3DataGeo1) > 0)
            {
                $Gr3DataSataPtrGeo1 = \@Gr3DataGeo1;
            }
            else
            {
                logInfo(" Not enough 'group 3 data sata' drives ");
                return ERROR;
            }
        }
    
    } # end of if for source pdisks grouping
    
    if($geoLocationId[1] != 0 || $autogrouping == 1)
    {
    
        logInfo (" Putting Destination drives into groups.\n");
        
        logInfo("Found $fcCountGeo2 Fibre drives and $sataCountGeo2 SATA drives at geolocation $geoLocationId[1].");

        $drivesInAllGeo2Data   = scalar(@ourDataGeo2Entries);
        $drivesInAllGeo2Unsafe = scalar(@ourUnsafeGeo2Entries);
        
        if ($bayFlag)
        {
            $drivesInAllGeo2Data   = $drivesInAllGeo2Data   - $drivesInAllGeo2Data   % 2;
            $drivesInAllGeo2Unsafe = $drivesInAllGeo2Unsafe - $drivesInAllGeo2Unsafe % 2;
        }    


        # the adjustments are based upon raid 5 requirements (this correction
        # may go away)

        $drivesInGr3Geo2Data = 3 + $bayFlag;
        
        if ( $drivesInGr3Geo2Data > scalar(@ourDataGeo2Entries)
             || $drivesInAllGeo2Unsafe < 2 )
        {
            $msg =  "There does not appear to be enough pdisks with the right labels\n";
            $msg .= "to build the necessary configuration. You will need to relabel\n";
            $msg .= "your drives, or add more drives or bays.\n\n";
            $msg .= "Group:      Drives needed:     Drives available:\n";
            $msg .= "9 data              $drivesInGr3Geo2Data                  $drivesInAllGeo2Data \n";
            $msg .= "unsafe              2                    $drivesInAllGeo2Unsafe  \n";

            logInfo($msg);
            # don't return, rather let a drive create fail
        }
 
        #
        # Now we build the individual disk arrays. We do our best to spread
        # them across the bays. (This may be ugly.)
        #

        # do the easy ones first - most/all data

        for ( $i = 0; $i < $drivesInAllGeo2Data; $i++ )
        {
            if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_DEVTYPE} )  # fibre
            {
                push( @allDataGeo2, $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_PID} );
            }
            elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_DEVTYPE} )  # sata
            {
                push( @allDataSataGeo2, $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_PID} );
            }
        }

        print "      all data groups done \n";

        # most/all of the unsafes

        for ( $i = 0; $i < $drivesInAllGeo2Unsafe; $i++ )
        {

            if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourUnsafeGeo2Entries[$i]]{PD_DEVTYPE} )  # fibre
            {
                push( @allUnsafeGeo2, $pdisks{PDISKS}[$ourUnsafeGeo2Entries[$i]]{PD_PID} );
            }
            elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourUnsafeGeo2Entries[$i]]{PD_DEVTYPE} )  # sata
            {
                push( @allUnsafeSataGeo2, $pdisks{PDISKS}[$ourUnsafeGeo2Entries[$i]]{PD_PID} );
            }
        }

        print "      all unsafe groups done \n";


        # now the odd/evens

        for ( $j = 0; $j < scalar( @driveBays ); $j++ )
        {
            $count = 0;

            for ( $i = 0; $i < $drivesInAllGeo2Data; $i++ )
            {
                if ( $driveBays[$j] ==  $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{SES} )
                {
                    # same bay, select odd/even
    
                    if ( ($count % 2) == 0 )
                    {
                        if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_DEVTYPE} )  # fibre
                        {
                            push( @evenDataGeo2, $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_PID} );
                        }
                        elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_DEVTYPE} )  # sata
                        {
                            push( @evenDataSataGeo2, $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_PID} );
                        }
                    }
                    else
                    {
    
                        if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_DEVTYPE} )  # fibre
                        {
                            push( @oddDataGeo2, $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_PID} );
                        }
                        elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_DEVTYPE} )  # sata
                        {
                            push( @oddDataSataGeo2, $pdisks{PDISKS}[$ourDataGeo2Entries[$i]]{PD_PID} );
                        }
                    }

                    $count++;
                }
            }
        }

        print "      odd and even groups done \n";

        if ($fcCountGeo2 > 0 )
        {
    
            #
            # now the raid 5 data ones. First do all the FC drives, then repeat
            # for all the SATA drives.
            #

            # make/init some Ptr for each bay. These are the index for the last
            # pdisk used from the bay.

            for ( $i = 0; $i < scalar( @driveBays ); $i++ )
            {
                $bayPtr[$i]=0;
            }


            #
            # first the parity 3 group
            #

            $bay = 0;
            $pdd = 0;

            $driveCnt = 0;

            while ($driveCnt <  $drivesInGr3Geo2Data)
            {

                if (
                   ( $pdisks{PDISKS}[$ourDataGeo2Entries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                   ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataGeo2Entries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                   ( 0 == IsInList($pdisks{PDISKS}[$ourDataGeo2Entries[$pdd]]{PD_PID}, \@Gr3DataGeo2 ) )  # not in list
                   )
                {
                    # add drive to list
                    push ( @Gr3DataGeo2, $pdisks{PDISKS}[$ourDataGeo2Entries[$pdd]]{PD_PID} );
                    $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                    $bay++;                                # switch to next bay
                    $bay = $bay  % scalar(@driveBays);     # wrap bay number

                    $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                    $driveCnt++;                           # show we got another one
                    $skipped = 0;                          # reset skipped counter
                }
                else
                {
                    # skip drive, bay mismatched, or was in list
                    $pdd++;
                    $skipped++;
                    
                    if($skipped > scalar(@ourDataGeo2Entries) )
                    {
                        # we've skipped enough drives that we can't find
                        # any more in this bay, go on to the next bay
                        # and search for the next drive
                        $bay++;
                        $skipped = 0;
                    }
                }

                # wrap pointers if necessary

                $pdd = $pdd % scalar(@ourDataGeo2Entries);
                $bay = $bay % scalar(@driveBays);
            }

            print "      R5P3 FC group done \n";

        }
        
        #
        # Now do the above for the SATA drives. Same code, different variables.
        #
        # first the parity 3 group
        #

        if ( $sataCountGeo2 > 0 )
        {
            # make/init some Ptr for each bay. These are the index for the last
            # pdisk used from the bay.

            for ( $i = 0; $i < scalar( @driveBays ); $i++ )
            {
                $bayPtr[$i]=0;
            }

            $bay = 0;
            $pdd = 0;

            $driveCnt = 0;

            while ($driveCnt <  $drivesInGr3Geo2Data)
            {

                if  (
                    ( $pdisks{PDISKS}[$ourDataGeo2Entries[$pdd]]{SES} == $driveBays[$bay] ) &&          # bay matches and
                    ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataGeo2Entries[$pdd]]{PD_DEVTYPE} ) &&            # drive type matches and
                    ( 0 == IsInList($pdisks{PDISKS}[$ourDataGeo2Entries[$pdd]]{PD_PID}, \@Gr3DataSataGeo2 ) )   # not in list
                    )
                {
                    # add drive to list
                    push ( @Gr3DataSataGeo2, $pdisks{PDISKS}[$ourDataGeo2Entries[$pdd]]{PD_PID} );
                    $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                    $bay++;                                # switch to next bay
                    $bay = $bay  % scalar(@driveBays);     # wrap bay number

                    $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                    $driveCnt++;                           # show we got another one
                    $skipped = 0;                          # reset skipped counter
                }
                else
                {
                    # skip drive, bay mismatched, or was in list
                    $pdd++;
                    $skipped++;
                    
                    if($skipped > scalar(@ourDataGeo2Entries) )
                    {
                        # we've skipped enough drives that we can't find
                        # any more in this bay, go on to the next bay
                        # and search for the next drive
                        $bay++;
                        $skipped = 0;
                    }
                }

                # wrap pointers if necessary

                $pdd = $pdd % scalar(@ourDataGeo2Entries);
                $bay = $bay % scalar(@driveBays);
            }
            print "      R5P3 SATA group done \n";

        }

        #
        # Drives are sorted into groups, but some groups may be empty based
        # upon the number and type of bays.
        #


        $bay = scalar(@driveBays) ;

        my $str1 = "\nI think there are $bay bay(s). (@driveBays) \n";

        $str1 .=  "------------- disk groupings ----- step 1 --------\n";

        # fibre ones
        $str1 .= sprintf "                Gr3DataGeo2[%3d",scalar(@Gr3DataGeo2);
        $str1 .=  "]:  @Gr3DataGeo2 \n";

        $str1 .= sprintf "                allDataGeo2[%3d",scalar(@allDataGeo2);
        $str1 .=  "]:  @allDataGeo2 \n";

        $str1 .= sprintf "              allUnsafeGeo2[%3d",scalar(@allUnsafeGeo2);
        $str1 .=  "]:  @allUnsafeGeo2 \n";

        $str1 .= sprintf "               evenDataGeo2[%3d",scalar(@evenDataGeo2);
        $str1 .=  "]:  @evenDataGeo2 \n";

        $str1 .= sprintf "                oddDataGeo2[%3d",scalar(@oddDataGeo2);
        $str1 .= "]:  @oddDataGeo2 \n";

        # sata ones

        $str1 .= sprintf "            Gr3DataSataGeo2[%3d",scalar(@Gr3DataSataGeo2);
        $str1 .=  "]:  @Gr3DataSataGeo2 \n";

        $str1 .= sprintf "            allDataSataGeo2[%3d",scalar(@allDataSataGeo2);
        $str1 .=  "]:  @allDataSataGeo2 \n";

        $str1 .= sprintf "          allUnsafeSataGeo2[%3d",scalar(@allUnsafeSataGeo2);
        $str1 .=  "]:  @allUnsafeSataGeo2 \n";

        $str1 .= sprintf "           evenDataSataGeo2[%3d",scalar(@evenDataSataGeo2);
        $str1 .=  "]:  @evenDataSataGeo2 \n";

        $str1 .= sprintf "            oddDataSataGeo2[%3d",scalar(@oddDataSataGeo2);
        $str1 .= "]:  @oddDataSataGeo2 \n";

        $str1 .=  " -----------------------------------------\n";
        logInfo($str1);


        #
        # Groups are filled with the drives we have. Now setup pointers that will be used
        # for the rest of the function. If an array is empty, the pointer will point to
        # the corresponding array for the other drive type. (We can have one type of bay
        # or mixed and this should all work.
        #

        $evenDataPtrGeo2 = \@evenDataGeo2;
        $oddDataPtrGeo2 = \@oddDataGeo2;
        $allDataPtrGeo2 = \@allDataGeo2;
        $allUnsafePtrGeo2 = \@allUnsafeGeo2;
        $Gr3DataPtrGeo2 = \@Gr3DataGeo2;

        $evenDataSataPtrGeo2 = \@evenDataSataGeo2;
        $oddDataSataPtrGeo2 = \@oddDataSataGeo2;
        $allDataSataPtrGeo2 = \@allDataSataGeo2;
        $allUnsafeSataPtrGeo2 = \@allUnsafeSataGeo2;
        $Gr3DataSataPtrGeo2 = \@Gr3DataSataGeo2;

        #
        # Now deal with pointers that may be references to empty arrays.
        # Same chunk of code replicated 14 times.
        #

        # first the fibre ones

        if (scalar(@evenDataGeo2) == 0 )
        {
            if (scalar(@evenDataSataGeo2) > 0)
            {
                $evenDataPtrGeo2 = \@evenDataSataGeo2;
            }
            else
            {
                logInfo(" Not enough 'even data' drives ");
                return ERROR;
            }
        }

        if (scalar(@oddDataGeo2) == 0 )
        {
            if (scalar(@oddDataSataGeo2) > 0)
            {
                $oddDataPtrGeo2 = \@oddDataSataGeo2;
            }
            else
            {
                logInfo(" Not enough 'odd data' drives ");
                return ERROR;
            }
        }


        if (scalar(@allDataGeo2) == 0 )
        {
            if (scalar(@allDataSataGeo2) > 0)
            {
                $allDataPtrGeo2 = \@allDataSataGeo2;
            }
            else
            {
                logInfo(" Not enough 'all data' drives ");
                return ERROR;
            }
        }


        if (scalar(@allUnsafeGeo2) == 0 )
        {
            if (scalar(@allUnsafeSataGeo2) > 0)
            {
                $allUnsafePtrGeo2 = \@allUnsafeSataGeo2;
            }
            else
            {
                logInfo(" Not enough 'all Unsafe' drives ");
                return ERROR;
            }
        }


        if (scalar(@Gr3DataGeo2) == 0 )
        {
            if (scalar(@Gr3DataSataGeo2) > 0)
            {
                $Gr3DataPtrGeo2 = \@Gr3DataSataGeo2;
            }
            else
            {
                logInfo(" Not enough 'group 3 data' drives ");
              return ERROR;
            }
        }


        # now the sata ones

        if (scalar(@evenDataSataGeo2) == 0 )
        {
            if (scalar(@evenDataGeo2) > 0)
            {
                $evenDataSataPtrGeo2 = \@evenDataGeo2;
            }
            else
            {
                logInfo(" Not enough 'even data sata' drives ");
                return ERROR;
            }
        }


        if (scalar(@oddDataSataGeo2) == 0 )
        {
            if (scalar(@oddDataGeo2) > 0)
            {
                $oddDataSataPtrGeo2 = \@oddDataGeo2;
            }
            else
            {
                logInfo(" Not enough 'odd data sata' drives ");
                return ERROR;
            }
        }


        if (scalar(@allDataSataGeo2) == 0 )
        {
            if (scalar(@allDataGeo2) > 0)
            {
                $allDataSataPtrGeo2 = \@allDataGeo2;
            }
            else
            {
                logInfo(" Not enough 'all data sata' drives ");
                return ERROR;
            }
        }


        if (scalar(@allUnsafeSataGeo2) == 0 )
        {
            if (scalar(@allUnsafeGeo2) > 0)
            {
                $allUnsafeSataPtrGeo2 = \@allUnsafeGeo2;
            }
            else
            {
                logInfo(" Not enough 'all Unsafe sata' drives ");
                return ERROR;
            }
        }

        if (scalar(@Gr3DataSataGeo2) == 0 )
        {    
            if (scalar(@Gr3DataGeo2) > 0)
            {
                $Gr3DataSataPtrGeo2 = \@Gr3DataGeo2;
            }
            else
            {
                logInfo(" Not enough 'group 3 data sata' drives ");
                return ERROR;
            }
        }
    } # end of if for destination pdisks grouping
        
    #
    # Now all the pointers point to valid arrays and we should be able to make
    # vdisks at will.
    #
    # All the following use the pointers to the arrays so that we don't worry
    # about empty arrays (since the pointers all point to full ones).
    #

        ################ Disk groups are defined #######################################


    # make the vdisks according to strategy (CreateSingleVdisk)

    #
    # This is done by making arrays for the vdisk's name, size and raid type
    # and then walking the arrays to create the individual vdisks. The
    # content of the arrays is based upon the strategy passed in.
    #

    # We can either set up arrays and create vdisks at the end, or create them on the fly
    # This variable controls the use of the arrays after the if statements. We default to
    # false and set it true when we want the arrays to be used.

    $UseArrays = FALSE;

    debug("in makevdisks  $strategy");

    if ( $strategy == 1 )
    {
        
        ####################
        # 20 small vdisks, raids 0, 1, 5, and 10
        # small - 85 to 210 MB
        # Source vdisks creation on single geolocation
        # multiple groups
        ####################
        $UseArrays = TRUE;

        debug("strategy 1 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19" );

        @Capacity = (    100,   105,  110,  115,  120,
                         125,   130,  135,  140,  145,
                         150,   155,  160,  165,  170,
                         175,   180,  185,  190,  195 );

        @Type = (   RAID_5,  RAID_1,  RAID_5, RAID_10, RAID_10,
                    RAID_1,  RAID_10, RAID_10,  RAID_5,  RAID_5,
                    RAID_5,  RAID_1,  RAID_5, RAID_10,  RAID_1,
                    RAID_10,  RAID_1, RAID_10,  RAID_5, RAID_10 );

        @Stripe = (  64,   0,   8, 256, 512,
                      0, 512, 128,  32,  16,
                     32, 128,   8, 512,   0,
                    128,   0, 256,  64, 256 );

        @Depth =  ( 0,    scalar(@$allUnsafePtrGeo1), 0,   2,    2,
                    scalar(@$evenDataPtrGeo1),    0,     2,   0,    0,
                    0,    0,     0,   2,    3,
                    2,    scalar(@$evenDataSataPtrGeo1),     2,   0,    4 );

        @Parity = ( 3, 0, 3, 0, 0,
                    0, 0, 0, 3, 3,
                    3, 0, 3, 0, 0,
                    0, 0, 0, 3, 0 );

        @Disks =  ( $Gr3DataPtrGeo1,     $allUnsafePtrGeo1,    $allDataPtrGeo1,   $Gr3DataPtrGeo1,    $Gr3DataPtrGeo1,
                    $evenDataPtrGeo1,     $Gr3DataPtrGeo1,    $evenDataPtrGeo1,    $allDataPtrGeo1,    $allDataPtrGeo1,
                    $Gr3DataPtrGeo1,     $allUnsafeSataPtrGeo1,    $allDataPtrGeo1,    $Gr3DataSataPtrGeo1,    $Gr3DataSataPtrGeo1,
                    $Gr3DataSataPtrGeo1,   $evenDataSataPtrGeo1,   $oddDataSataPtrGeo1,    $allDataSataPtrGeo1,   $allDataPtrGeo1 );
    }
    elsif ( $strategy == 2)
    {
         
        ####################
        # 20 small vdisks, raids 0, 1, 5, and 10
        # small - 85 to 210 MB
        # Source vdisks creation on multiple geolocations
        # multiple groups 
        ####################
        
        $UseArrays = TRUE;

        debug("strategy 2 selected");

        @VDMName = (   "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                       "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                       "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                       "VDM15", "VDM16", "VDM17", "VDM18", "VDM19" );

            @Capacity = ( 100,   105,  110,  115,  120,
                          125,   130,  135,  140,  145,
                          150,   155,  160,  165,  170,
                          175,   180,  185,  190,  195 );

            @Type = (  RAID_5,  RAID_1,  RAID_5, RAID_10, RAID_10,
                       RAID_1, RAID_5, RAID_10,  RAID_10,  RAID_5,
                       RAID_5,  RAID_10,  RAID_5, RAID_5,  RAID_1,
                       RAID_10,  RAID_1, RAID_10,  RAID_5, RAID_10 );

          @Stripe = (  64,  0,   8, 256, 512,
                       0, 512, 128,  32,  16,
                       32, 128,   8, 512,   0,
                       128,   0, 256,  64, 256 );

           @Depth =  ( 0,    scalar(@$allUnsafeSataPtrGeo2),     0,   2,    2,
                       3,    0,     2,   2,    0,
                       0,    0,     0,   0,    scalar(@$allUnsafePtrGeo1),
                       2,    scalar(@$allUnsafeSataPtrGeo1),     2,   0,    4 );

          @Parity = ( 3, 0, 3, 0, 0,
                      0, 3, 0, 0, 3,
                      3, 0, 3, 3, 0,
                      0, 0, 0, 3, 0 );

           @Disks =  ( $Gr3DataPtrGeo1,     $allUnsafeSataPtrGeo2,   $allDataPtrGeo1,     $Gr3DataPtrGeo2,       $Gr3DataPtrGeo1,
                       $Gr3DataPtrGeo2,     $Gr3DataSataPtrGeo1,     $evenDataPtrGeo2,    $evenDataPtrGeo1,      $allDataPtrGeo2,
                       $Gr3DataPtrGeo1,     $Gr3DataPtrGeo2,         $allDataPtrGeo1,     $oddDataSataPtrGeo2,   $allUnsafePtrGeo1,
                       $Gr3DataSataPtrGeo2, $allUnsafeSataPtrGeo1,   $oddDataSataPtrGeo2, $allDataSataPtrGeo1,   $allDataPtrGeo2 ); 
    }
    elsif ( $strategy == 3)
    {
        my @originalVdisks;
        my @baseVdisks;
        my @tempVdisks;
        my $ans;
        
        ####################
        # Up to 30 vdisks, RAID_10 and RAID_5 
        # All slightly larger than the largest current existing vdisk
        # Destination (Mirror) vdisks creation on single geolocation
        # multiple groups
        ####################
        $UseArrays = TRUE;

        debug("strategy 3 selected");

        #
        # check if numVdisks was passed in.  
        # If it was, use it.
        # If not, ask user how many vdisks to create
        #
        if (!$numVdisks)
        {
            do
            {
                print "\n\n=====>  Enter the number of vdisks to create as mirrors (1-30): ";
                $ans = <STDIN>;
                chomp ($ans);
            } 
            while ( ($ans < 1) || ($ans > 30) );
        }
        else 
        {
            $ans = $numVdisks;
            if ( ($ans < 1) || ($ans > 30) )
            {
                logInfo(">>>>>>>> Illegal value passed for numVdisks.  Must be 1-30.  <<<<<<<<");
                return ERROR;
            } 
        }

        # 
        # Get the vdisks that currently exist
        #
        %rsp = $controller->virtualDisks();
        if ( ! %rsp  )             
        {
            logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      
        {
            logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
        if ($rsp{COUNT} < 1)
        {
            logInfo(">>>>>>>> No vdisks currently exist <<<<<<<<");
            return ERROR;
        }

        for ($i = 0; $i < $rsp{COUNT}; $i++)
        {
            $originalVdisks[$i] = $rsp{VDISKS}[$i]{VID};
        }

        #
        # Remove any vlinks that may exist
        #
        $ret = TestLibs::BEUtils::RemoveVlinks($controller, \@originalVdisks, \@tempVdisks);  
        if ( $ret  != GOOD )      
        {
            logInfo(">>>>>>>> Error from RemoveVlinks <<<<<<<<");
            return ERROR;
        }
        
        #
        # Remove any currently existing mirrors
        #
        $ret = TestLibs::BEUtils::RemoveMirrors($controller, \@tempVdisks, \@baseVdisks);  
        if ( $ret  != GOOD )      
        {
            logInfo(">>>>>>>> Error from RemoveMirrors <<<<<<<<");
            return ERROR;
        }

        #
        # Find the size of the largest vdisk that is not a mirror or a vlink   
        #
        $maxSize = 0;
        for ($i = 0; $i < $rsp{COUNT}; $i++)
        {
            if ( IsInList( $rsp{VDISKS}[$i]{VID}, \@baseVdisks ) )
            {
                if ( $rsp{VDISKS}[$i]{CAPACITY} > $maxSize )
                {
                    $maxSize = $rsp{VDISKS}[$i]{CAPACITY};
                }
            }
        }

        logInfo("Largest base vdisk found is $maxSize blocks.");

        $maxSize = 1 + int( $maxSize / 2048 );
        
        logInfo("All mirror vdisks created will be $maxSize MB.");

        #
        # Set up max of 30 vdisks
        #
        
        @VDMName = (    "MIR00", "MIR01", "MIR02", "MIR03", "MIR04",
                        "MIR05", "MIR06", "MIR07", "MIR08", "MIR09",
                        "MIR10", "MIR11", "MIR12", "MIR13", "MIR14",
                        "MIR15", "MIR16", "MIR17", "MIR18", "MIR19",
                        "MIR20", "MIR21", "MIR22", "MIR23", "MIR24",
                        "MIR25", "MIR26", "MIR27", "MIR28", "MIR29"  );

        @Capacity = (    $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize  );


            @Type = (    RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                         RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5,
                         RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                         RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5,
                         RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                         RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5  );

            @Stripe = ( 512,  64, 512,  64, 256,
                         32, 256,  32, 128,  16,
                        128,  16, 512,   8, 512,
                          8, 256,  64, 256,  64,
                        128,  32, 128,  32, 512,
                         16, 512,  16, 256,   8  );

            @Depth =  ( 2,   0,   2,   0,   2,
                        0,   2,   0,   2,   0,
                        2,   0,   2,   0,   2,
                        0,   2,   0,   2,   0,
                        2,   0,   2,   0,   2,
                        0,   2,   0,   2,   0  );

            @Parity = ( 0, 3, 0, 3, 0,
                        3, 0, 3, 0, 3,
                        0, 9, 0, 3, 0,
                        3, 0, 3, 0, 3,
                        0, 3, 0, 3, 0,
                        3, 0, 3, 0, 3  );

            @Disks =  ( $Gr3DataPtrGeo2,     $Gr3DataPtrGeo2,      $Gr3DataSataPtrGeo2,  $Gr3DataSataPtrGeo2,  $Gr3DataPtrGeo2,
                        $Gr3DataPtrGeo2,     $Gr3DataSataPtrGeo2,  $Gr3DataSataPtrGeo2,  $oddDataPtrGeo2,      $allDataPtrGeo2,
                        $Gr3DataSataPtrGeo2, $allDataSataPtrGeo2,  $evenDataPtrGeo2,     $Gr3DataPtrGeo2,      $evenDataSataPtrGeo2,
                        $Gr3DataSataPtrGeo2, $allDataPtrGeo2,      $Gr3DataPtrGeo2,      $allDataSataPtrGeo2,  $Gr3DataSataPtrGeo2,
                        $Gr3DataPtrGeo2,     $allDataPtrGeo2,      $Gr3DataSataPtrGeo2,  $allDataSataPtrGeo2,  $Gr3DataPtrGeo2,
                        $Gr3DataPtrGeo2,     $Gr3DataSataPtrGeo2,  $Gr3DataSataPtrGeo2,  $evenDataPtrGeo2,     $Gr3DataPtrGeo2  );
                        
                        
        #
        # Limit the number of vdisks created to the input value by truncating
        # on of the arrays.   
        #
        $#Capacity = $ans - 1;
                                             
        }
        elsif ( $strategy == 7 )
        {
        
            my @originalVdisks;
            my @baseVdisks;
            my @tempVdisks;
            my $ans;
            my %rsp1;
        
            ####################
            # Up to 20 vdisks, RAID_10 and RAID_5 
            # All slightly larger than the largest current existing vdisk
            # Destination (Mirror) vdisks creation on multiple geolocations
            # multiple groups
            ####################
            
            $UseArrays = TRUE;

            debug("strategy 7 selected");

            # 
            # Get the vdisks that currently exist
            #
            
            %rsp1 = $controller->virtualDisks();
            if ( ! %rsp1  )             
            {
                logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
                return ERROR;
            }
            if ( $rsp1{STATUS} != PI_GOOD )      
            {
                logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
                PrintError(%rsp1);
                return ERROR;
            }
            if ($rsp1{COUNT} < 1)
            {
                logInfo(">>>>>>>> No vdisks currently exist <<<<<<<<");
                return ERROR;
            }

            for ($i = 0; $i < $rsp1{COUNT}; $i++)
            {
                $originalVdisks[$i] = $rsp1{VDISKS}[$i]{VID};
            }
        
            #
            # Remove any vlinks that may exist
            #
            
            $ret = TestLibs::BEUtils::RemoveVlinks($controller, \@originalVdisks, \@tempVdisks);  
            if ( $ret  != GOOD )      
             {
                logInfo(">>>>>>>> Error from RemoveVlinks <<<<<<<<");
                return ERROR;
             }
        
            #
            # Remove any currently existing mirrors
            #
            
            $ret = TestLibs::BEUtils::RemoveMirrors($controller, \@tempVdisks, \@baseVdisks);  
            if ( $ret  != GOOD )      
            {
                logInfo(">>>>>>>> Error from RemoveMirrors <<<<<<<<");
                return ERROR;
            }

            #
            # Find the size of the largest vdisk that is not a mirror or a vlink   
            #
            
            $maxSize = 0;
            for ($i = 0; $i < $rsp1{COUNT}; $i++)
            {
                if ( IsInList( $rsp1{VDISKS}[$i]{VID}, \@baseVdisks ) )
                {
                    if ( $rsp1{VDISKS}[$i]{CAPACITY} > $maxSize )
                    {
                        $maxSize = $rsp1{VDISKS}[$i]{CAPACITY};
                    }
                }
            }

            logInfo("Largest base vdisk found is $maxSize blocks.");

            $maxSize = 1 + int( $maxSize / 2048 );
        
            logInfo("All mirror vdisks created will be $maxSize MB.");

            #
            # Set up max of 20 vdisks
            #
            
            @VDMName = ( "MIR00", "MIR01", "MIR02", "MIR03", "MIR04",
                        "MIR05", "MIR06", "MIR07", "MIR08", "MIR09",
                        "MIR10", "MIR11", "MIR12", "MIR13", "MIR14",
                        "MIR15", "MIR16", "MIR17", "MIR18", "MIR19" );

            @Capacity = ( $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize );


            @Type = (  RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                        RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5,
                       RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                        RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5 );

            @Stripe = ( 512,  64, 512,  64, 256,
                         32, 256,  32, 128,  16,
                        128,  16, 512,   8, 512,
                          8, 256,  64, 256,  64 );

            @Depth =  ( 2,   0,   2,   0,   2,
                        0,   2,   0,   2,   0,
                        2,   0,   2,   0,   2,
                        0,   2,   0,   2,   0 );

            @Parity = ( 0, 3, 0, 3, 0,
                        3, 0, 3, 0, 9,
                        0, 3, 0, 3, 0,
                        3, 0, 3, 0, 3 );

            @Disks =  ( $Gr3DataPtrGeo2,     $Gr3DataPtrGeo1,      $Gr3DataSataPtrGeo2,  $Gr3DataSataPtrGeo1,  $Gr3DataPtrGeo2,
                        $Gr3DataPtrGeo1,     $Gr3DataSataPtrGeo2,  $Gr3DataSataPtrGeo1,  $oddDataPtrGeo2,      $allDataPtrGeo1,
                        $oddDataSataPtrGeo2, $allDataSataPtrGeo1,  $evenDataPtrGeo2,     $Gr3DataPtrGeo1,      $evenDataSataPtrGeo2,
                        $Gr3DataSataPtrGeo1, $allDataPtrGeo2,      $Gr3DataPtrGeo1,      $allDataSataPtrGeo2,  $Gr3DataSataPtrGeo1 );
                        
        }
        elsif ( $strategy == 4 )
        {
            my $i;
            my $j;
            my %rsp;
            my @originalVdisks;
            my @baseVdisks;
            my @newVdisks;
            my @newMirrorVdisks;
            my $numBaseVdisksUsed;
            my $baseVdisk;
            my $srcVdisk;
            my @baseVdisksUsed;
            my @tempVdisks;
            my $masterIndex;
       

            print ("Option 4 - Adding Mirrors: \n");

            #########################################
            # Strategy 4 
            #            Add up to 20 mirrors to existing 20 source vdisks. 
            #            All RAID_5 & RAID_10, multiple groups
            #########################################

            #
            # Find the master 
            #
            $masterIndex = FindMaster($objPtr);
            if ( $masterIndex == INVALID ) 
            { 
                logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
                return(ERROR); 
            } 
            $master = $coList[$masterIndex];  

            #
            # Get the VIDs of all the current vdisks
            #
            %rsp = $master->virtualDisks();
            if ( ! %rsp  )              
            {
                logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
                return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      
            {
                logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }
        
            for ($i = 0; $i < $rsp{COUNT}; $i++)
            {
                $originalVdisks[$i] = $rsp{VDISKS}[$i]{VID};
            }

            logInfo("Current vdisks: \n@originalVdisks");
        
            #
            # Remove any vlinks that may exist
            #
            $ret = TestLibs::BEUtils::RemoveVlinks($master, \@originalVdisks, \@tempVdisks);  
            if ( $ret  != GOOD )      
            {
                logInfo(">>>>>>>> Error from RemoveVlinks <<<<<<<<");
                return ERROR;
            }
        
            #
            # Remove any currently existing mirrors
            #
            $ret = TestLibs::BEUtils::RemoveMirrors($master, \@tempVdisks, \@baseVdisks);  
            if ( $ret  != GOOD )      
            {
                logInfo(">>>>>>>> Error from RemoveMirrors <<<<<<<<");
                return ERROR;
            }

            logInfo("Base vdisks (not vlinks or mirrors): \n@baseVdisks");

            #
            # Create new vdisks for new mirrors
            #
        
                $ret = MakeGeoVdisks($objPtr, 7, 0, 0, 0, 0 );
                if ( $ret == ERROR )
                {
                    logError(">>>>> Failed to create new vdisks <<<<<");
                    return (ERROR);
                }

            #
            # Get the VIDs of all the current vdisks again
            #
            %rsp = $master->virtualDisks();
            if ( ! %rsp  )              
            {
                logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
                return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      
            {
                logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }
        
            for ($i = 0; $i < $rsp{COUNT}; $i++)
            {
                $newVdisks[$i] = $rsp{VDISKS}[$i]{VID};
            }

            #
            # Get VIDs of the new mirror vdisks that were created
            #
            for ( $i = 0; $i < scalar(@newVdisks); $i++ )
            {
                if ( 0 == IsInList( $newVdisks[$i], \@originalVdisks ) )
                {
                    push (@newMirrorVdisks, $newVdisks[$i]);
                }
            }

            logInfo("New vdisks created to be mirrors: \n@newMirrorVdisks");

            #
            # Wait until all raids have completed initialization.
            #
            $ret = TestLibs::BEUtils::WaitOnNewerInits( $master, \@originalVdisks );
            if ( $ret != GOOD ) 
            {
                logInfo(">>>>>>>> Error from WaitOnNewerInits command <<<<<<<<");
                return ERROR;
            }

            #
            # Assign the new vdisks as mirrors to random baseVdisks
            #
            logInfo("Setting up mirrors....");  
            
            for ( $i = 0; $i < scalar(@newMirrorVdisks); $i++ )
            {
                                                     # src             dest
                %rsp = $master->virtualDiskControl(0x03, $originalVdisks[$i], $newMirrorVdisks[$i]);
                
                if (!%rsp)                        # no response
                {
                    logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                    return ERROR;
                }

                if ($rsp{STATUS} != PI_GOOD)            # 1 is bad
                {
                    logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                    PrintError(%rsp);
                    return ERROR;
                }
                else
                {
                    logInfo("Vdisk $newMirrorVdisks[$i] is now a mirror of vdisk $newMirrorVdisks[$i]");  
                }
            }
            
            return GOOD;
 
        }
        else
        {
            #########################
            # you have chosen badly
            #########################
            logWarning(">>>>> Unavailable strategy specified ($strategy). Sorry, no vdisks created. <<<<<");
            return ERROR;
        }


    # figure out how many to make, based upon smallest array size. This helps
    # when we miscount the number of elements in an array.
    $numberToCreate = min( scalar(@VDMName), min(scalar(@Capacity), scalar(@Type) ) );
    $numberToCreate = min( $numberToCreate,  min(scalar(@Stripe),   scalar(@Depth) ) );
    $numberToCreate = min( $numberToCreate,  min(scalar(@Parity),   scalar(@Disks) ) );

    logInfo("to create $numberToCreate \n @VDMName \n @Capacity \n @Type");

    my $numberNew = 0;

    if ( $UseArrays == TRUE )
    {
        # now actually make the vdisks
        for(my $r = 0; $r < $numberToCreate; $r++)
        {

            if (  ($Stripe[$r] < 128) && ($Type[$r] == 4) )
            {
                $Stripe[$r] = 128;
            }

            debug("creating vdisk using  $VDMName[$r], $Capacity[$r] MB, $Type[$r]");
            
            # Capacity is in MBs, call is in GBs
            $ret = CreateSingleVdisk($controller, $VDMName[$r], $Capacity[$r], $Type[$r],
                                           $Stripe[$r], $Depth[$r], $Parity[$r],  $Disks[$r] );

            if ( $ret == INVALID )
            {                                                                            #
                logWarning(">>>>> Failed creating $r th Vdisk <<<<<");
                return (ERROR);
            }

            push (  @newVdisks, $ret );  # save new vdisk number
            $numberNew++;
        }
    }

    # make sure we have created some vdisks for the rest to be done

    if ( $numberNew == 0 )
    {
        # no vdisks were created, so nothing more to do
        return GOOD;
    }

    if (  ($option & NO_RAID_INIT)  == 0 )
    {
        if ( ERROR == InitializeSomeVdisks( $controller, \@newVdisks ) )
        {
            logWarning(">>>>> Failed initializing vdisks. <<<<<");
            return (ERROR);
        }
    }

    return GOOD;
 
}

##############################################################################
#
#          Name: GeoVdiskMenu
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub GeoVdiskMenu
{
    trace();

    my( $ctlr, $wwn, $ipPtr ) = @_;

    my $ret;
    my $option;
    my $mirrortype1 = 2;
    my $mirrortype2 = 4;
    my $mirrortype3 = 3;
    my $mirroroption;

    print "\n\n";
    print "##################################################################################\n";
    print "############################# Vdisk Create menu ##################################\n";
    print "\n";
    print "  1) 20 source vdisks on one geolocation, raids 0,1,5,10 multiple groups  \n";
    print "  2) 20 source vdisks on multiple geolocations, 0,1,5,10 multiple groups \n";
    print "  3) Create Destination [Mirror] vdisks \n";
    print "  4) 20 source vdisks on user specified geolocation, 0,1,5,10 multiple groups \n";
    print " 99) Exit Menu \n";
    print "\n\n Select an option: ";
    
    my $ans = <STDIN>;
    chomp ($ans);

    $option = $ans;

    print "\n\n";

    # now call functions based upon the option

    if ( $option == 99 )
    {
        return GOOD;
    }
    
    if ( $option == 1 || $option == 2 )
    {
        $ret = MakeGeoVdisks($ctlr, $option, 0, 0, 0, 0);
        
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to configure system: MakeGeoVdisks <<<<<<<<");
        }
    }
    
    if ($option == 3)
    {
        print " \n";
        print "********************************************************************************\n";  
        print "******************************** Mirror Menu ***********************************\n"; 
        print "  1) Create Destination [Mirror] vdisks on a geolocation \n";
        print "  2) Create Destination [Mirror] vdisks on multiple geolocations \n";
        print "  3) Create Destination [Mirror] vdisks on user specified geolocation \n";
        print " 99) Exit Menu \n";
        print "\n\n Select an option: ";

        my $opt = <STDIN>;

        chomp ($opt);

        $mirroroption = $opt;

        print "\n\n";
        
        if ( $mirroroption == 99 )
        {
            return GOOD;
        }
        
        if ( $mirroroption == 1 )
        {
            $ret = BasicConfig( $ctlr,  55, $ipPtr, $wwn,  0, $mirrortype1 );
            
            if ( $ret == ERROR )
            {
                logError(">>>>>>>> Failed to configure system: BasicConfig <<<<<<<<");
            }
        }    
        
        if ( $mirroroption == 2 )
        {
            $ret = MakeGeoVdisks($ctlr, $mirrortype2, 0, 0, 0, 0);
            
            if ( $ret == ERROR )
            {
                logError(">>>>>>>> Failed to configure system: MakeGeoVdisks <<<<<<<<");
            }
        }    
        if ( $mirroroption == 3 )
        {
            print "Enter destination geolocation ID: ";
            my $destgeoid = <STDIN>;

            chomp ($destgeoid);
        
            if ( ($destgeoid >= 1) && ($destgeoid <= 255) )
            {
                $ret = BasicConfig( $ctlr,  55, $ipPtr, $wwn,  0, $mirrortype3, $destgeoid );
            
                if ( $ret == ERROR )
                {
                    logError(">>>>>>>> Failed to configure system: BasicConfig <<<<<<<<");
                }
            }
            else
            {
                logError(">>>>>>>> destination geolocation value is invalid : $destgeoid <<<<<<<<");
                return ERROR;
            }
        }
    }
    
    if ( $option == 4 )
    {
        print "Enter source geolocation ID: ";
        my $srcgeoid = <STDIN>;

        chomp ($srcgeoid);
        
        if ( ($srcgeoid >= 1) && ($srcgeoid <= 255) )
        {

            $ret = MakeGeoVdisks($ctlr, 1, 0 , 0, $srcgeoid, 0);
        
            if ( $ret == ERROR )
            {
                logError(">>>>>>>> Failed to configure system: MakeGeoVdisks <<<<<<<<");
            }
        }     
        else
        {
            logError(">>>>>>>> source geolocation value entered is invalid : $srcgeoid <<<<<<<<");
            return ERROR;
        }
    }
    return GOOD;
}

##############################################################################
#
#          Name: GeoConfig
#
#        Inputs: controller object, strategy and WWNs pointer 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: User can use one of the startegies to configure a N-way system
#
##############################################################################
sub GeoConfig
{
    trace();
    
    my ( $objPtr, $strategy, $wwn ) = @_;

    my $i;
    my $j;
    my $ret;
    my $master;
    my $baycount;
    my $masterIndex;
    my @coList;
    my @bayId;
    my %bays;

    @coList = @$objPtr;
    
    $master = $coList[0];     # controller objects
    
        if ( $strategy == 1 )
        {

            logInfo ("Georaid configuration type 1 strategy 1 selected \n");

            #########################################
            # Strategy 1 
            #            Label_14
            #            20 small raids 0, 1, 5, 10, multiple groups
            #            Source vdisks creation on single geolocation
            #            Server_Map   BUT selects servers using WWN
            #########################################

            $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to label the drives <<<<<");
                return (ERROR);
            }
            
            $ret = GeoLocationConfig($master);
            
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to configure geolocation <<<<<");
                return (ERROR);
            }
            
            $ret = MakeNWay($objPtr);
            
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to create the VCG <<<<<");
                return (ERROR);
            }

            $masterIndex = FindMaster($objPtr);
            if ( $masterIndex == INVALID ) 
            { 
                logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
                return(ERROR); 
            } 
            $master = $coList[$masterIndex];  

            $ret = MakeGeoVdisks($objPtr, 1, 0, 0, 0, 0);
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to create new vdisks <<<<<");
                return (ERROR);
            }

            GetSIDs( $master, 0 );   # show sids to user

            $ret = PromptUser( 3 );

            $ret = AssociateServers($master, 2, $wwn);
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to associate drives to servers <<<<<");
                return (ERROR);
            }
            # now we have vdisks, all have owners, all are initialized. Tell
            # user thay can start IO.

            $ret = PromptUser( 7 );

        }
        elsif ( $strategy == 2 )
        {

            logInfo ("Georaid configuration type 2 strategy 2 selected \n");

            #########################################
            # Strategy 2 
            #            Label_14
            #            20 small raids 0, 1, 5, 10, multiple groups
            #            source vdisks creation on multiple geolocations
            #            Server_Map   BUT selects servers using WWN
            #########################################

            $ret = LabelAllDrives($master, 10, 2, 2, 0, 0);     # for 14 drive bays
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to label the drives <<<<<");
                return (ERROR);
            }

            $ret = GeoLocationConfig($master);
            
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to configure geolocation <<<<<");
                return (ERROR);
            }
            
            $ret = MakeNWay($objPtr);

            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to create the VCG <<<<<");
                return (ERROR);
            }

            $masterIndex = FindMaster($objPtr);
            if ( $masterIndex == INVALID ) 
            { 
                logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
                return(ERROR); 
            } 
            $master = $coList[$masterIndex];  

            $ret = MakeGeoVdisks($objPtr, 2, 0, 0, 0, 0);
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to create new vdisks <<<<<");
                return (ERROR);
            }

            GetSIDs( $master, 0 );   # show sids to user

            $ret = PromptUser( 3 );

            $ret = AssociateServers($master, 2, $wwn);
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to associate drives to servers <<<<<");
                return (ERROR);
            }
            # now we have vdisks, all have owners, all are initialized. Tell
            # user thay can start IO.

            $ret = PromptUser( 7 );

        }
        else
        {
            #########################
            # you have chosen badly
            #########################
            logWarning(">>>>> Unavailable strategy specified ($strategy). Sorry, no vdisks created. <<<<<");
            return ERROR;
        }
        
    return GOOD;
}        
            
##############################################################################
#
#          Name: GeoLocationConfig
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This routine will group divebays and set geolocation.
#
##############################################################################
sub GeoLocationConfig
{
    trace();
    
    my ( $master ) = @_;

    my $i;
    my $j;
    my $ret;
    my $geobaycount;
    my $baycount;
    my %bays;
        
        logInfo ("Grouping the drivebays and setting geolocation \n");
        
        # get the diskbays information and find the count 
        
        %bays = $master->diskBays();
    
        $baycount = $bays{COUNT};
            
        if ( $baycount == 1 )
        {
            # when there is a single drive bay return warning 
                
            logWarning(">>>>>> Go find some more bays <<<<<<<<");
            return (ERROR);
        }
        elsif ( $baycount % 2 == 1 )
        {
            # when there are odd number of drivebays, then grouping is done 
            # such a way that one geolocation will have odd number of drivebays 
            # and second geolocation will have even number of drivebays. 
              
            $geobaycount = floor($baycount / 2) + 1;
        }
        else 
        {
            # when there are even number of drivebays then grouping is done 
            # such a way that each geolocation will have equal number of drivebays. 
              
            $geobaycount = $baycount / 2;
        }
            
        for ( $i = 0; $i < $geobaycount; $i++ )
        {   
            print "\n\n";
                
            
            $ret = ConfigGeoLocation ($master, $bays{BAYS}[$i]{PD_BID}, GL_ID1 );
                
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to set geolocation on bay <<<<<");
                return (ERROR);
            }
        }
            
        for ($j = $geobaycount; $j < $baycount; $j++)
        {
            print "\n\n";
                
            $ret = ConfigGeoLocation ($master, $bays{BAYS}[$j]{PD_BID}, GL_ID2 );
                
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to set geolocation on bay <<<<<");
                return (ERROR);
            }
        }
        
    return GOOD; 
}        

##############################################################################
#
#          Name: GeoDegradeCheck
#
#        Inputs: controller object
#
#       Outputs: GOOD if none degraded,
#                INVALID if some degraded,
#                ERROR if we get an error
#
#  Globals Used: none
#
#   Description: Look at the vdisks that are in the operating state and ignore
#                the vdisks which are inoperative
#
#
##############################################################################
sub GeoDegradeCheck
{
    trace();
    my ( $ctlr ) = @_;

    my %rsp;
    my $i;

    # use 'devstat pd'

    %rsp = $ctlr->deviceStatus("PD");

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from deviceStatus <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get device status <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    # now we have the data, let's look at it

    for $i (0..$#{$rsp{LIST}})
    {

        #
        # Skip all drives that are not currently operable
        #
        if (  $rsp{LIST}[$i]{PD_DEVSTAT} == 0x10  )
        {
            #
            # Check to see if the drive is degraded
            #
            if ( ( $rsp{LIST}[$i]{PD_MISCSTAT} & 0x03 ) != 0 )
            {
                print "PDD # $rsp{LIST}[$i]{PD_PID} is still rebuilding",
                      " (MISCSTAT = $rsp{LIST}[$i]{PD_MISCSTAT})",
                      " (CLASS = $rsp{LIST}[$i]{PD_CLASS}) \r";
                return INVALID;
            }

        }
     }

    # now also check the raids and make sure they are all operable


    %rsp = $ctlr->raids();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    for (my $i = 20; $i < $rsp{COUNT}; $i++)
    {
        #$output .= sprintf("%3hu  0x%2.2x     0x%2.2x  %3d  %14s  %4d  %5d\n",
        #                   $rsp{RAIDS}[$i]{RID},
        #                   $rsp{RAIDS}[$i]{TYPE},
        #                   $rsp{RAIDS}[$i]{DEVSTAT},
        #                   $rsp{RAIDS}[$i]{VID},
        #                   $rsp{RAIDS}[$i]{CAPACITY},
        #                   $rsp{RAIDS}[$i]{PCTREM},
        #                   $rsp{RAIDS}[$i]{FRCNT});

        # make sure they are all operational
        if ( $rsp{RAIDS}[$i]{DEVSTAT} != 0x10 )
        {
            # this one was not operational, return INVALID
            logInfo("Raid $rsp{RAIDS}[$i]{RID} was not operational.".
                    " (status =$rsp{RAIDS}[$i]{DEVSTAT})" );
            return INVALID;
        }

    }

    logInfo("Drives have completed rebuild");

    return GOOD;    # none were degraded
}

##############################################################################
#
#          Name: UnfailGeoPdisk
#
#        Inputs: controller object, failed pdisk, array of destination pdisks,
#                ses, slot
#
#       Outputs: GOOD if none degraded,
#                INVALID if some degraded,
#                ERROR if we get an error
#
#  Globals Used: none
#
#   Description: unfail the pdisk and do validations.
#
##############################################################################
sub UnfailGeoPdisk    
{

    trace();
    my ( $ctlr, $pdisk , $destpdisks, $ses, $slot, $lid, $port) = @_;
    
    my %rsp;
    my $ret;
    my %pdiski;
    my $useLidFlag = TRUE;
    my $i;
    
    if  ( !defined($slot) || !defined($ses) )
    {
        logInfo("Error, bypassed drive, but no ses/slot information.");
        return ERROR;
    } 

    logInfo("Unbypassing drive at slot $slot, ses $ses.");

    %rsp = $ctlr->physicalDiskBypass($ses, $slot, 0);    # 0 is unbypass
       
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDiskBypass <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to restore drive $pdisk. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }
        
    # now this takes a few seconds, so let's wait for ses

    DelaySecs(15);
        
    if ( $useLidFlag == TRUE )
    {
        logInfo("LIP reset on the drive.");
        # we have a loop id to use, send a LIP to the device 
        $ret = TestLibs::BEUtils::LipResetDevice( $ctlr, $pdisk, $port, $lid);
    }
        
    DelaySecs(10);

    logInfo("Drives have completed rebuild");

    Wait4Ses(  $ctlr, 15 );

    $pdisk = FindGeoPdId( $ctlr, $destpdisks, $ses, $slot );
        
    if($pdisk == INVALID)
    {
        logInfo(">>>>>>>> Unable to determine Pid for drive SES = $ses, Slot = $slot. <<<<<<<<");  
        return ERROR;
    } 
    return GOOD;    # none were degraded
}


##############################################################################
#
#          Name: FindGeoPdId
#
#        Inputs: controller object, array of destination pdisks,
#                ses, slot
#
#       Outputs: GOOD if none degraded,
#                INVALID if some degraded,
#                ERROR if we get an error
#
#  Globals Used: none
#
#   Description: find the pid of unfailed pdisk.
#
##############################################################################
sub FindGeoPdId
{
    my ( $ctlr, $pdisk , $destpdisks, $ses, $slot, $lid, $port) = @_;
    
    trace();
    
    my $i;
    my $j;
    my $okData = 0;
    my $badDataCount = 0;
    my @destpdisks = @$destpdisks;
    my %rsp;
    my $ret;
    my %pdiski;
    my $useLidFlag = TRUE;

    if  ( !defined($slot) || !defined($ses) )
    {
        logInfo("Error, bypassed drive, but no ses/slot information.");
        return ERROR;
    }   
    
    while ( $okData == 0 )
    {
        
        # have we been down this path too many times?
        if ( $badDataCount > 30 )
        {
            logInfo(" Failure: Too many attempts for getting SES data. ");
            return INVALID;
        }
        
        my %drives = $ctlr->physicalDisks();  # get list of drives present

        if ( ! %drives  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDisks, retrying <<<<<<<<");
            $badDataCount++;
            next;
        }
        if ($drives{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error from physicalDisks, retrying <<<<<<<<");
            $badDataCount++;
            next;
        }

        $okData = 1;

        print "Looking for SES $ses and SLOT $slot on $drives{COUNT} drives\n";

        for ( $i = 0; $i < $drives{COUNT}; $i++)     # for each drive
        {
           for ($j = 0; $j < scalar(@destpdisks); $j++)
           {
                if ( $drives{PDISKS}[$i]{PD_PID} == $destpdisks[$j] ) # if the drive is in destination geolocation
                {
                    print "Checking drive $i, PID $drives{PDISKS}[$i]{PD_PID},";
                    print " SES $drives{PDISKS}[$i]{SES}, SLOT $drives{PDISKS}[$i]{SLOT} \n";
 
                    # make sure we have valid SES/SLOT information, if not, retry
                    if (  ( 65535  == $drives{PDISKS}[$i]{SES})  ||   ( 255  == $drives{PDISKS}[$i]{SLOT} ) )
                    {
                        # data was bad, SES info not ready, try again
                
                        $badDataCount++;
                
                        logInfo(" SES data was not ready, pause and retry ");
                        sleep (1);
                        $okData = 0;
                        last;
                    }
        
                    if (($drives{PDISKS}[$i]{SES} == $ses) && ($drives{PDISKS}[$i]{SLOT} == $slot))  # if drive is good
                    {
                        print "found it!\n";
                        return $drives{PDISKS}[$i]{PD_PID} ;
                    }
                }    
            }     
        }

        logInfo("Unbypassing drive at slot $slot, ses $ses.");

        %rsp = $ctlr->physicalDiskBypass($ses, $slot, 0);    # 0 is unbypass
       
        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskBypass <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to restore drive $pdisk. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
        
        # now this takes a few seconds, so let's wait for ses

        DelaySecs(15);
        
        if ( $useLidFlag == TRUE )
        {
            logInfo("LIP reset on the drive.");
            # we have a loop id to use, send a LIP to the device 
            $ret = TestLibs::BEUtils::LipResetDevice( $ctlr, $pdisk, $port, $lid);
        }
        
        DelaySecs(10);

        Wait4Ses(  $ctlr, 15 );

        $pdisk = FindGeoPdId( $ctlr, $destpdisks, $ses, $slot );
        
        if($pdisk == INVALID)
        {
            logInfo(">>>>>>>> Unable to determine Pid for drive SES = $ses, Slot = $slot. <<<<<<<<");  
            return ERROR;
        }
	} 
}

##############################################################################
#
#          Name: FindGeoPdId
#
#        Inputs: controller object, array of destination pdisks,
#                ses, slot
#
#       Outputs: GOOD if none degraded,
#                INVALID if some degraded,
#                ERROR if we get an error
#
#  Globals Used: none
#
#   Description: find the pid of unfailed pdisk.
#
##############################################################################
#sub FindGeoPdId
#{
#    my ( $ctlr, $pdisks, $ses, $slot ) = @_; 
#    
#    my $i;
#    my $j;
#    my $okData = 0;
#    my $badDataCount = 0;
#    my @destpdisks = @$pdisks;
#
#     
#    
#    while ( $okData == 0 )
#    {
#        
#        # have we been down this path too many times?
#        if ( $badDataCount > 30 )
#        {
#            logInfo(" Failure: Too many attempts for getting SES data. ");
#            return INVALID;
#        }
#        
#        
#        my %drives = $ctlr->physicalDisks();  # get list of drives present
#
#        if ( ! %drives  )
#        {
#            logInfo(">>>>>>>> Failed to get response from physicalDisks, retrying <<<<<<<<");
#            $badDataCount++;
#            next;
#        }
#        if ($drives{STATUS} != PI_GOOD)
#        {
#            logInfo(">>>>>>>> Error from physicalDisks, retrying <<<<<<<<");
#            $badDataCount++;
#            next;
#        }
#
#        $okData = 1;
#
#
#        print "Looking for SES $ses and SLOT $slot on $drives{COUNT} drives\n";
#
#        for ( $i = 0; $i < $drives{COUNT}; $i++)     # for each drive
#        {
#           for ($j = 0; $j < scalar(@destpdisks); $j++)
#           {
#                if ( $drives{PDISKS}[$i]{PD_PID} == $destpdisks[$j] ) # if the drive is in destination geolocation
#                {
#                    print "Checking drive $i, PID $drives{PDISKS}[$i]{PD_PID},";
#                    print " SES $drives{PDISKS}[$i]{SES}, SLOT $drives{PDISKS}[$i]{SLOT} \n";
# 
#                    # make sure we have valid SES/SLOT information, if not, retry
#                    if (  ( 65535  == $drives{PDISKS}[$i]{SES})  ||   ( 255  == $drives{PDISKS}[$i]{SLOT} ) )
#                    {
#                        # data was bad, SES info not ready, try again
#                
#                        $badDataCount++;
#                
#                        logInfo(" SES data was not ready, pause and retry ");
#                        sleep (1);
#                        $okData = 0;
#                        last;
#                    }
#        
#        
#                    if (($drives{PDISKS}[$i]{SES} == $ses) && ($drives{PDISKS}[$i]{SLOT} == $slot))  # if drive is good
#                    {
#                        print "found it!\n";
#                        return $drives{PDISKS}[$i]{PD_PID} ;
#                    }
#                }    
#            }     
#        }
#
#    }
#    return INVALID; 
#}


##############################################################################

1;   # we need this for a PM

##############################################################################
=head1 CHANGE       LOG
        
##############################################################################
# Change log:
# $Log$
# Revision 1.6  2006/05/25 16:52:07  ElvesterN
# Removed diff markers, made some code changes for re-used
# variables, commented second instance of FindGeoPdId sub
#
# Revision 1.5  2006/05/24 07:51:30  EidenN
# Moved from 750 Branch
#
# Revision 1.2.2.2  2006/03/10 13:58:25  HoltyB
# TBolt00000000:Merged with HEAD
#
# Revision 1.2.2.1  2006/02/24 14:17:25  MiddenM
# Merge from WOOKIEE_EGGS_GA_BR into MODEL750_BR
#
# Revision 1.4  2006/02/27 04:27:35  AnasuriG
# Added code for creation vdisks based on user choice georaid
#
# Revision 1.3  2006/01/20 08:19:10  AnasuriG
# Updated GeoVdisks subroutine for grouping SATA disks
#
# Revision 1.4  2006/02/27 04:27:35  AnasuriG
# Added code for creation vdisks based on user choice georaid
#
# Revision 1.3  2006/01/20 08:19:10  AnasuriG
# Updated GeoVdisks subroutine for grouping SATA disks
#
# Revision 1.2  2006/01/10 09:59:36  AnasuriG
# Added option for user to create vdisks on his choice of geolocation
#
# Revision 1.1  2006/01/09 12:06:42  AnasuriG
# New File Created for Georaid Integration testing
#
#
##############################################################################
