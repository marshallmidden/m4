#$Id: sanscriptET.pm 4298 2005-05-04 18:53:47Z RysavyR $
##############################################################################
# File name:  XIOtech::sanscriptET
#
# Desc: Perl wrapper library for the java cli to facilitate scripting the
#       XIOtech SAN product suites with perl.
#       The set of commands in this package for test use only.
#
#       This file must not be distributed to customers.
#
# Date: 03/14/2003
#
# Original Author:  Keith House
#
# Last modified by  $Author: RysavyR $
# Modified date     $Date: 2005-05-04 13:53:47 -0500 (Wed, 04 May 2005) $
#
# Copyright XIOtech Corporation 2001-2003
#
##############################################################################
package XIOtech::sanscriptET;

use XIOtech::sanscript;

=head1 NAME

XIOtech::sanscriptET - Perl commands to manage XIOtech Storage Devices for Engineering Test

Copyright XIOtech Corporation 2001-2003

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

use sanscript;

This document describes basic usuage of the commands to manage a XIOtech Storage Device.
These commands are for Engineering Test only.

=head1 DESCRIPTION

sanscriptET is a Perl module that allows configuration and mamagement of
XIOtech storage device.

=begin html

<img src="logo_xiotech_normal.gif">

=end html

=cut

require Exporter;
@ISA       = qw(Exporter);
@EXPORT_OK = qw(
                XSSAreboot
                versionApply
                );

#Some local variables to this package
my $VCGID = -1; # the vcg ID commands should be associated with
my $ERROR = 0;  # error code of command
my $ERROR_STRING; # error message
my $SOCKET; # socket for communcating to the scriptAgent proxy
my $CONNECTED = 0; # boolean for "Are we connected?"
my $PORT = 10000; # what port to use, can be adjusted by the user

use strict;
use Socket;
use IO::Handle;
use Carp;

# Command hash

my %cmd =(
          VERSIONAPPLY              => "versionapply",
          XSSA                      => "xssa"
          );

##############################################################################
#
#  TEST ONLY Commands
#
#############################################################################

=head1 B<TEST ONLY Commands>

=cut
##############################################################################
# Name: versionApply
#
# Desc: Applies a version of firmware to cnc
#
# In:   $versionID
#
# Returns:  1 on success, 0 on failure
##############################################################################
sub versionApply
{
    my ($parm1) = XIOtech::sanscript::_getArgs(1, @_);

    if (defined(XIOtech::sanscript::_executeAndParse("$cmd{VERSIONAPPLY} \"$parm1\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 versionApply

Applies a version of XSSA code or firmware code.

=over 1

=item Usage:

 if (versionApply("1.2"))
 {
     print "The version was applied\n";
 }

=item Returns:

=back

=begin html

<UL>
<LI>1 on success</LI>
<LI>0 on failure</LI>
</UL>

=end html

=cut
##############################################################################
# Name: XSSAreboot
#
# Desc: reboots the XSSA
#
# Returns:  1 on success, 0 on error
##############################################################################
sub XSSAreboot
{
    if (defined(XIOtech::sanscript::_executeAndParse("$cmd{XSSA} reboot")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 XSSAreboot

Reboots the XSSA

=over 4

=item Usage:

 if (XSSAreboot())
 {
     print "XSSA is rebooting\n";
 }
 else
 {
     print "Failed to reboot the XXSA" . errorString() . "\n";
 }

=item Returns:

=back

=begin html

<UL>
<LI>1 on success</LI>
<LI>0 on failure</LI>
</UL>

=end html

=cut

# CUT_HERE

=head1 Author

Keith A. House: housek@xiotech.com

=cut

1;