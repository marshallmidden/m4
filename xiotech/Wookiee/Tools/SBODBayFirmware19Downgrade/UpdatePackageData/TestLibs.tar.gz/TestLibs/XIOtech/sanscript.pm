#$Id: sanscript.pm 5051 2005-09-19 17:33:37Z EidenN $
##############################################################################
# File name:  XIOtech::sanscript
#
# Desc: Perl wrapper library for the java cli to facilitate scripting the
#       Xiotech SAN product suites with perl.
#
# Date: 01/09/2001
#
# Original Author:  Tony Asleson
#
# Last modified by  $Author: EidenN $
# Modified date     $Date: 2005-09-19 12:33:37 -0500 (Mon, 19 Sep 2005) $
#
# Copyright Xiotech Corporation 2001-2005
#
##############################################################################
package XIOtech::sanscript;

=head1 NAME

XIOtech::sanscript - Perl commands to manage Xiotech Storage Devices

Copyright Xiotech Corporation 2001-2005

=head1 SUPPORTED PLATFORMS

=over 4

=item *

Linux

=item *

Windows

=item *

Novell Netware

=back

=head1 SYNOPSIS

This document describes basic usage of the commands to manage a Xiotech Storage Device

 use XIOtech::sanscript;
 use XIOtech::sanscript(port => 10001);

The default port that sanscript.pm will talk to the scriptAgent on is 10000.  If there is a conflict, the port
the scriptAgent is listening on can be changed with the parameter: -Dport=10001.  See the scriptAgent.sh or the
scriptAgent.bat file for details.

 use XIOtech::sanscript;
 use strict;
 use warnings;

 my $SN = 10214;

 if (!XIOdeviceSet($SN))
 {
     print "XIOdeviceset() failed\n";
     print errorString() . "\n";
     print errorCode() . "\n";
     exit -1;
 }

 my %san = cncInfo($SN);

 if (%san)
 {
     print "\ncncInfo() returned\n\n";

     while ((my $k, my $v) = each %san)
     {
         print "$k = $v\n";
     }
     print "\n";
 }

 if (reserve())
 {
     print "reserve() worked\n";
 }
 else
 {
     print "reserve() failed\n";
     print errorString() . "\n";
     exit -1;
 }

 exit 0;

=head1 DESCRIPTION

sanscript is a Perl module that allows configuration and management of
Magnitude and Magnitude 3D via the ICON.

=cut

=head1 Command Catagories

L</Bay Commands>
 E<verbar> L</Cluster Commands>
 E<verbar> L</Common Commands>
 E<verbar> L</Copy Commands>
 E<verbar> L</Disk Group Commands>
 E<verbar> L</Geo Pool Commands>
 E<verbar> L</HAB Commands>
 E<verbar> L</Newport Commands>
 E<verbar> L</Physical Disk Commands>
 E<verbar> L</Server Commands>
 E<verbar> L</Vblock Commands>
 E<verbar> L</Virtual Disk Commands>
 E<verbar> L</Virtual Link Commands>
 E<verbar> L</VPort Commands>
 E<verbar> L</Workport Commands>
 E<verbar> L</Workset Commands>

=cut

require Exporter;
@ISA    = qw(Exporter);
@EXPORT = qw(bayBeacon
             bayCount
             bayInfo
             bayList
             changePort
             copyInfo
             copyReverse
             copySetDescription
             copyTerminate
             clusterSet
             diskgroupAdd
             diskgroupInfo
             diskgroupName
             diskgroupRemove
             diskgroupSet
             defragAll
             dscShutdown
             environment
             errorCode
             errorString
             geopoolAdd
             geopoolInfo
             geopoolRemove
             habAssign
             habList
             habUnassign
             info
             logs
             newportInfo
             newportInfo
             newportList
             pdiskBeacon
             pdiskCount
             pdiskDefrag
             pdiskInfo
             pdiskLabel
             pdiskList
             reserve
             serverDelete
             serverInfo
             serverList
             serverName
             unreserve
             vblockAdd
             vblockList
             vblockRemove
             vblockSet
             vdiskAbort
             vdiskBeacon
             vdiskCopy
             vdiskCopyAbort
             vdiskCopyPause
             vdiskCopyResume
             vdiskCopyStatus
             vdiskCopySwap
             vdiskCreate
             vdiskDelete
             vdiskErase
             vdiskExpand
             vdiskInfo
             vdiskList
             vdiskLock
             vdiskMask
             vdiskMaxCapacity
             vdiskMove
             vdiskMirror
             vdiskMirrorBreak
             vdiskName
             vdiskPause
             vdiskResume
             vdiskSwap
             vdiskUnlock
             vdiskUnmask
             vdiskWriteCache
             versionApply
             vlinkCount
             vlinkCreate
             vlinkList
             vportList
             workportCreate
             workportDelete
             workportInfo
             workportList
             workportName
             workset
             worksetList
             writeCache
             XIOdeviceList
             XIOdeviceSet
             XIOtechVersion
             );

use constant DEFAULT_PORT => 10000; # default port we use to talk to the script agent
#Some local variables to this package
my $VCGID = -1; # the vcg ID commands should be associated with
my $ERROR = 0;  # error code of command
my $ERROR_STRING; # error message
my $SOCKET; # socket for communcating to the scriptAgent proxy
my $CONNECTED = 0; # boolean for "Are we connected?"
my $PORT = DEFAULT_PORT; # what port to use, can be adjusted by the user
my %CONNECTION_HASH = {}; # key = address, value = socket

sub import
{
    my $pack = shift;
    my $callpkg = caller(0);
    my %hash = @_;

    while((my $k, my $v) = each %hash)
    {
        if ($k eq "port")
        {
            $PORT = $v;
        }
    }
    Exporter::export($pack, $callpkg, @EXPORT_OK);
}

use strict;
use Socket;
use IO::Handle;

# Command hash

my %cmd =(
          BAYBEACON          => "baybeacon",
          BAYCOUNT           => "baycount",
          BAYINFO            => "bayinfo",
          BAYLIST            => "baylist",
          COPYINFO           => "copyinfo",
          COPYREVERSE        => "copyreverse",
          COPYTERMINATE      => "copyterminate",
          COPYSETDESCRIPTION => "copysetdescription",
          CLUSTERSET         => "clusterset",
          INFO               => "info",
          DISKGROUPADD       => "diskgroupadd",
          DISKGROUPINFO      => "diskgroupinfo",
          DISKGROUPNAME      => "diskgroupname",
          DISKGROUPREMOVE    => "diskgroupremove",
          DISKGROUPSET       => "diskgroupset",
          DEFRAGALL          => "defragall",
          DSCSHUTDOWN        => "dscshutdown",
          ENVIRONMENT        => "environment",
          GEOPOOLADD         => "geopooladd",
          GEOPOOLINFO        => "geopoolinfo",
          GEOPOOLREMOVE      => "geopoolremove",
          HABASSIGN          => "habassign",
          HABLIST            => "hablist",
          HABUNASSIGN        => "habunassign",
          LOGS               => "logs",
          NEWPORTINFO        => "newportinfo",
          NEWPORTLIST        => "newportlist",
          PDISKBEACON        => "pdiskbeacon",
          PDISKCOUNT         => "pdiskcount",
          PDISKDEFRAG        => "pdiskdefrag",
          PDISKINFO          => "pdiskinfo",
          PDISKINFOLIST      => "pdiskinfolist",
          PDISKLABEL         => "pdisklabel",
          PDISKLIST          => "pdisklist",
          RESERVE            => "reserve",
          SERVERDELETE       => "serverdelete",
          SERVERINFO         => "serverinfo",
          SERVERLIST         => "serverlist",
          SERVERNAME         => "servername",
          UNRESERVE          => "unreserve",
          VBLOCKADD          => "vblockadd",
          VBLOCKLIST         => "vblocklist",
          VBLOCKREMOVE       => "vblockremove",
          VBLOCKSET          => "vblockset",
          VDISKBEACON        => "vdiskbeacon",
          VDISKCOPY          => "vdiskcopy",
          VDISKCOPYABORT     => "vdiskabort",
          VDISKCOPYPAUSE     => "vdiskpause",
          VDISKCOPYRESUME    => "vdiskresume",
          VDISKCOPYSWAP      => "vdiskswap",
          VDISKCREATE        => "vdiskcreate",
          VDISKDELETE        => "vdiskdelete",
          VDISKERASE         => "vdiskerase",
          VDISKEXPAND        => "vdiskexpand",
          VDISKINFO          => "vdiskinfo",
          VDISKINFOLIST      => "vdiskinfolist",
          VDISKLIST          => "vdisklist",
          VDISKLOCK          => "vdisklock",
          VDISKMASK          => "vdiskmask",
          VDISKMAXCAPACITY   => "vdiskmaxcapacity",
          VDISKMIRROR        => "vdiskmirror",
          VDISKMIRRORBREAK   => "vdiskmirrorbreak",
          VDISKMOVE          => "vdiskmove",
          VDISKNAME          => "vdiskname",
          VDISKUNMASK        => "vdiskunmask",
          VDISKWRITECACHE    => "vdiskwritecache",
          VERSION            => "version",
          VERSIONAPPLY       => "versionapply",
          VLINKCOUNT         => "vlinkcount",
          VLINKCREATE        => "vlinkcreate",
          VLINKLIST          => "vlinklist",
          VPORTLIST          => "vportlist",
          WORKPORTCREATE     => "workportcreate",
          WORKPORTDELETE     => "workportdelete",
          WORKPORTINFO       => "workportinfo",
          WORKPORTLIST       => "workportlist",
          WORKPORTNAME       => "workportname",
          WORKSET            => "workset",
          WORKSETLIST        => "worksetlist",
          WRITECACHE         => "writecache",
          XIODEVICELIST      => "xiodevicelist",
          XIODEVICESET       => "xiodeviceset"
          );

use constant CONNECTION_FAILURE => -1;

# make sure to clean up on exit
END
{
    foreach my $socket (values %CONNECTION_HASH)
    {
        if ($socket)
        {
            close($socket);
        }
    }
}

##############################################################################
# PRIVATE FUNCTION
# Name:  _createArray
#
# Returns:
# Given a hash with key values "0", "1", ...
# This will walk through the hash and build an array
#
# Notes: This is an internal function
##############################################################################
sub _createArray
{
    my ($values) = @_;
    my @list = ();

    if (defined($values))
    {
        my $count = 0;

        while (exists($values->{"$count"}))
        {
            $list[$count++] = $values->{"$count"};
        }
    }

    return @list;
}

##############################################################################
# PRIVATE FUNCTION
# Name:  _executeAndParse
#
# Desc: This executes the java command and parses out the resulting string
#
# Returns:  undef on error, otherwise an empty array when we have nothing
#           otherwise a reference to an array of hashes
#
# Notes: This is an internal function
##############################################################################
sub _executeAndParse
{
    my ($cmd) = @_;

    my @elm = ();     #Our array of hashes
    my $rc; # return code
    my $text; # the text we are getting back

    $ERROR_STRING = "No Error";
    $ERROR = 0;

    _connect() || return undef;

    # Send the command
    print $SOCKET $cmd;
    $SOCKET->flush();

    # get the response
    $rc = <$SOCKET>;

    if (defined($rc))
    {
        # get the return code
        $rc =~ /CODE:(\d+)/;
        $rc = $1;

        while (1)
        {
            # get more text if there is more
            my $input = <$SOCKET>;

            if (defined($input))
            {
                # STOP tells us when there is no more data
                if ($input !~ /STOP/)
                {
                    $text .= $input;
                }
                else
                {
                    last;
                }
            }
            else
            {
                $ERROR = CONNECTION_FAILURE;
                $ERROR_STRING = "ICON Proxy no longer available";
                close($SOCKET);                  # close the socket
                $CONNECTED = 0;                  # clear the flag
                $CONNECTION_HASH{$PORT} = 0;     # don't try and re-use this socket

                return undef;
            }
        }

        if (defined($text))
        {
            #How many hashes have we found
            my $count = 0;

            if ($rc == 0)
            {
                #Indicator if we found he start identifier
                my $startFound = 0;

                #Take the whole and split into lines
                my @lines = split( /\n/, $text);

                #Walk through each line
                for( my $ln = 0; $ln < @lines; ++$ln)
                {
                    if ($startFound)
                    {
                        #Are we done?
                        if ($lines[$ln] eq "END")
                        {
                            $startFound = 0;
                            #Increment count
                            ++$count;
                        }
                        else
                        {
                            #for each line parse it into key value pairs
                            my($key, $value) = split( /:/, $lines[$ln], 2);

                            #Just in case "someone" gives us crap back
                            if (!defined($value))
                            {
                                $value = "";
                            }

                            $elm[$count]->{$key} = $value;
                        }
                    }
                    elsif($lines[$ln] eq "BEGIN")   #Check to see if we found the start token
                    {
                        $startFound = 1;
                    }
                }
                return \@elm;
            }
            else
            {
                #command failed
                $ERROR_STRING = $text;
                $ERROR = $rc;
                #Print the error out
                return undef;
            }
        }
        else
        {
            return \@elm;
        }
    }
    else
    {
        $ERROR = CONNECTION_FAILURE;
        $ERROR_STRING = "ICON Proxy no longer available";
        close($SOCKET);                  # close the socket
        $CONNECTED = 0;                  # clear the flag
        $CONNECTION_HASH{$PORT} = 0;     # don't try and re-use this socket
        return undef;
    }
    die "shouldn't get here";
}

##############################################################################
# PRIVATE FUNCTION
# Name: _extractHashElementN
#
# Desc: extracts a hash element by value out of a reference to an array
#       of hashes
#
# In:   reference to an array, which element to extract
#
# returns:  Empty hash on error, else hash element at that position
##############################################################################
sub _extractHashElementN
{
    my ( $refArray, $elem ) = @_;

    my %hashVal;

    if( !defined($refArray))
    {
        return %hashVal;
    }

    if( !defined($elem) )
    {
        $elem = 0;
    }

    #Cast the array
    my @array = @$refArray;

    if (@array && ( $elem < scalar(@array)))
    {
        %hashVal = %{$array[$elem]};
    }

    return %hashVal;
}
##############################################################################
# PRIVATE FUNCTION
# Name: _getArgs
#
# Desc: Gets the parameters passed to a function, sets missed to ""
#
# In:   Number of arguments you are expecting
#       @_
#
# returns:  Arguments for function consumption
##############################################################################
sub _getArgs
{
    my($num, @list) = @_;

    my @rc;

    #We have enough parameters
    if (@list >= $num)
    {
        @rc = @list;
    }
    else
    {
        #copy what we have
        my @copy = @list;

        for (my $i = scalar(@list); $i < $num; ++$i)
        {
            # Setting an empty value for $i;
            $copy[$i] = "";
        }

        @rc = @copy;
    }

    #Make sure we don't have any undefs in the list
    for( my $i = 0; $i < scalar(@rc); ++$i )
    {
        if( !defined($rc[$i]) )
        {
            $rc[$i] = "";
        }
    }
    return @rc;
}

##############################################################################
# PRIVATE FUNCTION
# Name: _connect
#
# Desc: Establishes a socket connection to the ICON proxy agent
#
# Returns:  1 on success, 0 on error
##############################################################################
sub _connect
{
    my $host = "127.0.0.1";
    my $iaddr;
    my $paddr;
    my $proto;
    my $SOCK;
    my $rc = 1;

    # Are we already connected?
    if (!$CONNECTED)
    {
        # Have we connected to this port before?
        if (!$CONNECTION_HASH{$PORT})
        {
            if ($iaddr = inet_aton($host))
            {
                $paddr = sockaddr_in($PORT, $iaddr);
                $proto = getprotobyname("tcp");

                if (socket($SOCK, PF_INET, SOCK_STREAM, $proto) && connect($SOCK, $paddr))
                {
                    # Set the global socket
                    $SOCKET = $SOCK;
                    # Set state to connected
                    $CONNECTED = 1;
                    # Store this socket with port as the key
                    $CONNECTION_HASH{$PORT} = $SOCK;
                }
                else
                {
                    $ERROR_STRING = "ICON Script proxy is not responding at $host:$PORT: $!";
                    $ERROR = CONNECTION_FAILURE;
                    $rc = 0;
                }
            }
            else
            {
                $ERROR_STRING = "ICON Script proxy is not responding at $host:$PORT";
                $ERROR = CONNECTION_FAILURE;
                $rc = 0;
            }
        }
        else
        {
            # Use the socket we created before on this port.
            $SOCKET = $CONNECTION_HASH{$PORT};
        }
    }

    return $rc;
}

##############################################################################
# Name: _listToHash
#
# Desc: Takes a list of hash type information and coverts to an array of hashes
#
# Returns undef on error, otherwise an array of hashes
##############################################################################
sub _listToHash
{
    my ($list) = @_;
    my @array = ();

    $list =~ /\[(.+)\]/;
    # remove the braces

    $list = $1;

    # Find the stuff within braces
    #    while ($list =~ /{(.+((\[.+\])+|[^}]))}/ )
    while ($list =~ /{(([^}\[]+)|(.+\[.+\].*))}/ )
    {
        # get whats left over
        $list = $';
        # save our match
        my $temp = $1;
        my %hash;

        # ignore something like RAID_LIST:[{ }]
        # get key:value
        while ($temp =~ /((\w+):([^\[\]{},]+)(, )?)|(\w+:\[{.+}\])/ )
        {
             if ($1)
             {
                 $hash{$2} = $3;
             }
             $temp = $';
        }

        push(@array, \%hash);
    }
    return (\@array);
}

###############################################################################
#
# User commmands start here
#
###############################################################################

=head1 Common Commands

L</changePort>
 E<verbar> L</dscShutdown> 
 E<verbar> L</environment>
 E<verbar> L</errorCode>
 E<verbar> L</errorString>
 E<verbar> L</info>
 E<verbar> L</reserve>
 E<verbar> L</unreserve>
 E<verbar> L</writeCache>
 E<verbar> L</XIOdeviceList>
 E<verbar> L</XIOdeviceSet>
 E<verbar> L</XIOtechVersion>

=cut
###############################################################################
# Name: changePort
#
# Desc: Changes the port used to talk to the script agent.  With no parameters
#       the default port is used.
#
# Returns: 1 on a successful connection, 0 on failure
#
###############################################################################
sub changePort
{
	my ($newPort) = @_;

    # Set the port we want to use
    if ($newPort)
    {
        $PORT = $newPort;
    }
    else
    {
        $PORT = DEFAULT_PORT;
    }
    
    # Set as unconnected to force a reconnect
    $CONNECTED = 0;
	# Reset the error
	$ERROR = 0;
	$ERROR_STRING = "No Error";

    if (!_connect())
    {
        return 0;
    }

    return 1
}

=head2 changePort

Changes the port the script will use to communicate to a script agent.  This allows a script to
communicate to more than one script agent and thusly more than one ICON.  The script agent
can be invoked with the parameter -Dport=10001 (java -Dport=10001 -jar scriptAgent.jar) and 
it will listen on port 10001.  The default port is 10000.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000"><tr><td align="center">
<table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8"><tr><td>

 #!/bin/perl
 # This script will connect to two different script agents and reserve all the systems
 # on two different ICONs.
 
 use XIOtech::sanscript;

 $xd = XIOdeviceList();

 for (my $i = 0; $i < scalar(@$xd); $i++)
 {
     XIOdeviceSet($xd->[$i]{SERIAL_NUMBER});
     reserve();
 }
 
 changePort(10001); # a script agent must be running and listening on this port

 $xd = XIOdeviceList();

 for (my $i = 0; $i < scalar(@$xd); $i++)
 {
     XIOdeviceSet($xd->[$i]{SERIAL_NUMBER});
     reserve();
 }

 changePort(); # with no parameter the default port (10000) is used.

 for (my $i = 0; $i < scalar(@$xd); $i++)
 {
     XIOdeviceSet($xd->[$i]{SERIAL_NUMBER});
     unreserve();
 } 
 
 if (!changePort(10002))
 {
    print errorString(),"\n";
 }

 changePort(10001);

 $xd = XIOdeviceList();

 for (my $i = 0; $i < scalar(@$xd); $i++)
 {
     XIOdeviceSet($xd->[$i]{SERIAL_NUMBER});
     unreserve();
 }

 exit(0);

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
###############################################################################
# Name: dscShutdown
#
# Desc: Shutsdown the DSC
#
# Returns:  1 on success, 0 on error
#
###############################################################################
sub dscShutdown
{
    if (defined(_executeAndParse("$cmd{DSCSHUTDOWN}")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 dscShutdown

Shuts down the DSC.  This will stop all I/O associated with the DSC.  All vdisks and vlinks will become
unavailable.  Use this command carefully!  This command is for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000"><tr><td align="center">
<table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8"><tr><td>

 if (dscShutdown())
 {
     print "DSC is shutdown.\n"
 }
 else
 {
     print "error\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
# Name: environment
#
# Desc: Returns a hash with the environment information for a given
#       controller
#
# In:   controller serial number
#
# Returns:  Empty hash on error, otherwise a hash with info
##############################################################################
sub environment
{
    my ($serialNumber) = _getArgs(1, @_);

    return _extractHashElementN(_executeAndParse("$cmd{ENVIRONMENT} \"$serialNumber\""),0);
}

=head2 environment

Retrieves environment information for a controller for
a Xiotech storage device set by L</XIOdeviceSet>.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

B<Magnitude 3D>

 # Get the environment information for controller 0

 my %env = environment(0);

 if (%env)
 {
     print "Serial Number = ", $%env{SERIAL_NUMBER}, "\n";
 }
 else
 {
     print "Error with environment()\n";
 }

B<Magnitude>

 my %env = environment();

 if (%env)
 {
     print "Serial Number = ", $%env{SERIAL_NUMBER}, "\n";
 }
 else
 {
     print "Error with environment()\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

a hash with environmental information on success

=item *

an empty hash on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
###############################################################################
# Name: errorCode
#
# Desc: More error information about a command that exits incorrectly, like
#       errno in Ccd /u
#
# Returns:  Error code
#
# Notes:    Error code is only valid when a function returns with a
#           non-successful error code
###############################################################################
sub errorCode
{
    return $ERROR;
}

=head2 errorCode

The error code associated with the most recent command.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000"><tr><td align="center">
<table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8"><tr><td>

 $rc = errorCode();

 if ($rc != 0)
 {
     print("An error has occurred: $rc\n");
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

An integer value that is the error code.

=back

=cut
##############################################################################
# Name: errorString
#
# Desc: More error information about a command that exits incorrectly, like
#       errno in C
#
# Returns:  Error string
#
# Notes:    Error string is only valid when a function returns with a
#           non-successful error code
##############################################################################
sub errorString
{
    return $ERROR_STRING;
}

=head2 errorString

The error message associated with the most recent command.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 $rc = errorCode();
 $string = errorString();

 if ($rc != 0)
 {
     print("An error has occurred: $string\n");
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

A message describing the most recent error.

=back

=cut
##############################################################################
# Name: info
#
# Desc: Returns information about a vcg
#
# Returns hash on success, empty hash on error
##############################################################################
sub info
{
    my %hash = _extractHashElementN(_executeAndParse("$cmd{INFO}"), 0);

    if (%hash)
    {
        if ($hash{CONTROLLER_LIST})
        {
            delete($hash{CONTROLLER_LIST});
        }
    }
    return %hash;
}

=head2 info

Retrieve information about the DSC as set by L</XIOdeviceSet>.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 my %hash = info();

 if (%hash)
 {
     print "dsc name = $hash{NAME}\n";
 }
 else
 {
     print "Error with info: " . errorString() . "\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

On success, a hash containing the following keys:

 CACHE
 CONFIGURED_CONTROLLER_COUNT
 CONTROLLER_COUNT
 IS_CONFIGURED
 IS_MANAGED
 MAX_CONTROLLERS
 NAME
 SCRUBBING
 SERIAL_NUMER
 STATUS
 SYSTEM_TYPE

=item *

an empty hash on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
##############################################################################
# Name: XIOdeviceList
#
# Desc: An array of sans
#
# Returns: undefined on error, otherwise an array of Xiotech storage devices
##############################################################################
sub XIOdeviceList
{
    return(_executeAndParse("$cmd{XIODEVICELIST}"));
}

=head2 XIOdeviceList

Returns a list of Xiotech storage devices managed by the ICON.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $devices = XIOdeviceList();

 if (defined($devices))
 {
     print "There are " . scalar(@$devices) . "available\n";

     for ($i = 0; $i < scalar(@$devices); $i++)
     {
         %hash = %{$devices->[$i]};
         print "Serial number = " $hash{SERIAL_NUMBER} + "\n";
     }
 }
 else
 {
     print "There are no devices available\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

an array of info hashes on success

=item *

undefined on failure

=back

=over 4

=item See also:

L</info>

=back

=cut
##############################################################################
# Name: XIOdeviceSet
#
# Desc: Sets which san to work with
#
# Notes: No errors, however you pick the wrong one you will know about it
#        when you try to call another function that tries to use the san
##############################################################################
sub XIOdeviceSet
{
    my ($sn) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{XIODEVICESET} \"$sn\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 XIOdeviceSet

Sets the serial number of the Xiotech storage device that all subsequent
commands will act upon.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 if (XIOdeviceSet(9999) == 0)
 {
     print "9999 is not a valid DSC\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</XIOdeviceList>

=back

=cut
##############################################################################
# Name: XIOtechVersion
#
# Desc: Returns the version of the Xiotech ICON
#
# Returns empty hash on error, otherwise a hash of firmware versions
##############################################################################
sub XIOtechVersion
{
    my %hash = _extractHashElementN(_executeAndParse("$cmd{VERSION}"), 0);

    return %hash;
}

=head2 XIOtechVersion

Retrieves the version information for the ICON and if a Xiodevice has been selected, the version
information for the Xiodevice.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my %version = XIOtechVersion();

 if ($version{ICON} ne $version{SCRIPTAGENT})
 {
     print "scriptAgent not the same version as the ICON\n";
     exit;
 }

 XIOdeviceSet(11111);
 %version = XIOtechVersion();

 if (defined(%version))
 {
     print "ICON version = $version{ICON}\n" ;
 }
 else
 {
     print "Error retrieving verson\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

On success, a hash containing the following keys:

 SYSTEM_RELEASE
 ICON
 SCRIPTAGENT

=item *

undefined on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
##############################################################################
# Name: reserve
#
# Desc: Reserves the dsc
#
# In:   none
#
# Returns:  1 on success, 0 on failure
##############################################################################
sub reserve
{
    if (_executeAndParse("$cmd{RESERVE}"))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 reserve

Reserves the current Xiotech Storage device allowing
changes to the system.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 if (reserve())
 {
     print "reserved\n";

 }
 else
 {
     print "Error with reserve()\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</XIOdeviceSet> E<verbar> L</unreserve>

=back

=cut
##############################################################################
# Name: unreserve
#
# Desc: unreserves the dsc
#
# In:   none
#
# Returns:  1 on success, 0 on failure
##############################################################################
sub unreserve
{
    if (_executeAndParse("$cmd{UNRESERVE}"))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 unreserve

Unreserves the current Xiotech Storage device.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 if (unreserve())
 {
     print "unreserved\n";

 }
 else
 {
     print "Error with unreserve()\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</XIOdeviceSet> E<verbar> L</reserve>

=back

=cut
##############################################################################
# Name: writeCache 
#
# Desc: Turns write cache on or off for the DSC
#
# In:   none, on or off
#
# Returns:  1 on success, 0 on failure
##############################################################################
sub writeCache
{
    if (scalar(@_) == 0)
    {
        my %hash = _executeAndParse("$cmd{WRITECACHE}");
        
        if (%hash)
        {
            if ($hash{STATE} eq "on")
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return -1;
        }
    }
    else
    {
        my $parm = _getArgs(1, @_);

        if (_executeAndParse("$cmd{WRITECACHE} \"$parm\""))
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}

=head2 writeCache

Turns DSC write cache on or off and retrieves current DSC write cache state. 
This command is available for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 reserve();

 if (writeCache("on")
 {
     print "DSC write cache is on";
 }
 else
 {
     print "Error with writeCache(\"on\")";
 }
 
 if (writeCache() == 1)
 {
     print "DSC write cache is on";
 }
 
 if (writeCache() == 0)
 {
     print "print DSC write cache is off";
 }

 if (writeCache() == -1)
 {
     print "error in retrieving DSC write cache state.";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

writeCache(on | off)
1 on success, 0 on failure

=item *

writeCache()
1 if DSC write cache is on
0 if DSC write cache is off
-1 on error

=back

=cut
##############################################################################
#
#  BAY Commands
#
#############################################################################

=head1 Bay Commands

L</bayBeacon> E<verbar> L</bayCount> E<verbar> L</bayInfo> E<verbar> L</bayList>

=cut
##############################################################################
# Name: bayBeacon
#
# Desc: Beacons a bay
#
# In:   bayid, time in seconds
#
# Returns: 1 on success, 0 is a failure
##############################################################################
sub bayBeacon
{
    my ($id, $time) = _getArgs(2, @_);

    if (defined(_executeAndParse("$cmd{BAYBEACON} \"$id\" \"$time\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 bayBeacon

Beacons a bay for a specified number of seconds for
a Xiotech storage device set by L</XIOdeviceSet>.  This command is available
for Magnitude 3D only.  The maximum time is 10 minutes (6000 seconds).

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $bay_id = 1;
 my $seconds = 60;

 if (bayBeacon($bay_id, $seconds) == 0)
 {
     print "bayBeacon() failed for: ",
     errorString(),
     "\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
##############################################################################
# Name: bayCount
#
# Desc: Returns number of bays
#
# Returns -1 on error
##############################################################################
sub bayCount
{
    my %rc = _extractHashElementN(_executeAndParse("$cmd{BAYCOUNT}"), 0);

    if (%rc)
    {
        return $rc{BAYCOUNT};
    }
    else
    {
        return -1;
    }
}

=head2 bayCount

Returns the number of bays.  This command is available
for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $count = 0;

 $count = bayCount();

 if ($count >= 0)
 {
     print "number of bays = $count\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

the number of bays on success

=item *

-1 on error

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
#############################################################################
# Name: bayInfo
#
# Desc: Returns a hash with the bay information for a given
#       bay indentifier
#
# In:   scalar bay identifer
#
# Returns:  Empty hash on error, otherwise a hash with info
##############################################################################
sub bayInfo
{
    my ($id) = _getArgs(1, @_);

    my %hash = _extractHashElementN(_executeAndParse("$cmd{BAYINFO} \"$id\""),0);

    if (%hash)
    {
        if (exists($hash{PDISK_LIST}))
        {
            delete($hash{PDISK_LIST});
        }
    }
    return (%hash);
}

=head2 bayInfo

Retrieves bay information.  This command is available for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my %hash;

 %hash = bayInfo("A");

 if (%hash)
 {
     print "Name = $hash{NAME}\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

On success, a hash containing the following keys

 ID
 NAME
 DEVICE_STATUS
 VENDOR_ID
 SERIAL_NUMBER
 INTERFACE_CARD_SLOT
 WWN
 PRODUCT_ID
 TYPE
 LOOP_STATUS
 SIZE

=item *

an empty hash on error

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
##############################################################################
# Name: bayList
#
# Desc: Returns an array of bay identifiers
#
# Returns:  Empty hash on error, otherwise a hash with info
##############################################################################
sub bayList
{
    my $result = _executeAndParse("$cmd{BAYLIST}");

    if (!defined($result))
    {
        return undef;
    }

    my %values = _extractHashElementN($result,0);

    my @list = ();

    if (%values)
    {
        @list = _createArray(\%values);
    }

    return (\@list);
}

=head2 bayList

Retrieves a list of bay identifiers.  This command is available
for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $list = bayList();

 if ($list)
 {
     print "There are ", scalar(@$list), " bays\n";
 }

 for (my $i = 0; $ < scalar(@$list); $i++)
 {
     print "ID = $list->[$i]\n";
 }


=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

a reference to an array of bay IDs on success

=item *

undef on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut

##############################################################################
#
#  Copy Commands
#
#############################################################################

=head1 Copy Commands

L</copyInfo> E<verbar> L</copyReverse> E<verbar> L</copyTerminate> E<verbar> L</copySetDescription>

=cut
##############################################################################
#
# copyInfo - returns information about current copies
#
##############################################################################
sub copyInfo
{
    my $array = _executeAndParse("$cmd{COPYINFO}");

    if (!defined($array))
    {
        return undef;
    }
    return $array;
}

=head2 copyInfo

Returns a list of copy information records.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 XIOdeviceSet(111111);

 my $ci = copyInfo();

 if ($ci)
 {
     print "There are " . scalar(@$ci) . " copyinfo records\n";
     print "source =  " . $ci->[0]{SOURCE_SN} . "\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

A reference to an array of hashes.  Each hash is a copy information record.

The hash contains the following keys:

 COPY_ID - unique ID for this copy
 DESCRIPTION - text the user can set to describe this copy
 SOURCE_SN - source serial number
 SOURCE_VBLOCK - source vblock
 SOURCE_VDISK - source vdisk
 SOURCE_VLINK - 1 if source is a vlink, 0 if source is not a vlink
 DEST_SN - destination serial number
 DEST_VBLOCK - destination vblock
 DEST_VDISK - destination vdisk
 DEST_VLINK - 1 if destination is a vlink, 0 if destination is not a vlink

If the source is a vlink, then the following additional keys are available:

 SOURCE_REMOTE_SN - remote source serial number
 SOURCE_REMOTE_VBLOCK - remote source vblock
 SOURCE_REMOTE_VDISK - remote source vdisk

If the destination is a vlink, then the following additional keys are available:

 DESTINATION_REMOTE_SN - remote destination serial number
 DESTINATION_REMOTE_VBLOCK - remote destination vblock
 DESTINATION_REMOTE_VDISK - remote destination vdisk

=item *

undef on failure

=back

=cut
##############################################################################
#
# copySetDescription
#
##############################################################################
sub copySetDescription
{
    my (@parms) = _getArgs(2, @_);

    if (_executeAndParse("$cmd{COPYSETDESCRIPTION} \"$parms[0]\" \"$parms[1]\""))
    {
        return 1;
    }
    return 0;
}

=head2 copySetDescription

Sets the description for a copy.  A copy is uniquely identified by the copy id

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 XIOdeviceSet(111111);
 reserve();

 my $ci = copyInfo();

 if ($ci)
 {
     print "Setting description for copy $ci->[0]{COPY_ID}
     copySetDescription($ci->[0]{COPY_ID}, "A description");
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</copyInfo>

=back

=cut
##############################################################################
#
# copyReverse
#
##############################################################################
sub copyReverse
{
    my (@parms) = _getArgs(1, @_);

    if (_executeAndParse("$cmd{COPYREVERSE} \"$parms[0]\""))
    {
        return 1;
    }
    return 0;
}

=head2 copyReverse

Reverses a copy.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
        <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
        <tr><td>

 XIOdeviceSet(111111);
 reserve();

 my $ci = copyInfo();

 if ($ci)
 {
     print "Reversing copy ID $ci->[0]{COPY_ID}
     copyReverse($ci->[0]{COPY_ID});
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</copyInfo>

=back

=cut
##############################################################################
#
# copyTerminate
#
##############################################################################
sub copyTerminate
{
    my (@parms) = _getArgs(1, @_);

    if (_executeAndParse("$cmd{COPYTERMINATE} \"$parms[0]\""))
    {
        return 1;
    }
    return 0;
}

=head2 copyTerminate

Terminates a copy.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 XIOdeviceSet(111111);
 reserve();

 my $ci = copyInfo();

 if ($ci)
 {
     print "Terminating copy ID $ci->[0]{COPY_ID}
     copyTerminate($ci->[0]{COPY_ID});
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</copyInfo>

=back

=over 4

=item See also:

L</copyInfo>

=back

=cut
##############################################################################
#
#  DISKGROUP Commands
#
#############################################################################

=head1 Disk Group Commands

L</diskgroupAdd> E<verbar> L</diskgroupInfo> E<verbar> L</diskgroupRemove> E<verbar>
 L<diskgroupSet>

=cut
##############################################################################
# Name: diskgroupAdd
#
# Desc: Adds physical disks to an existing disk group
#
# In:   diskgroup_id, pdisk_id1, pdiskid2, ...
#
# Returns:
##############################################################################
sub diskgroupAdd
{
    my (@pdisks) = _getArgs(2, @_);

    my $command = "$cmd{DISKGROUPADD} ";

    for (my $i = 0; $i < @pdisks; $i++)
    {
        $command .= " \"$pdisks[$i]\"";
    }

    if (_executeAndParse($command))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 diskgroupAdd

Adds one or more physical disks to an existing disk group. Bays can be added by specifying the bay ID.
This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my @pdisks = ( "A2", "A4", "A8" );
 diskgroupSet(0);

 if (diskgroupAdd(@pdisks))
 {
     print "physical disks A2, A4, and A8 were added to ",
           "disk group 0\n";
 }

 my @pdisks = ( "A2" );
 diskgroupSet(0);

 if (diskgroupAdd(@pdisks)
 {
     print "physical disk A2 was added to ",
           "disk group 0\n";
 }


=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>, L</diskgroupRemove>

=back

=cut
############################################################
# Name: diskgroupInfo
#
# Desc: Retrieves information about a disk group
#
# In:   diskgroup_id
#
# Returns:
##############################################################################
sub diskgroupInfo
{
    my ($id) = _getArgs(1, @_);

    my %hash = _extractHashElementN(_executeAndParse("$cmd{DISKGROUPINFO} \"$id\""),0);

    return (%hash);
}

=head2 diskgroupInfo

Retrieves information about a disk group.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $diskgroup_id = 1;
 my %diskgroup_info = diskgroupInfo($diskgroup_id);

 if (%diskgroup_info)
 {
    print "Disk group $diskgroup_id is named ",
          "$diskgroup_info{NAME}\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

a hash of diskgroup information on success

 NAME
 DESCRIPTION
 INDEX
 R10SS
 R5SS
 R5PARITY
 DISKS
 THRESHOLD
 RAIDSPERCREATE

=item *

an empty hash on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
##############################################################################
# Name: diskgroupRemove
#
# Desc: Removes one or more physical disks from a disk group
#
# Returns 1 on success, 0 on failure
##############################################################################
sub diskgroupRemove
{
    my (@pdisks) = _getArgs(2, @_);

    my $command = "$cmd{DISKGROUPREMOVE} ";

    for (my $i = 0; $i < @pdisks; $i++)
    {
        $command .= " \"$pdisks[$i]\"";
    }

    if (_executeAndParse($command))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 diskgroupRemove

Removes one or more physical disks from the current disk group.  Bays can be removed by specifying the
Bay ID.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my @pdisks = ( "A2", "A4", "A8" );
 diskgroupSet(0);

 if (diskgroupRemove(@pdisks))
 {
     print "Physical disks A2, A4, and A8 were removed ",
           "from disk group 0\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>, L</diskgroupAdd>

=back

=cut
##############################################################################
# Name: diskgroupSet
#
# Desc: Sets the current diskgroup to use
#
# In:   diskgroup ID
#
# Returns: 1 on success, 0 on error
##############################################################################
sub diskgroupSet
{
    my ($diskgroup) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{DISKGROUPSET} \"$diskgroup\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 diskgroupSet

Selects the current diskgroup to use.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 diskgroupSet(0);

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
#
#  PDISK Commands
#
#############################################################################

=head1 Physical Disk Commands

L</pdiskBeacon> E<verbar> L</pdiskCount> E<verbar> L</pdiskDefrag> E<verbar>
 L</pdiskInfo> E<verbar> L<pdiskLabel> E<verbar> L</pdiskList> L</defragAll>

=cut
##############################################################################
# Name: pdiskBeacon
#
# Desc: Beacons a drive
#
# In:   $drive      which drive to beacon
#       $duration   number of seconds to beacon
#
# Returns:  1 on success, 0 on error
##############################################################################
sub pdiskBeacon
{
    my ($drive, $duration) = _getArgs(2, @_);

    if ( defined( _executeAndParse("$cmd{PDISKBEACON} \"$drive\" \"$duration\"")) )
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 pdiskBeacon

Beacons a physical disk for I<$duration> number of seconds.  This command is available for Magnitude 3D only.
The maximum beacon time is 10 minutes (6000 seconds).

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $pdisk_id = "A0";
 my $duration = 30;

 if (pdiskBeacon($pdisk_id, $duration))
 {
     print "pdisk $pdisk_id is beaconing for $duration seconds";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
##############################################################################
# Name: pdiskCount
#
# Desc: Returns number of pdisks
#
#Returns -1 on error otherwise the number of pdisks
##############################################################################
sub pdiskCount
{
 my %rc = _extractHashElementN(_executeAndParse("$cmd{PDISKCOUNT}"),0);

 if (%rc)
 {
     return $rc{PDISKCOUNT};
 }
 else
 {
     return -1;
 }
}

=head2 pdiskCount

Returns the number of physical disks.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $count = pdiskCount();

 if ($count > -1)
 {
     print "There are $count physical drives.\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=back

=begin html

<UL>
<LI>the number of physical disks on success</LI>
<LI>-1 on failure</LI>
</UL>

=end html

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
##############################################################################
# Name: pdiskDefrag
#
# Desc: Starts a defragmentation operation on a physical disk
#
# In:   physical disk id
#
# Returns:  1 on success, 0 on error
##############################################################################
sub pdiskDefrag
{
    my ($drive) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{PDISKDEFRAG} \"$drive\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 pdiskDefrag

Starts a defragmentation operation on a physical disk.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $pdisk_id = "A0";

 if (pdiskDefrag($pdisk_id)
 {
     print "Defrag started on physical disk $pdisk_id\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
##############################################################################
# Name: defragAll
#
# Desc: Starts a defragmentation operation on a all physical disks
#
# In:   commmand - start, stop, status
#
# Returns:  start, stop: 1 on success, -1 on error
#           status: 1  = ON, 0  = OFF, -1 on error
##############################################################################
sub defragAll
{
    my ($command) = _getArgs(1, @_);

    my %hash = _extractHashElementN(_executeAndParse("$cmd{DEFRAGALL} \"$command\""), 0);

    if (defined(%hash))
    {
        return $hash{STATUS};
    }
    else
    {
        return 0;
    }
}

=head2 defragAll

Starts a defragmentation operation on all physical disks that are defragable.  This command is available
for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 if (defragAll("start"))
 {
     print "Defrag all started";
 }

 if (defragAll("stop"))
 {
     print "Defrag all stopped";
 }

 if (defragAll("status"))
 {
     print "Defrag all is started";
 }
 else
 {
     print "Defrag all is stopped";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

start and stop return 1 on success

=item *

status returns 1 if defrag all is started

=item *

start and stop return 0 on failure

=item *

status returns 0 if defrag all is stopped

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
##########################################################################
# Name: pdiskInfo
#
# Desc: Returns a hash with the physical disk information for a given
#       physical disk identifier
#
# In:   scalar  physicaldiskidentifer
#
# Returns:  Empty hash on error, otherwise a hash with info
##############################################################################
sub pdiskInfo
{
    my ($id) = _getArgs(1, @_);
    return _extractHashElementN(_executeAndParse("$cmd{PDISKINFO} \"$id\""),0);
}

=head2 pdiskInfo

Retrieve physical disk information.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $pdisk_id = "A0";
 my %hash = pdiskInfo($pdisk_id);

 if (%hash)
 {
      print "The name of physical disk $pdisk_id ",
            " is $hash{NAME}\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

a hash of physical disk information on success

 LARGEST_AVAILABLE_IN_BLOCKS
 TOTAL_AVAILABLE_IN_BLOCKS
 PATH_COUNT
 SLOT_NUMBER
 SERIAL_NUMBER
 CAPACITY_IN_BLOCKS
 PERCENT_REMAINING
 LARGEST_AVAILABLE_SPACE
 WRITE_REQUEST_COUNT
 VENDOR_ID
 DEVICE_LABEL
 QUEUE_DEPTH
 USED_SPACE_IN_BLOCKS
 REVISION
 USED_SPACE
 TOTAL_AVAILABLE_SPACE
 AVERAGE_SECTOR_COUNT_PER_REQUEST
 READ_REQUEST_COUNT
 PRODUCT_ID
 MISCELLANEOUS_STATUS
 PSTATE
 PATH_3
 ID
 CHANNEL
 DEVICE_STATUS
 PATH_2
 AVERAGE_REQUEST_PER_SECOND
 DEVICE_CAPACITY
 ERROR_COUNT
 PATH_1
 PATH_4
 WWN
 NAME
 VCG_SERIAL_NUMBER
 POST_STATUS
 ENCLOSURE_NUMBER
 SHOULD_BE_DEFRAGEMENTED
 FIBRE_CHANNEL_ID

=item *

an empty hash on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut
##############################################################################
# Name: pdiskLabel
#
# Desc: Labels a drive
#
# In:   $drive, $label
#
# Returns: 1 on success, 0 on error
##############################################################################
sub pdiskLabel
{
    my ($label, $drive) = _getArgs(2, @_);

    if( defined(_executeAndParse("$cmd{PDISKLABEL} \"$label\" \"$drive\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 pdiskLabel

Labels a drive.  Label types are B<UNLABELED>, B<DATA>,
B<HOTSPARE>, and B<NOTSAFE>.   This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $pdisk_id = "A0";
 my $label = "DATA";

 XIOdeviceSet($serial_number);

 if (pdiskClass($pdisk_id, $label)
 {
     print "Physical disk $pdisk_id is labeled a DATA drive.\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</XIOdeviceSet>

=back

=cut

##############################################################################
# Name: pdiskList
#
# Desc: Returns a list of physical disk identifers
#
# Returns:  an array of physical disk id's
#           on error returns undef
##############################################################################
sub pdiskList
{
    my $result = _executeAndParse("$cmd{PDISKLIST}");

    if (!defined($result))
    {
        return undef;
    }

    my %values = _extractHashElementN($result,0);

    my @list = ();

    if (%values)
    {
        @list = _createArray(\%values);
    }

    return (\@list);
}

=head2 pdiskList

Retrieve a list of physical disk identifiers.  This command is available
for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $list = pdiskList();

 if ($list)
 {
     print "There are ", scalar(@$list), " physical ",
           "disks.\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=back

=begin html

<UL>
<LI>a reference to an array of physical disks on success</LI>
<LI>undef on failure</LI>
</UL>

=end html

=over 4

=item See also:

L<XIOdeviceSet>

=back

=cut
##############################################################################
#
#  WORKPORT Commands
#
#############################################################################

=head1 Workport Commands

L</workportCreate> E<verbar> L</workportDelete> E<verbar> L</workportInfo>
 E<verbar> L</workportList> E<verbar> L</workportName>

=cut
##############################################################################
# Name: workportCreate
#
# Desc: Creates a work port
#
# In: new port id
#
# Returns: 1 on success, 0 on error
##############################################################################
sub workportCreate
{
    my ($newport_id) = _getArgs(1, @_);

    if( defined(_executeAndParse("$cmd{WORKPORTCREATE} \"$newport_id\"")) )
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 workportCreate

Creates a workport.
 This command is available for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 if (workportCreate(0))
 {
     print "workport created";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</workportDelete>

=back

=cut
##############################################################################
# Name: workportDelete
#
# Desc: Causes a workport to become a newport
#
# In: new port id
#
# Returns: 1 on success, 0 on error
##############################################################################
sub workportDelete
{
    my ($workport_id) = _getArgs(1, @_);

    if( defined(_executeAndParse("$cmd{WORKPORTDELETE} \"$workport_id\"")) )
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 workportDelete

Deletes a workport.  This command is available
for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 if (workportDelete(0))
 {
     print "workport 0 deleted";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</workportCreate>

=back

=cut
##############################################################################
# Name: workportInfo
#
# Desc: A hash of workport information
#
# Returns:
##############################################################################
sub workportInfo
{
    my ($workport) = _getArgs(1, @_);

    return _extractHashElementN(_executeAndParse("$cmd{WORKPORTINFO} \"$workport\""), 0);
}

=head2 workportInfo

Information about a workport.  This command is available
for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my %workportinfo = workportInfo($workportlist->[0]);

 if (%workportinfo)
 {
     print "workport ID = $workportinfo{ID}\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=back

=begin html

<UL>
<LI>a hash of workport information</LI>
<UL>
    <LI>ID</LI>
    <LI>NAME</LI>
    <LI>TARGET_MAP</LI>
    <LI>TARGET</LI>
    <LI>STATUS</LI>
    <LI>SELECTED_TARGET</LI>
    <LI>ATTRIBUTES</LI>
    <LI>ASSOCIATIONS</LI>
    <LI>ASSOC_COUNT</LI>
    <LI>WWN</LI>
</UL>
<LI>undef on error</LI>
</UL>

=end html

=cut
##############################################################################
# Name: workportList
#
# Desc: A list of workports for the current workset
#
# Returns:
##############################################################################
sub workportList
{
    my $list = _executeAndParse("$cmd{WORKPORTLIST}");
    my @list;

    if ($list)
    {
        for (my $i = 0; $i < scalar(@$list); $i++)
        {
            if (exists($list->[$i]{ID}))
            {
                push(@list, $list->[$i]{ID});
            }
        }
        return (\@list);
    }
    else
    {
        return undef;
    }
}

=head2 workportList

A list of workports.  This command is available
for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $workportlist = workportList();

 if ($workportlist)
 {
     print "There are " . @$workportlist . " workports\n";
 }

 # List out the workport ids

 for (my $i = 0; $i < scalar(@$workportlist); $i++)
 {
     print "ID = $workportlist->[$i]\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

A reference to an array of workport identifiers on success

=item *

undef on failure

=back

=cut
##############################################################################
# Name: workportName
#
# Desc: Names a workport
#
# Returns: 1 on success, 0 on failure
##############################################################################
sub workportName
{
    my ($workport, $name) = _getArgs(2, @_);

    if (defined(_executeAndParse("$cmd{WORKPORTNAME} \"$workport\" \"$name\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 workportName

Names a workport.   This command is available
for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $workport = 1;
 my $name = "Bob";

 if ($workportName($workport, $name)
 {
     print "Workport $workport has been named $name";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
#
#  NEWPORT Commands
#
#############################################################################

=head1 Newport Commands

L</newportInfo> E<verbar> L</newportList>

=cut
##############################################################################
# Name: newportInfo
#
# Desc: newport information
#
# In:   $newport (system assigned identifier)
#
# Returns:  an empty hash on error, otherwise it returns the hash with the
#           newport information
##############################################################################
sub newportInfo
{
    my ($newport) = _getArgs(1, @_);

    return _extractHashElementN(_executeAndParse("$cmd{NEWPORTINFO} \"$newport\""), 0);
}

=head2 newportInfo

Retrieves newport information.  This command is available
for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my %newportinfo = newportInfo(0);

 if (%newportinfo)
 {
     print "newport 0 ID = ", $newport{ID}, "\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=back

=begin html

<UL>
<LI>a hash of newport information on success</LI>
<UL>
    <LI>ID</LI>
    <LI>NAME</LI>
    <LI>DEVICE_TYPE</LI>
    <LI>TARGET</LI>
    <LI>ATTRIBUTES</LI>
    <LI>STATUS</LI>
    <LI>WWN</LI>
    <LI>VPORTS</LI>
</UL>
<LI>an enpty hash on error</LI>
</UL>

=end html

=cut
##############################################################################
# Name: newportList
#
# Desc: Newport list
#
# In: none
#
# Returns: A reference to an array of server IDs
#          undef on error
##############################################################################
sub newportList
{
    my ($list_type) = _getArgs(1, @_);

    my $list = _executeAndParse("$cmd{NEWPORTLIST}");
    my @list;

    if (defined($list))
    {
        @list = ();

        for (my $i = 0; $i < scalar(@$list); $i++)
        {
            if (exists($list->[$i]{ID}))
            {
                push(@list, $list->[$i]{ID});
            }
        }
        return (\@list);
     }
     else
     {
         return (undef);
     }
}

=head2 newportList

Retrieve an array of newport ids.  This command is available
for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);

 my $newportlist = newportList();

 if ($newportlist)
 {
     print "There are ", @$newportlist, " newports\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=back

=begin html

<UL>
<LI>a reference to an array of newport ids on success</LI>
<LI>undef on error</LI>
</UL>

=end html

=cut
#############################################################################
#
#  VDISK Commands
#
#############################################################################

=head1 Virtual Disk Commands

L</vdiskBeacon> E<verbar> L</vdiskBufferOff> E<verbar> L</vdiskBufferOn> E<verbar>
 L</vdiskCopy> E<verbar> L</vdiskCopyAbort> E<verbar> L</vdiskCopyPause> E<verbar>
 L</vdiskCopyResume> E<verbar> L</vdiskCopySwap> E<verbar> L</vdiskCreate> E<verbar>
 L</vdiskDelete> E<verbar> L</vdiskErase> E<verbar> L</vdiskExpand> E<verbar>
 L</vdiskInfo> E<verbar> L</vdiskList> E<verbar> L</vdiskLock> E<verbar> L</vdiskMask> E<verbar>
 L</vdiskMaxCapacity> E<verbar> L</vdiskMirror> E<verbar> L</vdiskMirrorBreak> E<verbar>
 L</vdiskMove> E<verbar> L</vdiskName> E<verbar> L</vdiskUnlock> E<verbar> L</vdiskUnmask>
 L</vdiskWriteCache>

=cut
##############################################################################
# Name: vdiskBeacon
#
# Desc: Beacons all the physical drives in a virtual disk
#
# In:   virtual disk id
#
# Returns:  1 on success, 0 on error
##############################################################################
sub vdiskBeacon
{
    my ($id) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{VDISKBEACON} \"$id\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskBeacon

Beacons all the physical drives in a virtual disk.  This command is available to Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 workset(0);
 vblockset(0);

 if (vdiskBeacon(0))
 {
     print "The vdisk is beaconing\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
# Name: vdiskCopy
#
# Desc: copies a vdisk
#
# In:   $source, $destination
#
# Returns: O on success, any other value is an error
##############################################################################
sub vdiskCopy
{
    my ($source, $destination ) = _getArgs(2, @_);

    if (defined(_executeAndParse("$cmd{VDISKCOPY} \"$source\" \"$destination\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskCopy

Performs a virtual disk copy operation.  This command is available for Magnitude 3D and Magnitude.
  For Magnitude 3D the source and destination value can be in the form "vblock/vdisk_id" to allow copying
a virtual disk from one vblock to another.  For Magnitude the source and destination can be in the form of
"cluster/vdisk_id" to allow copying a virtual disk from one cluster to another.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);
 reserve();

 my ($source = 0, $destination = 1);

 if (vdiskCopy($source, $destination))
 {
     print "Copying from vdisk $source to vdisk $destination\n";
 }

 my $vblock = 1;

 if (vdiskCopy($source, "$vblock/$destination"))
 {
     print "Copying from vdisk $source to vdisk $vblock/$destination\n";
 }
 
 if (vdiskCopy("$vblock/$source", "$vblock/$destination"))
 {
     print "Copying from vdisk $vblock/$source to $vblock/$destination\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskCopyAbort> E<verbar> L</vdiskCopyPause> E<verbar> L</vdiskCopyResume>

=back

=cut
##############################################################################
# Name: vdiskCopyAbort
#
# Desc: Aborts a vdisk copy/swap
#
# In:   $destination
#
# Returns: O on success, any other value is an error
##############################################################################
sub vdiskCopyAbort
{
    my ($destination) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{VDISKCOPYABORT} \"$destination\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskCopyAbort

Aborts a L</vdiskCopy> operation.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);
 reserve();

 my $destination = 1;

 if (vdiskCopyAbort($destination))
 {
     print "Copy to vdisk $destination aborted\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskCopy>

=back

=cut
##############################################################################
# Name: vdiskCopyPause
#
# Desc: Pauses a vdisk copy/swap
#
# In:   $destination
#
# Returns: O on success, any other value is an error
##############################################################################
sub vdiskCopyPause
{
    my ($destination) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{VDISKCOPYPAUSE} \"$destination\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskCopyPause

Pauses a L</vdiskCopy> operation.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);
 reserve();

 my ($destination = 1);

 if (vdiskCopyPause($destination))
 {
     print "Copy to vdisk $destination paused\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskCopy>

=back

=cut
##############################################################################
# Name: vdiskCopyResume
#
# Desc: Resumes a paused vdisk copy
#
# In:   $destination
#
# Returns: 1 on success, 0 on error
##############################################################################
sub vdiskCopyResume
{
    my ($destination) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{VDISKCOPYRESUME} \"$destination\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskCopyResume

Resumes a paused L</vdiskCopy> operation.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);
 reserve();

 my $destination = 1;

 if (vdiskCopyResume($destination))
 {
     print "Copy to vdisk $destination resumed\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
# Name: vdiskCopyStatus
#
# Desc: Returns the status of a copy operation - in progress or not in progress
#
# In: destination_id of copy operation
#
# Returns: 1 if copy in progress, 0 if no copy in progress, -1 on error
##############################################################################
sub vdiskCopyStatus
{
    my ($destination) = _getArgs(1, @_);
    sleep(2);
    my %hash = vdiskInfo($destination);

    if (%hash)
    {
        if ($hash{MIRROR_COPY_STATUS} ne "none")
        {
            return 1;
        }
        return 0;
    }
    return -1;
}

=head2 vdiskCopyStatus

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);
 reserve();

 my ($source = 0, $destination = 1);

 if (vdiskCopyStatus($destination) == 1)
 {
     print "Copying from vdisk $source to vdisk in progress\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 if copy in progress

=item *

0 if no copy in progress

=item *

-1 if failure

=back

=cut
##############################################################################
# Name: vdiskCopySwap
#
# Desc: Performs a vdisk copy/swap
#
# In:   $source, $destination
#
# Returns: 1 on success, 0 on error
##############################################################################
sub vdiskCopySwap
{
    my ($source, $destination) = _getArgs(2, @_);

    if (defined(_executeAndParse("$cmd{VDISKCOPYSWAP} \"$source\" \"$destination\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskCopySwap

Performs a virtual disk copy swap operation.  This command is available for Magnitude 3D and Magnitude.
  For Magnitude 3D the source and destination value can be in the form "vblock/vdisk_id" to allow copy swapping
a virtual disk from one vblock to another.  For Magnitude the source and destination can be in the form of
"cluster/vdisk_id" to allow copy swapping a virtual disk from one cluster to another.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);
 reserve();

 my ($source = 0, $destination = 1);

 if (vdiskCopySwap($source, $destination))
 {
     print "Copyswapping from vdisk $source to vdisk $destination.\n";
 }

 my ($vblock = 1);

 if (vdiskCopySwap($source, "$vblock/$destination"))
 {
     print "Copyswapping from vdisk $source to vdisk $vblock/$destination\n";
 }
 
 if (vdiskCopySwap("$vblock/$source", "$vblock/$destination"))
 {
     print "Copyswapping from vdisk $vblock/$source to $vblock/$destination\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
# Name: vdiskCreate
#
# Desc: creates a vdisk
#
# In:   $identifer (human assigned)
#       $cap        capacity desired
#       $name
#
# Returns:  If successful returns a hash with it's information
#           otherwise it returns an empty hash
##############################################################################
sub vdiskCreate
{
    my ($id, $raid, $cap) = _getArgs(3, @_);

    if (_executeAndParse("$cmd{VDISKCREATE} \"$id\" \"$raid\" \"$cap\""))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskCreate

Creates a virtual disk.  Capacity is in MB.  This command is available for Magnitude 3D and Magnitude.
 Supported raid types: Magnitude 3D, Release 2 - Raid 0, Raid 10.  Raid 0, 5, and 10 for all others.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my ($id = 0, $raid = 10, $capacity = 1000);

 if (vdiskCreate($id, $raid, $capacity)
 {
    print "vdisk $name was created.\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskDelete>

=back

=cut
##############################################################################
# Name: vdiskDelete
#
# Desc: Deletes a vdisk
#
# In:   $vdisk_id
#
# Returns:  1 on success, 0 on error
#
# Notes: All data on vdisk is lost FOREVER!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
##############################################################################
sub vdiskDelete
{
    my ($id) = _getArgs(1,@_);

    my $result = _executeAndParse("$cmd{VDISKDELETE} \"$id\"");

    if (defined($result))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskDelete

Deletes a vdisk. B<CAUTION: THIS WILL REMOVE ALL DATA ON THE VIRTUAL DISK>.
  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 if (vdiskDelete(0))
 {
     print "vdisk 0 deleted\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskCreate>

=back

=cut
##############################################################################
# Name: vdiskErase
#
# Desc: Erases a virtual disk
#
# In:   $vdisk
#
# Returns:  1 on success, 0 on error
#
##############################################################################
sub vdiskErase
{
    my ($vdisk) = _getArgs(1, @_);

    my $result = _executeAndParse("$cmd{VDISKERASE} \"$vdisk\"");

    if (defined($result))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskErase

Erases a virtual disk.  B<CAUTION: THIS WILL REMOVE ALL DATA ON THE VIRTUAL DISK>.
  This command is available for Magnitude 3D only.

=over 4

=item Usage

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $vdisk = 0;

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 if (vdiskErase($vdisk)
 {
     print "vdisk $vdisk has been erased\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut

##############################################################################
# Name: vdiskExpand
#
# Desc: Expands a vdisk
#
# In:   $vdisk $capacity
#
# Returns:  1 on success, 0 on error
#
##############################################################################
sub vdiskExpand
{
    my ($vdisk, $capacity) = _getArgs(2, @_);

    my $result = _executeAndParse("$cmd{VDISKEXPAND} \"$vdisk\" \"$capacity\"");

    if (defined($result))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskExpand

Expands a virtual disk.  Capacity is in MB.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my ($vdisk = 0, $capacity = 1000);

 if (vdiskExpand($vdisk, $capacity))
 {
     print "vdisk $vdisk expanded by $capacityMB\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
# Name: vdiskInfo
#
# Desc: Gets information on a vdisk
#
# In:   $id (system assigned)
#
# Returns:  Hash with Vdisk information, on error returns empty hash
##############################################################################
sub vdiskInfo
{
    my ($id) = _getArgs(1, @_);

    my %hash = _extractHashElementN(_executeAndParse("$cmd{VDISKINFO} \"$id\""),0);

    if (%hash)
    {
        if (exists($hash{RAID_ID_LIST}))
        {
            my $raidlist = _listToHash($hash{RAID_ID_LIST});

            $hash{RAID_TYPE} = $raidlist->[0]{RAID_TYPE};
            delete($hash{RAID_ID_LIST});
        }
    }
    return (%hash);
}

=head2 vdiskInfo

=over 4

Retrieves information about a virtual disk.  This command is available for Magnitude 3D and Magnitude.

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my $vdisk = 0;

 my %hash = vdiskInfo($vdisk);

 if (%hash)
 {
     print "vdisk $vdisk name = $hash{NAME}\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:


=item *

A hash with virtual disk information on success

=item

 AVERAGE_REQUESTS_PER_SECOND
 ID
 RAID_TYPE
 STATUS
 MIRROR_DEPTH
 UNINITIALIZED_CAPACITY
 COPY_SOURCE_ID
 WRITE_REQUEST_COUNT
 COPY_PERCENT_COMPLETE
 CAPACITY
 ATTRIBUTE
 NAME
 CACHE
 QUEUE_DEPTH
 NUMBER_OF_RAIDS
 MIRROR_COPY_STATUS
 AVERAGE_SECTOR_COUNT_PER_REQUEST
 SECTORS_PER_STRIPE
 READ_REQUEST_COUNT

=item *

an empty hash on error

=back

=cut
##############################################################################
# Name: vdiskList
#
# Desc: Returns an array of vdisk identifiers
#
# In:
#
# Returns:  a array reference with the vdisk list, undef on error
##############################################################################
sub vdiskList
{
    my $result = _executeAndParse("$cmd{VDISKLIST}");

    if (!defined($result))
    {
        return undef;
    }

    my %values = _extractHashElementN($result,0);

    my @list = ();

    if (%values)
    {
        @list = _createArray(\%values);
    }

    return (\@list);
}

=head2 vdiskList

An array of virtual disk IDs.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my $list = vdiskList();

 if ($list)
 {
     for (my $i = 0; $i < @$list; $i++)
     {
         print "$list->[$i]\n";
     }
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

a reference to an array of vdisk identifiers

=item *

undef on error

=back

=cut
##############################################################################
# Name: vdiskLock
#
# Desc: Turns on the lock for a vdisk
#
# In:   scalar  vdisk id
#
# Returns:  1 on success, 0 on error
##############################################################################
sub vdiskLock
{
    my ($id) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{VDISKLOCK} \"$id\" on")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskLock

Locks a virtual disk.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my $vdiskID = 0;

 if ($vdiskLock($vdiskID))
 {
     print "vdisk $vdisksID is locked\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskUnlock>

=back

=cut
##############################################################################
# Name: vdiskMask
#
# Desc: Associates a server and a virtual disk
#
# In:   $server The server id
#       $lun    The logical unit number
#       $vdisk  The vdisk id
#       $vport  The vport id
#
# Returns:  1 on success, 0 on error
##############################################################################
sub vdiskMask
{
    my ($workport, $lun, $vdisk, $vport) = _getArgs(4, @_);

    if (defined(_executeAndParse("$cmd{VDISKMASK} \"$workport\" \"$lun\" \"$vdisk\" \"$vport\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskMask

Associates a virtual disk with a workport/server.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

B<MAGNITUDE 3D>

 my $workport = 0;
 my $lun = 0;
 my $vdisk = 0;
 my $vport = 4;

 if (vdiskMask($workport, $lun, $vdisk, $vport))
 {
     print "Virtual disk $vdisk is associated with workport ",
     "$workport using $lun on vport $vport";
 }

B<MAGNITUDE>

 my $server = 0;
 my $lun = 0;
 my $vdisk = 0;

 if (vdiskMask($server, $lun, $vdisk))
 {
     print "Virtual disk $vdisk is associated with server ",
     $server using lun $lun";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskUnmask>

=back

=cut
##############################################################################
# Name: vdiskMaxCapacity
#
# Desc: Returns the maximum size of a possible vdisk
#
# In:   $raid_type
#
# Returns: string on success, undef on error
##############################################################################
sub vdiskMaxCapacity
{
    my ($raid_type) = _getArgs(1, @_);

    my %rc = _extractHashElementN(_executeAndParse("$cmd{VDISKMAXCAPACITY} \"$raid_type\""), 0);

    if (%rc)
    {
        return $rc{MAX_CAPACITY};
    }
    else
    {
        return undef;
    }
}

=head2 vdiskMaxCapacity

The maximum capacity a virtual disk can have based on a raid type.  This command
 is available for Magnitude 3D and Magnitude.  Supported raid types: Magnitude 3D, Release 2 - Raid 0, Raid 10.  Raid 0, 5, and 10 for all others.
 The capacity is in MB.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 reserve();
 workset(0);
 vblockSet(0);
 diskgroupSet(0);

 my $raidType = 10;
 my $capacity = vdiskMaxCapacity($raidType);

 if ($capacity)
 {
    print "max capacity for raid $raidType ",
          $capacity,
          "\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

Available space in megabytes on success

=item *

undef on error

=back

=cut
##############################################################################
# Name: vdiskMirror
#
# Desc: Performs a vdisk mirror
#
# In:   $source, $destination
#
# Returns: 1 on success, 0 on error
##############################################################################
sub vdiskMirror
{
    my ($source, $destination) = _getArgs(2, @_);

    if (defined(_executeAndParse("$cmd{VDISKMIRROR} \"$source\" \"$destination\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskMirror

Begins a virtual disk mirror operation.  This command is available for Magnitude 3D
 and Magnitude.  For Magnitude 3D the source and destination value can be in the form "vblock/vdisk_id" to allow mirroring
a virtual disk from one vblock to another.  For Magnitude the source and destination can be in the form of
"cluster/vdisk_id" to allow mirroring a virtual disk from one cluster to another.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my ($source = 0, $destination = 1);

 if (vdiskMirror($source, $destination))
 {
     print "Mirroring from vdisk $source to vdisk $destination\n";
 }

 my ($vblock = 1);

 if (vdiskMirror($source, "$vblock/$destination"))
 {
     print "Mirroring from vdisk $source to vdisk $vblock/$destination\n";
 }
 
 if (vdiskMirror("$vblock/$source", "$vblock/$destination"))
 {
     print "Mirroring from vdisk $vblock/$source to $vblock/$destination\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
# Name: vdiskMirrorBreak
#
# Desc: Performs a vdisk copy/swap
#
# In:   $destination
#
# Returns: 1 on success, 0 on error
##############################################################################
sub vdiskMirrorBreak
{
    my ($destination) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{VDISKMIRRORBREAK} \"$destination\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskMirrorBreak

Breaks a virtual disk mirror.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my ($destination = 1);

 if (vdiskMirrorBreak($destination))
 {
     print "Mirror is broken on vdisk $destination\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
# Name: vdiskMove
#
# Desc: Performs a vdisk move
#
# In:   $source, $destination
#
# Returns: 1 on success, 0 on error
##############################################################################
sub vdiskMove
{
    my ($source, $destination) = _getArgs(2, @_);

    if (defined(_executeAndParse("$cmd{VDISKMOVE} \"$source\" \"$destination\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskMove

Performs a virtual disk move operation.  This command is available for Magnitude 3D and Magnitude.
  For Magnitude 3D the source and destination value can be in the form "vblock/vdisk_id" to allow moving
a virtual disk from one vblock to another.  For Magnitude the source and destination can be in the form of
"cluster/vdisk_id" to allow moving a virtual disk from one cluster to another.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);
 reserve();

 my ($source = 0, $destination = 1);

 if (vdiskMove($source, $destination))
 {
     print "moving vdisk $source to vdisk $destination.\n";
 }

 my $vblock = 1;

 if (vdiskMove($source, "$vblock/$destination"))
 {
     print "Moving vdisk $source to vdisk $vblock/$destination\n";
 }
 
 if (vdiskMove("$vblock/$source", $vblock/$destination))
 {
     print "Moving vdisk $vblock/$source to $vblock/$destination\n"
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
# Name: vdiskName
#
# Desc: Sets the name for a vdisk
#
# In:   scalar  vdisk id  name
#
# Returns:  1 on success, 0 on error
##############################################################################
sub vdiskName
{
    my ($vdiskID, $name) = _getArgs(2, @_);

    if (defined(_executeAndParse("$cmd{VDISKNAME} \"$vdiskID\" \"$name\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskName

Change the name of a virtual disk.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my $vdiskID = 0;
 my $name = "FRED";

 if (vdiskName($vdiskID, $name) == 1)
 {
     print "vdisk $vdiskID has been renamed to $name\n";

     my %vdiskinfo = vdiskInfo($vdiskID);

     print "The name is $vdiskinfo{NAME}\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=item See also:

L</XIOdeviceSet>

=back

=cut
##############################################################################
# Name: vdiskUnlock
#
# Desc: Turns off the lock for a vdisk
#
# In:   scalar  vdisk id
#
# Returns:  1 on success, 0 on error
##############################################################################
sub vdiskUnlock
{
    my ($id) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{VDISKLOCK} \"$id\" off")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskUnlock

Unlocks a virtual disk.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my $vdiskID = 0;

 if (vdiskLockOff($vdiskID))
 {
     print "vdisk $vdiskID locked\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskLock>

=back

=cut
##############################################################################
# Name: vdiskUnmask
#
# Desc: Disasociates a server and a virtual disk
#
# In:   $server The server id
#       $vdisk  The vdisk id
#
# Returns:  1 on success, 0 on error
##############################################################################
sub vdiskUnmask
{
    my ($workport, $vdisk) = _getArgs(2, @_);

    if (defined(_executeAndParse("$cmd{VDISKUNMASK} \"$workport\" \"$vdisk\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vdiskUnmask

Disassociates a virtual disk with a server.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my $workport = 1;
 my $vdiskID = 0;

 if (vdiskUnmask($workport, $vdiskID))
 {
     print "Virtual disk $vdiskID is disassociated with workport ",
            $workport;
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskMask>

=back

=cut
##############################################################################
# Name: vdiskWriteCache
#
# Desc: Turns off the cache for a vdisk
#
# In:   scalar  vdisk_id [ on | off ]
#
# Returns:  1 on success, 0 on error
##############################################################################
sub vdiskWriteCache
{
     my ($parm1, $parm2) = _getArgs(2, @_);

     if (defined(_executeAndParse("$cmd{VDISKWRITECACHE} \"$parm1\" \"$parm2\"")))
     {
         return 1;
     }
     else
     {
         return 0;
     }
 }

=head2 vdiskWriteCache

Turns the write cache for a virtual disk on or off.  This command is available to Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
 <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
 <tr><td>

 reserve();
 workset(0);
 vblockset(0);

 if (vdiskWriteCache(0, "on"))
 {
     print "The vdisk writecache is on for vdisk 0\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskInfo> to determine cache state

=back

=cut
##############################################################################
#
#  VLINK Commands
#
#############################################################################

=head1 Virtual Link Commands

L</vlinkCount> E<verbar> L</vlinkCreate> E<verbar> L</vlinkList>

=cut
##############################################################################
#
# vlinkCount - returns the number of vlinks
#
##############################################################################
sub vlinkCount
{
    my %hash = _extractHashElementN(_executeAndParse("$cmd{VLINKCOUNT}", 0));

    if (%hash)
    {
        return $hash{COUNT};
    }
    else
    {
        return -1;
    }
}

=head2 vlinkCount

Returns the number of virtual links.  This command is available for Magnitude 3D and Magnitude.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 XIOdeviceSet(111111);

 $count = vlinkCount();

 print "There are $count vlinks\n";

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

Number of vlinks on success

=item *

-1 on failure

=back

=cut
##############################################################################
#
# vlinkCreate - creates a vlink
#
# In: vlink index, vdisk id to create
##############################################################################
sub vlinkCreate
{
    my ($index, $vdisk) = _getArgs(2, @_);

    if (defined(_executeAndParse("$cmd{VLINKCREATE} \"$index\" \"$vdisk\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vlinkCreate

Creates a vlink.  This command is available for Magnitude 3D and Magnitude.  The created vlink can be removed by using the vdiskDelete command.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);
 reserve();

 $count = vlinkCount();

 if ($count > 0)
 {
     my $vlinks = vlinkList();

    my %vlink = %{$vlinks->[0]};

     if ($vlink{LINKABLE})
     {
         if (vlinkCreate($vlink{INDEX}, 0))
         {
             print "Created vlink\n";
         }
     }
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vdiskDelete>

=back

=cut
##############################################################################
#
# vlinkList - Lists available vlinks
#
##############################################################################
sub vlinkList
{
    my $array = _executeAndParse("$cmd{VLINKLIST}");

    if (!defined($array))
    {
        return undef;
    }
    return $array;
}

=head2 vlinkList

Returns a list of vlinks

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);
 reserve();

 my $vlinks = vlinkList();

 if ($vlinks)
 {
     print "There are " . scalar(@$vlinks) . " vlinks\n";
     print "INDEX = " . $vlinks->[0]{INDEX};
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

A reference to an array of hashes.  Each hash is a vlink.

The hash contains the following keys:

 INDEX
 DSC
 LUN
 NAME
 CAPACITY
 RAID_TYPE
 LINKABLE

=item *

undef on failure

=back

=cut
##############################################################################
#
#  VPORT Commands
#
#############################################################################

=head1 VPort Commands

L</vportList>

=cut
##############################################################################
#
# vportList - Lists vports for the specified workport
#
##############################################################################
sub vportList
{
    my ($workport) = _getArgs(1, @_);

    my $array = _executeAndParse("$cmd{VPORTLIST} \"$workport\"");

    if (!defined($array))
    {
        return undef;
    }
    return $array;
}

=head2 vportList

Returns a list of vports for a workport

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 my $workport = 0;
 XIOdeviceSet(111111);
 workset(0);
 vblockSet(0);

 my $vports = vportList($workport);

 if ($vports)
 {
     print "There are " . scalar(@$vports) . " vports for workport $workport.\n";
     print "VPORT = " . $vports->[0]{VPORT};
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

A reference to an array of hashes.  Each hash contains vport information.

The hash contains the following keys:

 VPORT
 CONTROLLER
 HBA

=item *

undef on failure

=back

=cut

##############################################################################
#
#  VBLOCK Commands
#
#############################################################################

=head1 Vblock Commands

L</vblockAdd> E<verbar> L</vblockList> E<verbar> L</vblockRemove> E<verbar> L</vblockSet>

=cut
##############################################################################
# Name: vblockAdd
#
# Desc: Adds a vblock to the current workset
#
# In:   vblock
#
# Returns: 1 on success, 0 on error
##############################################################################
sub vblockAdd
{
    my ($vblock) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{VBLOCKADD} \"$vblock\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vblockAdd

Adds a vblock to the current workset.  This command is available to Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);

 my $vblock = 1;

 if (vblockAdd($vblock))
 {
     print "vblock $vblock has been added to workset 0\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vblockRemove>

=back

=cut

##############################################################################
# Name: vblockList
#
# Desc: Returns an array of available vblocks
#
# In: None
#
# Returns:  A reference to an array of available vblocks
##############################################################################
sub vblockList
{
    my $result = _executeAndParse("$cmd{VBLOCKLIST}");

    if (!defined($result))
    {
        return undef;
    }

    my %values = _extractHashElementN($result,0);

    my @list = ();

    if (%values)
    {
        @list = _createArray(\%values);
    }

    return (\@list);
}

=head2 vblockList

Returns a reference to an array of available vblock IDs.  This command is available for Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
 <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
 <tr><td>

 XIOdeviceSet(111111);

 my $list = vblockList();

 if ($list)
 {
     for (my $i = 0; $i < @$list; $i++)
     {
         print "$list->[$i]\n";
     }
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

a reference to an array of available vblocks

=item *

undef on error

=back

=cut
##############################################################################
# Name: vblockRemove
#
# Desc: Removes a vblock from the current workset
#
# In:   vblock
#
# Returns: 1 on success, 0 on error
##############################################################################
sub vblockRemove
{
    my ($vblock) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{VBLOCKREMOVE} \"$vblock\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vblockRemove

Removes a vblock from the current workset.  This command is available to Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);

 my $vblock = 1;

 if (vblockRemove($vblock))
 {
     print "vblock $vblock has been removed from workset 0\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</vblockAdd>

=back

=cut
##############################################################################
# Name: vblockSet
#
# Desc: Sets the current vblock to use
#
# In:   vblock
#
# Returns: 1 on success, 0 on error
##############################################################################
sub vblockSet
{
    my ($vblock) = _getArgs(1, @_);

    if (defined(_executeAndParse("$cmd{VBLOCKSET} \"$vblock\"")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 vblockSet

Selects the current vblock to use.  This command is available to Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(111111);
 workset(0);

 my $vblock = 0;

 if ($vblockSet($vblock))
 {
     print "The current vblock is now $vblock\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
#
#  Cluster Commands
#
#############################################################################

=head1 Cluster Commands

L</clusterSet>

=cut
##############################################################################
# Name: clusterset
#
# Desc: Sets the current cluster to use
#
# In:   workset or nothings
#
# Returns: 1 on success, 0 on error
##############################################################################
sub clusterSet
{
    my ($cluster) = _getArgs(1, @_);

    my $result = _executeAndParse("$cmd{CLUSTERSET} \"$cluster\"");

    if (!defined($result))
    {
        return 0;
    }

    return 1;
}

=head2 clusterSet

Selects the current cluster to use.  This command is available to Magnitude only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 clusterset(0);

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=cut
##############################################################################
#
#  WORKSET Commands
#
#############################################################################

=head1 Workset Commands

L</workset> E<verbar> L</worksetList>

=cut
##############################################################################
# Name: workset
#
# Desc: Sets the current workset to use
#
# In:   workset or nothing
#
# Returns: 1 on success, 0 on error
##############################################################################
sub workset
{
    my ($workset) = _getArgs(1, @_);

    my $result = _executeAndParse("$cmd{WORKSET} \"$workset\"");

    if (!defined($result))
    {
        return undef;
    }

    my %values = _extractHashElementN($result,0);

    my @list = ();

    if (%values)
    {
        @list = _createArray(\%values);
    }

    return (\@list);
}

=head2 workset

Selects the current workset to use.  This command is available to Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $list = workset(0);

 if (scalar(@$list) == 0)
 {
     print "There are no vblocks in workset 0\n";
 }
 else
 {
     print "workset 0 contains the following vblocks: ";

     for (my $i = 0; $i < scalar(@$list); $i++)
     {
         print "$list->[$i] ";
     }
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

A list of vblocks in the workset.

=item *

undef on failure

=back

=cut
##############################################################################
# Name: worksetList
#
# Desc: Gets the information for all the worksets
#
# In:   Nothing
#
# Returns: An array of hashes of workset information
##############################################################################
sub worksetList
{
    my $result = _executeAndParse("$cmd{WORKSETLIST}");

    if (!defined($result))
    {
        return undef;
    }

    for (my $i = 0; $i < scalar(@$result); $i++)
    {
        my @vblocks = split(/,/, $result->[$i]{VBLOCKS});      
        $result->[$i]{VBLOCKS} = \@vblocks;
    }
    return ($result);
}

=head2 worksetList

Retrieves a list of workset information.  The information consists of workset ID,
 workset NAME and the VBLOCKS contained in the workset.  This command is available to Magnitude 3D only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 XIOdeviceSet(10214);

 my $worksets = worksetList();

 for (my $i = 0; $i < @$worksets; $i++)
 {
     my %ws = %{$worksets->[$i]};

     print "ID = $ws{ID} ";
     print "NAME = $ws{NAME} ";
     print "VBLOCKS = ";

     my @vblocks = @{$ws{VBLOCKS}};

     for (my $j = 0; $j < @vblocks; $j++)
     {
         print "$vblocks[$j] ";
     }
     print "\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

An array of hashmaps containing workset information.  Keys in the hashmap are:

=item

 ID - ID of the workset
 NAME - name of the workset as set by the user
 VBLOCKS - an array of vblock IDs

=item *

undef on failure

=back

=cut
##############################################################################
#
#  HAB Commands
#
#############################################################################

=head1 HAB Commands

L</habAssign> E<verbar> L</habList> E<verbar> L</habUnassign>

=cut
##############################################################################
# Name: habAssign
#
# Desc: Assigns a hab to the current cluster
#
# In:   hab
#
# Returns: 1 on success, 0 on error
##############################################################################
sub habAssign
{
    my ($hab) = _getArgs(1, @_);

    my $result = _executeAndParse("$cmd{HABASSIGN} \"$hab\"");

    if (!defined($result))
    {
        return 0;
    }

    return 1;
}

=head2 habAssign

Assigns a hab to the current cluster.  This command is available to Magnitude only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 clusterSet(0);
 habAssign(0);

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</clusterSet>

=back

=cut
##############################################################################
# Name: habList
#
# Desc: Returns a list of unassigned habs
#
# Returns: A list of unassigned habs, undef on error
##############################################################################
sub habList
{
    my $result = _executeAndParse("$cmd{HABLIST}");

    if (!defined($result))
    {
        return undef;
    }

    my %values = _extractHashElementN($result,0);

    my @list = ();

    if (%values)
    {
        @list = _createArray(\%values);
    }

    return (\@list);
}

=head2 habList

Retrieves a list of unassigned habs.  This command is available to Magnitude only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $list = habList();
 habAssign($list->[0]);

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

A list of unassigned habs in success

=item *

0 on failure

=back

=over 4

=item See also:

L</clusterSet>

=back

=cut
##############################################################################
# Name: habUnassign
#
# Desc: Unassigns a hab from the current cluster
#
# In:   hab
#
# Returns: 1 on success, 0 on error
##############################################################################
sub habUnassign
{
    my ($hab) = _getArgs(1, @_);

    my $result = _executeAndParse("$cmd{HABUNASSIGN} \"$hab\"");

    if (!defined($result))
    {
        return 0;
    }

    return 1;
}

=head2 habUnassign

Unassigns a hab from the current cluster.  This command is available to Magnitude only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 clusterSet(0);
 habUnassign(0);

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</clusterSet>

=back

=cut
##############################################################################
#
#  Server Commands
#
#############################################################################

=head1 Server Commands

L</serverDelete> E<verbar> L<serverInfo> E<verbar> L</serverList> E<verbar> L</serverName>

=cut
##############################################################################
# Name: serverDelete
#
# Desc: Deletes a server from the current cluster
#
# In:   server id
#
# Returns: 1 on success, 0 on error
##############################################################################
sub serverDelete
{
    my ($server) = _getArgs(1, @_);

    my $result = _executeAndParse("$cmd{SERVERDELETE} \"$server\"");

    if (!defined($result))
    {
        return 0;
    }

    return 1;
}

=head2 serverDelete

Deletes a server from the current cluster.  This command is available to Magnitude only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 clusterSet(0);
 serverDelete(0);

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</clusterSet>

=back

=cut
##############################################################################
# Name: serverInfo
#
# Desc: Returns information about a server
#
# In:   server id
#
# Returns: server information on success, undef on failure
##############################################################################
sub serverInfo
{
    my ($server) = _getArgs(1, @_);

    my %hash = _extractHashElementN(_executeAndParse("$cmd{SERVERINFO} \"$server\""), 0);

    return (%hash);
}

=head2 serverInfo

Retrieves information about a server.  This command is available to Magnitude only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my %hash;

 clusterSet(0);
 %hash = serverInfo(0);

 if (%hash)
 {
    print "server name = " . $hash{NAME} ."\n";
 }

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

A hash of server information

 ACTIVITY
 STATUS
 NAME
 WWN
 ID
 ASSOCIATIONS

=item *

undef on failure

=back

=over 4

=item See also:

L</clusterSet>

=back

=cut
##############################################################################
# Name: serverList
#
# Desc: Lists servers for the current cluster
#
# In:   none
#
# Returns: list of servers on success, undef on failure
##############################################################################
sub serverList
{
    my $result = _executeAndParse("$cmd{SERVERLIST}");

    if (!defined($result))
    {
        return undef;
    }

    my %values = _extractHashElementN($result,0);

    my @list = ();

    if (%values)
    {
        @list = _createArray(\%values);
    }

    return (\@list);
}

=head2 serverList

List of available servers for the current cluster.
  This command is available to Magnitude only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $list;

 clusterSet(0);
 $list = serverList();
 print "There are " . @$list . " servers available\n";

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

reference to an array of servers on success

=item *

undef on failure

=back

=over 4

=item See also:

L</clusterSet>

=back

=cut
##############################################################################
# Name: serverName
#
# Desc: Names a server
#
# In:   server id
#
# Returns: 1 on success, 0 on failure
##############################################################################
sub serverName
{
    my ($server, $name) = _getArgs(2, @_);

    my $result = _executeAndParse("$cmd{SERVERNAME} \"$server\" \"$name\"");

    if (!defined($result))
    {
        return 0;
    }

    return 1;
}

=head2 serverName

Names a server.  This command is available to Magnitude only.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
<tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
<tr><td>

 my $list;

 clusterSet(0);
 $list = serverList();
 serverName($list->[0], "Bob");

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=item See also:

L</clusterSet>

=back

=cut
##############################################################################
#
#  Geo Pool Commands
#
#############################################################################

=head1 Geo Pool Commands

L</geopoolAdd> E<verbar> L<geopoolInfo> E<verbar> L</geopoolRemove>

A GeoRaid license is required for these commands.

=cut
##############################################################################
# Name: geopoolAdd
#
# Desc: Adds controller nodes and bays to a geo pool
#
# In: geo pool id, controller node ids, bay ids,
#
# Returns: 1 on success, 0 on error
##############################################################################
sub geopoolAdd
{
    my (@parms) = _getArgs(16, @_);

    if (defined(_executeAndParse("$cmd{GEOPOOLADD} @parms")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 geopoolAdd

Adds controller nodes or bays to a geo pool.  A GeoRaid license is required to use this command.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
        <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
        <tr><td>

 geopoolAdd($geopoolID, @controllerNodes, @bays);

 # adds controller node 1 and bays A, B to geo pool 0
 geopoolAdd(0, 1, "A", "B");

 # adds controller node 0 (as primary) and bays C, D to geo pool 1
 geopoolAdd(1, 0P, "C", "D");

 # moves bay A to geo pool 2
 geopoolAdd(2, "A");

 # moves controller node 1 to geo pool 2
 geopoolAdd(2, 1);

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=back

=cut
###############################################################################
# Name: geopoolInfo
#
# Desc: Retrieves information about a geopool
#
# In: geopool ID
#
# Returns: a hash of geo pool information on sucess
#          an empty hash on error
###############################################################################
sub geopoolInfo
{
    my ($geopoolID) = _getArgs(1, @_);

    return (_executeAndParse("$cmd{GEOPOOLINFO} \"$geopoolID\""));
}

=head2 geopoolInfo

Returns a hash of geo pool information.  A GeoRaid license is required to use this command.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 my %hash = geopoolInfo(0);

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

A hash of geo pool information:

 ID - ID of the geo pool 0-3
 NAME - Name of the geopool
 CN - A list of controller nodes
 BAYS - A list of bays
 PRIMARY_CN - The primary controller node

=item *

empty hash on failure

=back

=over 4

=back

=cut
###############################################################################
# Name: geopoolRemove
#
# Desc: Removes controller nodes or bays to a geo pool
#
# In: geopool ID
#
# Returns: 1 on sucess, 0 on error
###############################################################################
sub geopoolRemove
{
    my (@parms) = _getArgs(16, @_);

    if (defined(_executeAndParse("$cmd{GEOPOOLREMOVE} @parms")))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

=head2 geopoolRemove

Removes controller nodes or bays from a geo pool.  A GeoRaid license is required to use this command.

=over 4

=item Usage:

=for html <table border="0" cellpadding="1" cellspacing="0" width="95%" bgcolor="#000000">
    <tr><td align="center"><table border="0" cellpadding="4" cellspacing="0" width="100%" bgcolor="#e8e8e8">
    <tr><td>

 # removes controller node 1 and bays A, B from geo pool 0
 geopoolAdd(0, 1, "A", "B");

 # removes controller node 0 and bays C, D from geo pool 1
 geopoolAdd(1, 0, "C", "D");

=for html </td></tr></table></td></tr></table>

=item Returns:

=item *

1 on success

=item *

0 on failure

=back

=over 4

=back

=cut

1;
