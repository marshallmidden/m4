#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library - Wookiee 1 tests
#
#   11/09/2004  XIOtech   Damon Anderson
#
#   A set of library functions for integration testing. This set try to do
#   actions a user might do incorrectly.
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2004 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::Wookiee1.pm - Test that stress Mirror Resync feature.

$Id: Wookiee1.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL>
     <LI>Linux</LI>
     <LI>Windows</LI>
 </UL>

=end html

=head1 SYNOPSIS

This document describes the perl scripts to test the robustness of the
Linux OS with the minimal requirements that define a Wookiee deliverable.


=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

            W1TestEntry()

        The less significant ones

              <none>

=cut


#
# - what I am
#

package TestLibs::Wookiee1;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use XIOTech::cmdMgr;
use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;
use TestLibs::UETestSupport;


#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - local Constants used
#

#use constant ALLCTLRS     => 17;
#use constant SINGLECTLR   => 18;
#use constant MASTERCTLR   => 19;
#use constant SLAVECTLR    => 20;
#use constant ALLSLAVES    => 21;

#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 4298 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

    #



    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                      &W1TestEntry


                     );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.

 $moxaPtr: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.

 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller.

 $retIn: This is a controle variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the
          attached servers. When configuring systems, this list determines
          which WWNs will be associated with vdisks. If an entry in this
          list is not found on the system, it will be ignored. A WWN
          found on the system that is not included in the list will not
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this
        is the pointer to that controller object. It is one of the
        members of the list that $coPtr points to.




=back

=cut


###############################################################################


###############################################################################



###############################################################################


###############################################################################

=head2 WookieeTestCase01 function

This test case chooses a controller at random and then power cycles that
controller with the stepping and range passed in as test arguments. Idea
is mainly to test the boot process on Wookie controllers. Power is turned
off and then with varying delays it is allowed to boot.
The test has these basic steps...

     1) Set up delay seconds and range of seconds to run test variables.
     2) Choose controller at random.
     3) Verifies Mirroring is finished
     4) Verifies Active IO activity.
     5) Cycles power continiously for the period of time choosen. The amount of
        time givin to the controller to boot is increased or decressed (dependent
        on the test case) after each cycle.
     6) Gives controller time to fully come up, then unfails and verifies
        controller consistancy from when test was started.

=cut

=over 1

=item Usage:

 my $rc = WookieTestCase01( $coPtr, $snPtr, $retIn, $moxaIP, $moxaPtr,  $parmsPtr   );

 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $retIn is a control flag and should be GOOD
        $moxaIP is a pointer to a list of IPs
        $moxaPtr is a pointer to a list of moxa objects
        $parmsPtr is a pointer to a hash that is used for Test Case arguments.

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 In the end the choosen random controller should be up and 
 running and in a unfailed state.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.

=back

=cut


##############################################################################
#
#          Name: WookieeTestCase01
#
#        Inputs: controller list pointer, Moxa IP Address, Moxa, 
#                initial wait time until power off in sec., final wait time 
#                until power off in sec., wait time increment.
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Requirements: N-way controller configuration where N>1
#
#  Globals Used: none
#
#   Description: Loop that tests for failing of Linux system with power cycles
#                Only power cycles one controller choosen at random at the start
#                of the test.
#                Uses the moxa to cycle power
#
#
#      Defaults: initial and longest wait is 300 and 10 seconds
#                power off delay increment is -10 seconds
#
##############################################################################
sub WookieeTestCase01
{
    trace();
    my ($coPtr, $snPtr, $retIn, $moxaIP, $moxaPtr,  $parmsPtr  ) = @_;
    
    my $initialPowerOffDelay = $parmsPtr->{initialpoweroffdelay}; 
    my $finalPowerOffDelay = $parmsPtr->{finalpoweroffdelay}; 
    my $powerOffIncrement = $parmsPtr->{poweroffwaitstep};
        
    my $nextPowerOff;
    my @coList;
    my $numCtrls;
    my $randomControllerIndex;
    my $victimController;
    my $victimSerialNum;
    my $ret;
    my $mIdx;
    my $sIdx;
    my $tMap;
    my @moxaMap;
    my @moxaList;
    my $MRWTimeout;
    my $delay;                      #number of seconds to wait until next poweroff
    my @tMap;
    my @initialVdisks;
    my %mirrorData;
    my @activeServers;
    my $keepGoing = 1;
    my $ctlr;
    my $cycleCount;                 #Number of power cycles that will be performed.
    my $cycle;                      #used to keep track of the loop count for cycles.
    my @deadList;
    

    #Do they really want to run this test?
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    @moxaMap = @$moxaPtr;
    @moxaList = @$moxaIP;

    @coList = @$coPtr;
    $numCtrls = scalar( @coList);
    $randomControllerIndex = rand $numCtrls;
    $victimController = $coList[$randomControllerIndex];
    $victimSerialNum =  TestLibs::IntegCCBELib::GetSerial($victimController);
    #$victimSerialNum =  $victimController->{SERIALNUM};
    
    $MRWTimeout = 3600;  # time allowed for resync to finish  (3600 is good)

    #
    # Make sure we are working with at least two controller setup
    # identifies the master and slave
    #
    ($mIdx, $sIdx) = FindMasterPickSlave($coPtr);
    if ( ($mIdx == INVALID) || ($sIdx == INVALID) )
    {
        logInfo(">>>>>>>>> Error: could not find at least two controllers " .
                    "destined Master and Slave.");
        return ERROR;
    }
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $mIdx, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    #Initialize power wait delay to defaults if not defined.
    $initialPowerOffDelay = 300 if( $initialPowerOffDelay !~ /^\d+$/);
    $finalPowerOffDelay = 10 if( $finalPowerOffDelay !~ /^\d+$/ );
    $powerOffIncrement = -10 if( $powerOffIncrement !~ /^-?\d+$/ );
    #script is smart about incrementing in correct direction
    #$powerOffIncrement = abs $powerOffIncrement;


    # Check to make sure arguments are valid
    if( $initialPowerOffDelay <0 ||
        $finalPowerOffDelay <0 ) 
    {
        logError(">>>>>>> Failure of arguments, delay must be 0 seconds or " .
                    "greater.");
        return ERROR;
    }
    #Make sure powerOffIncrement is in negative so we countdown when final delay less
    #than initial delay
    if( ($finalPowerOffDelay < $initialPowerOffDelay) && ($powerOffIncrement >= 0)) 
    {
        logError(">>>>>>> Failure of argument. Final power off delay is less " .
            "than initial. Delay steps should be < 0");             
        return ERROR;
    }
    elsif( ($finalPowerOffDelay > $initialPowerOffDelay) && ($powerOffIncrement <= 0 )) 
    {
        logError(">>>>>>> Failure of argument. Final power off delay is " . 
                    "greater than initial. Delay steps should be > 0");
        return ERROR;
    }

    logInfo("");
    logInfo(" Test parameters:");
    logInfo("      Initial wait time seconds: $initialPowerOffDelay");
    logInfo("       Final wait legth seconds: $finalPowerOffDelay");
    logInfo("    Step this number of seconds: $powerOffIncrement");
    logInfo("Number of controllers passed in: $numCtrls");
    logInfo(" Random Target Power off victim: $victimController->{HOST}");
    logInfo("");
   
    #################################################################
    #
    # Execute cleanup and data collection at start
    #
    #
    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #

    # 
    # check ability to control the moxa power here. It beats waiting to have
    # a failed controller and no way to unfail it. The test just turns ON all
    # ports passed in to the test. 
    #

    $ret = PowerCheck ($moxaIP, $moxaPtr);
    if ( $ret !=0 )
    {
        logError(">>>>>> Failed PowerCheck");
        return ERROR;
    }

    #
    # Gets the controller ready for the main part of the test.
    # Sets delay/cycle values and turns off the victim controller
    #
    $ctlr = $coList[$randomControllerIndex];
    $delay = $initialPowerOffDelay;
    $cycleCount = int (abs( $finalPowerOffDelay - $initialPowerOffDelay) 
                        / abs($powerOffIncrement)) + 1;
    
    #
    #Can only send this before the power abuse loops since the amount of time given
    #to the controller to boot up might be too short to be able to reconnect and
    #send a new message.
    #
    CtlrLogTextAll($coPtr,"WookieTestCase01: Power off controller, delay $delay " .
                          "seconds between. [$initialPowerOffDelay, " . 
                          "$finalPowerOffDelay, $powerOffIncrement, $delay]");
    
    logInfo("Turning off the controller to start out the tests.");
    logInfo("-OFF-> Powering off controller $victimController->{HOST} (" . 
                localtime(time) . ")");
    $ret = TestLibs::IntegCCBELib::PowerChange(
            $moxaList[$randomControllerIndex], 
            $moxaMap[$randomControllerIndex], 0);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to power down the controller <<<<<<<<");
        return ERROR;
    }
    
    #Delay some before first power on to be nice to power supplis.
    logInfo("Waiting 30 seconds to be nice to power supplies before power on.");
    DelaySecs(30);
   

    #
    # Lets pound on power. The controller will love this.
    #
    $cycle = 0;
    while( $delay >= 0 and $keepGoing == 1)
    {
        $cycle++;   
        logInfo("\n\n--- Power cycle loop (will delay $delay seconds cycle: " . 
                "($cycle/$cycleCount) ---\n" .
                "[$initialPowerOffDelay, $finalPowerOffDelay, " .
                "$powerOffIncrement, $delay]");        
        
        #
        #Turning on the power for the victim controller. 
        #Power will then be cut shortly below.
        #
        logInfo("-ON-> Powering on controller $victimController->{HOST} (" . 
                localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                    $moxaList[$randomControllerIndex], 
                    $moxaMap[$randomControllerIndex], 1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power up the controller <<<<<<<<");
            return ERROR;
        }
         
        #
        # Turns off the power $delay seconds after the power has been turned on.
        # Wait a period of time based on the testcase arguments.
        #
        logInfo("Power now on. Will delay $delay seconds before next power off.");
        DelaySecs( $delay);
        logInfo("-OFF-> Powering off controller $victimController->{HOST} (" . 
                localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                    $moxaList[$randomControllerIndex], 
                    $moxaMap[$randomControllerIndex], 0);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power down the controller <<<<<<<<");
            return ERROR;
        }
        
        #
        # Lets be nice to the power supplies. Wait a bit before turning 
        # back on the power
        #
        logInfo("Controller $ctlr->{HOST} is off, waiting 30 seconds before ".
                "power up."); 
        DelaySecs( 30 );
              
        #
        # Increases or decreases (if powerOffIncrement is negative) the delay 
        # for the next round of power ON->delay->OFF cycles.
        #
        $delay += $powerOffIncrement;
        #
        # KeepGoing is treated like a boolean and controls when the power cycle
        # loop finishes. Checks to see if we are ending the test based on an 
        # increase in stepping of delay or decreasesing (powerOffIncrement) delay.
        #
        if( $finalPowerOffDelay == $initialPowerOffDelay) 
        {
            $keepGoing = 0;
        }
        #
        # If increasing it makes sure delay is less than or equal to the final 
        # delay time wished for.
        #
        elsif( $powerOffIncrement > 0 )
        {
            $keepGoing = $delay <= $finalPowerOffDelay ? 1 : 0;
        }
        #
        # If decreasing, make sure the delay is greater or equal to the final 
        # delay time wished for.
        #
        elsif( $powerOffIncrement < 0) 
        {
            $keepGoing = $delay >= $finalPowerOffDelay ? 1 : 0;
        }
        
    }

    logInfo("\n############# Power abuse loop completed #############");
    logInfo("\n\nCompleted all power cycles. Now will power up the system and " .
            "let it boot.");
    logInfo("-ON-> Powering on controller $victimController->{HOST} (" . 
            localtime(time) . ")");
    $ret = TestLibs::IntegCCBELib::PowerChange(
            $moxaList[$randomControllerIndex], 
            $moxaMap[$randomControllerIndex], 1);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to power up the controller  <<<<<<<<");
        return ERROR;
    }

    logInfo("Power now on. Delaying before reconnect.");
    # Lets wait full 2 mins to give the system/controller plenty of time 
    # before connection   
    DelaySecs( 150);
    # Reconnect to the controller(s)
    $ret = TestNReconnectAll($coPtr);
    if( $ret != GOOD) 
    {
        logError(">>>>>>>> Failed to reconnect to the controllers <<<<<<<<");
        return ERROR;
    }

    #Make sure we are up and running with Power UP Failed State on Controllers
    $ret = wookieTCPowerUpFailed( $victimController);
    if( $ret != GOOD) 
    {
        logInfo(">>>>>>>> Failed Power up Failed State <<<<<<<<");
        #return ERROR;
    }

    
    #
    # Find the master controller
    #
    logInfo("Searching for the master controller for the UnFailController method.");
    $mIdx = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $mIdx == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
        return ERROR;
    }

    #
    # Unfail controller
    #
    logInfo("Unfailing the controller ($victimController)  ");
    $ret = TestLibs::IntegCCBELib::UnFailController( 
                        $coList[$mIdx], $victimSerialNum );
    if (  $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to restore the controller to active duty " .
                "<<<<<<<<");
        return ERROR;
    }
 
    #
    # Failover timeline
    #
    @deadList = (INVALID);
    $ret = FailOverTimeLineNway( $coPtr, 120, $snPtr, \@deadList);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Verify test controller consistancy based from the start of the test.
    # Ensure nothing was broken
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("WookieeTestCase01 has completed successfully");
    logInfo("------------ End of Wookie power test case 1. ------------");

    return GOOD;
}

###############################################################################

=head2 WookieeTestCase05 function

This test case chooses two controllers at random and then uses these
two controllers as victums of power cycling. The fist choosen victum
controller is turned off and then the script waits a period of time
and then it turns off the second victum controller. The idea is that
this script is ran on a 2 way controller system and it is to probe if
there are any election timing issues and boot problems on the wookiee
systems.

[Note: In order to test election issues, run this test on a 2 controller
system.]

The test has these basic steps...

     1) Set up delay seconds and total run time in seconds and step variables.
     2) Choose two controllers at random.
     3) Verifies Mirroring is finished
     4) Verifies Active IO activity.
     5) Cycles power continiously for the period of time choosen on the two controllers
        delaying a period of time from turning off second controller from the fist. 
        The amount delay is increased or decreased based on test case parmaters.
        time givin to the controller to boot is increased or decressed (dependent
        on the test case) after each cycle.
     6) Gives controllers time to fully come up, then unfails and verifies
        the controller consistancy from when test was started.

=cut

=over 1

=item Usage:

 my $rc = WookieTestCase05( $coPtr, $snPtr, $retIn, $moxaIP, $moxaPtr,  $parmsPtr   );

 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $retIn is a control flag and should be GOOD
        $moxaIP is a pointer to a list of IPs
        $moxaPtr is a pointer to a list of moxa objects
        $parmsPtr is a pointer to a hash that is used for Test Case arguments.

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen other
 than some possiable network socket connection errors [noted during
 run time].

 In the end the choosen random controllers should be up and 
 running and in a unfailed state.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.

=back

=cut


##############################################################################
#
#          Name: WookieeTestCase05
#
#        Inputs: controller list pointer, Moxa IP Address, Moxa, 
#                initial wait time until power off in sec., final wait time 
#                until power off in sec., wait time increment.
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Requirements: N-way controller configuration where N>1
#
#  Globals Used: none
#
#   Description: Loop that tests for failing of Linux system with power cycles
#                More rigerious power cycle testing for dual (or greater) number
#                of controllers. 
#                Two random Controllers are power cycled with varying amounts of 
#                time between
#                cycling power from each other.
#                Uses the moxa to cycle power
#
#
#      Defaults: Power off diferential is 160 seconds
#                Power off wait delay step is 1 second.
#                Decending is true
#
##############################################################################
sub WookieeTestCase05
{
    trace();
    my ($coPtr, $snPtr, $retIn, $moxaIP, $moxaPtr, $parmsPtr ) = @_;
    
    my $powerOffMaxDiferential = $parmsPtr->{poweroffmaxdiferential};
    my $powerOffDiferentialStep = $parmsPtr->{poweroffdiferentialstep};
    my $decending = $parmsPtr->{decending};
    
    my $powerOffCount;
    
    my @coList;
    my $numCtrls;
    my $randomControllerIndex1;
    my $randomControllerIndex2;
    my $victimController1;
    my $victimSerialNum1;
    my $victimController2;
    my $victimSerialNum2;
    my $ret;
    my $mIdx;
    my $sIdx;
    my $tMap;
    my @moxaMap;
    my @moxaList;
    my $MRWTimeout;
    my $delay;                #number of seconds to wait until next poweroff
    my @tMap;
    my @initialVdisks;
    my @serialNums;
    my %mirrorData;
    my @activeServers;
    my $cycleCount;           #Number of power cycles that will be performed.

    #Do they really want to run this test?
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    @moxaMap = @$moxaPtr;
    @moxaList = @$moxaIP;

    @coList = @$coPtr;
    $numCtrls = scalar( @coList);

    #
    # Make sure we are working with at least two controller setup
    # identifies the master and slave
    #
    ($mIdx, $sIdx) = FindMasterPickSlave($coPtr);
    if ( ($mIdx == INVALID) || ($sIdx == INVALID) )
    {
        logInfo(">>>>>>>>> Error: could not find at least two controllers " .
                "destined Master and Slave.");
        return ERROR;
    }

    #Pick two random unique controllers
    $randomControllerIndex1 = rand $numCtrls;
    $victimController1 = $coList[$randomControllerIndex1];
    $victimSerialNum1 =  TestLibs::IntegCCBELib::GetSerial($victimController1);
    while( 1) 
    {
      $randomControllerIndex2 = rand $numCtrls;
      $victimController2 = $coList[$randomControllerIndex2];
      last if( $victimController1 != $victimController2);
    }
    $victimSerialNum2 = TestLibs::IntegCCBELib::GetSerial($victimController2);

    $MRWTimeout = 3600;               # time allowed for resync to finish

    #
    # Initialize power wait delay to defaults if not defined.
    #
    $powerOffMaxDiferential = 160 if( $powerOffMaxDiferential !~ /^\d+$/ );
    $powerOffDiferentialStep = 1 if( $powerOffDiferentialStep !~ /^\d+$/);
    $decending = 1 if( $decending < 0 or $decending > 1 );

    #
    # Check to make sure arguments are valid
    #
    if( $powerOffMaxDiferential <1 ) 
    {
        logError(">>>>>>> Failure of arguments, powerOffMaxDiferential must " .
                    "be greater than 0 seconds.");
        return ERROR;
    }
    
    #
    # Make sure powerOffIncrement is negative so we countdown when the final 
    # delay less than initial delay
    #
    if( $powerOffDiferentialStep <= 0)
    {
        logError(">>>>>>> Failure of argument. powerOffDiferentialStep is <=0. " .
                    "The step for the power cycle on the second victim " .
                    "shoudl be greater than 0.");                
        return ERROR;
    }
    if( $decending < 0 or $decending > 1) 
    {
        logError(">>>>>>> Failure of argument. Decending should be 1 for true " . 
                    "or 0 for false");
        return ERROR;
    }

    logInfo("");
    logInfo(" Test parameters:");
    logInfo("Longest time to wait before powering off second controller " . 
                "(powerOffMaxDiferential): $powerOffMaxDiferential");
    logInfo("Add or subtract this number of seconds for next cycle " .
                "(powerOffDiferentialStep): $powerOffDiferentialStep");
    logInfo("Time will be (decending, $decending): " . 
                ( $decending == 1 ?'true' : 'false' ) );
    logInfo("Number of controllers passed in: $numCtrls");
    logInfo("Random Target controller #1: $victimController1->{HOST}");
    logInfo("Random Target controller #2: $victimController2->{HOST}");
    logInfo("");
   





    #################################################################
    #
    # Execute cleanup and data collection at start
    #
    #
    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #

    # 
    # check ability to control the moxa power here. It beats waiting to have
    # a failed controller and no way to unfail it. The test just turns ON all
    # ports passed in to the test. 
    #

    $ret = PowerCheck ($moxaIP, $moxaPtr);
    if ( $ret !=0 )
    {
        logError
        return ERROR;
    }

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $mIdx, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    
    #
    # Sets the initial amount of time to wait before turning off the second controller
    # from the first.
    #
    if( $decending > 0) 
    {
      $delay = $powerOffMaxDiferential;
       # make this negative so we take time away instead of adding
      $powerOffDiferentialStep *= -1; 
    }
    else
    {
      $delay = 0;
    }
    
    #
    # Lets pound on power. The controllers will love this.
    #
    $powerOffCount=0;
    $cycleCount = abs( int($powerOffMaxDiferential/$powerOffDiferentialStep)) + 1;
    while( $delay >= 0 and $delay <= $powerOffMaxDiferential )
    {
        #Log a message on the controllers of each power cycle loop
        CtlrLogTextAll($coPtr,"Loop $powerOffCount: Power off both controllers, " . 
                        "delay $delay seconds between. [$powerOffMaxDiferential, " .
                        "$powerOffDiferentialStep, $delay]");
        
        logInfo("\n\n--- Start of power cycle loop (will delay $delay seconds " .
                    "cycle: " . ($powerOffCount+1) . "/$cycleCount) ---");
        
        #
        # Power off first victim controller
        #
        logInfo("-OFF-> Powering off first victim controller " . 
                "$victimController1->{HOST} (" . localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                $moxaList[$randomControllerIndex1], 
                $moxaMap[$randomControllerIndex1], 0);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power down the controller " .
                "[$powerOffCount powerOff's completed]  <<<<<<<<");
            return ERROR;
        }

        #
        # Waiting a period of time before turning off second random victim controller.
        #
        logInfo("Waiting $delay seconds before powering off second victim " .
                "controller.");
        DelaySecs( $delay);
            
        #    
        # Turning off the second random victim controller.
        #
        logInfo("-OFF-> Powering off second victim controller " .
                "$victimController2->{HOST} (" . localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                $moxaList[$randomControllerIndex2], 
                $moxaMap[$randomControllerIndex2], 0);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power down the controller " . 
                "[$powerOffCount powerOff's completed]  <<<<<<<<");
            return ERROR;
        }
        
        $powerOffCount++;
        # calculate the amount of delay for the next run through of the loop.
        $delay += $powerOffDiferentialStep;
        
        logInfo("Power now off for both controllers. Power off count: $powerOffCount");

        # Lets be nice to the power supplies. Wait a bit before turning back 
        # on the power
        DelaySecs(30);
        
        #
        # turn on the power for first victim controller (both are turned on 
        # with no intended delay)
        #
        logInfo("-ON-> Powering on controller $victimController1->{HOST} (" . 
                localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                $moxaList[$randomControllerIndex1], 
                $moxaMap[$randomControllerIndex1], 1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power up the controller " . 
                        "[$powerOffCount powerOff's]  <<<<<<<<");
            return ERROR;
        }
        
        #
        # turn on the power for the second victim controller (both are turned on 
        # with no intended delay)
        #
        logInfo("-ON-> Powering on controller $victimController2->{HOST} (" . 
                    localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                    $moxaList[$randomControllerIndex2], 
                    $moxaMap[$randomControllerIndex2], 1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power up the controller " .
                        "[$powerOffCount powerOff's]  <<<<<<<<");
            return ERROR;
        }
        
        
        logInfo("Now giving both systems time to fully boot up.");
        DelaySecs( 180);
        
        
        # Reconnect to the controllers since they were both turned off completly.
        $ret = TestNReconnectAll($coPtr);
        if( $ret != GOOD) 
        {
            logError(">>>>>>>> Failed to reconnect to the controllers <<<<<<<<");
            return ERROR;
        }
        
        #da - will need something like this later
        #if ( $xtcDPtr )
        #{
        #    $xtcDPtr->{TESTLOOPS} =  $powerOffCount;
        #}
    }

    logInfo("\n########### Power abuse loop completed ###########");

    
    #
    # Unfail the controllers
    #
    logInfo("Unfailing any controller that is failed");
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $moxaPtr );
    if ( $ret != GOOD ) { 
        logInfo(">>>>>>>> Failed to restore the controller to active duty  " .
                "<<<<<<<<");
        return ERROR; 
    }

    
    #
    # Verify controller consistancy based on how they were from the start 
    # of the test.
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("WookieeTestCase05 has completed successfully");
    logInfo("------------ End of Wookie power test case 05. ------------");

    return GOOD;
}


###############################################################################

=head2 WookieeTestCase07 function

This test case chooses two controllers at random and then uses these
two controllers as victums of power cycling. The fist choosen victum
controller is turned off and then the script waits a period of time
and then it turns off the second victum controller. The idea is that
this script is ran on a 2 way controller system and it is to probe if
there are any election timing issues and boot problems on the wookiee
systems.
[Note: this test differs from Test Case 05 only by the addition of
a new argument for specifying the Minimum delay between shutting down
the second controller. Test Cast 05 runs to/from 0 seconds for Minimum.]

[Note 2: In order to test election issues, run this test on a 2 controller
system.]

The test has these basic steps...

     1) Sets up delay/step and timing range variables in seconds.
     2) Choose two controllers at random.
     3) Verifies Mirroring is finished
     4) Verifies Active IO activity.
     5) Cycles power continiously for the period of time choosen on the two controllers
        delaying a period of time from turning off second controller from the fist. 
        The amount delay is increased or decreased based on test case parmaters.
     6) Gives controllers time to fully come up, then unfails and verifies
        the controller consistancy from when test was started.

=cut

=over 1

=item Usage:

 my $rc = WookieTestCase07( $coPtr, $snPtr, $retIn, $moxaIP, $moxaPtr,  $parmsPtr   );

 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $retIn is a control flag and should be GOOD
        $moxaIP is a pointer to a list of IPs
        $moxaPtr is a pointer to a list of moxa objects
        $parmsPtr is a pointer to a hash that is used for Test Case arguments.

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen other
 than some possiable network socket connection errors [noted during
 run time].

 In the end the choosen random controllers should be up and 
 running and in a unfailed state.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.

=back

=cut

##############################################################################
#
#          Name: WookieeTestCase07
#
#        Inputs: controller list pointer, Moxa IP Address, Moxa, 
#                initial wait time until power off in sec., final wait time 
#                until power off in sec., wait time increment.
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Requirements: N-way controller configuration where N>1
#
#  Globals Used: none
#
#   Description: (Identical to Test Case 05, but adds another argument for 
#                starting or stoping delay seconds at a value other than 0.)
#                Loop that tests for failing of Linux system with power cycles
#                More rigerious power cycle testing for dual (or greater) number
#                of controllers. 
#                Two random Controllers are power cycled with varying amounts of 
#                time between cycling power from each other.
#                Uses the moxa to cycle power
#
#
#      Defaults: Power off diferential is 160 seconds
#                Power off wait delay step is 1 second.
#                Decending is true
#
##############################################################################
sub WookieeTestCase07
{
    trace();
    my ($coPtr, $snPtr, $retIn, $moxaIP, $moxaPtr, $parmsPtr ) = @_;
    
    my $powerOffMaxDiferential = $parmsPtr->{poweroffmaxdiferential};
    my $powerOffMinDiferential = $parmsPtr->{poweroffmindiferential};
    my $powerOffDiferentialStep = $parmsPtr->{poweroffdiferentialstep};
    my $decending = $parmsPtr->{decending};
    
    my $powerOffCount;
    
    my @coList;
    my $numCtrls;
    my $randomControllerIndex1;
    my $randomControllerIndex2;
    my $victimController1;
    my $victimSerialNum1;
    my $victimController2;
    my $victimSerialNum2;
    my $ret;
    my $mIdx;
    my $sIdx;
    my $tMap;
    my @moxaMap;
    my @moxaList;
    my $MRWTimeout;
    my $delay;              #number of seconds to wait until next poweroff
    my @tMap;
    my @initialVdisks;
    my @serialNums;
    my %mirrorData;
    my @activeServers;
    my $cycleCount;         #Number of power cycles that will be performed.

    #Do they really want to run this test?
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    @moxaMap = @$moxaPtr;
    @moxaList = @$moxaIP;

    @coList = @$coPtr;
    $numCtrls = scalar( @coList);

    #
    # Make sure we are working with at least two controller setup
    # identifies the master and slave
    #
    ($mIdx, $sIdx) = FindMasterPickSlave($coPtr);
    if ( ($mIdx == INVALID) || ($sIdx == INVALID) )
    {
        logInfo(">>>>>>>>> Error: could not find at least two controllers " .
                "destined Master and Slave.");
        return ERROR;
    }

    #
    # Pick two random unique controllers
    #
    $randomControllerIndex1 = rand $numCtrls;
    $victimController1 = $coList[$randomControllerIndex1];
    $victimSerialNum1 =  TestLibs::IntegCCBELib::GetSerial($victimController1);
    
    #
    # Keep cycling until we have a second victim controller different from 
    # the first victim controller choosen at random.
    #
    while( 1) 
    {
      $randomControllerIndex2 = rand $numCtrls;
      $victimController2 = $coList[$randomControllerIndex2];
      last if( $victimController1 != $victimController2);
    }
    $victimSerialNum2 = TestLibs::IntegCCBELib::GetSerial($victimController2);

    $MRWTimeout = 3600;               # time allowed for resync to finish


    #
    # Initialize power loop variables to defaults if not defined.
    #
    $powerOffMaxDiferential = 160 if( $powerOffMaxDiferential !~ /^\d+$/ );
    $powerOffMinDiferential = 10 if( $powerOffMinDiferential !~ /^\d+$/ );
    $powerOffDiferentialStep = 1 if( $powerOffDiferentialStep !~ /^\d+$/ );
    $decending = 1 if( $decending < 0 or $decending > 1 );


    #
    # Check to make sure arguments are valid
    #
    if( $powerOffMaxDiferential <1 ) 
    {
        logError(">>>>>>> Failure of arguments, powerOffMaxDiferential must " . 
                    "be greater than 0 seconds.");
        return ERROR;
    }
    if( $powerOffMinDiferential < 0 || 
            $powerOffMinDiferential> $powerOffMaxDiferential) 
    {
        logError(">>>>>>> Failure of arguments, powerOffMinDiferential must be " .
            "equal to or greater than 0 seconds and less than your max setting " . 
            "($powerOffMaxDiferential).");
        return ERROR;
    }
    
    #
    # Make sure powerOffIncrement is in negative so we countdown when final 
    # delay less than initial delay
    #
    if( $powerOffDiferentialStep <= 0)
    {
        logError(">>>>>>> Failure of argument. powerOffDiferentialStep is <=0. " .
            "The step for the power cycle on the second victim controller " . 
            "should be greater than 0.");                
        return ERROR;
    }
    if( $decending < 0 or $decending > 1) 
    {
        logError(">>>>>>> Failure of argument. Decending should be 1 for true " .
            "or 0 for false");
        return ERROR;
    }

    logInfo("");
    logInfo(" Test parameters:");
    logInfo("Longest time to wait before powering off second controller " .
                "(powerOffMaxDiferential): $powerOffMaxDiferential");
    logInfo("Shortest time to wait before powering off second controller " .
                "(powerOffMinDiferential): $powerOffMinDiferential");
    logInfo("Add or subtract this number of seconds for next cycle " . 
                "(powerOffDiferentialStep): $powerOffDiferentialStep");
    logInfo("Time will be (decending, $decending): " . 
                ( $decending == 1 ?'true' : 'false' ) );
    logInfo("Number of controllers passed in: $numCtrls");
    logInfo("Random Target controller #1: $victimController1->{HOST}");
    logInfo("Random Target controller #2: $victimController2->{HOST}");
    logInfo("");
   



    #################################################################
    #
    # Execute cleanup and data collection at start
    #
    #
    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #

    # 
    # check ability to control the moxa power here. It beats waiting to have
    # a failed controller and no way to unfail it. The test just turns ON all
    # ports passed in to the test. 
    #

    $ret = PowerCheck ($moxaIP, $moxaPtr);
    if ( $ret !=0 )
    {
        logError
        return ERROR;
    }

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $mIdx, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    #Calculate how many times we will cycle through the test
    $cycleCount = int(($powerOffMaxDiferential - $powerOffMinDiferential)
                        /abs($powerOffDiferentialStep)) + 1;
                        
                        
    #
    # Sets the initial amount of time to wait before turning off the second 
    # controller from the first.
    #
    if( $decending > 0) 
    {
      $delay = $powerOffMaxDiferential;
      # make sure this negative so we take time away instead of adding
      $powerOffDiferentialStep *= -1;  
    }
    else
    {
      $delay = $powerOffMinDiferential;
    }
    
    
    #
    # Lets pound on power. The controllers will love this.
    #
    $powerOffCount=0;
    while( $delay >= 0 and $delay <= $powerOffMaxDiferential and 
                $delay >= $powerOffMinDiferential )
    {
        # Log a message on the controllers of each power cycle loop
        CtlrLogTextAll($coPtr,
            "Loop $powerOffCount: Power off both controllers, delay $delay " . 
            "seconds between. [$powerOffMinDiferential, $powerOffMaxDiferential," .
            " $powerOffDiferentialStep, $delay]");
        
        logInfo("\n\n--- Start of power cycle loop (will delay $delay seconds " . 
            "cycle: " . ($powerOffCount+1) . "/$cycleCount) ---");
        
       
        #
        # Power off first victim controller
        #
        logInfo("-OFF-> Powering off first victim controller " . 
                "$victimController1->{HOST} (" . localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                        $moxaList[$randomControllerIndex1], 
                        $moxaMap[$randomControllerIndex1], 0);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power down the controller [$powerOffCount " . 
                        "powerOff's completed]  <<<<<<<<");
            return ERROR;
        }

        #
        # Waiting a period of time before turning off second random victim controller.
        #
        logInfo("Waiting $delay seconds before powering off second victim " .
                "controller.");
        DelaySecs( $delay);
        logInfo("-OFF-> Powering off second victim controller " .
                "$victimController2->{HOST} (" . localtime(time) . ")");  
                
        #    
        # Turning off the second random victim controller.
        #
        $ret = TestLibs::IntegCCBELib::PowerChange(
                $moxaList[$randomControllerIndex2], 
                $moxaMap[$randomControllerIndex2], 0);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power down the controller " .
                "[$powerOffCount powerOff's completed]  <<<<<<<<");
            return ERROR;
        }
        
        $powerOffCount++;
        # calculate the amount of delay for the next run through of the loop.
        $delay += $powerOffDiferentialStep;
        
        logInfo("Power now off for both controllers. Power off count: $powerOffCount");

        # Lets be nice to the power supplies. Wait a bit before turning back on the power
        DelaySecs(30);
        
        #
        # turn on the power for first victim controller (both are turned on 
        # with no intended delay)
        #
        logInfo("-ON-> Powering on controller $victimController1->{HOST} (" . 
                localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                $moxaList[$randomControllerIndex1], 
                $moxaMap[$randomControllerIndex1], 1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power up the controller " . 
                        "[$powerOffCount powerOff's]  <<<<<<<<");
            return ERROR;
        }
        
        
        #
        # turn on the power for the second victim controller (both are turned on 
        # with no intended delay)
        #
        logInfo("-ON-> Powering on controller $victimController2->{HOST} (" . 
                    localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                    $moxaList[$randomControllerIndex2], 
                    $moxaMap[$randomControllerIndex2], 1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power up the controller " . 
                        "[$powerOffCount powerOff's]  <<<<<<<<");
            return ERROR;
        }
        
        logInfo("Now giving both systems time to fully boot up.");
        DelaySecs( 180);
        
        # reconnect to the controllers since they were both turned off completly.
        $ret = TestNReconnectAll($coPtr);
        if( $ret != GOOD) 
        {
            logError(">>>>>>>> Failed to reconnect to the controllers <<<<<<<<");
            return ERROR;
        }
        
        #da - will need something like this later
        #if ( $xtcDPtr )
        #{
        #    $xtcDPtr->{TESTLOOPS} =  $powerOffCount;
        #}
    }

    logInfo("\n########### Power abuse loop completed ###########");

    
    #
    # Unfail the controllers
    #
    logInfo("Unfailing any controller that is failed");
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $moxaPtr );
    if ( $ret != GOOD ) { 
        logInfo(">>>>>>>> Failed to restore the controller to active duty  " . 
                "<<<<<<<<");
        return ERROR; 
    }
      
    #
    # Verify controller consistancy based on how they were from the start 
    # of the test.
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("WookieeTestCase05 has completed successfully");
    logInfo("------------ End of Wookie power test case 05. ------------");

    return GOOD;
}


###############################################################################

=head2 WookieeTestCase10 function

This test case chooses two controllers, one random and the other 
always the master as victums of power cycling. The master
controller is turned off and then the script waits a period of time
and then it turns off the second victum controller. The idea is that
this script runs on a 2 way controller system and it is to probe if
there are any election timing issues and boot problems on the wookiee
systems.

[Note: this test differs from Test Case 07 by the addition of always
having the first controller being turned off as the master controller
and all failed controllers are unfailed after each dual powercycle.]

The test has these basic steps...

     1) Sets up delay timing variables.
     2) Finds Master and then choose one random slave victum controller.
     3) Verifies Mirroring is finished
     4) Verifies Active IO activity.
     5) Cycles power continiously for the period of time choosen on the two controllers
        delaying a period of time from turning off second controller from the fist. 
        The amount delay is increased or decreased based on test case parmaters.
        Time givin before the second controller is powered off is increased or 
        decressed (dependent on the test case) after each cycle.
        5.1) Unfails all controllers at the end of each cycle.
     6) Gives controllers time to fully come up, then unfails and verifies
        the controller consistancy from when test was started.

=cut

=over 1

=item Usage:

 my $rc = WookieTestCase10( $coPtr, $snPtr, $retIn, $moxaIP, $moxaPtr,  $parmsPtr   );

 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $retIn is a control flag and should be GOOD
        $moxaIP is a pointer to a list of IPs
        $moxaPtr is a pointer to a list of moxa objects
        $parmsPtr is a pointer to a hash that is used for Test Case arguments.

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen other
 than some possiable network socket connection errors [noted during
 run time].

 In the end the choosen random controllers should be up and 
 running and in a unfailed state.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.

=back

=cut

##############################################################################
#
#          Name: WookieeTestCase10
#
#        Inputs: controller list pointer, Moxa IP Address, Moxa, 
#                initial wait time until power off in sec., final wait time 
#                until power off in sec., wait time increment.
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Requirements: N-way controller configuration where N>1
#
#  Globals Used: none
#
#   Description: Loop that tests for failing of controller with power cycles.
#                The victim controllers are as follows, victim2 is choosen at
#                random at the begining of the test. Victim1 controller changes
#                just before powerOff to the master controller.
#
#                Controllers are power cycled with varying amounts of time between
#                cycling power from each other.
#                Uses the moxa to cycle power
#
#
#      Defaults: Power off Maximum Diferential is 160 seconds
#                Power off Minimum Diferential is 10 seconds.
#                Power off wait delay step is 1 second.
#                Decending is true
#
##############################################################################
sub WookieeTestCase10
{
    trace();
    my ($coPtr, $snPtr, $retIn, $moxaIP, $moxaPtr,  $parmsPtr ) = @_;
    
    my $powerOffMaxDiferential = $parmsPtr->{poweroffmaxdiferential};
    my $powerOffMinDiferential = $parmsPtr->{poweroffmindiferential};
    my $powerOffDiferentialStep = $parmsPtr->{poweroffdiferentialstep};
    my $decending = $parmsPtr->{decending};

    my $powerOffCount;
    
    my @coList;
    my $numCtrls;
    my $randomControllerIndex1;
    my $randomControllerIndex2;
    my $victimController1;
    my $victimSerialNum1;
    my $victimController2;
    my $victimSerialNum2;
    my $ret;
    my $mIdx;
    my $sIdx;
    my $tMap;
    my @moxaMap;
    my @moxaList;
    my $MRWTimeout;
    my $delay;              #number of seconds to wait until next poweroff
    my @tMap;
    my @initialVdisks;
    my @serialNums;
    my %mirrorData;
    my @activeServers;
    my $cycleCount;         #Number of power cycles that will be performed.

    #Do they really want to run this test?
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    @moxaMap = @$moxaPtr;
    @moxaList = @$moxaIP;

    @coList = @$coPtr;
    $numCtrls = scalar( @coList);

    #
    # Make sure we are working with at least two controller setup
    # identifies the master and slave
    #
    # sIdx is chosen at random when N>2
    #
    ($mIdx, $sIdx) = FindMasterPickSlave($coPtr);
    if ( ($mIdx == INVALID) || ($sIdx == INVALID) )
    {
        logInfo(">>>>>>>>> Error: could not find at least two controllers " . 
                "destined Master and Slave.");
        return ERROR;
    }

    #
    # Set up the variables to show the serial of the controller and indexes for 
    # power methods.
    #
    $victimController2 = $coList[$sIdx];
    $victimSerialNum2 =  TestLibs::IntegCCBELib::GetSerial($victimController2);
    $randomControllerIndex2 = $sIdx;
    $victimController1 = $coList[$mIdx];
    $victimSerialNum1 = TestLibs::IntegCCBELib::GetSerial($victimController1);
    $randomControllerIndex1 = $mIdx;


    # time allowed for resync to finish
    $MRWTimeout = 8600; 

    # Initialize power wait delay to defaults if not defined.
    $powerOffMaxDiferential = 160 if( $powerOffMaxDiferential !~ /^\d+$/ );
    $powerOffMinDiferential = 10 if( $powerOffMinDiferential !~ /^\d+$/ );
    $powerOffDiferentialStep = 1 if( $powerOffDiferentialStep !~ /^\d+$/ );
    $decending = 1 if( $decending < 0 or $decending > 1 );


    #
    # Check to make sure arguments are valid
    #
    if( $powerOffMaxDiferential <1 ) 
    {
        logError(">>>>>>> Failure of arguments, powerOffMaxDiferential must " . 
                    "be greater than 0 seconds.");
        return ERROR;
    }
    if( $powerOffMinDiferential < 0 || 
            $powerOffMinDiferential> $powerOffMaxDiferential) 
    {
        logError(">>>>>>> Failure of arguments, powerOffMinDiferential must be " . 
                    "equal to or greater than 0 seconds and less than your max " .
                    " setting ($powerOffMaxDiferential).");
        return ERROR;
    }
    
    #
    # Make sure powerOffIncrement is negative so we countdown when the final 
    # delay less than initial delay
    #
    if( $powerOffDiferentialStep <= 0)
    {
        logError(">>>>>>> Failure of argument. powerOffDiferentialStep is <=0. " . 
            "The step for the power cycle on the second victim controller should " . 
            "be greater than 0.");                
        return ERROR;
    }
    if( $decending < 0 or $decending > 1) 
    {
        logError(">>>>>>> Failure of argument. Decending should be 1 for true " . 
        " or 0 for false");
        return ERROR;
    }
                   
    logInfo("");
    logInfo(" Test parameters:");
    logInfo("Longest time to wait before powering off second controller " .
                "(powerOffMaxDiferential): $powerOffMaxDiferential");
    logInfo("Shortest time to wait before powering off second controller " . 
                "(powerOffMinDiferential): $powerOffMinDiferential");
    logInfo("Add or subtract this number of seconds for next cycle " . 
                "(powerOffDiferentialStep): $powerOffDiferentialStep");
    logInfo("Time will be (decending, $decending): " . 
                ( $decending == 1 ?'true' : 'false' ) );
    logInfo("Number of controllers passed in: $numCtrls");
    logInfo("Master Target controller #1: $victimController1->{HOST}");
    logInfo("Random Target controller #2: $victimController2->{HOST}");
    logInfo("");
   





    #################################################################
    #
    # Execute cleanup and data collection at start
    #
    #
    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #

    # 
    # check ability to control the moxa power here. It beats waiting to have
    # a failed controller and no way to unfail it. The test just turns ON all
    # ports passed in to the test. 
    #

    $ret = PowerCheck ($moxaIP, $moxaPtr);
    if ( $ret !=0 )
    {
        logError
        return ERROR;
    }

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $mIdx, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    
    #
    # Sets the initial amount of time to wait before turning off the second controller
    # from the first.
    #
    if( $decending > 0) 
    {
      $delay = $powerOffMaxDiferential;
      # make this negative so we take time away instead of adding
      $powerOffDiferentialStep *= -1;        
    }
    else
    {
      $delay = $powerOffMinDiferential;
    }
    
    #
    # Lets pound on power. The controllers will love this.
    #
    $powerOffCount = 0;
    $cycleCount = int(($powerOffMaxDiferential - $powerOffMinDiferential)
                        /abs($powerOffDiferentialStep)) + 1;
    while( $delay >= $powerOffMinDiferential and $delay <= $powerOffMaxDiferential )
    {
        #Log a message on the controllers of each power cycle loop
        CtlrLogTextAll($coPtr,"Loop $powerOffCount: Power off both controllers, " . 
                        "delay $delay seconds between. [$powerOffMinDiferential, " .
                        "$powerOffMaxDiferential, $powerOffDiferentialStep, $delay]");
    
        logInfo("\n\n--- Start of power cycle loop (will delay $delay seconds " . 
                    "cycle: " . ($powerOffCount+1) . "/$cycleCount) ---");
        
        #
        # Power off first victim controller (always master)
        #
        logInfo("-OFF-> Powering off master controller " . 
                "$victimController1->{HOST} (" . localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                $moxaList[$mIdx], $moxaMap[$mIdx], 0);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power down the controller " . 
                "[$powerOffCount powerOff's completed]  <<<<<<<<");
            return ERROR;
        }

        
        #
        # Waiting a period of time before turning off second random victim controller.
        #
        logInfo("Waiting $delay seconds before powering off second victim " . 
                "controller.");
        DelaySecs( $delay);
        
        #    
        # Turning off the second random victim controller.
        #
        logInfo("-OFF-> Powering off second victim controller " . 
                    "$victimController2->{HOST} (" . localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                    $moxaList[$randomControllerIndex2], 
                    $moxaMap[$randomControllerIndex2], 0);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power down the controller " . 
                        "[$powerOffCount powerOff's completed]  <<<<<<<<");
            return ERROR;
        }
        
        $powerOffCount++;
        # calculate the amount of delay for the next run through of the loop.
        $delay += $powerOffDiferentialStep;
        
        logInfo("Power now off for both controllers. Power off count: $powerOffCount");

        # Lets be nice to the power supplies. Wait a bit before turning back on the power
        DelaySecs(30);
        
        
        #
        # turn on the power for the second victim controller (both are turned on 
        # with no intended delay)
        #
        logInfo("-ON-> Powering on controller $victimController1->{HOST} (" . 
                    localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                    $moxaList[$randomControllerIndex1], 
                    $moxaMap[$randomControllerIndex1], 1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power up the controller " . 
                "[$powerOffCount powerOff's]  <<<<<<<<");
            return ERROR;
        }
       
        #
        # turn on the power for the second victim controller (both are turned on 
        # with no intended delay)
        #
        logInfo("-ON-> Powering on controller $victimController2->{HOST} (" . 
                    localtime(time) . ")");
        $ret = TestLibs::IntegCCBELib::PowerChange(
                    $moxaList[$randomControllerIndex2], 
                    $moxaMap[$randomControllerIndex2], 1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power up the controller " . 
                        "[$powerOffCount powerOff's]  <<<<<<<<");
            return ERROR;
        }
        
        logInfo("Now giving both systems time to fully boot up.");
        DelaySecs( 180);

        # Reconnect to the controllers since they were both turned off completly.
        $ret = TestNReconnectAll($coPtr);
        if( $ret != GOOD) 
        {
            logError(">>>>>>>> Failed to reconnect to the controllers <<<<<<<<");
            return ERROR;
        }

        
        #
        # Test to see if we are on our last run through the while power cycle loop.
        # If not, then reconnect to the controllers, unfail all, and then choose
        # the new master controller to be the first power off victim.
        #
        if( $delay >= $powerOffMinDiferential and $delay <= $powerOffMaxDiferential) 
        {

            #
            # Unfail the controllers
            #
              
            logInfo("Unfailing both controllers.");
            logInfo("Searching for the master controller for the UnFailController method.");
            $mIdx = TestLibs::IntegCCBELib::FindMaster( $coPtr );
            if ( $mIdx == INVALID )
            {
                logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
                return ERROR;
            }
            logInfo("Unfailing the controller ($victimController1->{HOST})  ");
            $ret = TestLibs::IntegCCBELib::UnFailController( 
                        $coList[$mIdx], $victimController1->{SERIAL_NUM} );
            if (  $ret == ERROR )
            {
                logInfo(">>>>>>>> Failed to restore the controller ( " . 
                    "$victimController1->{SERIAL_NUM} ) to active duty " .
                    "<<<<<<<<");
                return ERROR;
            }
            logInfo("Unfailing the controller ($victimController2->HOST})  ");
            $ret = TestLibs::IntegCCBELib::UnFailController( 
                        $coList[$mIdx], $victimController2->{SERIAL_NUM} );
            if (  $ret == ERROR )
            {
                logInfo(">>>>>>>> Failed to restore the controller ( " . 
                    "$victimController2->{SERIAL_NUM} ) to active duty " .
                    "<<<<<<<<");
                return ERROR;
            }
            
            
                    
            #Set the new victim controller to the newly found master
            $victimController1 = $coList[$mIdx];
            $randomControllerIndex1 = $mIdx;
            logInfo("Target Master controller ip is now: " . 
                    $victimController1->{HOST});
        }

        
        #da - will need something like this later
        #if ( $xtcDPtr )
        #{
        #    $xtcDPtr->{TESTLOOPS} =  $powerOffCount;
        #}
    }
        

    #
    # Unfail the controllers
    #
    logInfo("Unfailing any controller that is failed");
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $moxaPtr );
    if ( $ret != GOOD ) { 
        logInfo(">>>>>>>> Failed to restore the controller to active duty  " .
                "<<<<<<<<");
        return ERROR; 
    }

    #
    # Verify controller consistancy based on how they were from the start 
    # of the test.
    #
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }    

    logInfo("WookieeTestCase10 has completed successfully");
    logInfo("------------ End of Wookie power test case 10. ------------");

    return GOOD;
}


###############################################################################
###############################################################################

=head2 W1TestEntry function

The primary entry point for the Wookie linux integration tests.

A function used for debugging the code as a generic entry. The final
parameter represents the test case to be run. A test case of 99 will
run most tests sequentially. There is no guarantee that the tests can actually
run sequentially and give full coverage.

The test system should be configured as desired and IO from the
servers should be running. Most likely this will mean a two-way system.
IO from the servers needs to be consistent over time or the IO validation
checks may fail. For the most part, RAIDs should be redundant as many tests
will fail pdisks and require rebuilds. The test will hang if a drive
becomes permanently degraded.

Tests can be run individually by specifying the test case number. ( 1...25+)
Not all test case numbers exist ( the list is not contiguous). Specifying
an invalid number just means no test will be run. Test case 99 will run most
test cases sequentially. Test that are designed to cause a fatal condition
will not be part of the 99 sequence.

Some test require a minimum of a 2 way configuration, others will run on
1-way or n-way configurations.

Refer to the individual test cases for more information on the
individual tests.

=cut

=over 1

=item Usage:

 my $rc = W1TestEntry($coPtr, $moxaPtr, $mmPtr, $parmsPtr, $spare );

 where: $coPtr is a pointer to a list of controller objects
        $moxaPtr is a pointer to a list of Moxa controller IP addresses
        $mmPtr is a pointer to a list of tha Moxa channel mappings
        $parmsPtr is a pointer to a test parms hash
        $spare is an extra item, not used
=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the test(s)
           ran to completion without error. Test logs must be reviewed to
           ensure the test ran correctly.



=back

=cut


##############################################################################
#
#          Name: W1TestEntry
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:
#
##############################################################################
sub W1TestEntry
{
    trace();
    my ( $coPtr, $snPtr, $moxaIP, $mmPtr, $parmsPtr, $dummy ) = @_;

    my $ret;

    my $case = $parmsPtr->{testcase}; 
    
    #
    # Note: there are some loines referring to loop counts. This may not 
    # be relevant for resync. If not used, they may be removed. For Defrag
    # BEStress they were used.
    #


    my $autoLoop;
    my $loopCount = 0;

    $autoLoop = 0;
    $ret = GOOD;

    if ( defined($parmsPtr->{loopcount} ) )
    {
        $loopCount =  $parmsPtr->{loopcount};
    }

    my @coList = @$coPtr;

    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "                starting Wookiee 1 Test Case $case. ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");

    if ( !$loopCount )
    {
        logInfo("LoopCount was not specified, default values will be used.");
        $autoLoop = 1;
    }

    if ( $case == 99 )
    {
        logInfo("All test cases selected, default loop count values will be used.");
        $autoLoop = 1;
    }


    #
    # You will need to add tests case calls here as you add test cases. The 99/all
    # case does not need to apply to all cases. However if it is applied to a test case, 
    # then the test cases need to support one test following another. Mainly this means 
    # that test cases may need to 'clean up' the system before they actually run.
    #
    # You'll also need to determine what parameters each test will take.
    #

    if ( $case == 1  || $case == 99 ) 
    { 
        $ret = WookieeTestCase01( $coPtr, $snPtr, GOOD, $moxaIP, $mmPtr, $parmsPtr);
    }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 5  || $case == 99 ) 
    { 
        $ret = WookieeTestCase05( $coPtr, $snPtr, GOOD, $moxaIP, $mmPtr,
                                  $parmsPtr);
    }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 7  || $case == 99 ) 
    { 
        $ret = WookieeTestCase07( $coPtr, $snPtr, GOOD, $moxaIP, $mmPtr,
                                  $parmsPtr);
    }
    if ( $ret != GOOD ) { return $ret; }
    
    if ( $case == 10  || $case == 99 ) 
    { 
        $ret = WookieeTestCase10( $coPtr, $snPtr, GOOD, $moxaIP, $mmPtr,
                                  $parmsPtr);
    }
    if ( $ret != GOOD ) { return $ret; }



    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
    CtlrLogTextAll( $coPtr, "           Wookiee1 Test Case $case ends. ");
    CtlrLogTextAll( $coPtr, "---------------------------------------------------");

    return $ret;

}
###############################################################################


##############################################################################
#
#          Name: Support Functions
#
#  These are probably not exported.
#
##############################################################################
##############################################################################
#
#          Name: wookieTCControllerCheck
#
#        Inputs: controller list pointer, Moxa IP Address, Moxa,
#                reconnect delay, wait for state time, flags
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Loop that tests failover for various failure types
#                Uses the moxa to cycle power   
#                Loop Count defaults to 2000 if not specified
#
##############################################################################
sub wookieTCControllerCheck
{
    trace();                        # This allows function tracability
    my ($coPtr) = @_;

    my $msg;
    my $msg0;
    my $master;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my %vdisks;
    my %raids;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;
    my @currentVdisks;

    my @raids;
    my @sizes;
    my @disks;
    my @vdisks;
    my $raid;
    my $pdskPtr;
    my $sIdx;
    my $rIdx;
    my $size;
    my $expSize;
    my $newVDD;
    my $i;
    my %ret;
    my $MRWTimeout;
    my $numCtrls;
    my @serialNums;
    my %info1;
    my $flags;
    my %mirrorData;
    my @startingTmap;
    my $vdiskListPtr;
    my %pdisksHash;
    my %raidsHash;
    my $viskListPtr;
    my %vdisksHash;



    my $sps;
    my @coList;
    @coList = @$coPtr;

    $MRWTimeout = 30;               # time allowed for resync to finish
    $flags = 0;                     # added checks

    $numCtrls = scalar( @coList);

    ##########################################################################
    #
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    #
    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #
    for ( $i = 0; $i < $numCtrls; $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coPtr->[$i]);
    }

    $master = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $master == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
        return ERROR;
    }

    if ( 1 == GotRaid5($coList[$master]) )
    {
        logInfo ( "Raid 5 configured in system, making sure R5 resync bit set.");
        $flags = $flags | ADD_R5RESYNC_CHECK;
    }

    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, \@serialNums, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);


    # return (GOOD);
    #
    # display some starting info
    #
    $ret = TestLibs::IntegCCBELib::DispPdiskInfo($coList[$master]);

    if ( $ret == ERROR )
    {
        logError("Failed to get pdisk info at start");
        return ERROR;
    }


    #
    # Adda a pdisks FWV
    #

    %info1 = $coList[$master]->physicalDisks();
    if ( ! %info1  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDisks <<<<<<<<");
        return ERROR;
    }
    if ($info1{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get physicalDisks info <<<<<<<<");
        PrintError(%info1);
        return ERROR;
    }

    logInfo(" Physical disk firmware information ");

    logPhysicalDisks("FWV", %info1);

    logInfo(" ");

    $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$master] );
    if ( $ret == ERROR )
    {
        logError("Failed to get target list at start");
        return ERROR;
    }


    #
    # check to sse that everything is good at the start
    #

    logInfo("Check to see if everything is functioning at the start of the test");
    $ret = TestBEState($coPtr);

    if ( ($ret != GOOD) && !(NO_STARTUP_CHECK) )
    {
        logInfo("Test of the BE state failed");
        return ERROR;
    }

    #
    # find the currently active servers
    #

    logInfo("Getting initial data for activity measurements.");

    @vCounts = GetVdiskActivityCounts($coPtr);
    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);


    print "Serial num array is: " . @serialNums . "\n";
    $ret = GroupTargetMap($coPtr, \@serialNums, \@startingTmap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }



    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );

    $vdiskListPtr  = \@initialVdisks;

    if ( scalar(@initialVdisks) != 0 )
    {
        # we have some active vdisks
        if ( $initialVdisks[0] == INVALID )
        {
            # error case 
            logInfo(">>>>>>>> Warning - can't get an initial active vdisklist  <<<<<<<<");
            $vdiskListPtr  = 0;   # clear the point so we skip the following tests
        }
    }

    #
    # get initial BE data used for validation
    #

    %raidsHash =  $coList[$master]->raids();
    %pdisksHash = $coList[$master]->physicalDisks();
    %vdisksHash = $coList[$master]->virtualDisks();

    $ret = CheckBEHashes( \%pdisksHash, \%vdisksHash, \%raidsHash);
    if ( $ret == ERROR )
    {
        logInfo("Initial BE Hash indicated a bad state.");
        return ERROR;
    }

    #
    # startup parity scan, if we are doing any in the loop

    if (  (ADD_PARITY_SCAN & $flags) || (ADD_MORE_PARITY_SCANS & $flags) )
    {
        # parity scan the world
        $ret = TestLibs::BEUtils::PScanCheck( \@coList, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("Initial parity scan reported an error - test failed.");
            return ERROR;
        }
    }

    # find the master,
    logInfo("Searching for the master controller in the group");
    $master = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $master == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
        return ERROR;
    }


    ##########################################################
    #
    # Test the state of the system (one controller IS failed)
    #
    ##########################################################

    # ADD_R5RESYNC_CHECK
    #if (  ADD_R5RESYNC_CHECK & $flags  )
    #{
    #    # wait for resync to finish on all raids
    #    $ret = TestLibs::Validate::R5ResyncCheck( \@coList, 0, INVALID );
    #    if ( $ret != GOOD )
    #    {
    #        logInfo("R5 resync check reported an error - test failed.");
    #        return ERROR;
    #    }
    #}

    #
    # Rel 3.1 adds resync, need to wait for it to complete
    #
    #$ret = MirrorResyncWait($coPtr, $MRWTimeout);
    #if ($ret != GOOD)
    #{
    #    logInfo("Failed Mirror Resync wait.");
    #    $ret = MirrorCheck( $coPtr, \%mirrorData);
    #    return ERROR;
    #}

    #$ret = MirrorCheck( $coPtr, \%mirrorData);
    #if ($ret != GOOD)
    #{
    #    logInfo("Failed Mirror State Check.");
    #    return ERROR;
    #}
    
    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    print " && Just about to do a VerifyIO which does a TestSystemState1\n";
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     \@serialNums
                   );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> (wookieTCControllerCheck, VerifyIO) Controller State bad <<<<<<<<");
        return ERROR;
    }


    # check the back end state, vdisk status, pdisk status, raid status
    $ret = TestLibs::Validate::TestSystemState3($coList[$master], \%pdisksHash, \%vdisksHash, \%raidsHash);
    if ( ($ret == ERROR) && !(NO_BED_CHECK & $flags) )
    {
        logInfo(">>>>>>>> (wookieTCControllerCheck, TestSystemState3) Controller state bad <<<<<<<<");
        return ERROR;
    }

    if (  (ADD_PARITY_SCAN & $flags) || (ADD_MORE_PARITY_SCANS & $flags) )
    {
        # parity scan the world
        $ret = TestLibs::BEUtils::PScanCheck( \@coList, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("Parity scan reported an error - test failed.");
            return ERROR;
        }
    }

    return GOOD;


}

##############################################################################
#
#          Name: wookieTCPowerUpFailed
#
#        Inputs: Controller ptr you wish to have tested
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Checks to make sure the controller are in Power UP failed
#                state
#
##############################################################################
sub wookieTCPowerUpFailed 
{
    trace();                        # This allows function tracability
    my ($ctlr ) = @_;
    my $ret;
    my $ctrlsn;                     # Serial number for passed in controller
    #my $stateDescription;           # Used to get human readable cntrl STATE description

    $ctrlsn = TestLibs::IntegCCBELib::GetSerial( $ctlr);
    $ret = TestLibs::IntegCCBELib::GetPowerUpState($ctlr);
    if( $ret == INVALID)
    {
        logError(">>>>>>> Failure (wookieTCPowerUpFailed): GetPowerUpState returned INVALID");
        return ERROR;
    }
    elsif( $ret == POWER_UP_FAILED)
    {
        logInfo("Controller sn of $ctrlsn is tested positive for POWER_UP_FAILED");
        return GOOD;
    }
    #$stateDescription = XIOTech::cmdMgr::_getString_POWERUP($rsp{STATE});
    #logError("(wookieTCPowerUpFailed) Controller is not in POWER_UP_FAILED state, it is in $stateDescription state");
    return ERROR;
}




##############################################################################
1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.1  2005/05/04 18:53:52  RysavyR
# Initial revision
#
# Revision 1.3  2005/03/22 16:40:39  PalmiD
# TBolt00000000: Added a FailOverTimeLineNWay between the UnfailController
# and the TestEndMirrorCheck to match the standard convention and provide
# sufficient delay for the write cache to enable.  General Cleanup.
# Reviewed by Craig Menning (virtually).
#
# Revision 1.2  2005/02/23 20:26:32  AndersonD
# Tbolt00000000: Initial relase of the power cycling tests. Reviewed by Craig.
#
# Revision 1.1  2004/11/08 14:54:31  MenningC
# tbolot00000000: new files for resync, wrtcache and wookiee specific tests, reviewed by Dave P.
#
# Revision 1.2  2004/09/02 21:20:54  KohlmeyerA
# Tbolt00000000:  Broke UETest up into separate UETest and UETestSupport files.
# Reviewed by Craig.
#
# Revision 1.1  2004/07/12 15:28:55  MenningC
# tbolt00000000: new file for orphan raids test.  reviewed by Al
#
#
#
#
##############################################################################
