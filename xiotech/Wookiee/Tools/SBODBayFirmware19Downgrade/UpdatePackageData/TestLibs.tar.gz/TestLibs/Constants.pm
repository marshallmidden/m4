#$Id: Constants.pm 35359 2007-11-13 22:14:03Z neal_eiden $
##############################################################################
# File name:  TestLibs::Constants
#
# Desc: Constants used by TestLibs
#
# Date: 07/18/2002
#
# Original Author:  Keith House
#
# Last modified by  $Author: neal_eiden $
# Modified date     $Date: 2007-11-13 16:14:03 -0600 (Tue, 13 Nov 2007) $
#
# Copyright XIOtech A Seagate Company 2001, 2002
#
##############################################################################


package TestLibs::Constants;

require Exporter;
@ISA = qw(Exporter);

# Create tags for groups of constants so they can be included into Export or Export_OK
%EXPORT_TAGS = (
                XSSA    => [qw(
                                 XSSADATATYPE  
                                 XSSAHOTSPARETYPE
                                 XSSAUNSAFETYPE
                                 XSSAUNLABLEDTYPE
                                 WORKSETCOUNT
                                 VBLOCKCOUNT
                                 XSSAVDISKCOUNT

                                 UNMASKVDISKS    
                                 DELETEVDISKS    
                                 DELETEWORKPORTS 
                                 DELETEVBLOCKS   
                                 UNLABELPDISKS   
                                 CLEANALL 
                                 BIGFOOT
                                 MAGNITUDE       
                              
                               )],

                CCBE    => [qw(
                              
                                 CCBEDATATYPE  
                                 CCBEHOTSPARETYPE
                                 CCBEUNSAFETYPE 
                                 CCBEUNLABLEDTYPE
                                 CCB_PORT 
                                 CCBETIMEOUT   
                                 X1PORT     
                                 USEDHOTSPARETYPE 
                                 UNUSEDHOTSPARETYPE
                                 CCBEVLINKTYPE
                                  
                               )],

                REDI    => [qw(
                              
                                 COPY_BREAK          
                                 COPY_CONTINUOUS     
                                 COPY_SWAP           

                                 ABORT_COPY          
                                 PAUSE_COPY          
                                 RESUME_COPY         
                                 BREAK_ALL_COPIES    
                                 BREAK_SPECIFIED_COPY
                                 COPY_FLIP           


                               )],

                RAIDS    => [qw(

                                 RAID_NONE 
                                 RAID_0 
                                 RAID_1 
                                 RAID_5 
                                 RAID_10
                                 
                               )],

                GRABBER => [qw(
                              
                                 ALLITEMS
                                 ALLVERS         

                                 DEVSTATUS        
                                 ENVSTATS         
                                 FWVERSION        

                                 GENFUNCTION      
                                 GENMRP           
                                 GETREPORT        

                                 SOSTABLE         

                                 GLOBALCACHEINFO  

                                 LOGINFO          

                                 NVRAMREAD        
                                 MEMREAD          
                                 FIDREAD          

                                 STRUCTUREINFO    

                                 MODEBITINFO      

                                 SNMPPROPERTIES   

                                 PDISKS           

                                 DISKBAYS         

                                 DEVICELIST       
                                 PORTLIST         
                                 BEDEVICEPATHS    

                                 SCRUBINFO        
                                                  
                                 SERIALNUMBERS    

                                 SERVERS          
                                 SERVERLOOKUP     

                                 STATSALL

                                 SNAPREADDIR      
                                 TARGETS   
                                 TARGETSTATUS       
                                 TARGETRESLIST    

                                 VCGINFO          
                                 VCGELECTIONSTATE 

                                 VDISKS           
                                 VDISKCOUNT       
                                 VDISKINFO        
                                 VDISKLIST        
                                 VDISKOWNER       

                                 RAIDS            

                                 VLINKCTRLCOUNT   
                                 VLINKCTRLINFO    
                                 VLINKCTRLVDISKS  
                                 VLINKINFO        

                                 CCBBACKTRACE
                                 BEDVERSION
                                 BEDCHECK 
                                 PROCDATA 
                                                                  
                                 ACTIVESERVERLIST   
                                 TARGETMAP          
                                 INITIALVDISKS      
                                 SERIALNUMBERS2         
                                 PDISKDATA          
                                 VDISKDATA          
                                 RAIDDATA  
                               )],

                XTC    => [qw(
                                 RECORD_GROUP 
                                 RECORD_TYPE 
                                 RECORD_GROUP_INDEX 
                               )],

              XIOCISER => [qw(
                                 XIOCISER_CMD_OPTION
                                 GOOD_USER_CANCEL
                                 BAD
                                 TESTCASE_NAME_SIZE 
                                 TESTCASE_STATUS_SIZE
                                 TESTCASE_STEP_SIZE
                                 DSC_NAME_SIZE
                                 TIMESTAMP_SIZE
                                 SERVER_NAME_SIZE
                                 STR_IP_ADDRESS_SIZE
                               )],
                               
                BASE_REGRESSION => [qw(
                                 BREG_SKIPTESTS_FLAG
                                 BREG_NOCLEANUP_FLAG
                               )],

                );

# The Export_OK values are not imported by default, they must be in the import list of the calling module
      Exporter::export_ok_tags('XSSA', 'CCBE', 'GRABBER', 'REDI', 'RAIDS', 'XTC', 'XIOCISER', 'BASE_REGRESSION');  # add  @EXPORT_OK


# These are exported by default
#      Exporter::export_tags('XSSA');     # add  to @EXPORT
@EXPORT = qw(

                                 GOOD 
                                 ERROR 
                                 XMCGOOD 
                                 XMCERROR
                                 TRUE 
                                 FALSE 
                                 INVALID 

                                 NO_SERVER_CHECK
                                 NO_BED_CHECK
                                 NO_STARTUP_CHECK
                                 ADD_PARITY_SCAN
                                 ADD_MORE_PARITY_SCANS
                                 ADD_R5RESYNC_CHECK

                                 NORELABEL
                                 
                                 LOGTARGETSTATUS
                                 LOGTARGETMAP

                                 NO_RAID_INIT
                                 DEFRAG_WAIT
                                 ISFRAGMENTED
                                 NOTFRAGMENTED
                                 DEFRAGGING
                                 SKIPVALIDATIONFAILURE
                                 CB
                                 CM
                                 CS

                                 PDISKBYPASS
                                 PDISKSPINDOWN
                                 PDISKFAIL
                                 PDISKPULL
                                 DONTMAKEHOTSPARE
                                
                                 PD_DT_ALL        
                                 FC_PREFERRED
                                 SATA_PREFERRED
                                 RAID5_DEFRAG_ENABLED_WOOKIEE
                                 RAID5_DEFRAG_ENABLED_BIGFOOT
                                 CACHING_ALLOWED_WOOKIEE
                                 
                                 NOCACHECHECK
                                 
                                 MIRROR_FULL
                                 MIRROR_LIMITED
                                 MIRROR_LIMITED_BIT
                                 MIRROR_RANDOM_BIT 

                                 NWF_CTLR  
                                 NWF_DBAY  
                                 NWF_FEBSW 
                                 NWF_BEBSW 
                                 NWF_BEQSW 

                                 NWF_OK    
                                 NWF_2FAIL 
                                 NWF_FAILED
                                 NWF_UNFAIL

                                 NWF_SIMUL 
                                 NWF_STAGE 
                                 
                                 NWAY_MAX_CONTROLLERS
                                 
                                 RAID_DEV_INOP
                            
                                 ALLCTLRS  
                                 SINGLECTLR
                                 MASTERCTLR
                                 SLAVECTLR 
                                 ALLSLAVES
                                 
                                 CACHE_ENABLED
                                 CACHE_DISABLED 
                                 
                                 DEFAULT_MRW_TIMEOUT

                    );

{

no warnings;

use constant GOOD      => 0;
use constant ERROR     => 1;
use constant XMCGOOD   => 1;
use constant XMCERROR  => 0;
use constant TRUE      => 1;
use constant FALSE     => 0;
use constant INVALID   => -999;
# Enable tester port
use constant CCB_PORT  => 3100;
# CCB Port 3000 can be enabled for 750 testing
#use constant CCB_PORT  => 3000;
use constant CCBETIMEOUT    => 600;
use constant X1PORT         => 2341;
                     
use constant PDISKBYPASS    => 100;
use constant PDISKSPINDOWN  => 101;
use constant PDISKPULL      => 102;
use constant PDISKFAIL      => 103;

use constant RAID_DEV_INOP  => 0x01;

use constant ALLCTLRS     => 17;
use constant SINGLECTLR   => 18;
use constant MASTERCTLR   => 19;
use constant SLAVECTLR    => 20;
use constant ALLSLAVES    => 21;

use constant CACHE_ENABLED  => 0x81;
use constant CACHE_DISABLED => 0x80;

use constant MIRROR_FULL     => 0x84;
use constant MIRROR_LIMITED  => 0x85;


# this one is a bit/mask
use constant DONTMAKEHOTSPARE  => 2;   

# bitmap flages for Validate::MirrorCheck()
use constant NOCACHECHECK  => 2;
 

# mirror resync wait timeout. must be large for bigger systems
use constant DEFAULT_MRW_TIMEOUT  => 3600;

use constant NORELABEL  => 1;

# pdisk label types XSSA text
use constant XSSADATATYPE     => "DATA";        #define DATATYPE 1
use constant XSSAHOTSPARETYPE => "HOTSPARE";    #define HOTSPARETYPE 2
#use constant XSSAUNSAFETYPEII   => "UNSAFE";      #define UNSAFETYPE 3
use constant XSSAUNSAFETYPE   => "NOTSAFE";      #define UNSAFETYPE 3
use constant XSSAUNLABLEDTYPE => "UNLABELED";    #define UNLABLEDTYPE 0

# pdisk label types CCBE Numbers
use constant CCBEDATATYPE => 1;        #define DATATYPE 1
use constant CCBEHOTSPARETYPE => 2;    #define HOTSPARETYPE 2
use constant CCBEUNSAFETYPE => 3;      #define UNSAFETYPE 3
use constant CCBEUNLABLEDTYPE => 0;    #define UNLABLEDTYPE 0
use constant CCBEVLINKTYPE => 5;       # used for vlinks

# needed for some tests using hotspare drives (Rel 2 and 3 changes)
use constant USEDHOTSPARETYPE =>   (  64 + CCBEHOTSPARETYPE);   
use constant UNUSEDHOTSPARETYPE => ( 128 + CCBEHOTSPARETYPE); 

# Virtual Disks Raid Types

use constant RAID_NONE => "NONE";       # - Define RAID_NONE 0
use constant RAID_0 => 0;               # - Define RAID_0 1
use constant RAID_1 => 1;               # - Define RAID_1 2
use constant RAID_5 => 5;               # - Define RAID_5 3
use constant RAID_10 => 10;             # - Define RAID_10 4

# N-way failover constants

use constant NWF_CTLR    => 10;              # object type is controller
use constant NWF_DBAY    => 11;              # object type is diskBay
use constant NWF_FEBSW   => 12;              # object type is FE Brocade swithc
use constant NWF_BEBSW   => 13;              # object type is BE Brocade Switch
use constant NWF_BEQSW   => 14;              # object type is BE Qlogic switch

use constant NWF_OK      => 20;              # state is OK
use constant NWF_2FAIL   => 21;              # state is to be failed
use constant NWF_FAILED  => 22;              # state is failed
use constant NWF_UNFAIL  => 23;              # state is unfailing

use constant NWF_SIMUL   => 30;              # fail as a group
use constant NWF_STAGE   => 31;              # fail one after the other

#
# Define the maximum number of controllers handled by these test cases
#
use constant NWAY_MAX_CONTROLLERS   => 4;


# constants for the grabber code 
use constant  ALLITEMS         => 199 ;    # does all of the items below


use constant  DEVSTATUS        =>  12 ;    # Displays device status information.
use constant  FWVERSION        =>  14 ;    # Displays firmware version information.


use constant  SOSTABLE         =>  18 ;    # Retrieve and print an SOS table.

use constant  GLOBALCACHEINFO  =>  19 ;    # Displays global cache information.

use constant  LOGINFO          =>  22 ;    # Displays the list N log messages.

use constant  NVRAMREAD        =>  23 ;    # Read NVRAM and dump it to a file.

use constant  STRUCTUREINFO    =>  26 ;    # Displays a strucure from the CCB.

use constant  MODEBITINFO      =>  27 ;    # Displays mode bits.



use constant  PDISKS           =>  31 ;    # Displays physical disk information for all physical disks.

use constant  DISKBAYS         =>  36 ;    # Displays disk bay information for all disk bays.

use constant  DEVICELIST       =>  42 ;    # Displays the devices on the specified channel
use constant  PORTLIST         =>  43 ;    # List of ports (fibre channel adapters) on the front or back end
use constant  BEDEVICEPATHS    =>  44 ;    # Lists the Backend Device Paths

use constant  SCRUBINFO        =>  46 ;    # Displays the scrubbing information.
                                    
use constant  SERIALNUMBERS    =>  47 ;    # Displays the serial numbers for this controller.

use constant  SERVERS          =>  48 ;    # Displays server information for all servers.

use constant  STATSALL         =>  54 ;    # all/most of the  stats* commands.


use constant  TARGETS           => 64 ;    # Displays target information for all targets.
use constant  TARGETSTATUS      => 65 ;    # Displays the status of targets.
use constant  TARGETRESLIST     => 69 ;    # Displays a list of resources associated with a Target ID.


use constant  VCGINFO           => 71 ;    # Displays virtual controller group information.

use constant  VDISKS            => 73 ;    # Displays virtual disk information for all virtual disks.
use constant  VDISKCOUNT        => 74 ;    # Displays the number of virtual disks.
use constant  VDISKLIST         => 76 ;    # Displays a list of virtual disk identifiers.
use constant  VDISKOWNER        => 77 ;    # Displays the owners of a virtual disk.

use constant  RAIDS             => 78 ;    # Displays raid information for all raids.


use constant  VLINKCTRLCOUNT    => 83 ;    # Displays the count of remote controllers.
use constant  VLINKCTRLINFO     => 84 ;    # Displays the information for a remote controller.
use constant  VLINKCTRLVDISKS   => 85 ;    # Displays the virtual disks of a remote controller.
use constant  VLINKINFO         => 86 ;    # Displays the information of a virtual link.

use constant  CCBBACKTRACE      => 91 ;    # Displays the CCB bactrace and other data.
use constant  BEDVERSION        => 92 ;    # Displays the the fw versions of the BE devices.
use constant  BEDCHECK          => 93 ;    # Displays the configuration of the BE devices.
use constant  PROCDATA          => 94 ;    # Displays the debug data for the proc board processors.
use constant  ALLVERS           => 95 ;    # Displays all code revision for BF and the BE.




# not yet done...


use constant  ENVSTATS         =>  13 ;    # Displays environmental statistics.
use constant  GENFUNCTION      =>  15 ;    # Call PI_GenFunction with passed in parameters.
use constant  GENMRP           =>  16 ;    # Issue a generic MRP.
use constant  GETREPORT        =>  17 ;    # Retrieves various debug reports.
use constant  MEMREAD          =>  24 ;    # Read memory on specified processor.
use constant  FIDREAD          =>  25 ;    # Read the specified file ID.
use constant  SNMPPROPERTIES   =>  29 ;    # Set or Get SNMP trap addresses on the ccb.
use constant  SERVERLOOKUP     =>  53 ;    # Find a Server ID from a WWN and Target ID.
use constant  SNAPREADDIR       => 63 ;    # Read the snapshot directory.
use constant  VCGELECTIONSTATE  => 72 ;    # Displays the state of an election.


use constant ACTIVESERVERLIST   =>  1 ;    
use constant TARGETMAP          =>  2 ; 
use constant INITIALVDISKS      =>  3 ; 
use constant SERIALNUMBERS2     =>  4 ; 
use constant PDISKDATA          =>  5 ; 
use constant VDISKDATA          =>  6 ; 
use constant RAIDDATA           =>  7 ;

#######################################################################################

#
# constants used by the XSSA library calls
#
use constant WORKSETCOUNT       =>  16 ;
use constant VBLOCKCOUNT        =>  32 ;
use constant XSSAVDISKCOUNT     =>  32 ;

# Used by the CleanAll function
use constant UNMASKVDISKS       =>  99 ;
use constant DELETEVDISKS       =>  98 ;
use constant DELETEWORKPORTS    =>  97 ;
use constant DELETEVBLOCKS      =>  96 ;
use constant UNLABELPDISKS      =>  95 ;
use constant CLEANALL           =>  94 ;

use constant BIGFOOT => 1;
use constant MAGNITUDE => 2;


#######################################################################################
#
# constants used by the Base Regression routines
#
use constant BREG_SKIPTESTS_FLAG    => 0x01; # exit after setup; 
                                             # skip actual regression test.
use constant BREG_NOCLEANUP_FLAG    => 0x02; # skip cleanup before exit 

                 
#######################################################################################



###############################################################################

#
# XTC related constants...
#

#
# Constants used in the RECORD arrays found in the main XTC data structure.
# There are the indices to each particular part in the record.
#
use constant RECORD_GROUP => 0;
use constant RECORD_TYPE  => 1;
use constant RECORD_GROUP_INDEX => 2;

###############################################################################



###############################################################################

#
# XIOciser Related constants...
#   

# If this is the last command line option that is passed in, then the XTC will
# be started in the context of XIOciser.
use constant XIOCISER_CMD_OPTION    => "-xiociser";

# This is used as a return code in functions to indicate that an action was
# successful, but the user cancelled the action.
use constant GOOD_USER_CANCEL       => -99;

# This constant is used by XIOciser to indicate failure.
use constant BAD => 1;

# The size of a testcase name field in a XIOciser related structure.
use constant TESTCASE_NAME_SIZE     =>        36;

# The size of a testcase status field in a XIOciser related structure.
use constant TESTCASE_STATUS_SIZE   =>        36;

# The size of a testcase step field in a XIOciser related structure.
use constant TESTCASE_STEP_SIZE     =>        36;

# The size of a dscName field in a XIOciser related structure.
use constant DSC_NAME_SIZE          =>        16;   

# The size of a TIMESTAMP field in a XIOciser related structure.
use constant TIMESTAMP_SIZE         =>        24;    

# The size of a server name field in a XIOciser related structure.  Note:
# this is name the same as the server hostname.  This is a user specified
# name.
use constant SERVER_NAME_SIZE       =>        64;  

# The size of a string IP address field in a XIOciser related structure.
use constant STR_IP_ADDRESS_SIZE    =>        16;  

###############################################################################

# coverd by other options...

# use constant  NETSTAT          =>  28 ;    # Prints active TCP socket connection data (same as STRUCTUREINFO 2).
    

# use constant  PDISKCOUNT       =>  33 ;    # Displays the number of physical disks.
# use constant  PDISKINFO        =>  34 ;    # Displays physical disk information.
# use constant  PDISKLIST        =>  35 ;    # Displays a list of physical disk identifiers.
# use constant  DISKBAYCOUNT     =>  37 ;    # Displays the number of disk bays bypass cards.
# use constant  DISKBAYLIST      =>  38 ;    # Displays a list of disk bay identifiers.
# use constant  DISKBAYINFO      =>  39 ;    # Displays disk bay information.

# use constant  DISKBAYSTATUS    =>  41 ;    # Displays diskbays and associated PDisks.
# use constant  POWERUPSTATE     =>  45 ;    # Display the power-up state of this controller.
# use constant  SERVERCOUNT      =>  49 ;    # Displays the number of servers.

# use constant  SERVERINFO       =>  51 ;    # Displays server information.
# use constant  SERVERLIST       =>  52 ;    # Displays a list of servers identifiers.
# use constant  STATSCACHEDEV    =>  54 ;    # Displays statistics for a cache device.
# use constant  STATSLOOP        =>  55 ;    # Displays statistics for back end loop.
# use constant  STATSPCI         =>  56 ;    # Displays statistics for back end PCI.
# use constant  STATSPROC        =>  57 ;    # Displays statistics for back end proc.
# use constant  STATSSERVER      =>  58 ;    # Displays statistics for a server.
# use constant  STATSVDISK       =>  59 ;    # Displays statisitcs for virtual disks.

# use constant  STATSENVIRONMENTAL  => 62;   # Displays environmental statistics.
# use constant  TARGETCOUNT       => 66 ;    # Displays the number of targets.
# use constant  TARGETINFO        => 67 ;    # Displays target information.
# use constant  TARGETLIST        => 68 ;    # Displays a list of target identifiers.

# use constant  VDISKINFO         => 75 ;    # Displays virtual disk information.
# use constant  RAIDCOUNT         => 79 ;    # Displays the number of raid devices.

# use constant  RAIDLIST          => 81 ;    # Displays a list of raid device identifiers.
# use constant  RAIDINFO          => 82 ;    # Displays raid information.


#######################################################################################

#
# constants used by the failover library, bitmapped
#
use constant    NO_SERVER_CHECK => 1;
use constant    NO_BED_CHECK => 2;
use constant    NO_STARTUP_CHECK => 4;
use constant    ADD_PARITY_SCAN => 8;
use constant    ADD_MORE_PARITY_SCANS => 16;
use constant    ADD_R5RESYNC_CHECK =>  32;
use constant    MIRROR_LIMITED_BIT =>  64;
use constant    MIRROR_RANDOM_BIT  => 128;


#
# constants for generating the target map for failover, bitmapped
#
use constant    LOGTARGETSTATUS => 1;
use constant    LOGTARGETMAP => 2;

# used by defrag, redi cp, and BE utils

use constant PD_DT_ALL => 0x80;           # for GetDataDisks, return ALL drives 
use constant FC_PREFERRED => 0x81;        # for GetDataDisks, FC drives preferred 
use constant SATA_PREFERRED => 0x82;      # for GetDataDisks, SATA drives preferred 
use constant RAID5_DEFRAG_ENABLED_BIGFOOT => 1;   # Raid5 defrag:  1 - enabled, 0 - disabled
use constant RAID5_DEFRAG_ENABLED_WOOKIEE => 1;   # Raid5 defrag:  1 - enabled, 0 - disabled
use constant CACHING_ALLOWED_WOOKIEE => 0;       # we are allowed to turn on/off vdisk caching

             # these are bit significant
use constant NO_RAID_INIT => 1;    # for makeVdisks, defrag test  
use constant DEFRAG_WAIT => 2;     # for defrag test

use constant ISFRAGMENTED => 1;
use constant NOTFRAGMENTED => 0;
use constant DEFRAGGING => 4;
use constant SKIPVALIDATIONFAILURE => 128;

# redi copy options
use constant    CB => "CB";
use constant    CM => "CM";
use constant    CS => "CS";

# these are the different paramters that are used for the 
# vdiskcontrol function. They are mapped to the proper
# numeric value in the StartCopyOp function.
use constant    COPY_BREAK           => "COPY_BREAK";           
use constant    COPY_CONTINUOUS      => "COPY_CONTINUOUS";                   
use constant    COPY_SWAP            => "COPY_SWAP";            

use constant    ABORT_COPY           => "ABORT_COPY";           
use constant    PAUSE_COPY           => "PAUSE_COPY";           
use constant    RESUME_COPY          => "RESUME_COPY";          
use constant    BREAK_ALL_COPIES     => "BREAK_ALL_COPIES";     
use constant    BREAK_SPECIFIED_COPY => "BREAK_SPECIFIED_COPY";     
use constant    COPY_FLIP            => "COPY_UNSWAP";


#################################################



}

1;

__END__

=head1 NAME

NAME OF THE MODULE

TestLibs::Constants - Constants used by TestLibs

$Id: Constants.pm 35359 2007-11-13 22:14:03Z neal_eiden $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

  use TestLibs::Constants;

=head1 DESCRIPTION

Constants used by TestLibs.  You should use this library if you are using TestLibs
so we are consistent with our constants.

=head2 Constants

 GOOD
 ERROR
 TRUE
 FALSE
 INVALID
 CCB_PORT
 REDUNDANT    
 HOTSPARE     
 NONREDUNDANT 
 UNLABLED     

=head1 AUTHOR

Keith House housek@xiotech.com

=head1 CHANGELOG

 $Log$
 Revision 1.4  2006/11/14 11:07:12  AnasuriG
 TBolt00000000
 Changed constant CCB_PORT to 3000 from 3100

 Revision 1.3  2006/08/01 11:12:41  AnasuriG
 TBolt00015075
 Added changes for PDISKFAIL

 Revision 1.2  2006/05/24 07:51:30  EidenN
 Moved from 750 Branch

 Revision 1.1.1.1.30.1  2006/05/24 03:48:24  EidenN
 tbolt0000000:  Added support for STP (SAS Transport Protocal)

 Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
 import CT1_BR to shared/Wookiee

 Revision 1.42  2005/03/09 19:24:58  PalmiD
 TBolt00000000: Added NOCACHETEST for bypassing mirror validation checks.
 Reviewed by Craig Menning (virtually).

 Revision 1.41  2005/03/08 19:45:24  ElvesterN
 Tbolt0000000: Added constants MIRROR_FULL, MIRROR_LIMITED, MIRROR_LIMITED_BIT, MIRROR_RANDOM_BIT to facilitate changes in FailOver.pm and Validate.pm - Reviewed By:  CraigM

 Revision 1.40  2004/11/18 15:51:18  MenningC
 tbolot00000000: new functions for mirror vaildation, reviewed by Al.

 Revision 1.39  2004/11/10 17:29:48  PalmiD
 TBolt00000000: Added CACHE_ENABLED and CACHE_DISABLED constants. Reviewed by Craig Menning

 Revision 1.38  2004/09/24 19:53:00  MenningC
 tbolt00000000: Message allowing errors in BE6 (ql reset errors) and disable cache test for wookiee. reviewed by TIm.

 Revision 1.37  2004/09/22 16:15:27  KohlmeyerA
 Tbolt00000000: Set the flag to indicate RAID5 defrag is enabled for WOOKIEE
 Reviewed by Craig.

 Revision 1.36  2004/09/02 21:22:13  KohlmeyerA
 Tbolt00000000:  Added new controller constants.
 Reviewed by Craig.

 Revision 1.35  2004/08/31 21:13:19  MenningC
 Tbolt00000000: Add raid 5 defrag enabled flag for wookiee; reviewed by Al

 Revision 1.34  2004/08/11 13:44:24  MenningC
 tbolt00000000:change to support the 3D defrag changes.

 Revision 1.33  2004/07/28 15:04:35  MenningC
 tbolt00000000: updates to support SATA and adrdress 4 way issues, reviewed by Al

 Revision 1.32  2004/05/26 15:55:39  KohlmeyerA
 Tbolt00000000:  Added flag and modified DefragRemain and CheckSosTables
 to handle Raid 5 no longer being defragmented.  Also did some cleanup of multiple defragwait and defragremain functions.
 Reviewed by Craig

 Revision 1.31  2004/05/24 13:55:21  MenningC
 tbolt00000000: Detect errors failing items in failover nway, ignore R10 miscompare in parity scan, updates to logged info, detect inop raids in failover. . reviewed by Al

 Revision 1.30  2004/04/15 18:51:57  KohlmeyerA
 Tbolt00000000 - Added contants for different type of disks due to addition of SATA disks.  Reviewed by Craig

 Revision 1.29  2004/02/19 23:52:25  SchibillaM
 TBolt00000000: Separate NWay algorithms and support functions into separate
 files.  Move max controllers constant into Constants.pm.  Minor changes to
 PromptUser().

 Revision 1.28  2004/01/20 20:30:38  RysavyR
 TBolt00000000: New "RegressionNWay" and "QLResets" test capability both from a specific
 ".pl" and through XTC. Reviewed by Craig.

 Revision 1.27  2003/12/23 20:48:14  MenningC
 TBOLT00000000: Additions for the nway failover test. Reviewed by Olga

 Revision 1.26  2003/10/07 15:40:36  ThiemanE
 Added some constants for XIOciser and the XTC
 Reviewed by Craigm

 Revision 1.25  2003/09/24 19:59:10  MenningC
 tbolt00000000: support for a r5 resync check for failover; for and reviewed by Jim S.

 Revision 1.24  2003/07/23 15:01:03  GrigorenkoO
 Tbolt00000000 Added new constants

 Revision 1.23  2003/07/23 14:04:16  MenningC
 tbolt00000000: added support for an additional loop parameter, add initial parityscan support to failover; reviewed by Olga

 Revision 1.22  2003/06/26 18:04:28  MenningC
 TBOLT00000000: Changes to support unchanging drive labels during hotspare in R2 and R3; reviewed by Olga

 Revision 1.21  2003/06/24 15:53:38  MenningC
 TBOLT00000000: Changes to support scrub testing; reviewed by Olga

 Revision 1.20  2003/05/28 14:54:20  MenningC
 TBOLT00000000: Changes to support bypassing of drives, patch for servermates, fix a defrag case timing.; reviewed by JW

 Revision 1.19  2003/04/22 20:28:00  GrigorenkoO
 Tbolt00000000 changed XSSAUNASFETYPE to NOTSAFE

 Revision 1.18  2003/04/15 14:55:42  WerningJ
 Add back in the Klude for PDisk label NOTSAFE vs UNSAFE
 Reviewed by Craig M

 Revision 1.17  2003/03/26 21:27:02  WerningJ
 Cleaned Up Constants
 Added Export_OK for none default export lists
 These must now be added to the import list of the calling module
 Reviewed by Craig M

 Revision 1.15  2003/01/14 15:26:39  MenningC
 Tbolt00000000: Changes to support BEUtils lib, removed UMC. Reveiewed by J Werning.

 Revision 1.14  2003/01/07 22:27:50  MenningC
 Tbolt00000000: Many changes to handle the new content of targetstatus, reveiwed by Jeff Werning

 Revision 1.13  2002/12/04 14:23:16  MenningC
 tbolt00000000 modiifcation to IO and BE checks for Neal, reviewed by Olga and/or Jeff W.

 Revision 1.12  2002/11/12 20:54:19  MenningC
 TBOLT00000000: Version info for Manufacturing. Reviewed by J Werning

 Revision 1.11  2002/11/11 21:26:38  WerningJ
 Now using constants from CONSTANT.pm for Drive types
 Reviewed by Craig M

 Revision 1.10  2002/11/01 21:34:36  WerningJ
 Placed drive type constants here from IntegCCBELib
 Reviewed by Craig M

 Revision 1.9  2002/10/22 18:56:07  MenningC
 tbolt00000000  changed some SERAILNUMBERS to SERIALNUMBRS2 to avoid a conflict,  reviewed by Max

 Revision 1.8  2002/10/17 20:56:06  GrigorenkoO
 Tbolt0000000 added constans

 Revision 1.7  2002/09/16 14:56:27  MenningC
 tbolt00000000 cmore changes
 ; reviewed by J Werning

 Revision 1.6  2002/09/11 19:20:06  MenningC
 tbolt00000000 added ccbtrace, some cleanup, reviewed by Jeff Werning

 Revision 1.5  2002/09/11 15:31:42  MenningC
 tbolt00000000 continued development, reviewed by Jeff Werning

 Revision 1.4  2002/09/10 19:35:54  MenningC
 tbolt00000000 support for controller data collection, reviewed by Jeff Werning

 Revision 1.3  2002/08/02 01:44:55  HouseK
 Added or corrected some POD (perldoc)

 Revision 1.2  2002/07/31 19:44:18  HouseK
 Result of merge from tag LOGGING_CHANGES

 Revision 1.1.2.2  2002/07/29 15:45:56  WerningJ
 Added some constats
 Reviewed by Craig M

 Revision 1.1.2.1  2002/07/26 01:16:39  HouseK
 hiding errors around constants

 Revision 1.1  2002/07/19 01:03:47  HouseK
 Initial check in


=cut
