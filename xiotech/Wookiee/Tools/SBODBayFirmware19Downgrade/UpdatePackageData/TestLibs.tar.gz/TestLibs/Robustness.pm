#!/usr/bin/perl -w
# $Header$

###############################################################################
# File name:  TestLibs::Robustness
#
# Desc: A set of library functions for integration testing. These focus on
#       controller robusness testing.
#
# Date: 07/26/2002
#
# Original Author:  Olga Grigorenko
#
# Last modified by  $Author: RysavyR $
# Modified date     $Date: 2005-05-04 13:53:47 -0500 (Wed, 04 May 2005) $
#
#   It is expected that the user will write a perl script that calls 
#   these library.
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################

=head1 NAME

TestLibs::Robustness - Perl support for  bigfoot robusntess (endurance) testing

$Id: Robustness.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

This document describes usage of the Perl functions to Test Controllers Robustness

=head1 DESCRIPTION

Test Functions Available
                CompareFwVersion
                ControllersValidateAll
                CotrollerCodeApply
                PreCodeApplyControllersSnapShot
                ControllerResetWithFailOver
                CodeUpdateMainLoop
                CreateMaxVd
                RobustnessLabel
                RobustServerProp

=cut

package TestLibs::Robustness;

use Cwd;

use File::Temp qw/ :mktemp  /;
use File::Path;
use Archive::Tar;

use warnings;
use lib "../CCBE";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
#use XIOtech::sanscript;

use TestLibs::Validate;
use TestLibs::IntegXMCLib;
use TestLibs::IntegCCBELib;
use TestLibs::utility;
use TestLibs::Fibre;
use TestLibs::Logging;
use TestLibs::BEUtils;
use TestLibs::Constants qw(:DEFAULT :GRABBER :CCBE);
use TestLibs::BEUtils;
use TestLibs::scrub;

use Dumpvalue;
my $dumper = new Dumpvalue;
my $dumper2 = new Dumpvalue;

use strict;

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      &CompareFwVersion
                      &ControllersValidateAll
                      &CotrollerCodeApply
                      &PreCodeApplyControllersSnapShot
                      &ControllerResetWithFailOver
                      &RobustnessLabel
                      &RobustServerProp
                      &RollingCodeUpdateMain
                      &CreateMaxVd
                      &PowerCycleDriveBay
                                            );

    %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;

################################################################################

=head2 PreTestSnapShot
          
Gets initial information about VCG;

=over 4

=item Usage:

 my $FuctionReturn = GetFwversion( $Obj, $Option );    
 
 where: $Obj - controller object to which code should be Applied 
        $Option - ACTIVESERVERLIST (1)
                  TARGETMAP (2)                  
                  INITIALVDISKS (3)
                  SERIALNUMBERS2 (4)
                  PDISKDATA (5)
                  VDISKDATA (6)
                  RAIDDATA (7)

 
 my @FuctionReturn = @$FuctionReturn;
 if( $FuctionReturn[0] < 0)
 {
    print "Unable to retrieve information \n";
 } 

 Notes:
 
 None

=item Returns:

 On success - Returns reference to the array with information.
 On error - First element in the array is less then 0.

=back

=cut


##############################################################################
#
#          Name: PreTestSnapShot
#
#        Inputs: Pointer to the Controllers objects list
#                Which item to return  
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Gets initial information about VCG 
#                 
#                
#
##############################################################################

sub PreCodeApplyControllersSnapShot
{
    my ( $coPtr, $Opt  ) = @_;
    trace();
        
    my @coList = @$coPtr ;      #-list of controller objects
    my $newMaster = INVALID;    #-will become an object of a master controller
    my $ret;                    #-display fuctions return 
    my @vCounts;                #-begining count for server activity
    my @sCounts;                #-end server count activity
    my %info1;                  #-target status information
    my @serialNums;             #-serial numbers
    my @startingTmap;           #-Initial Target map
    my @activeServers;          #-Array of servers with IO
    my @initialVdisks;          #-Virtual disks with OI
    my $vdiskListPtr;           #-Instance of virtual disks pointer
    my @pdiskData;              #-Array of physical disks states
    my @vdiskData;              #-Array of virtual disks states
    my @raidData;               #-Array of raids states
    my $i = 0;                  #-Forloop count

    my @ReturnArray;

    ##########################################################################

    #
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    #


    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #    
    for ( $i = 0; $i < scalar(@coList); $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
    }


    #- Get Info on which controller is the master
     
    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    
    if ( $newMaster == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller  <<<<<<<<");
        $ReturnArray[0] = INVALID; 
    }

    if( $Opt == ACTIVESERVERLIST)
    {
        #
        # find the currently active servers
        #

        logInfo("Pause to allow activity to accumulate");
        @sCounts = GetServerActivityCounts($coPtr);
                
        logInfo("Pause to allow server activity to accumulate");
        DelaySecs(20);

        @ReturnArray = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    }

    
    if( $Opt == TARGETMAP)
    {
        #
        # display target list
        #

        $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$newMaster] );
    
        if ( $ret != GOOD )
        {
            logError("Failed to get target list at start");
            $ReturnArray[0] = INVALID;
        }

        #
        # get the initial/starting target map
        #

        logInfo("Getting the target status, then building the target map");
    
#        %info1 = GetTargetStatus($coList[$newMaster]);
#
#        if ( ! %info1  )              # if no data from call
#        {
#            logInfo(">>>>>>>> Failed to get a response from GetTargetStatus <<<<<<<<");
#            $ReturnArray[0] = INVALID;
#        }
#
#        if ( $info1{STATUS} != PI_GOOD )      # if call returned an error
#        {
#            logInfo(">>>>>>>> Error from GetTargetStatus <<<<<<<<");
#            $ReturnArray[0] = INVALID;
#        }
#        
#        @ReturnArray = CreateTargetMap(\@serialNums, %info1);
#        PrintTargetMap(\@ReturnArray); 

        $ret = GroupTargetMap($coPtr, \@serialNums, \@ReturnArray, $newMaster, LOGTARGETMAP);
        if ( $ret != GOOD )  {$ReturnArray[0] = INVALID; }


    }

    
    if( $Opt == INITIALVDISKS)
    {
        #
        # get the initial active vdisks for the test
        #

        
        logInfo("Getting initial data for activity measurements.");
        @vCounts = GetVdiskActivityCounts($coPtr);
                
        logInfo("Pause to allow vdisk activity to accumulate");
        DelaySecs(20);

        @ReturnArray = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
        if ( scalar(@ReturnArray) != 0 )
        {
            # we have some active vdisks
            if ( $ReturnArray[0] == INVALID )
            {
                # error case 
                logInfo("    ====> Warning - can't get an initial active vdisklist <====");
            }
        }
    }

    if( $Opt == SERIALNUMBERS2)
    {
        @ReturnArray = @serialNums;
    }


    #
    # get initial BE data used for validation
    #

    if( $Opt == PDISKDATA )
    {
        #
        # display physical disk info
        #

        $ret = TestLibs::IntegCCBELib::DispPdiskInfo($coList[$newMaster]);

        if ( $ret != GOOD )
        {
            logError("    ====> Failed to get pdisk info at start <====");
            $ReturnArray[0] = INVALID;    
        }
        else
        {
            @ReturnArray = GetPdiskStateArray($coList[$newMaster]);
        }
    }
    
    if( $Opt == VDISKDATA)
    { 
        @ReturnArray = GetVdiskStateArray($coList[$newMaster]);
    }
    
    if( $Opt == RAIDDATA)
    {
        @ReturnArray = GetRaidStateArray($coList[$newMaster]); 
    }
    
    return @ReturnArray;

}

################################################################################

=head2 ControllerCodeApply
          
This function sends firmware image files to the controller;

=over 4

=item Usage:

 my $FuctionReturn = ControllerCodeApply( $Obj, $FrimwareKitLocation );    
 
 where: $Obj - controller object to which code should be Applied 
        $FrimwareKitLocation - Path to firmware kit location on the network  

 
 if( $FuctionReturn == 1)
 {
    print "Firmware versions have not been applied \n";
 } 

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error - Returns 1 (ERROR).

=back

=cut





##############################################################################
#
#          Name: ControllerCodeApply
#
#        Inputs: Controller object
#                Path to the fwk (firmware kit) file 
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: Applies code to the controller
#
#
##############################################################################
sub ControllerCodeApply
{
    my ( $obj, $filefwk ) = @_;  #-$file fwk fw kit location 
    trace();

    logInfo("File to update ".$filefwk);
    my $template = "fwkDIRXXXXX";

    my $fwk = 0;      #-Return from the Tar function that decompresses the file
    my $ControllerSerial;
    my $rsp = 0;
    my $loginok = 0;
    my $compressed = 1;         # True, the FWK file should be compressed
    my $FwUpdateRet = GOOD;     # Return from FW update function 
    my @image_list;

    # Read in the tar FWK file
    
    $fwk = Archive::Tar->new($filefwk, $compressed);
    
    if (!$fwk)
    { 
        logInfo( "can't open FWK file: ".$filefwk);
        return ERROR;
    }


    #-get to the right dir

    my $current_dir = cwd();
    my $tmpdir = mkdtemp( $template );
    chdir $tmpdir or logInfo("Can't change to  ".$tmpdir);

    @image_list = $fwk->list_files();
    
    if (!@image_list)
    {
        logInfo("    ====> Failed to get File list from FWK <====");
        return ERROR;
    }
    
    
    $fwk->extract(@image_list); # Get Firmware Images
    
    ####################################################################
    #
    # Get and Display Version 
    #   

    logInfo("Controller FW before the Code Update...");
    logInfo(" ");

    my %FW = GetFwversion( $obj );
    
    if (%FW)
    {
        logInfo("Updating controller firmware...");
        logInfo("");
    
        $ControllerSerial = GetSerial( $obj );
        
        if( $ControllerSerial == INVALID) #-previous function returned error
        {
            return ERROR;
        }
        
        ###############################################################
        #
        # Update Code against controller object
        #
        
        
        foreach my $image (@image_list)
        {
            if ( $FwUpdateRet == GOOD )                     
            {
                logInfo("Updating Firmware $image on controller SN: $ControllerSerial");
                
                # Update code
                
                my %CodUpdateRet = $obj->sendFirmware($image);

                if( %CodUpdateRet )
                {
                    if ($CodUpdateRet{STATUS} == PI_GOOD)
                    {
                        logInfo("Firmware update successful.");
                    }
                    else
                    {
                        my $msg = "    ====> Firmware update failed. See logs for details. <====";
                        displayError($msg, %CodUpdateRet);
                        return ERROR;
                    }
                }
                else
                {
                    logInfo("    ====> ERROR: Did not receive a response packet on Firmware Update. <====");
                    return ERROR;
                }
            }
        }   
    }
    else
    {
        logInfo("    ====> Display of controller firmware FAILED, Test Stop ... <====");
        return ERROR;       
    }
    
    logInfo("==============================================================");
    logInfo("  Update Completed Successfully for SN: $ControllerSerial");
    logInfo("==============================================================");

    #remove temp dir
    chdir $current_dir or logInfo("Can't \" cd ".$current_dir."\"");
    $rsp = rmtree($tmpdir);

    if (!$rsp)
    {
        logInfo("    ====> Could not delete temporary Directory! <====");
    }

    return GOOD;
}

##############################################################################

=head2 CompareFwversions
          
This function retrieves firmware visions hashes from the controllers 
and compares them to make sure that they match.  If there is a mismatch in 
firmware visions function will return ERROR (1), if firmware versions math, 
function will return GOOD (0);

=over 4

=item Usage:

 my $FuctionReturn = CompareFwversions ( $PointerToObjList );    
 
 where: $PointerToObjList - pointer to the list of  controller objects
 
 if( $FuctionReturn == 1)
 {
    print "Firmware versions mismatch \n";
 } 

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error - Returns 1 (ERROR).

=back

=cut

##############################################################################
#
#          Name: CompareFwversions
#
#        Inputs: Pointer to the list of controller objects
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Comapares Controller(s) Version(s), if all the same returns
#                GOOD if defferent return ERROR;
#
#
##############################################################################

sub CompareFwVersion
{
    my ( $ObjListRef ) = @_;
    trace();
     
    my $msg1 = "Firmware version  mismatch... ";
    my $msg2 = " is not the same as ";
    my @ObjList = @$ObjListRef;             #-List of Controller objects 
    my $type;                               #-data set name
    
    ################################################################
    #
    # Get and Display Firmware Ver 
    #
    
    #
    # First controller fw versions
    #
    
    logInfo(" ");
    logInfo("Getting Versions for controller - 0 - ");
    
    my %CompareTo;
    my %OrgVer = $ObjList[0]->fwVersion();      

    
    if (!%OrgVer)
    {
        logInfo("    ====> ERROR: Failed to receive a response from fwVersion. <====");
        return ERROR;
    }

    if ($OrgVer{STATUS} != PI_GOOD)
    {
        my $msg = "    ====> ERROR: Failed to retrieve firmware version information. <====";
        displayError($msg, %OrgVer);
        return ERROR;
    }
    
    #
    # do the compare
    #
    
        

    my @fwtypes = ( FW_VER_CCB_RUNTIME,
                    FW_VER_BE_RUNTIME,
                    FW_VER_FE_RUNTIME,
                    FW_VER_CCB_BOOT,
                    FW_VER_BE_BOOT,
                    FW_VER_FE_BOOT,
                    FW_VER_BE_DIAG,
                    FW_VER_FE_DIAG);
   
    my @fwPrint = ( "FW_VER_CCB_RUNTIME",
                    "FW_VER_BE_RUNTIME",
                    "FW_VER_FE_RUNTIME",
                    "FW_VER_CCB_BOOT",
                    "FW_VER_BE_BOOT",
                    "FW_VER_FE_BOOT",
                    "FW_VER_BE_DIAG",
                    "FW_VER_FE_DIAG");


    for (my $t = 1; $t < scalar(@ObjList); $t++)
    {
        %CompareTo = $ObjList[$t]->fwVersion();      
        
        if (!%CompareTo)
        {
            logInfo("    ====> ERROR: Failed to receive a response from fwVersion. <====");
            return ERROR;
        }

        if ($CompareTo{STATUS} != PI_GOOD)
        {
            my $msg = "    ====> ERROR: Failed to retrieve firmware version information. <====";
            displayError($msg, %CompareTo);
            return ERROR;
        }

        logInfo( "Comparing firmware versions between controller -0- and controller -".$t."-"); 
        
        for (my $y = 0; $y < scalar(@fwtypes); ++$y)
        {
            $type = $fwtypes[$y]; 

            if("$OrgVer{$type}{REVISION}" ne "$CompareTo{$type}{REVISION}") 
            {
                logInfo($msg1." for data set ". $type);
                loginfo($OrgVer{$type}{REVISION}.$msg2.$CompareTo{$type}{REVISION});
                return ERROR;
            } 
            
            if("$OrgVer{$type}{BUILD_ID}" ne "$CompareTo{$type}{BUILD_ID}")
            {
                logInfo($msg1." for data set ". $type);
                loginfo($OrgVer{$type}{BUILD_ID}.$msg2.$CompareTo{$type}{BUILD_ID});
                return ERROR;
            }
            
            if("$OrgVer{$type}{SYSTEM_RLS}" ne "$CompareTo{$type}{SYSTEM_RLS}")
            {
                logInfo($msg1." for data set ". $type);
                loginfo($OrgVer{$type}{SYSTEM_RLS}.$msg2.$CompareTo{$type}{SYSTEM_RLS});
                return ERROR;            
            }

            logInfo("Firmware data sets have matched... ");
        } 
    }
    logInfo(">>>> All firmware data sets have matched");
    return GOOD;
}

##############################################################################

=head2 ControllerResetWithFailOver
          
Gracefully reboots the controllers enabling rolling code update.  
This function is used on the controller that has to be rebooted after the code has been 
successfully applied. Fails controller and reboot is by power cycling controller.

=over 4

=item Usage:

 my $FuctionReturn = ControllerResetWithFailOver ( $MasterObj, 
                                                   $FailSerailNumber, 
                                                   $RebootObj );    
 
 where: $MasterObj - Object of the master controller
        $FailSerailNumber - Serial number of the controller to be failed and reset
        $RebootObj - Object of the controller to be reset 

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error - Returns 1 (ERROR).

=back

=cut




##############################################################################
#
#          Name: ControllerRebootWithFailOver
#
#        Inputs: $MasterObj - Object of the master controller
#                $FailSerailNumber - Serial number of the controller to be failed and reset
#                $RebootObj - Object of the controller to be reset
#                $MoxaIp - IP address of the Moxa Power switch
#                $Chan - Moxa Channel 
#
#
#       Outputs: Good - 0
#                Error - 1
#
#  Globals Used: none
#
#   Description:  Gracefully resets the controllers enabling rolling code update.  
#                 This function is used on the controller that has to be reset after 
#                 the code has been successfully applied. Fails controller and resets 
#                 controller CCBE, Front End, Back End, Qlogic Cards.
#
###############################################################################


sub ControllerRebootWithFailOver
{
    my ( $MasterObj, $FailSerialNumber, $RebootObj, $MoxaIp, $Chan) = @_;
    trace();

    my $TimeDelay = 30;                 #-reconnect in 30 sec time 
    my $msg = " controller Serial Number  ";
    
    my $FuntionRet = TestLibs::IntegCCBELib::FailController($MasterObj, $FailSerialNumber);
    
    if( $FuntionRet != GOOD)
    {
        logInfo(" ");
        logInfo("    ====> ERROR: Can not fail ". $msg.$FailSerialNumber . " <====");
        return ERROR;
    }
    else
    {
        logInfo("    ====> " . $msg.$FailSerialNumber." was failed");
    }
    
    $FuntionRet = PowerCycle( $MoxaIp, $Chan );

    if($FuntionRet != GOOD)
    {
        logInfo(" ");
        logInfo("    ====> ERROR: Can not power cycle ". $msg. $FailSerialNumber . " <====");
        return ERROR;
    }

    $FuntionRet = Reconnect($RebootObj, $TimeDelay); 
    
    if($FuntionRet != GOOD)
    {
        logInfo(" ");
        logInfo("    ====> ERROR: Can not reconnect to ". $msg. $FailSerialNumber . " <====");
        return ERROR;
    }
    
    my $check = 1;
    my $break = 0;
   
    while($check != 0)
    {
        my $PowerUpSate = GetPowerUpState( $RebootObj );
        
        if($PowerUpSate == POWER_UP_FAILED) #-Power Up FAILD STATE for the controller
        {
            $check = 0;
        }
        else
        {
            if($break < 20 )
            {
                logInfo("Power-Up state after reset is ".$PowerUpSate);
                logInfo("Pausing for 10 sec...");
                DelaySecs(10);
                $break++;
            }
            else
            {
                logInfo("    ====> Code Update test has failed !!! <====");
                logInfo("    ====> Expected power up state -> Failed <====");
                logInfo("    ====> Wrong power up state ".$PowerUpSate . " <====");
                return ERROR; 
            }
        }
    }
    
    
    #
    # Unfail the controller
    #

    $FuntionRet = UnFailController( $MasterObj,  $FailSerialNumber);
    
    if( $FuntionRet != GOOD)
    {
        logInfo("    ====> ERROR: Failed to unfail controller <====");
        return ERROR;   
    }
    else
    {
        logInfo("Controller serial number $FailSerialNumber was unfailed");
    }
    return GOOD;
}


##############################################################################

=head2 ControllersValidateAll
          
Validate controllers state, virtual disk state, raids state, 
target state and if the targets have been moved back after fail over 
and rest of the appropriate controller, physical disk state and server activity.

=over 4

=item Usage:

 my $FuctionReturn = ControllersValidateAll ( $coPtr, 
                                              $activeServersRef, 
                                              $startingTmapRef,
                                              $vdiskListRef,
                                              $serialNumsRef,
                                              $pdiskDataRef,
                                              $vdiskDataRef,
                                              $raidDataRef);    
 
 where: $coPtr              - pointer to the list of controllers objects.
        $activeServersRef   - pointer to the server activity array obtained 
                                from GetServerActivityCounts();
        $startingTmapRef    - pointer to the targets activity obtained 
                                from CreateTargetMap().
        $vdiskListRef       - pointer to the virtual disk activity 
                                Obtained from GetVdiskActivityCounts().
        $serialNumsRef      - pointer to the list containing serial 
                                numbers of the controllers.
        $pdiskDataRef       - pointer to the list containing physical 
                                disk information obtained from GetPdiskStateArray(). 
        $vdiskDataRef       - pointer to the list containing physical
                                disk information obtained from GetVdiskStateArray().
        $raidDataRef        - pointer to the list containing physical
                                disk information obtained from GetRaidStateArray().
 
 if($FuctionReturn != 0)
 {
    print "Controller validation failed \n";
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error - Returns 1 (ERROR).

=back

=cut






=head2 ControllersValidateAll
          
Validate controllers state, virtual disk state, raids state, 
target state and if the targets have been moved back after fail over 
and rest of the appropriate controller, physical disk state and server activity.
     
=over 4

=item Usage:

 my $FuctionReturn = ControllersValidateAll ( @ValidateInfo );     
  
 where:     
    $ValidateInfo[0] - pointer to the list of controllers objects.
    $ValidateInfo[1] - pointer to the server activity array obtained from GetServerActivityCounts();
    $ValidateInfo[2] - pointer to the targets activity obtained from CreateTargetMap().
    $ValidateInfo[3] - pointer to the virtual disk acrivity Obtained from GetVdiskActivityCounts().
    $ValidateInfo[4] - pointer to the list containing serial numbers of the controllers.
    $ValidateInfo[5] - pointer to the list containing physical disk information obtained from GetPdiskStateArray(). 
    $ValidateInfo[6] - pointer to the list containing physical disk information obtained from GetVdiskStateArray().
    $ValidateInfo[7]- pointer to the list containing physical disk information obtained from GetRaidStateArray().
 

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error - Returns 1 (ERROR).

=back

=cut

##############################################################################

=head2 CodeUpdateMainLoop
          
Rolling Code Update Robustness test main - function that contains 
calls to enable rolling code update. Rolling code update definition: 
while Bigfoot is executing IO, code is applied to one of the controllers in 
VCG, and then the controller is deactivated and reset.  Deactivated controller 
is activated.  The same set of actions is repeated on the second controller in the VCG.  During the test, script checks server activity, makes sure that after the controller is activated targets fail back, check physical disk state, virtual disks state and raids state. If the number of times to execute the test is not passed into the function Robustness Rolling Code Update will update both controllers until system error occurs of user stops the test manually.

=over 4

=item Usage:

 my $FuctionReturn = RollingCodeUpdateMain( $ObjListRef, $PassToCodeLevelsRef, $TimeToRunTheTest );     
  
 where:     
    $ObjListRef - pointer to the list of controllers objects.
    $PassToCodeLevelsRef - pointer to the list  Containing passes to the location of code update (.fwk) files.
    $TimeToRunTheTest - number of time to execute the test, 
                        if nothing is passed the test will run until 
                        system error occurs or user stops the test manually. 
 

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error - Returns 1 (ERROR).

=back

=cut


##############################################################################
#
#          Name: CodeUpdateMainLoop
#
#        Inputs: $ObjListRef - pointer to the list of controllers objects.
#                $PassToCodeLevelsRef - pointer to the list  Containing passes to the location of code update (.fwk) files.
#                $TimeToRunTheTest - number of time to execute the test, 
#                                    if nothing is passed the test will run until 
#                                    system error occurs or user stops the test manually.
#               $MoxaIp             - Moxa Ip address
#               $RefChannels        - Pointer to the list of Moxa channels
#
#       Outputs: Good(0), Error(1)
#
#  Globals Used: none
#
#   Description: Rolling Code Update Robustness test main - function that contains 
#               calls to enable rolling code update. Rolling code update definition: 
#               while Bigfoot is executing IO, code is applied to one of the controllers in 
#               VCG, and then the controller is deactivated and reset.  Deactivated controller 
#               is activated.  The same set of actions is repeated on the second controller in the VCG.
##############################################################################

sub CodeUpdateMainLoop
{
    my ( $ObjListRef, $PassToCodeLevelsRef, $TimeToRunTheTest, $MoxaIpRef, $RefChannels ) = @_;
    trace();

    my @ObjList = @$ObjListRef;
    my @Channels = @$RefChannels;
    my @MoxaIp = @$MoxaIpRef;
    my @PassToCodeLevels = @$PassToCodeLevelsRef;
    my @ValidateInfo;
    my $FunctionRet;
    my $TestGoodRunCount = 0;
    my $TestLoopExecute = 1;
    my @ControllerUpdateCount;
    my $UpdateCont;

    my @activeServersRef; 
    my @startingTmapRef;
    my @initialVdisksRef; 
    my @serialNumsRef;
    my @pdiskDataRef;
    my @vdiskDataRef;
    my @raidDataRef;






    
    #
    # - Initialize code update count for each controller 
    #

    for(my $y = 0; $y < scalar(@ObjList); $y++)
    {
        $ControllerUpdateCount[$y] = 0;    
    }
    
    
    if($TimeToRunTheTest)
    {
        $TestLoopExecute = $TimeToRunTheTest; 
    }
    
    while( $TestLoopExecute > 0 )
    {
        #
        # For each code level loop
        #
    
        for ( my $outerloop = 0; $outerloop < scalar(@PassToCodeLevels); $outerloop++)
        {
            logInfo("Generating Activity Information");

            @activeServersRef = PreCodeApplyControllersSnapShot( $ObjListRef, ACTIVESERVERLIST ); 
            @startingTmapRef = PreCodeApplyControllersSnapShot( $ObjListRef, TARGETMAP );
            @initialVdisksRef = PreCodeApplyControllersSnapShot( $ObjListRef, INITIALVDISKS);
            @serialNumsRef = PreCodeApplyControllersSnapShot( $ObjListRef, SERIALNUMBERS2 );
            @pdiskDataRef = PreCodeApplyControllersSnapShot( $ObjListRef, PDISKDATA );
            @vdiskDataRef = PreCodeApplyControllersSnapShot( $ObjListRef, VDISKDATA );
            @raidDataRef = PreCodeApplyControllersSnapShot( $ObjListRef, RAIDDATA );

            if(( $activeServersRef[0] == INVALID ) || 
               ( $startingTmapRef[0] == INVALID )  ||
               ( $initialVdisksRef[0] == INVALID ) ||
               ( $serialNumsRef[0] == INVALID )    ||
               ( $pdiskDataRef[0] == INVALID )     ||
               ( $vdiskDataRef[0] == INVALID )     ||
               ( $raidDataRef[0] == INVALID )) 
            {
                logInfo("    ====> Failed while getting validate information... <====");
                return ERROR;
            }

            #
            # For each controller loop
            #

            for(my $innerLoop = 0; $innerLoop < scalar(@ObjList); $innerLoop++)
            {
                $FunctionRet = ControllerCodeApply($ObjList[$innerLoop], $PassToCodeLevels[$outerloop]);
            
                if( $FunctionRet != GOOD )
                {
                    logInfo("Test failed: Unable to apply code....");
                    return ERROR;
                }
                
                #
                # Increment number of times controller has been updated
                #
           
                $ControllerUpdateCount[$innerLoop]++; 
                
                my $MasterObj = FindMaster($ObjListRef);
                
                if($MasterObj < 0)
                {
                    logInfo("    ====> Test failed: After code update, unable to find master controller... <====");
                    return ERROR;
                }
                
                my $RestSerial = GetSerial($ObjList[$innerLoop]);
                
                if($RestSerial == INVALID )
                {
                    logInfo("    ====> Test failed: After code update, unable to get serial number of the controller <====");
                    return ERROR;
                }
                
                $FunctionRet = ControllerRebootWithFailOver($ObjList[$MasterObj], 
                                                            $RestSerial, 
                                                            $ObjList[$innerLoop],
                                                            $MoxaIp[$innerLoop], 
                                                            $Channels[$innerLoop]);
                    
                if( $FunctionRet != GOOD )
                {
                    logInfo("    ====> Test failed: Unable to reboot controllers... <====");
                    return ERROR;
                }
                logInfo(" ");
                logInfo("Controller serial number $RestSerial has been updated ".$ControllerUpdateCount[$innerLoop]." time(s)");        
                logInfo(" ");
                DelaySecs(120);
            } 

            $FunctionRet = ControllersValidateAll($ObjListRef,
                                                  \@activeServersRef,
                                                  \@startingTmapRef,
                                                  \@initialVdisksRef,
                                                  \@serialNumsRef,
                                                  \@pdiskDataRef,
                                                  \@vdiskDataRef,
                                                  \@raidDataRef);
            if($FunctionRet != GOOD)
            {
                logInfo("    ====> Test failed: system data mismatch <====");
                return ERROR;
            } 
           
            $FunctionRet = CompareFwVersion($ObjListRef);
            
            if( $FunctionRet != GOOD )
            {
                logInfo("    ====> Test failed: firmware versions mismatch <====");
                return ERROR;
            }
            
            $TestGoodRunCount++;
        }

        if( $TimeToRunTheTest )
        {
            $TestLoopExecute--; 
        }
    }
    
    logInfo("Test completion ..... GOOD ");
    logInfo("During the test, Contollers were updated $TestGoodRunCount time(s) !!!!");
    return GOOD;
}


################################################################################

=head2 GetFwversion
          
Retrieve firmware versions for single controller;

=over 4

=item Usage:

 my %FuctionReturn = GetFwversion( $Obj );    
 
 where: $Obj - controller object to which code should be Applied 
 

 
 if( ! %FuctionReturn)
 {
    print "Unable to retrieve firmware versions \n";
 } 

 Notes:
 
 None

=item Returns:

 On success - Returns hash with information.
 On error - Returns empty hash.

=back

=cut



##############################################################################
#
#          Name: GetFwversion
#
#        Inputs: Controller object
#
#       Outputs: Hash with firmware infomation  if GOOD
#               Empty Hash if error
#
#  Globals Used: none
#
#   Description: Retrieve firmware versions for single controller
#
#
##############################################################################

sub GetFwversion
{
    my ( $obj ) = @_;
    my %EmptyHash;
    trace();

    ################################################################
    #
    # Get and Display Firmware Ver 
    #
    
    my %rsp = $obj->fwVersion();

    if (!%rsp)
    {
        print "    ====> ERROR: Failed to receive a response from fwVersion. <==== \n";
        return %EmptyHash;     #-error break return empty hash
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        my $msg = "    ====> ERROR: Failed to retrieve firmware version information. <====";
        displayError($msg, %rsp);
        return %EmptyHash;      #-error break return empty hash
    }
    
    my $fmsg = $obj->displayFirmwareVersion(%rsp);
    print $fmsg;

    print "Completed Display of Firmware Versions...\n \n";

    return %rsp;        #-no error return good hash
}

##############################################################################
#
#          Name: ScrubLoopMain
#
#        Inputs: Pointer to the list of controller objects
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Comapares Controller(s) Version(s), if all the same returns
#                GOOD if defferent return ERROR;
#
#
##############################################################################
sub ScrubLoopMain
{
    my( $PointerObjList );
    
    # Find Who is the master
    # Get initial info
    # Get an array of addresses of SCISI devices to be hit
            # Build a hash key device ID
            # Set all values to 0
            # when hit change value hit - 1
            
    # 0 out the logs
    # start the trace
    # issue scrub command 
    # get last 40 logs
        # make sure the coresponding log message has been issued
            #- if it has been issued Set the flag to good
            # 

      
}


##############################################################################
#
#          Name: CreateMaxVd
#
#        Inputs: Pointer to the list of controller objects
#                VD raids type (1 ( raid 0), 2 (raids 1), 4 (raid 10))
#                Number of times to run the test 
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Creates max number of virutal disks of certain raid 
#
#
##############################################################################

sub CreateMaxVd
{
    my ( $PointerObjList, $rtype, $TimeToRunTheTest ) = @_;
    
    # Get validation info
    # Find Who is the master
    # Get number of virtual disks created
    # Then calculate the number of virtual disks to create
    # In the for loop create number of virutal disks needed
    #   pushing IDs on the array
    # In the for loop delete all crated virtual disks

    my $TestLoopExecute;
    my @ObjList = @$PointerObjList;
    my $capacity = 1;
    my $MaxNumber = 512;


    my @activeServers;
    my @startingTmap;
    my @initialVdisks;
    my @serialNums;
    my @pdiskData;
    my @vdiskData;
    my @raidData;
    my $FunctionRet;


    if($TimeToRunTheTest)
    {
        $TestLoopExecute = $TimeToRunTheTest; 
    }
    
    while( $TestLoopExecute > 0 )
    {
        logInfo("Generating Activity Information");

        @activeServers = PreCodeApplyControllersSnapShot( \@ObjList, ACTIVESERVERLIST ); 
        @startingTmap = PreCodeApplyControllersSnapShot( \@ObjList, TARGETMAP );
        @initialVdisks = PreCodeApplyControllersSnapShot( \@ObjList, INITIALVDISKS);
        @serialNums = PreCodeApplyControllersSnapShot( \@ObjList, SERIALNUMBERS2 );
        @pdiskData = PreCodeApplyControllersSnapShot( \@ObjList, PDISKDATA );
        @vdiskData = PreCodeApplyControllersSnapShot( \@ObjList, VDISKDATA );
        @raidData = PreCodeApplyControllersSnapShot( \@ObjList, RAIDDATA );

        if(( $activeServers[0] == INVALID ) || 
           ( $startingTmap[0] == INVALID )  ||
           ( $initialVdisks[0] == INVALID ) ||
           ( $serialNums[0] == INVALID )    ||
           ( $pdiskData[0] == INVALID )     ||
           ( $vdiskData[0] == INVALID )     ||
           ( $raidData[0] == INVALID )) 
        {
            logInfo("    ====> Failed while getting validate information... <====");
            return ERROR;
        }

        my $MasterObj = FindMaster(\@ObjList);
                
        if($MasterObj < 0)
        {
            logInfo("    ====> Test failed: After code update, unable to find master controller... <====");
            return ERROR;
        }


        
        my @VdListExist = GetVdiskList($ObjList[$MasterObj]);
        
        if($VdListExist[0] < 0)
        {
            logInfo("    ====> ERROR: Unable to get Virtual disk list <====");
            return ERROR;
        }
        
        my $NumberOfVdtoCreate = $MaxNumber - scalar(@VdListExist);
        
        if($NumberOfVdtoCreate == 0)
        {
            logInfo("There are ".scalar(@VdListExist)." Virtual disks exists ");
            return ERROR;
        }
        
        my @PdList; #-used in virutal disk creation
        my $stripe = 512; #-use by default
        my $parity = 0; #-is not used, used only in raid 5
        my $depth = 2;
                
        my @CreatedVd;
        
        #
        # Raid 10 virutal disk
        #

        if(( $rtype == RAID_10 ) || ( $rtype == RAID_1 ))
        {
            
            # Get data type drives
            @PdList = GetTheseDisks($ObjList[$MasterObj], CCBEDATATYPE);
            
            if($PdList[0] < 0)
            {
                logInfo("    ====> ERROR: Unable to get physical drives labeled as Data <====");
                return ERROR;
            }
        }

        
        if( $rtype == RAID_0 )
        {
            # Get unsafe type drives
            
            @PdList = GetTheseDisks($ObjList[$MasterObj], CCBEUNSAFETYPE);
            
            if($PdList[0] < 0)
            {
                logInfo("    ====> ERROR: Unable to get physical drives labeled as Unsafe <====");
                return ERROR;
            }
                        
        }

        #
        # Raid 1 physical disk calculation;
        #
        
        my @AccPhysicalDisks;

        
        if($rtype == RAID_1 )
        {
            @AccPhysicalDisks = ($PdList[0], $PdList[1]);
        }
        else
        {
            @AccPhysicalDisks = @PdList;
        }

        
        my $i;  # - loop count
        
        for( $i = 0; $i < $NumberOfVdtoCreate; $i++)
        {
            
            my $VdId = CreateSingleVdisk($ObjList[$MasterObj], 
                                         $i, 
                                         $capacity, 
                                         $rtype, 
                                         $stripe, 
                                         $depth, 
                                         $parity, 
                                         \@AccPhysicalDisks);
            if( $VdId < 0 )
            {
                logInfo("    ====> ERROR: unable to create virutal disk number $i <====");                
                @VdListExist = GetVdiskList($ObjList[$MasterObj]);
        
                if($VdListExist[0] < 0)
                {
                    logInfo("    ====> ERROR: Unable to get Virtual disk list <====");
                    return ERROR;
                }
                
                logInfo("Number of virtual disks currently present on the Bigfoot: ". scalar(@VdListExist));
                return ERROR;
            }
            else
            {
                @VdListExist = GetVdiskList($ObjList[$MasterObj]);
        
                if($VdListExist[0] < 0)
                {
                    logInfo("    ====> ERROR: Unable to get Virtual disk list <====");
                    return ERROR;
                }
                          
                logInfo("Virtual disk number ". scalar(@VdListExist)  ." was created, Id - $VdId"); 
                push(@CreatedVd, $VdId);
            }
        }

        #
        # Create extra virtual disk should fail
        #

        my $VdIdExt = CreateSingleVdisk($ObjList[$MasterObj], 
                                     $i, 
                                     $capacity, 
                                     $rtype, 
                                     $stripe, 
                                     $depth, 
                                     $parity, 
                                     \@AccPhysicalDisks);
         if( $VdIdExt < 0 )
         {
             logInfo("EXPECTED: unable to create virtual disk number $i");                
             @VdListExist = GetVdiskList($ObjList[$MasterObj]);
        
             if($VdListExist[0] < 0)
             {
                 logInfo("    ====> ERROR: Unable to get Virtual disk list <====");
                 return ERROR;
             }
             
             logInfo("Number of virtual disks currently present on the Bigfoot: ". scalar(@VdListExist));
         }
         else
         {
             @VdListExist = GetVdiskList($ObjList[$MasterObj]);
        
             if($VdListExist[0] < 0)
             {
                 logInfo("    ====> ERROR: Unable to get Virtual disk list <====");
                 return ERROR;
             }
                          
             logInfo("Virtual disk number ". scalar(@VdListExist)  ." was created, Id - $VdIdExt");
             return ERROR;
         }


        #
        # Delete created virtual disks
        #
        
        for (my $t = 0; $t < scalar(@CreatedVd); $t++)
        {
            $FunctionRet = DeleteSingleVdisk($ObjList[$MasterObj], $CreatedVd[$t]);
            
            if( $FunctionRet < 0 )
            {
                logInfo("    ====> Unable to delete vd id $CreatedVd[$t] <====");
                return ERROR;
            }
            logInfo("Vd id $CreatedVd[$t] was deleted ");
        }

        #
        # Make sure we are still connected
        #
        $FunctionRet = TestNReconnectAll($PointerObjList);
        if ( $FunctionRet != GOOD ) { return ERROR; }
       
       
        $FunctionRet = ControllersValidateAll(\@ObjList,
                                              \@activeServers,
                                              \@startingTmap,
                                              \@initialVdisks,
                                              \@serialNums,
                                              \@pdiskData,
                                              \@vdiskData,
                                              \@raidData);
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Test failed: system data mismatch <====");
            return ERROR;
        } 
           
        if( $TimeToRunTheTest )
        {
            $TestLoopExecute--; 
        }
    }

      
}




################################################################################

=head2 PowerCycleDriveBay
          
Robustness test that power cycles drive bay, depending on the key allows the drives
to rebuild. If $Key = TRUE - allow drive bay to rebuild.

    # Virtual disks activity and server activity
    # Find Who is the master
    # Power Cycle Drive bay
    # Depending on the key, 
    #       wait for rebuild to compete
    #       do not wait for rebuild to complete
    # Validate virtual disks activity and server activety

=over 4

=item Usage:

 my $FuctionReturn = PowerCycleDriveBay($PointerObjList, 
                                        $MoxaIP, 
                                        $Chan, 
                                        $Key, 
                                        $TimeToRunTheTest);    
 
 where: $PointerObjList - pointer to the list of objects
        $MoxaIP - Moxa Ip address
        $Chan - Channel to power cycle
        $Key -  key TRUE wait for rebuild to complete
        $TimeToRunTheTest - number of times to run the test    
 

 
 Notes:
 
 None

=item Returns:

 On success - GOOD.
 On error - ERROR.

=back

=cut






##############################################################################
#
#          Name: PowerCycleDriveBay
#
#        Inputs: 
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: #
#
##############################################################################


sub PowerCycleDriveBay
{

    my ( $PointerObjList, $MoxaIP, $Chan, $Key, $inLoops ) = @_;
    
    trace();
    
    #
    # Set Local Vars
    #
    my $TestLoopExecute = 1;
    my @ObjList = @$PointerObjList;
    my $iloop = 0;
    my $return;
    my @activeServers;   # to insure IO activity
    my @serialNums;
    my $FunctionRet;     # to insure system state 
    my $ExtraCheckRet;   # to Double Check for outstanding rebuilds
    my $ret;
    
    my @startingTmap;
    my @initialVdisks;
    my %info1;
    my $vdiskListPtr;
    my @vCounts;
    my @sCounts;
    my $newMaster;
    
    my %mirrorData;

    my %raidsHash; 
    my %pdisksHash;
    my %vdisksHash;
    my @coList;
    
    @coList = @$PointerObjList; 

    my $DebugMes = "Robustness  - Drive Bay Power Cycle test begins";
        
    #
    # Send test start message to the controller logs
    #
    $FunctionRet = CtlrLogTextAll($PointerObjList, $DebugMes);
        
    if($FunctionRet != GOOD)    
    {
        logInfo("    ====> Unable to send message to debug console <====");
        return ERROR;   
    }

    #
    # Find Master
    #
    $newMaster = TestLibs::IntegCCBELib::FindMaster( \@coList );
    if ( $newMaster == INVALID )
    {
        logError("    ====> Failed to find the master controller <====");
        return ERROR;
    }
        
    # Capture mirrorData to use for call to TSS3
    $ret = MirrorInitialData( $PointerObjList, \%mirrorData);
        
    #
    # Check BE HASHs before start of the loop
    #
    $ret = CheckBEHashes( \%mirrorData );
    if ( $ret == ERROR )
    {
        logInfo("    ====> Initial BE Hash indicated a bad state. <====");
        return ERROR;
    }


    for ($iloop = 0; $iloop < $inLoops; $iloop++ )
    {

        #
        # find the currently active servers
        #
        logInfo("Getting initial data for activity measurements.");

        @vCounts = GetVdiskActivityCounts($PointerObjList);
        @sCounts = GetServerActivityCounts($PointerObjList);

        logInfo("Pause to allow activity to accumulate");
        DelaySecs(20);
        
        #
        # Get the initial active vdisks for the test
        #
        logInfo("Generating Activity Information");

        @activeServers = MakeActiveServerMap( \@coList,  \@sCounts, 10 );
        @initialVdisks = MakeActiveVdiskMap( \@coList,  \@vCounts, 10 );

        $vdiskListPtr  = \@initialVdisks;

        if ( scalar(@initialVdisks) != 0 )
        {
            #
            # we have some active vdisks
            #
            if ( $initialVdisks[0] == INVALID )
            {
                #
                # error case 
                #
                logInfo("    ====> Warning - can't get an initial active vdisklist  <====");
                $vdiskListPtr  = 0;   # clear the point so we skip the following tests
            }
        }

        #
        # Find Master controller
        #
        my $MasterObj = FindMaster(\@ObjList);
            
        if($MasterObj == INVALID)
        {
            logInfo("    ====> Test failed: unable to find master controller... <====");
            return ERROR;
        }
            
        logInfo("");
        logInfo("--------------------- Loop $iloop of $inLoops completed, . -------------------");
        logInfo("");
        logInfo("");
                
        #
        # Power Cycle drive bay via Moxa/APC
        #
        $DebugMes = "Power Cycle Drive Bay Test: Power Off ";
    
        $FunctionRet = CtlrLogTextAll($PointerObjList, $DebugMes);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to send message to debug console <====");
            return ERROR;   
        }

        #
        # Send Power OFF command to the MOA/APC
        #    
        $FunctionRet = TestLibs::xiocontrol::ACPowerControl(  $$MoxaIP[0], $$Chan[0], 0); 
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to power off drive bay <====");
            return ERROR;
        }

        #
        # Add 5 second delay between power on/off
        #
        DelaySecs(5);

        $DebugMes = "Power Cycle Drive Bay Test: Power On ";
    
        #
        # Send Power On message to the controller logs
        #
        $FunctionRet = CtlrLogTextAll($PointerObjList, $DebugMes);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to send message to debug console <====");
            return ERROR;   
        }
                  
        #
        # Send Power ON command to the MOA/APC
        #
        $FunctionRet = TestLibs::xiocontrol::ACPowerControl( $$MoxaIP[0], $$Chan[0], 1); 
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to power on drive bay <====");
            return ERROR;
        }
            
        logInfo("Drive bay has been power cycled");
    
        #
        # Check for Good SES data before procedding
        #
        my $check = TRUE;                                                       
        my $count = 0;

        logInfo("Waiting for drive bay to power up...");
    
        DelaySecs(45);

        logInfo(" ");
        logInfo("Waiting for SES to come on ready....");
        logInfo(" ");
    
        #
        # Find Master controller
        #
        $MasterObj = FindMaster(\@ObjList);
            
        if($MasterObj == INVALID)
        {
            logInfo("    ====> Test failed: unable to find master controller... <====");
            return ERROR;
        }
        
        $FunctionRet = Wait4Ses($ObjList[$MasterObj], 120);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Timed out while waiting for SES to come ready <====");
            return ERROR;
        }  
        
        #
        # Start Check loop; Check for rebuilds to start and then monitor progress
        #
        while( $check == TRUE )
        {
        
            #
            # Allow drive bay to come on ready
            #
            logInfo("Waiting for rebuild to start...");
            DelaySecs(30);

            $FunctionRet = DegradeCheck($ObjList[$MasterObj]);
        
        
            if($FunctionRet == ERROR)
            {
                logInfo("    ====> ERROR: occured while checking physical disk status <====");
                return ERROR;
            }

            if($count < 10 )
            {
                if($FunctionRet == INVALID)
                {
                    logInfo("Rebuild started....");
                    $check = FALSE; 
                }
                elsif($FunctionRet == GOOD)
                {
                    logInfo("Rebuild Completed before function called (Increase number of Vdisks with I/O).");
                    $check = FALSE; 
                }

            }
            else
            {
                logInfo("    ====> Rebuild did not start after 5 min <====");
                return ERROR;
            }

            $count++;
        }
    
        #
        # Depending on the key wait for rebuild to finish
        #
        if($Key == TRUE)
        {
            $check = TRUE;
        
            while( $check == TRUE )
            {
        
                #
                # Allow time for drive to rebuild
                #
                logInfo("Waiting for rebuild to complete ");
            
                DelaySecs(90);

                $FunctionRet = WaitRebuild($ObjList[$MasterObj]);          
            
                if($FunctionRet == ERROR)
                {
                    logInfo("    ====> ERROR: occured while checking physical disk status <====");
                    return ERROR;
                }
            
                if($FunctionRet == GOOD)
                {
                    logInfo("Rebuild finished / Double Checking....");
                }
            
                DelaySecs(30);

                #
                # Let's double check that all rebuilds have completed
                #
                $ExtraCheckRet = WaitRebuild($ObjList[$MasterObj]);

                if($ExtraCheckRet == ERROR)
                {
                    logInfo("    ====> ERROR: occured while checking physical disk status <====");
                    return ERROR;
                }

            
                if($ExtraCheckRet == GOOD) 
                {
                    logInfo("Rebuilds finished....");
                    $check = FALSE;
                }
                else
                {
                    logInfo("Rebuilds have not yet completed.  Continue checking...");
                }
                                                              
            }
        }

        #
        # Test for CCBTIMEOUT and re-login if needed
        #
        $FunctionRet = TestNReconnectAll(\@ObjList);
    
        if($FunctionRet != GOOD)
        {
            logInfo("    ====> Unable to reconnect to one or more of the controllers. <====");
            return ERROR;
        }
            logInfo("");
            logInfo("--------------------- Loop $iloop of $inLoops completed, . -------------------");
            logInfo("");
            logInfo("");
        
        DelaySecs(60);    
        #
        # check the back end state, vdisk status, pdisk status, raid status
        #
        $ret = TestLibs::Validate::TestSystemState3($coList[$newMaster], \%mirrorData);
        if ( ($ret == ERROR))
        {
            logInfo("    ====> Validations have failed <====");
            return ERROR;
        }

       DelaySecs(30);
    }

    return GOOD;
  
}

#############################################################################
#
#          Name: RobustnessLabel
#
#        Inputs: $Loop - Optional - Number of time to re-label physical disks, 
#                        default - Infinite number   
#
#       Outputs: ERROR - if ERROR Occurs
#                GOOD - if $Loop is passed, after executing 
#                Number $Loop return GOOD on Success 
#
#  Globals Used: none
#
#   Description: Part of the Robustness Test; Re-labels physical disks with the 
#                current device label. Usually ran on the fully configured VCG 
#                with IO running.         
#
##############################################################################

sub RobustnessLabel
{
trace();
my ( $loop ) = @_;               #-Number of time to execute the test
my $count = 1;                   #-Check for while loop
my $rc = GOOD;                   #-Check for command execution
my $returnValue;
my @PdId;
 
if ( $loop )                     
{
    $count = $loop;
}    
else
{
    $loop = 0;
}

    $returnValue = PdList(\@PdId, "ALL");           #-Get Physical DiskList 
    if($returnValue != GOOD) {return ERROR;}
    
    while( $count )
    {
        for(my $i = 0; $i < scalar(@PdId); $i++)
        {
            if($rc == GOOD)
            {
                my %Hash = PdInfo($PdId[$i]); #-Get Physical Disk info
                if(%Hash)
                {
                    #-Label Physcal disk with the label it has right now 
                    $rc = TestLibs::IntegXMCLib::LabelSingleDrive($Hash{PSTATE}, $PdId[$i]);  
                    if( $rc == ERROR)
                    {
                        return ERROR;    
                    } 
                }
                else
                {
                    return ERROR;
                }
            }
            else
            {
                return ERROR;
            }
        }

        if( $loop > 0)
        {
            $count--;
        }
    }
           
    return GOOD;   
}

=head2 RobustnessLabel

This test Runs on a Dual or Single Controller. 
 
 Test set up: 
 
 All physical disks recognized by the Bigfoot are labeled and in operational state, 
 Virtual disks are created and I/O is being executed on the server.
 
 Test Execution stops on Error cause by following:    
 
 Unable to retrieve physical disk list
 Unable to retrieve physical disk information 
 Unable to Label physical disk  


 Calls PdList()
          Gets physical disk list  
          On Success - Returns an Array of physical disk IDs 
          On Failure - Returns an Array with first Element less then 0 
 
 for each physical disk ID...
    
    Calls PdInfo($Physical_Disk_ID)
              On Success - Returns a Hash with of physical disk infomation  
              On Failure - Returns an Empty Hash

    Calls LabelSingleDrive($Physical_Disk_ID)
              Labels single Physical disk
              On Success - Returns GOOD - 0 value  
              On Failure - Returns ERROR - 1 value 
  
=over 4

=item Usage:
 
 my $rc = RobustnessLabel( $Loop );
 or 
 my $rc = RobustnessLabel();

 where Inputs:      
               $Loop - ( Optional Input ) is a Number of times Test should be executed, 
If $Loop is not passed into the function by the User, Test will be Executed until Error occurs or 
until User manually stop the Test   
       

 Notes:
 
 None

=item Returns:

 $rc will be GOOD  - only in case if $Loop is passed and Test has executed Successfully
 $rc will be ERROR - if following errors occured: 
                    Unable to retrieve physical disk list
                    Unable to retrieve physical disk information 
                    Unable to Label physical disk 

=back

=cut

#############################################################################
#
#          Name: RobustServerProp
#
#        Inputs: Controller Obj, SID, loop count (default is 1000) 
#
#       Outputs: ERROR - if ERROR Occurs
#                GOOD  
#
#   Description: Part of the Robustness Test; Re-labels physical disks with the 
#
##############################################################################

sub RobustServerProp
{
    trace();

    my ($controller, $sid, $loop) = @_;
    
    my %rsp;

    if ( !$loop )                     
    {
        $loop = 1000;
    }    

    for (1 .. $loop)
    {
        %rsp = $controller->serverProperties($sid, 0, 1);

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                logInfo("Properties for Server $sid set successfully to 1");
            }
            else
            {
                logInfo("    ====> Failed to set properties on server $sid <====");
                PrintError(%rsp);
                return ERROR;
            }
        }
        else
        {
            logInfo("    ====> Did not receive a response packet setting server properties <====");
            return ERROR;
        }

        %rsp = $controller->serverProperties($sid, 0, 0);

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                logInfo("Properties for Server $sid set successfully to 0");
            }
            else
            {
                logInfo("    ====> Failed to set properties on server $sid <====");
                PrintError(%rsp);
                return ERROR;
            }
        }
        else
        {
            logInfo("    ====> Did not receive a response packet setting server properties <====");
            return ERROR;
        }
    }

    return GOOD;
}

=head2 RobustnessLabel

This test Runs on a Dual or Single Controller. 
 
 Test set up: 
 
 All physical disks recognized by the Bigfoot are labeled and in operational state, 
 Virtual disks are created and I/O is being executed on the server.
 
 Test Execution stops on Error cause by following:    
 
 Unable to retrieve physical disk list
 Unable to retrieve physical disk information 
 Unable to Label physical disk  


 Calls PdList()
          Gets physical disk list  
          On Success - Returns an Array of physical disk IDs 
          On Failure - Returns an Array with first Element less then 0 
 
 for each physical disk ID...
    
    Calls PdInfo($Physical_Disk_ID)
              On Success - Returns a Hash with of physical disk infomation  
              On Failure - Returns an Empty Hash

    Calls LabelSingleDrive($Physical_Disk_ID)
              Labels single Physical disk
              On Success - Returns GOOD - 0 value  
              On Failure - Returns ERROR - 1 value 
  
=over 4

=item Usage:
 
 my $rc = RobustnessLabel( $Loop );
 or 
 my $rc = RobustnessLabel();

 where Inputs:      
               $Loop - ( Optional Input ) is a Number of times Test should be executed, 
If $Loop is not passed into the function by the User, Test will be Executed until Error occurs or 
until User manually stop the Test   
       

 Notes:
 
 None

=item Returns:

 $rc will be GOOD  - only in case if $Loop is passed and Test has executed Successfully
 $rc will be ERROR - if following errors occured: 
                    Unable to retrieve physical disk list
                    Unable to retrieve physical disk information 
                    Unable to Label physical disk 

=back

=cut


1;   # we need this for a PM



###############################################
#
# Revision history
#
# $Log$
# Revision 1.1  2005/05/04 18:53:52  RysavyR
# Initial revision
#
# Revision 1.18  2005/01/12 23:12:51  PalmiD
# TBolt00000000: Added call to capture initial mirror data.  Changed call to
# "CheckBEHashes" to use mirror data hash. General cleanup of error
# message syntax.
# Reviewed by Craig Menning.
#
# Revision 1.17  2004/12/22 22:19:41  EidenN
# Tbolt00000:  Added a delay after TestNReconnect in PowerCycle Drive Bay - Reviewed by: Cmenning
#
# Revision 1.16  2004/12/22 21:34:29  EidenN
# Tbolt:000000:  Re-write of PowerCycleDriveBay section - Reviewed By: CMenning
#
# Revision 1.15  2004/10/13 18:17:29  EidenN
# Tbolt0000:  Fixed eval error with wookie hardware
#
# Revision 1.14  2004/10/03 19:39:47  EidenN
# Tbolt0000: Added CheckSystemState3
#
# Revision 1.13  2004/05/07 16:53:58  KohlmeyerA
# Tbolt00000000 - Corrected  max number of vdisks in CreateMaxVd.  Also added TestNReconnectAll.  Reviewed by Craig
#
# Revision 1.12  2004/01/19 22:01:12  VossO
# Tbolt00000000 Edit file
#
# Revision 1.11  2003/10/15 15:29:48  TeskeJ
# tbolt00009173 - raid-5 updates for release 3, mostly vdmax & crexpassocdel
# rev by Craig
#
# Revision 1.10  2003/06/03 19:47:36  MenningC
# TBOLT00000000: Changed many of the 'display' functions in the CCBCL to fill a string rather than print to the screen. The test scripts can now use these functions. Reviewed by Jeff W.
#
# Revision 1.9  2003/05/29 12:56:44  WerningJ
# Rewrote all XTC data structures
# Reviewed by Craig M
#
# Revision 1.8  2003/05/01 15:39:26  GrigorenkoO
# Tbolt00000000 Added BEutil lib
#
# Revision 1.7  2003/03/26 21:24:53  WerningJ
# Removed calls to unused modules
# Reviewed by Craig M
#
# Revision 1.6  2003/02/19 19:52:23  GrigorenkoO
# Tbolt00000000 added Wait4SES in PowerCycleDriveBay function
#
# Revision 1.5  2003/01/22 16:27:24  GrigorenkoO
# Tbolt00000000 Added power cycle drive bay test
#
# Revision 1.4  2003/01/15 15:42:17  GrigorenkoO
# Tbolt Added CreateMaxVd test case
#
# Revision 1.3  2003/01/07 22:27:50  MenningC
# Tbolt00000000: Many changes to handle the new content of targetstatus, reveiwed by Jeff Werning
#
# Revision 1.2  2002/10/22 18:56:07  MenningC
# tbolt00000000  changed some SERAILNUMBERS to SERIALNUMBRS2 to avoid a conflict,  reviewed by Max
#
# Revision 1.1  2002/10/15 18:04:03  GrigorenkoO
# New file
#
#
#
#
###############################################


