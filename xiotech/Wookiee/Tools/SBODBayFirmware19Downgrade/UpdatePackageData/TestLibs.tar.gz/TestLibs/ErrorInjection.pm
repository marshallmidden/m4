#! /usr/bin/perl s
# $Header$
####s##########################################################################
# File name:  TestLibs::ErrorInjection
#
# Desc: A set of library functions for Injecting Errors using special hardware.
#
# Date: 08/30/2002
#
# Original Author:  Jeff Werning
#
# Last modified by  $Author: RysavyR $
# Modified date     $Date: 2005-05-04 13:53:47 -0500 (Wed, 04 May 2005) $
#
#   Copyright 2003 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################
=pod
=head1 NAME

TestLibs::ErrorInjection - Perl Functions to Inject Errors into the XIOtech Storage Devices via special hardware

$Id: ErrorInjection.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED OS

    MS Windows

=head1 SYNOPSIS

This document describes usuage of the Perl Scripts to Inject Errors into the XIOtech hardware using an I2C interface

    use TestLibs::ErrorInjection.pm;
    I2CInject ($fault, $control, $comPort);

The following Globals are exported for use to select the Fault.

    PS_FAN_STATUS      
    PS_AC_FAIL         
    PS_DC_FAIL         
    PS_REMOVED         

    PS_12_VOLT         
    PS_5_VOLT          
    PS_BE_3_VOLT       
    PS_R74             

    I2C_ENVIORNMENTALS 
    I2C_FE_TEMP_SENSOR 
    I2C_SUICIDE_RESET  
    I2C_POWER_SUPPLY   

    SDRAM_FE_ADDRESS   
    SDRAM_FE_DATA      
    SDRAM_BE_ADDRESS   
    SDRAM_BE_DATA      

    NVSRAM_FE_ADDR_DATA
    NVSRAM_BE_ADDR_DATA

    PCI_FE_ADDR_DATA   
    PCI_BE_ADDR_DATA   
    PCI_CCB_ADDR_DATA  
    PCI_RESET_HOST_SLOT1  
    PCI_RESET_STORAGE_SLOT2  

    NMI_FE

    RESET_FE_PROC  
    RESET_BE_PROC  
    RESET_CCB_PROC  

The following Globals are exported for use when controlling the Fault.

    I2C_SET
    I2C_RESET
    I2C_PULSE
    
The COM Port must be the name as known in the Registry.    

=head1 DESCRIPTION

This module uses the iPort/AI RS-232 to I2C Host Adapter with ASCII Interface to inject errors into modified controller
hardware.  Documentation for the iPort/AI can be found at: http://www.mcc-us.com/202ug.htm


=cut

#                         
# - what I am
#

package TestLibs::ErrorInjection;

#
# - other modules used
#

use warnings;
use TestLibs::Logging;
use TestLibs::Constants;
use lib 'PerlLibs';
use Dumpvalue;

my $dumper = new Dumpvalue;

#
# - perl compiler/interpreter flags 'n' things
#

use strict;

BEGIN {
        my $OS_win = ($^O eq "MSWin32") ? 1 : 0;

#        print "Perl version: $]\n";
#        print "OS   version: $^O\n";

        # This must be in a BEGIN in order for the 'use' to be conditional
        if ($OS_win) {
#            print "Loading Windows modules\n";
            eval "use Win32::SerialPort";
            die "$@\n" if ($@);
            eval "use Win32API::CommPort qw( :PARAM :STAT 0.19 )";
            die "$@\n" if ($@);

        }
        else {
#            print "Loading Unix modules\n";
#            eval "use Device::SerialPort";
#           die "$@\n" if ($@);
        }
} # End BEGIN

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      &I2CInject

                      I2C_PULSE
                      I2C_RESET
                      I2C_SET

                      PS_FAN_STATUS      
                      PS_AC_FAIL         
                      PS_DC_FAIL         
                      PS_REMOVED         

                      PS_12_VOLT         
                      PS_5_VOLT          
                      PS_BE_3_VOLT       
                      PS_R74             

                      I2C_ENVIORNMENTALS 
                      I2C_FE_TEMP_SENSOR 
                      I2C_SUICIDE_RESET  
                      I2C_POWER_SUPPLY   

                      SDRAM_FE_ADDRESS   
                      SDRAM_FE_DATA      
                      SDRAM_BE_ADDRESS   
                      SDRAM_BE_DATA      

                      NVSRAM_FE_ADDR_DATA
                      NVSRAM_BE_ADDR_DATA

                      PCI_FE_ADDR_DATA   
                      PCI_BE_ADDR_DATA   
                      PCI_CCB_ADDR_DATA  
                      PCI_RESET_HOST_SLOT1  
                      PCI_RESET_STORAGE_SLOT2  

                      NMI_FE

                      RESET_FE_PROC  
                      RESET_BE_PROC  
                      RESET_CCB_PROC  

                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # Control
    use constant I2C_RESET     => 0;
    use constant I2C_SET       => 1;
    use constant I2C_PULSE     => 2;

    # Power Supply
    use constant PS_FAN_STATUS      =>  "PS_FAN_STATUS";
    use constant PS_AC_FAIL         =>  "PS_AC_FAIL";
    use constant PS_DC_FAIL         =>  "PS_DC_FAIL";
    use constant PS_REMOVED         =>  "PS_REMOVED";

    # DC Power Status
    use constant PS_12_VOLT         =>  "PS_12_VOLT";
    use constant PS_5_VOLT          =>  "PS_5_VOLT";
    use constant PS_BE_3_VOLT       =>  "PS_BE_3_VOLT";
    use constant PS_R74             =>  "PS_R74";

    # I2C
    use constant I2C_ENVIORNMENTALS =>  "I2C_ENVIORNMENTALS";
    use constant I2C_FE_TEMP_SENSOR =>  "I2C_FE_TEMP_SENSOR";
    use constant I2C_SUICIDE_RESET  =>  "I2C_SUICIDE_RESET";
    use constant I2C_POWER_SUPPLY   =>  "I2C_POWER_SUPPLY";
 
    # Zion Local Bus-SDRAM
    use constant SDRAM_FE_ADDRESS   =>  "SDRAM_FE_ADDRESS";
    use constant SDRAM_FE_DATA      =>  "SDRAM_FE_DATA";
    use constant SDRAM_BE_ADDRESS   =>  "SDRAM_BE_ADDRESS";
    use constant SDRAM_BE_DATA      =>  "SDRAM_BE_DATA";
 
    # SLV8 Bus-FLASH, NVSRAM
    use constant NVSRAM_FE_ADDR_DATA =>  "NVSRAM_FE_ADDR_DATA";
    use constant NVSRAM_BE_ADDR_DATA =>  "NVSRAM_BE_ADDR_DATA";
 
    # PCI BUS
    use constant PCI_FE_ADDR_DATA           =>  "PCI_FE_ADDR_DATA";
    use constant PCI_BE_ADDR_DATA           =>  "PCI_BE_ADDR_DATA";
    use constant PCI_CCB_ADDR_DATA          =>  "PCI_CCB_ADDR_DATA";
    use constant PCI_RESET_HOST_SLOT1       =>  "PCI_RESET_HOST_SLOT1";  
    use constant PCI_RESET_STORAGE_SLOT2    =>  "PCI_RESET_STORAGE_SLOT2";  
 
    # ZION - NMI
    use constant NMI_FE             =>  "NMI_FE";

    # Reset Processor
    use constant RESET_FE_PROC      =>  "RESET_FE_PROC";  
    use constant RESET_BE_PROC      =>  "RESET_BE_PROC";   
    use constant RESET_CCB_PROC     =>  "RESET_CCB_PROC";  


    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;

#BEGIN {
#        my $OS_win = ($^O eq "MSWin32") ? 1 : 0;
#        my $Perl_Ver = ($] gt "5.006001") ? 1 : 0;
#
#        print "Perl version: $]\n";
#        print "OS   version: $^O\n";
#
#        # This must be in a BEGIN in order for the 'use' to be conditional
#        if ($OS_win) {
#            print "Loading 5.6 API module\n";
#            eval "use Perl56::Win32::API 0.01";
#        die "$@\n" if ($@);
#
#        }
#        else {
#            print "Loading 5.8 API module\n";
#            eval "use Perl58::Win32::API 0.01";
#       die "$@\n" if ($@);
#        }
#
#        # This must be in a BEGIN in order for the 'use' to be conditional
#        if ($OS_win) {
##            print "Loading Windows module\n";
#            eval "use Win32::SerialPort";
#        die "$@\n" if ($@);
#
#        }
#        else {
##            print "Loading Unix module\n";
##            eval "use Device::SerialPort";
##       die "$@\n" if ($@);
#        }
#} # End BEGIN



########################################################################
### Function name: InjectErrorEntry
###
### Purpose: Print out the sense data returned from a SCSI command
##
## INPUT:    Error Type to Inject, Set/Reset/Pulse (1/0/2), Com Port to use
## OUTPUT:   Return of GOOD or ERROR
##
#######################################################################

sub InjectErrorEntry
{
    trace();                        # This allows function tracability

    my ($faultType, $portName) = @_;

    my $returnValue = GOOD;

    #
    # Defined error injection controls, the key is the key
    #
    my %injectControls = (
                        # Power Supply
                        PS_FAN_STATUS           =>  I2C_SET,
                        PS_AC_FAIL              =>  I2C_SET,
                        PS_DC_FAIL              =>  I2C_SET,
                        PS_REMOVED              =>  I2C_SET,

                        # DC Power Status
                        PS_12_VOLT              =>  I2C_SET,
                        PS_5_VOLT               =>  I2C_SET,
                        PS_BE_3_VOLT            =>  I2C_SET,
                        PS_R74                  =>  I2C_SET,

                        # I2C
                        I2C_ENVIORNMENTALS      =>  I2C_SET,
                        I2C_FE_TEMP_SENSOR      =>  I2C_SET,
                        I2C_SUICIDE_RESET       =>  I2C_SET,
                        I2C_POWER_SUPPLY        =>  I2C_SET,
 
                        # Zion Local Bus-SDRAM
                        SDRAM_FE_ADDRESS        =>  I2C_PULSE,
                        SDRAM_FE_DATA           =>  I2C_PULSE,
                        SDRAM_BE_ADDRESS        =>  I2C_PULSE,
                        SDRAM_BE_DATA           =>  I2C_PULSE,
 
                        # SLV8 Bus-FLASH, NVSRAM
                        NVSRAM_FE_ADDR_DATA     =>  I2C_PULSE,
                        NVSRAM_BE_ADDR_DATA     =>  I2C_PULSE,
 
                        # PCI BUS
                        PCI_FE_ADDR_DATA        =>  I2C_PULSE,
                        PCI_BE_ADDR_DATA        =>  I2C_PULSE,
                        PCI_CCB_ADDR_DATA       =>  I2C_PULSE,
                        PCI_RESET_HOST_SLOT1    =>  I2C_SET,
                        PCI_RESET_STORAGE_SLOT2 =>  I2C_SET,
 
                        # ZION - NMI
                        NMI_FE                  =>  I2C_PULSE,
                        
                        # Reset Processor
                        RESET_FE_PROC           =>  I2C_SET,
                        RESET_BE_PROC           =>  I2C_SET,
                        RESET_CCB_PROC          =>  I2C_SET,
                        );
    
    $returnValue = I2CInject($faultType, $injectControls{$faultType}, $portName);
    
    return $returnValue;
}

########################################################################
### Function name: I2CPort
###
### Purpose: Print out the sense data returned from a SCSI command
##
## INPUT:    Error Type to Inject, Set/Reset/Pulse (1/0/2), Com Port to use
## OUTPUT:   Return of GOOD or ERROR
##
#######################################################################

sub I2CInject
{
    trace();                        # This allows function tracability

    my ($faultType, $control, $portName) = @_;

    #
    # Defined error injection types, the key is the key
    #

    my %hardwareFaults = (
                        # Power Supply
                        PS_FAN_STATUS         =>  0b0010010,
                        PS_AC_FAIL            =>  0b0010001,
                        PS_DC_FAIL            =>  0b0010000,
                        PS_REMOVED            =>  0b0000011,

                        # DC Power Status
                        PS_12_VOLT            =>  0b0011001,
                        PS_5_VOLT             =>  0b0011010,
                        PS_BE_3_VOLT          =>  0b0011000,
                        PS_R74                =>  0b0011100,

                        # I2C
                        I2C_ENVIORNMENTALS    =>  0b0001111,
                        I2C_FE_TEMP_SENSOR    =>  0b0000010,
                        I2C_SUICIDE_RESET     =>  0b0000001,
                        I2C_POWER_SUPPLY      =>  0b0000000,
 
                        # Zion Local Bus-SDRAM
                        SDRAM_FE_ADDRESS      =>  0b0000100,
                        SDRAM_FE_DATA         =>  0b0000101,
                        SDRAM_BE_ADDRESS      =>  0b0010011,
                        SDRAM_BE_DATA         =>  0b0010100,
 
                        # SLV8 Bus-FLASH, NVSRAM
                        NVSRAM_FE_ADDR_DATA   =>  0b0000110,
                        NVSRAM_BE_ADDR_DATA   =>  0b0010101,
 
                        # PCI BUS
                        PCI_FE_ADDR_DATA        =>  0b0010110,
                        PCI_BE_ADDR_DATA        =>  0b0000111,
                        PCI_CCB_ADDR_DATA       =>  0b0010111,
                        PCI_RESET_HOST_SLOT1    =>  0b0001011,
                        PCI_RESET_STORAGE_SLOT2 =>  0b0001100,
 
                        # ZION - NMI
                        NMI_FE                =>  0b0001000,

                        # Reset Processor
                        RESET_FE_PROC         =>  0b0001001,
                        RESET_BE_PROC         =>  0b0001010,
                        RESET_CCB_PROC        =>  0b0001101,
                        );
    

    my $quiet = 0;
    my $portObj;
    my $I2C_Output;
    my $I2C_Output_Set;
    my $I2C_Output_Reset;

    my @keys;
    my $indexKey;

    # Generate the I2C output string, Default for a reset
    $I2C_Output = sprintf "%02X", $hardwareFaults {$faultType};

    # Set up the Control of the fault
    if ($control == I2C_SET)
    {
        # Add the Set bit to the Fault Byte
        $I2C_Output_Set = $hardwareFaults {$faultType} | 0b10000000;
        # Format for the ASCII output
        $I2C_Output = sprintf "%02X", $I2C_Output_Set;
    }
    elsif ($control == I2C_PULSE)
    {
        # Add the Set bit to the Fault Byte
        $I2C_Output_Set = $hardwareFaults {$faultType} | 0b10000000;
        # Format for the ASCII output
        $I2C_Output_Set = sprintf "%02X", $I2C_Output_Set;
        $I2C_Output_Reset = sprintf "%02X", $hardwareFaults {$faultType};
        # Concatenate the Set / Reset to create a pulse
        $I2C_Output = $I2C_Output_Set . "~" . $I2C_Output_Reset;
    }

    # Set up the Serial Port
    $portObj = new Win32::SerialPort ($portName, $quiet)
         || TestLibs::Logging::logWarning ("Can't open $portName: $^E");    # $quiet is optional

    $portObj->user_msg(1);
    $portObj->error_msg(1);
    $portObj->databits(8);
    $portObj->baudrate(19200);
    $portObj->parity("none");
    $portObj->stopbits(1);
    $portObj->buffers(4096, 4096);

    $portObj->read_interval(100);    # max time between read char (milliseconds)
    $portObj->read_char_time(5);     # avg time between read char
    $portObj->read_const_time(100);  # total = (avg * bytes) + const 
    $portObj->write_char_time(5);
    $portObj->write_const_time(100);


    $portObj->write_settings || undef $portObj;

    # See if the setting update was successful
    if (!$portObj)
    {
        TestLibs::Logging::logWarning ("Could not write serial port settings");
        return ERROR;
    }

    # Turn Echo Prompt Off
    SendOutput($portObj, "/E0\r\n");
    ReadInput($portObj);

    # Open the I2C Connection
    SendOutput($portObj, "/O\r\n");
    ReadInput($portObj);

    # Set the Slave I2C Address to 0x70
    SendOutput($portObj, "/D70\r\n");
    ReadInput($portObj);

    # Send the Given Injection Code to the Slave    
    SendOutput($portObj, "/T~$I2C_Output\r\n");
    ReadInput($portObj);

    # Close the I2C Connection
    SendOutput($portObj, "/C\r\n");
    ReadInput($portObj);

    SendOutput($portObj, "//\r\n");
    ReadInput($portObj);


    # Destruct
    $portObj->close || die "failed to close";
    undef $portObj;

    return GOOD;

    #
    # Subroutine to send charecters out the serial port
    #
    sub SendOutput
    {
        my ($portObj, $output_string) = @_;

        TestLibs::Logging::logInfo ("Send I2C:$output_string");
 
        my $count_out = $portObj->write($output_string);
        warn "write failed\n"         unless ($count_out);
        warn "write incomplete\n"     if ( $count_out != length($output_string) );
    }
    
    #
    # Subroutine to read charecters in from the serial port
    #
    sub ReadInput
    {
        my ($portObj) = @_;

        my $gotit = "";
        my $match1 = "*";
        until ("" ne $gotit) 
        {
            $gotit = $portObj->lookfor;       # poll until data ready
            TestLibs::Logging::logWarning ("Aborted without match") unless (defined $gotit);
            last if ($gotit);
            $match1 = $portObj->matchclear;   # match is first thing received
            last if ($match1);
            sleep 1;                          # polling sample time
        }

        my ($match, $after, $pattern, $instead) = $portObj->lastlook;
          # input that MATCHED, input AFTER the match, PATTERN that matched
          # input received INSTEAD when timeout without match

        TestLibs::Logging::logInfo ("Receive I2C:$after");

        $portObj->lookclear;                  # empty buffers

    }

}

#######################################################################

1;

__END__

=head1 CHANGELOG

 $Log$
 Revision 1.1  2005/05/04 18:53:52  RysavyR
 Initial revision

 Revision 1.4  2003/05/29 12:56:44  WerningJ
 Rewrote all XTC data structures
 Reviewed by Craig M

 Revision 1.3  2003/03/27 17:36:18  WerningJ
 Removed calls XMC disconnect which are no longer required
 Reviewed by Olga

 Revision 1.2  2003/03/14 16:23:32  WerningJ
 Added new Error Injections
 Reviewed by Craig M

 Revision 1.1  2003/01/29 16:36:51  WerningJ
 New Library for Hardware Error Injection
 Reviewed by Craig M


=cut

