#! /usr/bin/perl s
# $Header$
##############################################################################
# File name:  TestLibs::Validate
#
# Desc: A set of library functions for integration testing. These focus on
#       validation of controller state and configuration.
#
# Date: 07/31/2002
#
# Original Author:  Craig Menning
#
# Last modified by  $Author: m4 $
# Modified date     $Date: 2007-06-29 10:05:08 -0500 (Fri, 29 Jun 2007) $
#
#   It is expected that the user will write a perl script that calls 
#   these  function.
#
#   Copyright 2002-2006 Xiotech Corporation. All rights reserved.
#
#   For Xiotech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::Validate - Perl support for validating bigfoot controller state

$Id: Validate.pm 26510 2007-06-29 15:05:08Z m4 $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

This document describes usage of the Perl Scripts to Test Controllers

=head1 DESCRIPTION

Test Scripts Available
    TBD

=cut

#                         
# - what I am
#

package TestLibs::Validate;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use Time::localtime;
use Math::BigInt;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::cmVCG;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::IntegCCBELib;
use TestLibs::BEUtils;

#use TestLibs::IntegXMCLib;
#use XIOtech::sanscript;
use TestLibs::utility;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                      &ActiveServerList
                      &ActiveVdiskList
                      &AnyMirrorsPresent
                      
                      &BLValidate

                      &CcbeControllerCheck
                      &CheckBEHashes
                      &CheckPdiskState
                      &CheckRaidState
                      &CheckServerState
                      &CheckVCGState
                      &CheckVdiskState

                      &CompareLists
                      &CompareLists2
                      &CompareTargetMap
                      &ControllerActiveVdiskList
                      &ControllerActiveVdiskListPart1
                      &ControllerActiveVdiskListPart2
                      &CreateTargetMap
                        
                      &FailOverTimeLine
                      &FailOverTimeLineNway
                      &FENodes
                      &FEPortMatrix

                      &GetBEStateHash
                      &GetServerActivityCounts
                      &GetServerIO
                      &GetPdiskStateArray
                      &GetRaidStateArray
                      &GetVdiskStateArray
                      &GetVdiskActivityCounts
                      &GroupTargetMap

                      &IsThisControllerGood
                      &IsVdiskMirrorDest

                      &MakeActiveServerMap
                      &MakeActiveVdiskMap
                      &MirrorCheck
                      &MirrorInitialData
                      &MirrorPartnerCheck
                      &MirrorResyncWait
                        
                      &PeriodicDataGather
                      &PrintTargetMap
                      &PScanReqdWait

                      &TargetMapCheck
                      &TargetMapDelta
                      &TestBEState
                      &TestEndMirrorCheck
                      &TestForServerIO
                      &TestPrep4MirrorCheck
                      &TestSystemState
                      &TestSystemState1
                      &TestSystemState2
                      &TestSystemState3
                      
                      &VerifyIOGather

                      &Wait4MinPowerUpState
                      &Wait4PowerUpState
                      &Wait4NoWaitPowerUpState

                      &XssaControllerCheck

                      );

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 26510 $);
}
    our @EXPORT_OK;



##############################################################################
#
#          Name: IsVCGFailed
#
#        Inputs: controller object list, index to list
#
#       Outputs: GOOD, if controller IS failed, ERROR if not failed,
#                INVALID on error
#
#  Globals Used: none
#
#   Description: A function to determine of a specific controller is failed.
#                All members of the vcg may be checked.
#
##############################################################################


##############################################################################
#
#          Name: CheckAtStart
#
#        Inputs: Pointer to controller object list,
#                Index to Master,
#                Pointer to Serial Number Array,
#                Pointer to starting Target Map Array (Updated),
#                Pointer to Active Server Array (Updated),
#                Pointer to Initail VDisk Array (Updated),
#                Pointer to 
#
#
#       Outputs: GOOD, if controller IS failed, ERROR if not failed,
#                INVALID on error
#
#  Globals Used: none
#
#   Description: A function to determine of a specific controller is failed.
#                All members of the vcg may be checked.
#
##############################################################################

sub CheckAtStart
{
    my ($coPtr, $masterIndex, $serialNumsPtr, $startingTmapPtr, $activeServersPtr,
        $initialVdisksPtr, $pdiskDataPtr, $vdiskDataPtr, $raidDataPtr) = @_;
                                              
    my %info1;
    my @_vCounts;
    my @_sCounts;
    my @coList = @$coPtr;
    my $ret;
                    
    #
    # check to see that everything is good at the start
    #

    logInfo("Check to see if everything is functioning at the start of the test");
    $ret = TestBEState($coPtr);

    if ( $ret != GOOD )
    {
        logInfo("    ====> Test of the BE state failed <====");
        return ERROR;
    }

    #
    # find the currently active servers
    #
    
    logInfo("Getting initial data for activity measurements.");

    @_vCounts = GetVdiskActivityCounts($coPtr);
    @_sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);


    #
    # get the initial/starting target map
    #

    logInfo("Getting the target status, then building the target map");




    $ret = GroupTargetMap($coPtr, $serialNumsPtr, $startingTmapPtr, $masterIndex,  LOGTARGETMAP);
    if ( $ret != GOOD )  {return ERROR; }

    #

    #


    logInfo("Generating Activity Information");

    @$activeServersPtr = MakeActiveServerMap( $coPtr,  \@_sCounts, 10 );
    @$initialVdisksPtr = MakeActiveVdiskMap( $coPtr,  \@_vCounts, 10 );

    if ( scalar(@$initialVdisksPtr) != 0 )
    {
        # we have some active vdisks
        if ( $initialVdisksPtr->[0] == INVALID )
        {
            # error case 
            logInfo("    ====> Warning - can't get an initial active vdisklist <====");

        }
    }
    
    #
    # get initial BE data used for validation
    #

    @$pdiskDataPtr = GetPdiskStateArray($coList[$masterIndex]);
    @$vdiskDataPtr = GetVdiskStateArray($coList[$masterIndex]);
    @$raidDataPtr  = GetRaidStateArray($coList[$masterIndex]);

    return GOOD;
}

##############################################################################
#
#          Name: CreateTargetMap
#
#        Inputs: targetstatus hash
#
#       Outputs: Array representing the target mapping,
#                INVALID as first member on error
#
#  Globals Used: none
#
#   Description: This function takes the hash that is the CCBCL's
#                TARGETSTATUS data and extracts the server/target mapping
#                information. (If this works) The data will be an array
#                of numbers. Each array element represents one of the 
#                physical targets (QLogic card slots) in the vcg. The value
#                is a bitmap of which logical targets are presently mapped 
#                to the card
#
##############################################################################
sub CreateTargetMap
{
    my ($snPtr, %info ) = @_;

    my $targetCount;
    my @targets;
    my $i;
    my $j;
    my $k;
    my $msg;
    my $linecount;
    my @serialNums;

    my $owner;
    my $chan;
    my $tid;
    my $index;
    my $bit;

    my @map;

    my $targPtr = $info{TARGETS};
    
    @targets = @$targPtr;

    #print "serial number pointer $snPtr \n";


    @serialNums = @$snPtr;

    $targetCount = scalar(@targets);

    for ( $i = 0; $i < $targetCount; $i++ )
    {
        $map[$i] = 0;        # clear the map
    }        
    


    for ( $i = 0; $i < $targetCount; $i++ )
    {
            
        # get te basic info
        $tid = $targets[$i]{TGD_TID}; 
        $chan = $targets[$i]{TGD_CHAN}; 
        $owner = $targets[$i]{TGD_OWNER};

        # map chan and owner to index

        for ( $j = 0; $j < scalar(@serialNums); $j++ )
        {
            $index = $j;
            if ( $owner == $serialNums[$j] ) 
            {
                # we are done if there is a match
                last;
            }
        }

        # finish the index
        $index = ( $index * 4 ) + $chan;

        $bit = 1 << $index;

        # update map

        $map[$tid] |= $bit;
    }


    return @map;

}
##############################################################################
#
#          Name: GroupTargetMap
#
#        Inputs: pointer to list of controller objects
#                pointer to list of serial numbers
#                pointer to output target map
#                index of the master
#                options flag
#
#       Outputs: Array representing the target mapping,
#                INVALID as first member on error
#
#  Globals Used: none
#
#   Description: The function gets the targetstatus data from all alive
#                controllers in the vcg and generates a target map. Based 
#                upon the options flags the target status data will be
#                logged for the controllers (LOGTARGETSTATUS) and/or the
#                resulting target map can be printed (LOGTARGETMAP).
#
#                Steps:
#                  - Get target status from the master
#                  - print if requested
#                  - Identify controllers that are not represented
#                    (these are the other active controllers that have
#                     targets on them)
#                  - Get target status from the others
#                    - print if requested
#                    - collate with data from the master
#                  - Finish assembling the map
#                  - print map if requested
#                  - return status
#
#  Sample Call:
#    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETSTATUS + LOGTARGETMAP);
#    if ( $ret != GOOD )  {return ERROR; }
#
##############################################################################
sub GroupTargetMap
{
    my ($coPtr, $snPtr, $tmPtr, $master, $options ) = @_;


    my @coList;
    my @snList;
    my @tMap;
    my $i;
    my $j;
    my $k;
    my %info;
    my @missingList;
    my $missingCount;
    my $targPtr;
    my $targetCount;
    my $tid;
    my $chan; 
    my $owner;
    my $index;
    my @targets;
    my $bit;

    # turn array pointers into lists we can reference
    
    @coList = @$coPtr;

    @snList = @$snPtr;
    

    # - Get target status from the master

    %info = TestLibs::IntegCCBELib::GetTargetStatus($coList[$master]);

    if ( ! %info  )              # if no data from call
    {
        logInfo("    ====> Failed to get a response from GetTargetStatus <====");
        return ERROR;
    }

    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo("    ====> Error from GetTargetStatus <====");
        PrintError(%info);
        return ERROR;
    }

    # - print if requested
    if ( $options & LOGTARGETSTATUS )
    {
        LogTargetStatus( %info);
    }

    # validate the output pointer (We do this here so at least we may 
    # get the master's targetstatus logged.)

    unless ($tmPtr)
    {
        # no pointer to the target map, not allowed
        logInfo("    ====> Missing pointer to the target map. <====");
        return ERROR;
    }

    # Start building the target map
    
    @tMap = @$tmPtr;

    $targPtr = $info{TARGETS};
    
    @targets = @$targPtr;
        
    $targetCount = scalar(@targets);

    for ( $i = 0; $i < $targetCount; $i++ )
    {
        $$tmPtr[$i] = 0;        # clear the map
    }        


    # - Identify controllers that are not represented, filling in 
    #   the target map as we go 
    #   (these are the other active controllers that have
    #    targets on them)

    for ( $i = 0; $i < $targetCount; $i++ )
    {
            
        # get te basic info
        $tid = $targets[$i]{TGD_TID}; 
        $chan = $targets[$i]{TGD_CHAN}; 
        $owner = $targets[$i]{TGD_OWNER};

#print ( "t,c,o: $tid, $chan, $owner \n");

        # map chan and owner to index

        for ( $j = 0; $j < scalar(@snList); $j++ )
        {
            $index = $j;
            if ( $owner == $snList[$j] ) 
            {
                # we are done if there is a match
                last;
            }
        }

        if ( $chan < 4 )
        {
            # chan number is legal, put the info in the map
        
            # finish the index
            $index = ( $index * 4 ) + $chan;

            $bit = 1 << $index;

            # update map

            $$tmPtr[$tid] |= $bit;
        }
        else
        {
            # chan number was not legal, this represents a missing 
            # set of info, add controller sn to list, note: we are
            # going to have duplicate entries
            push (@missingList, $owner);
            $missingCount++;
        }

    }

    # now clean up the list of other controllers
    @missingList = SortAndRemoveDups(@missingList);

#print ("missinglist @missingList \n");

    # - Get target status from the others

    for ( $i = 0; $i < scalar(@missingList); $i++ )
    {
        # now look thru the snList to get the offset to the 
        # controller 
        for ($j = 0; $j <scalar(@snList); $j++ )
        {
            if ( $snList[$j] == $missingList[$i] )
            {
                # matching SN, j is the index to the object list
                # nothing more to do in this list
                last;
            }    
        }

        if  ( $master == $j )
        {
            # we already did the master, so we can skip it this time around
            next;
        }


        # make sure we got a real one
        if ( $j >= scalar(@snList) )
        {
            # rolled past the end of the list, bad news
            logInfo("Serial number not in the list, can't get target status");
            logInfo("  Serial number to match: $missingList[$i]");
            logInfo("  Supplied list: @snList ");
            next; 
            return ERROR;

        }


        # got the object index, now we can go get targetstatus

        %info = GetTargetStatus($coList[$j]);

        if ( ! %info  )              # if no data from call
        {
            logInfo("    ====> Failed to get a response from GetTargetStatus (nonfatal) <====");
            # we may be attempting to work on a dead controller, 
            # since this may be the case, ignore the failure
            #return ERROR;
            next;
        }

        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo("    ====> Error from GetTargetStatus  (nonfatal) <====");
            PrintError(%info);
            # we may be attempting to work on a dead controller, 
            # since this may be the case, ignore the failure
            #return ERROR;
            next;
        }

        # - print if requested
        if ( $options & LOGTARGETSTATUS )
        {
            LogTargetStatus( %info);
            
        }


        # - collate with data from the master



        $targPtr = $info{TARGETS};
    
        @targets = @$targPtr;
        
        $targetCount = scalar(@targets);


        # - Identify controllers that are not represented, filling in 
        #   the target map as we go 
        #   (these are the other active controllers that have
        #    targets on them)

        for ( $k = 0; $k < $targetCount; $k++ )
        {
        
            # get te basic info
            $tid = $targets[$k]{TGD_TID}; 
            $chan = $targets[$k]{TGD_CHAN}; 
            $owner = $targets[$k]{TGD_OWNER};

#print ( "T,C,O: $tid, $chan, $owner \n");

            # map chan and owner to index

            for ( $j = 0; $j < scalar(@snList); $j++ )
            {
                $index = $j;
                if ( $owner == $snList[$j] ) 
                {
                    # we are done if there is a match
                    last;
                }
            }

            if ( $chan < 4 )
            {
                # chan number is legal, put the info in the map
    
                # finish the index
                $index = ( $index * 4 ) + $chan;

                $bit = 1 << $index;

                # update map

                $$tmPtr[$tid] |= $bit;
            }

        }

        # - Finish assembling the map (done, see above code)
    }
    
    # - print map if requested

    if ( $options & LOGTARGETMAP )
    {
        PrintTargetMap ($tmPtr);    
    }

    # - return status

    return GOOD;



}



##############################################################################
#
#          Name: PrintTargetMap
#
#        Inputs: one target map
#
#       Outputs: GOOD
#
#  Globals Used: none
#
#   Description: A simple print of the target array
#
##############################################################################
sub PrintTargetMap
{
    my ($m1Ptr) = @_;

    my @map;
    my $i;
    my $j;

    @map = @$m1Ptr;
    my $str;
    logInfo ("");

    for ( $i = 0; $i < scalar(@map); $i++ )
    {
        $str = " ";
        for ($j = 0; $j <32; $j++)
        {
            # build binary representation
            if ( $map[$i] & (1 << $j) )
            {
                $str = "1" . $str;
            }
            else
            {
                $str = "0" . $str;
            }
        }
        
        logInfo(sprintf ("%3d:  %16s  ", $i, $str));
    }        
    
    logInfo ("");
    
    return GOOD;

}

##############################################################################
#
#          Name: CompareTargetMap
#
#        Inputs: one target map, another target map
#
#       Outputs: GOOD, if the maps match, ERROR if they are different,
#                INVALID on error
#
#  Globals Used: none
#
#   Description: Two of the arrays are compared to see if they are the
#                same or different.
#
##############################################################################
sub CompareTargetMap
{
    my ($m1Ptr, $m2Ptr) = @_;

    my @map1;
    my @map2;

    my $num;
    my $i;

    @map1 = @$m1Ptr;
    @map2 = @$m2Ptr;

    # only based upon the smaller array
    $num = min(scalar(@map1), scalar(@map2));
    
    # for each item
    for ($i = 0;$i < $num; $i++ )
    {
        
        # are they equal
        if ( $map1[$i] != $map2[$i] )
        {
            # an entry is different, we are done
            logInfo("    ====> The target maps did not match <====");
            return ERROR;
        }
    }

    # all were the same...
    logInfo("The target maps were the same.");
    return GOOD;

}

##############################################################################
#
#          Name: TargetMapCheck
#
#        Inputs: one target map pointer
#
#       Outputs: GOOD, if the mapis all 0s, ERROR if not
#                INVALID on error
#
#  Globals Used: none
#
#   Description: Check if all array members are 0.
#
##############################################################################
sub TargetMapCheck
{
    my ($m1Ptr) = @_;

    my @map1;
    my $num;
    my $i;

    @map1 = @$m1Ptr;

    # only based upon the array size    $num = (@map1);
    $num = scalar(@map1);
    
    # for each item
    for ($i = 0;$i < $num; $i++ )
    {
        # are they equal
        if ( $map1[$i] != 0 )
        {
            # an entry is non-zero, we are done
            return ERROR;
        }
    }

    # all were the zero...
    return GOOD;

}





##############################################################################
#
#          Name: TargetMapDelta
#
#        Inputs: one target map, another target map
#
#       Outputs: difference map,
#                INVALID as first element on error
#
#  Globals Used: none
#
#   Description: This function XORs the two input maps at a bit level> The 
#                resulting array is returned. This can be used to identify 
#                what part of the configuration is wrong.
#
##############################################################################
sub TargetMapDelta
{
    my ($m1Ptr, $m2Ptr) = @_;

    my @map1;
    my @map2;
    my @map3;
    my $num;
    my $i;
    my $j;

    @map1 = @$m1Ptr;
    @map2 = @$m2Ptr;

    # only based upon the smaller array
    $num = TestLibs::utility::min(scalar(@map1), scalar(@map2));
    
    if ( $num < 1 )
    {
        push (@map3, INVALID );
        return @map3;
    }

    # for each item
    for ($i = 0;$i < $num; $i++ )
    {

        $j = $map1[$i] ^ $map2[$i];
        push (@map3, $j);    


    }

    # done.
    return @map3;

}




##############################################################################
#
#          Name: VCGFailedCheck
#
#        Inputs: controller object list
#
#       Outputs: GOOD is all controllers are operational
#                ERROR if one or more are failed
#                INVALID if data cannot be obtained from tbe master controller
#
#  Globals Used: none
#
#   Description: This function uses VCGINFO to determine if all controllers
#                are operational. Only the data from the master controller is
#                used. The function will determine which controller is the 
#                master. THe caller just provides a lost of controllers
#
##############################################################################
sub VCGFailedCheck
{
    return GOOD;
}



##############################################################################
#
#          Name: VCGFailMap
#
#        Inputs: controller object list
#
#       Outputs: an array of controller states
#                INVALID as first element on error
#
#  Globals Used: none
#
#   Description: This function uses VCGINFO to determine which controllers
#                are operational or not. An array of state values, one for 
#                each controller in the group is returned.
#
##############################################################################
sub VCGFailMap
{
    return GOOD;
}


##############################################################################
#
#          Name: IsThisControllerGood
#
#        Inputs: controller object list, index to controller
#
#       Outputs: CCBE Based Function
#                GOOD if the controller is Good
#                ERROR if in a different condition
#                INVALID  on error
#
#  Globals Used: none
#
#   Description: This function uses VCGINFO to determine is the specific
#                controller is Good or not.
#
##############################################################################
sub IsThisControllerGood
{
    my($Pointer, $poss) = @_;
    my @Obj = @$Pointer;
    my $Flag = ERROR;
        
    if ( ! $Obj[$poss] )
    {
        logInfo("    ====> User Error: Wrong Array Position <====");
        return INVALID;
    }

    my $IP = $Obj[$poss]->{HOST};

    my $MasterPoss = TestLibs::IntegCCBELib::FindMaster($Pointer);

    if ( $MasterPoss == INVALID )
    {
        logInfo("    ====> Failed to find the new master controller <====");
        return INVALID;
    }

    my %rsp = $Obj[$MasterPoss]->XIOTech::cmdMgr::vcgInfo(0);
    
    if ( ! %rsp )              # if no return from call
    {
        logInfo("    ====> Failed to get response from vcgInfo <====");
        return INVALID;
    }

    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo("    ====> Error from vcgInfo <====");
        TestLibs::IntegCCBELib::PrintError(%rsp);
        return ERROR;
    }

    logVCGInfo(%rsp);        # display VCGinfo
    
    for (my $i = 0; $i < $rsp{VCG_MAX_NUM_CONTROLLERS}; ++$i)
    {
        if($rsp{CONTROLLERS}[$i]{IP_ADDRESS} eq $IP)
        {
            my $failureState = "OPERATIONAL";
            
            if ($rsp{CONTROLLERS}[$i]{FAILURE_STATE} != FD_STATE_OPERATIONAL)
            {
                logInfo("    ====> Controller $IP is not operational <====");
                $failureState = "NOT OPERATIONAL";
                $Flag = ERROR;
            }
            else
            {
                $Flag = GOOD;
            }
            logInfo("Controller IP: $rsp{CONTROLLERS}[$i]{IP_ADDRESS} -> $failureState");
            return $Flag;
        }
    }

    logInfo("    ====> Controller $IP not found in VCGinfo <====");
    return ERROR;   
    
}

 
##############################################################################
#
#          Name: CcbeControllerCheck
#
#        Inputs: Reference to an array of objects
#
#       Outputs: GOOD - All controller are operational 
#               ERROR - One of the Controllers is not operational or 
#               INVALID -One of the Controllers is in unknown state  
#
#  Globals Used: none
#
#   Description: Retrieves which one of the controllers is the Master, Gets VCG info 
#                from the master controller, checks if all controllers in VCG are 
#                operational  
#
##############################################################################

sub CcbeControllerCheck
{
    my ($Obj) = @_;
    my @Obj = @$Obj;
    my $Flag = GOOD;
    my $MasterPoss = TestLibs::IntegCCBELib::FindMaster($Obj);
    
    if ( $MasterPoss == INVALID )
    {
        logError("    ====> Failed to find the new master controller <====");
        return INVALID;
    }

    my %rsp = $Obj[$MasterPoss]->XIOTech::cmdMgr::vcgInfo(0);
    
    if ( ! %rsp )              # if no return from call
    {
        logInfo("    ====> Failed to get response from vcgInfo <====");
        return INVALID;
    }

    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo("    ====> Error from vcgInfo <====");
        TestLibs::IntegCCBELib::PrintError(%rsp);
        return INVALID;
    }
 
    for (my $i = 0; $i < $rsp{VCG_MAX_NUM_CONTROLLERS}; ++$i)
    {
        if ($rsp{CONTROLLERS}[$i]{SERIAL_NUMBER} == 0)
        {
            next;
        }

        my $failureState = "";
        if ($rsp{CONTROLLERS}[$i]{FAILURE_STATE} == FD_STATE_FAILED)
        {
            $failureState = "FAILED";
            $Flag = ERROR;
        }
        elsif ($rsp{CONTROLLERS}[$i]{FAILURE_STATE} == FD_STATE_OPERATIONAL)
        {
            $failureState = "OPERATIONAL";
        }
        elsif ($rsp{CONTROLLERS}[$i]{FAILURE_STATE} == FD_STATE_POR)
        {
            $failureState = "POWER ON READY";
            $Flag = ERROR;
        }
         elsif ($rsp{CONTROLLERS}[$i]{FAILURE_STATE} == FD_STATE_ADD_CONTROLLER_TO_VCG)
         {
             $failureState = "ADDING CTRL TO VCG";
             $Flag = ERROR;
         }
         elsif ($rsp{CONTROLLERS}[$i]{FAILURE_STATE} == FD_STATE_STRANDED_CACHE_DATA)
         {
             $failureState = "STRANDED CACHE DATA";
             $Flag = ERROR;
         }
         elsif ($rsp{CONTROLLERS}[$i]{FAILURE_STATE} == FD_STATE_FIRMWARE_UPDATE_INACTIVE)
         {
             $failureState = "FIRMWARE UPDATE INACTIVE";
             $Flag = ERROR;
         }
         elsif ($rsp{CONTROLLERS}[$i]{FAILURE_STATE} == FD_STATE_FIRMWARE_UPDATE_ACTIVE)
         {
             $failureState = "FIRMWARE UPDATE ACTIVE";
             $Flag = ERROR;
         }
         elsif ($rsp{CONTROLLERS}[$i]{FAILURE_STATE} == FD_STATE_UNFAIL_CONTROLLER)
         {
             $failureState = "UNFAIL CONTROLLER";
             $Flag = ERROR;
         }
         else
         {
             $failureState = "UNKNOWN";
             $Flag = INVALID; 
         }

        logInfo("Controller IP: $rsp{CONTROLLERS}[$i]{IP_ADDRESS} -> $failureState");
    }
    
    return $Flag; 
}

##############################################################################
#
#          Name: XssaControllerCheck
#
#        Inputs: Reference to an array of objects
#
#       Outputs: GOOD - All Controllers are operational
#                ERROR - otherwise
#
#  Globals Used: none
#
#   Description: Gets VCG info 
#                from the master controller, checks if all controllers 
#                in VCG are operational  
#
##############################################################################

sub XssaControllerCheck
{
    my $Hash = controllerInfo();
    my @Hash = @$Hash;
    if(@Hash)
    {
        for(my $i = 0; $i < scalar(@Hash); $i++)
        {
            if(${$Hash[$i]}{CONTROLLER_STATE} ne "operational")
            {
                logInfo("IP Address: ${$Hash[$i]}{CONTROLLER_IP}");
                logInfo("State : ${$Hash[$i]}{CONTROLLER_STATE}");
                return ERROR;
            }
        }
    }
    else
    {
        logInfo("Can not Retrieve Controller Information");
        return INVALID;
    }
    return GOOD;    
}




##############################################################################
#
#          Name: ConfirmPowerUpState
#
#        Inputs: controller object, desired state
#
#       Outputs: GOOD if state matches, ERROR if different,
#                INVALID  on error
#
#  Globals Used: none
#
#   Description: This function gets the POWERUPSTATE from the controller 
#                and compares it to the desired value.
#
##############################################################################
sub ConfirmPowerUpState
{
    return GOOD;
}



#
# the following are supporting functions and will end up in the integration libraries
# they are shown here temporarily for documentation reasons. (for Tom)
#

##############################################################################
#
#          Name: GetTargetsData
#
#        Inputs: controller object
#
#       Outputs: Hash with the data
#                INVALID  on error
#
#  Globals Used: none
#
#   Description: This function gets the TARGETSTATUS information from the
#                controller. The data is returned in a hash that matches that
#                used internally in the the CCBCL.
#
##############################################################################
sub GetTargetsDataMap
{
    my($ctlr, $snPtr) = @_;
    
    my $targetCount;
    my %info;
    my $rc;
    my $i;
    my $j;
    my $owner;
    my $chan;
    my $tid;
    my $index;
    my $bit;
    my @map;
    my @map2;
    my @serialNums;
    
    @serialNums = @$snPtr;
    
    for ( $i = 0; $i < 4; $i++ )
    {
        $map2[$i] = 0;                   # clear the dummy map
    }        

    
    %info = $ctlr->targets();            # get the target data
    
    if ( ! %info  )                      # if no return from call
    {
        logInfo("    ====> Failed to get response from targets <====");
        return @map2;
    }

    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo("    ====> Error from targets <====");
        PrintError(%info);
        return @map2;
    }
    
    
    $targetCount = $info{COUNT};

    for ( $i = 0; $i < 4; $i++ )
    {
        $map[$i] = 0;                    # clear the real map
    }        
    for (my $i = 0; $i < $targetCount; $i++)
    {
        # get te basic info
        $tid   = $info{TARGETS}[$i]{TGD_TID}; 
        $chan  = $info{TARGETS}[$i]{TGD_CHAN};    # aka PORT
        $owner = $info{TARGETS}[$i]{TGD_OWNER};

        # map chan and owner to index

        for ( $j = 0; $j < scalar(@serialNums); $j++ )
        {
            $index = $j;
            if ( $owner == $serialNums[$j] ) 
            {
                # we are done if there is a match
                last;
            }
        }

        if( $chan < 4 )
        {
            # only do the ones that are valid ( skip 25? ones )
            # finish the index
            $index = ( $index * 4 ) + $chan;

            $bit = 1 << $tid;

            # update map

            $map[$chan] |= $bit;
        }
    }

    return @map;

}
##############################################################################
#
#          Name: ActiveVdiskList
#
#        Inputs: controller object list
#
#       Outputs: list of active vdisks , list may be empty
#                INVALID  as 1st element on error
#
#  Globals Used: none
#
#   Description: This functions does a vdisk info on the controller to
#                determine is a significant amount of writes and reads are
#                seen. Two readings, taken a few seconds apart should show
#                a change in the number of read and write requests.
#
#                This function MUST get activity data from at least one
#                controller. It need not get data from ALL controllers.
#
##############################################################################
sub ActiveVdiskList
{
    my ($coPtr) = @_;
    trace();

    my $i;
    my $j;
    my %rsp;
    my %rsp2;
    my $activity;
    my $ctlr;
    my @activeList;
    my @shortList;
    my $shortSize;
    my @badList;
    my $numVdisks;
    my $master;

    my @coList;
    
    @coList = @$coPtr;

    push (@badList, INVALID);       # set up the error return array
    
              
    $master = TestLibs::IntegCCBELib::FindMaster($coPtr);

    if ($master == INVALID)
    {
        logInfo("    ====> Unable to determine master for active vdisk list <====");
        return @badList;
    }
        
    # first do the master
    $ctlr = $coList[$master];         # get object for master

    @activeList = ControllerActiveVdiskList($ctlr, 15, 5, "V");

    $shortSize = scalar(@activeList);

    if ( $shortSize > 0 )
    {
        if ( $activeList[0] == INVALID )
        {
            # we should get a list from the master, at least
            logInfo("    ====> Unable to get master's active vdisks <====");
            return @badList;
        }
    }

    # now we have an active list for the master, now add in the slaves

    for ( $i = 0; $i < scalar(@coList); $i++ )
    {
        # for each controller, but not the master
        if ( $i != $master )
        {
            $ctlr = $coList[$i];         # get object
             
            @shortList = ControllerActiveVdiskList($ctlr, 15, 5, "V");   # get list

            $shortSize = scalar(@shortList);    

            if ( $shortSize > 0 )     # if something is in the list
            {
                if ( $shortList[0] == INVALID )
                {
                    # we go no list from the slave, but that's OK
                }
                else
                {
                    # we got a list with stuff in it
                    for ( $j = 0; $j < scalar(@shortList); $j++ )
                    {
                        # add the new list to the old list
                        push(@activeList, $shortList[$j]);
                    }
                }
            }
        }
    }

    # we have the list from all the controllers, now let's sort it
    # but we may have duplicate entries. (same vdisk active on 2 contollers)
    # in that case we will remove the duplicates.


    @shortList = SortAndRemoveDups(@activeList);

    # some debug stuff for the functions called
#    my $ret = CompareLists (\@activeList, \@shortList);
#    print "list compare returned $ret \n";
#
#    $ret = CompareLists (\@activeList, \@activeList);
#    print "list compare returned $ret \n";
#
#    push (@activeList, 99);
#    $ret = CompareLists (\@activeList, \@shortList);
#    print "list compare returned $ret \n";
#
#    print "@activeList  \n";
#    push (@activeList, 99);
#    push (@activeList, 64);
#    print "unsorted:\n";
#    print "@activeList  \n";
#    @activeList = SortAndRemoveDups(@activeList);
#    print "sorted & unduped:\n";
#    print "@activeList  \n";
    


    # send list to caller
    return @shortList;
}
    

##############################################################################
#
#          Name: SortAndRemoveDups
#
#        Inputs: one list  
#
#       Outputs: the sorted list
#
#  Globals Used: none
#
#   Description: This function just sorts a list (list is assumed to have 
#                something in it).
#
#
##############################################################################
#sub SortAndRemoveDups
#{
#    my (@list) = @_;
#    
#    if (scalar(@list) < 2 )
#    {
#        # no need to sort a 0 length or single item list 
#        return @list;
#    }
#    
#    my @list2 = sort(@list);      # sort the list (the easy part)
#    
#    # now to remove any duplicates
#    
#    my @list3;    
#    my $i;
#
#    push (@list3, $list2[0]);  # let's start with the easy one
#    
#    # now do the rest of the list
#    for ( $i = 1; $i < scalar(@list2); $i++ )
#    {
#        if ( $list2[$i] != $list2[ ($i - 1) ] )
#        {
#            # add the different one to the new list
#            push (@list3, $list2[$i]);   
#        }
#    }
#
#    return @list3;
#}

##############################################################################
#
#          Name: CompareLists
#
#        Inputs: one list ptr, another list ptr 
#
#       Outputs: GOOD if lists match
#                ERROR if contents differ
#                INVALID  if different size
#
#  Globals Used: none
#
#   Description: This function just compares two lists. Lists must be sorted.
#
#
##############################################################################
sub CompareLists
{
    my( $lPtr1, $lPtr2) = @_;

    my $i;
    my @list1;
    my @list2;

    @list1 = @$lPtr1;
    @list2 = @$lPtr2;
        
 #print(" First List: @list1 \n");
 #print(" Other List: @list2 \n");

    if ( scalar(@list1) != scalar(@list2) )
    {
        logInfo("    ====> Error: the two lists had different lengths <====");
        logInfo(" First List: @list1 ");
        logInfo(" Other List: @list2 ");
        return INVALID;
    }

    for ( $i = 0; $i < scalar(@list1); $i++ )
    {
        if ( $list1[$i] != $list2[$i] )
        {


            logInfo("    ====> Error: list contents differ at offset $i <====");
            logInfo(" First List: @list1 ");
            logInfo(" Other List: @list2 ");
            return ERROR;
        }
    }

    logInfo("The lists are identical.");        # may get commented out....
    return GOOD;

}

##############################################################################
#
#          Name: CompareLists2
#
#        Inputs: list ptr(to test), reference list ptr 
#
#       Outputs: GOOD if lists match
#                ERROR if contents differ
#
#  Globals Used: none
#
#   Description: This function just compares two lists. All of the items in the
#                reference list must be in the test(1st) list. Extras in 
#                the first list will be ignored. List are assumed to be sorted.
#
#
##############################################################################
sub CompareLists2
{
    my( $lPtr1, $lPtr2) = @_;

    my $i;
    my $j;
    my @list1;
    my @list2;
    my $result1;


    @list1 = @$lPtr1;
    @list2 = @$lPtr2;
        
 #print(" First List: @list1 \n");
 #print(" Other List: @list2 \n");


    for ( $i = 0; $i < scalar(@list2); $i++ )
    {
        $result1 = ERROR;  # indicate no match
        
        for ( $j = 0; $j < scalar(@list1); $j++)
        {
            
            # note: this test used to be '==' but was changed to 'eq' for the 
            # brocade test. Hopefully, this still works for failover....

            if ( $list1[$j] eq $list2[$i] )
            {
                $result1 = GOOD;      # indicate match
            }
        }

        if ( $result1 == ERROR )
        {
            logInfo("    ====> Error: item at offset $i is missing from the test list <====");
            logInfo(" Test List: @list1 ");
            logInfo(" Ref. List: @list2 ");
            return ERROR;
        }
    }

    logInfo("All items were found in the test list.");        # may get commented out....
    return GOOD;

}

            
##############################################################################
#
#          Name: ControllerActiveVdiskList
#
#        Inputs: controller object 
#
#       Outputs: list of active vdisks, list may be empty
#                INVALID  as 1st element on error
#
#  Globals Used: none
#
#   Description: This functions does a vdisk info on the controller to
#                determine is a significant amount of writes and reads are
#                seen. Two readings, taken a few seconds apart should show
#                a change in the number of read and write requests.
#
#
##############################################################################
sub ControllerActiveVdiskList
{
    trace();
    my ($ctlr, $duration, $threshold, $noise) = @_;

    my %rsp;
    my $activity;
    my @activeList;
    my @badList;
    my $numVdisks;
    my $msg;
    my $val1;
    my $val2;

    if ( ! $noise )
    {
        $noise = "Q";
    }
    
    push (@badList, INVALID);       # set up the error return array
    

    # get the first sample
    %rsp = $ctlr->statsVDisk();     # get the initial reading
    
    if ( ! %rsp  )
    {
        logInfo("    ====> No response from statsVDisk <====");
        return @badList;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Error returned from statsVdisk <====");
        TestLibs::IntegCCBELib::PrintError(%rsp);
        return @badList;
    }
    
    
    sleep ($duration);    # Pause between samples

    #get second sample and compute activity
    return ( ControllerActiveVdiskListPart2($ctlr, \%rsp, $duration, $threshold, $noise) );

}


            
##############################################################################
#
#          Name: ControllerActiveVdiskListPart1
#
#        Inputs: controller object 
#
#       Outputs: data from statsvdisk
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub ControllerActiveVdiskListPart1
{
    trace();
    my ($ctlr,  $noise) = @_;

    my %rsp;
    my $activity;
    my @activeList;
    my @badList;
    my $numVdisks;
    my $msg;
    my $val1;
    my $val2;

    if ( ! $noise )
    {
        $noise = "Q";
    }
    

    # get the first sample
    %rsp = $ctlr->statsVDisk();     # get the initial reading
    
    if ( ! %rsp  )
    {
        if ( $noise ne "Q" )
        {
            logInfo("    ====> No response from statsVDisk <====");
        }
        $rsp{STATUS} = PI_ERROR;
        $rsp{ERROR_CODE} = 0;
        
        return %rsp;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        if ( $noise ne "Q" )
        {
            logInfo("    ====> Error returned from statsVdisk <====");
        }
        TestLibs::IntegCCBELib::PrintError(%rsp);
        return %rsp;
    }
    

    return %rsp;
}





##############################################################################
#
#          Name: ControllerActiveVdiskListPart2
#
#        Inputs: controller object 
#
#       Outputs: list of active vdisks, list may be empty
#                INVALID  as 1st element on error
#
#  Globals Used: none
#
#   Description: This functions does a vdisk info on the controller to
#                determine is a significant amount of writes and reads are
#                seen. Two readings, taken a few seconds apart should show
#                a change in the number of read and write requests.
#
#
##############################################################################
sub ControllerActiveVdiskListPart2
{
    trace();
    my ($ctlr, $firstSample, $duration, $threshold, $noise) = @_;

    my $i;
    my %rsp;
    my %rsp2;
    my $activity;
    my @activeList;
    my @badList;
    my $numVdisks;
    my $msg;
    my $val1;
    my $val2;
    my %vdisks;


    %rsp = %$firstSample;

#     my $numSecs = $duration;                # time between samples
# 
     if ( ! $noise )
     {
         $noise = "Q";
     }
     
     push (@badList, INVALID);       # set up the error return array
     
     my $sn = TestLibs::IntegCCBELib::GetSerial($ctlr);
     if ( $sn == INVALID  )
     {
         logInfo("Controller not responding, vdisk list skipped");
         return @badList;
     }
 
#     %rsp = $ctlr->statsVDisk();     # get the initial reading
#     
#     if ( ! %rsp  )
#     {
#         logInfo("No response from statsVDisk");
#         return @badList;
#     }
# 
#     if ($rsp{STATUS} != PI_GOOD)
#     {
#         logInfo("Error returned from statsVdisk ");
#         TestLibs::IntegCCBELib::PrintError(%rsp);
#         return @badList;
#     }
# 
#     sleep($numSecs);                       # wait for activity to accumulate

    %rsp2 = $ctlr->statsVDisk();    # get the follow-up reading
    
    if ( ! %rsp2  )
    {
        logInfo("    ====> Failed to get response from statsVDisk <====");
        return @badList;
    }

    if ($rsp2{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get statsVDisk <====");
        TestLibs::IntegCCBELib::PrintError(%rsp2);
        return @badList;
    }

    %vdisks = $ctlr->virtualDisks();    # get the follow-up reading
    
    if ( ! %vdisks  )
    {
        logInfo("    ====> Failed to get response from vdisks <====");
        return @badList;
    }

    if ($vdisks{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get vdisks <====");
        TestLibs::IntegCCBELib::PrintError(%vdisks);
        return @badList;
    }

    
    
    $numVdisks = min( $rsp{COUNT}, $rsp2{COUNT});   # use smaller of the counts


    # first display the data
    
    if ( $noise ne "Q" ) 
    { 
        logInfo("");
    }

    $msg =  "Virtual Disk Activity on controller $sn ($duration second period) ($rsp{COUNT} disks):\n";
    $msg .= "\n";
    $msg .= " VID     RREQ     WREQ    total   \n";
    $msg .= "-----  -------  -------  -------  \n";
    if ( $noise ne "Q" ) 
    { 
        logInfo($msg);
    }

    for (my $i = 0; $i < $numVdisks; $i++)
    {
        $msg = "";


        #
        #  This assumes the lists are in the same order
        #
        
        if ( $rsp{VDISKS}[$i]{VID} == $rsp2{VDISKS}[$i]{VID} )   # same vdisk
        {
            $msg .= sprintf( "%5hu  ",  $rsp{VDISKS}[$i]{VID});
        }
        else
        {
            $msg .= sprintf( "ERROR  ");
        }

        $val1 =  $rsp2{VDISKS}[$i]{RREQ}  - $rsp{VDISKS}[$i]{RREQ};  # reads
        $msg .= sprintf "%7s  ", $val1;
        
        $val2 =  $rsp2{VDISKS}[$i]{WREQ}  - $rsp{VDISKS}[$i]{WREQ};  # writes
        $msg .= sprintf "%7s  ", $val2 ;
        
        $msg .= sprintf "%7s  ", $val2 + $val1 ;       # total

        if ( IsVdiskMirrorDest($rsp{VDISKS}[$i]{VID}, \%vdisks ) )
        {
            $msg .= "  Mirror Dest";
        }

        if ( $noise ne "Q" ) 
        { 
            logInfo($msg);
        }
    
          
    }

    if ( $noise ne "Q" ) 
    { 
        logInfo("");
    }



    # now, the useful part...
    for (my $i = 0; $i < $numVdisks; $i++)
    {
        
        #
        # We need to make sure we are looking at the same vdisk is each list and 
        # also make sure the vdisk is not the destination of the mirror.
        #
        
        if ( ($rsp{VDISKS}[$i]{VID} == $rsp2{VDISKS}[$i]{VID}) &&    # same vdisk
             ( 0 == IsVdiskMirrorDest($rsp{VDISKS}[$i]{VID}, \%vdisks) ) )  # not mirror dest 
        {
        
            

            
            
            
            $activity =  $rsp2{VDISKS}[$i]{RREQ}  - $rsp{VDISKS}[$i]{RREQ} +
                         $rsp2{VDISKS}[$i]{WREQ}  - $rsp{VDISKS}[$i]{WREQ};
            
            if ( $activity > $threshold )   # a threshold for minimum activity
            {
                # there is enough activity, add it to the list
                #logInfo(" $activity requests on vdisk $rsp{VDISKS}[$i]{VID} ");
               
               
                push (@activeList, $rsp{VDISKS}[$i]{VID});
            }
        }
        elsif($rsp{VDISKS}[$i]{VID} != $rsp2{VDISKS}[$i]{VID})
        {
            logInfo("    ====> ERROR: vdisk lists are different when getting activity <====");
            return @badList;
        }
          
    }
    
    if ( $noise ne "Q" ) 
    { 
        logInfo("");
    }
    
    # got to sort this list

    return @activeList;
}

    
###############################################################################

=head2 IsVdiskMirrorDest function

This function scans the vdisks hash looking for a matching VID, then checks
that vid to see if it is a mirror destination.

=cut

=over 1

=item Usage:

 my $rc = IsVdiskMirrorDest( $VID, $vdisksPtr  );
 
 where: $VID is the vdisk VID in question
        $vdisksPtr is a pointer to a vdisks hash

=item Returns:

       $rc will be 1 if detected as a mirror destination, 0 if not. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut

##############################################################################
#
#          Name: IsVdiskMirrorDest
#
#
##############################################################################
sub IsVdiskMirrorDest
{

    my ($vid, $vdPtr ) = @_;

    my $i;
    my $msg;

    for ( $i = 0; $i < $vdPtr->{COUNT}; $i++)
    {
    
        $msg =" Vdisk $vdPtr->{VDISKS}[$i]{VID} mirror status is $vdPtr->{VDISKS}[$i]{MIRROR}, ";
        $msg .= "SCORVID $vdPtr->{VDISKS}[$i]{MIRROR} ";

        $msg .= "\n";

        #print $msg;
    
        if ($vid == $vdPtr->{VDISKS}[$i]{VID} )    # matched vid
        {
            if ( 0 < $vdPtr->{VDISKS}[$i]{MIRROR} )    # is mirror dest
            {
                #logInfo(" $vid is Mirror Dest");
                return 1;   # indicate mirror dest
            }
            else
            {
                #logInfo(" $vid not Mirror Dest");
                return 0;   # indicate not mirror dest
            }
        }

    }
    #
    # not in list, strange
    #

    logInfo(" Vdisk $vid not found in list");
    return 0;
}
##############################################################################

sub IsVdiskMirrorDestTest
{
    my ($ctlr) = @_;

    my $ret;
    my %vdisks;
    my $i;

    %vdisks = $ctlr->virtualDisks();    # get the follow-up reading
    
    if ( ! %vdisks  )
    {
        logInfo("    ====> Failed to get response from vdisks <====");
        return ERROR;
    }

    if ($vdisks{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get vdisks <====");
        TestLibs::IntegCCBELib::PrintError(%vdisks);
        return ERROR;
    }

    for ( $i = 0; $i < 40; $i++ )
    {
        logInfo("\n\nChecking vdisk $i");
        
        $ret =  IsVdiskMirrorDest($i, \%vdisks );

        logInfo("\nFor vdisk $i, Returned $ret");
    }

    return GOOD;

}
###############################################################################
=head2 AnyMirrorsPresent function

This function waits for mirror resync to complete.

=cut

=over 1

=item Usage:

 my $rc = AnyMirrorsPresent( $ctlr );
 
 where: $ctlr is the controller object for the master

=item Returns:

       $rc will be 1 if mirrors found, 0 if none, INVALID if error 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut

##############################################################################
#
#          Name: AnyMirrorsPresent
#
#
##############################################################################


sub AnyMirrorsPresent
{

    my ($ctlr) = @_;
    
    my $ret;
    my %vdisks;
    my $i;

    logInfo("AnyMirrorsPresent: Checking to see if any mirrors are present.");

    #
    # Get information on the vdisks
    #
    %vdisks = $ctlr->virtualDisks();    # get the follow-up reading
    
    if ( ! %vdisks  )
    {
        logInfo("    ====> Failed to get response from vdisks <====");
        return ERROR;
    }

    if ($vdisks{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get vdisks <====");
        TestLibs::IntegCCBELib::PrintError(%vdisks);
        return ERROR;
    }

    #
    # Look thru the vdisk info for a mirror
    #

    for ( $i = 0; $i < $vdisks{COUNT}; $i++ )
    {
        # logInfo("\n\nChecking vdisk $vdisks{VDISKS}[$i]{VID}");
        
        $ret =  IsVdiskMirrorDest($vdisks{VDISKS}[$i]{VID}, \%vdisks );

        # logInfo("\nFor vdisk $vdisks{VDISKS}[$i]{VID}, Returned $ret");
        if ($ret == 1) 
        {
            # mirror destination found
            logInfo("AnyMirrorsPresent: At least one mirror destination found");
            return 1;
        }
    }

    # none found
    logInfo("AnyMirrorsPresent: No mirror destinations found");
    return 0;



}


###############################################################################
=head2 MirrorCheck function

This function compares current resync data to the initial resync data. If 
there are noticeable differences, and error is reported. This does not look 
at _all_ data in the hashes.

=cut

=over 1

=item Usage:

 my $rc = MirrorCheck( $coPtr, $iPtr );
 
 where: $coPtr is the pointer to the systems controller objects
        $iPtr  is a pointer to the initial resync data (filled hash)

=item Returns:

       $rc will be GOOD if collection went OK, INVALID or ERROR if not. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut

###############################################################################
sub MirrorCheck
{
    my ($coPtr, $iPtr, $scope) = @_;
    
    
    my %nowData;
    my $ret;
    my $now;
    my $orig;
    my $nowA;
    my $origA;
    
    #
    # default to full validation
    #
    if ( !defined ($scope))
    {
        $scope = MIRROR_FULL;
    }
    
    logInfo("\n\n------------------------------  Mirror State validation begin -----------------------------\n\n");
    
    #
    # We received the initial data, now get the current data
    #
    
    $ret =  MirrorInitialData( $coPtr, \%nowData );
    if ( $ret != GOOD )
    {
        logInfo("Error fetching the current mirror data - validation failed");
        return ERROR;
    }
    
    #
    # We have both sets of data. First, check the vdisks data. We will verify 
    # the mirror, attr and scorvid values for each vdisk
    #
    
    my $iv;
    my $ci;
    my $idx;
    my $vid;
    my $failFlag = 0;
    my $printFlag;
    my $j;
    my $msg;
    my $initCacheEnabled;  # Initial cache enabled state
    my $currCacheEnabled;  # Current cache enabled state
    
    logInfo("Begin mirror validation with vdisks data");
    
    for ( $idx = 0; $idx < $iPtr->{VDISKS}{COUNT}; $idx++)
    {
        
        $printFlag = 0;
        
        # 
        # for each vdisk entry, get the VID, find that VID in the current 
        # data (getting the index into the current data) then finally
        # compare the data items.
        #
        
        $vid = $iPtr->{VDISKS}{VDISKS}[$idx]{VID};
        
        #print "Vdisk entry #idx is VID $vid\n";
        
        $ci = INVALID;
        for ( $j = 0; $j < $nowData{VDISKS}{COUNT}; $j++)
        {
            if ( $vid == $nowData{VDISKS}{VDISKS}[$j]{VID} )
            {
                $ci = $j;
                #print "matching current index is $ci \n";
                last;
            }
        }
        if ( $ci == INVALID )        
        {
            logInfo("Could not find vdisk $vid in the current data - validation failed");
            $failFlag = 1;
            next;
        }
        
        $nowA = $nowData{VDISKS}{VDISKS}[$ci]{ATTR};
        $origA =  $iPtr->{VDISKS}{VDISKS}[$idx]{ATTR};
            
        $now = $nowData{VDISKS}{VDISKS}[$ci]{MIRROR};
        $orig =  $iPtr->{VDISKS}{VDISKS}[$idx]{MIRROR};
        
                    
        #
        # If $scope is = NOCACHECHECK (mask cache ATTR bit and compare the data) 
        #
        if ($scope == NOCACHECHECK)
        {
        
            #$now = (($nowData{VDISKS}{VDISKS}[$ci]{ATTR}) & 0x1011);
            $nowA = ($nowA & 0x1011);
            logInfo("now = $nowA \n");
            #$orig = (($iPtr->{VDISKS}{VDISKS}[$idx]{ATTR}) & 0x1011);
            $origA = ($origA & 0x1011);
            logInfo("orig = $origA \n");
            
        
            if 
            ( 
                ( $iPtr->{VDISKS}{VDISKS}[$idx]{VID}            !=  $nowData{VDISKS}{VDISKS}[$ci]{VID} )     ||    # check VID (sanity check)
                ( $iPtr->{VDISKS}{VDISKS}[$idx]{SCORVID}        !=  $nowData{VDISKS}{VDISKS}[$ci]{SCORVID} ) ||    # check source vid
                ( $iPtr->{VDISKS}{VDISKS}[$idx]{MIRROR}         !=  $nowData{VDISKS}{VDISKS}[$ci]{MIRROR} )  ||    # check mirror state
                ( $origA  !=  $nowA ) # check attribute bits
            ) 
                #( (($iPtr->{VDISKS}{VDISKS}[$idx]{ATTR}) & 0x0100)  !=  (($nowData{VDISKS}{VDISKS}[$ci]{ATTR}) & 0x0100) ) # check attribute bits

            {
               # logInfo("Mirror data did not match for vdisk $vid - validation fails");
               # $msg = "";
               # $msg .= "      VID: was $iPtr->{VDISKS}{VDISKS}[$idx]{VID} is  $nowData{VDISKS}{VDISKS}[$ci]{VID} \n";
               # $msg .= "  SCORVID: was $iPtr->{VDISKS}{VDISKS}[$idx]{SCORVID} is  $nowData{VDISKS}{VDISKS}[$ci]{SCORVID} \n";
               # $msg .= "   MIRROR: was $iPtr->{VDISKS}{VDISKS}[$idx]{MIRROR} is  $nowData{VDISKS}{VDISKS}[$ci]{MIRROR}  \n";
               # #$msg .= "     ATTR: was $iPtr->{VDISKS}{VDISKS}[$idx]{ATTR} is  $nowData{VDISKS}{VDISKS}[$ci]{ATTR} \n";
               # $msg .= "     ATTR: was $orig is  $now \n";
               # logInfo($msg);
                $printFlag = 1;
                $failFlag = 1;  
            }
             
        }
            
      
        #
        # have both indices, compare the data
        #
        
        elsif ($scope == MIRROR_FULL)
        {
            if ( 
                (  $iPtr->{VDISKS}{VDISKS}[$idx]{VID}     !=  $nowData{VDISKS}{VDISKS}[$ci]{VID} ) ||        # check VID (sanity check)
                (  $iPtr->{VDISKS}{VDISKS}[$idx]{SCORVID} !=  $nowData{VDISKS}{VDISKS}[$ci]{SCORVID} ) ||    # check source vid
                (  $iPtr->{VDISKS}{VDISKS}[$idx]{MIRROR}  !=  $nowData{VDISKS}{VDISKS}[$ci]{MIRROR} ) ||     # check mirror state
                (  $iPtr->{VDISKS}{VDISKS}[$idx]{ATTR}    !=  $nowData{VDISKS}{VDISKS}[$ci]{ATTR} )          # check attribute bits
               ) 
            {
                $printFlag = 1;
                $failFlag = 1;  
            } 
        }
        else
        {
            # MIRROR_LIMITED + ??
            if ( 
                   (  $iPtr->{VDISKS}{VDISKS}[$idx]{VID}     !=  $nowData{VDISKS}{VDISKS}[$ci]{VID} ) ||        # check VID (sanity check)
                   (  $iPtr->{VDISKS}{VDISKS}[$idx]{SCORVID} !=  $nowData{VDISKS}{VDISKS}[$ci]{SCORVID} ) ||    # check source vid
                   (  ( 0xfff7 & $iPtr->{VDISKS}{VDISKS}[$idx]{ATTR})  !=  
                      ( 0xfff7 & $nowData{VDISKS}{VDISKS}[$ci]{ATTR}) 
                   )            # check atribute bits (except suspend bit)
               ) 
            {
            
                #$now = $nowData{VDISKS}{VDISKS}[$ci]{MIRROR};
                #$orig =  $iPtr->{VDISKS}{VDISKS}[$idx]{MIRROR};
                
                if ( $orig != $now )
                {
                    
                    #
                    #       vd_mirror definitions
                    #
                    #        .set    vdnomirror,0            # 00 # no mirror active
                    #        .set    vdcopyto,1              # 01 # Sec. copy destination
                    #        .set    vdcopymirror,2          # 02 # Sec. copy mirror
                    #        .set    vdcopyuserpause,3       # 03 # copy user paused
                    #        .set    vdcopyautopause,4       # 04 # copy auto paused
                    
                    
                    # if it was paused,   it must still be paused
                    # if it was mirrored, it can be mirrored or copying
                    
                  
                    if ( $orig == 2 )                     # was mirrored
                    {
                        if ( $now != 2 && $now != 1 )     # now not mirrored or copying
                        {
                            $printFlag = 1;
                            $failFlag = 1; 
                        }
                    }
                    elsif ( $orig == 3 || $orig == 4 )    # was paused
                    {
                        if ( $now != 3 && $now != 4 )     # now not paused
                        {
                            $printFlag = 1;
                            $failFlag = 1; 
                        }
                    }         
                        
                }
                 
            } 
            
        }
        
        
        #
        # If we failed this comparison, log the error
        #
        if ( $printFlag == 1 )
        {
            logInfo("Mirror data did not match for vdisk $vid - validation fails");
            $msg = "";
            $msg .= sprintf("      VID: was %4d is %4d \n", 
                             $iPtr->{VDISKS}{VDISKS}[$idx]{VID}, 
                             $nowData{VDISKS}{VDISKS}[$ci]{VID});
            $msg .= sprintf("  SCORVID: was %4d is %4d \n", 
                             $iPtr->{VDISKS}{VDISKS}[$idx]{SCORVID},  
                             $nowData{VDISKS}{VDISKS}[$ci]{SCORVID} );
            $msg .= sprintf("   MIRROR: was %4d is %4d \n",
                             $orig,
                             $now );
            $msg .= sprintf("     ATTR: was 0x%02X is 0x%02X \n",
                             $origA,
                             $nowA );
            logInfo($msg);
        }
        
        
        
    }
    
    logInfo("Vdisks Data Evaluation complete");
    
    # 
    # vdisks data done, now do the raids data. Note, we are deferring failure
    # until all the checks have been done.
    #        
        

    #
    # If $scope == NOCACHECHECK then skip this (global cache check)
    #
    if (!($scope & NOCACHECHECK)) 
    { 
        #
        # Get just the cache enabled bit from the cache status
        #
        $initCacheEnabled = $iPtr->{GLOBALCACHEINFO}{CA_STATUS} & 0x1;
        $currCacheEnabled = $nowData{GLOBALCACHEINFO}{CA_STATUS} & 0x1;

        #
        # Check the global cache information for changes
        # 
        if ($initCacheEnabled != $currCacheEnabled) #||
            #($iPtr->{GLOBALCACHEINFO}{CA_BATTERY} != $nowData{GLOBALCACHEINFO}{CA_BATTERY}))
        {
            logInfo("Global cache information did not match - validation failed");
            $msg = sprintf "\n" .
                            "CA_STATUS (enabled bit only): was 0x%x is 0x%x\n" .
                            "CA_BATTERY: was 0x%x is 0x%x\n",
                            $initCacheEnabled,
                            $currCacheEnabled,
                            $iPtr->{GLOBALCACHEINFO}{CA_BATTERY},
                            $nowData{GLOBALCACHEINFO}{CA_BATTERY};

            logInfo($msg);
            $failFlag = 1;
        }
        
    }



    if ( $failFlag != 0 )
    {
        logInfo("\n\n------------------------------  Mirror state validation has failed.  ------------------------------\n\n  ");
        return ERROR;
    }    
    
    logInfo("\n\n------------------------------  Mirror state validation passed.  ------------------------------\n\n ");
    
    return GOOD;
}


###############################################################################
=head2 MirrorInitialData function

This function collects the initial data for resync validation. It fills in
a hash with the state of the mirrors at the time this is called. Later, this
data is used to validate that the mirrors have not changed.

=cut

=over 1

=item Usage:

 my $rc = MirrorInitialData( $coPtr, $rPtr );
 
 where: $coPtr is the pointer to the systems controller objects
        $rPtr  is a pointer to the initial resync data (empty hash)

=item Returns:

       $rc will be GOOD if collection went OK, INVALID or ERROR if not. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut

###############################################################################
sub MirrorInitialData
{
    my ($coPtr, $mirrorDataPtr) = @_;
    
    my $ret;
    my $ctlr;
    my $master;
    my $msg;
    my %rsp;
    
    if ( defined($mirrorDataPtr) )
    {
        #
        # the pointer is valid, so, let's get the data. We will collect
        # 'resyncData', 'vdisks', and 'raids'. 
        #
        
        #
        # we do this on the master controller
        #
        $master = TestLibs::IntegCCBELib::FindMaster($coPtr);
        if ( $master == INVALID)
        {
            logInfo("Failed to get master");
            return ERROR;
        }
    
        $ctlr = $$coPtr[$master];
        
        #
        # go for the resyncData
        #
        %rsp = $ctlr->resyncData(1);

        if (%rsp)
        {
            if ($rsp{STATUS} != PI_GOOD)
            {
                logInfo("Unable to retrieve the resync data.");
                PrintError(%rsp);
                return ERROR;
            }
        }
        else
        {
            logInfo("ERROR: Did not receive a response packet.");
            return ERROR;
        }
        
        %{$mirrorDataPtr->{RESYNCDATA}} = %rsp;
        
        #
        # now the pdisks data
        # 
        %rsp = $ctlr->physicalDisks();
        if ( ! %rsp  )              # if no return from call
        {
            logInfo("    ====> Failed to get response from physicalDisks command <====");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo("    ====> Error from physicalDisks command <====");
            PrintError(%rsp);
            return ERROR;
        }
        %{$mirrorDataPtr->{PDISKS}} = %rsp;
        
        #
        # now the vdisks data
        # 
        %rsp = $ctlr->virtualDisks();
        if ( ! %rsp  )              # if no return from call
        {
            logInfo("    ====> Failed to get response from virtualDisks command <====");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo("    ====> Error from virtualDisks command <====");
            PrintError(%rsp);
            return ERROR;
        }
        %{$mirrorDataPtr->{VDISKS}} = %rsp;
        
        #
        # now the raids data
        # 
        %rsp = $ctlr->raids();
        if ( ! %rsp  )              # if no return from call
        {
            logInfo("    ====> Failed to get response from raids command <====");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo("    ====> Error from raids command <====");
            PrintError(%rsp);
            return ERROR;
        }
        
        %{$mirrorDataPtr->{RAIDS}} = %rsp;             # ${$hashref->{"KEY"}}

        #
        # Now the global cache information
        #
        %rsp = $ctlr->globalCacheInfo();

        if ( ! %rsp  )              # if no return from call
        {
            logInfo("    ====> Failed to get response from global cache info command <====");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo("    ====> Error from global cache info command <====");
            PrintError(%rsp);
            return ERROR;
        }
        
        %{$mirrorDataPtr->{GLOBALCACHEINFO}} = %rsp;             # ${$hashref->{"KEY"}}

        $msg = $ctlr->displayGlobalCacheInfo(%rsp);
        logInfo($msg);
    }
    
    $ret = MirrorDataShow($coPtr);
    
    return GOOD;
}
###############################################################################

sub MirrorDataShow
{
    my ($coPtr) = @_;
    
    my $ctlr;
    my $master;
    my $msg;
    my %rsp;
    
    $master = TestLibs::IntegCCBELib::FindMaster($coPtr);
    if ( $master == INVALID)
    {
        logInfo("Failed to get master");
        return ERROR;
    }
    
    $ctlr = $$coPtr[$master];
    
    logInfo("************************************************** Mirror Data Start ***************************************************");
    
    
    %rsp = $ctlr->resyncData(1);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            $msg = $ctlr->displayResyncData("DTL", 4096, %rsp);
            logInfo($msg);
        }
        else
        {
            logInfo("Unable to retrieve the resync data.");
            PrintError(%rsp);
        }
    }
    else
    {
        logInfo("ERROR: Did not receive a response packet.");
        return ERROR;
    }

    DispVdisksRaids($ctlr);

    logInfo("***************************************************** Mirror Data End ****************************************************");
          
    return GOOD;    
}

###############################################################################

=head2 MirrorResyncWait function

This function waits for mirror resync to complete.

=cut

=over 1

=item Usage:

 my $rc = MirrorResyncWait( $coPtr, $timeout  );
 
 where: $coPtr is a pointer the the controller objects
        $timeout max number of seconds to wait.

=item Returns:

       $rc will be GOOD if done in time allotted, ERROR otherwise 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut

##############################################################################
#
#          Name: MirrorResyncWait
#
#        Inputs: controller object list, timeout
#
#       Outputs: GOOD if resync done within timeout and no error
#                ERROR if error or timeout
#
#  Globals Used: none
#
#   Description: Wiats for mirror resync to finish
#
##############################################################################


sub MirrorResyncWait
{
    my ($coPtr, $timeOut) = @_;
    
    my %vdisks;
    my $ret;
    my $errorCount;
    my $maxErrors;
    my $i;
    my $ctlr;
    my $stillCooking;
    
    $maxErrors = 10;                 # probably a parm needed.
    
    logInfo("");
    logInfo("MirrorResyncWait: begin");
    
    $i = TestLibs::IntegCCBELib::FindMaster($coPtr);
    
    if ( $i == INVALID )
    {
        logInfo("AnyMirrorsPresent: Could not determine master controller");
        return INVALID;
    }
    
    $ctlr = $$coPtr[$i];
    
    
    #
    # First see if there are any mirrors.
    #
    $ret = AnyMirrorsPresent($ctlr);
    
    #
    # If there are no mirrors, we are done, If there are some, then
    # pause for a while to allow the resync to start (may not need 
    # the delay) 
    #
    
    if ( $ret == INVALID)
    {
        logInfo("Error during check if any mirrors exist.");
        return ERROR;
    }
        
    if ( $ret == 0   )
    {
        # no mirrors
        return (GOOD);
    }
    
    DelaySecs(5);

    #
    # Now look for resync to be done, manage timeout on the way.
    #
    # When the devices are mirror the status is VD_COPYMIRROR. When
    # resyncing the status would be VD_COPYTO, unless the copy is
    # paused in which the status would be either VD_COPYUSERPAUSE  
    # or VD_COPYAUTOPAUSE.
    # define VD_NOMIRROR      0          /**< No mirror active                   */
    # define VD_COPYTO        1          /**< Secondary copy destination         */
    # define VD_COPYMIRROR    2          /**< Secondary copy mirror              */
    # define VD_COPYUSERPAUSE 3          /**< copy user pause                    */
    # define VD_COPYAUTOPAUSE 4          /**< copy auto pause                    */
    #

    $errorCount = 0;

    while ( $timeOut > 0 )
    {

        #
        # pause 1 sec and decrement timeout counter
        #

# logInfo("$timeOut seconds to go in resync wait");

        sleep 10;
        $timeOut = $timeOut - 10;
        
        if ( $errorCount > $maxErrors )
        {
            logInfo("MirrorResyncWait: Too many errors getting vdisks data");
            return ERROR;
        }
        
        #
        # all info is in vdisks, so get the data
        #
        
        %vdisks = $ctlr->virtualDisks();    # get the follow-up reading
    
        if ( ! %vdisks  )
        {
            logInfo("    ====> Failed to get response from vdisks <====");
            $errorCount++;
            next;
            #return ERROR;
        }

        if ($vdisks{STATUS} != PI_GOOD)
        {
            logInfo("    ====> Unable to get vdisks <====");
            TestLibs::IntegCCBELib::PrintError(%vdisks);
            $errorCount++;
            next;
            #return ERROR;
        }

        #
        # look for any disks in the resyncing state, warn on pauses
        #
        
        $stillCooking = 0;
        
        for ( $i = 0; $i < $vdisks{COUNT}; $i++ )
        {
            print ("\rChecking vdisk $vdisks{VDISKS}[$i]{VID}");
        
            if ( ($vdisks{VDISKS}[$i]{MIRROR} != 0 ) &&
                 ($vdisks{VDISKS}[$i]{MIRROR} != 2 ))
            {
                # vdisk paused or resyncing
                if ( $vdisks{VDISKS}[$i]{MIRROR} != 1 )
                {
                    logInfo("MirrorResyncWait: Vdisk  $vdisks{VDISKS}[$i]{VID} is paused, ".
                             "MIRROR=$vdisks{VDISKS}[$i]{MIRROR}, ".
                             "This may not be good.");
                }
                #
                # still not ready, done with this pass, go back and do next
                #
                $stillCooking = 1;
                last;
            }

        }    # end for $i
        
        
        #
        # If none were resyncing, we are done.
        #
        if ( $stillCooking == 0 )
        {
            #
            # No resync or Pause, we are done.
            #
            print("\n");
            logInfo("MirrorResyncWait: No resync in progress.");
            logInfo("");
            # need to refresh the connection to the slave
            TestNReconnectAll($coPtr, 2);
            
            return GOOD;
            
        }
        

    }

    #
    # if we get here we have timed out. not good.
    #
    
    # need to refresh the connection to the slave
    TestNReconnectAll($coPtr, 2);
    
    logInfo("MirrorResyncWait: Timeout waiting for mirror resync to complete");
    logInfo("");
    return ERROR;
}    

##############################################################################
#
#          Name: IsVdiskActive
#
#        Inputs: controller object list, vdisk number
#
#       Outputs: GOOD if vdisk shows activity, ERROR if not,
#                INVALID  on error
#
#  Globals Used: none
#
#   Description: This functions does a statsvdisk on the controllers to
#                determine is a significant amount of writes and reads are
#                seen. Two readings, taken a few seconds apart should show
#                a change in the number of read and write requests.
#
##############################################################################
sub IsVdiskActive
{

#    my %rsp = $currentMgr->statsVDisk();
#
#        logMsg("begin\n");
#




    return GOOD;
}

##############################################################################
#
#          Name: GetVCGInfoData
#
#        Inputs: controller object list
#
#       Outputs: array of vcginfo data from the master
#                INVALID  as 1st element on error
#
#  Globals Used: none
#
#   Description: This function gets the vcginfo date from the master
#                controller.
#
##############################################################################
sub GetVCGInfoData
{
    return GOOD;
}

##############################################################################
#
#          Name: Wait4PowerUpState
#
#        Inputs: controller object, desired state, timeout(in seconds)
#
#       Outputs: GOOD when state is achieved
#                ERROR if timeout
#                INVALID  on other error
#
#  Globals Used: none
#
#   Description: This function gets the powerupstate from the specified
#                controller and checks for a match. Repeat until match
#                or timeout
#
##############################################################################
sub Wait4PowerUpState
{
    my ($ctlr, $dState, $timeout) = @_;

    my $loops;

    my $i;
    my $ret;

    $loops = $timeout / 5;     # number of secs delay between samples
                               # should match sleep() below

    # make sure loops is reasonable
    if ( $loops < 1 ) 
    {
        $loops = 1;            # always do at least one
    }

    # now loop until we get what we want
    for ( $i = 0; $i < $loops; $i++ )
    {
        $ret = TestLibs::IntegCCBELib::GetPowerUpState($ctlr);
        
        if ($ret == INVALID)
        {
            # got an error somewhere
            return INVALID;
        }
         
        if ($ret == $dState)
        {
            # state matched, we are done
            return GOOD;
        }

        sleep (5);
    }

    # timed out!
    return ERROR;
}


##############################################################################
#
#          Name: Wait4MinPowerUpState
#
#        Inputs: controller object, desired state, timeout(in seconds)
#
#       Outputs: GOOD when state is achieved
#                ERROR if timeout
#                INVALID  on other error
#
#  Globals Used: none
#
#   Description: This function gets the powerupstate from the specified
#                controller and checks for a matching state or 'higher'.
#                Repeat until match or timeout.
#
##############################################################################
sub Wait4MinPowerUpState
{
    my ($ctlr, $dState, $timeout) = @_;

    my $loops;

    my $i;
    my $ret;

    $loops = $timeout / 5;     # number of secs delay between samples
                               # should match sleep() below

    # make sure loops is reasonable
    if ( $loops < 1 ) 
    {
        $loops = 1;            # always do at least one
    }

    # now loop until we get what we want
    for ( $i = 0; $i < $loops; $i++ )
    {
        $ret = TestLibs::IntegCCBELib::GetPowerUpState($ctlr);
        
        if ($ret == INVALID)
        {
            # got an error somewhere
            return INVALID;
        }
         
        if ($ret >= $dState)
        {
            # state matched or better, we are done
            return GOOD;
        }

        sleep (5);
    }

    # timed out!
    return ERROR;
}

##############################################################################
#
#          Name: Wait4NoWaitPowerUpState
#
#        Inputs: controller object, timeout(in seconds)
#
#       Outputs: GOOD when a valid power up state is achieved
#                ERROR if timeout
#                INVALID  on other error
#
#  Globals Used: none
#
#   Description: This function gets the powerupstate from the specified
#                controller and checks for a matching state or 'higher'.
#                Repeat until match or timeout.
#
##############################################################################
sub Wait4NoWaitPowerUpState
{
    my ($ctlr, $timeout) = @_;

    my $loops;

    my $i;
    my $ret;

    $loops = $timeout / 5;     # number of secs delay between samples
                               # should match sleep() below

    # make sure loops is reasonable
    if ( $loops < 1 ) 
    {
        $loops = 1;            # always do at least one
    }

    # now loop until we get what we want
    for ( $i = 0; $i < $loops; $i++ )
    {
        $ret = TestLibs::IntegCCBELib::GetPowerUpState($ctlr);
        
        if ($ret == INVALID)
        {
            # got an error somewhere
            logWarning("Error: Could not get Power Up State from controller");
            return INVALID;
        }
         
        if ($ret != POWER_UP_START &&
            $ret != POWER_UP_WAIT_PROC_COMM &&
            $ret != POWER_UP_PROCESS_BE_INIT &&
            $ret != POWER_UP_PROCESS_DISCOVERY &&
            $ret != POWER_UP_WAIT_CORRUPT_BE_NVRAM &&
            $ret != POWER_UP_ALL_CTRL_BE_READY &&
            $ret != POWER_UP_PROCESS_R5_RIP &&
            $ret != POWER_UP_SIGNAL_SLAVES_RUN_FE)
        { 
            # state not waiting, we are done
            return GOOD;
        }

        sleep (5);
    }

    # timed out!
    logWarning("Error: Timeout waiting for controller to reach a No Wait Power Up State");

    return ERROR;
}

##############################################################################
#
#          Name: PCLoop4JT
#
#        Inputs: controller object 
#
#       Outputs: GOOD, if controller IS failed, ERROR if not failed,
#                INVALID on error
#
#  Globals Used: none
#
#   Description: A function validae a FW bug for JT. Just here so I won't 
#                lose it.
#
##############################################################################
sub PCLoop4JT
{
    my ($coPtr, $moxaPtr, $moxaIP, $index) = @_;

    my $ret;
    my @coList;
    my @moxaMap;
    my %stuff;

    @coList = @$coPtr;
    @moxaMap = @$moxaPtr;

    while(1)
    {
        
        %stuff = GetTargetStatus($coList[$index]);
        LogTargetStatus( %stuff);
        
        
        $ret = DispPdiskInfo( $coList[$index] );

        if ( $ret == ERROR )
        {
            logInfo("failed to get pdiskinfo/devstat pd");
            return ERROR;
        }


        # the power cycle
        $ret = TestLibs::IntegCCBELib::PowerCycle($moxaIP, $moxaMap[$index]);
        


        # reconnect and wait
        logInfo("Pause for 60 seconds and reconnect ) ");
        $ret = TestLibs::IntegCCBELib::Reconnect( $coList[$index], 60 );
        if ( $ret == ERROR )
        {
            logError("    ====> Failed to reconnect to the controller <====");
            return ERROR;
        }
        
        logInfo("Wait for 5 minutes");

        DelaySecs(300);
                

     
    }
    return GOOD;
}




##############################################################################
# Name:     ActiveServerList
#
# Desc:     Creates a list of the active servers.
#
# Input:  Pointer to an array of controllers
# Output: Array of active server Ids 
##############################################################################
sub ActiveServerList
{
    trace();
    my ($coPtr) = @_;
    my @ar1;
    my @ar2;
    my @retarr;
    my @coList;
    my $i;
    my $j;
    my $size;
    my $diff;

    @coList = @$coPtr;

    #Initialize the server array to all inactive

    for $i (0..255)
    {
        $retarr[$i] = FALSE;
    }

    my $numCtlrs = scalar( @coList );

    #
    # Walk through each of the controllers and flag the active servers
    #
    for $i (0..$numCtlrs-1)
    {
        logInfo("");
        logInfo("Getting server activity for controller $i.....");

        @ar1 = GetServerIO($coList[$i]);
        sleep(10);
        @ar2 = GetServerIO($coList[$i]);


        $size = min( scalar(@ar1), scalar(@ar2));


        for $j (0..$size)
        {
            if (defined($ar1[$j]) && defined($ar2[$j]))
            {
                $diff = $ar2[$j] - $ar1[$j];
                logInfo(sprintf(" Server %3d: 1st %9d, 2nd %9d, activity = %6d", $j ,$ar1[$j], $ar2[$j], $diff) ); 
                if ($diff > 15)             
                {
                    $retarr[$j] |= TRUE;
                }
            }
        }
    }

    # Display Active servers
    my $str = "Active Servers:";

    for $i (0..scalar(@retarr))
    {
        if ($retarr[$i])
        {
            $str .= " $i,";
        }
    }
    logInfo($str);
    logInfo("");

    return @retarr;
}
##############################################################################
# Name:     GetServoIO
#
# Desc:     Looks to see if servers are still processing I/O requests.
#
# Input:    obj - controller object
##############################################################################
sub GetServerIO
{
    trace();
    my ($obj) = @_;
    my @commands;

    bless($obj, "XIOTech::cmdMgr");

    my %rsp = $obj->serverList(undef);

    if (%rsp)
    {
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo("getServerIO: Unable to retrieve Server List.");
        }
        else
        {
            # 
            # Loop through all server
            for my $i (0..$#{$rsp{LIST}})
            {
                # logInfo ("Retrieving stats for server $rsp{LIST}[$i]  ");
                my %rsp2 = $obj->statsServer($rsp{LIST}[$i]);

                if (%rsp2)
                {
                    if ($rsp2{STATUS} != PI_GOOD)  
                    {
                        
                        if (!(($rsp2{STATUS} == 0x01)  &&    
                                    ($rsp2{ERROR_CODE} == 0x2f)))                                       
                        { 
                            #logInfo("getServIO: Unable to retrieve Server Stats.");
                        }
                        else
                        {
                            $commands[$rsp{LIST}[$i]] = 0;
                            #logInfo("\t\tServer: $rsp{LIST}[$i] returned 0x2F");   

                        }
                    }
                    else
                    {
                        $commands[$rsp{LIST}[$i]] = ($rsp2{AG_READS} + $rsp2{AG_WRITES});
                        #logInfo("Server: $rsp{LIST}[$i] Reads: $rsp2{AG_READS} Writes: $rsp2{AG_WRITES}");   
                    }

                }
            }
        }

    }
    else
    {
        #logInfo("GetServoIO: Did not receive a response packet.");
    }


    return @commands;
}

##############################################################################
# Name:     TestForServerIO
#
# Desc:     Looks to see if servers are still processing I/O requests.
#
# Input:    None
##############################################################################
sub TestForServerIO
{
    trace();
    my ($coPtr, $actServerPtr) = @_;

    my $rc = GOOD;
    my $retry = 0;

    my @serverList = @$actServerPtr;

    do
    {
        $rc = GOOD;
        my @activeServers = ActiveServerList($coPtr);

        if (scalar(@activeServers) != scalar(@serverList))
        {
            logInfo("Mismatch in number of active servers  ");
            $rc = ERROR;
        }
        else
        {
            for my $i (0..scalar(@activeServers))
            {
                if (defined($activeServers[$i]))
                {
                    if ($activeServers[$i] != $serverList[$i])
                    {
                        logInfo("Mismatch in active server list  ");
                        $rc = ERROR;
                    }
                }
            }
        }
        if ($rc != GOOD)
        {
            logInfo(" First List: @serverList ");
            logInfo(" Other List: @activeServers ");
            ++$retry;
            sleep (10);
            logInfo("Failed Active Server test - Retry No. $retry");
        }
    } while (($rc != GOOD) && ($retry < 1));

    return $rc;
}

##############################################################################
# Name:     TestForServerIO2
#
# Desc:     Looks to see if servers are still processing I/O requests.
#
# Input:    None
##############################################################################
sub TestForServerIO2
{
    trace();
    my ($coPtr, $actServerPtr) = @_;

    my $rc = GOOD;
#    my $retry = 0;

    my @serverList = @$actServerPtr;

#    do
#    {
#        $rc = GOOD;
        my @activeServers = ActiveServerList($coPtr);

#        if (scalar(@activeServers) != scalar(@serverList))
#        {
#            logInfo("Mismatch in number of active servers  ");
#            $rc = ERROR;
#        }
#        else
#        {


        $rc = CompareLists2( \@activeServers, $actServerPtr);

        if ( $rc != GOOD )
        {
            logInfo("Mismatch in active server list  ");
        }

#            for my $i (0..scalar(@activeServers))
#            {
#                if (defined($activeServers[$i]))
#                {
#                    if ($activeServers[$i] != $serverList[$i])
#                    {
#                        logInfo("Mismatch in active server list  ");
#                        $rc = ERROR;
#                    }
#                }
#            }
#        }
#        if ($rc != GOOD)
#        {
#            logInfo(" First List: @serverList ");
#            logInfo(" Other List: @activeServers ");
#            ++$retry;
#            sleep (10);
#            logInfo("Failed Active Server test - Retry No. $retry");
#        }
#    } while (($rc != GOOD) && ($retry < 1));


    return $rc;
}


##############################################################################
#
#          Name: GetServerActivityCounts
#
#        Inputs: controller object list 
#
#       Outputs: 
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################
sub GetServerActivityCounts
{
    trace();
    my ($coPtr) = @_;

    my $k;
    my $t;

    my %servers;
    my $iServer;
    my %targets;
    my $iTarget;
    my %sstats;
    my $bMyServer;

    my $iCtrl;
    my $ctrl;
    my @coList;
    my $added;
    my $sid;
    my $amount;
    
    my $amountR; 
    my $amountW; 

    @coList = @$coPtr;       # get array of objects

    my @activity;
    my @activity2;

    # for each controller, get the vdisk list and counts 
    for ($iCtrl = 0; $iCtrl < scalar(@coList); $iCtrl++)
    {
        $ctrl = $coList[$iCtrl];

        %servers = $ctrl->servers();

        if( !%servers )
        {
            # no servers, we are done with this controller (it is dead)
            next;    
        }

        %targets = $ctrl->targets();

        if( !%targets )
        {
            # no targets, we are done with this controller (it is dead)
            next;    
        }

        if ($servers{STATUS} != PI_GOOD)
        {
            logInfo("getServerIO: Unable to retrieve Server List.");
            next;
        }

        # status is good, extract the data
        for ( $iServer = 0; $iServer < $servers{COUNT}; $iServer++)
        {
            $bMyServer = 0;
            $sid = $servers{SERVERS}[$iServer]{SID};

            # Loop through the targets to find the target for this server.
            # If the target is found, check if ths controller is the owner
            # of the target.
            for ($iTarget = 0; $iTarget < $targets{COUNT}; $iTarget++)
            {
                # Is this the target for this server's target and is it
                # owned by this controller?
                if ($servers{SERVERS}[$iServer]{TARGETID} == $targets{TARGETS}[$iTarget]{TGD_TID} &&
                    $targets{TARGETS}[$iTarget]{TGD_OWNER} == $ctrl->{SERIAL_NUM})
                {
                    # Yep, it is my server
                    $bMyServer = 1;
                    last;
                }
            }
        
            # Only get the server statistics if this server is owned
            # by this controller.
            if ($bMyServer == 1)
            {
                %sstats = $ctrl->statsServer($sid);

                # a little hash with a VID and total count
                # save in an array of little hashes
                $added = 0;

                if ($sstats{STATUS} == PI_GOOD)  
                {
                    $amount = ($sstats{AG_READS} + $sstats{AG_WRITES});
                    $amountR = Math::BigInt->new($sstats{AG_RBYTES} / 1048576);
                    $amountW = Math::BigInt->new($sstats{AG_WBYTES} / 1048576);
                    
                    
                    #print "server $sid: MB written = $amountW, bytes = $sstats{AG_WBYTES}\n";;
                    #print "server $sid: MB read =  $amountR, bytes = $sstats{AG_RBYTES} \n";
                    
                    
                    for ( $k = 0; $k < scalar(@activity); $k++)
                    {

                        # look for existing item to add to
                        if ($activity[$k]{SID} == $sid )
                        {
                            # combine into existing item
                            #print "merging ";
                            #print "$activity[$k]{VID2}  $little{VID2}  $activity[$k]{COUNTS} $little{COUNTS} \n";
                            $activity[$k]{COUNTS} += $amount;
                            $activity[$t]{READSECTORS} += $amountR;
                            $activity[$t]{WRITESECTORS} += $amountW;
                            $added = 1;
                        }
                    }
                    if ( $added == 0)
                    {
                        # new item, create new entry
                
                        $t = scalar(@activity);
                        $activity[$t]{SID} = $sid;
                        $activity[$t]{COUNTS} = $amount;
                        $activity[$t]{READSECTORS} = $amountR;
                        $activity[$t]{WRITESECTORS} = $amountW;
                        
                        
                        

                    }
                }
            }
        }
    }

    if ( scalar(@activity) < 1 )
    {
        logInfo("No Server activity count information found");
    }

    return @activity;
}
##############################################################################
#
#          Name: MakeActiveServerMap
#
#        Inputs: controller object list 
#
#       Outputs: 
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################
sub MakeActiveServerMap
{
    trace();
    my ($coPtr, $firstPtr, $threshold) = @_;

    my @first;
    my @second;
    my %little;
    my $matched;
    my @badAr;
    my $i;
    my $j;
    my $sid;
    my $count;
    my $totalActivity;
    my @activity;
    my @activity2;

    push ( @badAr, INVALID);

    @first = @$firstPtr;

    @second = GetServerActivityCounts($coPtr);  # get the current counts
    
    $totalActivity = 0;

    $matched = 0;

    #
    # Takes all items in the first array and looks for the matching one 
    # in the second. If a match found, then compute the change and
    # add the vdisk to the active array. If an item is only in the 
    # first list, and not in the second, it will not be 'active'. 
    # Ditto for the other way around. If things are going well,
    # both lists should always have the same members. 
    # 
    
    
    
    
    for ($i = 0; $i < scalar( @first ); $i++ )
    {
        # for each item in the first array...extract the data
        $sid = $first[$i]{SID};
        $count = $first[$i]{COUNTS};

        #print " got $sid, $count \n";

        # get the matching entry in the second array
        for( $j = 0; $j < scalar(@second); $j++)
        {
            if ( $sid == $second[$j]{SID} )
            {
                # item matched, now combine results
                $count= $second[$j]{COUNTS} - $count;

                $totalActivity += $count;
 
                logInfo(" Server activity SID: $sid, count: $count");

                if ($count > $threshold)
                {
                    # the server had enough activity
                    push( @activity, $sid );
                    $matched = 1;
                }
            }

        }
    }

    if ( $matched == 0 )
    {
        # no data was found, return invalid
        return @badAr;
    }

    # we are good.
    logInfo("Total server activity = $totalActivity ");
    logInfo("");

    return SortAndRemoveDups(@activity);

}

##############################################################################
#
#          Name: MakeActiveServerMapQ
#
#        Inputs: controller object list 
#
#       Outputs: 
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################
sub MakeActiveServerMapQ
{
    trace();
    my ($coPtr, $firstPtr, $threshold) = @_;

    my @first;
    my @second;
    my %little;
    my $matched;
    my @badAr;
    my $i;
    my $j;
    my $sid;
    my $count;
    my $totalActivity;
    my @activity;
    my @activity2;

    push ( @badAr, INVALID);

    @first = @$firstPtr;

    @second = GetServerActivityCounts($coPtr);  # get the current counts
    
    $totalActivity = 0;

    $matched = 0;

    #
    # Takes all items in the first array and looks for the matching one 
    # in the second. If a match found, then compute the change and
    # add the vdisk to the active array. If an item is only in the 
    # first list, and not in the second, it will not be 'active'. 
    # Ditto for the other way around. If things are going well,
    # both lists should always have the same members. 
    # 
    
    
    
    
    for ($i = 0; $i < scalar( @first ); $i++ )
    {
        # for each item in the first array...extract the data
        $sid = $first[$i]{SID};
        $count = $first[$i]{COUNTS};

        #print " got $sid, $count \n";

        # get the matching entry in the second array
        for( $j = 0; $j < scalar(@second); $j++)
        {
            if ( $sid == $second[$j]{SID} )
            {
                # item matched, now combine results
                $count= $second[$j]{COUNTS} - $count;

                $totalActivity += $count;
 
                #logInfo(" Server activity SID: $sid, count: $count");

                if ($count > $threshold)
                {
                    # the server had enough activity
                    push( @activity, $sid );
                    $matched = 1;
                }
            }

        }
    }

    if ( $matched == 0 )
    {
        # no data was found, return invalid
        return @badAr;
    }

    # we are good.
    #logInfo("Total server activity = $totalActivity ");
    #logInfo("");

    return SortAndRemoveDups(@activity);

}




        

##############################################################################
#
#          Name: GetVdiskActivityCounts
#
#        Inputs: controller object list 
#
#       Outputs: 
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################
sub GetVdiskActivityCounts
{
    trace();
    my ($coPtr) = @_;

    my $i;
    my $j;
    my $k;
    my $t;
    my %rsp;
    my $ctlr;
    my %little;
    my @coList;
    my $added;
    my %vdisks;

    @coList = @$coPtr;       # get array of objects

    my @activity;
    my @activity2;


    # get the master so we can get vdisks info
    
    $i = TestLibs::IntegCCBELib::FindMaster($coPtr);
    if ( $i == INVALID )
    {
        logInfo("GetVdiskActivityCounts: Failed to get master");
        return ERROR;
    }
    $ctlr = $coList[$i];

    # get vdisks info for mirror check

    %vdisks = $ctlr->virtualDisks();
    if ( ! %vdisks  )              # if no return from call
    {
        logInfo("    ====> Failed to get response from virtualDisks command <====");
        return ERROR;
    }
    if ( $vdisks{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo("    ====> Error from virtualDisks command <====");
        PrintError(%vdisks);
        return ERROR;
    }



    # for each controller, get the vdisk list and counts 
    for ($i = 0; $i < scalar(@coList); $i++)
    {

        $ctlr = $coList[$i];
        %rsp = ControllerActiveVdiskListPart1($ctlr, "Q" );
        if ($rsp{STATUS} == PI_GOOD)
        {
            # status is good, extract the data
            for ( $j = 0; $j < $rsp{COUNT}; $j++)
            {
                
                
                # a little hash with a VID and total count
                $little{VID2} = $rsp{VDISKS}[$j]{VID};
                $little{COUNTS} =  $rsp{VDISKS}[$j]{RREQ} +
                                     $rsp{VDISKS}[$j]{WREQ};

                
                #
                # Make sure mirror destinations show 0 count
                #
                
                if ( IsVdiskMirrorDest($rsp{VDISKS}[$j]{VID}, \%vdisks ) )
                {
                    $little{COUNTS} = 0;
                }
                
                # save in an array of little hashes
                $added = 0;
                for ( $k = 0; $k < scalar(@activity); $k++)
                {

                    # look for existing item to add to
                    if ($activity[$k]{VID2} == $little{VID2} )
                    {
                        # combine into existing item
                        #print "merging ";
                        #print "$activity[$k]{VID2}  $little{VID2}  $activity[$k]{COUNTS} $little{COUNTS} \n";
                        $activity[$k]{COUNTS} += $little{COUNTS};
                        $added = 1;
                    }
                }
                if ( $added == 0)
                {
                    # new item, create new entry
                    
                    $t = scalar(@activity);
                    $activity[$t]{VID2} = $little{VID2};
                    $activity[$t]{COUNTS} = $little{COUNTS};

                }
            }
        }
    }

    if ( scalar(@activity) < 1 )
    {
        logInfo("No Vdisk activity count information found");
    }


    return @activity;
}
##############################################################################
#
#          Name: MakeActiveVdiskMap
#
#        Inputs: controller object list 
#
#       Outputs: 
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################
sub MakeActiveVdiskMap
{
    trace();
    my ($coPtr, $firstPtr, $threshold) = @_;

    my @first;
    my @second;
    my %little;
    my $matched;
    my @badAr;
    my $i;
    my $j;
    my $vid;
    my $count;
    my $totalActivity;
    my @activity;


    push ( @badAr, INVALID);

    @first = @$firstPtr;

    @second = GetVdiskActivityCounts($coPtr);  # get the current counts
    
    $totalActivity = 0;

    $matched = 0;

    #
    # Takes all items in the first array and looks for the matching one 
    # in the second. If a match found, then compute the change and
    # add the vdisk to the active array. If an item is only in the 
    # first list, and not in the second, it will not be 'active'. 
    # Ditto for the other way around. If things are going well,
    # both lists should always have the same members. 
    # 
    
    
    
    
    for ($i = 0; $i < scalar( @first ); $i++ )
    {
        # for each item in the first array...extract the data
        $vid = $first[$i]{VID2};
        $count = $first[$i]{COUNTS};

        #print " got $vid, $count \n";

        # get the matching entry in the second array
        for( $j = 0; $j < scalar(@second); $j++)
        {
            if ( $vid == $second[$j]{VID2} )
            {
                # item matched, now combine results
                $count= $second[$j]{COUNTS} - $count;

                $totalActivity += $count;


                logInfo(" Vdisk activity VID: $vid, count: $count");

                if ($count > $threshold)
                {
                    # the vdisk had enough activity
                    push( @activity, $vid );
                    $matched = 1;
                }
            }

        }
    }

    if ( $matched == 0 )
    {
        # no data was found, return invalid
        return @badAr;
    }

    # we are good.
    logInfo("Total vdisk activity = $totalActivity ");
    logInfo("");
    
    return SortAndRemoveDups(@activity);
}

##################################################################################
#
# Show targetst raids vdisls pdisks targets vcginfo for all good controllers
#
##################################################################################
sub ShowSystem
{
    my ($coPtr,  $master ) = @_;


    my @coList;
    my %rsp;
    my $i;
    my @ipList;
    my $j;
    my %info;

    my $k;
    my $owner;
    my $index;
    my @targets;
    my $bit;
    my $ret;
    my $retVal = GOOD;
    my $flag = 0;
    # turn array pointers into lists we can reference
    
    @coList = @$coPtr;


    # get vcginfo from the master to determine which controllers are alive vs. failed

    %rsp = $coList[$master]->XIOTech::cmdMgr::vcgInfo(0);
    
    if ( ! %rsp )              # if no return from call
    {
        logInfo("    ====> Failed to get response from vcgInfo <====");
        return INVALID;
    }

    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo("    ====> Error from vcgInfo <====");
        TestLibs::IntegCCBELib::PrintError(%rsp);
        return ERROR;
    }

    #
    # Walk vcginfo to get a list of good serial numbers (put in @goodSerials)
    #
    
    for ( $i = 0; $i < $rsp{VCG_MAX_NUM_CONTROLLERS}; ++$i)
    {
        if ($rsp{CONTROLLERS}[$i]{SERIAL_NUMBER} == 0)
        {
            # we skip ones that are not used
            next;
        }
        if ($rsp{CONTROLLERS}[$i]{FAILURE_STATE} == FD_STATE_OPERATIONAL)
        {
            # add this controller to the list
            push (@ipList, $rsp{CONTROLLERS}[$i]{IP_ADDRESS} );
        }
            
    }

    #
    # - Get data from each good controller
    #
    for ( $i = 0; $i < scalar(@ipList); $i++ )
    {
        # now look thru the snList to get the offset to the 
        # controller 
        for ($j = 0; $j <scalar(@coList); $j++ )
        {
            if ( $coList[$j]->{HOST} eq $ipList[$i] )
            {
                # matching SN, j is the index to the object list
                # nothing more to do in this list
                last;
            }    
        }

        logInfo(" ");
        logInfo(" ********************************  Data for $coList[$j]->{HOST} *****************************");

        # make sure we got a real one
        if ( $j >= scalar(@coList) )
        {
            # rolled past the end of the list, bad news
            logInfo("IP address not in the list, can't get target status");
            logInfo("  IP address to match: $ipList[$i]");
            next; 
            return ERROR;

        }


        # got the object index, now we can go get targetstatus

        %info = GetTargetStatus($coList[$j]);

        if ( ! %info  )              # if no data from call
        {
            logInfo("    ====> Failed to get a response from GetTargetStatus (nonfatal) <====");
            # we may be attempting to work on a dead controller, 
            # since this may be the case, ignore the failure
            #return ERROR;
            next;
        }

        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo("    ====> Error from GetTargetStatus  (nonfatal) <====");
            PrintError(%info);
            # we may be attempting to work on a dead controller, 
            # since this may be the case, ignore the failure
            #return ERROR;
            next;
        }

        LogTargetStatus( %info);
        
        
        %rsp = $coList[$j]->targets();
        if ( ! %rsp  )              # if no return from call
        {
            logInfo("    ====> Failed to get response from targets command <====");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo("    ====> Error from targets command <====");
            PrintError(%rsp);
            return ERROR;
        }
 
        logTargets(%rsp);


        logInfo("getting vcginfo ");

        $ret = DispVcgInfo($coList[$j]);
        if ( $ret == ERROR )
        {
            logInfo("    ====> Failed - Display VCG Info  <====");
            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;
        }

        logInfo("getting mirror partners ");

        %rsp = $coList[$j]->vcgMPList();

        if ( ! %rsp  )              # if no return from call
        {
            logInfo("    ====> Failed to get response from vcgMPList command <====");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo("    ====> Error from vcgMPList command <====");
            PrintError(%rsp);
            return ERROR;
        }

        logInfo($coList[$j]->displayVCGMPList(%rsp));


        logInfo("getting devstat PD info ");

        $ret = DispPdiskInfo($coList[$j]);
        if ( $ret == ERROR )
        {
            logInfo("    ====> Failed - Display Pdisk Info <====");
            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;
        }


        #
        # add in devicelist fe 0,1,2,3
        #


        for $k (0..3)
        {
          #Validate port and check to see if it is ISCSI or FC, based on which 
          #device list is retrieved
          
          &TestLibs::iscsi::ValidateTargetType($coList[$j], $k, \$flag);

            if ($flag == 1)
            {
                logInfo("Device List FE channel $k:");
                %rsp = $coList[$j]->deviceList("FE", $k);
                if ( ! %rsp  )              # if no return from call
                {
                    logInfo("    ====> Failed to get response from deviceList <====");
                    $retVal = ERROR;   # defer the return until all tests are done
                    #return ERROR;
                }
                if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
                {
                    if ( $rsp{ERROR_CODE} != $coList[$j]->PI_ERROR_INV_CHAN )
                    {
                        logInfo("    ====> Error from deviceList <====");
                        PrintError(%rsp);
                        $retVal = ERROR;   # defer the return until all tests are done
                        #return ERROR;
                    }
                    else
                    {
                        logInfo("No card on channel $k");
                    }
                }
                else
                {
                    logDeviceList(%rsp);
                }
            }
        }


        logInfo("getting vdisks info  ");
        %rsp = $coList[$j]->virtualDisks();
        if ( ! %rsp  )              # if no return from call
        {
            logInfo("    ====> Failed to get response from virtualDisks command <====");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo("    ====> Error from virtualDisks command <====");
            PrintError(%rsp);
            return ERROR;
        }

        logVirtualDisks(%rsp);
        

        logInfo("getting raids info  ");

        %info = $coList[$j]->raids();
        if ( ! %info  )              # if no return from call
        {
            logInfo("    ====> Failed to get response from raids command <====");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo("    ====> Error from raids command <====");
            PrintError(%info);
            return ERROR;
        }

        logRaids(%info);

        logInfo("");



        logInfo("getting pdisks info  ");
        %info = $coList[$j]->physicalDisks();
        if ( ! %info  )
        {
            logInfo("    ====> Failed to get response from physicalDisks <====");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo("    ====> Unable to get physicalDisks info <====");
            PrintError(%info);
            return ERROR;
        }

        logPhysicalDisks("STD", %info);




        
    }
    
    logInfo (" *******************************************************************************");

    # - return status

    return $retVal;

    
}

##############################################################################
# Name:     TestSystemState1
#
# Desc:     Test the state of the system
#           Checks for:
#               Valid VCG
#               Servo I/O still active
#
# Inputs:   coPtr - pointer ot a list of controllers
#           actServerPtr - pointer to list of active servers
#           targetListPtr - pointer to list of assigned targets 
#           vdiskListPtr - pointer to a list of active vdisks
#           snPtr - pointer to a list of serial numbers for the controllers
#
#           note: if activerServerPtr or targetListPtr or vdiskListPtr 
#                 is 0 then that specific 
#                 test for continued operation is skipped. spPtr is needed
#                 for the tartget map validation.
#
##############################################################################
sub TestSystemState1
{
    trace();
    my ($coPtr, $actServerPtr, $targetListPtr, $vdiskListPtr, $snPtr) = @_;
    my @coList = @$coPtr;
    my $rc = GOOD;

    my $ret;
    my $retVal;
    my %info1;
    my %rsp;

    my @tmap;
    my @sMap;
    my @vMap;
    my @sCounts;
    my @vCounts;
    my $thresholdV;
    my $thresholdS;
    my $samplePeriod;
    my @vList;
    my $i;
    my $msg;

    my %vdActivity1;
    my %servActivity1;

    $retVal = GOOD;

    ################################
    #
    # Tuned parameters for this fcn
    #
    ################################

    $thresholdV = 5;         # i/o transactions to consider active
    $thresholdS = 5;         # i/o transactions to consider active
    $samplePeriod = 90;       # sqample period (seconds)


    logInfo("_____Measuring system activity and current status check...begin_____");
    
    $i = _time();
    logInfo("_____[$i]_____");
    
    my $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $newMaster == INVALID )
    {
        logInfo("    ====> Failed to find the master controller <====");
        return ERROR;
    }

    ##########################################################
    #
    # Get initial activity counts for the servers and vdisks
    #
    ##########################################################

    @sCounts = GetServerActivityCounts($coPtr);

    @vCounts = GetVdiskActivityCounts($coPtr);



    ########################################
    #
    # delay to allow activity to accululate
    #
    ########################################

    logInfo("Pause $samplePeriod seconds allowing activity to accumulate");
    DelaySecs($samplePeriod);            # let activity counts acculumate


    ###############################################
    #
    # display the current state of the controller 
    #
    ###############################################
    
    
    $ret = ShowSystem($coPtr,  $newMaster );
    

    # add in the mirror partner list per TBOLT00008741

    $ret = MirrorPartnerCheck( $coList[$newMaster]);
    if ( $ret == ERROR )
    {
        logInfo("    ====> Failed - Mirror Partner check  <====");
        $retVal = ERROR;   # defer the return until all tests are done
        #return ERROR;
    }


    $ret = GroupTargetMap($coPtr, $snPtr, \@tmap, $newMaster, LOGTARGETMAP );
    if ( $ret != GOOD )  {return ERROR; }



    # if we have an active target list, compare against it the current
    if (($targetListPtr))
    {
        $ret = CompareTargetMap(\@tmap, $targetListPtr);
        if ( $ret == ERROR )
        {
            logInfo("    ====> Failed - Target maps didn't match  <====");
            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;
        }
        else
        {
            logInfo("The target maps matched.");
        }
    }

    ##################################################
    #
    # now get the second activity count reading and 
    # determine where the activity is
    #
    ##################################################


    @sMap = MakeActiveServerMap( $coPtr,  \@sCounts, $thresholdS );

    @vMap = MakeActiveVdiskMap( $coPtr,  \@vCounts, $thresholdV );


    ##############################################
    #
    # compare this round's activity with the 
    # last round's activity
    #
    ##############################################


    # if we have an active server list, compare against it the current
    if (($actServerPtr))
    {
        logInfo("Checking active server lists");
        $ret = CompareLists2(\@sMap, $actServerPtr);
        if ( $ret != GOOD )
        {
            logInfo("    ====> Comment - Active server lists didn't match  <====");

#            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;
        }
        else
        {
            logInfo("The active server lists matched.");
            logInfo("");
        }
    }

    # if we have an active vdisk list, compare against it the current
    if (($vdiskListPtr))
    {
        logInfo("Checking active vdisk lists");
        $ret = CompareLists2(\@vMap, $vdiskListPtr);
        if ( $ret != GOOD )
        {
            logInfo("    ====> Failed - Vdisk lists didn't match  <====");
            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;
        }
        else
        {
            logInfo("The active vdisk lists matched.");
            logInfo("");
        }
    }




    logInfo("_____Measuring system activity and current status check...end_____");

    return $retVal;
}


##############################################################################
# Name:     TestSystemState
#
# Desc:     Test the state of the system
#           Checks for:
#               Valid VCG
#               Servo I/O still active
#
# Inputs:   coPtr - pointer ot a list of controllers
#           actServerPtr - pointer to list of active servers
#           targetListPtr - pointer to list of assigned targets 
#           vdiskListPtr - pointer to a list of active vdisks
#           snPtr - pointer to a list of serial numbers for the controllers
#
#           note: if activerServerPtr or targetListPtr or vdiskListPtr 
#                 is 0 then that specific 
#                 test for continued operation is skipped. spPtr is needed
#                 for the tartget map validation.
#
##############################################################################
sub TestSystemState
{
    trace();
    my ($coPtr, $actServerPtr, $targetListPtr, $vdiskListPtr, $snPtr) = @_;
    my @coList = @$coPtr;
    my $rc = GOOD;

    my $ret;
    my $retVal;
    my %info1;
    my @tmap;
    my @vList;

    logInfo("finding the master");

    $retVal = GOOD;
    
    my $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $newMaster == INVALID )
    {
        logInfo("    ====> Failed to find the master controller  <====");
        return ERROR;
    }

    ###############################################
    # display the current state of the controller 
    ###############################################
    logInfo("getting vcginfo on $newMaster");

    $rc = DispVcgInfo($coList[$newMaster]);
    if ( $rc == ERROR )
    {
        logInfo("    ====> Failed - Display VCG Info  <====");
        $retVal = ERROR;   # defer the return until all tests are done
        #return ERROR;
    }

    logInfo("getting pdisk info on $newMaster");

    $ret = DispPdiskInfo($coList[$newMaster]);
    if ( $ret == ERROR )
    {
        logInfo("    ====> Failed - Display Pdisk Info  <====");
        $retVal = ERROR;   # defer the return until all tests are done
        #return ERROR;
    }

    logInfo("getting target status on $newMaster");

    $ret =  TargetList( $coList[$newMaster] );
    if ( $ret == ERROR )
    {
        logInfo("    ====> Failed - Display target status  <====");
        $retVal = ERROR;   # defer the return until all tests are done
        #return ERROR;
    }


    ######################################################
    # get the 1st set data for the ongoing activity tests
    ######################################################
    


    ##################################################
    # get the current target map and print it, even 
    # if we don't check it
    ##################################################
#    %info1 = GetTargetStatus($coList[$newMaster]);
#
#    if ( ! %info1  )              # if no data from call
#    {
#        logInfo(">>>>>>>> Failed to get response from GetTargetStatus <<<<<<<<");
#        return ERROR;
#    }
#    if ( $info1{STATUS} != PI_GOOD )      # if call returned an error
#    {
#        logInfo(">>>>>>>> Error from GetTargetStatus <<<<<<<<");
#        PrintError(%info1);
#        return ERROR;
#    }
#    
#    @tmap = CreateTargetMap($snPtr, %info1);
#    
#    PrintTargetMap (\@tmap);


    $ret = GroupTargetMap($coPtr, $snPtr, \@tmap, $newMaster, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }



    # if we have an active target list, compare against it the current
    if (($targetListPtr))
    {
        $ret = CompareTargetMap(\@tmap, $targetListPtr);
        if ( $ret == ERROR )
        {
            logInfo("    ====> Failed - Target maps didn't match  <====");
            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;
        }
        else
        {
            logInfo("The target maps matched.");
        }
    }

    
    #######################################
    # check for continuing server activity
    #######################################
    
    logInfo("checking server activity on servers");

    # if we have an active server list, compare against it
    if (($actServerPtr))
    {
        #Test for Servo IO
        $rc = TestForServerIO2($coPtr, $actServerPtr);
        if ( $rc == ERROR )
        {
            logInfo("    ====> Failed - Servo IO stopped  <====");
            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;

        }
    }


    
    #######################################################
    # get, display and test the current active vdisk list
    #######################################################
    
    @vList = ActiveVdiskList( \@coList );
    if ( scalar(@vList) != 0 )
    {
        # we have some active vdisks
        if ( $vList[0] == INVALID )
        {
            # error case 
            logInfo("    ====> Failed - can't get a current active vdisklist  <====");
            $retVal = ERROR;
        }
        else
        {
            # list is good

            logInfo("Current vdisk list: @vList ");
            #print("Current vdisk list: @vList \n");

            # if we have an active target list, compare against it
            if (($vdiskListPtr))
            {
                $ret = CompareLists2( \@vList, $vdiskListPtr); 
                if ( ($ret == ERROR) || ($ret == INVALID) )
                {
                    logInfo("    ====> Failed - vdisk Lists didn't match  <====");
                    $retVal = ERROR;   # defer the return until all tests are done
                    #return ERROR;
                }
            }
        }
    }
    else
    {
        # we got no list, but we also may be expecting no list
        if (($vdiskListPtr))
        {
            # this call works for empty lists, too
            $ret = CompareLists2( \@vList, $vdiskListPtr); 
            if ( ($ret == ERROR) || ($ret == INVALID) )
            {
                logInfo("    ====> Failed - vdisk Lists didn't match  <====");
                $retVal = ERROR;   # defer the return until all tests are done
                #return ERROR;
            }
        }

    }
    return $retVal;
}

##############################################################################
#
#          Name: TestBEState
#
#        Inputs: controller object list
#
#       Outputs: GOOD if all tests pass
#                ERROR if one or more fails
#                INVALID  on other error
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub TestBEState
{
    my ($coPtr) = @_;

    my @coList;
    my $master;
    my $retFlag;

    my $i;
    my $ctlr;

    my $ret;

    $retFlag = GOOD;

    @coList = @$coPtr;


    for ( $i = 0; $i < scalar(@coList); $i++ )
    {

        # rescan the BE so the status is current. This is done on all controllers.
        $ret = RescanBE( $coList[$i] , 1);
        if ( $ret != GOOD )
        {
            logInfo("    ====> Failure to rescan the BE on controller $coList[$i]->{HOST} <====");
            return ERROR;
        }
    }


    # get the master controller
    $master = TestLibs::IntegCCBELib::FindMaster($coPtr);

    # are the pdisks good

    logInfo("Checking the status on the pdisks....");
    $ret = CheckPdiskState($coList[$master]);
    if ( $ret != GOOD )
    {
        logInfo("Pdisks are not all good - check has failed");
        $retFlag = ERROR;
    }

    # are the vdisks good

    logInfo("Checking the status on the vdisks....");
    $ret = CheckVdiskState($coList[$master]);
    if ( $ret != GOOD )
    {
        logInfo("Vdisks are not all good - check has failed");
        $retFlag = ERROR;
    }

    # are the raids good

    logInfo("Checking the status on the raids....");
    $ret = CheckRaidState($coList[$master]);
    if ( $ret != GOOD )
    {
        logInfo("    ====> Raids are not all good - check has failed <====");
        $retFlag = ERROR;
    }

    # are we in an n-way with all good controllers

    logInfo("Checking the status on the controllers....");
    $ret = CheckVCGState($coList[$master]);
    if ( $ret != GOOD )
    {
        logInfo("    ====> VCG/controllers are not all good - check has failed <====");
        $retFlag = ERROR;
    }

    # are there server assocations

    #logInfo("Checking the status on the servers....");
    #$ret = CheckServerState($coList[$master]);
    #if ( $ret != GOOD )
    #{
    #    logInfo("No servers associations found - check has failed");
    #    $retFlag = ERROR;
    #}

    return $retFlag;
}
##############################################################################
#
#          Name: GetPdiskStateArray
#
#        Inputs: controller object 
#
#       Outputs: and array of key pdisk info, or an array with INVALID
#
#  Globals Used: none
#
#   Description: Looks at devstat PD for
#                 devStat 
#                 miscStat
#                 poststat
#
#                for all pdisks.
#
#                We input must be a good controller, otherwise this WILL 
#                return and log an error.
#  
##############################################################################
sub GetPdiskStateArray
{
    trace();
    my ($ctlr1) = @_;
    my %rsp;
    my $groupSN;
    my $badDriveCount;
    my $ourDriveCount;
    my $pdidTotal;
    my $retVal;
    my $i;
    my @badAr;
    my $pdData;
    my @drData;

    $badDriveCount = 0;
    $ourDriveCount = 0;
    $pdidTotal = 0;
    
    $badAr[0] = INVALID;

    # get our serial number to qualify the drives with
    $groupSN = GetGroupSerial($ctlr1);
    if ($groupSN == INVALID)
    {
        logInfo("Can get our serial number");
        return @badAr;
    }

    ########### devstat PD ################

    #logInfo("Physical disk information");

    %rsp = $ctlr1->deviceStatus("PD");

    if ( ! %rsp  )
    {
        logInfo("    ====> Failed to get response from deviceStatus <====");
        return @badAr;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get device status <====");
        PrintError(%rsp);
        return @badAr;
    }
    
    # now walk the returned data
    for $i (0..$#{$rsp{LIST}})
    {
        
       
        # get status on each of OUR drives

        if (  $groupSN == $rsp{LIST}[$i]{PD_SSERIAL} )
        {
            # build a single item representing the status
            $pdData = 
                  ($rsp{LIST}[$i]{PD_PID}      & 0xff) * 65536 * 256 +
                  ($rsp{LIST}[$i]{PD_DEVSTAT}  & 0xff) * 65536 +
                  ($rsp{LIST}[$i]{PD_MISCSTAT} & 0xff) * 256 +
                  ($rsp{LIST}[$i]{PD_POSTSTAT} & 0xff) ;
            
            $ourDriveCount++;
            
            push ( @drData, $pdData );

        }

    }      

    if ( $ourDriveCount > 0 )
    {
        #return the array

      #  logInfo("Pdisk status array: ");
      #  PrintList( \@drData, 8 );
      #  logInfo("");

        return @drData;
    }
    else
    {
        # return the error array instead
        return @badAr;
    }
}

##############################################################################
#
#          Name: GetBEStateHash
#
#        Inputs: controller object, pointer to status variable, type 
#
#       Outputs: hash with status
#
#  Globals Used: none
#
#   Description: type is "RD" "VD" or "PD"
#
#                The input must be a good controller, otherwise this WILL 
#                return and log an error.
#  
##############################################################################
sub GetBEStateHash
{
    trace();
    my ($ctlr1, $stsPtr, $type) = @_;
    my %rsp;

    $$stsPtr = GOOD;

    ########### devstat XX ################

    %rsp = $ctlr1->deviceStatus($type);

    if ( ! %rsp  )
    {
        logInfo("    ====> Failed to get response from deviceStatus <====");
        $$stsPtr = ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get device status <====");
        PrintError(%rsp);
        $$stsPtr = ERROR;
    }
    

    return %rsp;
}

##############################################################################
#
#          Name: CheckPdiskState
#
#        Inputs: controller object 
#
#       Outputs: GOOD if all tests pass
#                ERROR if one or more fails
#                INVALID  on other error
#
#  Globals Used: none
#
#   Description: Looks at devstat PD for
#                 devStat = 0x10
#                 miscStat = 0x00
#                 poststat = 0x10
#
#                for all pdisks.
#
#                We input must be a good controller, otherwise this WILL 
#                return and log an error.
#  
#                We also need to own at least 5 Pdisks
#
##############################################################################
sub CheckPdiskState
{
    trace();
    my ($ctlr1) = @_;
    my %rsp;
    my $groupSN;
    my $badDriveCount;
    my $ourDriveCount;
    my $pdidTotal;
    my $retVal;
    my $i;

    $badDriveCount = 0;
    $ourDriveCount = 0;
    $pdidTotal = 0;
    
    # get our serial number to qualify the drives with
    $groupSN = GetGroupSerial($ctlr1);
    if ($groupSN == INVALID)
    {
        logInfo("Can get our serial number");
        return ERROR;
    }

    ########### devstat PD ################

    #logInfo("Physical disk information");

    %rsp = $ctlr1->deviceStatus("PD");

    if ( ! %rsp  )
    {
        logInfo("    ====> Failed to get response from deviceStatus <====");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get device status <====");
        PrintError(%rsp);
        return ERROR;
    }
    
    # now walk the returned data
    for $i (0..$#{$rsp{LIST}})
    {
        
                                                         
        #print (" devstat  =  $rsp{LIST}[$i]{PD_DEVSTAT}  \n");
        #print (" miscstat =  $rsp{LIST}[$i]{PD_MISCSTAT} \n");
        #print (" poststat =  $rsp{LIST}[$i]{PD_POSTSTAT} \n");
        #print (" serial   =  $rsp{LIST}[$i]{PD_SSERIAL}  \n");

        
        # check status on each of OUR drives
#        if ((( DEVSTATUS_OPERATIONAL != $rsp{LIST}[$i]{PD_DEVSTAT} ) ||
#             ( 0 != $rsp{LIST}[$i]{PD_MISCSTAT} ) ||
#             ( 0x10 != $rsp{LIST}[$i]{PD_POSTSTAT} ) )  &&
#             ( $groupSN == $rsp{LIST}[$i]{PD_SSERIAL} ))
        if ((( DEVSTATUS_OPERATIONAL != $rsp{LIST}[$i]{PD_DEVSTAT} ) ||
             ( 0x10 != $rsp{LIST}[$i]{PD_POSTSTAT} ) )  &&
             ( $groupSN == $rsp{LIST}[$i]{PD_SSERIAL} ))
        {
            # one of our drives is bad
            logInfo("Bad drive PID = $rsp{LIST}[$i]{PD_PID}, ".
                    "devstat = $rsp{LIST}[$i]{PD_DEVSTAT}, ".
                    "poststat =  $rsp{LIST}[$i]{PD_POSTSTAT}, ".
                    "serial number = $rsp{LIST}[$i]{PD_SSERIAL} ");

            $badDriveCount++;
        }

        if ( $groupSN == $rsp{LIST}[$i]{PD_SSERIAL} )
        {
            # count our drives
            $ourDriveCount++;

            # sum the disk num ( sum tested later )
            $pdidTotal += $rsp{LIST}[$i]{PD_PID};
        }
      
    }
    
    # now see if things are really good 

    $retVal = GOOD;

    if ( $badDriveCount > 0 )  
    {
        logInfo("$badDriveCount drives are not completely good");
        $retVal = ERROR;
    }

    # an arbitrary number, reduced to 3 by Nick for 750
    if ( $ourDriveCount < 4 )
    {
        logInfo("Only $ourDriveCount pdisks were found for us. This is not enough.");
        $retVal = ERROR;
    }
    
    # this is another arbitrary number, reduced to 6 by Nick for 750 (4 pdisks)
    if ( $pdidTotal < 6 )
    {
        # this test actually verifies that the controller is ready.
        # if the controller was not ready, the pdid number s are all 0
        # and the total is small.
        logInfo("The controller does not appear to be ready.");
        $retVal = ERROR;
    }

    return $retVal;

}
##############################################################################
#
#          Name: CheckVdiskState
#
#        Inputs: controller object 
#
#       Outputs: GOOD if all vdisks are operational
#                ERROR if one or more is not
#
#  Globals Used: none
#
#   Description: Uses devstat VD to see if all vdisks are operational
#
#
##############################################################################
sub CheckVdiskState
{
    trace();
    my ($ctlr1) = @_;
    my %rsp;
    my $i;
    my $groupSN;
    my $badDriveCount;
    my $retVal;

    $badDriveCount = 0;
    

    ########### devstat VD ################



    %rsp = $ctlr1->deviceStatus("VD");

    if ( ! %rsp  )
    {
        logInfo("    ====> Failed to get response from deviceStatus <====");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get device status <====");
        PrintError(%rsp);
        return ERROR;
    }
    
    # now walk the returned data
    for $i (0..$#{$rsp{LIST}})
    {
        # check status on each of the drives
        if ( DEVSTATUS_OPERATIONAL != $rsp{LIST}[$i]{DEVSTAT} ) 
        {
            # one of our drives is bad
            logInfo("Bad vdisk VID = $rsp{LIST}[$i]{VID}, ".
                    "device status = $rsp{LIST}[$i]{DEVSTAT} ");
            $badDriveCount++;
        }
    }
    
    # now see if things are really good 

    $retVal = GOOD;

    if ( $badDriveCount > 0 )  
    {
        logInfo("$badDriveCount vdisks are not operational");
        $retVal = ERROR;
    }


    return $retVal;

}



##############################################################################
#
#          Name: GetVdiskStateArray
#
#        Inputs: controller object 
#
#       Outputs: GOOD if all vdisks are operational
#                ERROR if one or more is not
#
#  Globals Used: none
#
#   Description: Uses devstat VD to see if all vdisks are operational
#
#
##############################################################################
sub GetVdiskStateArray
{
    trace();
    my ($ctlr1) = @_;
    my %rsp;
    my $i;
    my $groupSN;
    my $ourDriveCount;
    my $retVal;

    $ourDriveCount = 0;
    my @vdData;

    my $t;

    my @badAr;

    $badAr[0] = INVALID;


    ########### devstat VD ################



    %rsp = $ctlr1->deviceStatus("VD");

    if ( ! %rsp  )
    {
        logInfo("    ====> Failed to get response from deviceStatus <====");
        return @badAr;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get device status <====");
        PrintError(%rsp);
        return @badAr;
    }
    
    # now walk the returned data
    for $i (0..$#{$rsp{LIST}})
    {
        
        $t = ( $rsp{LIST}[$i]{DEVSTAT} & 0xff  ) + 
             ( $rsp{LIST}[$i]{VID}     & 0xfff ) * 256;
        
        $ourDriveCount++;

        push ( @vdData, $t );

    }
    
    if ( $ourDriveCount > 0 )
    {
        #return the array
        
      #  logInfo("Vdisk status array: ");
      #  PrintList( \@vdData, 3 );
      #  logInfo("");

        return @vdData;
    }
    else
    {
        # return the error array instead
        return @badAr;
    }

}




##############################################################################
#
#          Name: CheckRaidState
#
#        Inputs: controller object 
#
#       Outputs: GOOD if all tests pass
#                ERROR if one or more fails
#                INVALID  on other error
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub CheckRaidState
{
    trace();
    my ($ctlr1) = @_;
    my %rsp;
    my $badDriveCount;
    my $badPSDCount;
    my $retVal;
    my $i;
    my $pi;
    my $astatus;

    $badDriveCount = 0;
    $badPSDCount = 0;
    

    ########### devstat RD ################


    %rsp = $ctlr1->deviceStatus("RD");

    if ( ! %rsp  )
    {
        logInfo("    ====> Failed to get response from deviceStatus <====");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get device status <====");
        PrintError(%rsp);
        return ERROR;
    }
    
    # now walk the returned data
    for $i (0..$#{$rsp{LIST}})
    {
        #print (" devstat: $rsp{LIST}[$i]{DEVSTAT} \n");
        #print (" astatus: $rsp{LIST}[$i]{ASTATUS} \n");

        # check status on each of the drives
        if (( DEVSTATUS_OPERATIONAL != $rsp{LIST}[$i]{DEVSTAT} ) ||
            ( 0 !=  $rsp{LIST}[$i]{ASTATUS}) )
        {
            if (5 !=  $rsp{LIST}[$i]{TYPE})
            {
                
                # one of our drives is bad
                logInfo("Bad raid # $rsp{LIST}[$i]{RID}, ".
                        "device status is $rsp{LIST}[$i]{DEVSTAT} ".
                        "Astatus = $rsp{LIST}[$i]{ASTATUS}   ");
                $badDriveCount++;
            }
        }
        else
        {
            
            #print(" psdcount $rsp{LIST}[$i]{PSDCNT} \n");
            
            # good raid, now also check the PSDs
            for ($pi = 0; $pi < $rsp{LIST}[$i]{PSDCNT}; $pi++)
                {
                    #print (" psd status  $rsp{LIST}[$i]{PIDS}[$pi]{PSD_STATUS} \n");
                    #print (" psd astatus  $rsp{LIST}[$i]{PIDS}[$pi]{PSD_ASTATUS} \n");

                    # fix to ignore a new bit in the psd astatus
                    $astatus = $rsp{LIST}[$i]{PIDS}[$pi]{PSD_ASTATUS};
                    if ($astatus & 128)
                    {
                        logInfo("    ====> Warning: psarebuildwait bit in astatus is set, ignoring. <====");
                        $astatus = $astatus & 127;
                    }


                    if (( DEVSTATUS_OPERATIONAL != $rsp{LIST}[$i]{PIDS}[$pi]{PSD_STATUS} ) ||
                        ( 0 != $astatus ))
                    {
                        # one of the PSDs was bad
                        logInfo("Bad PSD # $i, " .
                                "pid = $rsp{LIST}[$i]{PIDS}[$pi]{PID},".
                                "device status = $rsp{LIST}[$i]{PIDS}[$pi]{PSD_STATUS},".
                                "astatus = $rsp{LIST}[$i]{PIDS}[$pi]{PSD_ASTATUS} ");
                        $badPSDCount++;
                    }
                }    
        }

    }
    
    # now see if things are really good 

    $retVal = GOOD;

    if ( $badDriveCount > 0 )  
    {
        logInfo("$badDriveCount raids are not operational");
        $retVal = ERROR;
    }
    if ( $badPSDCount > 0 )  
    {
        logInfo("$badPSDCount PSDs are not operational");
        $retVal = ERROR;
    }


    return $retVal;

}



##############################################################################
#
#          Name: GetRaidStateArray
#
#        Inputs: controller object 
#
#       Outputs: GOOD if all tests pass
#                ERROR if one or more fails
#                INVALID  on other error
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub GetRaidStateArray
{
    trace();
    my ($ctlr1) = @_;
    my %rsp;
    my $badDriveCount;
    my $badPSDCount;
    my $retVal;
    my $i;
    my $pi;
    my $t;
    my $infoCount;
    my @raidList;
    my @badAr;

    $infoCount = 0;
    
    $badAr[0] = INVALID;

    

    ########### devstat RD ################


    %rsp = $ctlr1->deviceStatus("RD");

    if ( ! %rsp  )
    {
        logInfo("    ====> Failed to get response from deviceStatus <====");
        return @badAr;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get device status <====");
        PrintError(%rsp);
        return @badAr;
    }
    
    # now walk the returned data
    for $i (0..$#{$rsp{LIST}})
    {

        $t = ( $rsp{LIST}[$i]{RID} & 0xffff )  * 65536;        # raid id number

        $t = $t + ( $rsp{LIST}[$i]{DEVSTAT} & 0xff) * 256;

        $t = $t + ( $rsp{LIST}[$i]{ASTATUS} & 0xff);

        push ( @raidList, $t );
        $infoCount++;

        
        # good raid, now also check the PSDs
        for ($pi = 0; $pi < $rsp{LIST}[$i]{PSDCNT}; $pi++)
            {
                 
                $t = ( ($rsp{LIST}[$i]{PIDS}[$pi]{PID} & 0xff) + 0x8000 ) * 65536;

                $t = $t + ( $rsp{LIST}[$i]{PIDS}[$pi]{PSD_STATUS} & 0xff ) * 256;

                $t = $t + ( $rsp{LIST}[$i]{PIDS}[$pi]{PSD_ASTATUS} & 0xff );
                
                push ( @raidList, $t );
                $infoCount++;


             }    

    }
    


    if ( $infoCount > 0 )
    {
        #return the array
        
       # logInfo("Raid status array: ");
       # PrintList( \@raidList, 16 );
       # logInfo("");

        return @raidList;
    }
    else
    {
        # return the error array instead
        return @badAr;
    }

}




##############################################################################
#
#          Name: PrintList
#
#        Inputs: a list of data (numeric), code for the length to print 
#
#       Outputs: GOOD 
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub PrintList
{
    trace();
    my ($listPtr, $len) = @_;

    my @dList;
    my $lines;
    my $i;
    my $j;
    my $msg;

    @dList = @$listPtr;

    $lines = scalar(@dList);

    for ( $i = 0; $i < $lines; $i++ )
    {
        $msg = sprintf(" %4d: %08x ", $i, $dList[$i]);
        logInfo ($msg);

    }


    return GOOD;

}

##############################################################################
#
#          Name: CheckVCGState
#
#        Inputs: controller object 
#
#       Outputs: GOOD if all tests pass
#                ERROR if one or more fails
#                INVALID  on other error
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub CheckVCGState
{
    trace();

    my ($ctlr1) = @_;
    my %rsp;
    my $retVal;
    my $j;
    
    $retVal = GOOD;

    %rsp = $ctlr1->vcgInfo(0);
    
    if ( ! %rsp  )
    {
        logInfo("    ====> Failed to get response from vcgInfo <====");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get vcgInfo <====");
        PrintError(%rsp);
        return ERROR;
    }

    if (  $rsp{VCG_MAX_NUM_CONTROLLERS} >= 1)            
    {
        # check each controller listed
        for ( $j = 0; $j < $rsp{VCG_MAX_NUM_CONTROLLERS}; $j++ )   
        {
            if ($rsp{CONTROLLERS}[$j]{SERIAL_NUMBER} == 0)
            {
                next;
            }

            if ($rsp{CONTROLLERS}[$j]{FAILURE_STATE} != FD_STATE_OPERATIONAL) 
            {   
                
                logInfo("Bad controller s/n $rsp{CONTROLLERS}[$j]{SERIAL_NUMBER}, ".
                        "state is $rsp{CONTROLLERS}[$j]{FAILURE_STATE}");
                $retVal = ERROR;
            }
        }
    }

    return $retVal;
}
##############################################################################
#
#          Name: CheckServerState
#
#        Inputs: controller object 
#
#       Outputs: GOOD if all tests pass
#                ERROR if one or more fails
#                INVALID  on other error
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub CheckServerState
{
    return GOOD;
}

##############################################################################
#
#          Name: TestSystemState2
#
#        Inputs: controller object 
#
#       Outputs: GOOD if all tests pass
#                ERROR if one or more fails
#                INVALID  on other error
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub TestSystemState2
{
    my ($ctlr, $pdaPtr, $vdaPtr, $rdaPtr) = @_;    


    my @daNow;
    my $ret;
    my $rtn;
    my $msg;
    my @tArray;

    my $i;

    $rtn = GOOD;

    logInfo("_____Validating BE conditions...start______");

    # check ongoing Pdiskstatus
    logInfo("Pdisk status check.");
    @daNow = GetPdiskStateArray($ctlr);
    if ( $pdaPtr )
    {
        $ret = CompareLists2(\@daNow, $pdaPtr);
        if ( $ret != GOOD )
        {
            # since the data is really packed hex, display both sets
            
            $msg = "  Current List:";
            for ( $i = 0; $i < scalar(@daNow); $i++ )
            {
                $msg .= sprintf(" 0x%08x",$daNow[$i]);
            }
            logInfo($msg);

            @tArray = @$pdaPtr;           # make array
            $msg = "Reference List:";
            for ( $i = 0; $i < scalar(@tArray); $i++ )
            {
                $msg .= sprintf(" 0x%08x",$tArray[$i]);
            }
            logInfo($msg);

            $rtn = ERROR;
        }
    }

    # check ongoing vdisk status
    logInfo("Vdisk status check.");
    @daNow = GetVdiskStateArray($ctlr);
    if ( $vdaPtr )
    {
        $ret = CompareLists2(\@daNow, $vdaPtr);
        if ( $ret != GOOD )
        {
            # since the data is really packed hex, display both sets
            
            $msg = "  Current List:";
            for ( $i = 0; $i < scalar(@daNow); $i++ )
            {
                $msg .= sprintf(" 0x%08x",$daNow[$i]);
            }
            logInfo($msg);

            @tArray = @$vdaPtr;           # make array
            $msg = "Reference List:";
            for ( $i = 0; $i < scalar(@tArray); $i++ )
            {
                $msg .= sprintf(" 0x%08x",$tArray[$i]);
            }
            logInfo($msg);

            $rtn = ERROR;
        }
    }

    # check ongoing raid status
    logInfo("Raid status check.");
    @daNow = GetRaidStateArray($ctlr);
    if ( $rdaPtr )
    {
        $ret = CompareLists2(\@daNow, $rdaPtr);
        if ( $ret != GOOD )
        {
            # since the data is really packed hex, display both sets
            
            $msg = "  Current List:";
            for ( $i = 0; $i < scalar(@daNow); $i++ )
            {
                $msg .= sprintf(" 0x%08x",$daNow[$i]);
            }
            logInfo($msg);

            @tArray = @$rdaPtr;           # make array
            $msg = "Reference List:";
            for ( $i = 0; $i < scalar(@tArray); $i++ )
            {
                $msg .= sprintf(" 0x%08x",$tArray[$i]);
            }
            logInfo($msg);

            $rtn = ERROR;
        }
    }


    # is the right one failed (vcginfo)

    logInfo("_____Validating BE conditions...complete______");

    return $rtn;
}
###############################################################################

=head2 TestSystemState3 function

A function for validating BE status that looks for changes relative to an
earlier set of collected data. (The actual state is less important, any
changes are considered significant.) This function will detect changes in
any previously existing data or data that goes away. It will not detect 
anything new that appears. 


=cut

=over 1

=item Usage:

 my $rc = TestSystemState3($ctlr, $mirrorDataPtr);
 
 where: $ctlr is a controller object
        $mirrorDataPtr is a pointer to the initial mirror data which includes:
            PDISKS - pdisks hash
            VDISKS - vdisks hash
            RAIDS  - raids hash
       

=item Returns:

       $rc will be GOOD or ERROR. GOOD indicates the current hash and the 
           reference hash matched. ERROR indicates there was a detected 
           difference in the hashes. Note: Not all of the hash elements are 
           checked.

=item Things to look for:
 
 The logs should contain useful information about any differences found.

=item Initial Conditions:

 The input hashes should contain good data. When first gathered they should 
 be validated with CheckBEHashes().


=back

=cut

##############################################################################
sub TestSystemState3
{
    my ($ctlr, $mirrorDataPtr) = @_;    

    my @daNow;
    my $ret;
    my $rtn;
    my $msg;
    my @tArray;

    my $i;
    my $pi;
    my $j;
    my $pj;

    my %raidsHash; 
    my %pdisksHash;
    my %vdisksHash;
    

    $rtn = GOOD;

    logInfo("_____Validating BE conditions...start______(tss3)");

    #
    # get the 'now' samples
    #
    %raidsHash =  $ctlr->raids();
    %pdisksHash = $ctlr->physicalDisks();
    %vdisksHash = $ctlr->virtualDisks();
    

    #
    # For each of the tests below, we are not assured that the arrays will be presented 
    # in the same order. Therefore, for each thing we are testing, we need to find the
    # correct array index in the current data. This is done by the FindXxxIndex() 
    # functions.
    #
    
    #
    # For each of the below tests we make sure the status for each item in the original
    # data is found, and the same, in the new sample. Failure comes from the status
    # being different, or missing in the new sample. New items, for example and added 
    # vdisk in the new data will not cause a failure.
    #
    

    #
    # check ongoing Pdiskstatus. We don't look at all the data for the pdisks, only the
    # status is important.
    #
    logInfo("Pdisk status check.");

    for ($i = 0; $i < $$mirrorDataPtr{PDISKS}{COUNT}; $i++)
    {
        
        #
        # first find the matching PID in the new data
        #
        $pi = FindPidIndex( \%pdisksHash, $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_PID} );
        if ($pi == INVALID)
        {
            logInfo("Could not find the matching pdisk record for PID $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_PID}");
            $rtn = ERROR;
            next;
        }
        
        #
        # Check ongoing PDISKS status
        #
        if( $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_DEVSTAT} !=  $pdisksHash{PDISKS}[$pi]{PD_DEVSTAT} )
        {
            $msg = sprintf("    ====> PID %3hu  devStat change: was 0x%02x, now 0x%02x ", 
                            $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_PID}, 
                            $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_DEVSTAT}, 
                            $pdisksHash{PDISKS}[$pi]{PD_DEVSTAT});

            if ( $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_CLASS} == 0 )                 # unlabeled check                
            {
                $msg .=  " - Ignored, disk is unlabeled.";
            }
            else
            {
                $rtn = ERROR;
            }
            logInfo($msg);
        }

        if( $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_MISCSTAT} !=  $pdisksHash{PDISKS}[$pi]{PD_MISCSTAT} )
        {
            $msg = sprintf("    ====> PID %3hu miscStat change: was 0x%02x, now 0x%02x ", 
                            $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_PID}, 
                            $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_MISCSTAT}, 
                            $pdisksHash{PDISKS}[$pi]{PD_MISCSTAT});

            if ( $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_CLASS} == 0 )                 # unlabeled check                
            {
                $msg .=  " - Ignored, disk is unlabeled.";
            }
            else
            {
                $rtn = ERROR;
            }
            logInfo($msg);
        }

        if( $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_POSTSTAT} !=  $pdisksHash{PDISKS}[$pi]{PD_POSTSTAT} )
        {
            $msg = sprintf("    ====> PID %3hu postStat change: was 0x%02x, now 0x%02x ", 
                            $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_PID}, 
                            $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_POSTSTAT}, 
                            $pdisksHash{PDISKS}[$pi]{PD_POSTSTAT});

            if ( $$mirrorDataPtr{PDISKS}{PDISKS}[$i]{PD_CLASS} == 0 )                 # unlabeled check                
            {
                $msg .=  " - Ignored, disk is unlabeled.";
            }
            else
            {
                $rtn = ERROR;
            }
            logInfo($msg);
        }
    }


    #
    # check ongoing VDISKS status
    #
    logInfo("Vdisk status check.");

    for ($i = 0; $i < $$mirrorDataPtr{VDISKS}{COUNT}; $i++)
    {
        #
        # first find the matching VID in the new data
        #
        $pi = FindVidIndex( \%vdisksHash, $$mirrorDataPtr{VDISKS}{VDISKS}[$i]{VID} );
        if ($pi == INVALID)
        {
            logInfo("Could not find the matching vdisk record for VID $$mirrorDataPtr{VDISKS}{VDISKS}[$i]{VID}");
            $rtn = ERROR;
            next;
        }

        if( $$mirrorDataPtr{VDISKS}{VDISKS}[$i]{DEVSTAT} !=  $vdisksHash{VDISKS}[$pi]{DEVSTAT} )
        {
            $msg = sprintf("    ====> VID %3h   devStat change: was 0x%02x, now 0x%02x \n", 
                            $$mirrorDataPtr{VDISKS}{VDISKS}[$i]{VID}, 
                            $$mirrorDataPtr{VDISKS}{VDISKS}[$i]{DEVSTAT}, 
                            $vdisksHash{VDISKS}[$pi]{DEVSTAT});
            logInfo($msg);
            $rtn = ERROR;
        }

        #
        # Add check for write cache
        #
        if( ($$mirrorDataPtr{VDISKS}{VDISKS}[$i]{ATTR} & 0x0100) != 
                ($vdisksHash{VDISKS}[$pi]{ATTR} & 0x0100) )
        {
            $msg = sprintf("    ====> VID %3h   ATTR change: was 0x%04x, now 0x%04x \n", 
                            $$mirrorDataPtr{VDISKS}{VDISKS}[$i]{VID}, 
                            $$mirrorDataPtr{VDISKS}{VDISKS}[$i]{ATTR}, 
                            $vdisksHash{VDISKS}[$pi]{ATTR});
            logInfo($msg);
            $rtn = ERROR;
         }

    }



    #
    # check ongoing RAIDS status
    #
    logInfo("Raid status check.");


    for ($i = 0; $i < $$mirrorDataPtr{RAIDS}{COUNT}; $i++)
    {
    
        # first find the matching RID in the new data
        
        $pi = FindRidIndex( \%raidsHash, $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{RID} );
        if ($pi == INVALID)
        {
            logInfo("Could not find the matching raid record for RID $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{RID}");
            $rtn = ERROR;
            next;
        }
    
        if( $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{DEVSTAT} !=  $raidsHash{RAIDS}[$pi]{DEVSTAT} )
        {
            $msg = sprintf("    ====> RID %3hu  devStat change: was 0x%02x, now 0x%02x \n", 
                            $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{RID}, 
                            $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{DEVSTAT}, 
                            $raidsHash{RAIDS}[$pi]{DEVSTAT});
            logInfo($msg);
            $rtn = ERROR;
        }

        if( $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{ASTATUS} !=  $raidsHash{RAIDS}[$pi]{ASTATUS} )
        {
            $msg = sprintf("    ====> RID %3hu  Astatus change: was 0x%02x, now 0x%02x \n", 
                            $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{RID}, 
                            $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{ASTATUS}, 
                            $raidsHash{RAIDS}[$pi]{ASTATUS});
            logInfo($msg);
            $rtn = ERROR;
        }

        #
        # a loop thru all the PSDs for this raid
        #
        for ( $j = 0; $j <  $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{PSDCNT}; $j++ )
        {

            # first find the matching PSD in the new data
        
            $pj = FindPsdIndex( \%raidsHash, $pi, $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{PIDS}[$j]{PID} );
            if ($pj == INVALID)
            {
                logInfo("Could not find the matching PSD record for PID $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{PIDS}[$j]{PID} for raid $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{RID}.");
                $rtn = ERROR;
                next;
            }

            
            if( $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{PIDS}[$j]{PSD_STATUS} !=  
                $raidsHash{RAIDS}[$pi]{PIDS}[$pj]{PSD_STATUS} )
            {
                $msg = sprintf("    ====> PSD %3hu   Status change: was 0x%02x, now 0x%02x (raid %4hu)\n", 
                                $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{PIDS}[$j]{PID}, 
                                $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{PIDS}[$j]{PSD_STATUS}, 
                                $raidsHash{RAIDS}[$pi]{PIDS}[$pj]{PSD_STATUS},
                                $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{RID});
                logInfo($msg);
                $rtn = ERROR;
            }

            if( $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{PIDS}[$j]{PSD_ASTATUS} !=  
                $raidsHash{RAIDS}[$pi]{PIDS}[$pj]{PSD_ASTATUS} )
            {
                $msg = sprintf("    ====> PSD %3hu  Astatus change: was 0x%02x, now 0x%02x (raid %4hu) \n", 
                                $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{PIDS}[$j]{PID}, 
                                $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{PIDS}[$j]{PSD_ASTATUS}, 
                                $raidsHash{RAIDS}[$pi]{PIDS}[$pj]{PSD_ASTATUS},
                                $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{RID});
                logInfo($msg);
                
                #
                # fix to ignore a new bit in the psd astatus
                # 
                if( (127 & $$mirrorDataPtr{RAIDS}{RAIDS}[$i]{PIDS}[$j]{PSD_ASTATUS}) ==  
                    (127 & $raidsHash{RAIDS}[$pi]{PIDS}[$pj]{PSD_ASTATUS}) )
                {
                    logInfo("    ====> Note: only psarebuildwait bit in astatus has changed, ignoring.");
                }
                else
                {                
                    $rtn = ERROR;
                }
                
            }


        }
    }


    # all done.

    logInfo("_____Validating BE conditions...complete______(tss3)");
    if ($rtn == GOOD)
    {
        logInfo("BE Validation successful.");
    }
    else
    {
        logInfo("    ====> BE Validation Failed <==== ");
    }

    return $rtn;
}

######################################################################################
###############################################################################

=head2 FindPidIndex function

This is an internal function used to find the index to a specific PID in a 
pdisks hash. It is used by validation functions for the BE.

=cut

=over 1

=item Usage:

 my $rc = FindPidIndex( $pHashPtr,  $pid );
 
 where: $pHashPtr is a pointer to a 'pdisks' hash
        $pid is the PID for the desired vdisk
       

=item Returns:

       $rc will be the index to the pdisk, or INVALID if a match
           is not found.

=item Things to look for:
 

=item Initial Conditions:





=back

=cut

##############################################################################
sub FindPidIndex
{
    my ( $pHashPtr, $pid ) = @_;
    
    my $i;

    for ($i = 0; $i < $$pHashPtr{COUNT} ; $i++)
    {
        if ( $pid == $$pHashPtr{PDISKS}[$i]{PD_PID} )
        {
            return $i;
        }
    }


    return INVALID;

}
######################################################################################
###############################################################################

=head2 FindVidIndex function

This is an internal function used to find the index to a specific VID in a 
vdisks hash. It is used by validation functions for the BE.

=cut

=over 1

=item Usage:

 my $rc = FindVidIndex( $pHashPtr,  $vid );
 
 where: $pHashPtr is a pointer to a 'vdisks' hash
        $vid is the VID for the desired vdisk
       

=item Returns:

       $rc will be the index to the vdisk, or INVALID if a match
           is not found.

=item Things to look for:
 

=item Initial Conditions:





=back

=cut

##############################################################################
sub FindVidIndex
{
    my ( $pHashPtr, $vid ) = @_;
    
    my $i;

    for ($i = 0; $i < $$pHashPtr{COUNT} ; $i++)
    {
        if ( $vid == $$pHashPtr{VDISKS}[$i]{VID} )
        {
            return $i;
        }
    }

    return INVALID;

}
######################################################################################
###############################################################################

=head2 FindRidIndex function

This is an internal function used to find the index to a specific RAID in a 
raids hash. It is used by validation functions for the BE.

=cut

=over 1

=item Usage:

 my $rc = FindRidIndex( $pHashPtr,  $rid );
 
 where: $pHashPtr is a pointer to a 'raids' hash
        $rid is the RID for the desired raid
       

=item Returns:

       $rc will be the index to the raid, or INVALID if a match
           is not found.

=item Things to look for:
 

=item Initial Conditions:





=back

=cut

##############################################################################
sub FindRidIndex
{
    my ( $pHashPtr, $rid )  = @_;
    
    my $i;

    for ($i = 0; $i < $$pHashPtr{COUNT} ; $i++)
    {
        if ( $rid == $$pHashPtr{RAIDS}[$i]{RID} )
        {
            return $i;
        }
    }

    return INVALID;

}
######################################################################################

###############################################################################

=head2 FindPsdIndex function

This is an internal function used to find the index to a specific PSD in a 
raids hash. It is used by validation functions for the BE.

=cut

=over 1

=item Usage:

 my $rc = FindPsdIndex( $pHashPtr, $idx, $pid );
 
 where: $pHashPtr is a pointer to a 'raids' hash
        $idx is the index to the specific raid
        $pid is the PID for the desired PSD
       

=item Returns:

       $rc will be the index to the PSD, or INVALID f a match
           is not found.

=item Things to look for:
 

=item Initial Conditions:

 It is assumed that the has does have the $idx+1 raids.




=back

=cut

##############################################################################
sub FindPsdIndex
{
    my ( $pHashPtr, $idx, $pid ) = @_;
    
    my $i;

    for ($i = 0; $i < $$pHashPtr{RAIDS}[$idx]{PSDCNT} ; $i++)
    {
        if ( $pid == $$pHashPtr{RAIDS}[$idx]{PIDS}[$i]{PID} )
        {
            return $i;
        }
    }

    return INVALID;

}


##############################################################################
#
#          Name: FEPortMatrix
#
#        Inputs: controller object for master, sample duration
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub FEPortMatrix
{
    my ($ctlr) = @_;

    my %rsp;
    my $i;
    my $j;
    my @mx;
    my @er;
    my $sz;

    $er[0] = INVALID;

    for ( $i = 0; $i < 4; $i++ )
    {
        # clear mx array
        $mx[$i] = 0;
    }

    for ( $i = 0; $i < 6; $i++ )
    {
        
        %rsp = $ctlr->getPortList(PI_PROC_FE_PORT_LIST_CMD, $i);

        if ( ! %rsp )
        {
            # no response
            return @er;
        }
        elsif ($rsp{STATUS} == 1)             # 1 is bad
        {
            logInfo("    ====> Failed: getPortList returned an error <====");
            PrintError(%rsp);
            logInfo("Failure in FEPortMatrix");
            return @er;
        }

        $sz = 1 + $#{$rsp{LIST}};

        #print "list type, = $i, size = $sz \n";

        for ( $j = 0; $j< $sz; $j++ )
        {
            
            #print "list has $rsp{LIST}[$j] \n";

            $mx[$rsp{LIST}[$j]] |= 1 << $i;
        }
    }

    #print "@mx \n";

    return @mx;
}

##############################################################################
#
#          Name: FailOverTimeLine
#
#        Inputs: controller object for master, sample duration
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub FailOverTimeLine
{
    my ($ctlr, $duration, $snPtr, $ctlr2) = @_;

    my $time1;
    my $time2;
    my $ret;
    my %rsp;
    my %vdaData1;
    my %vdaData2;
    my $elState;
    my @activeList;
    my @activeList2;
    my $msg;
    my %info1;
    my @tMap;
    my @fepm;
    my $i;
    my @qlData;
    my $stopCount;
    my $stopCount2;
    my $vdaFlag;
    my $orc;
    my $orc2;
    my $orcAddr;

    my @sCounts;
    my @sCounts2;
    my @sMap;
    my @coList;
    my $rms;

    # get starting "now" time
    $time1 = time;

    $time2 = $time1;

    # while "now" < (starting "now" + duration)
    
    $orcAddr = 0x340;         # need something better here...

    $coList[0] = $ctlr;
    if ($ctlr2)
    {
        $coList[1] = $ctlr2;
    }


    logInfo ("Fail-over time line begin....");

    while ( ($time1 + $duration) > $time2 )
    { 
        
        $time2 = time;
        ###########################
        # get election status data
        ###########################
        %rsp = $ctlr->vcgElectionState();

        # see how getting the slave's status went
        if (!%rsp)                         # no response
        {
            logInfo("    ====> Failed to receive a response from ELECTION status <====");
            $elState = -1;
            #return ERROR;
        }
        elsif ($rsp{STATUS} == 1)             # 1 is bad
        {
            logInfo("    ====> Failed: getting election status returned an error <====");
            PrintError(%rsp);
            logInfo("Failure in FailOverTimeLine");
            $elState = -1;
            #return ERROR;
        }
        else
        {
            $elState =  $rsp{STATE};
        }
            
        # initialize this here, so it will be correct if we are in an election
        $stopCount = "-";
        $stopCount2 = "-";
        $orc2 = "-----";
        $rms = 0;

        if ( $elState == 0 )
        {

            ######################################
            # get the first vdisk activity sample
            ######################################
            $vdaFlag = GOOD;

            %vdaData1 = ControllerActiveVdiskListPart1($ctlr);     # get the initial reading
            if (  $vdaData1{STATUS} != PI_GOOD  )
            {
                logInfo("Error from from ControllerActiveVdiskListPart1 (ctlr1)");
                $vdaFlag = ERROR;
            }

        
            if ( $ctlr2 )
            {
                %vdaData2 = ControllerActiveVdiskListPart1($ctlr2);     # get the initial reading
                if ( $vdaData2{STATUS} != PI_GOOD )
                {
                    logInfo("Error from from ControllerActiveVdiskListPart1 (ctlr2)");
                    $vdaFlag = ERROR;
                }
            }

            ######################################
            # get the first server activity sample
            ######################################
#
#            @sCounts = GetServerActivityCounts(\@coList);
#


            ########################
            # get port map data
            ########################


            @tMap = GetTargetsDataMap($ctlr, $snPtr);

            ########################
            # get resource manager state
            ########################
            $rms = GetRMState($ctlr);



            ########################
            # get stop counts
            ########################
            $stopCount = -1;
            %rsp = $ctlr->globalCacheInfo();
    
            if ( ! %rsp  )
            {
                logInfo("    ====> Failed to get globalCacheInfo from controller <====");
                #return (ERROR);
            }

            if (%rsp)
            {
                if ($rsp{STATUS} == PI_GOOD)
                {

                    $stopCount = sprintf("%1d", $rsp{CA_STOPCNT});
                    # $ctlr->displayGlobalCacheInfo(%rsp);
                    # logInfo("Master stop count = $stopCount ");
                }
                else
                {
                    logInfo("    ====> Error getting globalCacheInfo from controller <====");
                    PrintError(%rsp);
                    #return ERROR;
                }
            }


            if ( $ctlr2 )
            {
                %rsp = $ctlr2->globalCacheInfo();
    
                if ( ! %rsp  )
                {
                    logInfo("    ====> Failed to get globalCacheInfo from second controller <====");
                    #return (ERROR);
                }

                if (%rsp)
                {
                    if ($rsp{STATUS} == PI_GOOD)
                    {
                        $stopCount2 = sprintf("%1d", $rsp{CA_STOPCNT});
                        # $ctlr->displayGlobalCacheInfo(%rsp);
                        # logInfo("Master stop count = $stopCount ");
                    }
                    else
                    {
                        logInfo("    ====> Error getting globalCacheInfo from second controller <====");
                        PrintError(%rsp);
                        #return ERROR;
                    }    
                }
            }

            ########################################
            # Outstanding request counts FE @ 0x340
            ########################################



       #     %rsp = $ctlr->ReadMemory($orcAddr, 4, "FE");
       #     if ( ! %rsp  )              # if no return from call
       #     {
       #         logInfo(">>>>>>>> Failed to get response from ReadMemory <<<<<<<<");
       #         return ERROR;
       #     }
       #     if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
       #     {
       #         logInfo(">>>>>>>> Error from ReadMemory <<<<<<<<");
       #         PrintError(%rsp);
       #         return ERROR;
       #     }
       #
       #     $orc = unpack("L", $rsp{RD_DATA});
       #
       #
       #     if ( $ctlr2 )
       #     {
       #         %rsp = $ctlr2->ReadMemory($orcAddr, 4, "FE");
       #         if ( ! %rsp  )              # if no return from call
       #         {
       #             logInfo(">>>>>>>> Failed to get response from ReadMemory <<<<<<<<");
       #             return ERROR;
       #         }
       #         if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
       #         {
       #             logInfo(">>>>>>>> Error from ReadMemory <<<<<<<<");
       #             PrintError(%rsp);
       #             return ERROR;
       #         }
       # 
       #         $orc2 = sprintf("%5d", unpack("L", $rsp{RD_DATA}) );
       #     }
       #


            ##########################
            # get Qlstatus data for FE
            ##########################

            # nothing yet
            @fepm = FEPortMatrix($ctlr);



            #########################
            # get vdisk activity data
            #########################
            
            if (  $vdaFlag == GOOD  )
            {
                @activeList = ControllerActiveVdiskListPart2($ctlr, \%vdaData1, 2, 3, "Q");
        
                if ( $ctlr2 )
                {
                    @activeList2 = ControllerActiveVdiskListPart2($ctlr2, \%vdaData2, 2, 3, "Q");
                }
            }
            else
            {
                @activeList = (INVALID);
                @activeList2 = (INVALID);
            }
            # got all the data
        }
        else
        {
            @tMap = (0,0,0,0,0,0,0,0);
            @activeList = (INVALID);
            @activeList2 = (INVALID);
            @fepm = (0,0,0,0);
            sleep(1);
        }

        #########################
        # finish server activity
        #########################
#
#        @sMap = MakeActiveServerMapQ( \@coList,  \@sCounts, 2 );
#

        # format and print data
        ########################

        # time stamp
        $msg = sprintf("TimeLine:[%3d] ", ($time2 - $time1));

        # election state
        $msg .= sprintf("El:%3d ", $elState);

        # stop count
        $msg .= sprintf("SC:%1s ", $stopCount);
        $msg .= sprintf("S2:%1s ", $stopCount2);

        # resource manager state
        $msg .= sprintf("RM:%2d ", $rms);

        # outstanding request counts
   #     $msg .= sprintf("ORC:%5d ", $orc);
   #     $msg .= sprintf("OR2:%5s ", $orc2);


        # qlogic status 
        $msg .= "FEQL: ";
        for ( $i = 0; $i < scalar(@fepm); $i++ ) 
        {
            $msg .= sprintf("%02x ", $fepm[$i]);
        }
        
        # target map
        $msg .= "Tmap: ";
        for ( $i = 0; $i < scalar(@tMap); $i++ ) 
        {
            $msg .= sprintf("%04x ", $tMap[$i]);
        }
        

        # vdisks
        $msg .= "VD:";

        for ($i = 0; $i < scalar(@activeList); $i++ )
        {
            $msg .= sprintf(" %3d", $activeList[$i]);
        }
        if ($ctlr2 != 0)
        {
            for ($i = 0; $i < scalar(@activeList2); $i++ )
            {
                $msg .= sprintf(" %3d", $activeList2[$i]);
            }
        }


        

        ###########
        # print it
        ###########

        logInfo($msg);
#
#        print ("                                            Servers: @sMap \n");
#

    }
    # return

    logInfo ("Fail-over time line end");


    return GOOD;
}
##############################################################################



##############################################################################
#
#          Name: FailOverTimeLineNway
#
#        Inputs: controller object list ptr,
#                sample duration,
#                serial number list ptr
#                ptr to list of known missing ctlrs
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: 
#
#
##############################################################################
sub FailOverTimeLineNway
{
    my ($coPtr, $duration, $snPtr, $skipPtr) = @_;

    my $time1;
    my $time2;
    my $ret;
    my %rsp;
    my %vdaData1;
    my %vdaData2;
    my @activeList;
    my @activeList2;
    my $msg;
    my %info1;
    my @fepm;
    my $i;
    my $j;
    my @qlData;
    my $vdaFlag;
    my $orcAddr;

    my @sCounts;
    my @sCounts2;
    my @sMap;
    my @coList;

    my $elState;
    my $stopCount;
    my @tMap;
    my $RMState;
    my $CNodes;
    my $QLFlags;
    my $orCount;
    my $timePrinted;


    # get starting "now" time
    $time1 = time;

    $time2 = $time1;

    # while "now" < (starting "now" + duration)
    
    $orcAddr = 0x340;         # need something better here...

#    $coList[0] = $ctlr;
#   if ($ctlr2)
#   {
#        $coList[1] = $ctlr2;
#    }

    logInfo("");
    logInfo("");
    logInfo("");

    logInfo ("Fail-over time line begin....");

    while ( ($time1 + $duration) > $time2 )
    { 
        
        # loop thru each of the controller objects and collect its 
        # data for the timeline

        $time2 = time;
        $timePrinted = 0;

        for ( $i = 0; $i < scalar(@$coPtr); $i++ )
        {
            # initialize the data for this controller to defaults

            $elState = -1;                       # election state
            $stopCount = "-";                    # stop count
            $RMState = 0;                        # resource manager state
            $CNodes = $$snPtr[$i] & 0x0f;        # CNC Node
            $QLFlags = 0;
            @fepm = (0,0,0,0);                   # Qlogic FE port matrix (port list data)
            @tMap = (0, 0, 0, 0);    # target map (need more 0s)
            $orCount = 0;
            @activeList = (INVALID);             # active vdisk list

            # now verify that this is an available controller to use
            # (We skip the ones we know are dead/failed)

            if ( IsInList($i, $skipPtr) )
            {   
                next;
            }

            # Ok, this should be a good controller, now collect the data
            # for it.

        
            ###########################
            # get election status data
            ###########################
            %rsp = $$coPtr[$i]->vcgElectionState();

            # see how getting the slave's status went
            if (!%rsp)                         # no response
            {
                logInfo("    ====> Failed to receive a response from ELECTION status <====");
                $elState = -1;
                #return ERROR;
            }
            elsif ($rsp{STATUS} == 1)             # 1 is bad
            {
                logInfo("    ====> Failed: getting election status returned an error <====");
                PrintError(%rsp);
                logInfo("Failure in FailOverTimeLine");
                $elState = -1;
                #return ERROR;
            }
            else
            {
                $elState =  $rsp{STATE};
            }
            

            # we only do the following if we are not in an election
            
            if ( $elState == 0 )
            {

                ######################################
                # get the first vdisk activity sample
                ######################################
                $vdaFlag = GOOD;

                %vdaData1 = ControllerActiveVdiskListPart1($$coPtr[$i]);     # get the initial reading
                if (  $vdaData1{STATUS} != PI_GOOD  )
                {
                    logInfo("Error from ControllerActiveVdiskListPart1 (ctlr $i)");
                    $vdaFlag = ERROR;
                }

        
                ######################################
                # get the first server activity sample
                ######################################
    #
    #            @sCounts = GetServerActivityCounts(\@coList);
    #


                ########################
                # get port map data
                ########################


                @tMap = GetTargetsDataMap($$coPtr[$i], $snPtr);

                ########################
                # get resource manager state
                ########################
                $RMState = GetRMState($$coPtr[$i]);



                ########################
                # get stop counts
                ########################
                $stopCount = -1;
                %rsp = $$coPtr[$i]->globalCacheInfo();
    
                if ( ! %rsp  )
                {
                    logInfo("    ====> Failed to get globalCacheInfo from controller $i <====");
                    #return (ERROR);
                }

                if (%rsp)
                {
                    if ($rsp{STATUS} == PI_GOOD)
                    {

                        $stopCount = sprintf("%1d", $rsp{CA_STOPCNT});
                        # $ctlr->displayGlobalCacheInfo(%rsp);
                        # logInfo("Master stop count = $stopCount ");
                    }
                    else
                    {
                        logInfo("    ====> Error getting globalCacheInfo from controller $i <====");
                        PrintError(%rsp);
                        #return ERROR;
                    }
                }



                ########################################
                # Outstanding request counts FE @ 0x340
                ########################################



           #     %rsp = $$coPtr[$i]->ReadMemory($orcAddr, 4, "FE");
           #     if ( ! %rsp  )              # if no return from call
           #     {
           #         logInfo(">>>>>>>> Failed to get response from ReadMemory <<<<<<<<");
           #         return ERROR;
           #     }
           #     if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
           #     {
           #         logInfo(">>>>>>>> Error from ReadMemory <<<<<<<<");
           #         PrintError(%rsp);
           #         return ERROR;
           #     }
           #
           #     $orCount = unpack("L", $rsp{RD_DATA});
           #
           #


                ##########################
                # get Qlstatus data for FE
                ##########################

                # nothing yet
                @fepm = FEPortMatrix($$coPtr[$i]);



                #########################
                # get vdisk activity data
                #########################
            
                if (  $vdaFlag == GOOD  )
                {
                    @activeList = ControllerActiveVdiskListPart2($$coPtr[$i], \%vdaData1, 2, 3, "Q");
        
                }
                else
                {
                    @activeList = (INVALID);
                }
                # got all the data

            }   # (if election state )

            #########################
            # finish server activity
            #########################
    #
    #        @sMap = MakeActiveServerMapQ( \@coList,  \@sCounts, 2 );
    #

            # format and print data
            ########################

            # time stamp
            if ( $timePrinted == 0 )
            {
            
                # print time on first line of the group
                $msg = sprintf("TimeLine:[%3d] ", ($time2 - $time1));
                $timePrinted = 1;
            }
            else
            {
                # blank spaces on all others
                $msg = "               ";
            }
             
            # controller node number  
            $msg .= sprintf("Cn:%2d ", $CNodes);
                
            # election state
            if (defined($elState))
	    {
		$msg .= sprintf("El:%3d ", $elState);
	    }
	    else
	    {
		$msg .= sprintf("El:%3d ", -99);
	    }

            # stop count
            $msg .= sprintf("SC:%1s ", $stopCount);

            # resource manager state
            $msg .= sprintf("RM:%2d ", $RMState);

            # outstanding request counts
       #     $msg .= sprintf("ORC:%5d ", $orCount);


            # qlogic status 
            $msg .= "FEQL: ";
            for ( $j = 0; $j < scalar(@fepm); $j++ ) 
            {
                $msg .= sprintf("%02x ", $fepm[$j]);
            }
        
            # target map
            $msg .= "Tmap: ";
            for ( $j = 0; $j < scalar(@tMap); $j++ ) 
            {
                $msg .= sprintf("%08x ", $tMap[$j]);
            }
        

            # vdisks
            $msg .= "VD:";

            for ($j = 0; $j < scalar(@activeList); $j++ )
            {
                $msg .= sprintf(" %3d", $activeList[$j]);
            }


        

            ###########
            # print it
            ###########

            logInfo($msg);




        } # (for each controller)

    # make sure we killed off at least one second doing the above loop

    if ( $time2 == time )
    {
       sleep(1);
    }
    
         
    
    }   # ( while < duration )
    
    # return

    logInfo ("Fail-over time line end");
    logInfo("");
    logInfo("");
    logInfo("");


    return GOOD;
}

##############################################################################
#
#          Name: BLValidate
#
#        Inputs: controller object list pointer 
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Checks to make sure things are OK on the FE
#
#
##############################################################################
sub BLValidate
{
    my ($coPtr) = @_;

    my $i;
    my @coList;
    my @nodes;

    @coList = @$coPtr;

    for ( $i = 0; $i < scalar(@coList); $i++ )
    {
        @nodes = FENodes($coList[$i]);
        if (scalar(@nodes) > 0 )
        {
            if($nodes[0] eq INVALID)
            {
                logInfo("Error returned while getting nodes for the controller.");
                return ERROR;
            }
        }
    }


    return GOOD;
}
##############################################################################
#
#          Name: FENodes
#
#        Inputs: controller object, FE port number
#
#       Outputs: array of WWNs, 1st may be INVALID if error
#
#  Globals Used: none
#
#   Description: Returns a list of the WWNs seen by the port. Used by the 
#                Brocade switch test
#
#
##############################################################################
sub FENodes
{
    my ($ctlr) = @_;

    my $i;
    my $j;
    my $ret;
    my @WWNs;
    my @bad;
    my $master;
    my $temp;
    my $flag = 0;
    my %rsp;
    
    $bad[0] = INVALID;   # for errors
    logInfo("Getting attached WWNs on controller $ctlr ( IP: $ctlr->{HOST} ) ");

    # loop thru  all the ports and get the WWNs
    for ( $i = 0; $i < 4; $i++ )
    {
        
        #Validate port and check to see if it is ISCSI or FC, based on which 
        #device list is retrieved 
        
        &TestLibs::iscsi::ValidateTargetType ($ctlr, $i, \$flag);

        if ($flag == 1)
        {
        # get the device list

        %rsp = $ctlr->deviceList("FE", $i );
        
        if ( ! %rsp )
        {
            logInfo("Error getting devicelist data on FE, port $i .");
            return @bad;
        }

        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            if ( $rsp{ERROR_CODE} != $ctlr->PI_ERROR_INV_CHAN )
            {
                logInfo("    ====> Error from FE deviceList, port $i <====");
                PrintError(%rsp);
                return @bad;
            }
            else
            {
                logInfo("No card on channel $i");
            }
        }
        else
        {
            # data is good
            #logInfo("Device list for FE port $i ");
            #logDeviceList(%rsp);             # debug info

            for ( $j = 0; $j < $rsp{NDEVS}; $j++ )
            {
                # use one or the other 'temp =' lines 
                # $temp = sprintf ("%8.8x%8.8x", $rsp{LIST}[$j]{NODE_WWN_LO},
                $temp = sprintf ("%2.2x%8.8x", $i, 
                                               $rsp{LIST}[$j]{NODE_WWN_HI});
                

                # hint: using the port number ($i) in the array allows us to verify 
                # each port individually.

                push( @WWNs, $temp); 
            }
        }
      }

    }  # end of the port loop

    #
    # ok, now we have a list, we may have to sort it
    
    
    print "These WWNs were found: @WWNs \n";   # debug

    return @WWNs;

}

###############################################################################
##################################################################################
sub PScanReqdWait
{
    my ( $coPtr, $flag1, $flag2) = @_;
    
    # flags are currently unused

    my @coList;
    my $again;
    my %info;
    my $loop;
    my $master;
    my $raid;

    @coList = @$coPtr;

    logInfo("Waiting for required parity scan to complete on all raids");

    # get the master controller's index 
    $master = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    
    if ($master == INVALID)
    {
        logInfo("Failed to locate the master controller.");
        return ERROR;
    }

    print "\n";

    $again = 1;
    $loop = 0;

    while ( $again != 0 )
    {
        $again = 0;

        sleep(1);
        $loop++;

        # see if controller is alive

        if ( IsControllerAlive( $coList[$master] ) == GOOD )

        {
            # if alive
            # get raids data
            
            %info = $coList[$master]->raids();

            if ( ! %info  )              # if no return from call
            {
                print "\n";
                logInfo("    ====> Failed to get response from raids command <====");
                return ERROR;
            }
            if ( $info{STATUS} != PI_GOOD )      # if call returned an error
            {
                print "\n";
                logInfo("    ====> Error from raids command <====");
                PrintError(%info);
                return ERROR;
            }

            # for each raid
            for ( $raid = 0; $raid < $info{COUNT}; $raid++)
            {
                # look at the ASTATUS field

                print "     \rWaiting on Parity Scan [Loop: $loop] Checking controller".
                    " $coList[$master]->{HOST} , raid $info{RAIDS}[$raid]{RID},".
                    " Astatus = $info{RAIDS}[$raid]{ASTATUS} ";


                # if parity scan required bit is set
                if ( $info{RAIDS}[$raid]{ASTATUS} &  0x01 )
                {
                    # set 'again' to 1
                    $again = 1;
                }
            }
        }
        else
        {
            print "               \rController  $coList[$master]->{HOST} is not functional ";
            $again = 1;
        }
        
    }
    
    print "\n";

    return GOOD;
}
#################################################################################
##################################################################################
sub R5ResyncCheck
{
    my ( $coPtr, $flag1, $flag2) = @_;
    # flags are currently unused

    #
    # loops until R5 resync is complete. If it finds any raid on any controller
    # to be INOP, then it will exit with ERROR. Otherwise, exit with GOOD when
    # resync is done.
    #
    
    my @coList;
    my $again;
    my %info;
    my $loop;
    my $master;
    my $raid;
    my $i;
    my $j;
    my %raidsHash;
    my $retVal;

    @coList = @$coPtr;

    logInfo("Checking for raid resync to complete on all raids");

    # get the master controller's index 
    $master = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    
    if ($master == INVALID)
    {
        logInfo("Failed to locate the master controller.");
        return ERROR;
    }

    print "\n";

    $again = 1;
    $loop = 0;

    while ( $again != 0 )
    {
        $again = 0;

        sleep(1);
        $loop++;

        # see if controller is alive

        if ( IsControllerAlive( $coList[$master] ) == GOOD )

        {
            # if alive
            # get raids data
            
            %info = $coList[$master]->raids();

            if ( ! %info  )              # if no return from call
            {
                print "\n";
                logInfo("    ====> Failed to get response from raids command <====");
                $again = 1;
            }
            if ( $info{STATUS} != PI_GOOD )      # if call returned an error
            {
                print "\n";
                logInfo("    ====> Error from raids command <====");
                PrintError(%info);
                
                if ( $info{STATUS} == PI_TIMEOUT )
                {
                    $again = 1;
                }
                else
                {
                    return ERROR;
                }
            }

            # for each raid
            for ( $raid = 0; $raid < $info{COUNT}; $raid++)
            {
                # look at the ASTATUS field

                print "     \rWaiting on R5 resync [Loop: $loop] Checking controller".
                    " $coList[$master]->{HOST} , raid $info{RAIDS}[$raid]{RID},".
                    " Astatus = $info{RAIDS}[$raid]{ASTATUS} ";


                # if resync is in progress
                if ( $info{RAIDS}[$raid]{ASTATUS} &  0x10 )
                {
                    # set 'again' to 1
                    $again = 1;
                }
            }
        }
        else
        {
            print "               \rController  $coList[$master]->{HOST} is not functional ";
        }
        
        #
        # Now check all contrllers to see if any raids are INOP. If so, this will never
        # end, so return an error.
        #
        for ( $i = 0; $i < scalar(@$coPtr); $i++ )
        {
            #
            # see if the controller is in POWER_UP_COMPLETE
            #
            if ( GOOD == IsControllerAliveAndWell( $$coPtr[$i] ) )
            {
                #
                # now check the raids.
                #
                %raidsHash =  $$coPtr[$i]->raids();
    
                if (%raidsHash)
                {
                    if ($raidsHash{STATUS} == PI_GOOD)
                    {
                        
                        $retVal = GOOD;
                        
                        for ($j = 0; $j < $raidsHash{COUNT}; $j++)
                        {
                            #
                            # we got the raid information, look for INOP
                            # in each raid
                            #
                            if ( RAID_DEV_INOP ==  $raidsHash{RAIDS}[$j]{DEVSTAT})
                            {   
                                logInfo("    ====> Raid  $raidsHash{RAIDS}[$j]{RID} is INOP, test fails.");
                           
                                $retVal =  ERROR;
                            }
                        }
                        
                        #
                        # now return if any bad raids
                        #
                        if ($retVal == ERROR)
                        {
                            return ERROR;
                        }
                        
                    }
                    else
                    {
                        logInfo("    ====> Unable to retrieve the raids information from $$coPtr[$i]->{HOST}.");
                        PrintError(%raidsHash);
                        $again = 1;
                        next;
                    }
                }
                else
                {
                    LogInfo( "    ====> ERROR: $$coPtr[$i]->{HOST} did not return a raids packet.");
                    $again = 1;
                    next;
                }
                
            }   # if alive

        }   # for each controller

    }    # while loop
    
    print "\n";

    return GOOD;
}
#################################################################################
#################################################################################

=head2 MirrorPartnerCheck function

The Mirror Partners are displayed and the partners are validated to ensure 
that a partner is only used once.

=cut

=over 1

=item Usage:

 my $rc = MirrorPartnerCheck( $cobj  );
 
 where: $obj is a reference to a controller object.
       

=item Returns:

       $rc will be GOOD or ERROR. GOOD is each mirror partner is unique. ERROR
           if any partner is used more than once or if an error was reported
           while collecting the data.


=back

=cut

#################################################################################
sub MirrorPartnerCheck
{
    my ($obj) = @_;

    my %rsp;
    my @partners;
    my $i;
    my $j;
    my $msg;
    my $destMP;

    logInfo("\nMirror Partner check:");
    
    #
    # get the mirror partner data
    #

    %rsp = $obj->vcgMPList();

    if ( ! %rsp  )              # if no return from call
    {
        logInfo("    ====> Failed to get response from vcgMPList command <====");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo("    ====> Error from vcgMPList command <====");
        PrintError(%rsp);
        return ERROR;
    }

    #
    # display the mirror partner list
    #

    $msg = $obj->displayVCGMPList(%rsp);

    logInfo($msg);

    #
    # now walk the list and determine if any partners are used twice.
    #


    my @mplist = $rsp{MPLIST};

    for ($i = 0; $i < $rsp{COUNT}; $i++)
    {
        
        $destMP =  $rsp{MPLIST}[$i]{DEST};

        if ( scalar(@partners) > 0 )
        {
            for ($j = 0; $j < scalar(@partners); $j++ )
            {
                if ( $destMP == $partners[$j] )
                {
                    logInfo ("Mirror partner $destMP is used more than once, check fails.\n\n");
                    return ERROR;
                }
            }
        }

        # add new partner to list
        push (@partners, $destMP);

    }

    logInfo("All mirror partners are unique. \n\n");
    return GOOD;

}
#################################################################################
#
#  This is a function to gather and log some data we want to periodically 
#  save during and between tests.
#
#
#
sub PeriodicDataGather
{
    my ($coPtr) = @_;

    my $count = scalar(@$coPtr);

    my $i;
    my $ctlr;
    my $ret;

    for ( $i = 0; $i < $count ; $i++)
    { 
        $ctlr = $$coPtr[$i];

        if ( GOOD == TestConnection($ctlr) )
        {

            # first on the list is the memory leak stuff

            $ret = GPMemoryLeakTest($ctlr);

            # add more here
        }
    }
    return GOOD;
}
#################################################################################
sub TestConnection
{
    my ($obj) = @_;
    
    my $ret;

    # check to see if we are talking to the controller

    my $oldTimeout = $obj->{TIMEOUT};    # save this
    
    $obj->{TIMEOUT} = 10;             # temporary short value


    # need to have a valid socket for this test
    # if no socket, we will be connecting for the first time

    if ( $obj->{socket} )
    {

        $ret = GetPowerUpState($obj);     # almost any command will do

        if ( $ret != INVALID )
        {
            # got an answer from the controller, connection is good
            $obj->{TIMEOUT} = $oldTimeout;   # restore old value, return
            return GOOD;
        }    
        
    }
        
    $obj->{TIMEOUT} = $oldTimeout;   # restore old value
    
    return ERROR;

}
#################################################################################
sub CheckBEHashes
{
    my( $mirrorDataPtr ) = @_;


    if ( 0 != $mirrorDataPtr->{PDISKS} )
    {
        if ( ! $mirrorDataPtr->{PDISKS}  )
        {
            logInfo("    ====> Failed to get response from pdisks <====");
            return ERROR;
        }

        if ($$mirrorDataPtr{PDISKS}{STATUS} != PI_GOOD)
        {
            logInfo("    ====> Error from Pdisks command <====");
            PrintError(%{$mirrorDataPtr->{PDISKS}});
            return ERROR;
        }
    }

    if ( 0 != $mirrorDataPtr->{VDISKS} )
    {
        if ( ! $mirrorDataPtr->{VDISKS}  )
        {
            logInfo("    ====> Failed to get response from vdisks <====");
            return ERROR;
        }

        if ($mirrorDataPtr->{VDISKS}{STATUS} != PI_GOOD)
        {
            logInfo("    ====> Error from vdisks command <====");
            PrintError(%{$mirrorDataPtr->{VDISKS}});
            return ERROR;
        }
    }

    if ( 0 != $mirrorDataPtr->{RAIDS} )
    {
        if ( ! $mirrorDataPtr->{RAIDS}  )
        {
            logInfo("    ====> Failed to get response from raids <====");
            return ERROR;
        }

        if ($mirrorDataPtr->{RAIDS}{STATUS} != PI_GOOD)
        {
            logInfo("    ====> Error from raids command <====");
            PrintError(%{$mirrorDataPtr->{RAIDS}});
            return ERROR;
        }
    }

    return GOOD;

}
###############################################################################

=head2 IsControllerAliveAndWell function

This function tests to see if we still have a connection to the controller and 
that the controller is POWER_UP_COMPLETE.
If the connection is still good, we return GOOD, else ERROR.
=cut

=over 1

=item Usage:

 my $rc = IsControllerAliveAndWell( $ctlr  );

 where: $ctlr is a controller object


=item Returns:

       $rc will be GOOD or ERROR. GOOD indicates we have a connection.
           ERROR indicates there is no connection to the controller.

=item Things to look for:

 If the test fails to reconnect, the controller may be powered off.

=item Initial Conditions:

 There should be a valid controller object that has been connected to
 the controller as the information within the object is used to make
 a new connection.


=back

=cut


##############################################################################
#
#          Name: IsControllerAliveAndWell
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Makes sure there is a valid connection to the controller.
#                Test a command and if it times out reconnects to the controller.
#                Makes the connection using the existing controller object.
#
#
##############################################################################
sub IsControllerAliveAndWell
{
    trace();
    my ($ctlr ) = @_;

    my $ret = GOOD;
    my $oldTimeout;
    my %rsp;
    my $socket = 0;


    # check to see if we are talking to the controller

    $oldTimeout = $ctlr->{TIMEOUT};    # save this

    # need to have a valid socket for this test
    # if no socket, we will be connecting for the first time

    if ( $ctlr->{socket} )
    {

        $ctlr->{TIMEOUT} = 10;             # temporary short value
        
        %rsp = $ctlr->powerUpState();

        $ctlr->{TIMEOUT} = $oldTimeout;   # restore old value
        
        if ( ! %rsp  )
        {
            $ret = ERROR;      # timeout
        }
        elsif ($rsp{STATUS} != PI_GOOD)
        {
            $ret = ERROR;      # some error
        }
        elsif ( POWER_UP_COMPLETE != $rsp{STATE}  )
        {
            $ret = ERROR;
        }

    }
    else
    {
        $ret = ERROR;          # no socket, can't use
    }


    return $ret;

}
###############################################################################
#
#          Name: TestPrep4MirrorCheck
#
###############################################################################

=head2 TestPrep4MirrorCheck function

This function prepares the systems for defrag testing by first deleting 
unused vdsiks, Fixing any drive labels, waiting for mirror resync to finish
and collect data for mirror validation.

=cut

=over 1

=item Usage:

 my $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, $mirrorDataPtr );
 
 where: $coPtr is a list of controller object pointers
        $master is the inxdex into the controller list for the master
        $MRWTimeout is the timeout for mirror resync wait (in seconds) Note:
                    4 times this value is used
        $mirrorDataPtr is a pointer to collected mirror state data.
        
=item Returns:

       $ret will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.

=item Initial Conditions:

 The system should be configured. Any vdisks present should either be
 mapped to a server, or part of a mirror. Running I/O is not 
 important.


=back

=cut


##############################################################################
sub TestPrep4MirrorCheck
{
    my ($coPtr, $master, $MRWTimeout, $mirrorDataPtr) = @_;

    my $ctlr;
    my @coList;
    my $ret;
    
    
    # get the master controller
    @coList = @$coPtr;

    #
    # Clean up any unused vdisks
    #
    $ret = TestLibs::BEUtils::DeleteUnusedVdisks( $coList[$master], 0);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # Clean up pdisk labels
    #
    $ret = TestLibs::BEUtils::FixPdiskLabels ($coList[$master], 0);
    if ( $ret != GOOD ) { return ERROR; }
    
    #
    # Rel 3.1 adds resync, need to wait for it to complete
    #
    logInfo( "Making sure all mirror resync is complete at start of test.");
    $ret = MirrorResyncWait($coPtr, 4 * $MRWTimeout);
    if ($ret != GOOD)
    {
        logInfo("Failed Mirror Resync wait at start of test.");
        return ERROR;
    }

    #
    # collect initial mirror state data
    #
    $ret = MirrorInitialData( $coPtr, $mirrorDataPtr);
    if ($ret != GOOD)
    {
        logInfo("Failed collecting initial Mirror Data.");
        return ERROR;
    }
    
    return GOOD;

}
###############################################################################
#
#          Name: TestEndMirrorCheck
#
###############################################################################

=head2 TestEndMirrorCheck function

This function cleans up and checks the mirrors to see if they have changed as 
a result of the test. The cleanup removes unused vdisks and fixes labels
on the pdisks.

=cut

=over 1

=item Usage:

 my $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, $mirrorDataPtr );
 
 where: $coPtr is a list of controller object pointers
        $MRWTimeout is the timeout for mirror resync wait (in seconds) Note:
                    4 times this value is used
        $mirrorDataPtr is a pointer to collected mirror state data.
        
=item Returns:

       $ret will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.

=item Initial Conditions:

 The system should be configured. Any vdisks present should either be
 mapped to a server, or part of a mirror. Running I/O is not 
 important.


=back

=cut


##############################################################################
sub TestEndMirrorCheck
{
    my ( $coPtr, $MRWTimeout, $mirrorDataPtr) = @_;
    
    my $master;
    my $ctlr;
    my $ret;
    my @coList = @$coPtr;
    
    
    $master = TestLibs::IntegCCBELib::FindMaster($coPtr);
    if ( $master == INVALID ) { return(ERROR); } 
    
    #
    # Delete unused vdisks (needde for mirror check)
    #
    $ret = TestLibs::BEUtils::DeleteUnusedVdisks( $coList[$master], 0);
    if ($ret != GOOD)
    {
        logInfo("Failed Deleting unused vdisks.");
        return ERROR;
    }
    
    #
    # Nice thing to do, makes labels correct for next test
    #
    $ret = TestLibs::BEUtils::FixPdiskLabels ($coList[$master], 0);
    if ($ret != GOOD)
    {
        logInfo("Failed Fixing Pdisk labels.");
        return ERROR;
    }

    #
    # Rel 3.1 adds resync, need to wait for it to complete
    #
    $ret = MirrorResyncWait($coPtr, $MRWTimeout);
    if ($ret != GOOD)
    {
        logInfo("Failed Mirror Resync wait.");
        $ret = MirrorCheck( $coPtr, $mirrorDataPtr);
        return ERROR;
    }

    #
    # Now check that the mirrors havenet changed.
    #
    $ret = MirrorCheck( $coPtr, $mirrorDataPtr);
    if ($ret != GOOD)
    {
        logInfo("Failed Mirror State Check.");
        return ERROR;
    }
    
    return GOOD;
}

###############################################################################
#
#          Name: VerifyIOGather
#
###############################################################################

=head2 VerifyIOGather function

This function gathers the initial data used for IO checks in various tests.
The data for active vdisks, active servers and the starting target map
is collected.

=cut

=over 1

=item Usage:

 my $ret = VerifyIOGather($coPtr, $snPtr, $master, $asPtr, $avPtr, 
                          $tmPtr, $duration, $threshold );
 
 where: $coPtr is a list of controller object pointers
        $snPtr is a pointer to a list of controller serial numbers
        $master is the index for the master controller
        $asPtr is a pointer to an empty active server list
        $avPtr is a pointer to an empty active vdisk list
        $tmPtr is a pointer to an empty target map
        $duration is the sample duration for IO (suggest 20)
        $threshold is the number of IOs required to declare active (suggest 10)
        
=item Returns:

       $ret will be GOOD or ERROR. 

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.

=item Initial Conditions:

 The system should be configured. Any vdisks present should either be
 mapped to a server, or part of a mirror. Running I/O is not 
 important.


=back

=cut


##############################################################################
sub VerifyIOGather
{
    my ($coPtr, $snPtr, $master, $asPtr, $avPtr, $tmPtr, $duration, $threshold) = @_;


    my @vCounts;
    my @sCounts;
    my $ret;
    my @activeServers;
    my @initialVdisks;

    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs( $duration);

    $ret = GroupTargetMap($coPtr, $snPtr, $tmPtr, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, $threshold );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, $threshold );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    #
    # copy output to caller
    #

    @$asPtr = @activeServers;            
    @$avPtr = @initialVdisks;

    return GOOD;

}


#################################################################################

# This generic MRP will do a miscompare scan on RAID 10. Scrubset doesn't work right.
# Then after that you have to check the R10_MISCOMP field in each PDD to see if it's > 0.
#
# genmrp 0x110 16 000000008000001D0000000c
#
# oh yeah - just RAID 12. I'm going to try to get that all working right 
# in the next day or two so it's easier. That's one pass. See rdd.inc 
#  for the bit definitions of the middle word. 
# >So, is that all raids, a single one, a vdisk....?
# >

#
##################################################################################
#################################################################################


1;   # we need this for a PM

