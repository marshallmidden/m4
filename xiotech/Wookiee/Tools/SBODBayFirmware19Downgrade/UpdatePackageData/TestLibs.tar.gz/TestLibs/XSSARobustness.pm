#!/usr/bin/perl -w
# $Header$

##############################################################################
#
# File name:    TestLibs::XSSARobustness
#
# Version:      $Revision: 33446 $
#
# Description:  A set of library functions for integration testing. These focus on
#               XSSA robusness testing.
#
# Author:       Olga Grigorenko
#
# Date:         07/26/2002
#
# Description:      A set of library functions for integration testing. These focus on
#               XSSA robusness testing.
#
#   It is expected that the user will write a perl script that calls
#   these library.
#
#  Copyright (c) 2003 XIOtech Corporation. All rights reserved.
#
##############################################################################

=head1 NAME

TestLibs::XSSARobustness - Perl support for  XSSA robusntess (endurance) testing

$Id: XSSARobustness.pm 33446 2007-10-15 14:20:10Z nick_elvester $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

This document describes usage of the Perl functions to Test XSSA Robustness

=head1 DESCRIPTION

Test Functions Available
                VdiskRobustness

=cut

##############################################################################

package TestLibs::XSSARobustness;

#*****************************************************************************
#* use libraries
#*****************************************************************************

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;

use File::Temp qw/ :mktemp  /;
use File::Path;
use Archive::Tar;

use warnings;
use lib "../CCBE";
use lib "../../CCBE";
use lib "../";
use lib ".";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;

use XIOtech::sanscript (port => 10000);
use XIOtech::sanscriptET;

use TestLibs::Validate;
use TestLibs::IntegCCBELib;
use TestLibs::IntegXMCLib;
use TestLibs::utility;
use TestLibs::Fibre;
use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :XSSA :GRABBER);

use Dumpvalue;
use File::Basename;
use Cwd;

#*****************************************************************************
#* Private variables
#*****************************************************************************

my $dumper  = new Dumpvalue;
my $dumper2 = new Dumpvalue;

#*****************************************************************************
#* Private defines - constants
#*****************************************************************************

use constant COPYMIRROR => 1;
use constant COPYSWAP   => 2;

#use constant BIGFOOT   => "Magnitude 3D";
#use constant MAGNITUDEC => "Magnitude";

use constant RESETALL => "RESETALL";
use constant ROLLING  => "ROLLING";

use POSIX;
use strict;

#*****************************************************************************
#* Exported functions
#*****************************************************************************

BEGIN
{
    use Exporter ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION = 1.00;

    @ISA    = qw(Exporter);
    @EXPORT = qw(
      &ClusterSet
      &CodeUpdate
      &CodeUpdateDefrag
      &CopyCreate
      &CodeUpdateWrapper
      &CrtExpAsDsaDlt
      &DiskBayCommands
      &DiskGroupToRaid
      &DiskGroupCommands
      &FindFreeVdIds
      &FreeClusters

      &GoodPathBigfoot
      &ICONCodeApply
      &LabelRobustness
      &MagGoodPath
      &MaxExpandBigfoot
      &MaxExpandMagnitude
      &MaxVd
      &MaxVdExp
      &PdDefrag
      &PdiskCommands
      &ResetAllCodeApply
      &ResetAllControllers
      &RollingCodeApply
      &SystemErrorPath
      &UsedClusters
      &VdiskCommands
      &VdiskRobustness
      &VdiskServerCommands
      &VlinkCommands
      &WorkSetVblock

    );

    %EXPORT_TAGS = ();    # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 33446 $);
}
our @EXPORT_OK;

################################################################################

=head2 VdiskRobustness

Performs most used virtual disk functions in a repetitive fashion. The
functions are: create virtual disk, expand virtual disk, mask virtual
disk to a server, delete virtual disk.

=over 4

=item Usage:

 my $result = VdiskRobustness( $cnc, $TestLoop );

 where: $cnc - serial number of the Bigfoot
        $TestLoop - number of times to executed the test

 if( $result == GOOD)
 {
    print "Test passed \n";
 }
 else
 {
    print "Test has failed \n";
 }

 Notes:

 None

=item Returns:

 On success - Returns 0 - GOOD.
 On error - Returns 1 - ERROR.

=back

=cut

##############################################################################
#
#          Name: PdDefrag
#
#        Inputs: $NameRef - referance to vd name array
#                $VdIdRef - referance to vd id array
#                $VdRaidRef - referance to vd raid array
#                $PdGroupRef - referance to physical disk group array
#                $CapacityRef - referance to vd capacity array
#                $workSetRef - referance to vd work set array
#                $vBlockRef - referance to vd block array
#
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Create virutal disks.
#                Deletes the first created virtual disk.
#                Starts defrag on all physical drives,
#                Waits for rebuild to compete.
#                Deletes all created virtual disks.
#
#
##############################################################################

sub PdDefrag
{
    my ($NameRef, $VdIdRef, $VdRaidRef, $PdGroupRef, $CapacityRef, $workSetRef, $vBlockRef) = @_;

    trace();

    my $loop;
    my $return;
    my @DataDr;
    my @PdIdRef;

    #
    # Do sanity checks before changing configuration
    #

    #
    # need at least 2 virtual disks to do the test
    #
    if (scalar(@$VdIdRef) < 2)
    {
        logWarning("Wrong number of Vd Id parementer @$VdIdRef");
        return ERROR;
    }

    #
    # Get list of PDisks labeled for data and make sure we really have some
    #
    logInfo("Getting list of physical disks labeled as data...");

    $return = PdList(\@PdIdRef, XSSADATATYPE);

    if ($return != GOOD)
    {
        logWarning("Unable get list of data drives");
        return ERROR;
    }

    if (scalar(@PdIdRef) == 0)
    {
        logWarning("Physical disk list is empty");
        return ERROR;
    }

    #
    # Create n contiguous RAIDs
    #
    for ($loop = 0; $loop < scalar(@$VdIdRef); $loop++)
    {
        logInfo(" ");
        logInfo("Attempting to create VDisk $$VdIdRef[$loop] RAID $$VdRaidRef[$loop] capacity $$CapacityRef[$loop]");

        $return =   VDCreate($$NameRef[$loop],
                    $$CapacityRef[$loop],
                    $$VdIdRef[$loop],
                    $$VdRaidRef[$loop],
                    $$workSetRef[$loop],
                    $$vBlockRef[$loop],
                    $$PdGroupRef[$loop],
        );

        if ($return != GOOD)
        {
            logWarning("Unable to create VDisk $$VdIdRef[$loop]");
            return ERROR;
        }
    }

    #
    # Delete a VDisk to create a hole in the RAID allocation
    #
    logInfo("Deleting VDisk $$VdIdRef[0]");

    $return = vdiskDelete($$VdIdRef[0]);

    if ($return != XMCGOOD)
    {
        logWarning("Unable to delete VDisk $$VdIdRef[$loop]");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Defrag every drive simultaneously
    #
    logInfo(" ");
    logInfo("----------- Starting defrag -----------");
    logInfo(" ");

    for ($loop = 0; $loop < scalar(@PdIdRef); $loop++)
    {
        logInfo("Starting defrag operation on PDisk $PdIdRef[$loop]");
        $return = pdiskDefrag($PdIdRef[$loop]);

        if ($return != XMCGOOD)
        {
            logWarning("Unable to start defrag on PDisk $PdIdRef[$loop] ");
            DumpXSSAError();
            return ERROR;
        }
    }

    #
    # Wait for all defrags to complete
    #
    $return = WaitToRebuild();

    if ($return != GOOD)
    {
        logWarning("Unable to complete defrag ");
        return ERROR;
    }

    logInfo("Defrag is complete.....");

    #
    # Delete the VDisks that were previously created
    # ...but all the error exits will skip this operation and leave the
    #    system with extra vdisks and one less workset/vblock
    #
    for ($loop = 1; $loop < scalar(@$VdIdRef); $loop++)
    {
        $return = vdiskDelete($$VdIdRef[$loop]);
        if ($return != XMCGOOD)
        {
            logWarning("Unable to delete VDisk $$VdIdRef[$loop]");
            DumpXSSAError();
            return ERROR;
        }
    }

    #
    # ICON needs 10 seconds between config operations before device
    # status is correct. This should be a constant somewhere.
    #
    sleep(10);

    return GOOD;

}

##############################################################################
#
#          Name: LabelRobustness
#
#        Inputs:  $cnc - serial number of the Bigfoot
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Re-labels physical disks with the same label
#
##############################################################################

sub LabelRobustness
{
    my ($cnc) = @_;

    trace();

    my $result;     # result of funciton execution
    my @PdId;       # list of physical disk IDs
    my $Pointer;    # just a pointer
    my @PdLabel;    # array of physical disks labels
    my %hash;       # hash containing physical disk infor

    ##########################################################
    ##  Get list of physical disks
    ##  For each physical disk get the information creating array
    ##      of physical disk labels
    ##  Relabel physical disk with the same label
    ##  Return the result of the test
    ##
    ##

    #
    #-Get Physical Disk List
    #
    $Pointer = pdiskList();

    if (!($Pointer))
    {
        DumpXSSAError();
        logWarning("Unable To Retrieve Physical Disks List");
        return INVALID;
    }

    my @UnsortedPdId = @$Pointer;    #-Get The List of the PD ID'S

    if (!(scalar(@UnsortedPdId)))
    {
        logWarning("There are no physical disks on the Magnitude 3D");
        return ERROR;
    }

    #
    # sort drives
    #
    @PdId = sort(@UnsortedPdId);

    for (my $i = 0; $i < scalar(@PdId); $i++)
    {
        %hash = pdiskInfo($PdId[$i]);
        if (%hash)
        {
            push(@PdLabel, $hash{DEVICE_LABEL});
        }
        else
        {
            logWarning("Unable to get information for PD Id $PdId[$i]");
            return ERROR;
        }
    }

    #
    # Start labeling drives
    #

    for (my $loop = 0; $loop < scalar(@PdId); $loop++)
    {
        $result = pdiskLabel($PdId[$loop], $PdLabel[$loop]);
        if ($result != XMCGOOD)
        {
            logWarning("Unable to label Pd Id $PdId[$loop] as $PdLabel[$loop]");
            DumpXSSAError();
            return ERROR;
        }
        else
        {
            logInfo("Pd Id $PdId[$loop] re-labeled as $PdLabel[$loop]");
        }
    }
    return GOOD;
}

##############################################################################
#
#          Name: CodeUpdate
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $CodeVer - code version
#                 $Opt - Option of Copy Mirror (1)
#
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Updates code level via XSSA rolling code update
#                method.
#
##############################################################################

sub CopyCodeUpdate
{
    my ($cnc, $CodeVer, $Opt, $ObjList) = @_;

    trace();

    my $result;
    my %version;
    my @SrcVd = (0,  1,  2,  3,  4,  5,  6,  7,  8,  9,  10, 11, 12, 13, 14);
    my @DstVd = (15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29);
    my $Delay;
    my $Retry;
    my $RaidType     = 10;
    my $CopyCapacity = 1024;
    my @VBockSrc;
    my @WSetSrc;
    my @VBockDst;
    my @WSetDst;
    my $loop;

    #####################################################
    ## Get XSSA and system release versions
    ##  update either XSSA or Bigfoot
    ## Wait to both devices to come on ready

    if ($Opt)
    {

        #
        # $Opt, $VdNum, $RaidType, $SrcVd, $DstVd
        #
        DelaySecs(60);

        $result = CopyCreate(   $Opt,
                                $RaidType,
                                \@SrcVd,
                                \@DstVd,
                                $CopyCapacity,
                                \@VBockSrc,
                                \@WSetSrc,
                                \@VBockDst,
                                \@WSetDst
        );

        if ($result != GOOD)
        {
            logWarning("Unable to start copy operation on CNC $cnc");
            return ERROR;
        }

        #
        # Make sure copy has started on all the drives
        #
        my $Delay     = 3;
        my $Retry     = 4;
        my $NumCopies = FALSE;

        for ($loop = 0; $loop < scalar(@DstVd); $loop++)
        {
            $result = MakeSureCopyStarted($DstVd[$loop], $Delay, $Retry);
            if ($result == GOOD)
            {
                $NumCopies = TRUE;
                last;
            }
        }

        if ($NumCopies != TRUE)
        {
            logInfo("No copies are taking place....");
            return ERROR;
        }
    }

    $result = RollingCodeUpdate($CodeVer, $ObjList, $cnc);

    if ($result != GOOD)
    {
        logWarning("Code  Update failed ");
        return ERROR;
    }

    if ($Opt)
    {
        logInfo("Waiting for copy operaiton to finish....");
        $Delay = 60;
        $Retry = 10;

        for ($loop = 0; $loop < scalar(@DstVd); $loop++)
        {
            $result = WaitCopyCompete($DstVd[$loop], $Delay, $Retry);
            if ($result != GOOD)
            {
                logWarning("Copy did not finish");
                return ERROR;
            }
            if ($Opt)
            {
                if ($Opt == COPYMIRROR)
                {
                    logInfo("Copy complete - breaking mirror vd id $DstVd[$loop]");

                    $result = vdiskMirrorBreak($DstVd[$loop]);

                    if ($result != XMCGOOD)
                    {
                        logWarning("Unable to break mirror for vd id $DstVd[$loop]");
                        DumpXSSAError();
                        return ERROR;
                    }
                }
            }
        }
        for ($loop = 0; $loop < scalar(@SrcVd); $loop++)
        {
            $result = DeleteSingleVD($SrcVd[$loop], $WSetSrc[$loop], $VBockSrc[$loop]);
            if ($result != GOOD)
            {
                logWarning("Unable to delete vd id ");
                return ERROR;
            }

        }
        for ($loop = 0; $loop < scalar(@DstVd); $loop++)
        {
            $result = DeleteSingleVD($DstVd[$loop], $WSetDst[$loop], $VBockDst[$loop]);

            if ($result != GOOD)
            {
                logWarning("Unable to delete vd id");
                return ERROR;
            }

        }

    }

    return GOOD;
}

##############################################################################
#
#          Name: ResetAllControllers
#
#        Inputs:  $Opt          - option kind of copy commands
#                 $RaidType     - raid type of virtual disks
#                 $SrcVd        - reference to an array of  sourse vd ids
#                 $DstVd        - reference to an array of  destanation vd ids
#                 $CopyCapacity - capacity of virtual disks to create
#                 $VBlockSr     - reference to an array of vb of source vds
#                                 that would be updated
#                                 durring function execution
#                 $WSetSr       - reference to an array of ws of source vds
#                                 that would be updated
#                                 durring function execution
#                 $VBlockDst    - reference to an array of vb of destination  vds
#                                 that would be updated
#                                 durring function execution
#
#                 $WSetDst      - reference to an array of ws of destination vds
#                                 that would be updated
#                                 durring function execution
#
#
#
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Creates virtual disks, issues copy command among
#                create virtual disks
#
##############################################################################

sub ResetAllControllers
{
    my ($ObjList, $cnc) = @_;

    trace();

    my $return;

    my ($sec_b, $min_b, $hour_b) = CORE::localtime(time);
    logInfo("Resseting controllers in DSC");
    logInfo("Current time is $hour_b : $min_b : $sec_b");

    $return = XIOtech::sanscriptET::resetAll();

    if ($return != XMCGOOD)
    {
        logWarning("Code Apply Failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # test the connection to make sure the systems are up
    #
    $return = TestNReconnectAll($ObjList);

    if ($return != GOOD)
    {
        logInfo("One of the controller is in the failed state");
        logWarning("Code Apply Failed");
        return ERROR;
    }

    if (XSSA_Reserve($cnc) != GOOD)
    {
        logInfo("Unable to reserver CNC $cnc ");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: ICONCodeApply
#
#        Inputs:  $CodeVer      - code version
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Applies code version to ICON.
#
##############################################################################

sub ICONCodeApply
{
    my ($CodeVer) = @_;

    trace();

    my $return;

    #
    # get the virtion at the begening of the test
    #
    my %Ver;

    $return = XSSAVersions(\%Ver);

    if ($return != GOOD)
    {
        logWarning("Unable to retrieve versions");
        return ERROR;
    }

    logInfo("-----------> Curent versions: ");
    logInfo(" ");

    foreach my $name (sort keys %Ver)
    {
        logInfo("-----------> $name $Ver{$name}");
    }
    logInfo(" ");

    #
    # Apply Code
    #
    my ($sec_b, $min_b, $hour_b) = CORE::localtime(time);
    logInfo("Applying code to version $CodeVer");
    logInfo("Current time is $hour_b : $min_b : $sec_b");
    logInfo("May take up to 15 min");

    if ($CodeVer)
    {
        $return = XIOtech::sanscriptET::versionApply($CodeVer);

        if ($return != XMCGOOD)
        {
            logWarning("Code Apply Failed");
            DumpXSSAError();
            return ERROR;
        }
    }
    else
    {
        logWarning("No code version entered");
        return ERROR;
    }

    #
    # make sure ICON is ready
    #
    DelaySecs(60);

    my $ready = FALSE;
    my $count = 0;

    while ($ready != TRUE)
    {
        my %Ver;

        %Ver = XIOtechVersion();

        if (%Ver)
        {
            $ready = TRUE;

            foreach my $name (sort keys %Ver)
            {
                logInfo("-----------> $name $Ver{$name}");
            }
        }
        else
        {
            if ($count == 20)
            {
                logInfo("ICON has not come on ready in 20 min");
                return ERROR;
            }
            else
            {
                logInfo("ICON is not ready");
                DelaySecs(60);
                $count++;
            }
        }
    }

    logInfo(" ");

    return GOOD;

}


##############################################################################

=head2 RollingCodeApply function

The test uses the loaded firmware files on the ICON to load code on the Controller
or ICON.  Up to 4 files can be specified

=cut

=over 1

=item Usage:

 my $rc = RollingCodeApply ($FwFiles[$index],
                            $ObjList,
                            $inFlags,
                            $inLoops,
                            $fwKitcnt,
                            $testRef,
                            $iloop,
                            $parmsPtr)

 where: $FwFiles is a pointer to a list of firmware files
        $ObjList is a pointer to a list of controller IP numbers
        $inFlags is Validiation flag result set in the TestCase Profile
        $inLoops is TestCase Loop count result set in the TestCase Profile
        $fwKitcnt is a number of Firmware files passed
        $testRef is the a defined name of the type of test being executed
        $iloop is a pointer to the current loop count
        $parmsPtr is a subset of the data pointer

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:



=item Initial Conditions:


=back

=cut

##############################################################################
#
#          Name: RollingCodeApply
#
#        Inputs: $CodeVer
#                $ObjList
#                $inFlags
#                $inLoops
#                $fwKitcnt
#                $testRef
#                $iloop
#                $parmsPtr)
#
#
#
#
#       Outputs: GOOD, if successful, ERROR otherwise           #
#  Globals Used: none
#
#   Description: Rolling Code Update between 1 - 4 firmware files
#
##############################################################################

sub RollingCodeApply
{
    trace();
    #my ( $CodeVer, $ObjList, $cnc, $inFlags, $inLoops, $fwKitcnt, $testRef, $iloop, $xtcDataPtr ) = @_;
    my ($CodeVer, $ObjList, $inFlags, $inLoops, $fwKitcnt, $testRef, $iloop, $parmsPtr, $xwsObj) = @_;

    if ($parmsPtr->{CONNECTION} eq lc("xws"))
    {
        if($] >= 5.006 && $] < 5.008) {
            eval("use lib \"TestLibs/WsLib/Release-Perl56\"");
            eval("use xws");
            if($@)
            {
                logError("The module TestLibs::WsLib::Release-Perl56::xws is missing");
                return ERROR
            }
        } elsif($] >= 5.008) {
            eval("use lib \"TestLibs/WsLib/Release-Perl58\"");
            eval("use xws");
            if($@)
            {
                logError("The module TestLibs::WsLib::Release-Perl58::xws is missing");
                return ERROR
            }
        } else {
            logInfo("Perl version is v".$^V."\n");
            logError("This version of Perl is unsupported (v".$^V.")");
            return ERROR;
        }
        logInfo("Module xws loaded");
    }

    my $return;
    my $newMaster;
    my $flags;
    my $mes;
    my %Ver;

    $flags = 0;

    my @msgStr = (
        "0 - Rolling Code Update",
        "1 - Rolling Code Update w Copy Mirror",
        "2 - Rolling Code Update w Copy Swap",
        "3 - Rolling Code Update w Defrag",
        "4 - Code Update Reset all"
    );

    $testRef = @msgStr[ $parmsPtr->{CURTESTARGUMENT} ];

    if ($inFlags != 0)
    {
        $flags = $inFlags;
    }

    $mes = "***** Starting XSSA Code Update test: $testRef ";

    #
    # getting initial system data and finding master controller
    #
    my $Master = TestLibs::IntegCCBELib::FindMaster($ObjList);

    if ($Master == INVALID)
    {
        logError(">>>>>>>> Failed to find the master controller  <<<<<<<<");
        return ERROR;
    }
    
    # set the WHQL bit to 0 here. this sets the controller to SCSI-2 or the default
    # behavior prior to release 7.00 (anything < J009). if this is set now the roll down
    # to a SCSI-2 code version will retain the SCSI-2 setting and a roll up to a
    # SCSI-3 code version will have the behavior of switching from SCSI-2 to SCSI-3 which
    # is desirable for code versions of 6.02 and less to versions 7.00 and greater. This
    # is not desirable when going from 7.00 and greater to 7.00 and greater so some version
    # checking needs to be added.
#    logInfo("getting fw version");
#    my %fwver = $ObjList->[$Master]->fwVersion();
#    %fw = %{$fwver{65521}};
    
    my %cfgresp = $ObjList->[$Master]->cfgoption(0, 0);
    my $cfgopt = $ObjList->[$Master]->displaycfgoption(%cfgresp);
    logInfo("cfgoption is currently set to $cfgopt");
    
    logInfo("Changing cfgoption 1 to 0");
    %cfgresp = $ObjList->[$Master]->cfgoption(0, 1);
    
    $cfgopt = $ObjList->[$Master]->displaycfgoption(%cfgresp);
    logInfo("cfgoption is currently set to $cfgopt");
    
    my @startingTmap = PreTestSnapShot($ObjList, TARGETMAP);
    my @serialNums   = PreTestSnapShot($ObjList, SERIALNUMBERS);
    my @pdiskData    = PreTestSnapShot($ObjList, PDISKDATA);
    my @vdiskData    = PreTestSnapShot($ObjList, VDISKDATA);
    my @raidData     = PreTestSnapShot($ObjList, RAIDDATA);

    my @activeServer = PreTestSnapShot($ObjList, ACTIVESERVERLIST);
    my @vdiskListPre = PreTestSnapShot($ObjList, INITIALVDISKS);

    #
    # Check to see if data was successfully retrieved & $inFlag not equal to 1 (1 = Skip the check)
    #
    if ($flags != 1)
    {

        if (   ($startingTmap[0] == INVALID)
            || ($serialNums[0] == INVALID)
            || ($pdiskData[0] == INVALID)
            || ($vdiskData[0] == INVALID)
            || ($raidData[0] == INVALID) && ($flags != 1))

        {
            logInfo("Failed while getting validate information...");
            return ERROR;
        }
    }

    #
    # get the versions at the begining of the test
    $return = XSSAVersions(\%Ver, $parmsPtr->{CONNECTION}, $xwsObj, $parmsPtr->{CURSERIALNUMBER});
    if ($return != GOOD)
    {
        logWarning("Unable to retrieve versions");
        return ERROR;
    }

    logInfo("-----------> Curent versions: ");
    logInfo(" ");

    foreach my $name (sort keys %Ver)
    {
        logInfo("-----------> $name $Ver{$name}");
    }
    logInfo(" ");

    #
    # Apply Code
    #
    my ($sec_b, $min_b, $hour_b) = CORE::localtime(time);

    logInfo("");
    logInfo(" Test parameters:");
    logInfo("                   Validation Flag:   $inFlags ");
    logInfo("               Internal Test Loops:   $inLoops ");
    logInfo("              Firmware Kits Passed:   $fwKitcnt ");
    logInfo("             XSSA Code Update test:   $testRef ");

    logInfo("");
    logInfo("--------------------- Loop $iloop of $inLoops completed, . -------------------");
    logInfo("");
    logInfo("");

    logInfo("Applying code to version $CodeVer");
    logInfo("Current time is $hour_b : $min_b : $sec_b");
    logInfo("May take up to 18 min");

    if ($CodeVer)
    {
        # default to rolling update
        my $updateMethod = "rolling";
        if ($parmsPtr->{CURTESTARGUMENT} == 4)
        {
            $updateMethod = "resetall";
        }
        
        if ($parmsPtr->{CONNECTION} eq lc("xws"))
        {
            
            # we do all this business, because Ewok had a hard time figuring out how to
            # handle a file with \ in it.
            my ($name, $path, $suffix) = fileparse($CodeVer, '\.xzp');
            $name = $name.".xzp";
            my $savedir = cwd();

            my $i;
            opendir(DIR, $path) || die "can't opendir $path: $!";
            my @files = grep { /.*\.xzp/ && -f "$path/$_" } readdir(DIR);
            closedir DIR;
            for( $i=0; $i<scalar(@files); $i++ ) {
                if( lc($files[$i]) eq lc($name) ) {
                    # same file but case may vary, so let's take the directory listing version
                    $name = $files[$i];
                }
            }

            chdir $path;

            $return = $xwsObj->updateDscSoftware($name, $parmsPtr->{CURSERIALNUMBER});
            if ($return == ERROR)
            {
                logError("Error updating firmware (op Start)\n");
                return ERROR;
            }
            DelaySecs(16*60); # 16 mins
            $xwsObj = XwsReconnect($xwsObj, $parmsPtr);
        }
        else
        {
            $return = XIOtech::sanscriptET::versionApply($CodeVer, uc($updateMethod));
            if ($return != XMCGOOD)
            {
                logWarning("Code Apply Failed");
                DumpXSSAError();
                return ERROR;
            }
        }
        
        logInfo("Code has updated");
    
    }
    else
    {
        logWarning("No code version entered");
        return ERROR;
    }

    #
    #Change Delay between codeupdates based on the $inFlag result
    #
    if ($parmsPtr->{CONNECTION} ne lc("xws"))
    {
        if ($flags == 1)
        {
            DelaySecs(360);
        }
        else
        {
            DelaySecs(420);
        }
    }

    #
    # Test the CNC connections and reconnect if required
    #
    $return = TestNReconnectAll($ObjList);

    if ($return != GOOD)
    {
        logInfo("One of the controller is in the failed state");
        logWarning("Code Apply Failed");
        return ERROR;
    }

    #
    # Run Validation compares.  Only if $inFlag not equal to 1 (1 = Skip the check)
    #
    if ($flags != 1)
    {
        $return = ControllersValidateAll(   $ObjList,
                                            \@activeServer,
                                            \@startingTmap,
                                            \@vdiskListPre,
                                            \@serialNums,
                                            \@pdiskData,
                                            \@vdiskData,
                                            \@raidData
        );

        if ($return != GOOD)
        {
            logInfo("Test failed: system data mismatch");
            return ERROR;
        }
   }

    #
    # Check to see if Master Controller exists
    #
    $newMaster = TestLibs::IntegCCBELib::FindMaster($ObjList);

    if ($Master == INVALID)
    {
        logError(">>>>>>>> Failed to find the master controller  <<<<<<<<");
        return ERROR;
    }

    #
    # Reconnect to ICON
    #
    # if we are talking to Ewok, we don't need to reserve
    if ($parmsPtr->{CONNECTION} ne lc("xws"))
    {
        #if(XSSA_Reserve($cnc) != GOOD)
        if (XSSA_Reserve($parmsPtr->{CURSERIALNUMBER}) != GOOD)
        {
            logInfo("Unable to reserve CNC $parmsPtr->{CURSERIALNUMBER}} ");
            return ERROR;
        }
    }

    logInfo("Versions after code update to $CodeVer");

    #
    # Check ICON Versions (CNC and ICON returned)
    #
    $return = XSSAVersions(\%Ver, $parmsPtr->{CONNECTION}, $xwsObj, $parmsPtr->{CURSERIALNUMBER});

    if ($return != GOOD)
    {
        logWarning("Unable to retrieve versions");
        return ERROR;
    }

    logInfo("-----------> Curent versions: ");
    logInfo(" ");

    #
    # Display current Firmware version being used
    #
    foreach my $name (sort keys %Ver)
    {
        logInfo("-----------> $name $Ver{$name}");
    }
    logInfo(" ");

    return GOOD;
}

sub XwsReconnect
{
    my ($xwsObj, $parmsPtr) = @_;

    if ($parmsPtr->{CONNECTION} eq lc("xws"))
    {
        if($] >= 5.006 && $] < 5.008) {
            eval("use lib \"TestLibs/WsLib/Release-Perl56\"");
            eval("use xws");
            if($@)
            {
                logError("The module TestLibs::WsLib::Release-Perl56::xws is missing");
                return ERROR
            }
        } elsif($] >= 5.008) {
            eval("use lib \"TestLibs/WsLib/Release-Perl58\"");
            eval("use xws");
            if($@)
            {
                logError("The module TestLibs::WsLib::Release-Perl58::xws is missing");
                return ERROR
            }
        } else {
            logInfo("Perl version is v".$^V."\n");
            logError("This version of Perl is unsupported (v".$^V.")");
            return ERROR;
        }
        logInfo("Module xws loaded");
    }

    # create the session if it doesn't exist...
    if( $xwsObj == NULL ) {
        logInfo("Creating XWS connection object...\n");
        unless( $xwsObj = xws::XwsSession->new() )
        {
            logInfo("Unable to create XWS session: ".$parmsPtr->{XWSIP}."\n");
            return ERROR;
        }
    }

    # if we're connected, disconnect
    if( $xwsObj->getSessionId() ne "" )
    {
        $xwsObj->terminate();
    }

    # now reconnect
    logInfo("Creating XWS connection to $parmsPtr->{XWSIP}\n");
    my $rv = $xwsObj->create($parmsPtr->{XWSIP}, "Administrator", "made4you");
    if( $rv ) {
        logError("Unable to create a session with ".$parmsPtr->{XWSIP});
        return ERROR;
    }
    return $xwsObj;
}

=head2 CodeUpdateWrapper function

This the wrapper that calles the Code Update funtion within a loop

=cut

=over 1

=item Usage:

 my $rc = CodeUpdateWrapper(\@FwFiles,
                            \@ccbeObjArray,
                            $inFlags,
                            $inLoops,
                            $fwKitcnt,
                            $testGroup,
                            $testRecord,
                            $recordGroup,
                            $parmsPtr

 where: @FwFiles is a pointer to a list of firmware files
        @ccbeObjArray is a pointer to a list of controller IP numbers
        $inFlags is Validiation flag result set in the TestCase Profile
        $inLoops is TestCase Loop count result set in the TestCase Profile
        $fwKitcnt is a number of Firmware files passed
        $testGroup XTC data pointer
        $testRecord XTC data pointer
        $recordGroup XTC data pointer
        $parmsPtr is a subset of the data pointer

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:



=item Initial Conditions:


=back

=cut

##############################################################################
#
#          Name: CodeUpdateWrapper
#
#        Inputs: @FwFiles
#                $ObjList
#                $inFlags
#                $inLoops
#                $fwKitcnt
#                $testGroup
#                $testRecord
#                $recordGroup
#                $parmsPtr
#
#
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Calls the test function for Code Updates (Platform and ICON)
##############################################################################

sub CodeUpdateWrapper
{

    #my ( $FwFilesPtr, $ObjList, $cnc, $inFlags, $inLoops, $fwKitcnt, $testGroup, $testRecord, $recordGroup, $xtcDataPtr ) = @_;
    my ($FwFilesPtr, $ObjList, $inFlags, $inLoops, $fwKitcnt, $testGroup, $testRecord, $recordGroup, $parmsPtr) = @_;

    my $return;
    my $mes;
    my $TestLoop;
    my $testRef;
    my $iloop   = 0;
    my @FwFiles = @$FwFilesPtr;
    my @ccbeObjArray;
    
    # test types hash (defined by test arg in config file)
    my %testTypes;
    $testTypes{0}{name} = "Rolling Code Update";
    $testTypes{1}{name} = "Rolling Code Update with Copy Mirror";
    $testTypes{2}{name} = "Rolling Code Update with Copy Swap";
    $testTypes{3}{name} = "Rolling Code Update with Defrag";
    $testTypes{4}{name} = "Reset All Update";
    $testTypes{5}{name} = "ICON Code Update";

    #
    # Start of test loop
    #
    if (defined($parmsPtr->{CTE}{FID}))
    {
        logInfo("FID = $parmsPtr->{CTE}{FID}\n");
    }
    
    my $xwsObj = NULL;
    if ($parmsPtr->{CONNECTION} eq lc("xws"))
    {
        logInfo("Connection: '$parmsPtr->{CONNECTION}'\n");
        logInfo("IP:        '$parmsPtr->{XWSIP}'\n");
        $xwsObj = XwsReconnect($xwsObj, $parmsPtr);
    }

    for ($iloop = 0; $iloop < $inLoops; $iloop++)
    {
        if ($parmsPtr->{CONNECTION} eq lc("xws"))
        {
            $xwsObj = XwsReconnect($xwsObj, $parmsPtr);
        }
        else
        {
            if (XSSA_Reserve($parmsPtr->{CURSERIALNUMBER}) != GOOD)
            {
        
                logInfo("Unable to reserve DSC $parmsPtr->{CURSERIALNUMBER}");
                return ERROR;
            }
        }
        
        # Log in to the controllers (unless we are test 0 for some reason, moved forward
        # in a re-factoring)
        unless ($parmsPtr->{CURTESTARGUMENT} == 0)
        {
            $return = TestLibs::IntegCCBELib::CcbeConnectAll($parmsPtr->{'vcgIP'}, \@ccbeObjArray);
            if ($return != GOOD)
            {
                TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
                return ERROR;
            }
        }
        
        # Send message to the controllers and log
        $mes = "***** Starting $testTypes{$parmsPtr->{CURTESTARGUMENT}}{name} Test *****\n";;
        $return = TestLibs::IntegCCBELib::CtlrLogTextAll(\@ccbeObjArray, $mes);
        if ($return != GOOD)
        {
            logInfo("Unable to send message to debug console");
            return ERROR;
        }
        logInfo($mes);
        
        # determine which fw file to use in the update
        my $fwIndex = $iloop % scalar(@FwFiles);
        
        # do a little more loggin'
        TestLibs::Logging::logInfo("Updating device serial $parmsPtr->{CURSERIALNUMBER} to release $FwFiles[$fwIndex]");
        logInfo("--------------------- Loop $iloop of $inLoops completed. -------------------");

        if ($parmsPtr->{CURTESTARGUMENT} == 0 || $parmsPtr->{CURTESTARGUMENT} == 4)
        {
            if (RollingCodeApply($FwFiles[$fwIndex], $ObjList, $inFlags, $inLoops, $fwKitcnt, $testRef, $iloop, $parmsPtr, $xwsObj) != GOOD)
            {
                logInfo("Test failed while updating CNC $parmsPtr->{CURSERIALNUMBER} to FW $FwFiles[$fwIndex]");
                return ERROR;
            }
        }
        elsif (($parmsPtr->{CURTESTARGUMENT} == 5))
        {
            if (ICONCodeApply($FwFiles[$fwIndex]) != GOOD)
            {
                logInfo("Test faild while ICON to FW $FwFiles[$fwIndex]");
                return ERROR;
            }
        }
        else
        {
            logInfo("Unknown test argument $parmsPtr->{CURTESTARGUMENT}");
            return ERROR;
        }
        
        if ($parmsPtr->{CONNECTION} ne lc("xws"))
        {
            $return = unreserve($parmsPtr->{CURSERIALNUMBER});
            if ($return != XMCGOOD)
            {
                logInfo("Unable to unreserve CNC $parmsPtr->{CURSERIALNUMBER}");
                return ERROR;
            }
        }

        $mes = "***** Code Update is Complete *****";
        $return = TestLibs::IntegCCBELib::CtlrLogTextAll(\@ccbeObjArray, $mes);
        if ($return != GOOD)
        {
            logInfo("Unable to send message to debug console");
            return ERROR;
        }

        # CTE Stuff
        if (defined($parmsPtr->{CTE}{FID}))
        {
            logInfo("Updating CTE info at end of Rolling Update\n");

            # eval load the CTE lib, it has a bunch of required libs (DBI, etc.)
            eval("use TestLibs::CTE");
            if ($@)
            {
                logError("Need the TestLibs::CTE module and its dependencies, $@\n");
                exit(0);
            }

            if (UpdateFailoverRun($parmsPtr->{CTE}{FID}) == ERROR)
            {
                logError("Could not update failover_run table for FID $parmsPtr->{CTE}{FID}\n");
            }

            if (UpdateServerTable($parmsPtr->{CTE}{FID}) == ERROR)
            {
                logError("Could not update failover_run table for FID $parmsPtr->{CTE}{FID}\n");
            }
        }
        logInfo("--------------------- Loop $iloop of $inLoops completed, . -------------------");
    }

    # this may not be necessary, but it does not seem like this ever returns good per the sub's header
    return (GOOD);
}

##############################################################################
#
#          Name: CopyCreate
#
#        Inputs:  $Opt          - option kind of copy commands
#                 $RaidType     - raid type of virtual disks
#                 $SrcVd        - reference to an array of  sourse vd ids
#                 $DstVd        - reference to an array of  destanation vd ids
#                 $CopyCapacity - capacity of virtual disks to create
#                 $VBlockSr     - reference to an array of vb of source vds
#                                 that would be updated
#                                 durring function execution
#                 $WSetSr       - reference to an array of ws of source vds
#                                 that would be updated
#                                 durring function execution
#                 $VBlockDst    - reference to an array of vb of destination  vds
#                                 that would be updated
#                                 durring function execution
#
#                 $WSetDst      - reference to an array of ws of destination vds
#                                 that would be updated
#                                 durring function execution
#
#
#
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Creates virtual disks, issues copy command among
#                create virtual disks
#
##############################################################################

sub CopyCreate
{
    my ($Opt, $RaidType, $SrcVd, $DstVd, $CopyCapacity, $VBlockSr, $WSetSr, $VBlockDst, $WSetDst) = @_;

    trace();

    my $return;
    my @FreeVblock;
    my @FreeWorkSet;
    my $VdNameS   = "TestS";
    my $VdNameD   = "TestD";
    my $DiskGroup = 0;
    my $loop;
    my $VdNum;

    # set diskgroup to default disk group 0
    # the group includes all drives and will
    # select the right drives for the raid accordingly

    $return = diskgroupSet($DiskGroup);

    if ($return != XMCGOOD)
    {
        logWarning("Unable to set disk group id $DiskGroup");
        return ERROR;
    }

    # max number of drives to create 15 30 ids are avaluable
    # within the free workset
    #
    if (scalar(@$SrcVd) != scalar(@$DstVd))
    {
        logInfo("Number of destenation IDs does not match number of source IDs");
        logInfo("Destenation IDs: @$DstVd");
        logInfo("Source IDs: @$SrcVd");
        return ERROR;
    }

    $VdNum = scalar(@$SrcVd);

    if (($VdNum > 15) || ($VdNum <= 1))
    {
        logInfo("Requested number of copy drive to create is greater then 15 or <= then 1");
        return ERROR;
    }

    #
    # find free VB
    #
    $return = FindFreeWB(\@FreeVblock, \@FreeWorkSet);

    if ($return != GOOD)
    {
        logInfo("Error occured while getting free vblocks and worksets");
        return ERROR;
    }

    if (scalar(@FreeVblock) == 0)
    {
        logInfo("There are no free vblocks available");
        return ERROR;
    }

    logInfo("Following vblock are free @FreeVblock ");

    if (scalar(@FreeWorkSet) == 0)
    {
        logInfo("There are no free worksets available");
        return ERROR;
    }

    logInfo("Creating copy source virtual disks....");

    for ($loop = 0; $loop < $VdNum; $loop++)
    {

        $return = VDCreate( $VdNameS,
                            $CopyCapacity,
                            $$SrcVd[$loop],
                            $RaidType,
                            $FreeWorkSet[0],
                            $FreeVblock[0],
                            $DiskGroup
        );

        if ($return != GOOD)
        {
            logWarning("Unable to create vd id $loop RAID $RaidType capacity $CopyCapacity");
            return ERROR;
        }
        push(@$VBlockSr, $FreeVblock[0]);
        push(@$WSetSr,   $FreeWorkSet[0]);
    }

    logInfo("Creating copy destenation virtual disks....");

    for ($loop = 0; $loop < $VdNum; $loop++)
    {

        $return = VDCreate($VdNameS, $CopyCapacity, $$DstVd[$loop], $RaidType, $FreeWorkSet[0], $FreeVblock[0], $DiskGroup);

        if ($return != GOOD)
        {
            logWarning("Unable to create vd id $loop RAID $RaidType capacity $CopyCapacity");
            return ERROR;
        }
        push(@$VBlockDst, $FreeVblock[0]);
        push(@$WSetDst,   $FreeWorkSet[0]);
    }

    if ($Opt == COPYMIRROR)
    {
        for ($loop = 0; $loop < scalar(@$SrcVd); $loop++)
        {
            $return = vdiskMirror($$SrcVd[$loop], $$DstVd[$loop]);
            if ($return != XMCGOOD)
            {
                logWarning("Unable to start copy mirror from Vd Id $$SrcVd[$loop] to Vd Id $$DstVd[$loop]");
                DumpXSSAError();
                return ERROR;
            }
            logInfo("Started copy mirror from id $$SrcVd[$loop] to id $$SrcVd[$loop]");
        }
    }
    if ($Opt == COPYSWAP)
    {
        for ($loop = 0; $loop < scalar(@$SrcVd); $loop++)
        {
            $return = XIOtech::sanscript::vdiskCopySwap($$SrcVd[$loop], $$DstVd[$loop]);
            if ($return != XMCGOOD)
            {
                logWarning("Unable to start copy - SWAP from Vd Id $$SrcVd[$loop] to Vd Id $$DstVd[$loop]");
                DumpXSSAError();
                return ERROR;
            }
            logInfo("Started copy swap from id $$SrcVd[$loop] to id $$SrcVd[$loop]");
        }
    }

    return GOOD;
}

##############################################################################
#
#          Name: GoodPath
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
# JT Notes: description is wrong
#           this doesn't cleanup and leaves the system in a different state
#
#
##############################################################################
sub GoodPathBigfoot
{
    my ($cnc, $system) = @_;

    trace();

    my $Return;
    my @drivesToUse;

    $Return = CommonCommands($cnc, "Magnitude 3D");

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Common commands");
        return ERROR;
    }

    $Return = DiskBayCommands();

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Disk Bay commands");
        return ERROR;
    }

    $Return = PdList(\@drivesToUse, "UNLABELED");

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while getting list of unlabeled drives");
        return ERROR;
    }

    $Return = PdiskCommands("Magnitude 3D");

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Physical Disk commands");
        return ERROR;
    }

    $Return = DiskGroupCommands();

    if ($Return == ERROR)
    {
        logWarning("Error: Test failed while executing Disk Group Commands commands");
        return ERROR;
    }

    if ($Return == INVALID)
    {
        logWarning("Either data drives of unsafe drive are missing on the system");
        return ERROR;
    }

    #    $Return = WorkSetVblock();
    #
    #    if($Return != GOOD)
    #    {
    #        logWarning("Error: Test failed while executing Work Set Vblock commands");
    #        return ERROR;
    #    }

    my @Vblock;
    my @WorkSet;

    ####################################################################
    #
    # >> workset
    # >> vblockAdd
    # >> vblockSet

    $Return = FindFreeWB(\@Vblock, \@WorkSet);
    if ($Return != GOOD)
    {
        logWarning("Error occurred while trying to find free vblock and free workset");
        return ERROR;
    }
    if ((scalar(@Vblock) == 0) || (scalar(@WorkSet) == 0))
    {
        logWarning("There're no combination of free vblock and workset available");
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ workset ------------ ");

    print "WorkSet @WorkSet Vblock @Vblock\n";
    logInfo("Setting work set to work set $WorkSet[0]");

    $Return = workset($WorkSet[0]);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed");
        DumpXSSAError();

        # CQ -
        # return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vblockAdd ------------ ");

    logInfo("Adding vblock $Vblock[0]");

    $Return = vblockAdd($Vblock[0]);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to add vblock $Vblock[0] ");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vblockSet ------------ ");

    logInfo("Setting Vblock $Vblock[0]");

    $Return = vblockSet($Vblock[0]);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to set vblock $Vblock[0] ");
        DumpXSSAError();
        return ERROR;
    }

    $Return = VdiskCommands("Magnitude 3D");

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Vdisk commands");
        return ERROR;
    }

    #
    # Delete vblock, making work set a free work set
    #

    #
    # the work set should be already set.
    #
    logInfo(" ");
    logInfo("------------ vblockRemove ------------ ");

    $Return = vblockRemove($Vblock[0]);

    if ($Return != XMCGOOD)
    {
        logInfo("Unable to remove Vblock ID $Vblock[0] ");
        DumpXSSAError();
        return ERROR;
    }

    logInfo("Vblock ID $Vblock[0] has been removed");

    $Return = VdiskServerCommands("Magnitude 3D");

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Vdisk Server Commands commands");
        return ERROR;
    }

    $Return = VlinkCommands();

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Vlink commands");
        return ERROR;
    }

    if (scalar(@drivesToUse))
    {
        for (my $o = 0; $o < scalar(@drivesToUse); $o++)
        {
            $Return = LabelSingleDrive("UNLABELED", $drivesToUse[$o]);
            if ($Return != GOOD)
            {
                logWarning("Error: Test failed while unlabeleing drives $drivesToUse[$o]");
                return ERROR;
            }
        }
    }

    DelaySecs(60);

    return GOOD;
}

##############################################################################
#
#          Name: CommonCommands
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################

sub CommonCommands
{
    my ($cnc, $system) = @_;

    ###################################################################
    ##  XIOdeviceList
    ##  XIOtechVersion
    ##  CNCINFO
    ##  ENVIRONMENT
    ##  RESERVE

    logInfo(" ");
    logInfo(" ------------ XIOdeviceList  ------------ ");

    my $devices = XIOdeviceList();

    if (defined($devices))
    {
        logInfo("Device Number " . scalar(@$devices));

        for (my $i = 0; $i < scalar(@$devices); $i++)
        {
            my %hash = %{ $devices->[$i] };

            foreach my $name (keys %hash)
            {
                logInfo(" $name  $hash{$name} ");
            }
        }
    }
    else
    {
        logWarning("There are no devices available");
        DumpXSSAError();
        return ERROR;
    }
    logInfo(" ");
    logInfo(" ------------ XIOtechVersion  ------------ ");

    my %version = XIOtech::sanscript::XIOtechVersion();

    if (%version)
    {
        foreach my $name (keys %version)
        {
            logInfo("$name $version{$name}");
        }
    }
    else
    {
        logWarning("Command failed");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo(" ------------ CNCINFO  ------------ ");
    my %CtrInfo = XIOtech::sanscript::info();
    my @CtrInfo = XIOtech::sanscript::info();
    if (%CtrInfo)
    {
        foreach my $name (sort keys %CtrInfo)
        {
            logInfo(" $name - $CtrInfo{$name}");
        }
    }
    else
    {
        logWarning("Command Failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    ## >> environment
    #
    if ($system =~ "Magnitude 3D" || $system == 2)
    {
        for (my $loop = 0; $loop < scalar($CtrInfo{CONFIGURED_CONTROLLER_COUNT}); $loop++)
        {
            my %Inv = environment($loop);

            logInfo(" ");
            logInfo("------------  ENVIRONMENT ------------ for CNR $loop");

            if (%Inv)
            {
                foreach my $name (sort keys %Inv)
                {
                    logInfo(" $name - $Inv{$name}");
                }
            }
            else
            {
                logWarning("Command Failed");
                DumpXSSAError();

                #return ERROR;
            }
            DelaySecs(5);    # Allow user to examine the output
        }
    }

    if ($system =~ "MAGNITUDE")
    {
        my %Inv = environment();

        logInfo(" ");
        logInfo("------------  ENVIRONMENT ------------ ");

        if (%Inv)
        {
            foreach my $name (sort keys %Inv)
            {
                logInfo(" $name - $Inv{$name}");
            }
        }
        else
        {
            logWarning("Command Failed");
            DumpXSSAError();

            # return ERROR;
        }
        DelaySecs(5);    # Allow user to examine the output
    }

    return GOOD;
}
##############################################################################
#
#          Name: DiskBayCommands
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################

sub DiskBayCommands

{
    trace();

    my $Return;    # Function return

    ##################################################
    # >> BAYCOUNT
    # >> BAYLIST
    # >> BAYBEACONT
    # >> BAYINFO

    logInfo(" ");
    logInfo("------------ BAYCOUNT ------------ ");

    $Return = bayCount();

    if ($Return == 0)    # in case of error return negative number
    {
        logWarning("Command Failed");
        DumpXSSAError();
        return ERROR;
    }
    logInfo("Number of bay(s): $Return");

    logInfo(" ");
    logInfo("------------ BAYLIST ------------ ");

    #
    # reference to an array containing list of bays
    #
    my $BayList = bayList();

    if (scalar(@$BayList) == 0)
    {
        logWarning("Command Failed");
        DumpXSSAError();
        return ERROR;
    }

    logInfo("Drive Bay list: @$BayList");

    logInfo(" ");
    logInfo("------------ BAYBEACON ------------ ");
    my $seconds = 40;

    $Return = bayBeacon($$BayList[0], $seconds);

    if ($Return != XMCGOOD)
    {
        logWarning("Command Failed for disk bay id $$BayList[0]");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ BAYINFO ------------");

    my %BayInfo = bayInfo($$BayList[0]);

    if (%BayInfo)
    {
        foreach my $name (keys %BayInfo)
        {
            logInfo("$name  -  $BayInfo{$name}");
        }
    }
    else
    {
        logWarning("Command Failed for disk bay id $$BayList[0]");
        DumpXSSAError();
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: PdiskCommands
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################

sub PdiskCommands
{
    my ($System) = @_;

    trace();

    my $Return;       # Function return
    my $PdiskList;    # Pointer return to an array
    my %PdiskInfo;    # hash as function return

    logInfo(" ");
    logInfo("------------ PDISKCOUNT ------------ ");

    $Return = pdiskCount();

    if ($Return < 0)
    {
        logWarning("pdiskCount command failed");
        DumpXSSAError();
        return ERROR;
    }

    logInfo("Number of physical  disks is - $Return ");

    logInfo(" ");
    logInfo("------------ PDISKLIST ------------ ");

    logInfo("Getting physical disk list...");

    $PdiskList = pdiskList();
    if ($PdiskList)
    {
        if (scalar(@$PdiskList) == 0)
        {
            logWarning("pdiskList command failed");
            DumpXSSAError();
            return ERROR;
        }
    }

    logInfo("Physical disk list = @$PdiskList");

    logInfo(" ");
    logInfo("------------ PDISKLABEL ------------ ");

    my $option   = 2;    # only unlabeled drives
    my $data     = 11;
    my $unsafe   = 2;
    my $numspare = 1;
    my $unlabel  = 0;

    $Return = LabelAllDrives($data, $unsafe, $numspare, $unlabel, $option);
    if ($Return != GOOD)
    {
        logInfo("Error re-labeling all drives  *Check for bad drive*");
    }

    if ($System !~ "MAGNITUDE")
    {
        logInfo(" ");
        logInfo("------------ PDISKBEACON ------------ ");
        my $duration = 30;

        $Return = pdiskBeacon($$PdiskList[0], $duration);

        if ($Return != XMCGOOD)
        {
            logWarning("pdiskBeacon command failed for Pd Id $$PdiskList[0]");
            DumpXSSAError();
            return ERROR;
        }
    }

    logInfo(" ");
    logInfo("------------ PDISKINFO ------------ ");

    %PdiskInfo = pdiskInfo($$PdiskList[0]);

    if (%PdiskInfo)
    {
        foreach my $name (sort keys %PdiskInfo)
        {
            logInfo(" $name - $PdiskInfo{$name}");
        }
    }
    else
    {
        logWarning("pdiskInfo command failed for Pd Id $$PdiskList[0]");
        DumpXSSAError();
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: ErrorPathBigfoot
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Creates and sets disk group
#                Creates virtual disk of certain raid
#                Expands virutal disk 11 times
#                Attemps to expand virtual disk 12th time
#                Make sure 12 expandtion failed
#                Deletes virtual disk
#
##############################################################################
sub SystemErrorPath
{
    my ($System) = @_;

    trace();

    my $Return;
    my @ErrorParms = ("A", -9, 99999, "#");
    my $loop;

    if ($System =~ "Magnitude 3D" || $System == 2)
    {
        logInfo(" ");
        logInfo("------------ BAYBEACON ------------ ");
        my $seconds = 40;

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            logInfo("Executing command with following parm(s): $ErrorParms[$loop], $ErrorParms[$loop]");
            bayBeacon($ErrorParms[$loop], $ErrorParms[$loop]);

            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);

        }

        logInfo(" ");
        logInfo("------------ BAYINFO ------------");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            logInfo("Executing command with following parm(s): $ErrorParms[$loop]");

            bayInfo($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }
    }

    logInfo(" ");
    logInfo("------------ PDISKLABEL ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {

        pdiskLabel($ErrorParms[$loop], $ErrorParms[$loop]);

        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);

    }

    logInfo(" ");
    logInfo("------------ PDISKINFO ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {

        pdiskInfo($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);

    }

    logInfo(" ");
    logInfo("------------ PDISKBEACON ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        pdiskBeacon($ErrorParms[$loop], $ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);

    }

    logInfo(" ");
    logInfo("----------- pdiskDefrag -----------");
    logInfo(" ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        pdiskDefrag($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);

    }

    logInfo(" ");
    logInfo("------------ diskgroupSet ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        logInfo("Executing command with following parm(s): $ErrorParms[$loop]");

        diskgroupSet($ErrorParms[$loop]);

        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("Setting disk group to id 0 ");
    logInfo("Command is expected to work ");
    $Return = diskgroupSet(0);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ diskgroupAdd ------------ ");
    logInfo("Adding @ErrorParms drives to disk group N 23");

    diskgroupAdd(@ErrorParms);

    logInfo("Error message: ");

    DumpXSSAError();
    DelaySecs(5);

    logInfo(" ");
    logInfo("------------ diskgroupInfo ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        diskgroupInfo($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ diskgroupRemove ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        diskgroupRemove($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);

    }

    if ($System =~ "Magnitude 3D" || $System == 2)
    {
        logInfo(" ");
        logInfo("------------ workset ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            workset($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ vblockAdd ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            vblockAdd($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ vblockSet ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            vblockSet($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ vblockRemove ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            vblockRemove($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        my @Vblock;
        my @WorkSet;

        logInfo(" ");
        logInfo("Following Commands are expected to succeed");
        logInfo("-------------------------------------------");

        $Return = FindFreeWB(\@Vblock, \@WorkSet);
        if ($Return != GOOD)
        {
            logWarning("Error occurred while trying to find free vblock and free workset");
            return ERROR;
        }
        if ((scalar(@Vblock) == 0) || (scalar(@WorkSet) == 0))
        {
            logWarning("There're no combination of free vblock and workset available");
            return ERROR;
        }

        logInfo(" ");
        logInfo("------------ Set work block and work set ------------ ");
        logInfo(" ");
        logInfo("Work Set -> $WorkSet[0] Block -> $Vblock[0] ");

        $Return = SetWorkBlock($WorkSet[0], $Vblock[0]);

        if ($Return != GOOD)
        {
            logWarning("Error occured while setting work set and vblock");
            return ERROR;
        }

        $Return = diskgroupSet(0);

        if ($Return != XMCGOOD)
        {
            logWarning("Unable to set disk group N 0");
            DumpXSSAError();
            return ERROR;
        }
        logInfo(" ");
        logInfo("The following commands are expected to fail ");
        logInfo("--------------------------------------------");

        logInfo(" ");
        logInfo("------------ newportInfo ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            newportInfo($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ workportCreate ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            workportCreate($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ workportName ------------ ");
        logInfo(" ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            workportName($ErrorParms[$loop], $ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ workportInfo ------------ ");
        logInfo(" ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            workportInfo($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ workportInfo ------------ ");
        logInfo(" ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            workportInfo($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ workportName ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            workportName($ErrorParms[$loop], "Test");
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ workportDelete ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            workportDelete($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }
    }

    if ($System =~ "MAGNITUDE")
    {
        logInfo(" ");
        logInfo("------------ clusterSet ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            clusterSet($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("Following Commands are expected to succeed");
        logInfo("-------------------------------------------");

        my @FreeCluster;

        $Return = FreeClusters(\@FreeCluster);
        if ($Return != GOOD)
        {
            logInfo("Find free clusters funciton has failed");
            return ERROR;
        }
        if (scalar(@FreeCluster) == 0)
        {
            logInfo("There are no free clusters available for further test execution ");
            return ERROR;
        }

        logInfo(" ");
        logInfo("------------ clusterSet ------------ ");

        $Return = clusterSet($FreeCluster[0]);

        if ($Return != XMCGOOD)
        {
            logInfo("Cluster set command had failed");
            DumpXSSAError();
            return ERROR;
        }

        logInfo(" ");
        logInfo("------------ habAssign  ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            habAssign($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ habUnassign  ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            habUnassign($ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ serverName  ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            serverName($ErrorParms[$loop], $ErrorParms[$loop], $ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

        logInfo(" ");
        logInfo("------------ serverDelete  ------------ ");

        for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
        {
            serverDelete($ErrorParms[$loop], $ErrorParms[$loop], $ErrorParms[$loop]);
            logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
            DumpXSSAError();
            DelaySecs(5);
        }

    }

    logInfo(" ");
    logInfo("------------ vdiskCreate ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskCreate($ErrorParms[$loop], $ErrorParms[$loop], $ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskExpand ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskExpand($ErrorParms[$loop], $ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskInfo ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskInfo($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskErase ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskErase($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskDelete ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskDelete($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskLock ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskLock($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskLockOff ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskUnlock($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskInfo ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskDelete($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskMaxCapacity  ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskMaxCapacity($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskBeacon ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskBeacon($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskName ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskName($ErrorParms[$loop], "Test");
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskCopy ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskCopy($ErrorParms[$loop], $ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
    }

    logInfo(" ");
    logInfo("------------ vdiskCopyAbort ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskCopyAbort($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskCopyPause ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskCopyPause($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskCopyResume ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskCopyResume($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskCopyStatus ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskCopyStatus($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskCopySwap ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskCopySwap($ErrorParms[$loop], $ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskMirror ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskMirror($ErrorParms[$loop], $ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskMirrorBreak ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskMirrorBreak($ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);

    }

    logInfo(" ");
    logInfo("------------ vdiskMask ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskMask($ErrorParms[$loop], $ErrorParms[$loop], $ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    logInfo(" ");
    logInfo("------------ vdiskUnmask ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vdiskUnmask($ErrorParms[$loop], $ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(10);
    }

    logInfo(" ");
    logInfo("------------ vlinkCreate ------------ ");

    for ($loop = 0; $loop < scalar(@ErrorParms); $loop++)
    {
        vlinkCreate($ErrorParms[$loop], $ErrorParms[$loop]);
        logInfo("For error parm: $ErrorParms[$loop]  Error message: ");
        DumpXSSAError();
        DelaySecs(5);
    }

    return GOOD;

}

#
#  No clean up is done in these tests.  Need to remove Vdisks, Vblock and verify that the configuration is in the same condition as
#  when first started.  This script goes through the motions, but misses the cleanup.  Fix before Yeti tests start - NE
#

##############################################################################
#
#          Name: DiskGroupCommands
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################

sub DiskGroupCommands
{

    trace();

    my $Return;      # function return
    my @DataDr;      # array containing data drive ids
    my @UnsafeDr;    # array containing unsafe drive ids
    my $loop;        # loop count

    ####################################################################
    # >> diskgroupSet
    # >> diskgroupSet
    # >> diskgroupInfo
    # >> diskgroupRemove
    #

    logInfo("Creating disk group N23 to create RAID 10 virtual disks ");
    logInfo("Setting disk group N 23");

    logInfo(" ");
    logInfo("------------ diskgroupSet ------------ ");

    $Return = diskgroupSet(23);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to set disk group N 23");
        DumpXSSAError();
        return ERROR;
    }

    logInfo("Getting list of all data drives....");

    my $Type = XSSADATATYPE;

    $Return = PdList(\@DataDr, $Type);

    if ($Return != GOOD)
    {
        logWarning("Unable to get physical disk list of label type $Type ");
        return ERROR;
    }

    if (scalar(@DataDr) == 0)
    {
        logInfo("There are no data drive present on the system");
        return INVALID;

    }
    logInfo(" ");
    logInfo("------------ diskgroupAdd ------------ ");
    logInfo("Adding @DataDr drives to disk group N 23");

    $Return = diskgroupAdd(@DataDr);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to add Pd Ids: @DataDr to disk group N 23");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ diskgroupInfo ------------ ");

    my %DiskGroupInfo = diskgroupInfo(23);
    if (%DiskGroupInfo)    # in case of error returns empty hash
    {
        foreach my $name (sort keys %DiskGroupInfo)
        {
            logInfo(" $name - $DiskGroupInfo{$name}");
        }
    }
    else
    {
        logWarning("Unable get disk group N 23 informaiton ");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ diskgroupRemove ------------ ");

    my $NumberToRemove = ceil(scalar(@DataDr) / 2);
    my @DriveToRemove;

    for ($loop = 0; $loop < $NumberToRemove; $loop++)
    {
        push(@DriveToRemove, $DataDr[$loop]);
    }
    logInfo("Removing drives @DriveToRemove from disk group N 23 ");
    $Return = diskgroupRemove(@DriveToRemove);

    if ($Return != XMCGOOD)
    {
        logWarning("Cannot remove Pd Ids: @DriveToRemove from disk group N 23");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ diskgroupInfo ------------ ");

    %DiskGroupInfo = diskgroupInfo(23);
    if (%DiskGroupInfo)    # in case of error returns empty hash
    {
        foreach my $name (sort keys %DiskGroupInfo)
        {
            logInfo(" $name - $DiskGroupInfo{$name}");
        }
    }
    else
    {
        logWarning("Unable get disk group N 23 informaiton ");
        DumpXSSAError();
        return ERROR;
    }

    logInfo("Creating disk group N22 for RAID 1 Virtual disks");

    $Return = diskgroupSet(22);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to set disk group N 22");
        DumpXSSAError();
        return ERROR;
    }

    my @TwoDrives;

    logInfo("Extracting two data drives out of the group");

    for ($loop = 0; $loop < 2; $loop++)
    {
        push(@TwoDrives, $DataDr[$loop]);
    }

    logInfo("Adding drives: @TwoDrives to disk group N22");

    $Return = diskgroupAdd(@TwoDrives);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to add Pd Ids: @TwoDrives to disk group N 22");
        DumpXSSAError();
        return ERROR;
    }

    logInfo("Creating disk group N21 for RAID 0 Virtual disks");

    $Return = diskgroupSet(21);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to set disk group N 21");
        DumpXSSAError();
        return ERROR;
    }

    $Type = XSSAUNSAFETYPE;

    logInfo("Getting list of unsafe $Type");

    $Return = PdList(\@UnsafeDr, $Type);

    if (($Return != GOOD) && (scalar(@UnsafeDr) == 0))
    {
        logWarning("Unable to get physical disk list of label type $Type ");
        return ERROR;
    }

    if (scalar(@UnsafeDr) == 0)
    {
        logInfo("There are not unsafe drive on the system");
        return INVALID;
    }

    logInfo("Adding drives: @UnsafeDr to disk group N21");

    $Return = diskgroupAdd(@UnsafeDr);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to add Pd Ids: @UnsafeDr to disk group N 21");
        DumpXSSAError();
        return ERROR;
    }
    return GOOD;
}

##############################################################################
#
#          Name: WorkSetVblock
#
#        Inputs: None
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Finds a free workset and VBlock, selects that workset, adds
#                the VBlock and selects that VBlock for the next operations.
#
##############################################################################

sub WorkSetVblock
{
    trace();

    my $Return;     # function return
    my @WorkSet;    # Workset the test will be performed on
    my @Vblock;     # VBlock the test will be performed on
    my $vblockList;

    #
    # Find a free Workset and VBlock
    #
    $Return = FindFreeWB(\@Vblock, \@WorkSet);
    if ($Return != GOOD)
    {
        logWarning("Error occurred while trying to find free vblock and free workset");
        return ERROR;
    }

    if ((scalar(@Vblock) == 0) || (scalar(@WorkSet) == 0))
    {
        logWarning("There're no combination of free vblock and workset available");
        return ERROR;
    }

    #
    # Select the workset
    #
    logInfo(" ");
    logInfo("------------ workset ------------ ");
    print "WorkSet @WorkSet Vblock @Vblock\n";
    logInfo("Selecting Workset $WorkSet[0]");

    $vblockList = workset($WorkSet[0]);
    if (!defined($vblockList))
    {
        DumpXSSAError();
        logWarning("Unable to set Workset to $WorkSet[0]");
        return ERROR;
    }

    #
    # Add the VBlock
    #
    logInfo(" ");
    logInfo("------------ vblockAdd ------------ ");
    logInfo("Adding VBlock $Vblock[0]");

    $Return = vblockAdd($Vblock[0]);
    if ($Return != XMCGOOD)
    {
        logWarning("Unable to add VBlock $Vblock[0]");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Select the VBlock
    #
    logInfo(" ");
    logInfo("------------ vblockSet ------------ ");
    logInfo("Selecting VBlock $Vblock[0]");

    $Return = vblockSet($Vblock[0]);
    if ($Return != XMCGOOD)
    {
        logWarning("Unable to select VBlock $Vblock[0]");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Return
    #
    return GOOD;
}

##############################################################################
#
#          Name: VdiskCommands
#
#        Inputs: $System - Bigfoot or Magnitude
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs  virtual disk functions.
#
##############################################################################

sub VdiskCommands
{
    my ($System) = @_;

    trace();

    my $Return;
    my $capacity = 1024;

    logInfo(" ");
    logInfo("------------ vdiskCreate ------------ ");
    logInfo("Setting disk group to 21");

    $Return = diskgroupSet(21);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to set disk group N 21");
        DumpXSSAError();
        return ERROR;
    }

    my $id   = 0;
    my $raid = 0;

    logInfo("Creating vd id $id, raid $raid");

    $Return = vdiskCreate($id, $raid, $capacity);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id vdiskCreate $id raid $raid");
        DumpXSSAError();
        return ERROR;
    }

    DelaySecs(10);

    $Return = vdiskExpand($id, $capacity);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to expand vdisk $id raid $raid by $capacity MB ");
        DumpXSSAError();
        return ERROR;
    }

    logInfo("Setting disk group to 22");
    $Return = diskgroupSet(22);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to set disk group N 22");
        DumpXSSAError();
        return ERROR;
    }

    $id   = 1;
    $raid = 10;

    logInfo("Creating vd id $id, raid $raid");

    $Return = vdiskCreate($id, $raid, $capacity);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id vdiskCreate $id raid $raid");
        DumpXSSAError();
        return ERROR;
    }

    DelaySecs(10);

    logInfo(" ");
    logInfo("------------ vdiskExpand ------------ ");

    $Return = vdiskExpand($id, $capacity);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to expand vdisk $id raid $raid by $capacity MB ");
        DumpXSSAError();
        return ERROR;
    }

    logInfo("Setting disk group to 23");
    $Return = diskgroupSet(23);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to set disk group N 23");
        DumpXSSAError();
        return ERROR;
    }

    $raid = 10;
    my @id = (2, 3);

    for (my $i = 0; $i < scalar(@id); $i++)
    {
        logInfo("Creating vd id $id[$i], raid $raid");

        $Return = vdiskCreate($id[$i], $raid, $capacity);

        if ($Return != XMCGOOD)
        {
            logWarning("Command failed for vd id $id[$i] raid $raid ");
            DumpXSSAError();
            return ERROR;
        }

        DelaySecs(10);

        $Return = vdiskExpand($id, $capacity);

        if ($Return != XMCGOOD)
        {
            logWarning("Unable to expand vdisk $id[$i] raid $raid by $capacity MB ");
            DumpXSSAError();
            return ERROR;
        }
    }

    if ($System =~ "Magnitude 3D" || $System == 2)
    {
        logInfo(" ");
        logInfo("------------ vdiskBeacon ------------ ");

        $Return = vdiskBeacon($id);

        if ($Return != XMCGOOD)
        {
            logWarning("Command failed for vd id $id ");
            DumpXSSAError();
            return ERROR;
        }

        logInfo(" ");
        logInfo("------------ vdiskErase  ID $id ------------ ");

        $Return = vdiskErase($id);

        if ($Return != XMCGOOD)
        {
            logWarning("Command failed for vd id $id ");
            DumpXSSAError();
            return ERROR;
        }

        # > commands were taken out of the library
        #
        #

        # logInfo(" ");
        # logInfo("------------ vdiskBufferOn ------------ ");
        #
        # $Return = XIOtech::sanscript::vdiskBufferOn(0);
        #
        # if($Return != XMCGOOD)
        # {
        #     logWarning("Command failed for vd id 0 ");
        #     DumpXSSAError();
        #     #return ERROR;
        # }
        #
        # logInfo(" ");
        # logInfo("------------ vdiskBufferOff ------------ ");
        #
        # $Return = XIOtech::sanscript::vdiskBufferOff(0);
        #
        # if($Return != XMCGOOD)
        # {
        #     logWarning("Command failed for vd id 0 ");
        #     DumpXSSAError();
        #     # return ERROR;     CQ - TBolt00008449
        # }
    }

    #

    my $Vdlist = XIOtech::sanscript::vdiskList();

    if ($Vdlist)
    {
        logInfo("Virtual disk list @$Vdlist");
    }
    else
    {
        logWarning("Command failed ");
        DumpXSSAError();
        return ERROR;
    }

    my $source      = 2;
    my $destination = 3;

    logInfo(" ");
    logInfo("**************** Testing Copy related commands  ****************");
    logInfo(" ");
    logInfo(" Copy will have place between  source  $source and destination $destination");

    logInfo(" ");
    logInfo("------------ Destination VD ID $destination INFO ------------ ");

    my %VdInfo = vdiskInfo($destination);

    if (%VdInfo)
    {
        foreach my $name (keys %VdInfo)
        {
            logInfo("$name $VdInfo{$name}");
        }
    }
    else
    {
        logWarning("Command failed for vd id $destination");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ Source VD ID $source INFO ------------ ");

    %VdInfo = vdiskInfo($source);

    if (%VdInfo)
    {
        foreach my $name (keys %VdInfo)
        {
            logInfo("$name $VdInfo{$name}");
        }
    }
    else
    {
        logWarning("Command failed for vd id $destination");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vdiskCopy ------------ ");

    $Return = vdiskCopy($source, $destination);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id's $source and $destination");
        DumpXSSAError();
        return ERROR;
    }

    my $delay = 5;
    my $retry = 50;

    $Return = WaitCopyCompete($destination, $delay, $retry);

    if ($Return != GOOD)
    {
        logWarning("Copy did not compete on vd id $destination");
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vdiskCopy ------------ ");

    $Return = vdiskCopy($source, $destination);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id's $source and $destination");
        DumpXSSAError();
        return ERROR;
    }

    $Return = MakeSureCopyStarted($destination);
    if ($Return != GOOD)
    {
        logWarning("Copy operation did not start on VD ID $destination");
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vdiskCopyAbort ------------ ");

    $Return = XIOtech::sanscript::vdiskCopyAbort($destination);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id $destination");
        DumpXSSAError();
        return ERROR;
    }

    DelaySecs(10);

    logInfo(" ");
    logInfo("------------ Destination VD ID $destination INFO ------------ ");

    %VdInfo = vdiskInfo($destination);

    if (%VdInfo)
    {
        foreach my $name (keys %VdInfo)
        {
            logInfo("$name $VdInfo{$name}");
        }
    }
    else
    {
        logWarning("Command failed for vd id $destination");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vdiskCopy ------------ ");

    $Return = vdiskCopy($source, $destination);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id's $source and $destination");
        DumpXSSAError();
        return ERROR;
    }

    $Return = MakeSureCopyStarted($destination);
    if ($Return != GOOD)
    {
        logWarning("Copy operation did not start on VD ID $destination");
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vdiskCopyPause ------------ ");

    $Return = XIOtech::sanscript::vdiskCopyPause($destination);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id $destination");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vdiskCopyResume ------------ ");

    $Return = XIOtech::sanscript::vdiskCopyResume($destination);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id $destination");
        DumpXSSAError();
        return ERROR;
    }

    $delay = 1;
    $retry = 100;

    $Return = WaitCopyCompete($destination, $delay, $retry);

    if ($Return != GOOD)
    {
        logWarning("Copy did not compete on vd id $destination");
        return ERROR;
    }

    DelaySecs(10);

    logInfo(" ");
    logInfo("------------ vdiskCopySwap ------------ ");

    $Return = XIOtech::sanscript::vdiskCopySwap($source, $destination);
    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id's $source and $destination");
        DumpXSSAError();
        return ERROR;
    }

    $delay = 5;
    $retry = 20;

    $Return = WaitCopyCompete($destination, $delay, $retry);

    if ($Return != GOOD)
    {
        logWarning("Copy did not compete on vd id $destination");
        return ERROR;
    }

    DelaySecs(10);

    logInfo(" ");
    logInfo("------------ vdiskMirror ------------ ");

    $Return = XIOtech::sanscript::vdiskMirror($source, $destination);
    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id's $source and $destination");
        DumpXSSAError();
        return ERROR;
    }

    $Return = WaitCopyCompete($destination, $delay, $retry);

    if ($Return != GOOD)
    {
        logWarning("Copy did not compete on vd id $destination");
        return ERROR;
    }

    DelaySecs(10);

    logInfo(" ");
    logInfo("------------ Destination VD ID $destination INFO ------------ ");

    %VdInfo = vdiskInfo($destination);

    if (%VdInfo)
    {
        foreach my $name (keys %VdInfo)
        {
            logInfo("$name $VdInfo{$name}");
        }
    }
    else
    {
        logWarning("Command failed for vd id $destination");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vdiskMirrorBreak ------------ ");

    $Return = XIOtech::sanscript::vdiskMirrorBreak($destination);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for id $destination");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vdiskName ------------ ");

    $Return = XIOtech::sanscript::vdiskName($destination, "Test");

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for id $destination");
        DumpXSSAError();
        return ERROR;
    }

    DelaySecs(10);

    logInfo(" ");
    logInfo("------------ Destination VD ID $destination INFO ------------ ");

    %VdInfo = vdiskInfo($destination);

    if (%VdInfo)
    {
        foreach my $name (keys %VdInfo)
        {
            logInfo("$name $VdInfo{$name}");
        }
    }
    else
    {
        logWarning("Command failed for vd id $destination");
        DumpXSSAError();
        return ERROR;
    }

    $id   = 5;
    $raid = 10;

    logInfo(" ");
    logInfo("------------ vdiskMaxCapacity raid $raid ------------ ");

    my $MaxCapacity = XIOtech::sanscript::vdiskMaxCapacity($raid);
    if ($MaxCapacity)
    {
        logInfo("Max capacity for vd raid type $raid is $MaxCapacity MB");
    }
    else
    {
        logWarning("Command failed ");
        DumpXSSAError();
        return ERROR;
    }
    logInfo(" ");
    logInfo("Creating vd id $id, raid $raid");

    $Return = vdiskCreate($id, $raid, $MaxCapacity);

    if ($Return != XMCGOOD)
    {
        logWarning("Command failed for vd id vdiskCreate $id raid $raid");
        DumpXSSAError();
        return ERROR;
    }

    DelaySecs(10);

    logInfo(" ");
    logInfo("------------ VD ID $id Max Capacity INFO ------------ ");

    %VdInfo = vdiskInfo($id);

    if (%VdInfo)
    {
        foreach my $name (keys %VdInfo)
        {
            logInfo("$name $VdInfo{$name}");
        }
    }
    else
    {
        logWarning("Command failed for vd id $destination");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vdiskList ------------ ");

    $Vdlist = XIOtech::sanscript::vdiskList();

    if ($Vdlist)
    {
        logInfo("Virtual disk list @$Vdlist");
    }
    else
    {
        logWarning("Command failed ");
        DumpXSSAError();
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vdiskLock ------------ ");

    $Return = XIOtech::sanscript::vdiskLock($$Vdlist[0]);
    if ($Return != XMCGOOD)
    {
        logWarning("Command failed ");
        DumpXSSAError();
        return ERROR;

    }

    logInfo(" ");
    logInfo("------------ vdiskLockOff ------------ ");

    $Return = XIOtech::sanscript::vdiskUnlock($$Vdlist[0]);
    if ($Return != XMCGOOD)
    {
        logWarning("Command failed ");
        DumpXSSAError();
        return ERROR;

    }

    DelaySecs(10);

    logInfo(" ");
    logInfo("------------ vdiskDelete ------------ ");

    for (my $i = 0; $i < scalar(@$Vdlist); $i++)
    {
        $Return = XIOtech::sanscript::vdiskDelete($$Vdlist[$i]);

        if ($Return != XMCGOOD)
        {
            logWarning("Command failed for vd id $$Vdlist[$i]");
            DumpXSSAError();
            return ERROR;
        }
    }

    DelaySecs(20);

    return GOOD;

}

##############################################################################
#
#          Name: VlinkCommands
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################

sub VlinkCommands
{

    trace();

    my $VlinkList;
    my $VlinkCount;
    my $Return;
    my @FreeVblock;
    my @FreeWorkSet;
    my $Vblock;

    logInfo(" ");
    logInfo("------------ Find Free Vblock and Work Set ------------ ");

    $Return = FindFreeWB(\@FreeVblock, \@FreeWorkSet);

    if ($Return != GOOD)
    {
        logInfo("Error occured while getting free vblocks and worksets");
        return ERROR;
    }

    if (scalar(@FreeVblock) == 0)
    {
        logInfo("There are no free vblocks available");
        return ERROR;
    }

    logInfo("Following vblock are free @FreeVblock ");

    if (scalar(@FreeWorkSet) == 0)
    {
        logInfo("There are no free worksets available");
        return ERROR;
    }

    $Vblock = $FreeVblock[0];

    $Return = SetWorkBlock($FreeWorkSet[0], $FreeVblock[0]);

    if ($Return != GOOD)
    {
        logInfo("Error has occured while setting vblock - work set ");
        return ERROR;
    }

    logInfo(" ");
    logInfo("------------ vlinkCount ------------ ");

    $VlinkCount = vlinkCount();

    if (!($VlinkCount))
    {
        logWarning("There may not be any vlinks available or error has occured");
        DumpXSSAError();
    }

    if ($VlinkCount > 0)
    {

        logInfo("There are $VlinkCount - vlinks available");

        $VlinkList = vlinkList();

        for (my $i = 0; $i < scalar(@$VlinkList); $i++)
        {

            logInfo(" ");
            logInfo("------------ VLink Index info ${$VlinkList->[$i]}{INDEX} ");

            foreach my $name (keys %{ $VlinkList->[$i] })
            {
                logInfo(" $name  ${$VlinkList->[$i]}{$name} ");
            }
        }

        for (my $i = 0; $i < scalar(@$VlinkList); $i++)
        {

            if (${ $VlinkList->[$i] }{LINKABLE} eq "yes")
            {
                logInfo(" ");
                logInfo("------------ vlinkCreate ------------ ");

                $Return = vlinkCreate(${ $VlinkList->[$i] }{INDEX}, $i);

                if ($Return != XMCGOOD)
                {
                    logWarning("Unable to create vlink index ${$VlinkList->[$i]}{INDEX}");
                    DumpXSSAError();
                    return ERROR;
                }
                else
                {
                    logInfo("Vlink index has been created ${$VlinkList->[$i]}{INDEX}");

                    # last;
                }
                DelaySecs(10);

                logInfo(" ");
                logInfo("------------ vdiskList ------------ ");

                my $Vdlist = vdiskList();

                if ($Vdlist)
                {
                    logInfo("Virtual disk list @$Vdlist");
                }
                else
                {
                    logWarning("Command failed ");
                    DumpXSSAError();
                    return ERROR;
                }

                logInfo(" ");
                logInfo("------------ vdiskInfo ------------ ");

                my %VdInfo = vdiskInfo($$Vdlist[0]);

                if (%VdInfo)
                {
                    foreach my $name (keys %VdInfo)
                    {
                        logInfo("$name $VdInfo{$name}");
                    }
                }
                else
                {
                    logWarning("Command failed for vd id $$Vdlist[0]");
                    DumpXSSAError();
                    return ERROR;
                }

                logInfo(" ");
                logInfo("------------ vdiskDelete ------------ ");

                $Return = vdiskDelete($$Vdlist[0]);

                if ($Return != XMCGOOD)
                {
                    logWarning("Unable to delete vd id $$Vdlist[0]");
                    DumpXSSAError();
                    return ERROR;
                }
                else
                {
                    logInfo("Virtual disk id $$Vdlist[0] was deleted");
                }
                DelaySecs(10);

                logInfo(" ");
            }
        }
    }

    logInfo("------------ vblockRemove ------------ ");

    $Return = vblockRemove($FreeVblock[0]);

    if ($Return != XMCGOOD)
    {
        logInfo("Unable to remove Vblock ID $FreeVblock[0] ");
        DumpXSSAError();
    }
    else
    {
        logInfo("Vblock ID $FreeVblock[0] has been removed");
    }

    return GOOD;
}

##############################################################################
#
#          Name: NewWorkPort
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################
sub VdiskServerCommands
{
    my ($System) = @_;

    trace();

    my $Return;
    my $check     = FALSE;
    my $capacity  = 1024;
    my @VdId      = (0, 1, 2);
    my @Raid      = (0, 10, 10);
    my @DiskGroup = (21, 22, 23);
    my @lun       = (0, 1, 2);
    my $ServerId;
    my $HabList;
    my @FreeVb;
    my @FreeWs;
    my $FreeVp = 0;

    #
    # -> Set vblock or work set depending on the system
    #
    if ($System =~ "Magnitude 3D" || $System == 2)
    {

        #
        # Find free vb and set free vd
        #
        logInfo(" ");
        logInfo("------------ Find Free WB  ------------ ");

        $Return = FindFreeWB(\@FreeVb, \@FreeWs);
        if ($Return != GOOD)
        {
            logWarning("Error occured while looking for free vb and ws");
            return ERROR;
        }

        if ((scalar(@FreeVb) == 0) || (scalar(@FreeWs) == 0))
        {
            logWarning("There are no free vblock work set combination avaluable");
            return ERROR;
        }

        logInfo(" ");
        logInfo("------------ Set work block and work set ------------ ");
        logInfo(" ");
        logInfo("Work Set -> $FreeWs[0] Block -> $FreeVb[0] ");

        $Return = SetWorkBlock($FreeWs[0], $FreeVb[0]);

        if ($Return != GOOD)
        {
            logWarning("Error occured while setting work set and vblock");
            return ERROR;
        }
    }

    if ($System =~ "MAGNITUDE")
    {

        #
        # Find and set free cluster
        #
        my @FreeCluster;

        logInfo(" ");
        logInfo("------------ Find Free Cluster  ------------ ");

        $Return = FreeClusters(\@FreeCluster);
        if ($Return != GOOD)
        {
            logWarning("Error occured while looking for cluster");
            return ERROR;
        }
        if (scalar(@FreeCluster) == 0)
        {
            logWarning("No free cluster avaluable ");
            return ERROR;
        }

        logInfo(" ");
        logInfo("------------ Set Free Cluster ------------ ");

        $Return = XIOtech::sanscript::clusterSet($FreeCluster[0]);

        if ($Return != XMCGOOD)
        {
            logWarning("Unable to set cluster id $FreeCluster[0] ");
            DumpXSSAError();
            return ERROR;
        }
    }

    #
    # Create virtual disks
    #
    for (my $i = 0; $i < scalar(@VdId); $i++)
    {
        logInfo(" ");
        logInfo("------------ vdiskCreate ------------ ");
        logInfo("Setting disk group to $DiskGroup[$i]");

        $Return = diskgroupSet($DiskGroup[$i]);

        if ($Return != XMCGOOD)
        {
            logWarning("Unable to set disk group N $DiskGroup[$i]");
            DumpXSSAError();
            return ERROR;
        }

        logInfo("Creating vd id $VdId[$i], raid $Raid[$i], capacity $capacity");

        $Return = vdiskCreate($VdId[$i], $Raid[$i], $capacity);

        if ($Return != XMCGOOD)
        {
            logWarning("Command failed for vd id $VdId[$i], raid $Raid[$i], capacity $capacity");
            DumpXSSAError();
            return ERROR;
        }
    }

    # -> Get the list of unsinged server
    # -> Create server of work port depending on the system
    #
    if ($System =~ "Magnitude 3D" || $System == 2)
    {
        logInfo(" ");
        logInfo("------------ newportList ------------ ");

        my $newportlist = newportList();

        if (scalar(@$newportlist) == 0)
        {
            logWarning("There were no new ports available - section skipped");
        }

        if (scalar(@$newportlist) != 0)
        {
            logInfo("New port list @$newportlist");

            logInfo(" ");
            logInfo("------------ newportInfo ------------ ");

            my %newportInfo = newportInfo($$newportlist[0]);

            foreach my $name (keys %newportInfo)
            {
                logInfo(" $name $newportInfo{$name}");
            }

            logInfo(" ");
            logInfo("------------ workportCreate ------------ ");
            logInfo("Creating work port from new port id $$newportlist[0] ");

            $Return = workportCreate($$newportlist[0]);

            if ($Return != XMCGOOD)
            {
                logWarning("Command failed ");
                DumpXSSAError();
            }

            logInfo(" ");
            logInfo("------------ workportList ------------ ");

            my $workportlist = workportList();

            if (scalar(@$workportlist) == 0)
            {
                logWarning("Error: no work ports are available");
                DumpXSSAError();
            }

            $ServerId = $$workportlist[0];
        }
    }

    if ($System =~ "MAGNITUDE")
    {
        logInfo(" ");
        logInfo("------------ Getting hab list  ------------ ");

        if ($HabList)
        {
            if (scalar(@$HabList) == 0)
            {
                logWarning("There are no habs available on the Magnitude");
                return ERROR;
            }

            logInfo("Assing hab id $$HabList[0] to the current cluster");

            logInfo(" ");
            logInfo("------------ habAssign  ------------ ");
            logInfo(" ");
            logInfo("Hab id  $$HabList[0]");

            $Return = habAssign($$HabList[0]);

            if ($Return != XMCGOOD)
            {
                logWarning("Error: hab assing for hab id $$HabList[0] failed ");
                DumpXSSAError();
                return ERROR;
            }

            logInfo(" ");
            logInfo("------------ serverList  ------------ ");

            my $ServerList = serverList();

            if ($ServerList)
            {
                if (scalar(@$ServerList) == 0)
                {
                    logWarning("There are no servers available");
                    return ERROR;
                }

                logInfo(" ");
                logInfo("Server list: @$ServerList ");
                $ServerId = $$ServerList[0];
            }
            else
            {
                logWarning("Error: occured while getting server list");
                DumpXSSAError();
                return ERROR;
            }
        }
        else
        {
            logWarning("Error: occured while getting hab list");
            DumpXSSAError();
            return ERROR;
        }
    }

    #
    # -> associate virtual disks to the server
    #
    my $newportlist = newportList();
    if (scalar(@$newportlist) != 0)
    {

        for (my $o = 0; $o < scalar(@lun); $o++)
        {

            $Return = vdiskMask($ServerId, $lun[$o], $VdId[$o], $FreeVp);
            if ($Return != XMCGOOD)
            {
                logWarning("Failed to associate vd id $VdId[$o] to wp $ServerId via lun $lun[$o]");
                DumpXSSAError();
                return ERROR;
            }

            logInfo("Virtual disk $VdId[$o] is associated with $ServerId via lun $lun[$o]");
        }
    }

    #
    # -> execute name info commands depending on the system
    #
    if ($System =~ "Magnitude 3D" || $System == 2)
    {

        logInfo(" ");
        logInfo("------------ workportName ------------ ");
        logInfo(" ");
        my $newportlist = newportList();
        if (scalar(@$newportlist) != 0)
        {

            $Return = workportName($ServerId, "Test");

            if ($Return != XMCGOOD)
            {
                logWarning("Command failed");
                DumpXSSAError();
            }

            logInfo(" ");
            logInfo("------------ workportInfo ------------ ");
            logInfo(" ");

            my %WpInfo = workportInfo($ServerId);

            if (%WpInfo)
            {
                foreach my $name (keys %WpInfo)
                {
                    logInfo("$name $WpInfo{$name}");
                }
            }
            else
            {
                logWarning("Command failed");
                DumpXSSAError();

                #return ERROR;
            }
        }
    }

    if ($System =~ "MAGNITUDE")
    {
        $Return = serverName($ServerId, "Test");

        if ($Return != XMCGOOD)
        {
            logWarning("Error: server name command failed server id $ServerId intented name TEST");
            DumpXSSAError();
            return ERROR;
        }
        #### ----> Server info command is missing (Magnitude Classic Only)
    }

    #
    # my $newportlist = newportList();
    #
    if (scalar(@$newportlist) != 0)
    {

        logInfo(" ");
        logInfo("------------ vdiskUnmask ------------ ");
        logInfo(" ");

        for (my $q = 0; $q < scalar(@lun); $q++)
        {

            $Return = vdiskUnmask($ServerId, $VdId[$q]);
            if ($Return != XMCGOOD)
            {
                logWarning("Failed to disassociate vd id $VdId[$q] to wp $ServerId ");
                DumpXSSAError();
                return ERROR;
            }

            logInfo("Virtual disk $VdId[$q] is disassociated from $ServerId ");
        }

        DelaySecs(10);
    }
    my %WpInfo;

    #
    # Delete the server or workport depending on the system
    #
    if ($System =~ "Magnitude 3D" || $System == 2)
    {
        logInfo(" ");
        logInfo("------------ workportInfo ------------ ");
        logInfo(" ");
        my $newportlist = newportList();
        if (scalar(@$newportlist) != 0)
        {

            %WpInfo = workportInfo($ServerId);

            if (%WpInfo)
            {
                foreach my $name (keys %WpInfo)
                {
                    logInfo("$name $WpInfo{$name}");
                }
            }
            else
            {
                logWarning("Command failed");
                DumpXSSAError();
                return ERROR;
            }

            logInfo(" ");
            logInfo("------------ workportDelete ------------ ");
            logInfo(" ");

            $Return = workportDelete($ServerId);

            if ($Return != XMCGOOD)
            {
                logWarning("Command failed");
                DumpXSSAError();
                return ERROR;
            }
        }
        logInfo(" ");
        logInfo("------------ vdiskDelete ------------ ");

        for (my $i = 0; $i < scalar(@VdId); $i++)
        {
            $Return = XIOtech::sanscript::vdiskDelete($VdId[$i]);

            if ($Return != XMCGOOD)
            {
                logWarning("Command failed for vd id $VdId[$i]");
                DumpXSSAError();
                return ERROR;
            }
        }

        logInfo(" ");
        logInfo("------------ vblockRemove ------------ ");

        $Return = vblockRemove($FreeVb[0]);

        if ($Return != XMCGOOD)
        {
            logInfo("Unable to remove Vblock ID $FreeVb[0] ");
            DumpXSSAError();
            return ERROR;
        }

        logInfo("Vblock ID $FreeVb[0]  has been removed");
    }

    if ($System =~ "MAGNITUDE")
    {
        $Return = habUnassign($ServerId);
        if ($Return != XMCGOOD)
        {
            logWarning("Unable to delete server id  $ServerId");
            DumpXSSAError();
            return ERROR;
        }

        logInfo("Getting hab list....");

        #
        # Make sure related CQ has been fixed
        #
        $HabList = habList();

        if ($HabList)
        {
            if (scalar(@$HabList) == 0)
            {
                logWarning("There are no habs available on the Magnitude");
                return ERROR;
            }
            logWarning("There are no habs available on the Magnitude");
            return ERROR;

            logInfo("Hablist:  @$HabList");
        }
        else
        {
            logWarning("Error: hab list command have failed");
            DumpXSSAError();
            return ERROR;
        }

    }

    return GOOD;
}

##############################################################################
#
#          Name: CrtExpAsDsaDlt
#

=head2 CrExpAssocDel function

=cut

=over 1

=item Usage:

    my $rc = CrExpAssocDel($argRAIDType, $pTestParms);

    where:   $argRAIDType   testcase argument - RAID type
             $pTestParms    pointer to testparms:
                            These are supported through the diskgroupEdit command
                                See sanscriptET.html for acceptable values.
                            R5SS - Raid 5 stripe size
                            R10SS - Raid 10 stripe size
                            R5PARITY - Raid 5 parity
                            RAIDSPERVDISK - Raids per vdisk
                            THRESHOLD - threshold
                            NAME - The name of the diskgroup
                            DESC - A description of the diskgroup

                            These are testcase unique
                            PDNUM - number of virtual disk to use in VDisk creation

=item Returns:

    $rc will be GOOD or ERROR

=item Description:

            Performs a sequence of ICON scripting commands:
                setup a Disk Group
                select a WorkSet and VBlock
                create a VDisk
                associate the VDisk to a server
                expand the VDisk
                disassociate the VDisk from the server
                delete the VDisk
                release the VBlock and WorkSet
=back

=cut

##############################################################################

sub CrtExpAsDsaDlt
{
    my ($argRAIDType, $pTestParms) = @_;

    trace();

    #
    # Default constants
    #
    my $capacity     = 1024;
    my $diskGroupID  = 7;
    my $vdiskBlockID = 0;
    my $lun          = 0;
    my $configDelay  = 15;
    my $raidType;

    #
    # Variables
    #
    my $rc;    # Return code

    my $wpList;       # WorkPort list
    my $npList;       # NewPort list
    my @workSet;      # work set the test will be performed
    my @vblock;       # vblock the test will be executed
    my %testParms;    # hash of input test parms

    my %wpInfo;       # WorkPort info
    my %vdInfo;       # VDisk info
    my %dgInfo;       # Disk Group Info

    #
    # Set and Edit disk group
    #
    $rc = DiskGroupToRaid($argRAIDType, $diskGroupID, $pTestParms);

    if (GOOD != $rc)
    {
        logInfo("Unable to set and edit disk group");
        return ERROR;
    }

    #
    # Setup the common drive info values depending on the RAID type.
    #
    if ("s" eq $argRAIDType)
    {

        $raidType = 0;
    }

    elsif ("0" eq $argRAIDType)
    {
        $raidType = 0;

    }

    elsif ("1" eq $argRAIDType)
    {

        $raidType = 10;

    }

    elsif ("5" eq $argRAIDType)
    {
        $raidType = 5;
    }

    elsif ("10" eq $argRAIDType)
    {
        $raidType = 10;
    }
    else
    {
        logError("Invalid input test argument: $argRAIDType");
        return ERROR;
    }

    #
    # Find a free Workset and VBlock
    #
    if (GOOD != FindFreeWB(\@vblock, \@workSet))
    {
        logWarning("==> Error occurred while trying to find free vblock and free workset");
        return ERROR;
    }

    if ((0 == scalar(@vblock)) || (0 == scalar(@workSet)))
    {
        logWarning("==> There are either no available VBlocks or Worksets");
        return ERROR;
    }

    #
    # Select the workset
    #
    logInfo("Select Workset $workSet[0]");
    my $vblockList = workset($workSet[0]);
    if (!defined($vblockList))
    {
        DumpXSSAError();
        logWarning("==> Unable to set Workset to $workSet[0]");
        return ERROR;
    }

    #
    # Add the VBlock
    #
    logInfo("Add VBlock $vblock[0]");
    if (XMCGOOD != vblockAdd($vblock[0]))
    {
        logWarning("==> The vblockAdd command failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Select the VBlock
    #
    logInfo("Select VBlock $vblock[0]");
    if (XMCGOOD != vblockSet($vblock[0]))
    {
        logWarning("==> The vblockSet command failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Create the VDisk
    #
    logInfo("Create VDisk $vblock[0]/$vdiskBlockID, RAID type $raidType");

    if (XMCGOOD != vdiskCreate($vdiskBlockID, $raidType, $capacity))
    {
        logWarning("==> The vdiskCreate command failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Get VDisk info
    # Retry up to 30 seconds before failing
    # I'm doing this here to gather statistics on the correct delay time
    #
    logInfo("Get info for VDisk $vblock[0]/$vdiskBlockID");
    my $retryCount = 0;
    $rc = ERROR;
    while ((30 > $retryCount) && (ERROR == $rc))
    {
        %vdInfo = vdiskInfo($vdiskBlockID);
        if (%vdInfo)
        {
            $rc = GOOD;
        }
        else
        {
            $retryCount++;
            DelaySecs(1);
        }
    }

    logInfo("Retry count = $retryCount");
    if (%vdInfo)
    {
        foreach my $name (keys %vdInfo)
        {
            logInfo("   $name $vdInfo{$name}");
        }
    }
    else
    {
        logInfo("==> The vdiskInfo command failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Get NewPort List
    #
    logInfo("Get the NewPort list");
    $npList = newportList();
    if (0 == scalar(@$npList))
    {
        logWarning("==> The newportList command failed or no NewPorts are available");
        DumpXSSAError();
        return ERROR;
    }

    #    logInfo("NewPort list: @$npList");

    #
    # Create a WorkPort
    #
    logInfo("Create a WorkPort from NewPort $$npList[0] ");
    if (XMCGOOD != workportCreate($$npList[0]))
    {
        logWarning("==> The workportCreate command failed ");
        DumpXSSAError();
        return ERROR;
    }

    # Verify a WorkPort was created
    # Since we started with an empty WorkSet, we must find only 1 workport
    #
    logInfo("Verify a single WorkPort was created");
    $wpList = workportList();
    if (1 != scalar(@$wpList))
    {
        logWarning("==> There should be exactly 1 WorkPort but " . "there are " . scalar(@$wpList) . "");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Associate the WorkPort with the VDisk
    #
    logInfo("Associate VDisk $vblock[0]/$vdiskBlockID with " . "WorkPort $$wpList[0] via LUN $lun");
    if (XMCGOOD != vdiskMask($$wpList[0], $lun, $vdiskBlockID))
    {
        logWarning("==> The vdiskMask command failed");
        DumpXSSAError();
        return ERROR;
    }
    DelaySecs($configDelay);

    #
    # Get the WorkPort info
    #
    logInfo("Get the WorkPort info");

    %wpInfo = workportInfo($$wpList[0]);
    if (%wpInfo)
    {
        foreach my $name (keys %wpInfo)
        {
            logInfo("   $name $wpInfo{$name}");
        }
    }
    else
    {
        logWarning("==> The workportInfo command failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Expand the VDisk
    #
    logInfo("Expand VDisk $vblock[0]/$vdiskBlockID by $capacity MBs");
    if (XMCGOOD != vdiskExpand($vdiskBlockID, $capacity))
    {
        logWarning("==> The vdiskExpand command failed");
        DumpXSSAError();
        return ERROR;
    }
    DelaySecs($configDelay);

    #
    # Display the new VDisk info
    #
    logInfo("Get the info for VDisk $vblock[0]/$vdiskBlockID");
    %vdInfo = vdiskInfo($vdiskBlockID);
    if (%vdInfo)
    {
        foreach my $name (keys %vdInfo)
        {
            logInfo("   $name $vdInfo{$name}");
        }
    }
    else
    {
        logWarning("==> The vdiskInfo command failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Disassociate the VDisk from the WorkPort
    #
    logInfo("Disassociate VDisk $vblock[0]/$vdiskBlockID from WorkPort $$wpList[0]");
    if (XMCGOOD != vdiskUnmask($$wpList[0], $vdiskBlockID))
    {
        logWarning("==> The vdiskUnmask command failed");
        DumpXSSAError();
        return ERROR;
    }
    DelaySecs($configDelay);

    #
    # Get WorkPort info
    #
    logInfo("Get the WorkPort info");
    %wpInfo = workportInfo($$wpList[0]);
    if (%wpInfo)
    {

        #       foreach my $name (keys %wpInfo)
        #       {
        #           logInfo("   $name $wpInfo{$name}");
        #       }
    }
    else
    {
        logWarning("==> The workportInfo command failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Delete the VDisk
    #
    logInfo("Delete VDisk $vblock[0]/$vdiskBlockID");
    if (XMCGOOD != vdiskDelete($vdiskBlockID))
    {
        logWarning("==> The vdiskDelete command failed");
        DumpXSSAError();
        return ERROR;
    }
    DelaySecs($configDelay);

    #
    # Remove the VBlock
    #
    logInfo("Remove VBlock $vblock[0]");
    if (XMCGOOD != vblockRemove($vblock[0]))
    {
        logWarning("==> The vblockRemove command failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Delete the WorkPort
    #
    logInfo("Delete WorkPort $$wpList[0]");
    if (XMCGOOD != workportDelete($$wpList[0]))
    {
        logWarning("==> The workportDelete command failed");
        DumpXSSAError();
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name:  VdMax
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################

sub MaxVd
{
    my ($argRAIDType, $pTestParms) = @_;
    trace();

    my %testParms;
    my $driveType;        # Type of the physical drives to retrieve
    my $raidType;         # virutal disk XSSARAID type
    my $minDriveCount;    # min number of drives allowed for the RAID type
    my $maxDriveCount;    # max number of the drives allowed for the RAID type
    my @tempDriveList;    # Temp list of drives with specified label
    my @driveList;        # Acctual list of drive to be used in the test to create virtual disks
    my $driveCount;

    my $Return;
    my $capacity    = 15;
    my $diskGroupID = 0;
    my @DiskList;

    my $RaidType;

    my @FreeWS;
    my @FreeVB;

    my @VdIdFree;

    my @WSInUse;
    my @VBInUse;
    my $VDCount = 0;    # Used to name virtual disks
    my $VbLim   = 8;    # number of vblocks allowed in one work set
    my @VdIdCreatedDurringTest;
    my @WorkCreatedDurringTest;
    my @FreeCreatedDurringTest;
    my $TestWS;

    #
    # Select the Disk Group
    #
    logInfo("Select Disk Group $diskGroupID");
    if (XMCGOOD != diskgroupSet($diskGroupID))
    {
        logWarning("==> The diskgroupSet command failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Load the input test parms if they are defined and it's not a NULL pointer
    # Check each one to see if there is a valid value before loading it
    # Report the errors but continue if there are any
    #
    # Remove 'XIOtech::sanscriptET::' after CQ 9339 is fixed
    # Uncomment 'return ERROR' after CQ 9348 is fixed
    #
    if ((defined($pTestParms)) && ($pTestParms != NULL))
    {
        %testParms = %$pTestParms;

        if (defined($testParms{name}))
        {
            logInfo("Edit Disk Group $diskGroupID: Name = $testParms{name}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, NAME => $testParms{name}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if (defined($testParms{desc}))
        {
            logInfo("Edit Disk Group $diskGroupID: Description = $testParms{desc}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, DESC => $testParms{desc}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if (defined($testParms{r10ss}))
        {
            logInfo("Edit Disk Group $diskGroupID: RAID 10 stripe size = $testParms{r10ss}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, R10SS => $testParms{r10ss}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if (defined($testParms{r5ss}))
        {
            logInfo("Edit Disk Group $diskGroupID: RAID 5 stripe size = $testParms{r5ss}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, R5SS => $testParms{r5ss}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if (defined($testParms{r5parity}))
        {
            logInfo("Edit Disk Group $diskGroupID: RAID 5 parity = $testParms{r5parity}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, R5PARITY => $testParms{r5parity}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if (defined($testParms{raidspervdisk}))
        {
            logInfo("Edit Disk Group $diskGroupID: RAIDs per VDisk = $testParms{raidspervdisk}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, RAIDSPERVDISK => $testParms{raidspervdisk}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if ($testParms{threshold})
        {
            logInfo("Edit Disk Group $diskGroupID: Threshold = $testParms{threshold}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, THRESHOLD => $testParms{threshold}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }
    }

    #
    # Setup the common drive info values depending on the RAID type.
    #
    if ("s" eq $argRAIDType)
    {
        $driveType     = XSSAUNSAFETYPE;
        $raidType      = 0;
        $minDriveCount = 1;
        $maxDriveCount = 1;
    }

    elsif ("0" eq $argRAIDType)
    {
        $driveType     = XSSAUNSAFETYPE;
        $raidType      = 0;
        $minDriveCount = 2;
        $maxDriveCount = 1024;
    }

    elsif ("1" eq $argRAIDType)
    {

        $driveType     = XSSADATATYPE;
        $raidType      = 10;
        $minDriveCount = 2;
        $maxDriveCount = 2;
    }

    elsif ("5" eq $argRAIDType)
    {
        $driveType     = XSSADATATYPE;
        $raidType      = 5;
        $minDriveCount = 3;
        $maxDriveCount = 1024;
    }

    elsif ("10" eq $argRAIDType)
    {
        $driveType     = XSSADATATYPE;
        $raidType      = 10;
        $minDriveCount = 2;
        $maxDriveCount = 1024;
    }
    else
    {
        logError("Invalid input test argument: $argRAIDType");
        return ERROR;
    }

    #
    # Get a list of all the required type of drive
    #
    logInfo("Get list of all drives labeled as $driveType...");
    if (GOOD != PdList(\@tempDriveList, $driveType))
    {
        logWarning("==> Unable to get physical disk list of label type $driveType");
        return ERROR;
    }

    #
    # If PDNUM was defined by the user then select exactly that many drives
    #
    if ($testParms{pdnum})
    {
        if (scalar(@tempDriveList) < $testParms{pdnum})
        {
            logWarning("==> Testparms require $testParms{pdnum} drives but " . "only " . scalar(@tempDriveList) . " are available");
            return ERROR;
        }

        $driveCount = $testParms{pdnum};
    }

    #
    # User didn't specify PDNUM
    # if the available count < min required then error
    # if the RAID type requires a maximum # of drives that use that value
    # else use all available drives
    #
    else
    {
        if (scalar(@tempDriveList) < $minDriveCount)
        {
            logInfo("RAID type $raidType requires $minDriveCount drives but " . " only " . scalar(@tempDriveList) . " are available");
            return ERROR;
        }

        elsif (scalar(@tempDriveList) > $maxDriveCount)
        {
            $driveCount = $maxDriveCount;
        }

        else
        {
            $driveCount = scalar(@tempDriveList);
        }
    }

    #
    # Push the required number of drives onto the final drive list
    #
    for (my $i = 0; $i < $driveCount; $i++)
    {
        push(@driveList, $tempDriveList[$i]);
    }

    #
    # Add the drives to the Disk Group
    #
    logInfo("Add these drives to Disk Group $diskGroupID: @driveList");

    if (XMCGOOD != diskgroupAdd(@driveList))
    {
        logWarning("==> The diskgroupAdd command failed");
        DumpXSSAError();
        return ERROR;
    }
    logInfo("---------------------------------------------------------");
    logInfo(" ");
    logInfo("Virtual disk RAID type: $raidType");

    #
    # Get the Disk Group info
    #
    logInfo("Disk Group $diskGroupID info");

    my %dgInfo = XIOtech::sanscript::diskgroupInfo($diskGroupID);

    if (!%dgInfo)
    {
        logWarning("==> The diskgroupInfo command failed");
        DumpXSSAError();
    }
    else
    {
        foreach my $name (keys %dgInfo)
        {
            logInfo("   $name $dgInfo{$name}");
        }
    }

    # Now start creating virtual disks
    # First feel in all the free virutal disk id's with in used vblocks
    # and work sets

    #
    # Finding free ids in the used work sets and vblocks
    #
    $Return = FindFreeVdIds(\@VdIdFree, \@VBInUse, \@WSInUse);

    if ($Return != GOOD)
    {
        logWarning("Error while getting free vd ids from used ws and used vb");
        return ERROR;
    }
    if (scalar(@VdIdFree))
    {

        #
        # feel in all used work set - vblock pares
        #
        for (my $loop = 0; $loop < scalar(@VdIdFree); $loop++)
        {
            logInfo(" ");
            logInfo("-----------------------------");
            logInfo("Creating VdId $VdIdFree[$loop] in WS $WSInUse[$loop] and VB $VBInUse[$loop]");
            $Return = VDCreate($VDCount, $capacity, $VdIdFree[$loop], $raidType, $WSInUse[$loop], $VBInUse[$loop], $diskGroupID);

            if ($Return != GOOD)
            {

                logInfo("Failed to creat virtual disk number $VDCount");
                logWarning("Test Failed");
                return ERROR;
            }
            DelaySecs(10);

            $VDCount++;
        }
    }

    # find all free work sets and vblocks
    # choose the first avaluable free work set and create 8 vlocks (max
    # number of vblocks allowed in the work set)
    # in the each block create 0-31 vd's

    $Return = FindFreeWB(\@FreeVB, \@FreeWS);

    if ($Return != GOOD)
    {
        logWarning("Failed while looking for free Vblocks and Work Sets");
        return ERROR;
    }

    # if there is free vblock avaluable that means that there's free work
    # set as avaluable as well since there're 16 work set and 16 vblcoks

    my $count = 0;    # used to track number of vlocks created
                      # in the work set, max number for the variable
                      # is 8, when the variable reaches 7 ( 0-7 -> 8 vblocks)
                      # use the second avaluable free work set
    my @WorkSetTemp;  # used as a temperary array, to keep track of the workset
                      # in which virutal disks are being created, so that later
                      # we can delete them

    if (@FreeVB)
    {
        for (my $q = 0; $q < scalar(@FreeVB); $q++)
        {
            if ($count < $VbLim)
            {

                #
                # need to find work set what has less then 16 vblocks in it
                #
                $TestWS = $FreeWS[0];
                $count++;

            }
            else
            {
                $TestWS = $FreeWS[1];
            }

            for (my $VdId = 0; $VdId < 32; $VdId++)
            {
                $Return = VDCreate($VDCount, $capacity, $VdId, $raidType, $TestWS, $FreeVB[$q], $diskGroupID);
                if ($Return != GOOD)
                {
                    logInfo("Failed to creat virtual disk number $VDCount");
                    logWarning("Test Failed");
                    return ERROR;
                }

                DelaySecs(10);
                $VDCount++;
                push(@VdIdCreatedDurringTest, $VdId);         # in order to delete virutal disks
                push(@WorkCreatedDurringTest, $TestWS);
                push(@FreeCreatedDurringTest, $FreeVB[$q]);

            }
            push(@WorkSetTemp, $TestWS);                      # in order to remove virtual blocks
        }
    }
    else
    {
        logInfo("There's no free vblocks");
    }

    # The system has reached max number of virtual disks
    # Make sure that creating virtual disks over the limit allowed
    # returns error
    # Get the list of all used worksets and vblocks
    # In each vblock create extra virutal disk
    # Make sure the command fails as expected
    my @AllVbInUse;
    my @AllWsInUse;

    $Return = AllVBList(\@AllVbInUse, \@AllWsInUse);

    if ($Return != GOOD)
    {
        logWarning("Error occurred while trying to find in use vblock and in use workset");
        return ERROR;
    }

    for (my $InUse = 0; $InUse < scalar(@AllVbInUse); $InUse++)
    {
        logInfo(" ");
        logInfo("-----------------------------------------");
        logInfo(" ");
        logInfo(" Attempting to create Vd Id 32 in WS $AllWsInUse[$InUse], VB $AllVbInUse[$InUse] ");
        logInfo("**** Command is expected to fail ****");

        logInfo("Creating Vd Id 32 - The command is expected to fail");

        $Return = VDCreate("Extra", $capacity, 32, $RaidType, $AllWsInUse[$InUse], $AllVbInUse[$InUse], $diskGroupID);
        if ($Return == GOOD)
        {
            logWarning("Failed: was able to create vd id 32 - Operation is not allowed");
            return ERROR;
        }

        DelaySecs(10);

    }

    # First delete all create durring the test virutal disks
    # in all vblocks that had virutal disks
    # an the beging of the test
    logInfo("Deleting all created virtual disks");

    $Return = DeleteVDList(\@VdIdFree, \@WSInUse, \@VBInUse);
    if ($Return != GOOD)
    {
        logWarning("Failed while deleting virtual disks");
        return ERROR;
    }

    # Second delete virtual disks in the vblocks that didn't have any virtual disks
    # at the beggining of the test
    #
    $Return = DeleteVDList(\@VdIdCreatedDurringTest, \@WorkCreatedDurringTest, \@FreeCreatedDurringTest);
    if ($Return != GOOD)
    {
        logWarning("Failed while deleting virtual disks");
        return ERROR;
    }

    DelaySecs(10);

    logInfo("Deleting added vblocks");

    $Return = DeleteVBList(\@FreeVB, \@WorkSetTemp);

    if ($Return != GOOD)
    {
        logWarning("Failed while deleting added vblocks");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: FindFreeVdIds
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################

sub FindFreeVdIds
{
    my ($FreeVdId, $Vblock, $WorkSet) = @_;

    trace();

    my @VdId = (0 .. 31);
    my $Return;

    my @VblockInUse;
    my @WorkSetInUse;

    $Return = AllVBList(\@VblockInUse, \@WorkSetInUse);

    #    print "Vb in use @VblockInUse, ws in use @WorkSetInUse \n";

    if ($Return != GOOD)
    {
        logWarning("Error occurred while trying to find in use vblock and in use workset");
        return ERROR;
    }

    if ((scalar(@VblockInUse) == 0) || (scalar(@WorkSetInUse) == 0))
    {
        logWarning("There're no combination of vblock and workset in use");
        return GOOD;
    }

    for (my $loop = 0; $loop < scalar(@VblockInUse); $loop++)
    {

        $Return = SetWorkBlock($WorkSetInUse[$loop], $VblockInUse[$loop]);

        if ($Return != GOOD)
        {
            return ERROR;
        }

        #
        # Get the list of vd's
        #
        my $VdInUse = vdiskList();

        my $Check;
        my $Ext;

        #
        #print "Vd in use @$VdInUse \n";
        #
        if ($VdInUse)
        {

            for ($Ext = 0; $Ext < scalar(@VdId); $Ext++)
            {

                $Check = TRUE;

                for (my $InUse = 0; $InUse < scalar(@$VdInUse); $InUse++)
                {

                    #
                    #print "Compareing vd id $$VdInUse[$InUse] to $VdId[$Ext]\n";
                    #
                    if ($$VdInUse[$InUse] == $VdId[$Ext])
                    {

                        #print "Check = false \n";
                        $Check = FALSE;
                        last;
                    }
                }

                #
                #print "Check $Check \n";
                #
                if ($Check == TRUE)
                {

                    #
                    #print "Check = true: vd id $VdId[$Ext],  vb $VblockInUse[$loop], ws $WorkSetInUse[$loop] \n";
                    #
                    push(@$FreeVdId, $VdId[$Ext]);
                    push(@$Vblock,   $VblockInUse[$loop]);
                    push(@$WorkSet,  $WorkSetInUse[$loop]);
                }
            }
        }
        else
        {

            #
            # all vd id's are free
            #
            for (my $t = 0; $t < scalar(@VdId); $t++)
            {
                push(@$FreeVdId, $VdId[$t]);
                push(@$Vblock,   $VblockInUse[$loop]);
                push(@$WorkSet,  $WorkSetInUse[$loop]);
            }
        }
    }

    logInfo(" ");
    logInfo("----------------------------------------------------");
    logInfo(" ");

    logInfo("Following is the list of work set - vblock - free vd");
    for (my $t = 0; $t < scalar(@$FreeVdId); $t++)
    {
        logInfo("$$WorkSet[$t] - $$Vblock[$t] - $$FreeVdId[$t]");
    }

    return GOOD;

}

##############################################################################
#
#          Name: MagGoodPath
#
#        Inputs:  $cnc - serial number of the Bigfoot
#                 $TestLoop - numer of times to executed the test
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################

sub MagGoodPath
{
    my ($cnc, $system) = @_;

    trace();

    my $Return;

    $Return = CommonCommands($cnc, $system);

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Common commands");
        return ERROR;
    }

    $Return = PdiskCommands($system);

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Physical Disk commands");
        return ERROR;
    }

    $Return = DiskGroupCommands();

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Work Set Vblock commands");
        return ERROR;
    }

    my @ClusterList;

    $Return = FreeClusters(\@ClusterList);

    if ($Return != GOOD)
    {
        logWarning("Unable to get the list of free clusters");
        return ERROR;
    }

    logInfo("Free cluster list: @ClusterList ");

    #
    # Set the first free cluster on the free cluster list
    #
    $Return = XIOtech::sanscript::clusterSet($ClusterList[0]);

    if ($Return != XMCGOOD)
    {
        logWarning("Unable to set cluster id $ClusterList[0] ");
        DumpXSSAError();
        return ERROR;
    }

    $Return = VdiskCommands($system);

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Vdisk commands");
        return ERROR;
    }

    $Return = VdiskServerCommands($system);

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Vdisk Server Commands commands");
        return ERROR;
    }

    $Return = VlinkCommands();

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Vlink commands");
        return ERROR;
    }

    $Return = VlinkCommands();

    if ($Return != GOOD)
    {
        logWarning("Error: Test failed while executing Vlink commands");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: UsedClusters
#
#        Inputs:  None
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################
sub UsedClusters
{
    my ($UsedCluster) = @_;

    trace();

    my @ClusterList = (0, 1, 2, 3, 4, 5, 6, 7);
    my $VdList;
    my $Return;

    logInfo("Looking for used clusters...");
    logInfo(" ");
    for (my $i = 0; $i < scalar(@ClusterList); $i++)
    {
        $Return = XIOtech::sanscript::clusterSet($ClusterList[$i]);
        if ($Return != XMCGOOD)
        {
            logWarning("Unable to set cluster id $ClusterList[$i] ");
            DumpXSSAError();
            return ERROR;
        }
        logInfo("Cluster now - $ClusterList[$i] getting virutal disk list ");
        my $VdList = vdiskList();

        if ($VdList)
        {
            if (scalar(@$VdList) != 0)
            {
                push(@$UsedCluster, $ClusterList[$i]);
            }
        }
        else
        {
            logWarning("Unable to get vd id list from cluster $ClusterList[$i] ");
            DumpXSSAError();
            return ERROR;
        }
    }
    return GOOD;

}

##############################################################################
#
#          Name: FreeClusters
#
#        Inputs:  None
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################
sub FreeClusters
{
    my ($FreeClusters) = @_;

    trace();

    my @UsedClusters;
    my $Check;

    logInfo(" ");
    logInfo("Looking for free clusters....");

    my @ClusterList = (0, 1, 2, 3, 4, 5, 6, 7);
    my $Return = UsedClusters(\@UsedClusters);
    if ($Return != GOOD)
    {
        logWarning("Unable to get list of Used Clusters");
        return ERROR;
    }

    for (my $AllC = 0; $AllC < scalar(@ClusterList); $AllC++)
    {
        $Check = TRUE;

        for (my $UsedC = 0; $UsedC < scalar(@UsedClusters); $UsedC++)
        {
            if ($UsedClusters[$UsedC] == $ClusterList[$AllC])
            {
                $Check = FALSE;
            }
        }
        if ($Check == TRUE)
        {
            push(@$FreeClusters, $ClusterList[$AllC]);
        }
    }
    return GOOD;
}

##############################################################################
#
#          Name:  MaxExpandBigfoot
#
#        Inputs:  None
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################

sub MaxExpandBigfoot
{
    my ($Raid, $pTestParms, $system) = @_;

    trace();

    my $Return;

    my @FreeVblock;
    my @FreeWS;

    $Return = FindFreeWB(\@FreeVblock, \@FreeWS);

    if ($Return != GOOD)
    {
        logWarning("Error occured while getting free cluster");
        return ERROR;
    }

    if ((scalar(@FreeWS) == 0) || (scalar(@FreeVblock) == 0))
    {
        logInfo("There's no free work set - vblock pare avaluable to perform the test");
        return ERROR;
    }

    $Return = SetWorkBlock($FreeWS[0], $FreeVblock[0]);

    if ($Return != GOOD)
    {
        logInfo("Error occured while trying to set vblock - work set pare");
        return ERROR;
    }

    $Return = MaxVdExp($Raid, $system, $pTestParms);

    if ($Return != GOOD)
    {
        logInfo("Test failed");
        return ERROR;
    }

    #
    # delete vblock or cluster
    #
    logInfo("------------ vblockRemove ------------ ");
    $Return = vblockRemove($FreeVblock[0]);

    if ($Return != XMCGOOD)
    {
        logInfo("Unable to remove block is $FreeVblock[0]");
        DumpXSSAError();
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name:  MaxExpandMagnitude
#
#        Inputs:  None
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Performs most used virtual disk functions in a repetitive
#                fusion. The functions are: create virtual disk, expand
#                virtual disk, mask virtual disk to a server, delete
#                virtual disk.
#
##############################################################################

sub MaxExpandMagnitude
{
    my ($Raid, $pTestParms, $system) = @_;

    trace();

    my $Return;
    my @FreeCluster;

    logInfo(" ");
    logInfo("------------ clusterSet ------------ ");

    $Return = FreeClusters(\@FreeCluster);
    if ($Return != GOOD)
    {
        logWarning("Error occured while getting free cluster");
        return ERROR;
    }
    if (scalar(@FreeCluster) == 0)
    {
        logInfo("There's no free clusters avaluable");
        return ERROR;
    }

    $Return = clusterSet($FreeCluster[0]);

    if ($Return != XMCGOOD)
    {
        logInfo("Failed to set cluseter $FreeCluster[0] ");
        DumpXSSAError();
        return ERROR;
    }

    $Return = MaxVdExp($Raid, $system, $pTestParms);

    if ($Return != GOOD)
    {
        logInfo("Test failed");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name:  MaxVdExp
#
#        Inputs:  None
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Creates and sets pdisk group for vdisk creation
#
##############################################################################

sub MaxVdExp
{
    my ($argRAIDType, $System, $pTestParms) = @_;

    trace();

    my $raidType;
    my %testParms;
    my $diskGroupID = 0;
    my $loopCount   = 1;    # Internal loop count - used to optimaze the test time
                            # number of times to run the test, default to 1 if use does not
                            # pass the paremter
    my $Return;

    my $VdId     = 0;
    my $capacity = 1024;
    my $ExpCap   = 1024;
    my $ExpMax;
    my $MaxRaids = 10;      # when virtual disk contains 10 raids, no more expantions
                            # will be allowed

    #
    # set and edit disk group
    #
    $Return = DiskGroupToRaid($argRAIDType, $diskGroupID, $pTestParms);

    if ($Return != GOOD)
    {
        logInfo("Failed to set and edit disk group");
        return ERROR;
    }

    #
    # get the internel loop count to execute the test
    #
    if ((defined($pTestParms)) && ($pTestParms != NULL))
    {
        %testParms = %$pTestParms;

        #
        # get the loop count if passed
        #
        if (defined($testParms{loop}))
        {
            $loopCount = $testParms{loop};
        }
    }

    #
    # get the right raid type to create the virtual disk
    #
    if ("s" eq $argRAIDType)
    {
        $raidType = 0;
    }

    elsif ("0" eq $argRAIDType)
    {
        $raidType = 0;
    }

    elsif ("1" eq $argRAIDType)
    {
        $raidType = 10;
    }

    elsif ("5" eq $argRAIDType)
    {
        $raidType = 5;
    }

    elsif ("10" eq $argRAIDType)
    {
        $raidType = 10;
    }
    else
    {
        logError("Invalid input test argument: $argRAIDType");
        return ERROR;
    }

    for (my $i = 0; $i < $loopCount; $i++)
    {

        logInfo("*******************************************");
        logInfo(" ");
        logInfo("Total: $loopCount, done: $i, left to do: " . ($loopCount - $i));
        logInfo(" ");

        logInfo(" ");
        logInfo("------------ vdiskCreate ------------ ");

        logInfo("Creating vd id $VdId, raid $argRAIDType");

        $Return = vdiskCreate($VdId, $argRAIDType, $capacity);

        if ($Return != XMCGOOD)
        {
            logWarning("Command failed for vd id vdiskCreate $VdId raid $argRAIDType");
            DumpXSSAError();
            return ERROR;
        }

        DelaySecs(20);

        logInfo(" ");
        logInfo("------------ vdiskInfo ------------ ");

        my %VdInfo = vdiskInfo($VdId);

        if (%VdInfo)
        {
            foreach my $name (keys %VdInfo)
            {
                logInfo("$name $VdInfo{$name}");
            }
        }
        else
        {
            logWarning("Command failed for vd id $VdId");
            DumpXSSAError();
            return ERROR;
        }

        # max number of raids allowed in on vd is 16 on both Bigfoot and Mag
        # Mag:
        #   when number of reaids reachers 11 + 5 = 16 the last expantion is allowed to occure
        #   when the number of raids reachers 12 no more expantions shall be allowed
        # Bigfoot:
        #   when number of reaids reaches 12 + 4 = 16 the last expantion is allowed to occure
        #   when the number of reaids reachers 13 no more expantions allowed

        logInfo(" ");
        logInfo("------------ vdiskExpand ------------ ");

        my $ExpLoop     = TRUE;
        my $NumExpended = 0;

        while ($ExpLoop == TRUE)
        {

            #
            # if check == TRUE means that virtual disk can be yet expanded
            #
            $Return = vdiskExpand($VdId, $ExpCap);

            if ($Return != XMCGOOD)
            {

                logInfo(" ");
                logInfo("Virtual disk was expanded $NumExpended times");
                logWarning("Unable to expand vdisk $VdId raid $argRAIDType by $capacity MB ");
                DumpXSSAError();
                return ERROR;
            }

            $NumExpended++;

            logInfo("Expansion N $NumExpended for Vd Id $VdId by capacity $ExpCap MB");

            DelaySecs(20);

            %VdInfo = vdiskInfo($VdId);

            if (%VdInfo)
            {

                logInfo("Current Number of RAIDs in vd id $VdId is $VdInfo{NUMBER_OF_RAIDS}");
                if ($VdInfo{NUMBER_OF_RAIDS} < $MaxRaids)
                {

                    logInfo("Continue to expand...");
                }
                else
                {
                    logInfo("Shall not expand no more...");
                    $ExpLoop = FALSE;
                }
            }
            else
            {
                logWarning("Unable to get vdisk information");
                DumpXSSAError();
                return ERROR;

            }

        }

        logInfo("The expand command is expected to fail since there are $VdInfo{NUMBER_OF_RAIDS} RAIDs already present ");

        $Return = vdiskExpand($VdId, $ExpCap);

        if ($Return == XMCGOOD)
        {

            DelaySecs(20);

            %VdInfo = vdiskInfo($VdId);

            if (%VdInfo)
            {
                logInfo("Current Number of RAIDS in vd id $VdId is $VdInfo{NUMBER_OF_RAIDS}");
            }
            else
            {
                logWarning("Unable to get vdisk information");
                DumpXSSAError();
                return ERROR;

            }

            logInfo(" ");
            logInfo("Error: Was able to expand virtual disk ");
            logInfo("--------------------------------------------------------------------");
            logInfo(" ");
            logInfo("Checking ERROR  PATH -----------------------------------------------");
            logInfo("Checking max RAIDs allowed in one VD - shall not be greater than 10");

            my $RAIDcheck = TRUE;

            while ($RAIDcheck == TRUE)
            {

                $Return = vdiskExpand($VdId, $ExpCap);

                if ($Return != XMCGOOD)
                {
                    logWarning("Current number of RAIDS in vd id $VdId is $VdInfo{NUMBER_OF_RAIDS}");
                    DumpXSSAError();
                    return ERROR;
                }

                DelaySecs(20);

                %VdInfo = vdiskInfo($VdId);

                if (%VdInfo)
                {
                    if ($VdInfo{NUMBER_OF_RAIDS} < ($MaxRaids + 10))    # 10 is just a number out of my head
                    {
                        logInfo("Current Number of RAID in vd id $VdId is $VdInfo{NUMBER_OF_RAIDS}");

                    }
                    else
                    {
                        $RAIDcheck = FALSE;
                    }
                }
                else
                {
                    logWarning("Unable to get vdisk information");
                    DumpXSSAError();
                    return ERROR;

                }

            }

            return ERROR;
        }

        logInfo("Expand command failed as expected ");
        DumpXSSAError();

        logInfo(" ");
        logInfo("------------ vdiskInfo After expand ------------ ");

        %VdInfo = vdiskInfo($VdId);

        if (%VdInfo)
        {
            foreach my $name (keys %VdInfo)
            {
                logInfo("$name $VdInfo{$name}");
            }
        }
        else
        {
            logWarning("Command failed for vd id $VdId");
            DumpXSSAError();
            return ERROR;
        }

        logInfo(" ");
        logInfo("------------ vdiskDelete ------------ ");

        $Return = vdiskDelete($VdId);

        if ($Return != XMCGOOD)
        {
            logWarning("Command failed");
            DumpXSSAError();
            return ERROR;
        }
    }

    return GOOD;

}

##############################################################################
#
#          Name:  DiskGoupRaid
#
#        Inputs:  None
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Creates and sets pdisk group for vdisk creation
#
##############################################################################

sub DiskGroupToRaid
{
    my ($argRAIDType, $diskGroupID, $pTestParms) = @_;

    trace();

    my %testParms;
    my $driveType;        # Type of the physical drives to retrieve
    my $raidType;         # virutal disk XSSARAID type
    my $minDriveCount;    # min number of drives allowed for the RAID type
    my $maxDriveCount;    # max number of the drives allowed for the RAID type
    my @tempDriveList;    # Temp list of drives with specified label
    my @driveList;        # Acctual list of drive to be used in the test to create virtual disks
    my $driveCount;

    #
    # Select the Disk Group
    #
    logInfo("Select Disk Group $diskGroupID");
    if (XMCGOOD != diskgroupSet($diskGroupID))
    {
        logWarning("==> The diskgroupSet command failed");
        DumpXSSAError();
        return ERROR;
    }

    if ((defined($pTestParms)) && ($pTestParms != NULL))
    {
        %testParms = %$pTestParms;

        if (defined($testParms{name}))
        {
            logInfo("Edit Disk Group $diskGroupID: Name = $testParms{name}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, NAME => $testParms{name}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if (defined($testParms{desc}))
        {
            logInfo("Edit Disk Group $diskGroupID: Description = $testParms{desc}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, DESC => $testParms{desc}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if (defined($testParms{r10ss}))
        {
            logInfo("Edit Disk Group $diskGroupID: RAID 10 stripe size = $testParms{r10ss}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, R10SS => $testParms{r10ss}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if (defined($testParms{r5ss}))
        {
            logInfo("Edit Disk Group $diskGroupID: RAID 5 stripe size = $testParms{r5ss}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, R5SS => $testParms{r5ss}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
            XIOtech::sanscript::diskgroupInfo($diskGroupID);
        }
        if (defined($testParms{r5parity}))
        {
            logInfo("Edit Disk Group $diskGroupID: RAID 5 parity = $testParms{r5parity}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, R5PARITY => $testParms{r5parity}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if (defined($testParms{raidspervdisk}))
        {
            logInfo("Edit Disk Group $diskGroupID: RAIDs per VDisk = $testParms{raidspervdisk}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, RAIDSPERVDISK => $testParms{raidspervdisk}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }

        if ($testParms{threshold})
        {
            logInfo("Edit Disk Group $diskGroupID: Threshold = $testParms{threshold}");
            if (XMCGOOD != XIOtech::sanscriptET::diskgroupEdit($diskGroupID, THRESHOLD => $testParms{threshold}))
            {
                logWarning("==> The diskgroupEdit command failed");
                DumpXSSAError();
                return ERROR;
            }
        }
    }

    #
    # Setup the common drive info values depending on the RAID type.
    #
    if ("s" eq $argRAIDType)
    {
        $driveType     = XSSAUNSAFETYPE;
        $minDriveCount = 1;
        $maxDriveCount = 1;
    }

    elsif ("0" eq $argRAIDType)
    {
        $driveType     = XSSAUNSAFETYPE;
        $minDriveCount = 2;
        $maxDriveCount = 1024;
    }

    elsif ("1" eq $argRAIDType)
    {

        $driveType     = XSSADATATYPE;
        $minDriveCount = 2;
        $maxDriveCount = 2;
    }

    elsif ("5" eq $argRAIDType)
    {
        $driveType     = XSSADATATYPE;
        $minDriveCount = 3;
        $maxDriveCount = 1024;
    }

    elsif ("10" eq $argRAIDType)
    {
        $driveType     = XSSADATATYPE;
        $minDriveCount = 2;
        $maxDriveCount = 1024;
    }
    else
    {
        logError("Invalid input test argument: $argRAIDType");
        return ERROR;
    }

    #
    # Get a list of all the required type of drive
    #
    logInfo("Get list of all drives labeled as $driveType...");
    if (GOOD != PdList(\@tempDriveList, $driveType))
    {
        logWarning("==> Unable to get physical disk list of label type $driveType");
        return ERROR;
    }

    #
    # If PDNUM was defined by the user then select exactly that many drives
    #
    if ($testParms{pdnum})
    {
        if (scalar(@tempDriveList) < $testParms{pdnum})
        {
            logWarning("==> Testparms require $testParms{pdnum} drives but " . "only " . scalar(@tempDriveList) . " are available");
            return ERROR;
        }

        $driveCount = $testParms{pdnum};
    }

    #
    # User didn't specify PDNUM
    # if the available count < min required then error
    # if the RAID type requires a maximum # of drives that use that value
    # else use all available drives
    #
    else
    {
        if (scalar(@tempDriveList) < $minDriveCount)
        {
            logInfo("RAID type $raidType requires $minDriveCount drives but " . " only " . scalar(@tempDriveList) . " are available");
            return ERROR;
        }

        elsif (scalar(@tempDriveList) > $maxDriveCount)
        {
            $driveCount = $maxDriveCount;
        }

        else
        {
            $driveCount = scalar(@tempDriveList);
        }
    }

    #
    # Push the required number of drives onto the final drive list
    #
    for (my $i = 0; $i < $driveCount; $i++)
    {
        push(@driveList, $tempDriveList[$i]);
    }

    #
    # Add the drives to the Disk Group
    #
    logInfo("Add these drives to Disk Group $diskGroupID: @driveList");

    if (XMCGOOD != diskgroupAdd(@driveList))
    {
        logWarning("==> The diskgroupAdd command failed");
        DumpXSSAError();
        return ERROR;
    }

    #
    # Get the Disk Group info
    #
    logInfo(" ");
    logInfo("Disk Group $diskGroupID info");

    my %dgInfo = XIOtech::sanscript::diskgroupInfo($diskGroupID);

    if (!%dgInfo)
    {
        logWarning("==> The diskgroupInfo command failed");
        DumpXSSAError();
    }
    else
    {
        foreach my $name (keys %dgInfo)
        {
            logInfo("   $name $dgInfo{$name}");
        }
    }

    return GOOD;

}

##############################################################################
#
#          Name: ORTWrapper
#
#        Inputs: @FwFiles
#                $ObjList
#                $inFlags
#                $inLoops
#                $fwKitcnt
#                $testGroup
#                $testRecord
#                $recordGroup
#                $parmsPtr
#
#
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Calls the test function for ORT using code updates to cycle
#                through a mixed set of releases (max 9)
##############################################################################

sub ORTWrapper
{

    #my ( $FwFilesPtr, $ObjList, $cnc, $inFlags, $inLoops, $fwKitcnt, $testGroup, $testRecord, $recordGroup, $xtcDataPtr ) = @_;
    my ($FwFilesPtr, $ObjList, $inFlags, $inLoops, $fwKitcnt, $testGroup, $testRecord, $recordGroup, $parmsPtr) = @_;

    my $return;
    my $mes;
    my $TestLoop;
    my $testRef;
    my $iloop   = 0;
    my @FwFiles = @$FwFilesPtr;
    my @ccbeObjArray;
    my $cnc    = $parmsPtr->{CURSERIALNUMBER};
    my $system = "Magnitude 3D";

    #
    # Start of test loop
    #
    for ($iloop = 0; $iloop < $inLoops; $iloop++)
    {

        #if(XSSA_Reserve($xtcDataPtr->{CURSERIALNUMBER}) != GOOD)
        if (XSSA_Reserve($parmsPtr->{CURSERIALNUMBER}) != GOOD)
        {
            logInfo("Unable to reserver CNC $parmsPtr->{CURSERIALNUMBER} ");
            return ERROR;
        }

        if ($parmsPtr->{CURTESTARGUMENT} == 0)
        {

            #
            # Send message to the controllers
            #
            $mes    = "***** Starting On-Going Reliability test";
            $return = TestLibs::IntegCCBELib::CtlrLogTextAll(\@ccbeObjArray, $mes);

            if ($return != GOOD)
            {
                logInfo("Unable to send message to debug console");
                return ERROR;
            }

            for (my $index = 0; $index < scalar(@FwFiles); $index++)
            {

                #
                # print message on the screen
                #
                $mes = "Updating device serial $parmsPtr->{CURSERIALNUMBER} to release $FwFiles[$index]";
                TestLibs::Logging::logInfo($mes);

                logInfo("--------------------- Loop $iloop of $inLoops completed. -------------------");

                #
                # Call Test Function
                #
                if (RollingCodeApply($FwFiles[$index], $ObjList, $inFlags, $inLoops, $fwKitcnt, $testRef, $iloop, $parmsPtr) != GOOD)

                {
                    logInfo("Test failed while updating CNC $parmsPtr->{CURSERIALNUMBER} to FW $FwFiles[$index]");
                    return ERROR;
                }
                logInfo("--------------------- Making a configuration change -------------------");

                # Make configuration change
                # Scrubbing, defrags, Goodpath...  Something that should not fail

                # Add random test selection
                logInfo("--------------------- Starting XSSAGoodPath - ORT mid-change  -------------------");
                if (GoodPathBigfoot($cnc, $system) != GOOD)
                {
                    logInfo("Test failed while executing XSSA Bigfoot Good Path script - ORT ");
                    return ERROR;
                }

####### Configuration Change & wait (33 hours) .  may need to change this based on the number of firmware files
####### and how long each configuration change takes.
                logInfo("------ On-Going Reliability - Extended Data Verification running ------");

                DelaySecs(120000);

                #Need to refresh ICON connection
                if (XSSA_Reserve($parmsPtr->{CURSERIALNUMBER}) != GOOD)
                {
                    logInfo("Connection already exist");
                }

                # need to refresh the connections
                $return = TestNReconnectAll($ObjList);

                if ($return != GOOD)
                {
                    logInfo("Unable to send message to debug console");
                    return ERROR;
                }

                logInfo("--------------------- Loop $iloop of $inLoops completed. -------------------");

            }

        }
    }
    return GOOD;
}

1;    # we need this for a PM

###############################################
#
# Revision history
#
# $Log$
# Revision 1.3  2006/12/15 17:54:45  PlasterE
# Added support for 750 RCU.  The directory Test/TestLibs/WsLib holds the DLLs
# needed in order to communicate to Ewok.
# TBolt00000000
#
# Revision 1.2  2005/09/13 14:21:57  ElvesterN
# Added CTE update conditional.
# Reviewed by Neal Eiden.
#
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
# Revision 1.36  2005/04/01 15:50:58  EidenN
# Tbolt00000:  Added On-going reliability testcase
#
# Revision 1.35  2005/03/02 16:55:14  EidenN
# Tbolt0000000:  Fixed XSSACodeUpdate pointer deref - Reviewed By:  PalmiD
#
# Revision 1.34  2005/02/18 16:27:46  EidenN
# Tbolt0000:  Fixed RESETALL test and changed DEBUG Log to CtlrLogTextAll(\@ccbeObjArray, $mes); Reviewed By: FlemingS
#
# Revision 1.33  2005/02/10 20:08:28  EidenN
# Tbolt0000:  Added delay to vdiskLockOff in GOODPATH  and add wookie support - Reviewed by: FlemingS
#
# Revision 1.32  2005/02/07 14:22:59  EidenN
# Tbolt0000:  Changed passed in parms to XSSACodeupdate - Reviewed by: Cmenning
#
# Revision 1.31  2004/12/22 21:44:36  EidenN
# Tbolt:000000:  Increased wait time between code updates - Reviewed by: CMenning
#
# Revision 1.30  2004/12/06 22:49:45  EidenN
# Tbolt0000: Re-write of  RollingCodeApply.  Created CodeUpdateWrapper.  Added Validation Flags,  Test Loop count  and moved data to the proper place.  Reviewed by:  MenningC
#
# Revision 1.29  2004/10/18 16:18:28  EidenN
# no message
#
# Revision 1.28  2004/10/03 18:02:43  EidenN
# Tbolt0000:  Fixed XSSACodeUpdate to find the master controller.  Evel error that should have been an ==
#
# Revision 1.27  2004/09/15 18:31:42  EidenN
# Tbolt0000:  Fixed Magnitude/Magnitude 3D names from 1/2.  Fixed Comments sections.
#
# Revision 1.26  2004/04/14 18:06:06  MenningC
# tbolt00000000: fixed a startup warning, reviewed by Al
#
# Revision 1.25  2004/02/25 21:27:25  VossO
# Tbolt00000000 added ICONApplay funciton
#
# Revision 1.24  2004/02/17 20:54:44  VossO
# Tbolt00000000 Added time delay between code udpates
#
# Revision 1.23  2004/02/12 16:42:21  MenningC
# tbolt00000000: comment out call to vblock test per Neal.  Reviewed by Eiden.
#
# Revision 1.22  2004/01/06 22:47:26  VossO
# Tbolt00000000 Edit the file
#
# Revision 1.21  2003/11/25 18:56:28  VossO
# Tbolt changes made last time didn't get saved or checked in due to the mess with the name change
#
# Revision 1.20  2003/10/15 15:29:48  TeskeJ
# tbolt00009173 - raid-5 updates for release 3, mostly vdmax & crexpassocdel
# rev by Craig
#
# Revision 1.19  2003/10/02 19:35:51  GrigorenkoO
# Tbolt00000000 Fixed bug, rev JT
#
# Revision 1.18  2003/10/02 19:20:01  TeskeJ
# tbolt00009183 - RAID 5 changes in xssavdmax code and configuration file
# rev by Olga
#
# Revision 1.17  2003/09/29 20:44:38  ThiemanE
# Changed names to be compatible with linux
#
# Revision 1.16  2003/09/26 23:21:50  ThiemanE
# Changed name of some libraries that are lincluded to make the XTC linux compatible
#
# Revision 1.15  2003/09/23 16:47:23  TeskeJ
# tbolt00009173 - Release 3 test code changes
# rev by Olga
#
# Revision 1.14  2003/09/09 19:33:04  GrigorenkoO
# Tbolt00000000 changed CrExpAssocDel script to handle empty hash being passed to it
#
# Revision 1.13  2003/09/05 18:47:09  GrigorenkoO
# Tbol00000000 Added reset all test / w code update case and reset all DSC test case
#
# Revision 1.12  2003/08/20 13:31:47  GrigorenkoO
# Tbolt00000000 edit the file rev Craig
#
# Revision 1.11  2003/08/18 21:03:03  GrigorenkoO
# Tbolt moved function from Launcher to the lib rev Craig
#
# Revision 1.10  2003/08/18 18:13:21  GrigorenkoO
# Tbolt00000000 Added test and reconect to code update
#
# Revision 1.9  2003/08/05 19:34:53  GrigorenkoO
# Tbolt00000000 fixed create max vd script
#
# Revision 1.8  2003/07/23 15:00:08  GrigorenkoO
# Tbolt00000000 Added new test cases
#
# Revision 1.7  2003/07/09 15:02:37  GrigorenkoO
# Tbolt00000000 Added new function
#
# Revision 1.6  2003/05/01 18:58:22  GrigorenkoO
# Tbolt00000000 Added fuction create copies
#
# Revision 1.5  2003/05/01 14:43:02  GrigorenkoO
# Tbold00000000 Added copy mirror option to code update test case
#
# Revision 1.4  2003/04/22 15:28:33  GrigorenkoO
# Tbolt00000000 Added XSSACodeUpdate, XSSALabel, XSSADefrag Test cases
#
# Revision 1.3  2003/03/26 21:24:53  WerningJ
# Removed calls to unused modules
# Reviewed by Craig M
#
# Revision 1.2  2003/03/05 20:15:04  WerningJ
# Use XIOTech::sanscript library
# Reviewed by Craig M
#
# Revision 1.1  2003/02/26 22:03:05  GrigorenkoO
# Tbolt00000 new file reviewed by Craig Menning
#
# Revision 1.6  2003/02/19 19:52:23  GrigorenkoO
#
#
#
#
###############################################
