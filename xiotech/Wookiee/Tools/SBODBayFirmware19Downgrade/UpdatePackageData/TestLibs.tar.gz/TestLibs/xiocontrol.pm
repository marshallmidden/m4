#! /user/bin/perl -I ../PerlLibs -w
# $Header$

##############################################################################
#
#   Power switch control support
#
#   Copyright 2004  XIOtech   
#
#   1/21/2004 Craig Menning
#
#   A program to turn on and off power using a remote power switch.
#
##############################################################################
#
#
##############################################################################
#
#   For XIOtech internal use only.
#
##############################################################################

package TestLibs::xiocontrol;

use TestLibs::Constants qw(:DEFAULT);
use TestLibs::Logging;
# use PerlLibs::Net::Telnet ();

use LWP;
use HTTP::Request::Common;
use HTML::Form;

use strict;

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 24746 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point is ACPowerControl()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &ACPowerControl

                        &ControlApc
                        &ControlApcWeb
                        &ControlMoxaAPI
                        &ControlMoxaTelnet

                        &Letter2Number
                        &Number2Letter
                        &PrintXPUse


                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 24746 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################





##############################################################################
#
#          Name: ACPowerControl
#
#        Inputs: $powerIP, $chnls, $targState
#                (if it is desired to reboot the controller using ssh
#                (3000 or 750) the controller IP should be used in the 
#                station file for power control and 'ssh' for the channel)
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: entry point for power control
#
#
##############################################################################
sub ACPowerControl
{
    my ($powerIP, $chnls, $targState) = @_;
    my $i;
    my $password;
    my $user;
    my $ans;

    my ($forecast, $t); 
     
    my $len;
    my $fmt;
    my $chan;
    my $ret;

    #
    # validate to be a letter A-H(moxa), or number 1-8(apc)
    #
    my $moxaChans = "";
    my $apcChans = "";
    my $allChans4moxa = "";
    my $allChans4apc = "";
    my $chanValid = 0;
    my $chan1;
    my $chan2;
    my $prematch;
    my $match;
    
    # separate power control routine for ssh
    if (lc($chnls) eq 'ssh')
    {
        # make sure xioplink exists and establish the proper path
        my $sshBin = "xioplink.exe";
        if (stat("common/$sshBin"))
        {
            $sshBin = "common/$sshBin";
        }
        elsif (stat("$sshBin"))
        {
            ;
        }
        else
        {
            logInfo("Unable to find $sshBin\n");
            return ERROR;
        }
        logInfo("Found SSH at $sshBin\n");
        my $sshRebootCommand = "$sshBin -batch -l root -pw nextgen $powerIP /opt/xiotech/remote_reset";
        my $sshTestCommand   = "$sshBin -batch -l root -pw nextgen $powerIP uptime";
        
        # if the request is for 1 or ON check to make sure xioplink.exe is available
        # and return GOOD if ssh is functioning
        if ($targState == 1 || lc($targState) eq 'on')
        {
            my $sshTestReturn  = `$sshTestCommand`;
            my $startTime      = time();
            while ($sshTestReturn eq '')
            {
                my $elapsedTime = time() - $startTime;
                if ($elapsedTime > 180)
                {
                    logInfo("SSH not available for 3 minutes, check controller status on $powerIP\n");
                    return ERROR;
                }
                logInfo("SSH not ready on $powerIP, waiting 10 seconds to retry ($elapsedTime seconds since first attempt)\n");
                TestLibs::utility::DelaySecs(10);
                $sshTestReturn  = `$sshTestCommand`;
            }
            $sshTestReturn =~ m/up\s+(\d+:\d+)/;
            logInfo("SSH Functional, Uptime for $powerIP is $1\n");
            return GOOD;
        }
        
        # if the request is for 0, OFF, OF, cycle(c), toggle(t), or s(?)
        # reboot via plink.exe
        elsif ($targState == 0 || lc($targState) eq 'off' || lc($targState) eq 'of'
               || lc($targState) eq 'c' || lc($targState) eq 't' || lc($targState) eq 's')
        {
            logInfo("Rebooting $powerIP using\n");
            logInfo("$sshRebootCommand\n");
            $ret  = system($sshRebootCommand);
            return $ret >> 8;
        }
        # targState is invalid
        else
        {
            logInfo("\n\nInvalid parameter of $targState for 750 power control method\n\n");
            PrintUse();
            return (ERROR);
        }
    }

    $len = length($chnls);

    for ($i = 0; $i < $len; $i++ )
    {
        $fmt = sprintf("x%d C",$i);
        ($chan1) = unpack $fmt , $chnls;

        $chan = sprintf("%c",$chan1);
        
        $chan = uc($chan);

        #logInfo( "----------------------------------------------\n");
        
        #printf ("   Testing %s as a channel \n", $chan);

        if ( $chan ge 'A'  && $chan le 'H' )
        {
            #
            # channel meets Moxa requirements
            #
            #logInfo( "      validated moxa channel $chan \n");
            $moxaChans .= sprintf("%s",$chan);
            $allChans4moxa .= sprintf("%s",$chan);
            $allChans4apc .= Number2Letter($chan1);
            $chanValid = 1;
           # $chan2 = $chan1 + 32 ;
           # printf "           numeric channel = %c \n", $chan2; 


        }


        if ($chan ge "1"    && $chan le "8" )
        {
            #
            # channel meets apc requirements
            # 
            #logInfo( "      validated apc channel $chan \n");
            $apcChans .= sprintf("%s",$chan);
            $allChans4moxa .= Letter2Number($chan1);
            $allChans4apc .= sprintf("%s",$chan);
            $chanValid = 1;
           # $chan2 = $chan1 + 16 ;
           # printf "           alpha channel = %c \n", $chan2; 
        }

    }

    #logInfo( "Parsed channels is Moxa: $moxaChans or apc: $apcChans, valid flag is $chanValid \n");
    #logInfo( "                      input: $inf         $inf \n");
    #logInfo( "Parsed all channels is Moxa: $allChans4moxa or apc: $allChans4apc, valid flag is $chanValid \n");
                                                                
    if ($chanValid == 0)
    {
        logInfo( "\n\nInvalid input parameters - no valid channels found.\n\n");
        PrintUse();
        return (ERROR);
    }

    #######################################################
    # Get the command line parm and see if channel setting
    #######################################################
    

    #
    # validate to be one of 0,1,on,off,c(cycle),t(toggle)
    #

    $targState = uc ($targState);

    my $newState = INVALID;
    my $stateFlag = INVALID;

    if ( ( $targState eq '0' ) ||
         ( $targState eq "OFF" ) || 
         ( $targState eq "OF" ) )
    {
        $newState = 0;
        $stateFlag = 0;             # 0 = apc or moxa
    }


    if ( ( $targState eq '1' ) ||
         ( $targState eq "ON" ) )
    {
        $newState = 1;
        $stateFlag = 0;             # 0 = apc or moxa
    }

    if ( ( $targState eq 'C' ) ||
         ( $targState eq '2' ) ||
         ( $targState eq 'R') )
    {
        $newState = 2;
        $stateFlag = 0;             # 1 = apc only
    }

    if ( ( $targState eq 'S' ) ||
         ( $targState eq '3' ) )
    {
        $newState = 3;
        $stateFlag = 1;             # 1 = apc only
    }                        
    
    #logInfo( " newState is $newState, flag is $stateFlag \n");

    if ($newState == INVALID)
    {
        logInfo( "\n\nInvalid input parameters - state not valid.\n\n");
        PrintXPUse();
        return (ERROR);
    }



    ########################################
    # You must also have the Net::Telnet   #
    # library. This file is in the release #
    # directory (  \Test\PerlLibs\Net  )   #
    # and can be copied to your perl       #
    # directory ( C:\Perl\site\lib\Net )   #
    ########################################

    #logInfo( "--------> Detecting power controller type <--------- \n");
       

    #
    # Open a telnet connection and determine the type of power
    # controller.
    #
        #logInfo( "opening... $powerIP \n");

    $t = new Net::Telnet;
 
    my $mode = $t->errmode;
    $t->errmode("return");

    $ret = $t->open($powerIP);           # open connection to switch
                                  # switch response is...
                                  # Moxa: User password :
                                  # apc: User Name :


    if ( defined ($ret) )
    {
        $t->print("");  
  
        ($prematch, $match) = $t->waitfor('/:.*$/');
    }




    if (!defined($prematch) | !defined ($ret))
    {
        logInfo("Timeout connecting to power controller, pause 35 seconds, try again.");

        $t->close;

        sleep(35);

        $t = new Net::Telnet;
        
        $t->errmode("return");
        

        $ret = $t->open($powerIP);           # open connection to switch
                                             # switch response is...
                                             # Moxa: User password :
                                             # apc: User Name :

        sleep 1;
        
        if ( defined ($ret) )
        {
            $t->print("");  
      
            ($prematch, $match) = $t->waitfor('/:.*$/');
        }
        

    }

    ######################################################
    #
    # Branch to the appropriate control function
    #
    ######################################################
    if ( !defined ($ret) )
    {
        logInfo(">>>>> Unable to make telnet connection to power device.");  
        return ERROR;
    }

    $ret = GOOD;

    if (defined($prematch))
    {
        #logInfo( "Prematch: $prematch, Match: $match \n");

        if ( $prematch =~ /User Name/ )
        {
            
            #
            # Parameters: 
            #    $newState = 2;    # new state of port
            #    $stateFlag = 1;   # 1 = apc only
            #    $powerIP          # ipaddress
            #    $allChans4moxa    # all channels as letters;
            #    $allChans4apc     # all channels as numbers
            #    $t                # telnet session object
            #
            
            $t->close;
            
            sleep 1;

            if ( $newState > 1)
            {
                # cycle and status commands
                logInfo( "Controller is apc (telnet)\n");
                $ret = ControlApc($powerIP, $allChans4apc, $newState);
            }
            else
            {
                # on and off only
                logInfo( "Controller is apc (web)\n");
                $ret = ControlApcWeb($powerIP, $allChans4apc, $newState);
            }
        }
        else
        {
            logInfo( "Controller is Moxa (API)\n");

            if ( $stateFlag == 1)
            {
                logInfo( "\n\nInvalid State for Moxa control.\n\n");
                return (ERROR);
            }

            #
            # Parameters: 
            #    $newState = 2;    # new state of port
            #    $stateFlag = 1;   # 1 = apc only
            #    $powerIP          # ipaddress
            #    $allChans4moxa    # all channels as letters;
            #    $allChans4apc     # all channels as numbers
            #    $t                # telnet session object
            #


            $t->close;       # need this to support toggle


            #####################################################
            #
            # NOTE: we use the API intefrace as it is faster and
            # has error handling.
            #
            #####################################################


            if ( $newState == 2)
            {
              #  $ret = ControlMoxaTelnet($powerIP, $allChans4apc, 0);
              #  $ret = ControlMoxaTelnet($powerIP, $allChans4apc, 0);
                $ret = ControlMoxaAPI($powerIP, $allChans4moxa, 0);
                $ret = ControlMoxaAPI($powerIP, $allChans4moxa, 1);

            }
            else
            {
                # note: moxa telnet takes numeric channel numbers
              #  $ret = ControlMoxaTelnet($powerIP, $allChans4apc, $newState);
                $ret = ControlMoxaAPI($powerIP, $allChans4moxa, $newState);
            }
        }
    }
    else
    {
        logInfo( "Controller defaulted to Moxa (API)\n");

        if ( $stateFlag == 1)
        {
            logInfo( "\n\nInvalid State for Moxa control.\n\n");
            return (ERROR);
        }

        #
        # Parameters: 
        #    $newState = 2;    # new state of port
        #    $stateFlag = 1;   # 1 = apc only
        #    $powerIP          # ipaddress
        #    $allChans4moxa    # all channels as letters;
        #    $allChans4apc     # all channels as numbers
        #    $t                # telnet session object
        #

        # Don't forget to close the telnet connections
        $t->close;
        if ( $newState == 2)
        {
            $ret = ControlMoxaAPI($powerIP, $allChans4moxa, 0);
            $ret = ControlMoxaAPI($powerIP, $allChans4moxa, 1);


        }
        else
        {
            
            $ret = ControlMoxaAPI($powerIP, $allChans4moxa, $newState);
        }
    }
    

    return $ret;
}

#######################################################################

#
# These manipulations assume the ASCII 8 bit character set.
#

sub Number2Letter
{
    my ($in) = @_;

    if ( $in > 96 )
    {
        $in = $in - 48;
    }
    else
    {
        $in = $in - 16;
    }

    return sprintf("%c", $in);
}

sub Letter2Number
{
    my ($in) = @_;

    $in = $in + 16; 
    return sprintf("%c", $in);
}
######################################################################

#
# Individual functions to control a power device.
#

#
# APC is a telnet session. The connection is made, but we are
# not logged in.
#


sub ControlApc
{
    my ($powerIP, $allChans4apc, $newState) = @_;

        #    logInfo( "#########################\n");
        #    logInfo( "\nAPC telnet control:\n\n");
        #    logInfo( "#########################\n");


    my @output;
    my $fmt;
    my $chan;
    my $chan1;
    my $action;
    my @actions = (2,1,3,9);
    my $i;
    my $inf;
    my $prematch;
    my $match;
    my $j;
    my $t;
    my $ors;

    #login

        # logInfo( "logging in $powerIP\n");

    $t = new Net::Telnet;

    $t->open($powerIP);           # open connection to switch
                                  # switch response is...
                                  # Moxa: User password :
                                  # apc: User Name :

    my $mode = $t->errmode;
    $t->errmode("return");

 #   sleep 1;

    $t->print("");  

    ($prematch, $match) = $t->waitfor('/User Name .*$/');
        #     logInfo( "Prematch: $prematch, Match: $match \n");

    $t->print("apc");
    ($prematch, $match) = $t->waitfor('/:.*$/');
        #    logInfo( "Prematch: $prematch, Match: $match \n");

    $t->print("apc");
    ($prematch, $match) = $t->waitfor('/> .*$/');
        #     logInfo( "Prematch: $prematch, Match: $match \n");


    #1,3

    # logInfo( "sending 1 \n");

    $t->print("1");
    ($prematch, $match) = $t->waitfor('/> .*$/');
            # logInfo( "Prematch: $prematch, Match: $match \n");

    # logInfo( "sending 3 \n");

    $t->print("3");
    ($prematch, $match) = $t->waitfor('/> .*$/');
            # logInfo( "Prematch: $prematch, Match: $match \n");

    for ( $i = 0; $i < length($allChans4apc); $i++)
    {
        $fmt = sprintf("x%d C",$i);
        ($chan1) = unpack $fmt , $allChans4apc;
        $chan = sprintf("%c",$chan1);

        $action =  $actions[$newState];

        if ( $action == 9 ) {$chan = 9;}

        #chan,1,action,YES,<cr>,esc, esc


            # logInfo( "sending channel $chan \n");

        $t->print($chan);
        ($prematch, $match) = $t->waitfor('/> .*$/');
            # logInfo( "Prematch: $prematch, Match: $match \n");

            # logInfo( "sending 1 \n");

        $t->print("1");
        ($prematch, $match) = $t->waitfor('/> .*$/');
            # logInfo( "Prematch: $prematch, Match: $match \n");

            # logInfo( "sending action $action \n");
        if ( $action == 9 )
        {
            # parse prev $prequal to get state
                #logInfo( "$prematch \n");
            
            my @parts;

            logInfo( "\nCurrent Outlet State:\n");
            
            @parts = split(/\n/, $prematch);

            for ($j = 3; $j < 14; $j++ )
            {
                logInfo( "$parts[$j] \n");
            }
            
            # logInfo( "\n");

            last;   # end channel loop
        }
        else
        {
            # normal control
            $t->print($action);
            ($prematch, $match) = $t->waitfor('/cancel :.*$/');
                # logInfo( "Prematch: $prematch, Match: $match \n");

                # logInfo( "sending yes \n");


            $t->print("YES");
            ($prematch, $match) = $t->waitfor('/continue.*$/');
                # logInfo( "Prematch: $prematch, Match: $match \n");


                # logInfo( "sending <cr> \n");

            $t->print("");
            ($prematch, $match) = $t->waitfor('/> .*$/');
                # logInfo( "Prematch: $prematch, Match: $match \n");
        
            # grep for 'state:' in prematch  so we can print the state
            
            my @parts2;

            @parts2 = split(/:|\n/, $prematch);                                  # was \s
                 #logInfo( "\n#####################\n");
                 #print @parts2;
                 #logInfo( "\n#####################\n");

            for ( $j = 0; $j < (scalar(@parts2)-1); $j++)
            {
                
                    # print "Parts2[$j] = $parts2[$j] \n";
                
                if ( $parts2[$j] =~ /State/ )
                {
                        # logInfo( "new state is : $parts2[1+$j]\n");
                    last;
                } 
            }
            logInfo( "On IP $powerIP, channel $chan, is now $parts2[1+$j] \n");

            # sleep(2);            
        }


            #    logInfo( "sending esc \n");
    
    
        #
        # remove newline from prints when we do the escapes
        #
        $ors = $t->output_record_separator();
        $t->output_record_separator("");

        $t->print("\e");
        ($prematch, $match) = $t->waitfor('/> .*$/');
            #    logInfo( "Prematch: $prematch, Match: $match \n");

            #    logInfo( "sending esc \n");

        $t->print("\e");
        ($prematch, $match) = $t->waitfor('/> .*$/');
            #    logInfo( "Prematch: $prematch, Match: $match \n");

        #
        # restore newline
        #
        $t->output_record_separator($ors);



    }   # end of channel loop
    
    
    #    esc, esc, 4
    
    #
    # remove newlines
    #    
    $t->output_record_separator("");

        # logInfo( "sending esc \n");
    $t->print("\e");
    ($prematch, $match) = $t->waitfor('/> .*$/');
        # logInfo( "Prematch: $prematch, Match: $match \n");



        # logInfo( "sending esc \n");
    $t->print("\e");
    ($prematch, $match) = $t->waitfor('/> .*$/');
        # logInfo( "Prematch: $prematch, Match: $match \n");

    
         # logInfo( "sending 4 \n");
    $t->print("4\n");
    ($prematch, $match) = $t->waitfor(String => '/Bye.*$/', Timeout => 5);
         #   logInfo( "Prematch: $prematch, Match: $match \n");


    $t->close;

    print "done.\n";
    sleep 2;

    return GOOD;
}



sub ControlApcDamon
{
    my ($powerIP, $allChans4apc, $newState) = @_;

        #    logInfo( "#########################\n");
        #    logInfo( "\nAPC telnet control:\n\n");
        #    logInfo( "#########################\n");
    
    my $MAX_CON_RETRIES=3;


    my @output;
    my $fmt;
    my $chan;
    my $chan1;
    my $action;
    my @actions = (2,1,3,9);
    my $i;
    my $inf;
    my $prematch = '';
    my $match;
    my $j;
    my $t;
    my $ors;
    my %step; #Array holds the order of expected outcomes
    my $connect_count = 0;
    my $trial_count = 1;
    my $mode;
    my $outlet_index = 0;
    my $oseparator;
    my $step_number;
    my @process_steps;
    my $step_match;
    my $send_string;
    my $function;
    my $function_result;
    my $MAX_TRYS = 3;
    use constant STEPERROR => -65000;
        
    
    #
    # Build process steps
    #
    if( $newState == 9 )
    {
        @process_steps = ( 1,2,3,4,5,'6 outlet states',45,50,55);
    }
    else
    {
        @process_steps = (1,2,3,4,5);
        for ( $i = 0; $i < length($allChans4apc); $i++)
        {
            push( @process_steps, 10,15,20,25,30,35,40);
        }
        push( @process_steps, 45,50,55);
    }
    
    
    $t = new Net::Telnet(Telnetmode => 1);
    $t->dump_log("telnet_dump");
    
    $step{1} = {
        SendText => "\n",
        prompt => '/\s:\s$/',
        preProcess => 
            sub
            { 
                $t->close();
                while( $connect_count < $MAX_CON_RETRIES && !$t->open($powerIP))
                {
                    logInfo("Telnet connection has failed. Trying again.");
                    $connect_count++;
                }
                if( $connect_count >= $MAX_CON_RETRIES )
                {
                    logError(">>>> Fail (ACPower): too many connect retries.");
                    return STEPERROR;
                }
                else
                {
                    $connect_count++;
                    #$t->telnetmode(1);                    
                    $mode = $t->errmode;
                    $oseparator = $t->output_record_separator();
                    $t->errmode("return");
                    print "Have connected to terminal.\n";
                    #$t->print("");
                    #($prematch, $match) = $t->waitfor('/:.*/');
                    #$t->close();
                    return GOOD;
                }    
            } };
        
    $step{2} = {
        match => 'User Name',
        prompt => '/\s:\s$/', 
        SendText => "apc",
        ErrorMsg => 'Could not find the User Name field' 
        };
    
    $step{3} = {
        match => 'Password',
        SendText => "apc", 
        ErrorMsg => 'Could not find the Password field'
        };
    
    $step{4} = {
        match => '- Control Console -', 
        SendText => '1', 
        ErrorMsg => 'Could not find the - Control Console -'
        };
    
    $step{5} = {
        match => '- Device Manager -',
        SendText => '3',
        ErrorMsg => 'Could not find the - Device Manager -'
        };
                
    $step{'6 outlet states'} =
        {
            match => '- Outlet Control/Config -',
            SendText => '9',
            printLine => 'Outlet:\s+\d+' };                  
    
    $step{10} = {
        match => '- Outlet Control/Config -',
        SendText => sub {
            if( $outlet_index >= length( $allChans4apc)) 
            {
                logError("Error: Step 5, outlet index past # of outlets ".
                        "passed in.");
                return STEPERROR;
            }
            $fmt = sprintf("x%d C",$outlet_index);
            ($chan1) = unpack $fmt , $allChans4apc;
            $chan = sprintf("%c",$chan1);
            return $chan; },
        ErrorMsg => 'Could not find - Outlet Control/Config -' };
        
    $step{15} = {
        match => '- Outlet \d+: Outlet \d+ -',
        preProcess => sub { $outlet_index++ },
        SendText => '1',
        ErrorMsg => 'Could not find - Outlet #: Outlet # -' };
    
    $step{20} = {
        match => '- Control Outlet -',
        SendText => sub{ 
            #print "Control Outlet: NS $newState\n";
            #print "Control Outlet: A[NS]: $actions[$newState]\n";
            return $actions[$newState];} };
    
    $step{25} = {
        match => "Enter 'YES' to continue",
        SendText => 'YES' };
        
    $step{30} = {
        match => 'Command successfully issued.',
        SendText => '' };
        
    $step{35} = {
        match => '- Control Outlet -',
        SendText => "\e",
        noNewLine => 1,
        Msg => 'Current State of Outlet',
        printLine => 'State:' };
        
    $step{40} = {
        match => '- Outlet \d+: Outlet \d+ -',
        SendText => "\e",
        noNewLine => 1 };
        
    $step{45} = {
        match => '- Outlet Control/Config -',
        SendText => "\e",
        noNewLine => 1 };
        
    $step{50} = {
        match => '- Device Manager -',
        SendText => "\e",
        noNewLine => 1 };
        
    $step{55} = {
        match => '- Control Console -', 
        SendText => '4' };
        
    $step{60} = {
        match => 'Bye' };    
    
    @output = ('');
    #$step_match = '.*';
    #print "Grep is: " . grep( /$step_match/, @output);
    #exit;    
    for( $i = 0; $i < $#process_steps; $i++)
    {
        print "\n------------ I: $i Step: $process_steps[$i] ---------\n";
        if( defined $step{$process_steps[$i]}{preProcess} &&
            ref( $step{$process_steps[$i]}{preProcess}) eq "CODE")
        {
            $function = $step{$process_steps[$i]}{preProcess};
            $function_result = &$function();
            if( $function_result == STEPERROR)
            {
                logError( ">>>> Error: preProcess directive for step " .
                    "($process_steps[$i]) failed.");
                return ERROR;
            }
        }
            
        if( exists $step{$process_steps[$i]}{match}) 
        {
            $step_match = $step{$process_steps[$i]}{match};
        }
        else
        {
            $step_match = '.*';
        }
        
        print "Step match is: $step_match & ";
        print @output;
        print "\n";
        if( grep(/$step_match/, @output))
        {
            print "PREMATCH WITH STEPMATCH\n";
            if( $step{$process_steps[$i]}{noNewLine})
            {
                #print "Setting output_record_separator.\n";
                $t->output_record_separator("");
            }
            $send_string = $step{$process_steps[$i]}{SendText};
            if( !defined $send_string) 
            {
                #print "Setting send string to default of \"\".\n";
                $send_string = "";
            }
            
            #
            # Check to see if the SendText paramater is a code segment
            # If so, execute the code segment.
            #
            
            if( defined $send_string && ref( $send_string) eq "CODE")
            {
                $function = &$send_string();
                $function_result = &$send_string();
                if( $function_result == STEPERROR)
                {
                    logError(">>>> Error: The function for sendText for step " .
                            "($process_steps[$i]) has returned and error. Exiting..");
                    return ERROR;
                }
                
                $send_string = $function_result;
            }
            
            
            #
            # Send string is not a function.. If the length of this variable
            # is greater than 0 treat it as a string of text to send.
            #
            if( defined $send_string )
            {
                print "Sending the text \'$send_string\'\n";
                #my $bb = $t->print( $send_string);
                #print "BB is: $bb\n";
                #print ".....,,,,,------,,,,.....\n";
                #$t->getline();
                #usleep(100);     No Time::HiRes module
                #select( undef, undef, undef, 0.33);
                
                if( exists $step{$process_steps[$i]}{prompt} )
                {
                    print "Will wait for the prompt of: " .
                        $step{$process_steps[$i]}{prompt} . "\n"; 
                    @output = $t->cmd( String=>$send_string,
                                       Prompt=>$step{$process_steps[$i]}{prompt},
                                       cmd_remove_mode=>0);
                }
                else
                {
                    @output = $t->cmd( String=>$send_string,
                                       Prompt=> '/> .*$/',
                                       cmd_remove_mode=>0);
                
                }
                print "\n****** Output ******\n";
                print @output;
                print "\n";
                #print "Prematch in SendString: $prematch\n";
                #print "match in SendString: $match, $bb\n";
                #sleep(1);
            }
            
            if( $step{$process_steps[$i]}{Msg} ) 
            {
                print $step{$process_steps[$i]}{Msg};
            }
            
            if( $step{$process_steps[$i]}{printLine} )
            {
                $match = $step{$process_steps[$i]}{printLine};
                #if( defined $match )
                #{
                    #@output = split /\n/, $prematch;
                    my @matches = grep /$match/, @output;
                    print @matches;
                #}
            }
            if( $step{$process_steps[$i]}{postProcess} &&
                ref ($step{$process_steps[$i]}{postProcess}) eq "CODE")
            {
                $function = $step{$process_steps[$i]}{postProcess};
                $function_result = &$function();
                if( $function_result == ERROR)
                {
                    logError( ">>>> Step( $i) postProcess directive has returned ".
                                " an Error. Exiting..");
                    return ERROR;
                }
            }
            
            #Make sure the original seperator back
            $t->output_record_separator($oseparator);
        }
        
        #
        # We could not match the match directive for the current step.
        # Will try to find where we are on using the knowledge of the 
        # steps.
        #
        else 
        {
            my $found_step = 0;
            if( $step{$process_steps[$i]}{ErrMsg} ) 
            {
                logError( $step{$process_steps[$i]}{ErrMsg});
            }

            logError( ">>> Error: Does not look like we made it to (" .
                            "$step_match) Step($process_steps[$i]). " .
                            "Trying to find where we are.");
            
            
            # Check to see if we have already tried too many times
            if( $trial_count >= $MAX_TRYS)
            {
                logError(">>> Error: too many retries. Stopping.");
                return ERROR;
            }
              
            for( $j=$i-1; $j>=0; $j--) {
                $step_match = $step{$process_steps[$j]}{match};
                print "E $j Looking for: $step_match\n";
                print "E $j Have: $prematch\n";
                if(defined $step_match && ref($step_match) ne "CODE" && 
                    $#output > 0 && grep( /$step_match/, @output))
                {
                    logInfo("Found where we are. Back stepping to step " .
                        "number: $process_steps[$j]");
                    $i = $j-1;
                    $found_step = 1;
                    last;
                }
            }
            
            #This means no step in the list matched. Increment
            #trial count and try the process steps from start.
            if( $found_step != 1)
            {
                logError(">>> Error: Could not figure out where we are in control. " .
                            "Going back to step 0.");
                @output = ('');
                $match = "";
                $trial_count++;
                $i = -1;
            }
        }
    }            


    $t->close;

    print "done.\n";
    #sleep 2;

    return GOOD;
}


#####################################################################
#
# This controls the APC via it's Web interface
#

sub ControlApcWeb
{
    my ($powerIP, $allChans4apc, $newState) = @_;

    my $ua = LWP::UserAgent->new;
    
    
    $ua->credentials( $powerIP.':80', 'APC Management Card',  'apc', 'apc');
    $ua->credentials( $powerIP.':80', 'Switched Rack PDU', 'apc', 'apc');
    my $response;
    my $request;
    my $trial_count=0;
    my $done = 0;
    my $form;
    my $outlet_index = 0;
    my $chan;
    my $fmt;
    my $form_input;
    my $form_input_name = 'OL_Cntrl_Col1_Btn';
    my $form_input_type = 'checkbox';
    my $form_power_sel_name = 'MS3OutletCtrl';
    my @actions = (4,2,6,9);
    my @our_chans;
    my $state;
    
    #
    # Loop to try setting the desired power state up to 3 times
    # otherwise fail.
    #
    while( $trial_count < 3) 
    {
        
        
        #
        #Get the main web form for selecting the outlets to control
        #power-wise. m3out.htm for fw 1.x and rPDUout.htm for fw 2.x
        #
        $response = $ua->request( GET "http://$powerIP/ms3out.htm");
        if( ! $response->is_success)
        {
            $response = $ua->request( GET "http://$powerIP/rPDUout.htm");
            $form_power_sel_name = 'rPDUOutletCtrl'; #they renamed the input
        }            
        
        
        
        if( $response->is_success )
        {
            $form = HTML::Form->parse($response->content, $response->base);
            #$form->dump;     
            
            
            #
            # Loop through all the outlets passed in to be controled
            # setting the related form input checkbox.
            #
            while( $outlet_index < length( $allChans4apc))
            {
                #unpack the outlet channel
                $fmt = sprintf("x%d C",$outlet_index);
                ($chan) = unpack $fmt , $allChans4apc;
                $chan = sprintf("%c",$chan);
                push @our_chans, $chan;

                #Find the correct web form check box to muliputate.
                $form_input = $form->find_input( $form_input_name,
                    $form_input_type, $chan);
                
                
                # Make sure we were able to find that outlet's checkbox in the form.
                if( ! defined $form_input) 
                {
                    print ">>>> Error: You should not see this error, programmer ";
                    print "error. Exiting...\n";
                    return ERROR;
                }
                
                $chan++;    #Channels on the web form seem to start from 2 instead of 1
                $form_input->value( "?$chan,2");
                $outlet_index++;
            }
            
            #Sets the desired new state of the outlets selected (OFF|ON|..) etc.
            $form->value( $form_power_sel_name, $actions[$newState]);
    
            #$form->dump;
    
            #Builds the propper request based on our form selections.
            $request = $form->click;
            $request->authorization_basic('apc', 'apc');
            $response = $ua->request( $request);
    
            #
            # Check to see if got a 302 response from the apc web server
            #
            #On newer versions of libwww you use this.
            #push @{ $ua->requests_redirectable }, 'POST';
            #$ua->redirect_ok;
            #None of the above is supported on libwww 5.51
            #Which means we have to handle the redirect response from the apc
            #(although they are not web complient sending a 302, should be 303)
            # 6/6/05 EP office has model 7920 which does return correct response
            # code of 303 unlike the APC 7900's in rochester - adding 303 - DA
            #
            if( $response->code == 302 || $response->code == 303) {
                #print "We had a 302||303.. Print new location.\n";
                if( $response->as_string() =~ /Location: (.*)\n/) 
                {
                    $response = $ua->request( GET $1);
                    
                    if( $response->is_success) 
                    {
                        #print ">> Have good response.\n";
                        $form = HTML::Form->parse($response->content, $response->base);
                        #print ">> our new form: \n";
                        #$form->dump;
                        
                        $request = $form->click(); 
                        $request->authorization_basic( 'apc', 'apc');
      
                        #Execute this request
                        $response = $ua->request( $request);
      
                        #Look for the 302 response code again.
                        if( $response->code == 302 || $response->code == 303) 
                        {
                            if( $response->as_string() =~ /Location: (.*)\n/) 
                            {
                                $response = $ua->request( GET $1);
        
                                if( $response->is_success) 
                                {
                                    #Parse through the results web page to find 
                                    #the current outlet states.
                                    my @contentL = split /\n/, $response->content;
       
                                    foreach ( @contentL)
                                    {
                                        if( /title=\"Off\"/)
                                        {
                                            $state =  "Off";
                                        }
                                        if( /title=\"On\"/ )
                                        {
                                            $state = "On";
                                        }
                                        if( /(Outlet\s+)(\d+)/ )
                                        {
                                            if( grep( /^$2$/, @our_chans) )
                                            {
                                                print " $1$2 $state\n";
                                            }
                                        }
                                    }

                                    return GOOD;  
                                }
                            }
                        }
                    }
    
                }
            } # response->code == 302
            $trial_count++;
        } # response->is_success
        else 
        {
            $trial_count++;
        }
    } #while( $trial_count < 3)
    
    print ">>>> Error: Was not able to successfully control the outlets.\n";
    return ERROR;
}


#####################################################################

#
# The is a moxa API call. We use the DLL and currently this is an
# external program. We should close the telnet session before calling this.
#

sub ControlMoxaAPI
{
    my ($powerIP, $chan, $state) = @_;
    my $ret;
    my $ret2 = 0;

    logInfo( "#########################\n");
    logInfo( "\nMOXA API control:\n\n");
    logInfo( "#########################\n");

    #
    # Moxapower may be in the current directory of 'common' under
    # the current directory. Look for it in either location.
    #


    if ( stat("moxapower.exe") )
    {
        $ret = system("moxapower.exe", $powerIP, $chan, $state);
        $ret2 = $ret >> 8;
    }
    elsif ( stat("common\\moxapower.exe") )
    {
        $ret = system("common\\moxapower.exe", $powerIP, $chan, $state);
        $ret2 = $ret >> 8;
    }
    else
    {
        logInfo("Unable to find moxapower.exe program.\n");

        #
        # now we could try to do the telnet control here.
        # this would help if the moxapower program is no
        # longer around (as a last try).
        #
        $ret = ControlMoxaTelnet( $powerIP, $chan, $state);

    }
    
    logInfo("Moxa returned $ret, $ret2 \n");
    return $ret;
}

#####################################################################

#
# This is a telenet access to the Moxa, we are connect but
# not logged in.
#



sub ControlMoxaTelnet
{
    my ( $powerIP, $allChans, $newState) = @_;

    logInfo( "#########################\n");
    logInfo( "\nMOXA telnet control:\n\n");
    logInfo( "#########################\n");
   
    my $chan;
    my $chan1;
    my $i;
    my $action;
    my $match;
    my $prematch;
    my $fmt;
    my $bPtr;
    my $t;
   
    # we need to chenage the output record serarator so that the 
    # keystrokes can be sent properly. Space seems to work.

    $t = new Net::Telnet;

    $t->open($powerIP);           # open connection to switch
                                  # switch response is...
                                  # Moxa: User password :
                                  # apc: User Name :


    # logInfo( "modify  session \n");

    # Output_record_separator => $char,]
    $t->output_record_separator(' ');
    $t->timeout(5);
    

    my $mode = $t->errmode;
    $t->errmode("return");

    $t->print("");  

    ($prematch, $match) = $t->waitfor('/:.*$/');



    #
    # Moxa telnet sequence
    #
    # send            then expect
    # password<cr.    <...more>
    # \033[B          <...more>
    # \033[B          <...more>
    # \033[B          <CR>
    # \033[B          <CR>
    # for each channel...
    #     <cr>        <CR>
    #     \033[B      "] : "
    #     1,chan,action<cr>    <CR>            channel is number
    # \033[B          <CR>    
    # \033[B          <CR>    
    # \033[B          <CR>    
    # \033[B          <CR>    
    # \033[B          <CR>    
    # <cr>            (y/n) ?
    #   y             -- done -- 
    
    
    
    
    
    
    
    #     NPower Commander Telnet Configuration
    #-----------------------------------------------------------------------------
    # -> System             Set IP address, gateway address and subnet mask
    #    ISP                Set ISP dial no, ISP account password
    #    Mail               Set SMTP server, e-mail address
    #    Device             Set device connect, NPowerCommander
    #    Device Control     NPowerCommander control...
    #    Administrator      Set internet administrator name and password
    #    TelnetProfile      Set telnet configuration port and password
    #    Reset              Reset configuration to default
    #    Save_Restart       Save and Restart
    #    Exit               Exit and disconnection
    #
    # Command  > System <...more>
    #
    #
    #
    #
    #
    #
    #
    #
    #-----------------------------------------------------------------------------
    # ARROW KEY: 'UP/DOWN' Move cursor, 'RIGHT' Select, 'LEFT' Exit     Mode : USE

    
    
    
    
    logInfo( "\nsend password\n");
       
    # supply password go to main menu points to system
    # password<cr.    <...more>
    $t->print("admin\r");
    ($prematch, $match) = $t->waitfor('/more>.*$/');

        #    logInfo( "Prematch: $prematch, Match: $match \n");




    ##############################
    # down arrow, point to ISP
    # \033[B          <...more>
    ##############################

    logInfo( "send cursor pos \n");
    $t->print("\033\[14;29R");

    logInfo("Sending \033\[B     down arrow to ISP\n");
    $t->print("\033[B");

    ($prematch, $match) = $t->waitfor('/more>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n";)
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }

    ##############################
    # down arrow, point to Mail
    # \033[B          <...more>
    ##############################

    logInfo("Sending \033\[B   down arrow to mail\n");
    $t->print("\033\[B");
    ($prematch, $match) = $t->waitfor('/more>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }


    ##############################
    # down arrow, point to  Device
    # \033[B          <CR>
    ##############################

    logInfo("Sending \033\[B   down arrow to device\n");
    $t->print("\033\[B");
    ($prematch, $match) = $t->waitfor('/<CR>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }




    ##############################
    # down arrow, point to Device Control
    # \033[B          <CR>
    ##############################

    logInfo("Sending \033\[B   down arrow to device control\n");
    $t->print("\033\[B");
    ($prematch, $match) = $t->waitfor('/<CR>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }

    ##############################
    # select device control
    #     <cr>        <CR>
    ##############################

    logInfo("Sending cr to select device control\n");
    $t->print("\n");
    ($prematch, $match) = $t->waitfor('/<CR>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }


    ##############################
    # down arrow, point to Set
    #     \033[B      "] : "
    ##############################

    logInfo( "send cursor posn \n");
    $t->print("\033\[14;29R");
    sleep 1;

    logInfo("Sending \033\[B   down arrow to set\n");
    $t->print("\033\[B");
    ($prematch, $match) = $t->waitfor('/<CR>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }

    ##############################
    # for each channel...
    ##############################

    for ( $i = 0; $i < length($allChans); $i++)
    {
        $fmt = sprintf("x%d C",$i);
        ($chan1) = unpack $fmt , $allChans;
        $chan = sprintf("%c",$chan1);

        ##############################
        # select set
        #     <cr>        <CR>
        ##############################

        sleep 1;

        logInfo("Sending cr to select set\n");

        $t->print("\r");
        ($prematch, $match) = $t->waitfor('/] : .*$/');

            # logInfo( "Prematch: $prematch, Match: $match \n");
            if (!defined ($prematch))
            {
                $bPtr = $t->buffer;
                logInfo( "Buffer contents:\n$$bPtr \n");
            }

        ##############################
        # enter information, returns to set
        #     1,chan,action<cr>    <CR>            channel is number
        ##############################

        logInfo( "sending new state: 1,$chan,$newState\r\n");
        
        $t->print("1,$chan,$newState\r");
        ($prematch, $match) = $t->waitfor('/<CR>.*$/');

            # logInfo( "Prematch: $prematch, Match: $match \n");

            if (!defined ($prematch))
            {
                $bPtr = $t->buffer;
                logInfo( "Buffer contents:\n$$bPtr \n");
            }

        logInfo( "send cursor posn \n");
        $t->print("\033\[14;29R");
        sleep 1;

    }

    ##############################
    # left arrow, point to main menu 
    # \033[D          <CR>  
    ##############################


    logInfo("Sending \033\[D   back arrow to main\n");
    $t->print("\033\[D");
    ($prematch, $match) = $t->waitfor('/<CR>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }
   


        #   ISP
        #   Mail
        #   Device
        #-> Device Control
        #   Administrator
        #   TelnetProfile
        #   Reset
        #   Save_Restart
        #   Exit

    ##############################
    # down arrow, point to  Administrator
    # \033[B          <CR>
    ##############################

    logInfo( "send cursor posn \n");
    $t->print("\033\[14;29R");
    sleep 1;

    logInfo("Sending \033\[B   down arrow to Administrator\n");
    $t->print("\033\[B");
    ($prematch, $match) = $t->waitfor('/<CR>.*$/'); 
    
        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }

    ##############################
    # down arrow, point to  TelnetProfile
    # \033[B          <CR>
    ##############################

    logInfo("Sending \033\[B   down arrow to TelnetProfile\n");
    $t->print("\033\[B");
    ($prematch, $match) = $t->waitfor('/<CR>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }

    ##############################
    # down arrow, point to  Reset
    # \033[B          <CR>
    ##############################

    logInfo("Sending \033\[B   down arrow to Reset\n");
    $t->print("\033\[B");
    ($prematch, $match) = $t->waitfor('/<CR>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }

    ##############################
    # down arrow, point to  Save_Restart
    # \033[B          <CR>
    ##############################

    logInfo("Sending \033\[B   down arrow to Save_Restart\n");
    $t->print("\033\[B");
    ($prematch, $match) = $t->waitfor('/<CR>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }

    ##############################
    # down arrow, point to  Exit
    # \033[B          <CR>
    ##############################

    logInfo("Sending \033\[B   down arrow to Exit\n");
    $t->print("\033\[B");
    ($prematch, $match) = $t->waitfor('/<CR>.*$/');

        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n$$bPtr \n");
        }

    ##############################
    # return to select exit
    # <CR>          (y/n) ?
    ##############################
    $t->output_record_separator("\n");


    logInfo("Sending return to select exit\n");
    $t->print("");
    ($prematch, $match) = $t->waitfor('/disconnect.*$/');


        # logInfo( "Prematch: $prematch, Match: $match \n");
        if (!defined ($prematch))
        {
            $bPtr = $t->buffer;
            logInfo( "Buffer contents:\n>>>> $$bPtr <<<< \n");
        }

     


    ##############################
    # respond to exit prompt
    #   y             -- done --
    ##############################
    logInfo("Sending y to exit\n");
    $t->print("y");


    ##############################
    #($prematch, $match) = $t->waitfor('/ : .*$/');
    #    logInfo( "Prematch: $prematch, Match: $match \n");
    ##############################
   
       
    $t->close;
   
   
   return GOOD;
}
##########################################################################
# print uasge message for XIOpower

sub PrintXPUse
{
    logInfo( "\nXIOpower usage:\n");
    logInfo( "XIOpower  <ip address> <channels> <state> <c/r> \n");
    logInfo( "  where:\n");
    logInfo( "    <ip address> is the IP address of the power controller\n");
    logInfo( "                 i.e., 192.188.1.200    \n");
    logInfo( "      <channels> are the letters or numbers of the channel(s) to \n");
    logInfo( "                 be controlled. i.e.,  2 or C for single or \n");
    logInfo( "                 123  or ABC  for multiple channels  \n");
    logInfo( "         <state> is the new state of the channel.  \n");
    logInfo( "                 use 0 or 1 or ON or OFF.   \n");
    logInfo( "\n\n"); 

}
##############################################################################


1;   # we need this for a PM

##############################################################################

##########################################################################
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
#
# $Log$
# Revision 1.4  2006/05/25 19:55:01  ElvesterN
# added routine to check for ssh as the "moxa" power channel value, this allows
# an ssh reboot cycle rather than a power control (mostly for 750)
#
# Revision 1.3  2005/06/08 07:02:06  AndersonD
# TBolt00012954: Script now runs on APC 7920s. Fixed.
#
# Revision 1.2  2005/05/18 21:07:14  AndersonD
# tbolt00000000: updated to resolve random hangs of power control on APCs. Reviewed by Craig
#
# Revision 1.8  2004/11/05 14:45:53  MenningC
# tbolt00000000: fix logout/login problems with apc. reviewed by Randy Rysavy
#
# Revision 1.7  2004/06/07 16:31:17  KohlmeyerA
# Tbolt00000000:  Fixed a window where routine would "die" instead of returning ERROR
# if it could not communicate with power device.  Reviewed by Craig.
#
# Revision 1.6  2004/04/29 17:00:46  MenningC
# tbolt00000000: remove debug log entries, reviewed by Al
#
# Revision 1.5  2004/02/11 20:33:22  MenningC
# tbolt00000000:resolve missing fcn in error path, reviewed by Al
#
# Revision 1.4  2004/02/11 19:59:51  MenningC
# tbolt00000000:took out some extre debug
#
# Revision 1.3  2004/02/11 19:55:29  MenningC
# tbolt00000000: added 2 second pause at end. Reviewed by Al.
#
# Revision 1.2  2004/02/11 19:00:50  MenningC
# tbolt00000000: nadded debug prints; reviewed by Mark.
#
# Revision 1.1  2004/02/05 19:54:08  MenningC
# tbolt00000000: new power control script and related changes; reviewed by Al.
#
#
#
