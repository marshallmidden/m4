# $Header$
##############################################################################
#  
#   CCBE Integration test library - Debug Dump decoder
#
#   1/28/2003  XIOtech   Craig Menning
#
#   A set of library functions for extracting debug information from a 
#   buffer.
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002-2003 XIOtech 
#
#   For XIOtech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::dumpDecode

$Id: dumpDecode.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

A buffer is passed to this module and the function in this module decode
it and format it to ASCII strings. These strings are then logged and the 
user can look them over.

Entry pointes will be provided so that the user may call individual 
decoder functions that take the buffer to an ASCII string only. This will 
facilitate sharing of code among groups.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

              DecodeDump           
              
        The less significant ones


=cut


#                         
# - what I am
#

package TestLibs::dumpDecode;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::CtlrGrabber;
use TestLibs::utility;
use XIOTech::decodeRings;
use XIOTech::decodeSupport;
use XIOTech::fmtFIDs;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - Constants used   THESE ARE ONLY USED IN THIS FILE
#
use constant UNKNOWN_FID        => "unknown FID";

use constant DSKBFID            => "Disk Bays";
use constant PDISKFID           => "Physical Disks";
use constant TGTFID             => "Target";

use constant BEPEQ              => "BE Physical exec queue";
use constant BEREQ              => "BE RAID exec queue";
use constant BER5EQ             => "BE RAID 5 exec queue";
use constant BEVEQ              => "BE Virtual exec queue";
use constant BEDEQ              => "BE Define exec queue";
use constant BERIEQ             => "BE RAID init exec queue";
use constant BERXCEQ            => "BE RAID XOR completion exec queue";
use constant BERXEQ             => "BE RAID XOR exec queue";

use constant FEPEQ              => "FE Physical exec queue";
use constant FEREQ              => "FE RAID exec queue";
use constant FER5EQ             => "FE RAID 5 exec queue";
use constant FEVEQ              => "FE Virtual exec queue";
use constant FEDEQ              => "FE Define exec queue";
use constant FERIEQ             => "FE RAID init exec queue";
use constant FERXCEQ            => "FE RAID XOR completion exec queue";
use constant FERXEQ             => "FE RAID XOR exec queue";

use constant BEREEQ             => "BE RAID error exec queue";
use constant BEPCQ              => "BE Physical completion queue";
use constant BEFSEQ             => "BE File System exec queue";

use constant FEREEQ             => "FE RAID error exec queue";
use constant FEPCQ              => "FE Physical completion queue";
use constant FEFSEQ             => "FE File System exec queue";

use constant BEI0REQQ           => "BE ISP 0 request queue ";
use constant BEI1REQQ           => "BE ISP 1 request queue ";
use constant BEI2REQQ           => "BE ISP 2 request queue ";
use constant BEI3REQQ           => "BE ISP 3 request queue ";
use constant BEI0RSPQ           => "BE ISP 0 response queue ";
use constant BEI1RSPQ           => "BE ISP 1 response queue ";
use constant BEI2RSPQ           => "BE ISP 2 response queue ";
use constant BEI3RSPQ           => "BE ISP 3 response queue ";

use constant FEI0REQQ           => "FE ISP 0 request queue ";
use constant FEI1REQQ           => "FE ISP 1 request queue ";
use constant FEI2REQQ           => "FE ISP 2 request queue ";
use constant FEI3REQQ           => "FE ISP 3 request queue ";
use constant FEI0RSPQ           => "FE ISP 0 response queue ";
use constant FEI1RSPQ           => "FE ISP 1 response queue ";
use constant FEI2RSPQ           => "FE ISP 2 response queue ";
use constant FEI3RSPQ           => "FE ISP 3 response queue ";

use constant BEREEPCB           => "BE RAID error exec PCB ";
use constant BEPCPCB            => "BE Physical completion PCB ";
use constant BEPEPCB            => "BE Physical exec PCB ";
use constant BEREPCB            => "BE RAID exec PCB ";
use constant BER5EPCB           => "BE RAID 5 exec PCB ";
use constant BEVEPCB            => "BE Virtual exec PCB ";
use constant BEDEPCB            => "BE Define exec PCB ";
use constant BEIEPCB            => "BE RAID init exec PCB ";
use constant BERXCEPCB          => "BE RAID XOR completion exec PCB ";
use constant BERXEPCB           => "BE RAID XOR exec PCB ";
use constant BEFSEPCB           => "BE File System exec PCB ";
use constant FEDEPCB            => "FE Define exec PCB ";

use constant BEIRAM             => "BE Internal RAM ";
use constant FEIRAM             => "FE Internal RAM ";

use constant ITRCFID0           => "Initiator trace log 0 ";
use constant ITRCFID1           => "Initiator trace log 1 ";
use constant ITRCFID2           => "Initiator trace log 2 ";
use constant ITRCFID3           => "Initiator trace log 3 ";

use constant FETRCFID0          => "FE trace log 0 ";
use constant FETRCFID1          => "FE trace log 1 ";
use constant FETRCFID2          => "FE trace log 2 ";
use constant FETRCFID3          => "FE trace log 3 ";

use constant FEKII              => "FE proc internal information ";
use constant BEKII              => "BE proc internal information ";

use constant PDISKSFID          => "Pdisks "; 
use constant VDISKSFID          => "Vdisks "; 
use constant SRVRSTATS          => "Server Statistics "; 
use constant VDSKSTATS          => "Vdisk Statistics "; 
use constant SERVERSFID         => "Servers ";
use constant RAIDSFID           => "Raids ";  
use constant LPSTATSFE          => "FE Loop Statistics ";  
use constant LPSTATSBE          => "BE Loop Statistics ";  
use constant I2CSTATSFID        => "I2C Statistics ";  
use constant PROCSTATSFID       => "Proc Statistics ";  
use constant PCISTATSFID        => "PCI Statistics ";  
use constant CACHESTATSFID      => "Cache Statistics ";  
use constant ENVSTATSFID        => "Environment Statistics ";  
use constant ENVSTATSFIDNC      => "Combined Loop Statistics ";  

use constant CDBMAP             => "cache Disk Bay Map ";  
use constant CPDMAP             => "cache Physical Disk Map ";  
use constant CPDFMAP            => "cache pdisk fail Map ";  
use constant CPDRMAP            => "cache pdisk rebuild Map ";  
use constant CVDMAP             => "cache Virtual Disk Map ";  
use constant CVDCMAP            => "cache vdisk copy Map ";  
use constant CVDMMAP            => "cache vdisk mirror Map ";  
use constant CRMAP              => "cache Raid Map ";  
use constant CSMAP              => "cache Server Map ";  
use constant CSTMAP             => "cache Target Map ";  

use constant CDBPATH            => "cache Disk Bay Paths ";  
use constant CPDPATH            => "cache Physical Disk Paths "; 
 
use constant CCBSERIAL          => "CCB Serial Buffer ";  
use constant FEMRPTRCFID        => "FE MRP Trace ";  
use constant BEMRPTRCFID        => "BE MRP Trace ";  
use constant FEFLTRECFID        => "FE Flight Recorder ";  
use constant BEFLTRECFID        => "BE Flight Recorder ";  
use constant CCBTRCFID          => "CCB Trace Buffer ";  
use constant CCBHEAPSTFID       => "CCB Heap Stats ";  
use constant CCBPROFILEFID      => "CCB Profile Dump ";  
use constant CCBPCBDUMPFID      => "CCB PCB Dump ";  
use constant CCBFCMCOUNTERSFID  => "CCB FCM Counters Dump ";  

use constant BENVRPT1           => "BE NVRAM part 1 ";  
use constant BENVRPT2           => "BE NVRAM part 2 ";  
use constant BENVRPT5           => "BE NVRAM part 5 ";  
use constant FENVRPT1           => "FE NVRAM part 1 ";  
use constant FENVRPT5           => "FE NVRAM part 5 ";  
           
use constant CCBNVR1            => "CCB NVRAM 1 ";
use constant CCBNVRFLASH        => "CCB NVRAM Flash Copies ";
use constant FWVERSIONS         => "Firmware Versions ";
  
use constant PDISKFCALCTRS      => "Pdisk FCAL counters ";  
       

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 4298 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #




    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &DecodeDump
                        &ReadFileToBuffer


                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################

sub ReadFileToBuffer
{
    my ($filename, $bufferPtr, $strPtr) = @_;

    my $length;
    local *DATAFILE;
    my $ret;

    open DATAFILE, $filename or die "Can't open file: $filename";
    binmode DATAFILE;

    my @fileInfo = stat($filename);

    #print( "for file $filename . . \n"); 
    #print( " size(bytes) = $fileInfo[7] \n");


    
    $length = $fileInfo[7];    #  actual length of file

    $ret = read DATAFILE, $$bufferPtr, $length;

    if ( !$ret )
    {
        # zero bytes, or undef indicating error
        $$strPtr = "Error or zero bytes of data returned.";
        return ERROR;
    }

#    if ( $ret == EOF )
#    {
#        # at end of file
#        $$strPtr = "At end of file.";
#        return ERROR;
#    }



    $$strPtr = "Success, $ret bytes read.";
    return GOOD;

}
###########################################################################
#
#  this fcn determines the type of file we have been given and calls the 
#  appropriate dump routine. FE and BE proc dumps (NVRAM pt 5) contain a 
#  header, boot dumps (NVRAM pt 1) do not.
#
########################################################################### 
sub DecodeDump
{
    my ( $buffer, $flags, $filename, $option ) = @_;
    
    my $length;    
    my $fmt;           
    my $offset;
    my $item1;
    my $item2;
    my $item3;
    my $item4;   
    my $item5;
    my $item6;
    my $fid; 
    my $msg = "";  

    my $ret = GOOD;


    # buffer is the input stream
    # flags control the outcome in some yet-to-be-determined manner

    # the filename may contain the decoder specifier, This is particularly
    # true for the FIDs dumped to a floppy by the GUI. So the first choice
    # is to look for 'FID' in the name and match the number to a decoder

    $fid = FidMap($filename);



    #####################
    # process the header
    #####################

    $length = length $buffer;      # length of the record


    # now get the header data from the buffer
    #        00000000  67616944 20454220  000069C0 AD6C1979  Diag BE .i..y.l.
    #        00000010  28012003 42361603  00000000 00000000  . .(..6B........
    #         timestamp = 3 32 1 40 3 22 54 66

    $fmt = "LLLLS";

    ($item1, $item2, $item3, $item4, $item5 ) = unpack $fmt, $buffer;

    if ( $item1 != 0 && $length >= 20 )
    {
        # there is some data at the beginning that may be a header
        
        # re-read to get the header as a string
        
        ($item2) = unpack "A8", $buffer;
        ($item6) = unpack "A4", $buffer;

        if ( $item2 eq "Diag BE" )
        {
            # BE proc NVRAM part 5
            logInfo(" BE processor NVRAM part 5");
            $msg = "";
            $ret = DiagProc( $buffer, $flags, \$msg);
            logInfo($msg);
        }
        
        elsif ( $item2 eq "Diag FE" )
        {
            # FE proc NVRAM part 5
            logInfo(" FE processor NVRAM part 5");
            $msg = "";
            $ret = DiagProc( $buffer, $flags, \$msg);
            logInfo($msg);
        }
        
        elsif ( $item5 == 0x37e1 )
        {
            # NVRAM part 2
            logInfo(" NVRAM part 2");
            $ret = DumpNVR2( $buffer, $flags);
            logInfo($ret);
        }
        elsif ( $fid ne UNKNOWN_FID )
        {
            # FIDs may or may not appear to have a header so they
            # are tried here and in the no header case
            # decode files that are FIDs saved from the contoller
            $ret = DecodeFids( $buffer, $fid );


        }
        elsif ( $length == 32768   )
        {
            # assumed NVRAM part 1
            # contents of the first bytes are not guaranteed
            logInfo(" Validating NVRAM part 1");

            $fmt = "x25600 LL";

            ($item3, $item4 ) = unpack $fmt, $buffer;

            # : 0xbaebaeba   2: 0x1357eca8 

            if ( $item3 == 0xbaebaeba && $item4 == 0x1357eca8 )
            {
                logInfo(" NVRAM part 1 confirmed.");
                $ret = Part1Decode( \$buffer, $flags, \$msg);
                logInfo($msg);
            }
            # other 32kB non-header files could be in here as 'elsif ...'
            else
            {
                # something else
                if ( $option & 1 )
                {
                    $msg = FmtDataString( \$buffer, 0, "word", $length, 0);
                    logInfo($msg);
                    $ret = GOOD;
                }
                else
                {

                    $ret = UserSelect($buffer, $flags, $length);  
                }
            }

            
        }
        elsif ( $length == 65528 && $item6 eq "NVR1"   )
        {
            $ret = FmtCCBNVR1FID( \$msg, 0, \$buffer, 0, 0, $fid, 0xFEEB0000 );
            logInfo($msg);
        }

        elsif ( $length == 65536 && $item6 eq "NVR1"   )
        {
            $ret = FmtCCBNVR1FID( \$msg, 0, \$buffer, 0, 0, $fid, 0xFEEB0000 );
            logInfo($msg);
        }

        # other header types go here
        

        else
        {
            # unable to determine file type
            logInfo(" Record info: $item1, $item2, $length");
            if ( $option & 1 )
            {
                $msg = FmtDataString( \$buffer, 0, "word", $length, 0);
                logInfo($msg);
                $ret = GOOD;
            }
            else
            {

                $ret = UserSelect($buffer, $flags, $length);  
            }
        }

    }
    else
    {
        # there is no obvious header. try to guess the type
        # logInfo(" Record info: $item1, $item2, $length");
        logInfo(" There is no header to this file, checking size and filename. ");

        if ( $fid ne UNKNOWN_FID )
        {
            # FIDs may or may not appear to have a header so they
            # are tried here and in the with header case
            # decode files that are FIDs saved from the contoller
            $ret = DecodeFids( $buffer, $fid );


        }



        elsif ( $length == 32768   )
        {
            # assumed NVRAM part 1
            # contents of the first bytes are not guaranteed
            logInfo(" Validating NVRAM part 1");

            $fmt = "x25600 LL";

            ($item3, $item4 ) = unpack $fmt, $buffer;

            # : 0xbaebaeba   2: 0x1357eca8 

            if ( $item3 == 0xbaebaeba && $item4 == 0x1357eca8 )
            {
                logInfo(" NVRAM part 1 confirmed.");
                $ret = Part1Decode( \$buffer, $flags, \$msg);
                logInfo($msg);
            }
            # other 32kB non-header files could be in here as 'elsif ...'
            else
            {
                # something else
                if ( $option & 1 )
                {
                    $msg = FmtDataString( \$buffer, 0, "word", $length, 0);
                    logInfo($msg);
                    $ret = GOOD;
                }
                else
                {

                    $ret = UserSelect($buffer, $flags, $length);  
                }
            }

            
        }
        # other non-header files could be in here as 'elsif ...'
        else
        {
            # unable to determine file type
            logInfo(" Record info: $item1, $item2, $length");
            if ( $option & 1 )
            {
                $msg = FmtDataString( \$buffer, 0, "word", $length, 0);
                logInfo($msg);
                $ret = GOOD;
            }
            else
            {

                $ret = UserSelect($buffer, $flags, $length);  
            }
        }


    }



    return $ret;
            
}
##############################################################################
##############################################################################
sub DecodeFids
{
    my ($buffer, $fid) = @_;
    
    my $ret;
    my $msg;

    # The strings used here must match those in the FidMap() function
    if ( 
            $fid eq DSKBFID       ||
            $fid eq PDISKFID 
       )
    {
        $msg = "";

        $ret = FmtDiskBays( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    # The strings used here must match those in the FidMap() function



    
    
    elsif ( 
            $fid eq CCBPCBDUMPFID        
          )
    {
        $msg = "";

        $ret = FmtCCBPCBDumpFID(  \$msg, 0, \$buffer, 0, 0, $fid, 0  );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq CCBPROFILEFID        
          )
    {
        $msg = "";

        $ret = FmtCCProfileFID(  \$msg, 0, \$buffer, 0, 0, $fid, 0  );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq CCBHEAPSTFID        
          )
    {
        $msg = "";

        $ret = FmtCCBHeapStatsFID(  \$msg, 0, \$buffer, 0, 0, $fid, 0  );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq CCBTRCFID        
          )
    {
        $msg = "";

        $ret = FmtCCBTraceFID(  \$msg, 0, \$buffer, 0, 0, $fid, 0  );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq TGTFID           ||
            $fid eq "Other Target" 
          )
    {
        $msg = "";

        $ret = FmtTargetFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    # The strings used here must match those in the FidMap() function
    elsif ( 
            $fid eq BEREEQ       ||
            $fid eq BEPCQ        ||
            $fid eq BEFSEQ       ||
            $fid eq BEPEQ        ||
            $fid eq BEREQ        ||
            $fid eq BER5EQ       ||
            $fid eq BEVEQ        ||
            $fid eq BEDEQ        ||
            $fid eq BERIEQ       ||
            $fid eq BERXCEQ      ||
            $fid eq BERXEQ       ||
            $fid eq FEREEQ       ||
            $fid eq FEPCQ        ||
            $fid eq FEFSEQ       ||
            $fid eq FEPEQ        ||
            $fid eq FEREQ        ||
            $fid eq FER5EQ       ||
            $fid eq FEVEQ        ||
            $fid eq FEDEQ        ||
            $fid eq FERIEQ       ||
            $fid eq FERXCEQ      ||
            $fid eq FERXEQ
           )  
    {
        $msg = "\n$fid:\n";

        $ret = FmtExecQueFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    # The strings used here must match those in the FidMap() function
    elsif ( 
            $fid eq BEI0REQQ  ||
            $fid eq BEI1REQQ  ||
            $fid eq BEI2REQQ  ||
            $fid eq BEI3REQQ  ||
            $fid eq BEI0RSPQ  ||
            $fid eq BEI1RSPQ  ||
            $fid eq BEI2RSPQ  ||
            $fid eq BEI3RSPQ  ||
            $fid eq FEI0REQQ  ||
            $fid eq FEI1REQQ  ||
            $fid eq FEI2REQQ  ||
            $fid eq FEI3REQQ  ||
            $fid eq FEI0RSPQ  ||
            $fid eq FEI1RSPQ  ||
            $fid eq FEI2RSPQ  ||
            $fid eq FEI3RSPQ
           )  
    {
        $msg = "\n$fid:\n";
        # note: no hash generated for this one
        $ret = FmtIspRspQ( \$msg,  \$buffer, 0, length($buffer), $fid, 0 );
        logInfo ( $msg );

        
    }

    # The strings used here must match those in the FidMap() function
    elsif ( 
            $fid eq        BEREEPCB   ||
            $fid eq        BEPCPCB    ||
            $fid eq        BEPEPCB    ||
            $fid eq        BEREPCB    ||
            $fid eq        BER5EPCB   ||
            $fid eq        BEVEPCB    ||
            $fid eq        BEDEPCB    ||
            $fid eq        BEIEPCB    ||
            $fid eq        BERXCEPCB  ||
            $fid eq        BERXEPCB   ||
            $fid eq        FEDEPCB    ||
            $fid eq        BEFSEPCB 
           )  
    {
        $msg = "\n$fid:\n";
        # note: no hash generated for this one
        $ret = FmtPcb( \$msg,  \$buffer, 0, length($buffer), $fid, 0 );
        logInfo ( $msg );
   
        
    }

    # The strings used here must match those in the FidMap() function
    elsif ( 
            $fid eq BEIRAM      ||
            $fid eq FEIRAM
           )  
    {
        $msg = "";

        $ret = FmtIRAM( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif ( $fid eq PDISKSFID  )  
    {
        $msg = "";

        $ret = FmtPdisksFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (  $fid eq VDISKSFID  )  
    {
        $msg = "";

        $ret = FmtVdisksFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (   $fid eq SRVRSTATS  )  
    {
        $msg = "";

        $ret = FmtStatsServerFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (  $fid eq VDSKSTATS  )  
    {
        $msg = "";

        $ret = FmtStatsVdiskFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (   $fid eq SERVERSFID  )  
    {
        $msg = "";

        $ret = FmtServersFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (  $fid eq RAIDSFID  )  
    {
        $msg = "";

        $ret = FmtRaidsFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq LPSTATSFE      ||
            $fid eq LPSTATSBE
           )  
    {
        $msg = "";

        $ret = FmtStatsLoopFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (  $fid eq I2CSTATSFID  )  
    {
        $msg = "";

        $ret = FmtStatsI2CFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (  $fid eq PROCSTATSFID  )  
    {
        $msg = "";

        $ret = FmtStatsProcFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (  $fid eq PCISTATSFID  )  
    {
        $msg = "";

        $ret = FmtStatsPciFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (  $fid eq CACHESTATSFID  )  
    {
        $msg = "";

        $ret = FmtStatsCacheFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (  $fid eq ENVSTATSFID  )  
    {
        $msg = "";

        $ret = FmtStatsEnvFID( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif (  $fid eq ENVSTATSFIDNC  )  
    {
        $msg = "";

        $ret = FmtStatsLoopFIDNC( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq ITRCFID0      ||
            $fid eq ITRCFID1      ||
            $fid eq ITRCFID2      ||
            $fid eq ITRCFID3
           )  
    {
        $msg = "\n$fid:\n";

        # no hash 
        # ( $destPtr, $bufferPtr, $offset, $length, $processor, $address )
        
        $ret = FmtItrace( \$msg,  \$buffer, 0, length($buffer), $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq FETRCFID0      ||
            $fid eq FETRCFID1      ||
            $fid eq FETRCFID2      ||
            $fid eq FETRCFID3
           )  
    {
        $msg = "\n$fid:\n";

        # no hash 
        # ( $destPtr, $bufferPtr, $offset, $length, $processor, $address )
        
        $ret = FmtTrace( \$msg,  \$buffer, 0, length($buffer), $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq BEKII      ||
            $fid eq FEKII
           )  
    {
        $msg = "\n$fid:\n";

        # no hash 
        # ( $destPtr, $bufferPtr, $offset, $length, $processor, $address )
        
        $ret = FmtKii( \$msg,  \$buffer, 0, length($buffer), $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq        CDBMAP   ||
            $fid eq        CDBPATH  ||
            $fid eq        CPDMAP   ||
            $fid eq        CPDFMAP  ||
            $fid eq        CPDRMAP  ||
            $fid eq        CPDPATH  ||
            $fid eq        CVDMAP   ||
            $fid eq        CVDCMAP  ||
            $fid eq        CVDMMAP  ||
            $fid eq        CRMAP    ||
            $fid eq        CSMAP    ||
            $fid eq        CSTMAP 
           )  
    {
        $msg = "\n$fid - Hex Formatted:\n";
        # note: no hash generated for this one
        $msg .= FmtDataString( \$buffer, 0, "word", length($buffer), 0);
        logInfo ( $msg );

        
    }
    elsif (  $fid eq CCBSERIAL  )  
    {
        $msg = "Begin Decode. Note: this is a circular buffer. START and END are in the middle.";
        logInfo ( $msg );
        
        logInfo("Here are some pointers to help.\n\n");
        
        $msg = FmtDataString( \$buffer, 0, "word", 24, 0);
        logInfo ( $msg );

        logInfo("\nThe Serial data....\n\n");

        my $lBuffer = substr($buffer, 24);

        $msg = FmtDataString( \$lBuffer, 0, "text", length($lBuffer), 0);

        logInfo ( $msg );
        
    }

    elsif ( 
            $fid eq FEMRPTRCFID ||     
            $fid eq BEMRPTRCFID      
          )  
    {
        logInfo ( $fid );

        # no hash 
        # ( $ctlr, $proc, $buffer, $address, $format)
        
        $msg = TestLibs::CtlrGrabber::FmtProcData( 0, $fid, $buffer, 0,  "mrpTrace" );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq FEFLTRECFID ||     
            $fid eq BEFLTRECFID      
          )  
    {
        logInfo ( $fid );

        # no hash 
        # ( $ctlr, $proc, $buffer, $address, $format)
        
        $msg = TestLibs::CtlrGrabber::FmtProcData( 0, $fid, $buffer, 0,  "fltRec" );

        logInfo ( $msg );
        
    }

    elsif ( 
            $fid eq BENVRPT1 ||         # NVRAM part 1
            $fid eq FENVRPT1      
          )  
    {
        logInfo ( $fid );

        # no hash 
        $msg = "";
        
        Part1Decode( \$buffer, 0, \$msg);

        logInfo ( $msg );

    }
    elsif ( 
            $fid eq BENVRPT5 ||         # NVRAM part 5
            $fid eq FENVRPT5      
          )  
    {
        logInfo ( $fid );

        # no hash 
        $msg = "";
        
        DiagProc( $buffer, 0, \$msg);

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq BENVRPT2          # NVRAM part 2
          )  
    {
        logInfo ( $fid );

        # no hash 
        
        $ret = DumpNVR2( $buffer, 0);

        logInfo ( $ret );
        
    }
    elsif ( 
            $fid eq CCBNVR1          # CCB NVRAM
          )  
    {
        logInfo ( $fid );

        # no hash 
        # $ret = FmtCCBNVR1FID( \$msg, 0, \$buffer, 0, 0, $fid, 0xFEEB0000 );
        $ret = FmtCCBNVR1FIDNew( \$msg, 0, \$buffer, 0, 0, $fid, 0xFEEB0000 );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq CCBNVRFLASH          # CCB NVRAM Flash Copies
          )  
    {
        logInfo ( $fid );

        # no hash 
        $ret = FmtCCBNVR1FlashCopies( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq CCBFCMCOUNTERSFID
          )
    {
        $msg = "";

        $ret = FmtFCMCountersFID(  \$msg, 0, \$buffer, 0, 0, $fid, 0  );

        logInfo ( $msg );
        
    }
    elsif ( 
            $fid eq PDISKFCALCTRS          # Stats FCAL counters
          )  
    {
        logInfo ( $fid );

        # no hash 
        
        $ret = FmtFCALCounters( \$msg, 0, \$buffer, 0, 0, $fid, 0 );

        logInfo ( $msg );
        
    }
    elsif ( $fid eq FWVERSIONS  )  
    {
        $msg = "";
        $ret = FmtFWHeadersFIDSummary( \$msg, 0, \$buffer, 0, 0, $fid, 0 );
        logInfo ( $msg );
    }


    return GOOD;

}
##############################################################################
##############################################################################
#  
#   This fcn handles the unknown file type case. It gives the user 
#   the ability to manually select the decoder
#
#   Selecting an improper decoder will give unwanted results.
#
##############################################################################
sub UserSelect
{
    my ($buffer, $flags, $len ) = @_;

    my $ans;
    my $ret = GOOD;
    my $msg = "";

    logInfo(" Unable to determine the file structure - please help");

    print("\n\n Available decoders are... \n");
    print("    1) BE or FE NVRAM part 5                          21) Stats Env FID \n");
    print("    2) proc NVRAM part 1 (32kb File)                  22) Stats Server FID\n");
    print("    3) proc NVRAM part 2 (~1.4 MB file)               23) Stats Vdisk FID \n");
    print("    4) plain HEX dump                                 24) Stats Loop (FE or BE)\n");
    print("    5) Physical Device dump (pdisks, diskbays, etc.)  25) Stats I2C \n");
    print("    6) Targets FID                                    26) Stats Proc (FE and BE)\n");
    print("    7) Generic Exec. Queue, Compl. Queue, FIDs        27) Stats PCI (FE and BE)\n");
    print("    8) ISP req/resp Queue FIDs                        28) Stats Cache \n");
    print("    9) Generic PCB  FIDs                              29) Stats Loop (FE and BE, non-cache)\n");
    print("   10) IRAM (FE or BE) FIDs                           30) \n");
    print("   11)                                                31) Text (ASCII) dump\n");
    print("   12) Pdisks FID                                     32) FE or BE MRP Trace\n");
    print("   13) Vdisks FID                                     33) \n");
    print("   14) Raids FID                                      34) \n");
    print("   15) Servers FID                                    35) \n");
    print("   16) Initiator Trace                                36) \n");
    print("   17) FE Trace                                       37) \n");
    print("   18) proc internal information (K_ii)               38) \n");
    print("   19)                                                39) \n");
    print("   20)                                                40) debug entry... \n");
    print("\n");
    print("    anything else) exit program\n");
    print("\nEnter your selection: ");
    
    $ans = <STDIN>;
    chomp($ans);

    print ("\n");

    if ( $ans eq "1" )
    {
        logInfo (" NVRAM part 5 selected.");
        $msg = "";
        $ret = DiagProc( $buffer, $flags, \$msg);
        logInfo($msg);
    }
    elsif ( $ans eq "2" )
    {
        logInfo (" NVRAM part 1 selected.");
        $msg = "";
        $ret = Part1Decode( \$buffer, $flags, \$msg);
        logInfo($msg)
    }
    elsif ( $ans eq "3" )
    {
        logInfo (" NVRAM part 2 selected");
        $msg = DumpNVR2( $buffer, $flags);
        logInfo($msg);   
    }
    elsif ( $ans eq "4" )
    {
        logInfo (" Hex display selected.");
        $msg = FmtDataString( \$buffer, 0, "word", $len, 0);
        logInfo($msg);
    }
    elsif ( $ans eq "5" )
    {
        # physical device dumper

        my $msg;
        $ret = FmtDiskBays( \$msg, 0, \$buffer, 0, 0, "Physical Device", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "6" )
    {
        # targets fid dumper

        my $msg;
        $ret = FmtTargetFID( \$msg, 0, \$buffer, 0, 0, "Target FID", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "7" )
    {
        # Exec Queue fid dumper            

        my $msg;
        $ret = FmtExecQueFID( \$msg, 0, \$buffer, 0, 0, "Generic Exec Queue", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "8" )
    {
        # ISP request/resp  fid dumper   NO HASH GENERATED

        my $msg = "Generic ISP Queue \n";
        $ret = FmtIspRspQ( \$msg,  \$buffer, 0, length($buffer), "Generic ISP Queue", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "9" )
    {
        # PCB fid dumper    NO HASH GENERATED

        my $msg =  "";
        $ret = FmtPcb( \$msg,  \$buffer, 0, 0, "Generic PCB ", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "10" )
    {
        # targets fid dumper

        my $msg =  "";
        $ret = FmtIRAM( \$msg, 0, \$buffer, 0, 0, "Generic IRAM", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "21" )
    {
        # stats env fid dumper

        my $msg = "";
        $ret = FmtStatsEnvFID( \$msg, 0, \$buffer, 0, 0, "Stats Env", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "12" )
    {
        # pdisks fid dumper    ( )

        my $msg = "";
        $ret = FmtPdisksFID( \$msg, 0, \$buffer, 0, 0, "Pdisks", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "13" )
    {
        # vdisks fid dumper    ( )

        my $msg = "";
        $ret = FmtVdisksFID( \$msg, 0, \$buffer, 0, 0, "Vdisks", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "14" )
    {
        # raids fid dumper    ( )

        my $msg="";
        $ret = FmtRaidsFID( \$msg, 0, \$buffer, 0, 0, "Raids", 0 );
        logInfo ( $msg );
    }

    elsif ( $ans eq "15" )
    {
        # Servers fid dumper    ( )

        my $msg = "";
        $ret = FmtServersFID( \$msg, 0, \$buffer, 0, 0, "Servers", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "16" )
    {
        # Itrace fid dumper    ( )

        my $msg = "";
        $ret = FmtItrace( \$msg,  \$buffer, 0, 0, "Initiator Trace ", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "17" )
    {
        # Trace fid dumper    ( )

        my $msg = "";
        $ret = FmtTrace( \$msg,  \$buffer, 0, 0, "FE Trace ", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "18" )
    {
        # Trace fid dumper    ( )

        my $msg = "";
        $ret = FmtKii( \$msg,  \$buffer, 0, 0, "proc internal information ", 0 );
        logInfo ( $msg );
    }

    elsif ( $ans eq "22" )
    {
        # Stats server fid dumper    ( )

        my $msg = "";
        $ret = FmtStatsServerFID( \$msg, 0, \$buffer, 0, 0, "StatsServer", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "23" )
    {
        # Stats vdisk fid dumper     

        my $msg = "";
        $ret = FmtStatsVdiskFID( \$msg, 0, \$buffer, 0, 0, "StatsVdisk", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "24" )
    {
        # Stats loop FE | BE fid dumper     

        my $msg = "";
        $ret = FmtStatsLoopFID( \$msg, 0, \$buffer, 0, 0, "StatsLoop (generic)", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "25" )
    {
        # Stats loop FE | BE fid dumper     

        my $msg = "";
        $ret = FmtStatsI2CFID( \$msg, 0, \$buffer, 0, 0, "Stats I2C ", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "26" )
    {
        # Stats Proc FE | BE fid dumper     

        my $msg = "";
        $ret = FmtStatsProcFID( \$msg, 0, \$buffer, 0, 0, "Stats Proc ", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "27" )
    {
        # Stats PCI FE | BE fid dumper     

        my $msg = "";
        $ret = FmtStatsPciFID( \$msg, 0, \$buffer, 0, 0, "Stats PCI ", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "28" )
    {
        # Stats Cache fid dumper     

        my $msg = "";
        $ret = FmtStatsCacheFID( \$msg, 0, \$buffer, 0, 0, "Stats Cache ", 0 );
        logInfo ( $msg );
    }
    elsif ( $ans eq "29" )
    {
        # Stats Cache fid dumper     

        my $msg = "";
        $ret = FmtStatsCacheFIDNC( \$msg, 0, \$buffer, 0, 0, "Stats Loop (not cached) ", 0 );
        logInfo ( $msg );
    }


    elsif ( $ans eq "31" )
    {
        logInfo (" Hex display selected.");
        $msg = FmtDataString( \$buffer, 0, "text", $len, 0);
        logInfo($msg);
    }

    elsif ( $ans eq "32" )
    {
        logInfo ( "MRP Trace " );

        # no hash 
        # ( $ctlr, $proc, $buffer, $address, $format)
        
        $msg = CtlrGrabber::FmtProcData( 0, "MRP Trace" , \$buffer, 0,  0, "mrpTrace" );

        logInfo ( $msg );
    }

    elsif ( $ans eq "40" )
    {
        logInfo ( "MRP Trace " );

        # no hash 
        # ($destPtr, $hPtr, $bufferPtr, $offset, $reqLength, $processor, $address)
        
        $ret = FmtCCBHeapStatsFID(  \$msg, 0, \$buffer, 0, 0, "log ", 0  );

        logInfo ( $msg );
    }


    else
    {
        logInfo (" None selected - exiting");
    }

    return $ret;
}
                      

##############################################################################

##############################################################################

##############################################################################
#
#     This fcn handles the files that are data dumps from the BE 
#     processor NVRAM part 2. 
#
#
#
##############################################################################
sub DumpNVR2_OBSOLETE
{
    
    my ( $buffer, $flags ) = @_;
    
    my $available;

    my $msg;
    my $ret = GOOD;

    $available = length( $buffer ) ;   # bytes available to do

    FmtNvramDumpBEParts( \$msg, \$buffer, 0, $available, "  ", 0 );
    
    logInfo( $msg );


    return $ret;
}

##############################################################################

##############################################################################

##############################################################################
sub FidMap
{
    my ($fn) = @_;

    my $name = UNKNOWN_FID;             # default here

    my @parts1;
    my @parts2;

    # return if nothing was passed in
    if ( ! $fn ) { return $name; }

    @parts1 = split( /FID_/i, $fn );

    # if there is something after FID_ . . .
    if ( $parts1[1] )
    {
        @parts2 = split( /\./, $parts1[1]);

        #print "$fn \n";
        #print "parts: 1: $parts1[0]    2: $parts1[1]  3: @parts2  \n";
        #print "final: $parts2[0] \n";

        # Looks for "FID_" in the filename and maps the following number
        # to a text string. The string is used as a key and a label in the
        # DecodeDump() function.

        # if there is something before the . in the filename
        if ( $parts2[0] )
        {
            
            if ( $parts2[0] ==   2 ) {$name =  BENVRPT2   ; }
            
            if ( $parts2[0] == 256 ) {$name =  CCBTRCFID  ; }
            if ( $parts2[0] == 257 ) {$name =  CCBSERIAL  ; }
            if ( $parts2[0] == 258 ) {$name =  CCBHEAPSTFID  ; }
            if ( $parts2[0] == 259 ) {$name =  CCBPROFILEFID  ; }
            if ( $parts2[0] == 260 ) {$name =  CCBPCBDUMPFID  ; }

            # 261 and 262 are log files, use logSim.exe

            if ( $parts2[0] == 263 ) {$name =  CDBMAP  ; }
            if ( $parts2[0] == 264 ) {$name =  CDBPATH  ; }
            if ( $parts2[0] == 265 ) {$name =  CPDMAP  ; }
            if ( $parts2[0] == 266 ) {$name =  CPDFMAP  ; }
            if ( $parts2[0] == 267 ) {$name =  CPDRMAP  ; }
            if ( $parts2[0] == 268 ) {$name =  CPDPATH  ; }
            if ( $parts2[0] == 269 ) {$name =  CVDMAP  ; }
            if ( $parts2[0] == 270 ) {$name =  CVDCMAP  ; }
            if ( $parts2[0] == 271 ) {$name =  CVDMMAP  ; }
            if ( $parts2[0] == 272 ) {$name =  CRMAP  ; }
            if ( $parts2[0] == 273 ) {$name =  CSMAP  ; }
            if ( $parts2[0] == 274 ) {$name =  CSTMAP  ; }
            if ( $parts2[0] == 275 ) {$name =  DSKBFID; }
            if ( $parts2[0] == 276 ) {$name =  TGTFID; }

            if ( $parts2[0] == 277 ) {$name =  LPSTATSFE   ; }
            if ( $parts2[0] == 278 ) {$name =  LPSTATSBE   ; }
            if ( $parts2[0] == 279 ) {$name =  PDISKSFID  ; }
            if ( $parts2[0] == 280 ) {$name =  VDISKSFID  ; }
            if ( $parts2[0] == 281 ) {$name =  RAIDSFID   ; }
            if ( $parts2[0] == 282 ) {$name =  SERVERSFID ; }
            if ( $parts2[0] == 283 ) {$name =  I2CSTATSFID   ; }
            if ( $parts2[0] == 284 ) {$name =  PROCSTATSFID   ; }
            if ( $parts2[0] == 285 ) {$name =  PCISTATSFID   ; }
            if ( $parts2[0] == 286 ) {$name =  ENVSTATSFID   ; }
            if ( $parts2[0] == 287 ) {$name =  SRVRSTATS  ; }
            if ( $parts2[0] == 288 ) {$name =  VDSKSTATS  ; }
            if ( $parts2[0] == 289 ) {$name =  CACHESTATSFID   ; }
            if ( $parts2[0] == 290 ) {$name =  ENVSTATSFIDNC   ; }
            if ( $parts2[0] == 291 ) {$name =  PDISKFCALCTRS   ; }

           # if ( $parts2[0] == 284 ) {$name =  PDISKFID; }       # probably wrong

            if ( $parts2[0] == 293 ) {$name =  CCBNVR1   ; }
            if ( $parts2[0] == 296 ) {$name =  FWVERSIONS   ; }
            if ( $parts2[0] == 298 ) {$name =  CCBNVRFLASH   ; }
            if ( $parts2[0] == 299 ) {$name =  CCBFCMCOUNTERSFID   ; }
              

            if ( $parts2[0] == 512 ) {$name =  FEFLTRECFID  ; }
            # 513  flt rec w/timestamps
            if ( $parts2[0] == 514 ) {$name =  FEMRPTRCFID  ; }
            # 515  defrag trace

            # 516-519 are error trap fids

            if ( $parts2[0] == 520 ) {$name =  FEKII  ; }
            if ( $parts2[0] == 521 ) {$name =  ITRCFID0  ; }
            if ( $parts2[0] == 522 ) {$name =  ITRCFID1  ; }
            if ( $parts2[0] == 523 ) {$name =  ITRCFID2  ; }
            if ( $parts2[0] == 524 ) {$name =  ITRCFID3  ; }

            if ( $parts2[0] == 525 ) {$name =  FETRCFID0  ; }
            if ( $parts2[0] == 526 ) {$name =  FETRCFID1  ; }
            if ( $parts2[0] == 527 ) {$name =  FETRCFID2  ; }
            if ( $parts2[0] == 528 ) {$name =  FETRCFID3  ; }
            if ( $parts2[0] == 529 ) {$name =  FEPEQ  ; }
            if ( $parts2[0] == 530 ) {$name =  FEREQ  ; }
            if ( $parts2[0] == 531 ) {$name =  FER5EQ ; }
            if ( $parts2[0] == 532 ) {$name =  FEVEQ  ; }
            if ( $parts2[0] == 533 ) {$name =  FEDEQ  ; }
            if ( $parts2[0] == 534 ) {$name =  FERIEQ ; }
            if ( $parts2[0] == 535 ) {$name =  FERXCEQ; }
            if ( $parts2[0] == 536 ) {$name =  FERXEQ ; }


            if ( $parts2[0] == 537 ) {$name =  FEI0REQQ ; }
            if ( $parts2[0] == 538 ) {$name =  FEI1REQQ ; }
            if ( $parts2[0] == 539 ) {$name =  FEI2REQQ ; }
            if ( $parts2[0] == 540 ) {$name =  FEI3REQQ ; }
            if ( $parts2[0] == 541 ) {$name =  FEI0RSPQ ; }
            if ( $parts2[0] == 542 ) {$name =  FEI1RSPQ ; }
            if ( $parts2[0] == 543 ) {$name =  FEI2RSPQ ; }
            if ( $parts2[0] == 544 ) {$name =  FEI3RSPQ ; }

            if ( $parts2[0] == 545 ) {$name =  FENVRPT5 ; }
            if ( $parts2[0] == 546 ) {$name =  FEREEQ ; }
            # 547 raid error exec pcb  - see 803
            if ( $parts2[0] == 548 ) {$name =  FEPCQ  ; }
            # 549 raid error exec pcb  - see 805
            if ( $parts2[0] == 550 ) {$name =  FEIRAM  ; }
            # 551 be iram - see 807      
            
            # 556 FE define exec pcb
            if ( $parts2[0] == 556 ) {$name =  FEDEPCB ; }

            if ( $parts2[0] == 560 ) {$name =  FEFSEQ ; }
            if ( $parts2[0] == 562 ) {$name =  FENVRPT1 ; }


            if ( $parts2[0] == 768 ) {$name =  BEFLTRECFID  ; }
            # 769 flt rec w/timestamps
            if ( $parts2[0] == 770 ) {$name =  BEMRPTRCFID  ; }
            # 771 defrag trace

            # 772-775  Error trap info 

            if ( $parts2[0] == 776 ) {$name =  BEKII  ; }
            
            # 777-784 are initiator trace and FE trace, see 521-528

            if ( $parts2[0] == 785 ) {$name =  BEPEQ  ; }
            if ( $parts2[0] == 786 ) {$name =  BEREQ  ; }
            if ( $parts2[0] == 787 ) {$name =  BER5EQ ; }
            if ( $parts2[0] == 788 ) {$name =  BEVEQ  ; }
            if ( $parts2[0] == 789 ) {$name =  BEDEQ  ; }
            if ( $parts2[0] == 790 ) {$name =  BERIEQ ; }
            if ( $parts2[0] == 791 ) {$name =  BERXCEQ; }
            if ( $parts2[0] == 792 ) {$name =  BERXEQ ; }

            if ( $parts2[0] == 793 ) {$name =  BEI0REQQ ; }
            if ( $parts2[0] == 794 ) {$name =  BEI1REQQ ; }
            if ( $parts2[0] == 795 ) {$name =  BEI2REQQ ; }
            if ( $parts2[0] == 796 ) {$name =  BEI3REQQ ; }
            if ( $parts2[0] == 797 ) {$name =  BEI0RSPQ ; }
            if ( $parts2[0] == 798 ) {$name =  BEI1RSPQ ; }
            if ( $parts2[0] == 799 ) {$name =  BEI2RSPQ ; }
            if ( $parts2[0] == 800 ) {$name =  BEI3RSPQ ; }

            if ( $parts2[0] == 801 ) {$name =  BENVRPT5 ; }

            if ( $parts2[0] == 802 ) {$name =  BEREEQ ; }
            if ( $parts2[0] == 803 ) {$name =  BEREEPCB  ; }
            if ( $parts2[0] == 804 ) {$name =  BEPCQ  ; }
            if ( $parts2[0] == 805 ) {$name =  BEPCPCB   ; }
            # 806  FE iram    see 550
            if ( $parts2[0] == 807 ) {$name =  BEIRAM  ; }
            if ( $parts2[0] == 808 ) {$name =  BEPEPCB   ; }
            if ( $parts2[0] == 809 ) {$name =  BEREPCB   ; }
            if ( $parts2[0] == 810 ) {$name =  BER5EPCB  ; }
            if ( $parts2[0] == 811 ) {$name =  BEVEPCB   ; }
            if ( $parts2[0] == 812 ) {$name =  BEDEPCB   ; }
            if ( $parts2[0] == 813 ) {$name =  BEIEPCB   ; }
            if ( $parts2[0] == 814 ) {$name =  BERXCEPCB ; }
            if ( $parts2[0] == 815 ) {$name =  BERXEPCB  ; }
            if ( $parts2[0] == 816 ) {$name =  BEFSEQ ; }
            if ( $parts2[0] == 817 ) {$name =  BEFSEPCB  ; }
            if ( $parts2[0] == 818 ) {$name =  BENVRPT1  ; }


 






        }
    }
    return $name;
}

##############################################################################



##############################################################################
# Name:     FormatData()
#
# Desc:     Format binary data in various formats to STDOUT or a file
#
# Input:    data
#           address (that is came from)
#           format (byte/short/word/binary)
#           filename (if output to go to a file; undef otherwise)
#           reqLength - requested data length (0 = all available data)   
#      
##############################################################################
#sub FmtData
#{
#    my ( $buffer, $address, $format, $filen, $reqLength) = @_;
#
#    my $str;
#
#    $str =  FmtDataString( $buffer, $address, $format, $filen, $reqLength);
#
#    logInfo( $str); 
#
#
#}



1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.1  2005/05/04 18:53:52  RysavyR
# Initial revision
#
# Revision 1.28  2003/12/09 17:33:22  SchibillaM
# TBolt00009629: Add decoder support for FID 298 - CCB NVRAM Flash Copies.
#
# Revision 1.27  2003/11/21 20:26:58  SchibillaM
# TBolt00009629: FmtCCBNVR1FIDNew() replaces FmtCCBNVR1FID().  Lots of
# formatting changes to the CCB NVRAM FID.
#
# Revision 1.26  2003/11/07 21:20:12  SchibillaM
# TBolt00000000: Changes to decoders for FID 296 (FW Versions) and 256 (CCB
# Trace Buffer) to make them look more like the BFDump versions.  Move TracDec.pm
# from Test\TestLib to CBE\XIOTech.  Reviewed by Craig.
#
# Revision 1.25  2003/10/14 14:33:26  McmasterM
# TBolt00009397: Add logic to CCB to gather FCAL counters in background
# Added logic to CCB to collect and process the FCAL counters.  The data is
# stored in several arrays in the CCB DRAM, and are retrievable through the CCBE
# using the command 'fidread 299'.  The snapshot tools and DDR decoder have
# also been modified so that they are able to process the new arrays.
# Portions reviewed by Brett Tollefson
#
# Revision 1.24  2003/08/05 14:53:58  MenningC
# tbolt00000000: changes for nvram part 1; reviewed by Eric
#
# Revision 1.23  2003/07/29 19:48:45  MenningC
# tbolt00000000: support for no prompt; reviewed by Randy
#
# Revision 1.22  2003/06/26 18:25:59  MenningC
# TBOLT00000000: fix a decoder; reviewed by  Eric T
#
# Revision 1.21  2003/06/25 13:13:41  MenningC
# TBOLT00000000: support for fid 291; reviewed by  Eric T
#
# Revision 1.20  2003/06/17 19:46:56  MenningC
# TBOLT00000000; missed a de-reference; reviewed by BT
#
# Revision 1.19  2003/06/16 19:09:49  MenningC
# TBOLT00000000: import ddrdecode formatters into ccbcl; Reviewed by  Erc
#
# Revision 1.18  2003/06/11 16:21:58  MenningC
# TBOLT00000000: Added CCB nvr1 structure.; reviewed by Eric.
#
# Revision 1.17  2003/06/09 16:15:35  MenningC
# TBOLT00000000: Added coverage of more FIDs.; reviewed by JW.
#
# Revision 1.16  2003/06/05 15:09:46  MenningC
# TBOLT00000000: fixes for nvram pt1 selection and failover timeline changes;
#  reviewed by Eric.
#
# Revision 1.15  2003/06/03 19:47:36  MenningC
# TBOLT00000000: Changed many of the 'display' functions in the CCBCL to fill a string rather than print to the screen. The test scripts can now use these functions. Reviewed by Jeff W.
#
# Revision 1.14  2003/05/21 21:34:59  MenningC
# Tbolt00000000:more FIDs added to decoders; reveiwed by JW
#
# Revision 1.13  2003/05/14 19:19:16  MenningC
# Tbolt00000000:additions to ddrdecode. reviewed by Jeff W
#
# Revision 1.12  2003/05/12 16:52:35  MenningC
# Tbolt00000000:support for decofing of new FIDs. reviewed by Jeff W
#
# Revision 1.11  2003/05/01 19:18:38  MenningC
# Tbolt00000000; updates for nvram part 2, reviewed by JW
#
# Revision 1.10  2003/03/26 21:24:52  WerningJ
# Removed calls to unused modules
# Reviewed by Craig M
#
# Revision 1.9  2003/03/21 15:57:30  MenningC
# added record length validation - reviewed by JW
#
# Revision 1.8  2003/03/20 17:02:46  MenningC
# added decoding of redrr EQ and PCB.  reveiwed by JW
#
# Revision 1.7  2003/03/14 20:41:23  MenningC
# support for nvram part 1, reveiwed by JW
#
# Revision 1.6  2003/03/05 21:06:58  MenningC
# tbolt00000000 patch for bad structureinfo data, reviewed by JW
#
# Revision 1.5  2003/02/26 16:05:48  MenningC
# Tbolt00000000 updates for the constants record, reviewed by J Werning
#
# Revision 1.4  2003/02/14 16:10:11  MenningC
# fix some nvram stuff; reveiwed by Brett
#
# Revision 1.3  2003/02/10 22:21:14  MenningC
# Added more decode rings
#
# Revision 1.2  2003/02/08 16:17:12  MenningC
# Added more decode rings
#
# Revision 1.1  2003/02/07 17:38:31  MenningC
# new file
#
#
#
#
##############################################################################
