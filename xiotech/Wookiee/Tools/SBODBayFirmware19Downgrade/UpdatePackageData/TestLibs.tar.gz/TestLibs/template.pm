#$Id: template.pm 4298 2005-05-04 18:53:47Z RysavyR $
##############################################################################
# File name:  TestLibs::template
#
# Desc: A template for POD
#
# Date: 07/18/2002
#
# Original Author:  Keith House
#
# Last modified by  $Author: RysavyR $
# Modified date     $Date: 2005-05-04 13:53:47 -0500 (Wed, 04 May 2005) $
#
# Copyright XIOtech A Seagate Company 2001, 2002
#
##############################################################################

package TestLibs::template;

=head1 NAME

Module::NAME - A logging facility for trace, debug and log features

$Id: template.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

IF IT DOESN"T SUPPORT LINUX (MOXA FOR EXAMPLE), PLEASE STATE SO

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

 THIS SECTION OPTIONAL

 use TestLibs::Logging;

 debug("Here is some debug info")

 logInfo("Important info");

 logControl(trace => "true", debug => "true", error => "stop")

=head1 DESCRIPTION

TEST ALGORITHMS GO HERE IF THERE IS ONE

trace() provides a method of capturing code execution

debug() provides a method of capturing specific information a developer
deems useful in debugging their Perl script.

trace() and debug() display to STDERR by default, but can be sent to a file by using
debug_to().

The logControl() function controls the level of detail being
logged.  For example, to turn on trace and debug:

    logControl(trace => "true", debug => "true");

trace and debug are off by default

Other control options are:

 warning : continue - do not pause on warnings (default)
 warning : pause    - pause on warnings
 error   : continue - do not pause or stop of errors (default)
 error   : pause    - pause on warnings
 error   : stop     - stop on errors

=over 4

=item function($parameter)

Description here

=item logInfo($msg)

logs informational messags.  $msg is optional.

=back

=head1 AUTHOR

Your name and email address here

=head1 CHANGELOG

 $Log$
 Revision 1.1  2005/05/04 18:53:52  RysavyR
 Initial revision

 Revision 1.3  2002/08/02 01:44:56  HouseK
 Added or corrected some POD (perldoc)

 Revision 1.2  2002/07/18 19:24:31  HouseK
 test

 Revision 1.1  2002/07/18 19:17:37  HouseK
 Initial check in.

=cut

1;
