#! /usr/bin/perl -w
##############################################################################
#  
#   CTE Test Library
#
#   03/03/2005  Xiotech   Nick Elvester/Steve Weismann
#
#   A set of library functions to do CTE specific testing and reporting
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2005 Xiotech
#
#   For Xiotech internal use only.
#
##############################################################################

# what I am
package TestLibs::CTE;

# libs
use lib "../CCBE";
use lib "..";

# Core perl libs
use warnings;
use strict;
use Net::Time qw(inet_time inet_daytime);
use Net::SMTP;
use File::Basename;
use File::Copy;

# Optional perl libs (not optional for the script but not default perl modules)
# These are all available for Activestate perl through ppm
# Time::Parsedate is in a package called Time-modules (not available individually through ppm)
use Archive::Zip qw(:ERROR_CODES :CONSTANTS);
use DBI;
use DBD::mysql;
use MIME::Lite;
use Time::ParseDate;

# Xiotech libs
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::Logging;

# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.

# these are some globals which were not avoided but will most likely be
# placed in the config files at a later date
my $driver   = "mysql";
my $user     = "root";
my $password = "aztec";
my $options  = "host=db.corp.cte.xiotech.com";
my $db       = "CTE_Results";
my $dsn      = "DBI:$driver:database=$db;$options";

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    #$VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    $VERSION = do { my @r = (q$Revision: 27565 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        &Snap
                        &DebugCopy
                        &TimeStamp
                        &SimpleMailer
                        &CreateFailoverRun
                        &UpdateFailoverRun
                        &UpdateServerTable
                        &CloseFailoverRun
    );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);
}
our @EXPORT_OK;

###############################################################################
#  TimeStamp
#
#   DOES:   Returns a formatted date, time, and epoch for time stampping.
#           This information is derived from a RFC868 time server
#
#   IN:     Nothing
#
#   OUT:    Hash with three keys:
#               DATE  => String with date as MM-DD-YYYY
#               TIME  => String with time as HH:MM:SS
#               EPOCH => int with the current epoch (seconds since 1970)
#
#   REQUIRES:
#           Net::Time qw(inet_time inet_daytime)    (core perl module)
#           TestLibs::Constants qw(:DEFAULT :CCBE)  (Xiotech module)
#
#   TODO:   Maybe make the $timeServer a constant or config file Var
#
###############################################################################
sub TimeStamp
{
    my $timeServer = 'time.corp.cte.xiotech.com';

    # this epoch is taken from a time server using the simple time
    # protocol (Net::Time).
    # add 2208988800 seconds if server return epoch from 1/1/1900
    # which is the standard value for RFC868 (ours does 1/1/1970)
    my $epoch;
    unless ($epoch = inet_time($timeServer))
    {
        my %timeStamp = (ERR => ERROR);
        return(%timeStamp);
    }

    # i am using the if to add a 0 in front of the month and day if it is
    # less than 10 to make it easier to sort as a string in the db
    my @localtime = localtime($epoch);

    my $month = $localtime[4] + 1;
    if ($month < 10)
    {
        $month = "0" . $month;
    }

    my $day = $localtime[3];
    if ($day < 10)
    {
        $day = "0" . $day;
    }

    my $date = $month . "-" . $day . "-" . ($localtime[5] + 1900);

    # adjust the single digit hours, minutes, and seconds
    my $hour = $localtime[2];
    if ($hour < 10)
    {
        $hour = "0" . $hour;
    }
    my $minute = $localtime[1];
    if ($minute < 10)
    {
        $minute = "0" . $minute;
    }
    my $second = $localtime[0];
    if ($second < 10)
    {
        $second = "0" . $second;
    }

    my $time = $hour . ":" . $minute . ":" . $second;

    my %timeStamp = (DATE => $date, TIME => $time, EPOCH => $epoch);

    return (%timeStamp);
}

###############################################################################
#  SimpleMailer
#
#   DOES:   sends an email with status information. This sub is pretty CTE-
#           centric right now with some of the hard coded vars.
#
#   IN:     hashref containing body of email, a foreach keys will print the
#           key/value pairs (so use good names for the keys)
#
#   OUT:    GOOD on success ERROR on fail
#
#   REQUIRED:
#           Net::SMTP                               (core perl module)
#           MIME::Lite                              (optional perl module)
#           TestLibs::Constants qw(:DEFAULT :CCBE)  (Xiotech module)
#
#   TODO:   The addresses should really come from somewhere other than hard-
#           coded into the sub, but I haven't come up with a good place.
#           Same as above for the $smtpServer, $from, and $to.
#
###############################################################################
sub SimpleMailer
{
    my $bodyRef = shift(@_);
    my %body    = %{$bodyRef};
    
    my $smtpServer = "smtp.corp.cte.xiotech.com";
    my $from       = 'fabric_news_alert@xiotech.com';
    my $to         = '';
    
    # make a string for the email body, each key/value pair will get its own line
    my $bodyString;
    foreach my $key (keys %body) {
        $bodyString .= "$key: $body{$key}\n";
    }

    # 6512702630@mmode.com
    my @addresses = qw(
            6512702630@tmomail.net
            6129616494@cingularME.com
            6123255034@cingularME.com
            nicke@xiotech.com
            markj@xiotech.com
            fastd@xiotech.com
    );

    print "The following are the contents of the email you are about to send:\n";
    print "$bodyString\n";

    my $msg = MIME::Lite->new(
        From    => $from,
        To      => '',
        Subject => "Breaking Fabric News!",
        Data    => $bodyString
    );

    # send the email to the address list using SMTP
    my $smtp = Net::SMTP->new($smtpServer, Timeout => 180);
    $smtp->mail($from);

    foreach my $addy (@addresses)
    {
        $smtp->to($addy);
    }

    unless ($smtp->data())
    {
        return(ERROR);
    }
    unless ($smtp->datasend($msg->as_string))
    {
        return(ERROR);    
    }
    unless ($smtp->dataend())
    {
        return(ERROR);    
    }
    unless ($smtp->quit())
    {
        return(ERROR);    
    }
    return(GOOD);
}

###############################################################################
#  DebugCopy
#
#   DOES:   Takes the last 24 hours of the debug console for a particular
#           CTE system, zips the files and copies them to the "Y:" drive.
#           This assumes the use of the "G:" drive as the place where the
#           debug consoles are currently located and the "Y:" drive as the
#           place they need to go.
#
#   IN:     string for CTE number, i.e. "CTE18"
#
#   OUT:    1 for success, 0 for failure
#
#   REQUIRES:
#           File::Basename                          (core perl module)
#           File::Copy                              (core perl module)
#           Archive::Zip                            (optional perl module)
#           TestLibs::Constants qw(:DEFAULT :CCBE)  (Xiotech module)
#           TimeStamp                               (CTE custom subroutine)
#           FindUniqueFolder                        (CTE custom subroutine)
#
#   TODO:   This should probably take into account other people's possible
#           configurations and work with them (probably through the station
#           config file)
#
###############################################################################
sub DebugCopy
{
    my $cte = shift(@_);

    my $localDebug  = "G:/debug_logs/$cte";
    my $remoteDebug = "Y:/EngTest/QA/Debugconsole/$cte";

    # first thing is to check for the presence of the two dirs we need on the
    # G: drive and the Y: drive.
    print "Checking for the $localDebug and $remoteDebug directories\n";
    unless (-d $localDebug)
    {
        print "No local debug console dir found for $cte at $localDebug, exiting.\n";
        return(ERROR);
    }
    unless (-d $remoteDebug)
    {
        print "No remote debug console dir found for $cte at $remoteDebug, exiting.\n";
        return(ERROR);
    }
    print "Both directories exist\n";

    # now that we know the debug logs exist, look at the file listing and find the
    # last 24 hours of debug logs (then put them into an array)
    my @currentDebugLogs;
    unless (opendir(DIR, $localDebug))
    {
        warn("Error opening $localDebug for file listing: $!\n");
        return(ERROR);
    }
    my @files;
    unless (@files = readdir(DIR))
    {
        warn("Cannot read files from $localDebug: $!\n");
        return(ERROR);
    }
    closedir(DIR) || warn("Error closing $localDebug: $!\n");
    foreach my $file (@files)
    {
        my @fileInfo;
        unless (@fileInfo = stat("$localDebug/$file"))
        {
            warn("Error opening $localDebug/$file for file 'stat': $!\n");
            return(ERROR);
        }

        # get a current epoch to compare against the file timestamp (86400 sec in day)
        my %timeStamp;
        if (%timeStamp = TimeStamp() == ERROR)
        {
            warn("Cannot get time from TimeStamp\n");
            return(ERROR);
        }
        my $twentyFourHoursAgo = $timeStamp{EPOCH} - 86400;

        # if the file is a .out file and less than 24 hours old add it to the zip list
        if ($file =~ /.out/)
        {
            if ($fileInfo[9] > $twentyFourHoursAgo)
            {
                print "$file is less than 24 hours old, adding to list for zipping\n";
                push(@currentDebugLogs, "$localDebug/$file");
            }
        }
    }

    # if there aren't any debug consoles from the last 24 hours return ERROR
    if (scalar(@currentDebugLogs) < 1)
    {
        return(ERROR);
    }

    # find a unique name for a zip archive to add the logs to
    my $zipName;
    if ($zipName = FindUniqueFolder($localDebug, "$cte ", ".zip") == ERROR)
    {
        print "Cannot find a unique name for the zip file\n";
        return(ERROR);
    }

    # create the new zip at the location from above
    print "Creating zip archive of @currentDebugLogs at $zipName\n";
    my $debugZip = Archive::Zip->new();
    foreach my $currentDebugLog (@currentDebugLogs)
    {
        my $debugMember = $debugZip->addFile($currentDebugLog);
    }
    
    if ($debugZip->writeToFileNamed($zipName) != AZ_OK)
    {
        print "Error writing zip file $zipName\n";
        return(ERROR);
    }

    # now that we have our debug logs zip file copy it to the Y: drive
    my $zipBase = basename($zipName);
    print "Copying $zipName to $remoteDebug/$zipBase\n";
    copy($zipName, "$remoteDebug/$zipBase") || return(ERROR);
    return(GOOD);
}

###############################################################################
#  SnapDump
#
#   DOES:   takes a snapdump of the surviving controllers, zips it and copies
#           it to a network share (it only takes into account the current CTE
#           test station setup)
#
#   IN:     string IP address of CN0
#           string IP address of CN1
#           string for cte number, i.e. "CTE16"
#
#   OUT:    GOOD for success ERROR for failure
#
#   REQUIRES:
#           Cwd                                         (core perl module)
#           File::Path                                  (core perl module)
#           File::Copy                                  (core perl module)
#           Net::Ping                                   (core perl module)
#           File::Basename                              (core perl module)
#           Archive::Zip qw(:ERROR_CODES :CONSTANTS);   (optional perl module)
#           TestLibs::Constants qw(:DEFAULT :CCBE)      (Xiotech module)
#           FindUniqueFolder                            (custom CTE subroutine)
#
#   TODO:   This should probably take into account other people's possible
#           configurations and work with them (probably through the station
#           config file)
#
###############################################################################
sub SnapDump
{
    my $ip0 = shift(@_);
    my $ip1 = shift(@_);
    my $cte = shift(@_);

    my $snapDumpDir    = 'C:/Test/SnapDumps';
    my $remoteLocation = "Y:/EngTest/QA/SnapDumps";

    # get the current working path and determine which release we are using
    # we will need to name the dirs release_ because I couldn't think of a better
    # way to do this
    my $path = getcwd();
    my $release;
    if ($path =~ m/release_(\w+)/i)
    {
        $release = $1;
        print "release = $release\n";
    }
    else
    {
        warn("Cannot find firmware version from dir name.\n");
        return(ERROR);
    }

    # now that we know our release dir, form a path from the K: drive for both
    # snapdump.exe and logsim.exe
    my $snapDumpPath = "K:/Release/Yeti/ALPHABITS/Debug/$release/Test/Executables/SnapDump.exe";
    my $logSimPath   = "K:/Release/Yeti/ALPHABITS/Debug/$release/CCB/LogSim/Executable/LogSim.exe";

    # this next block is to create the dir structure for our snapdump storage (locally)
    # check for a main snapdump dir
    unless (-d $snapDumpDir)
    {
        print "There is no $snapDumpDir directory, creating...\n";
        unless (mkdir($snapDumpDir))
        {
            warn("Can't create $snapDumpDir for SnapDump storage: $!\n");
            return(ERROR);
        }
    }
    else
    {
        print "SnapDump directory exists at $snapDumpDir\n";
    }

    # now create the subfolders for this CTE number
    my $snapDumpSub = "$snapDumpDir/$cte";
    unless (-d $snapDumpSub)
    {
        print "There is no $snapDumpSub directory, creating...\n";
        unless (mkdir($snapDumpSub))
        {
            warn("Can't create $snapDumpSub for SnapDump storage: $!\n");
            return(ERROR);
        }
    }
    else
    {
        print "SnapDump Subdirectory exists at $snapDumpSub\n";
    }

    # find a unique date-stamped folder
    my $fullFolderPath;
    if ($fullFolderPath = FindUniqueFolder($snapDumpSub, "$cte ", "") == ERROR)
    {
        print "Cannot find a unique name for a date stamped folder\n";
        return(ERROR);
    }

    # now we can create our folder tree
    print "Creating folder $fullFolderPath\n";
    unless (mkdir($fullFolderPath))
    {
        warn("can't create folder $fullFolderPath: $!\n");
        return(ERROR);
    }
    print "Creating folder $fullFolderPath/CN0\n";
    unless (mkdir("$fullFolderPath/CN0"))
    {
        warn("can't create folder $fullFolderPath/CN0: $!\n");
        return(ERROR);
    }
    print "Creating folder $fullFolderPath/CN1\n";
    unless (mkdir("$fullFolderPath/CN1"))
    {
        warn("can't create folder $fullFolderPath/CN1: $!\n");
        return(ERROR);
    }

    # now we have all of our folders, take the snapdumps as long as controller responds to a ping
    my $ping = Net::Ping->new("icmp");
    if ($ping->ping($ip0))
    {
        print "$ip0 is alive, will take snapdump\n";
        print "Taking snapdump using the system command $snapDumpPath -l $logSimPath -o \"$fullFolderPath/CN0\" $ip0\n";
        system("$snapDumpPath -l $logSimPath -o \"$fullFolderPath/CN0\" $ip0");
    }
    else
    {
        print "$ip0 is dead, you must take a manual snapdump\n";
    }
    if ($ping->ping($ip1))
    {
        print "$ip1 is alive, will take snapdump\n";
        print "Taking snapdump using the system command $snapDumpPath -l $logSimPath -o \"$fullFolderPath/CN1\" $ip1\n";
        system("$snapDumpPath -l $logSimPath -o \"$fullFolderPath/CN1\" $ip1");
    }
    else
    {
        print "$ip1 is dead, you must take a manual snapdump\n";
    }
    $ping->close();

    # get just the zip file's path and name and put it into a separate variable for use in the copy
    my $zipPath = basename($fullFolderPath);
    my $zipFile = $zipPath . ".zip";

    print "Creating zip archive of $fullFolderPath at " . "$snapDumpDir/$zipFile\n";
    my $zip    = Archive::Zip->new();
    my $member = $zip->addTree($fullFolderPath);
    unless ($zip->writeToFileNamed("$snapDumpDir/$zipFile") == AZ_OK)
    {
        warn("Error writing file: $!\n");
        return(ERROR);
    } 

    # now delete the snapdump dir structure (rmdir() won't work unless the dir is empty)
    unless (rmtree([$fullFolderPath]))
    {
        warn("can't delete $fullFolderPath directory structure: $!");
        return(ERROR);
    }

    # now that we have our snapdump zip file copy it to the Y: drive
    print "Copying '$snapDumpDir/$zipFile' to $remoteLocation/$cte/$zipFile\n";
    unless (copy("$snapDumpDir/$zipFile", "$remoteLocation/$cte/$zipFile"))
    {
        warn("Can't copy zipfile: $!\n");
        return(ERROR);
    }
    return(GOOD);
}

###############################################################################
#  CreateFailoverRun
#
#   DOES:   Puts the appropriate values into the failover_run table to start
#           a new failover
#
#   IN:     string station name     (this is most likely from XTC.pl @ARGV[0])
#           string testcase name    (this is most likely from XTC.pl @ARGV[1])
#
#   OUT:    int FID for success ERROR for failure
#
#   REQUIRES:
#           DBI                                         (optional perl module)
#           DBD::mysql                                  (optional perl module)
#           TestLibs::Constants qw(:DEFAULT :CCBE)      (Xiotech module)
#           TimeStamp                                   (CTE custom subroutine)
#           Globals (values are examples):
#               $driver     = "mysql";
#               $user       = "root";
#               $password   = "password";
#               $options    = "host=192.168.0.1";
#               $db         = "CTE_results";
#               $dsn        = "DBI:$driver:database=$db;$options";
#
#   TODO:
#
###############################################################################
sub CreateFailoverRun
{
    my $station     = shift(@_);
    my $testcase    = shift(@_);
    my $testTag     = shift(@_);
    
    my $dbh;
    unless ($dbh = DBI->connect($dsn, $user, $password))
    {
        logError("Could not connect to DB\n");
        return(ERROR);
    }
    
    # get the fabric information from the station name
    my $xioSelectStatement = (
        "SELECT name, fabric, type, cn0_ip, cn1_ip, debug_console, release
        FROM xiotech_devices
        WHERE name = '$station'"
    );
    my $xioSqlReturn;
    unless ($xioSqlReturn = $dbh->selectrow_hashref($xioSelectStatement))
    {
        my $errorString = $dbh->errstr();
        logError("Failed SQL Query:\n\"$xioSelectStatement\"\nError: $errorString");
        return(ERROR);
    }
    
    # these will be the easy to use variables from the SQL data
    my $fabric          = $xioSqlReturn->{fabric};
    my $cn0             = $xioSqlReturn->{cn0_ip};
    my $cn1             = $xioSqlReturn->{cn1_ip};
    my $debugConsole    = $xioSqlReturn->{debug_console};
    my $release         = $xioSqlReturn->{release};
    
    # get the time stamp before we lock any tables to reduce the time they are locked
    my %timeStamp = TimeStamp();
    if (defined($timeStamp{ERR}))
    {
        logError("Cannot get time from TimeStamp");
        return(ERROR);
    }
    
    # now go out to the failover_run table and grab a new Failover ID
    unless ($dbh->do("LOCK TABLES failover_run WRITE"))
    {
        my $errorString = $dbh->errstr();
        logError("Failed DB Lock Statement\nError: $errorString");
        return(ERROR);
    }
    my $maxSqlStatement = "SELECT MAX(fid) FROM failover_run";
    my $maxSqlReturn;
    unless ($maxSqlReturn = $dbh->selectrow_hashref($maxSqlStatement))
    {
        my $errorString = $dbh->errstr();
        $dbh->do("UNLOCK TABLES");
        logError("Failed SQL Query:\n\"$maxSqlStatement\"\nError: $errorString");
        return(ERROR);
    }
    
    # add one to get the next available fid
    my $fid = ($maxSqlReturn->{'MAX(fid)'} + 1);
    
    # display and insert the new FID, then perform cleanup and return
    logInfo("Inserting the following values into the CTE Database:\n");
    logInfo("Test Tag         = $testTag");
    logInfo("Failover ID      = $fid\n");
    logInfo("Failover Running = Yes\n");
    logInfo("IO Status        = Go\n");
    logInfo("Start Date       = $timeStamp{DATE}\n");
    logInfo("Start Time       = $timeStamp{TIME}\n");
    logInfo("Start Epoch      = $timeStamp{EPOCH}\n");
    logInfo("Fabric           = $fabric\n");
    logInfo("Failover Mode    = $testcase\n");
    logInfo("Release          = $release\n");
    
    my $insertStatement = (
        "INSERT INTO failover_run(fid, start_date, start_time, start_epoch, fabric, failover_running, io_status, failover_mode, release, test_tag)
         VALUES ('$fid', '$timeStamp{DATE}', '$timeStamp{TIME}', '$timeStamp{EPOCH}', '$fabric', 'Yes', 'Go', '$testcase', '$release', '$testTag')"
    );
    unless ($dbh->do($insertStatement))
    {
        my $errorString = $dbh->errstr();
        $dbh->do("UNLOCK TABLES");
        logInfo($insertStatement);
        logError("Failed SQL Query:\n\"$maxSqlStatement\"\nError: $errorString");
        return(ERROR);
    }
    $dbh->do("UNLOCK TABLES");
    $dbh->disconnect();
    logInfo("Initial database entry for FID $fid complete\n");
    return($fid)
}

###############################################################################
#  UpdateFailoverRun
#
#   DOES:   Updates the failover_run table with data
#
#   IN:     int for fid
#
#   OUT:    GOOD for success ERROR for failure
#
#   REQUIRES:
#           DBI                                         (optional perl module)
#           DBD::mysql                                  (optional perl module)
#           TestLibs::Constants qw(:DEFAULT :CCBE)      (Xiotech module)
#           TimeStamp                                   (CTE custom subroutine)
#           Globals (values are examples):
#               $driver     = "mysql";
#               $user       = "root";
#               $password   = "password";
#               $options    = "host=192.168.0.1";
#               $db         = "CTE_results";
#               $dsn        = "DBI:$driver:database=$db;$options";
#
#   TODO:
#
###############################################################################
sub UpdateFailoverRun
{
    my $fid = shift(@_);

    my $dbh;
    unless ($dbh = DBI->connect($dsn, $user, $password))
    {
        logError("Could not connect to DB: $!");
        return(ERROR);
    }

    # get the time stamp before we lock any tables to reduce the time they are locked
    my %timeStamp = TimeStamp();
    if (defined($timeStamp{ERR}))
    {
        logError("Cannot get time from TimeStamp");
        return(ERROR);
    }

    # lock
    unless ($dbh->do("LOCK TABLES failover_run WRITE"))
    {
        my $errorString = $dbh->errstr();
        logError("Failed DB Lock Statement\nError: $errorString");
        return(ERROR);
    }
    
    # update the row with some fresh data
    my $updateSqlStatement = (
        "UPDATE failover_run SET 
        failovers_completed = failovers_completed + 1,
        last_updated_date   = '$timeStamp{DATE}',
        last_updated_time   = '$timeStamp{TIME}',
        last_updated_epoch  = '$timeStamp{EPOCH}'
        WHERE (fid = '$fid')"
    );
    unless ($dbh->do($updateSqlStatement))
    {   
        my $errorString = $dbh->errstr();
        $dbh->do("UNLOCK TABLES");
        logError("Failed SQL Query:\n\"$updateSqlStatement\"\nError: $errorString");
        return(ERROR);
    }
    $dbh->do("UNLOCK TABLES");
    $dbh->disconnect();
    logInfo("Update to failover_run for FID $fid Successful\n");
    return(GOOD);
}
    
###############################################################################
#  UpdateServerTable
#
#   DOES:   Updates the server_table table with data (must be executed after
#           UpdateFailoverRun())
#
#   IN:     int for fid
#
#   OUT:    GOOD for success ERROR for failure
#
#   REQUIRES:
#           DBI                                         (optional perl module)
#           DBD::mysql                                  (optional perl module)
#           TestLibs::Constants qw(:DEFAULT :CCBE)      (Xiotech module)
#           TimeStamp                                   (CTE custom subroutine)
#           Globals (values are examples):
#               $driver     = "mysql";
#               $user       = "root";
#               $password   = "password";
#               $options    = "host=192.168.0.1";
#               $db         = "CTE_results";
#               $dsn        = "DBI:$driver:database=$db;$options";
#
#   TODO:   Put the xiotech devices someplace better than a local array
#
###############################################################################
sub UpdateServerTable
{
    my $fid = shift(@_);

    my $dbh;
    unless ($dbh = DBI->connect($dsn, $user, $password))
    {
        logError("Could not connect to DB: $!");
        return(ERROR);
    }

    # get the time stamp before we lock any tables to reduce the time they are locked
    my %timeStamp = TimeStamp();
    if (defined($timeStamp{ERR}))
    {
        logError("Cannot get time from TimeStamp");
        return(ERROR);
    }
    
    # lock (it seems like this thing will be locked for a big chunk of code)
    unless ($dbh->do("LOCK TABLES server_table WRITE"))
    {
        my $errorString = $dbh->errstr();
        logError("Failed DB Lock Statement\nError: $errorString");
        return(ERROR);
    }
    
    # run an update to set all servers with this fid as failed if they haven't logged in for
    # 7200 seconds (two hours). We are using FID rather than fabric because it is the only 
    # reliable way to make sure this is the same failover run as what we are using for the 
    # other parts of the script
    my $twoHoursAgo = $timeStamp{EPOCH} - 7200;
    my $updateSqlStatement = (
        "UPDATE server_table SET 
        stop_date       = '$timeStamp{DATE}',
        stop_time       = '$timeStamp{TIME}',
        stop_epoch      = '$timeStamp{EPOCH}',
        stop_cause      = 'No login for 7200 seconds',
        server_status   = 'failed'
        WHERE fid = '$fid' AND last_login_epoch < '$twoHoursAgo' AND stop_date IS NULL"
    );
    unless ($dbh->do($updateSqlStatement))
    {   
        my $errorString = $dbh->errstr();
        $dbh->do("UNLOCK TABLES");
        logError("Failed SQL Query:\n\"$updateSqlStatement\"\nError: $errorString");
        return(ERROR);
    }
    logInfo("Updated all non-responding servers \(two hours\)\n");

    # now that the systems that aren't responding are taken care of, update the master
    # failover counter for each server.  This counter gets incremented if no failures
    # for any device type have occurred.
    my $goodServersSt = (
        "UPDATE server_table
        SET completed_failovers = completed_failovers + 1
        WHERE fid = '$fid'
        AND
        stop_date IS NULL
        AND
        failed_mounts IS NULL"
    );
    unless ($dbh->do($goodServersSt))
    {
        my $errorString = $dbh->errstr();
        $dbh->do("UNLOCK TABLES");
        logError("Failed SQL Query:\n\"$goodServersSt\"\nError: $errorString");
        return(ERROR);
    }
    logInfo("Updated all good servers\n");
    
    # each device needs to get handled separatley, i am using an array to loop through
    # the valid xiotech devices for now (there will probably be a better way in the future)
    my @xioDevices = qw(bigfoot magnitude unknown wookiee);
    foreach my $device (@xioDevices)
    {
        logInfo("Updating $device devices\n");
        # if the device is mounted and there are no failures in the first_*_fail column
        # add one to the completed failovers. The SET looks wierd because there is a cat of the device
        # in the SQL field name (the field names are valid perl vars so a cat was necessary)
        my $devUpdateSt = (
            "UPDATE server_table
            SET first_" . $device . "_failovers_completed = first_" . $device . "_failovers_completed + 1
            WHERE fid = '$fid'
            AND
            mounted_" . $device . " = 'yes'
            AND
            first_" . $device . "_fail_date IS NULL
            AND
            stop_date IS NULL"
        );
        unless ($dbh->do($devUpdateSt))
        {
            my $errorString = $dbh->errstr();
            $dbh->do("UNLOCK TABLES");
            logError("Failed SQL Query:\n\"$devUpdateSt\"\nError: $errorString");
            return(ERROR);
        }
    }
    $dbh->do("UNLOCK TABLES");
    $dbh->disconnect();
    logInfo("Update to server_table for FID $fid Successful\n");
    return(GOOD);
}

###############################################################################
#  CloseFailoverRun
#
#   DOES:   Closes out a failover run on success or failure
#
#   IN:     int    FID
#           string stop cause
#
#   OUT:    GOOD for success ERROR for failure
#
#   REQUIRES:
#           DBI                                         (optional perl module)
#           DBD::mysql                                  (optional perl module)
#           TestLibs::Constants qw(:DEFAULT :CCBE)      (Xiotech module)
#           TimeStamp                                   (CTE custom subroutine)
#           Globals (values are examples):
#               $driver     = "mysql";
#               $user       = "root";
#               $password   = "password";
#               $options    = "host=192.168.0.1";
#               $db         = "CTE_results";
#               $dsn        = "DBI:$driver:database=$db;$options";
#
#   TODO:
#
###############################################################################
sub CloseFailoverRun
{
    my $fid         = shift(@_);
    my $stopCause   = shift(@_);
    
    my $dbh;
    unless ($dbh = DBI->connect($dsn, $user, $password))
    {
        logError("Could not connect to DB\n");
        return(ERROR);
    }
    
    # get a time stamp
    my %timeStamp = TimeStamp();
    if (defined($timeStamp{ERR}))
    {
        logError("Cannot get time from TimeStamp");
        return(ERROR);
    }
    
    # lock
    unless ($dbh->do("LOCK TABLES failover_run WRITE"))
    {
        my $errorString = $dbh->errstr();
        logError("Failed DB Lock Statement\nError: $errorString");
        return(ERROR);
    }
    
    # display closing information before the update
    logInfo("Closing FID $fid with the following values in the CTE Database:\n");
    logInfo("Failover Running = No\n");
    logInfo("IO Status        = Stop\n");
    logInfo("Stop Date        = $timeStamp{DATE}\n");
    logInfo("Stop Time        = $timeStamp{TIME}\n");
    logInfo("Stop Epoch       = $timeStamp{EPOCH}\n");
    logInfo("Stop Cause       = $stopCause\n");
    
    my $updateStatement = (
        "UPDATE failover_run
        SET
        failover_running    = 'No',
        io_status           = 'Stop',
        stop_date           = '$timeStamp{DATE}',
        stop_time           = '$timeStamp{TIME}',
        stop_epoch          = '$timeStamp{EPOCH}',
        stop_reason         = '$stopCause'
        WHERE
        fid = '$fid'"
    );
    unless ($dbh->do($updateStatement))
    {
        my $errorString = $dbh->errstr();
        $dbh->do("UNLOCK TABLES");
        logError("Failed SQL Query:\n\"$updateStatement\"\nError: $errorString");
        return(ERROR);
    }
    $dbh->do("UNLOCK TABLES");
    
    # get the fabric for this FID out of the db
    my $serverHashRef = $dbh->selectrow_hashref("SELECT fid, fabric, failovers_completed, test_tag FROM failover_run WHERE fid = '$fid'");
    if(!keys(%{$serverHashRef})) {
        logError( "No fabric found in db for $fid");
    }
    
    # set the fabric
    my $fabric = $serverHashRef->{fabric};
    if(!$serverHashRef->{fabric}) {
        logError("No fabric found in db for $fid");
    }
    
    # set the test tag
    my $testTag = $serverHashRef->{test_tag};
    if(!$serverHashRef->{test_tag}) {
        logError("No test tag found in db for $fid");
    }
    
    # set the completed failovers
    my $failoversCompleted = $serverHashRef->{failovers_completed};
    if(!$serverHashRef->{failovers_completed}) {
        logError("No completed failovers found in db for $fid");
    }
    
    $dbh->disconnect();
    
    # shoot out the email
    my %body = (FID                => $fid,
                'Stop Cause'       => $stopCause,
                Fabric             => $fabric,
                'Test Tag'         => $testTag,
                'Cycles Completed' => $failoversCompleted,
    );
    SimpleMailer(\%body);
    
    logInfo("FID $fid Closed\n");
    return(GOOD)
}

# we need this for a PM
1;
