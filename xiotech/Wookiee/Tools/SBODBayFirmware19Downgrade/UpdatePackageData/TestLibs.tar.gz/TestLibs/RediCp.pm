#! /usr/bin/perl s
# $Header$
##############################################################################
# File name:  TestLibs::RediCp
#
# Desc: A set of library functions for integration testing. These focus on
#       testing the redi-copy function.
#
# Date: 08/05/2002
#
# Original Author:  Craig Menning
#
# Last modified by  $Author: PalmiD $
# Modified date     $Date: 2005-06-01 14:21:49 -0500 (Wed, 01 Jun 2005) $
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::RediCp - Perl Tests to test the Redi-Copy function

$Id: RediCp.pm 4413 2005-06-01 19:21:49Z PalmiD $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS



=head1 DESCRIPTION

Test Functions Available:
                      
   CreateInitialCfg - creates a starting configuration. Information used
            by this function is also shared with the RCTest function. So
            if another means is used to create the initial configuration,
            it must be compatible with this one. This specifically relates
            to the size of the vdisks and underlaying raids.

   RCTest - main test entry. Here is where the test actually runs. Input
            parameters allow selecting of the test case(s) and number of
            passes. Test cases may be random (test case number = 200), 
            sequential (test case is any other number, increment is 1 or 
            non-zero) or repeating (test case is no random and the increment
            is 0).

   Sample - a debug entry point, not normally used, actions may vary.
    

   Note: the test file names used, the test directory, possible drive 
            letters, file sizes, file data, etc. are kept as constants
            in this module. The user may choose to change them.


=cut

#                         
# - what I am
#

package TestLibs::RediCp;

#
# - other modules used
#

use warnings;
#use lib "../CCBE";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :REDI);
use TestLibs::IntegCCBELib;
use TestLibs::Validate;
use TestLibs::utility;
use TestLibs::BEUtils;
use TestLibs::WrtCacheSupport;


#
# - other modules used
#

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;



#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;
use File::Compare;
use File::Copy;

use strict;

# constants


###### constants specific to this tests #######

use constant    SINGLE => "SI";
use constant    MULTIPLE => "MU";
use constant    MASTER => "MA";
use constant    SLAVE => "SL";

# these three are bit specific and NOTHING must be 0
use constant    NOTHING => 0;
use constant    PAUSE => 1;
use constant    OWNERTGL => 2;

# these are the different paramters that are used for the 
# vdiskcontrol function. They are mapped to the proper
# numeric value in the StartCopyOp function.
#use constant    COPY_BREAK           => "COPY_BREAK";           
#use constant    COPY_CONTINUOUS      => "COPY_CONTINUOUS";                   
#use constant    COPY_SWAP            => "COPY_SWAP";            
#
#use constant    ABORT_COPY           => "ABORT_COPY";           
#use constant    PAUSE_COPY           => "PAUSE_COPY";           
#use constant    RESUME_COPY          => "RESUME_COPY";          
#use constant    BREAK_ALL_COPIES     => "BREAK_ALL_COPIES";     
#use constant    BREAK_SPECIFIED_COPY => "BREAK_SPECIFIED_COPY";     
#use constant    COPY_FLIP            => "COPY_UNSWAP";

# these are used for mid-copy stresses
use constant    ABORTMID => 256;
use constant    ABORTSTART => 512;

# possibly unused
use constant    FILEDELAY => 100;


# keep this one close to correct
use constant    MAXTESTCASE => 100;

use constant    RANDOMTESTCASE => 200;

#use constant    ENDSTEPS => 4096;

# these are numeric, not bit sensitive
use constant  PAUSED => 2;
use constant  RUNNING => 1;
use constant  STOPPED => 0;


######################### static data ##############################
#
# this data determines the configurations for the test and
# is really 'global' data, but it is treated as constants.
# What is here are the parameters for the system configuration 
# that are important to the test.

# hmm, only used in one fcn, gets changed and could be local, ?
# my @drvCfgMap = ( SINGLE, SINGLE, MULTIPLE, MULTIPLE, SINGLE, SINGLE ); 

# this single line is where vdisk sizes are changed, one vdisk is 4 times
# this size and the other starts as this size and then expanded three 
# times

use constant BASE_SIZE  => 500;       # Size info for vdisks (MBYTES)

# If the above number is 'larger' then there is more to copy and the
# activity while the copy is going is more tested. If the number is 
# 'smaller' then we can do more loops of the test and possibly better 
# test the events at the end of the copy sequence.

# vars used for creating vdisks
my $vdiskSize = (4 * BASE_SIZE);          # number of MB for the vdisks to use
my @space = ((4 * BASE_SIZE), BASE_SIZE); # actual sizes used to create vdisks
                                          #   2nd size is used 4x
my @raidTypes = ( RAID_10, RAID_10);      # raid types to use



# the filenames used for the test
my $goldFileName = "c:\\RCTgoldFile.txt";
my $silverFileNameEnd = ":\\test\\RCTsilverFile.txt";

my $testDir = ":\\test";
my $testFileStart = ":\\test\\RCTFile";
my $testFileEnd = ".txt";
my $tempFileStart = ":\\test\\RCTtemp";
my $testFyleStart = ":\\test\\RCTFyle";



# a list of drive Letters we may use
my @driveLetterPool =("E", "F", "G", "H" );

#######################  global data ###############################
#
# let's keep this small, global data is bad
#
#
my $currentState = STOPPED;         # PAUSED, RUNNING, STOPPED

my $currentOwner = 0;               # index to controller array


########################################################################

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                      &CreateInitialCfg
                      &RCTest
                      &Sample


                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4413 $);
}
    our @EXPORT_OK;




######################## Public Functions  #############################
 
###############################################################################

=head2 RCTest function

This is the key entry for the REDI-copy test.

=cut

=over 1

=item Usage:

 my $rc = RCTest($coPtr, $loops, $case, $increment);
 
 where:
     $case is the starting test case number 
     $coPtr is a pointer to a list(array) of controller objects
              (It is assumed that the first member is the master and
              is the default owner for the source vdisks for the test.)
     $loops is the number of loops to do.
     $increment determins if the test case number changes from loop to
              loop when $case is not the value for RANDOM cases. If the 
              value is 1 (non-zero) the test cases will increment, if the
              value is 0, the the same test case is repeated.  

=item Returns:

       $rc will be GOOD, ERROR or INVALID.

=item Description:

    

    Misc. notes:
    
    The value 200 for the starting case indicates RANDOM. The starting case
    number need not match a valid test case and will be incremented 
    internally to the next valid one for this test.
    
    There must not be other I/O activity on vdisks attached to the MASTER
    controller while this test starts. We use vedisk activity to determine 
    the initial mapping of vdisk to drive letter. One this determination 
    has been made, external IO can be started. This can be CPDEVICE or 
    IOMETER or other programs. Note: I do not expect other IO to work well 
    if done on the two vdisks used by this test during the COPY-MIRROR 
    test cases. This is because the mirror get broken and the two drives
    will be swapped between cases. The same issue may exist with copy-break
    due to the tests clean up between passes.
    
    Howevern IO running on other vdisks not used by the test is OK, 
    providing it is not running on the master during the mapping process.

    The mapping process is done when the vdisk to letter mappings are shown.

    For this test to work, it is run on one of the 'servers' attached 
    to the controllers and not the 'workstation'.

    This test assumes a two-way configuration. N-way should also work, but
    the test will be limited to the first two controllers in the object
    list.

    Starting requirements: 
    
    Two vdisks, one with a single raid, one with 
    multiple raids. Total size of each vdisk must be about the same and
    less than 4 time the amount used for BASE_SIZE within the code. No 
    IO running on the controller during initial startup of the script. 
    Addional IO supported as described above. The vdisks must be mapped to 
    two of the letters listed in @driveLetterPool in the code for the 
    server the script is run against. Addtional vdisks that are NOT in 
    the list are allowed but will not be used. There must be sufficient 
    uncommitted storage available to allow creatin of an additional 
    vdisks slightly larger than the two that start the test. Raid type(s)
    for this new vdisks are described in @raidTypes in the code. This test
    uses some prints and will write to the screen.

=back

=cut


##############################################################################
#
#          Name: RCTest
#
#        Inputs: $coPtr, $loops, $case, $incremen
#
#       Outputs: GOOD, ERROR, or INVALID 
#
#  Globals Used: $currentOwner, $currentState
#
#   Description: see the pod
#
##############################################################################


sub RCTest
{
    my ( $coPtr, $loops, $case, $increment  ) = @_;    
    trace();

    my $i;
    my $thisCase;
    my $str;
    my $ret;
    my @coList;
    my $owner;
    my $other;
    my $src;
    my $dest;
    my $opType;
    my $activity;
    my $special;
    my $temp;
    my $ourMaster;
    my $testDrive;
    my $f1Cnt;
    my $f2Cnt;
    my $ovCnt;
    my $maxFiles;
    my @vdisks;
    my %cfgState;
    my $numCtlrs;
    my @drvCfgMap;
    my @drvOwnerMap;

    my @tcCounts;
    my %copyCounts;

    my %rsp;
    my $msg;
    my $initialGlobalCacheState;

    #########################
    # get ready for the test
    #########################
    @coList = @$coPtr;
    $numCtlrs = scalar(@coList);

    # clear counters

    for ( $i = 0; $i < 100; $i++ )
    {
        $tcCounts[$i] = 0;
    }
    
    $copyCounts{COPY_BREAK } = 0;
    $copyCounts{COPY_CONTINUOUS } = 0;
    $copyCounts{COPY_SWAP } = 0;


    
    # identify master and slave controllers


    $ourMaster = FindMaster($coPtr);
    if ( $ourMaster == INVALID )
    {
        logInfo(">>>>>>>> Unable to determine master at the beginning, test fails <<<<<<<<");
        return ERROR;
    }
    $other = 1;
    if ( $ourMaster == 1 ) { $other = 0; }



    # get a list of the vdisks
    @vdisks = GetVdiskList($coList[$ourMaster]);


    # generate initial data file. we do 'dir *.* /s' in the DOS world
    # this will give about 1.5 MB on my server

    #$ret = system("dir", "c:\\*.*", ">".$goldFileName );       # smaller
    $ret = system("dir", "c:\\*.*", "/s", ">".$goldFileName );  # larger

    print" \n dir command returned $ret \n\n";
    if ( $ret != 0 )
    {
        logInfo(">>>>>>>> Error generating initial data set. <<<<<<<<");
        return ERROR;
    }

    # the size of the file just created determines the number of 
    # copy loops and files we can use during the test.
    
    $maxFiles = DetermineLoopCount();
 


    # get vdisk to drive letter mapping. note: this also puts the 
    # 'silver' file on the test drive

    # this will also need to create the test directory
    # get vdisk map here

    @drvCfgMap = MapDrives( $coPtr, \@driveLetterPool );

    # now drvCfgMap[x] and driveLetterPool[x] point to the same things

########################################### 
# Dave,  record and disable cache here
    #
    # Get the global cache information from the controller
    #
    %rsp = $ourMaster->globalCacheInfo();

    #
    # If the request for the global cache information failed, log
    # an appropriate message and set the error return value.
    #
    if (!%rsp)
    {
        $msg = sprintf "    ====> Failed to get response to globalCacheInfo " .
                        "from controller (0x%x) <====",
                        $ourMaster->{SERIAL_NUM};
        
        logInfo($msg);
        return (ERROR);
    }
    elsif ($rsp{STATUS} != PI_GOOD)
    {
        $msg = sprintf "    ====> Unable to get global cache information " .
                        "from controller (0x%x) <====",
                        $ourMaster->{SERIAL_NUM};
        
        logInfo($msg);
        PrintError(%rsp);

        undef %rsp;
        return (ERROR);
    }

    #
    # Disable global write cache
    #
    $ret = WrtCacheControlGlobal($ourMaster, WRTCACHE_GLOBAL_SET_DISABLE);

    if ( $ret != GOOD )
    {
        logInfo("    ====> Failed while disabling global write cache <====");
        logInfo("    ====> $ourMaster->{HOST} <====");

        return (ERROR);
    }


########################################### 
 
    #
    # Now get a map of which controller owns each drive
    #
    @drvOwnerMap = MapOwners( $coPtr,  \@drvCfgMap );
    if ( $drvOwnerMap[0] == INVALID )
    {
        logInfo("Invalid data from the mapping of owners");
        return ERROR;
    }

    #    
    # now drvOwnerMap[x] has the index of the controller that owns 
    # driveLetterPool[x] 
    #

########################################### 
# Dave restore global cache here

    #
    # Capture original global write cache state
    #
    $initialGlobalCacheState = $rsp{CA_STATUS} & 0x05;

    #
    # Restore original global write cache state
    #
    if ($initialGlobalCacheState == 0)
    {
        #
        # disable global write cache
        #
        logInfo("Disabling global write cache");
        logInfo("globalRequest is: WRTCACHE_GLOBAL_SET_DISABLE");
        $ret = WrtCacheControlGlobal($ourMaster, WRTCACHE_GLOBAL_SET_DISABLE);
        if ( $ret != GOOD )
        {
            return (ERROR);
        }
    }
    else
    {
        #
        # enable global write cache
        #
        logInfo("Enabling global write cache");
        logInfo("globalRequest is: WRTCACHE_GLOBAL_SET_ENABLE");
        $ret = WrtCacheControlGlobal($ourMaster, WRTCACHE_GLOBAL_SET_ENABLE);
        if ( $ret != GOOD )
        {
            return (ERROR);
        }
    }

########################################### 

    # need to qualify all entries in the map

    for ($i = 0; $i < scalar(@drvCfgMap); $i++ )
    {
        
        logInfo("VID $drvCfgMap[$i] is mapped as drive $driveLetterPool[$i] ".
                "and is owned by controller $drvOwnerMap[$i]  ");
        if ($drvCfgMap[$i] == INVALID)
        {
            logInfo("Invalid data from the mapping of drives");
            return ERROR;
        }
    }

    #######################################
    # now fill the source drives with data
    #######################################
    
    for ($i = 0; $i < scalar(@drvCfgMap); $i++ )
    {
        
        print "Filling drive  $driveLetterPool[$i]  \n";
        
        $ret = FillDrive($driveLetterPool[$i], $maxFiles);
        if ( $ret != GOOD)
        {
            logInfo("Unable to prepare source drives with data");
            return ERROR;
        }
    }




    ############################################
    # validate/correct the requested test case 
    ############################################
    if ( $case != RANDOMTESTCASE )
    {
        $thisCase = $case;

        # this part checks for a valid test case and will get the next
        # valid case if the supplied one is INVALID
        if ( INVALID eq Determine( $thisCase, "SOURCE" ) )
        {
            while ( INVALID eq Determine( ++$thisCase, "SOURCE" )) 
            {
                $thisCase = $thisCase % MAXTESTCASE;
            }  
        }
    }

    #####################################
    # loop for the number of iterations
    #####################################
    for ( $i = 0; $i < $loops; $i++ )
    {
        logInfo("");
        $str = sprintf("-------------------------------- beginning loop %4d", $i+1);
        $str .= " ------------------------------------";
        logInfo($str);
        
        #######################
        # determine test case
        #######################
        if ( $case == RANDOMTESTCASE )
        {
            $thisCase = GetRandomTestCase();
        }
        
        PrintTestCase($thisCase);
        
        $str = sprintf("---------------------------------------------------", $i+1);
        $str .= "-------------------------------------";
        logInfo($str);

        #
        # Verify master
        #
        $ourMaster = FindMaster($coPtr);
        if ( $ourMaster == INVALID )
        {
            logInfo("Error determining master - test aborts");
            last;
        }
        $other = 1;
        if ( $ourMaster == 1 ) { $other = 0; }

        # determine conditions for this test case, all should return
        # good data as the test case has been pre-validated
        
        $temp = Determine( $thisCase, "OWNER" );
        if ($temp eq MASTER )         # map 'owner' to controller number
        {
            $owner = $ourMaster;     
        }
        else
        {
            #
            # If more than 2 controllers, randomly select one of the slaves
            #
            if ( $numCtlrs > 2 )
            {
                $other = $ourMaster;
                while ( $other == $ourMaster )
                {
                    $other = int( rand($numCtlrs) );
                } 
            }
            $owner = $other;
        }
        
#         $temp = Determine( $thisCase, "SOURCE" );           # gets SINGLE or MULTIPLE
        $src = GetDrvID( \@drvCfgMap, $owner, \@drvOwnerMap );       # gets vdisk number

        $dest = Determine( $thisCase, "DESTINATION" );
        #$dest = GetDrvID( \@vdisks, $temp, "DESTINATION" ); # gets vdisk number

        $activity = Determine( $thisCase, "WAITACTIVITY" );

        $opType = Determine( $thisCase, "OPTYPE" );

        $special = Determine( $thisCase, "SPECIAL" );

        # update counters

        $tcCounts[$thisCase] += 1;
        $copyCounts{$opType } += 1;


        # refresh controller connections
        $ret = TestNReconnectAll( $coPtr );

        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Error refreshing controller connections at start <<<<<<<<");
            last;
        }



        ####################################
        # configure the system for the test
        ####################################

        # create the destination vdisk
    
        logInfo("Creating the destination drive ");

        $dest = CreateRCPReplacementVdisk($coList[$ourMaster], $src, $dest );

        if ( $dest < 0 )
        {
            
            logError("ERROR: Unable to create the destination drive for the test.");
            # makeDest returned INVALID, so we have no vdisks to work 
            # with
            last;
        }



# do what we need to do before starting this pass of the test

        #
        # the source disk needs to be the correct number of raids for the 
        # test and it must be a target on the correct controller. So. let's
        # do a redi-cp to the correct type of drive and them move the
        # target as needed. 
        #

        $ret = AdjustSrcDrvRaids( $coList[$ourMaster], $src, $thisCase );
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failure migrating to correct raid configuration <<<<<<<<");
            last;
        }

        # look at vdisk and raid information for the drives
        $ret = VRinfo($coList[$ourMaster], $src, "SOURCE"); 
        $ret = VRinfo($coList[$ourMaster], $dest, "DESTINATION"); 

        # get the drive letter being used
#        $temp = Determine( $thisCase, "SOURCE" );
        $testDrive = GetDrvID( \@driveLetterPool, $owner, \@drvOwnerMap );  # gets letter

        # collect the data used for validation after the copy
        %cfgState = PreRCValidate1($coList[$ourMaster], $dest, $src);
        RCValidatePrint1(\%cfgState);


        #######################
        # validate test setup
        #######################
        
        # make sure the vdisks are really the type we think they are 
        # this is a verification, clean up should have restored us to 
        # the right srouce drive state, we just created the dest

        $ret = ConfirmVD( $coList[$ourMaster], $src, $dest, $thisCase);

        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Source disk is not the correct raid configuration. <<<<<<<<");
#            return ERROR;
        }


        $ret =  ConfirmOwner( $coList[$owner], $thisCase, $src);
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> The vdisk is not owned by the correct controller. <<<<<<<<");
#            return ERROR;
        }



        # display the vdisks and targets before doing the test
        logInfo("------------------- Starting Targetstatus, vdisks and raids information ---------------");
        $ret = TargetList( $coList[$ourMaster] );
        $ret = DispVdisksRaids( $coList[$ourMaster] );
        logInfo("---------------------------------------------------------------------------------------");


        ###########################
        # start the copy operation
        ###########################
        $ret = StartCopyOp($coList[$ourMaster], $src, $dest, $opType);
        
        $currentOwner = $owner;           # save global copy
        $currentState = RUNNING;          # also global

        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failure starting the copy operation. <<<<<<<<");
            last;
        }

        ######################
        # wait for completion
        ######################

        ($ret, $f1Cnt, $f2Cnt) = WaitLoop( $coPtr,
                                           $owner, 
                                           $other, 
                                           $activity, 
                                           $special,
                                           $maxFiles,
                                           $testDrive,
                                           $dest  ); 

        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failure during the copy operation. <<<<<<<<");
            last;
        }


        #####################
        # verify the results
        #####################
			
		# allow controller to do any cleanup
		DelaySecs(20);

        # refresh controller connections
        $ret = TestNReconnectAll( $coPtr );
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Error refreshing controller connections at start <<<<<<<<");
            last;
        }


        logInfo("------------------- After the copy, vdisks and raids information ---------------");
        $ret = DispVdisksRaids( $coList[$ourMaster] );

        # look at vdisk and raid information for the drives
        $ret = VRinfo($coList[$ourMaster], $src, "SOURCE"); 
        $ret = VRinfo($coList[$ourMaster], $dest, "DESTINATION"); 

        # verify the configuration now as the validation may need to 
        # move raids around to verify the copy.

        $ret = RCValidate1($coList[$currentOwner], $dest, $src, $opType, \%cfgState);

        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failure validating the current configuration. <<<<<<<<");
            last;
        }
        
        

        # look for errors on the test drive(s). (Note: owner may have changed) This
        # look at the dest on a copy-swap, the source on a copy-break and 
        # source and dest for copy mirror. THe mirror will be broken by the fcn.
        # Any config changes to do this are temporary and reversed in the fcn.

        $ret = ValidateCopyOp($coList[$ourMaster],
                              $src, 
                              $dest, 
                              $opType, 
                              $testDrive, 
                              $f1Cnt, 
                              $f2Cnt, 
                              $ovCnt,
                              $maxFiles   );

        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failure validating the copy operation. <<<<<<<<");
            last;
        }
        

        # display the vdisks and targets before doing the test
        logInfo("------------------- Ending Targetstatus, vdisks and raids information ---------------");
        $ret = TargetList( $coList[$ourMaster] );
        $ret = DispVdisksRaids( $coList[$ourMaster] );



        ############################
        # cleanup for the next pass
        ############################

        
        logInfo("\nClean up at end of test case.");



# house cleaning here... just delete some test files? 
# No, we just continue to use them
        
        # put any moved targets back, any targets are properly owned by the 
        # master in the initial configurqtion which is the first 
        # controller in the object list, therefore the 2nd parm is $coList[0]
        
        # re-find the master as it may heve been moved for some reason
        $ourMaster = FindMaster($coPtr);
        if ( $ourMaster == INVALID )
        {
            logInfo("Error determining master - test aborts");
            last;
        }

        # we also need to delete the destination vdisk

        $ret = DisassocVdisk($coList[$ourMaster], $dest );
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failure disassociating the destination vdisk. <<<<<<<<");
            last;
        }

        $ret = DeleteSingleVdisk($coList[$ourMaster], $dest );
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failure deleting the destination vdisk. <<<<<<<<");
            last;
        }
        
        #######################################
        # point to next case (as appropriate)
        #######################################
        if ( $increment != 0 )
        {
            while ( INVALID eq Determine( ++$thisCase, "SOURCE" ) )
            {
                $thisCase = $thisCase % MAXTESTCASE;
            }  
        }

        if ( ($i + 1) % 5 == 0 )
        {
            # print some statistics every 10th pass
            PrintStats( \@tcCounts, \%copyCounts , $i );
        } 

    }
    #################
    # final clean up    
    #################

    # Shouldn't be much to do. If there was an error, we bailed before 
    # getting here. May want to remove the data file from the C: drive.


    # print some statistics at the end
    PrintStats( \@tcCounts, \%copyCounts , ($loops - 1) );

# clean up...
    # delete the test files on one or more vdisks. 

    for ($i = 0; $i < scalar(@drvCfgMap); $i++ )
    {
        $testDrive = $driveLetterPool[$i];
    
        $ret = DeleteFile( $testDrive.$testFileStart."*".$testFileEnd );
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failure deleting test files. <<<<<<<<");
            return ERROR;
        }
    
        $ret = DeleteFile( $testDrive.$silverFileNameEnd );
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failure deleting silver file. <<<<<<<<");
            return ERROR;
        }
    }    


    # We could also take out the directory used for the test... nawww!
    # return to the caller
    
    logInfo("Test Completed");

    return GOOD;
} 

###############################################################################

=head2 CreatInitialCfg function

This function creates the initial controller configuration for the test.

=cut

=over 1

=item Usage:

 my $rc = CreatInitialCfg($master, $slave, $masterIP, $slaveIP, $wwn);
 
 where $master is the master controller object
       $slave is the slave controller object
       $masterIP is the IP address of the master
       $slaveIP is the IP address of the slave 
       $wwn is a pointer to a list of QLogic card WWNs
       

=item Returns:

       $rc GOOD, ERROR or INVALID.

=item Description:

    This function creates a configuration with two vdisks. The first 
    vdisks consists of a single raid and is ( 4 * BASE_SIZE ) MBytes
    in size. The second vdisk consists of four raids, each BASE_SIZE
    MBytes in size. They are mapped to the first WWN in the wwn list.

    The controllers are configured as a two way system. The RCTest 
    function requires at least two controllers.

    Hardware should be configured so that the desried WWN appears on at
    least two of the initial targets on the master. If not, the 
    configuration will not work for the test.


    Notes:

    Only the first item in the WWN list is used and it must be for 
    the server that this script is run against.

    The caller should log into the controllers so that valid object are
    supplied.

    It is assumed that the system has been 'wipe_clean'ed before calling 
    this function.

    It is not required to use this function to configure for RCTest(). 
    Any other method that produces a compatible configuration will work
    and may be used.

=back

=cut


##############################################################################
#
#          Name: CreateInitialCfg
#
#        Inputs: $master, $slave, $masterIP, $slaveIP, $wwn 
#
#       Outputs: a parameter for the test 
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################


sub CreateInitialCfg
{
    my ($coPtr, $ipPtr, $wwn ) = @_;

    trace();
    
    my $ret;
    my %rsp;
    my @vdisks;
    my $i;
    my $masterIndex;
    my $master;
    my @coList = @$coPtr;
    my $msg;
    
    #
    # Find the master controller
    #
    $masterIndex = FindMaster( $coPtr );
    if ( $masterIndex == INVALID ) 
    { 
        logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
        return(ERROR); 
    } 
    $master = $coList[$masterIndex];

    # label the drives
    $ret = LabelAllDrives($master, 11, 0, 3, 0, 0 );     # for 14 drive bays
    if ( $ret == ERROR )
    {
        logInfo(">>>>> Failed to label the drives <<<<<");
        return (ERROR);
    }

    # make a vcg
    $ret = MakeNWay( $coPtr );
    if ( $ret == ERROR )
    {
        logInfo(">>>>> Failed to create the VCG <<<<<");
        return (ERROR);
    }

    # create vdisks - this is custom
    # init vdisks
    $ret = CreateExpand($coPtr);
    if ( $ret != GOOD )
    {
        logInfo(">>>>> Failed to create vdisks <<<<<");
        return (ERROR);
    }

    #
    # Find the master controller
    #
    $masterIndex = FindMaster($coPtr);
    if ( $masterIndex == INVALID ) 
    { 
        logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
        return(ERROR); 
    } 
    $master = $coList[$masterIndex];  

    # associate to this server

    GetSIDs( $master, 0 );   # show sids to user
    
    $ret = PromptUser( 3 );
    
    $ret = AssociateServers($master, 4, $wwn );
    if ( $ret == ERROR )
    {
        logInfo(">>>>> Failed to associate drives to servers <<<<<");
        $msg = "Provided WWN list is:\n";
        for ( $i = 0; $i < scalar(@$wwn); $i++ )
        {
            if ( ($i%4) == 0 )
            {
                $msg .= "\n";
            }
            $msg .= sprintf("   %8.8X%8.8X ", $wwn->[$i]{WWN_LO}, $wwn->[$i]{WWN_HI} );
        }
        logInfo($msg);
        return (ERROR);
    }

    logInfo ("");
    logInfo("   Now run the PrepareWindowsDisks.pl script to map the files.");
    logInfo("   The vdisks created should be some or all of E, F, G, and/or H. ");
    logInfo("   These letters should not be mapped to other local or network drives. ");
    logInfo("   The script will write data files to any of the drives in the ");
    logInfo("   list and may/will leave them.");
    logInfo ("");
    



}

###############################################################################

=head2 Sample function

This is a smaple entry used for code debug and should not be used.

=cut

=over 1

=item Usage:

 my $rc = Sample($TBD);
 
 
       

=item Returns:

       $rc = GOOD.

=item Description:
 
 The behaviour of this function may change. It was used for generic debgging
 of parts of the code.    

=back

=cut



##############################################################################
#
#          Name: Sample
#
#        Inputs: 
#
#       Outputs:  
#
#  Globals Used: none
#
#   Description:  debug function
#
##############################################################################
# sample: entry point for testing this stuff
sub Sample
{
    my ($p1) = @_;
    my @list = (0,1,2);
    trace();
    my $ret;

    print " sample entry\n";


    my $ctlr;
    my $src;
    my $dest;
    my $opType;

    $src = 64;
    $dest = 66;
    $opType = "COPY_BREAK";
    $ctlr = $p1;

    print " pre-copy src = $src, dest = $dest, opType = $opType \n";
    
    $ret = StartCopyOp($ctlr, $src, $dest, $opType);
    print " post-copy ret = $ret \n";



#    DisassocFewVdisks( $p1);

#    print"############################### random cases ##############################\n";
#    RCTest(\@list, 25, 200, 1);;
#    print"############################### repeat cases ##############################\n";
#    RCTest(\@list, 25, 0, 0);;
#    print"############################### incremental cases ##############################\n";
#    RCTest(\@list, 100, 0, 1);;
#    print"############################### incremental cases ##############################\n";
#    RCTest(\@list, 100, 75, 1);;

    print " sample exit\n";

    return GOOD;
} 


######################## Private Functions #############################


sub PrintStats
{
    my ($tcPtr, $ctPtr, $loops ) = @_;

    my @tcList;
    my %ctHash;

    my $i;
    my $j;
    my $msg;

    @tcList = @$tcPtr;
    
    logInfo("------------------------------------------------------------------------");        

    # first print the counts for each of the test cases in a 10 x 10 array
    
    $i = 1 + $loops;
    logInfo("After $i loops these are the test case counts");

    logInfo("TC     +0   +1   +2   +3   +4   +5   +6   +7   +8   +9   ");
    for ( $i = 0; $i < 10; $i++ )
    {
        $msg = sprintf("%3d:", ( 10 * $i) );
        for ( $j = 0; $j < 10; $j ++ )
        {
            $msg .= sprintf( " %4d",$tcList[$j + (10 * $i)]);
        }

        logInfo( $msg );    
    }

    # now a summary of the type of copies performed

    logInfo("Summary of the copy types that were run");

    while((my $k, my $v) = each %$ctPtr)
    {
        if (!defined($v))
        {
           $v = "error: undefined";
           debug("The value in hash $k is undefined");
        }
               
        logInfo("Copy type: $k performed $v times");
        
    }
    logInfo("------------------------------------------------------------------------");        

    return GOOD;
}


###############################################################################

=head2 AdjustSrcDrvRaids function

This is a function that checks to see if the number of raids on the 
supplied vdisk matched the requirements of the test case. If not, then a
redi-copy operation is done to migrate the vdisk to the correct
configuration.

=cut

=over 1

=item Usage:

 my $rc = AdjustSrcDrvRaids( $ctlr, $vid, $thisCase );
 
 where $case is the test case number
       $vid is the vdisk 
       $testCase is the current test case

       

=item Returns:

       $rc will be GOOD or ERROR.

=item Description:
 
    The addition of a redi copy (copy swap) will make the tet a little
    longer in the cases where this is necessary. However, this is for 
    a redi-copy test script so we are just putting a little more 
    emphasis on copy-swap.

=back

=cut


##############################################################################
#
#          Name: AdjustSrcDrvRaids
#
#        Inputs: $ctlr, $vdisk, $testCase
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Look at the vdisk configuration, see if it matches the
#                needs of the test case. Do a copy-swap to the a vdisk of
#                the correct configuration, if needed.
#
##############################################################################


sub AdjustSrcDrvRaids
{
    my ( $ctlr, $src, $thisCase ) = @_;

    my %rsp;
    my $ret;
    my $totalRaids;
    my $newRaids;
    my $vdiskSize;
    my $vType;
    my $newVd;

    #####################################
    # get number of raids for this vdisk
    #####################################
    $totalRaids = 0;
    # get the vdisk info
    %rsp = $ctlr ->virtualDiskInfo($src);

    # extract raids to array
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>> Failed to get response from virtualDiskInfo  <<<<<");
        return ERROR;
    }

    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        
        if ( $rsp{ERROR_CODE} != $ctlr ->PI_ERROR_INV_VID )
        {
            # handle errors EXCEPT invalid vdisk (it is considered OK)
            logInfo(">>>>> Error from virtualDiskInfo <<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }
    else
    {
        # good path, display the data
        $totalRaids = $rsp{RAIDCNT} + $rsp{DRAIDCNT};
    }

    #######################################
    # get number of raids for the test case
    #######################################

    $vType = Determine( $thisCase, "SOURCE" );
    if ( $vType eq SINGLE )
    {
        $newRaids = 1;
    }
    else
    {
        $newRaids = 4;    # our test design arbitrarily uses 4 raids for the
                          # multiple raid test cases
    }


    print ("Source has $totalRaids raid(s), we need $newRaids \n");

    ###########################################
    # if we match the requirements, return GOOD
    ###########################################
    
    # check for both are SINGLE
    if ( ($totalRaids == 1 ) && ( $newRaids == 1 ) )
    {
        # we have a match
        return GOOD;
    }

    # check for both are MULTIPLE
    if ( ($totalRaids != 1 ) && ( $newRaids != 1 ) )
    {
        # we have a match
        return GOOD;
    }
    ##########################################################
    # if we don't match, copy-swap to a vdisk that does match
    #
    # first create the target vdisk (slightly larget size,
    #   desired number of raids (either 4 or 1)
    ##########################################################

    $newVd = CreateRCPReplacementVdisk($ctlr, $src, $vType);
    if ( $newVd == INVALID )
    {
        logInfo("ERROR: unable to create a substitute source disk");
        return ERROR;
    }


    # start a redi-cp/copy-swap operation
    $ret = StartCopyOp($ctlr, $src, $newVd, COPY_SWAP);
    if ( ERROR == $ret ) 
    {
        logInfo("Error copying to substitute source disk");
        return ERROR;
    }

    # wait for it to complete
    $ret = WaitForCpComplete($ctlr, $newVd );
    if ( ERROR == $ret ) 
    {
        logInfo ("Error waiting for substitute source tosk copy to complete");
        return ERROR;
    }

    # delete the source (leave no debris)
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) ) 
    {
        logInfo("Error, unable to delete the previous source disk");
        return ERROR;
    }
    
    # return good


    return GOOD;
}


###############################################################################







###############################################################################

=head2 Determine function

This is a function that translates a test case number to the appropriate
action in the script. It is called once for each parameter to be 
determined.

=cut

=over 1

=item Usage:

 my $rc = Determine( $case, $parameter);
 
 where $case is the test case number and $parameter is which parameter
 to return.
       

=item Returns:

       $rc will be the parameter appropriate for the test case.

=item Description:
 
 The parameter is one of the following.
     "SOURCE"  for the source vdisk to use
     "DESTINATION" for the destination vdisk to use
     "OWNER" is the controller that will own the task
     "WAITACTIVITY" is what to do while the test is running
     "OPTYPE" it the type of operation to do
     "SPECIAL" is any additional special case testing
     
 The test case number is one of the documented values.
     1-28, 31-58 and 61-88 are already defined.

     all others will return invalid
     
     Response to invalid test cases may be unexpected. To determine if 
     a test case is INVALID, try the case is question for the parameter
     "SOURCE". If it is OK (does not return INVALID), then all other 
     parameters should be OK.

=back

=cut


##############################################################################
#
#          Name: Determine
#
#        Inputs: $case, $parameter ID
#
#       Outputs: a parameter for the test, always a numeric value
#
#  Globals Used: none
#
#   Description: Determines the test parameter based upon a test case number.
#                all test cases that are supported should be reflected in this 
#                function.
#
##############################################################################

sub Determine
{
    my ( $case, $parameter ) = @_;
    trace();
    my $temp1;
    my $temp2;
    
    ####################
    # SOURCE vdisk type
    ####################

    # note this one is more important than the rest as the other code
    # uses the result from here to determine if a test case is valid
    # therefore, the MUST return INVALID for any test case not supported
    # by the other parameters

    if ( $parameter eq "SOURCE")
    {
        # odd test cases use the single raid vdisk, even are multiple
        # raid vdisks
        
        if ( 
            ($case >=  1 && $case <= 28 ) ||
            ($case >= 31 && $case <= 58 ) ||
            ($case >= 61 && $case <= 88 )   )
        {
            if ( $case % 2 == 1 )
            {
                return( SINGLE );        # single raid vdisk
            }
            else
            {
                return (MULTIPLE);       # multiple raid vdisk
            } 
        }
        
        return INVALID;                  # bad case number
    }
    
    #########################
    # DESTINATION vdisk type
    #########################
    if ( $parameter eq "DESTINATION")
    {
        
        # destination raid type alternates for each pair of
        # test cases
        if ( 
            ($case >=  1 && $case <= 28 ) ||
            ($case >= 31 && $case <= 58 ) ||
            ($case >= 61 && $case <= 88 )   )
        {
            $temp1 = $case % 30;         # the same for all three ops
            $temp1--;                    # number is 0 based, 0,,27
            $temp1 = $temp1 / 2;         # numbers are paired  
            
            if ( $temp1 % 2 == 0 )
            {
                return SINGLE;           # single raid vdisk
            }
            else
            {
                return MULTIPLE;         # multiple raid vdisk
            } 
        }
        return INVALID;
    }

    #########################
    # OWNER at the start
    #########################
    if ( $parameter eq "OWNER")
    {
        if ( 
            ($case >=  1 && $case <= 28 ) ||
            ($case >= 31 && $case <= 58 ) ||
            ($case >= 61 && $case <= 88 )   )
        {
            $temp1 = $case % 30;         # the same for all three ops

            if (
                ( $temp1 >=  1 && $temp1 <=  4 ) ||
                ( $temp1 >=  9 && $temp1 <= 12 ) ||
                ( $temp1 >= 17 && $temp1 <= 24 ) ||
                ( $temp1 >= 27 && $temp1 <= 28 )    )
            {
                return MASTER;           # master starts the copy
            }
            else
            {

                return SLAVE;            # a slave starts the copy
            }
        }
        return INVALID;                  # someone chose badly
     }

    ############################
    # WAITACTIVITY for the test
    ############################

    if ( $parameter eq "WAITACTIVITY")
    {
        if ( 
            ($case >=  1 && $case <= 28 ) ||
            ($case >= 31 && $case <= 58 ) ||
            ($case >= 61 && $case <= 88 )   )
        {
            $temp1 = $case % 30;         # the same for all three ops

            $temp2 = NOTHING;

            if (
                ( $temp1 >=  9 && $temp1 <= 16 ) ||
                ( $temp1 >= 21 && $temp1 <= 24 )   )
            {
                $temp2 = $temp2 | PAUSE;          # these are pause/resume
            }

            if ( $temp1 >= 17 && $temp1 <= 24  )
            {
                $temp2 = $temp2 | OWNERTGL;       # these are owner toggle
            }

            return $temp2;
        }

        return INVALID;
    }

    ############################
    # OPTYPE for the test
    ############################

    if ( $parameter eq "OPTYPE")
    {
        if ( 
            ($case >=  1 && $case <= 28 ) ||
            ($case >= 31 && $case <= 58 ) ||
            ($case >= 61 && $case <= 88 )   )
        {
            $temp1 = int($case / 30);    # temp1 is 0..2

            if ( $temp1 == 0 ) { return COPY_SWAP; }      
            if ( $temp1 == 1 ) { return COPY_CONTINUOUS; }
            if ( $temp1 == 2 ) { return COPY_BREAK; }   
        }                                                             
        
        return INVALID;
    }

    ############################
    # SPECIAL cases for the test
    ############################

    if ( $parameter eq "SPECIAL")
    {
        if ( 
            ($case >=  1 && $case <= 28 ) ||
            ($case >= 31 && $case <= 58 ) ||
            ($case >= 61 && $case <= 88 )   )
        {
            $temp1 = int($case % 30);    # temp1 is 1..28

            if ( $temp1 == 25 ) { return ABORTMID; }
            if ( $temp1 == 26 ) { return ABORTSTART; }
            if ( $temp1 == 27 ) { return ABORTMID; }
            if ( $temp1 == 28 ) { return ABORTSTART; }

            return NOTHING;
        }
        
        return INVALID;
    }

    # anything else requested

    print "Incorrect parameter type selected!! \n";
    return INVALID;
} 

###############################################################################

=head2 TestDetermine function

This function loops through all the supported test cases and prints the
details for each case. This was used to debug the code.

=cut

=over 1

=item Usage:

 my $rc = TestDetermine();
 
 
       

=item Returns:

       $rc = GOOD.

=item Description:
 
 The function prints the following information
     "Src vd:"  for the source vdisk to use
     "Dst vd:" for the destination vdisk to use
     "owner:" is the controller that will own the task
     "wait:" is what to do while the test is running
     "op type:" it the type of operation to do
     "spec:" is any additional special case testing
     
 The test case number is one of the documented values.
     1-28, 31-58 and 61-88 are already defined.

     All others will not be printed.     

=back

=cut

##############################################################################
#
#          Name: TestDetermine
#
#        Inputs: none 
#
#       Outputs: prints stuff   
#
#  Globals Used: none
#
#   Description: debug function for testing the determine() function
#
##############################################################################
sub TestDetermine
{
    my $i;
    my $ret;
    my $str;
    trace();
    print "These are the test cases supported:  \n";
    
    for ( $i = 0; $i < 100; $i++ )
    {
        
        PrintTestCase($i);
        
    }
    print "\n######################################################################\n";
    return GOOD;
} 


###############################################################################


##########################################################

###############################################################################

=head2 ValidateCopyOp function

This is a smaple entry used for code debug and should not be used.

=cut

=over 1

=item Usage:

 my $rc = ValidateCopyOp($ctlr, $src, $dest, $opType, $testDrive, 
                                   $f1Cnt, $f2Cnt, $ovCnt, $maxFiles);
 
     where:
        $ctlr is a pointer to a controller object
        $src is the source vdisk
        $dest is the destination vdisk
        $opType is the type of copy that was done
        $testDrive is the DOS drive letter that matches the src drive
        $f1Cnt is a nmber of file (not used)
        $f2Cnt is an unused number
        $ovcnt is an unused number
        $maxFiles is the number of test files



=item Returns:

       $rc = GOOD or ERROR.

=item Description:
 
 Just deletes the vdisk.    

=back

=cut

##############################################################################
#
#          Name: ValidateCopyOp
#
#        Inputs: $ctlr, $src, $dest, $opType, $testDrive, $numFiles
#
#       Outputs: a parameter for the test 
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################

sub ValidateCopyOp
{
    my ($ctlr, $src, $dest, $opType, $testDrive, $f1Cnt, $f2Cnt, $ovCnt, $maxFiles) = @_;
    my $i;
    my $ret;
    my $numIFiles;
    my $numYFiles;

    trace();

print("     DEBUG: validating copy operation      source = $src, dest = $dest, opType = $opType,  num files = $maxFiles, test drive = $testDrive \n");

    TargetList($ctlr);

    # this will test the integrity of the files on a copy-swap, and 
    # just verify the source on a copy-break.

    for ($i = 1; $i < $maxFiles; $i++ )
    {
        
        # use the PERL compare function to see if the files match
        $ret = CompareFiles($goldFileName, $testDrive.$testFileStart.$i.$testFileEnd  );
        if ( $ret == ERROR )
        {
            logInfo ("");           # for screen appearance
            return ERROR;
        }
    }
    
    logInfo ("");           # for screen appearance


    # compare each fyle to silver
    for ( $i = 1; $i <= $f2Cnt; $i++ )
    {
        $ret = CompareFiles($testDrive.$silverFileNameEnd,
                            $testDrive.$testFyleStart.$i.$testFileEnd  );
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> Miscompare on secondary files <<<<<<<<");
            return ERROR;
        }
    }


    logInfo ("");           # for screen appearance


    
    # if we mirrored the drive, we must first break the mirror, then 
    # make the mirror visible, then see if it is good. After we are
    # done, swap the drive back so we haven't changed the net configuration

    if ( $opType eq COPY_CONTINUOUS )
    {
        # we just validated the source, by not the copy.
        # we need to make the copy accessable and verify it.
        
        # break the mirror
        $ret = StartCopyOp($ctlr, $src, $dest, BREAK_SPECIFIED_COPY);
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failure breaking the mirror. (Guess I saved 7 years.) <<<<<<<<");
            return ERROR;
        }

       
    }

    logInfo ("");           # for screen appearance


    return GOOD;

}


##############################################################################
#
#          Name: ConfirmOwner
#
#        Inputs: controller object,  case number, src vdisk number
#
#       Outputs: GOOD, if the owner is correct, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Checks the number of raids in the vdisk to see if it meets
#                the requirement for multiple of single raid testing
#
##############################################################################


sub ConfirmOwner
{
    my ( $ctlr, $thisCase, $src) = @_;
    my $serial;
    my %rsp;
    
    my $j;
    my $i;
    my $k;
    my @targets;
    my @servers;
    my $targetCount;
    my $targPtr;
    my $servPtr;

    # get this controller's serial number
    $serial = GetSerial($ctlr);
    
    if ($serial == INVALID)
    {
        # bad serial number
        return INVALID;
    }

    # get target mapping info (via targetstatus)
    %rsp = GetTargetStatus($ctlr);
    if ( $rsp{STATUS} !=GOOD)
    {
        # bad targetstatus information 
        return INVALID;
    }

    # find the vdisk in this data and see if it is attached to
    # this serial number
    
    $targPtr = $rsp{TARGETS};
    $servPtr = $rsp{SERVERS};
    @targets = @$targPtr;
    @servers = @$servPtr;
    $targetCount = scalar(@targets);

    print ("Checking that controller $serial owns vdisk $src \n");

    # drill down to the VIDs and check the owners serial for a match
    for ($i = 0; $i < $targetCount; ++$i)
    {
        for ($j = 0; $j < scalar(@servers); ++$j)
        {
            if ($targets[$i]{TGD_TID} == $servers[$j]{TARGETID})
            {
                if ($servers[$j]{NLUNS} > 0)
                {
                    for ($k = 0; $k < $servers[$j]{NLUNS}; ++$k)
                    {
                        if ( $src == $servers[$j]{LUNMAP}[$k]{VID})
                        {
                            # we found the matching vdisk
                            
                            if ( $serial == $targets[$i]{TGD_OWNER} )
                            {
                                # serial number matched for this vdisk
                                print " serial number matched\n";
                                return GOOD;
                            }

                            # we are going to fail, state what was actually found
                            logInfo("Vdisk $src is owned by controller $targets[$i]{TGD_OWNER}");
                        }
                    }
                }   
            }
        }
    }


    logInfo("Unable to confirm the vdisk($src) is owned by the controller($serial). ");

    # could not ge a match
    return ERROR;
     
}
##############################################################################
#
#          Name: ConfirmVD
#
#        Inputs: controller object,src vdisk number, dest vdisk number, case number
#
#       Outputs: GOOD, if the vdisk is correct, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Checks the number of raids in the vdisk to see if it meets
#                the requirement for multiple of single raid testing
#
##############################################################################


sub ConfirmVD
{
    my ( $ctlr, $src, $dest, $thisCase) = @_;

    my $typeS;
    my $typeD;
    my %rsp;

    # get the type (single or multiple) that this drive should be 
    $typeS = Determine( $thisCase, "SOURCE" );

    if ($typeS eq INVALID)
    {
        logInfo("Unable to get type info for case $thisCase");
        return ERROR;
    }

    # get the type (single or multiple) that this drive should be 
    $typeD = Determine( $thisCase, "DESTINATION" );

    if ($typeD eq INVALID)
    {
        logInfo("Unable to get type info for case $thisCase");
        return ERROR;
    }

    # get the data for the drive(s)
    %rsp = PreRCValidate1($ctlr, $dest, $src,);
    
    if ($rsp{STATUS} != GOOD)
    {
        # the data was bad
        return ERROR;
    }

    # now check the results.

    # check the source vdisk
    if ( $typeS eq SINGLE)
    {
        if ( 1 != $rsp{SRC_NUMRAIDS} )
        {
            logInfo ("Source type is single and there are multiple raids");
            return ERROR;
        }
    }
    else
    {
        if ( 1 == $rsp{SRC_NUMRAIDS} )
        {
            logInfo ("Source type is multiple and there is one raid");
            return ERROR;
        }
    }

    # check the destination vdisk
    if ( $typeD eq SINGLE)
    {
        if ( 1 != $rsp{DST_NUMRAIDS} )
        {
            logInfo ("Destination type is single and there are multiple raids");
            return ERROR;
        }
    }
    else
    {
        if ( 1 == $rsp{DST_NUMRAIDS} )
        {
            logInfo ("Destination type is multiple and there is one raid");
            return ERROR;
        }
    }


    return GOOD;
}




##############################################################################
#
#          Name: PrintTestCase
#
#        Inputs: test case number
#
#       Outputs:   
#
#  Globals Used: none
#
#   Description: Just prints the test case detail, more for debug than
#                anything else
#
##############################################################################

sub PrintTestCase
{
    my ($i) = @_;
    
    my $str;
    my $ret;
    
    trace();

    $str = "Test case:";
    $str .= sprintf ("%3d  ", $i);

    $ret = Determine( $i, "SOURCE" );
    if ($ret ne INVALID)
    {
        $str .= sprintf("Src vd: %2s  ",$ret);

        $ret = Determine( $i, "DESTINATION" );
        $str .= sprintf("Dst vd: %2s  ",$ret);

        $ret = Determine( $i, "OWNER" );
        $str .= sprintf("owner: %2s  ",$ret);

        $ret = Determine( $i, "WAITACTIVITY" );
        $str .= sprintf("wait: %2d  ",$ret);

        $ret = Determine( $i, "OPTYPE" );
        $str .= sprintf("op type: %2s  ",$ret);

        $ret = Determine( $i, "SPECIAL" );
        $str .= sprintf("spec: %2d  \n",$ret);
    }
    else
    {
        $str .= " not supported\n";
    }
    logInfo( $str );

    return;
}

 
############################################################

##############################################################################
#
#          Name: GetRandomTestCase
#
#        Inputs: none
#
#       Outputs: a randomly selected, valid test case 
#
#  Globals Used: none
#
#   Description: Get a random number in the range of possible test cases, 
#                validate it and change if needed. Return the good test
#                case number.
#
##############################################################################

sub GetRandomTestCase
{
    # this just gets a random number in the range of possible test cases
    my $thisCase = randomInt(0, MAXTESTCASE);

    trace();

    # then skips any invalid cases to get to the next valid one
    while ( INVALID eq Determine( ++$thisCase, "SOURCE" ) )
    {
        $thisCase = $thisCase % 100;
    }  

    return $thisCase;
}






##############################################################################
#
#          Name: CreateExpand
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Created Vdisks, expands, inits them    
#
#
##############################################################################
sub CreateExpand
{
    trace();
    my ($coPtr) = @_;

    my @coList = @$coPtr;
    my $ret;
    my $i;
    my $l;
    my @pddList;
    my $depth = 0;
    my $stripe = 0;
    my $parity = 0;
    my $rtype;
    my $numPDs;
    my $numControllers;
    my $raidTypesIndex;
    my $spaceIndex;
    my $masterIndex;
    my $size;
    my $ctlr;

    my @raidTypes = (RAID_10, RAID_10);
    #my @space = (10000, 2500);      # use the global version

    $numControllers = scalar(@coList);

    #
    # Find the master controller
    #
    $masterIndex = FindMaster( $coPtr );
    if ( $masterIndex == INVALID ) 
    { 
        logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
        return(ERROR); 
    } 
    $ctlr = $coList[$masterIndex];

    #
    # create an array of the PDDs so we know what are working with
    #

    ######################
    # pdisk list                      # need to use only the data disks
    ######################
 
    @pddList = GetDataDisks($ctlr, FC_PREFERRED);
    
    if ( $pddList[0] == INVALID )
    {
        logError(">>>>>>>> Not enough drives for C/E/I/D test  <<<<<<<<");
        return (ERROR);
    }
        
    #
    # Create one vdisk for each controller
    #
    $raidTypesIndex = 0;
    $spaceIndex = 0;
    for( $i = 0; $i < $numControllers; $i++ )
    { 
        # 
        # Get the next raid type.  If we passed the number in the array,
        # wrap back to the first one.
        #
        if ( $raidTypesIndex > $#raidTypes )
        {
            $raidTypesIndex = 0;
        }
        
        $rtype = $raidTypes[$i];
        $raidTypesIndex++; 

        # 
        # Get the next raid size.  If we passed the number in the array,
        # wrap back to the first one.
        #
        if ( $spaceIndex > $#space )
        {
            $spaceIndex = 0;
        }
        
        $size = $space[$i];
        $spaceIndex++; 


        ####################
        # calc Raid Parms
        ####################

        my $requestedBytes =  Math::BigInt->new(($size * 1024 * 1024 ) / 512 );

        my $rtn = ValidateVdiskParams( \$depth, \$rtype, \$stripe, \$parity, \@pddList );

        my $str = "";


        # all parameters are ready for the call to create the vdisk
        $str .= "CAPACITY: $requestedBytes blocks  ";
        $str .= "RAID: $rtype  ";
        $str .= "STRIPE SIZE: $stripe  ";
        $str .= "MIRROR DEPTH: $depth  ";
        $str .= "PARITY: $parity  "; 
        $numPDs = scalar(@pddList);
        $str .= "NUMBER of PDs: $numPDs  ";   # second line
        $str .= "PD IDs:  @pddList \n";

        logInfo($str);


        if ( $rtn == INVALID )
        {
            logInfo("Parameters for creating the vdisk are invalid.");
            return INVALID;
        }


          
        ###############
        # VDISK create
        ###############

        my %rtn = $ctlr->virtualDiskCreate(   $requestedBytes,
                                            \@pddList,
                                            $rtype,                                                                     
                                            $stripe,
                                            $depth,
                                            $parity,
                                            undef,          # vid to use (can be undef)
                                            4,             # maxraids
                                            10,            # threshold
                                            0,             # flags
                                            0              # minPD
                                            );         


        if ( ! %rtn  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskCreate <<<<<<<<");
            return ERROR;
        }
        if ( $rtn{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskCreate <<<<<<<<");
            PrintError(%rtn);
            return ERROR;
        }

        if ( $size < ( 2 * BASE_SIZE ) )
        {
            for( $l = 0; $l < 3; $l++)
            {

                ###############
                # VDISK expand
                ###############
                my %info = $ctlr->virtualDiskExpand($rtn{VID}, 
                                                $requestedBytes, 
                                                \@pddList, 
                                                $rtype,
                                                $stripe,
                                                $depth,
                                                $parity,
                                                4,             # maxraids
                                                10,            # threshold
                                                0,             # flags
                                                0              # minPD
                                                );         


                if ( ! %info  )              # if no return from call
                {
                    logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
                    return ERROR;
                }
                if ( $info{STATUS} != PI_GOOD )      # if call returned an error
                {
                    logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
                    PrintError(%info);
                    return ERROR;
                }

            }
        }


        #############
        # RAIDINIT
        #############
        logInfo("Now, initialize the VDD");
        $ret = InitVdiskRids($ctlr, $rtn{VID}); 
     
        if ( $ret != GOOD )
        {
            logError(">>>>>>>> Failure to initialize RAIDS <<<<<<<<");
            return ERROR;
        }

    }

    return GOOD;


}

##############################################################################
#
#          Name: FillDrive
#
#        Inputs: drive letter, number of files 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Created Vdisks, expands, inits them    
#
#
##############################################################################
sub FillDrive
{
    trace();
    my ($testDrive, $numFiles) = @_;
    

    my $i;
    my $j;
    my $k;
    my $ret;

    # if not done
    for ( $i = 0; $i < $numFiles; $i++ )
    {

        ###################################
        # copy data files on source drive
        ###################################
        
        # copy silver to named file
        $ret = CopyFiles($testDrive.$silverFileNameEnd, 
                         $testDrive.$testFileStart.$i.$testFileEnd  );
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> We failed to copy a file <<<<<<<<");
            return ERROR;
        }


    }   # end of while  (progress)

    logInfo ("");           # for screen appearance

    return GOOD;
}

###############################################################################

=head2 CreateRCPReplacementVdisk function

This function builds a new vdisks that is an equivalent to the supplied 
vdisk. The final RAID is made slightly larger so that it may be used as
a destination for redi-copy.

=cut

=over 1

=item Usage:

 my $rc = CreateRCPReplacementVdisk( $ctlr, $oldVdisk, type  );
 
 where: $ctlr is a controller object
        $oldVdisks is the vdisk to clone
        $ type is SINGLE or MULTIPLE

=item Returns:

       $rc will be INVALID or a vdisk number

=item Things to look for:
 
 There should be no unexpected messages in the debug console or the logs.
 

=back

=cut



##############################################################################
#
#          Name: CreateRCPReplacementVdisk
#
#        Inputs: controller object, disk for size/raid reference, type to create
#
#       Outputs: new vdisk number or INVALID
#
#  Globals Used: none
#
#   Description: Given a supplied controller and existing vdisk number
#                Create a new vdisk that is similar, but slightly larger.
#                These two vdisks will be used as the source and destination 
#                of a rediCP operation. If the disk is multiple raids, then
#                the replacement disk will also be multiple raids, with the 
#                last raid slightly larger. (Hint: all raids in a vdisk are
#                the same as far aas raid type, mirror depth(=2), parity, etc. 
#
##############################################################################
sub CreateRCPReplacementVdisk
{
    my ($ctlr, $oldVdisk, $type ) = @_;
    my $newVdisk;
    my $numRIDs;
    my @RIDarray;
    my $r;
    my $i;
    my @pdd;       
    my $capacity;
    my $sourceSize;
    my $ret;    
    my $rtype; 
    my $stripe; 
    my $depth; 
    my $parity; 
    my $remaining;    
    my $numNewRaids;    

    my %rsp;

    logInfo("      Creating a 'replacement' vdisk ");

    $newVdisk = 0;
    
    
    # get info for current vdisk
    #    vdiskinfo gives the IDs for the RAIDS

    %rsp = $ctlr->virtualDiskInfo($oldVdisk);

    if ( ! %rsp )
    {
        logInfo(">>>>> Failed to get vdisk status for vdisk $oldVdisk <<<<<");
        return (INVALID);           
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Error getting vdisk status for vdisk $oldVdisk <<<<<");
        return (INVALID);           
    }

    # get the raid numbers 

    $numRIDs = $rsp{RAIDCNT};    #Number of RIDs

    $sourceSize = $rsp{CAPACITY}; # number of blocks

    # put raids into an array
    for ( $r = 0; $r < $numRIDs; $r++)
    {
        push  @RIDarray, $rsp{RIDS}[$r];
    }

    # now find out how many raids we will be using
    
    if  ($type eq MULTIPLE)
    {
        # this is a multi raid device
        $numNewRaids = randomInt(3, 6);       # 3-6 raids
    }
    else
    {
        $numNewRaids = 1;
    }



    # get raidinfo, this tells us about the vdisks and other pertinent
    # info we will need. We are going to copy the details of the FIRST
    # raid in the vdisk, even if the other raids are a bit different.

    %rsp = $ctlr->virtualDiskRaidInfo($RIDarray[0]);

    if ( ! %rsp )
    {
        logInfo(">>>>> Failed to get raidinfo status <<<<<");
        return (INVALID);          # 
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Error getting raidinfo status <<<<<");
        return (INVALID);          # 
    }

    
    
    # get the rest of the needed data
   
    $rtype  = $rsp{TYPE};
    $stripe = $rsp{SPS};
    $depth  = $rsp{DEPTH};      # should be 2 for baby alpha
    $parity = $rsp{DEPTH};
    
    # now the list of pdisks
    for ( $r = 0; $r < $rsp{PSDCNT}; $r++ )
    {
        $pdd[$r] = $rsp{PIDS}[$r]{PID}
    }     

    if ( $depth == 0 ) { $depth = 2; }         # fix for cl bug 6202

    # create/expand the new vdisk

    for ( $i = 0; $i < $numNewRaids; $i++ )
    {
        # get this info for each raid

        $capacity = $sourceSize / $numNewRaids;
        # increase the size a bit for the last raid only

        if ( ( 1 + $i ) == $numNewRaids )
        {
            # this is the last raid for the drive
            $capacity = 10000 + $capacity;
        }

        if ( $i == 0 )
        {
            

            # the first raid is always a create
            print " creating: $capacity \n";
            print "           @pdd \n";
            print "           $rtype \n";
            print "           $stripe \n";
            print "           $depth \n";
            print "           $parity \n ";


            %rsp = $ctlr->virtualDiskCreate(  $capacity,
                                    \@pdd,
                                    $rtype,                                                                     
                                    $stripe,
                                    $depth,
                                    $parity,       # parity
                                    undef,          # vid to use (can be undef)
                                    4,             # maxraids
                                    10,            # threshold
                                    0,             # flags
                                    0              # minPD
                                    );         

            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>> Failed to get response from virtualDiskCreate <<<<<");
                return INVALID;
            }

            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>> Error from virtualDiskCreate <<<<<");
                PrintError(%rsp);
                return INVALID;
            }

            $newVdisk =  $rsp{VID}


        }
        else    # these are the additional raids
        {
            # not first raid, so it is an expand
            print " expanding: $newVdisk \n";
            print "            $capacity \n";
            print "            @pdd \n";
            print "            $rtype \n";
            print "            $stripe \n";
            print "            $depth \n";
            print "            $parity \n";


            %rsp = $ctlr->virtualDiskExpand( $newVdisk,   #  vdd to expand
                                             $capacity,   #  $capacity,
                                             \@pdd,       #  $pdPointer,
                                             $rtype,      #  $rtype,                                                                     
                                             $stripe,     #  $stripe,
                                             $depth,      #  $depth,
                                             $parity,       # parity
                                             4,             # maxraids
                                             10,            # threshold
                                             0,             # flags
                                             0              # minPD
                                             );         

            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>> Failed to get response from virtualDiskExpand <<<<<");
                return INVALID;
            }

            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>> Error from virtualDiskExpand <<<<<");
                PrintError(%rsp);
                return INVALID;
            }

        }

    # repeat for all raids in the vdisk
    }

    # we need the raids to be initialized for the test, so start the inits now

# JW asked me not to init raids for his debug. This may break raid 5
# testing in the future.

    $ret = InitVdiskRids($ctlr, $newVdisk);
    if ( $ret != GOOD )
    {
        # well, we couldn't start the inits, bail out
        return INVALID;
    }    
    
    logInfo("Pause to allow inits to start");

    DelaySecs(5);

    # now wait for the inits to complete (just starting isn't enough)
    if ( 0 != CheckInitProgress($ctlr, $newVdisk ) )
    {
        logInfo("Waiting for vdisk $newVdisk to become operational");
    
        while ( 0 != ( $remaining = CheckInitProgress($ctlr, $newVdisk ) ) )
        {
            print " $remaining percent left to initialize \r";
            # pause for a second or 2
            sleep 2;
        }
    }
    
    
    # return the new vdisk number
    
    return $newVdisk;

}


##############################################################################
#
#          Name: MakeDest
#
#        Inputs: controller object
#
#       Outputs: INVALID or the new VDISK number
#
#  Globals Used: none
#
#   Description: Created Vdisks, expands, inits them    
#
#
##############################################################################
sub MakeDest
{
    trace();
    my ($ctlr, $type) = @_;
    my $ret;
    my $i;
    my $l;
    my @pddList;
    my $remaining;
    my $depth = 0;
    my $stripe = 0;
    my $parity = 0;
    my $numPDs;


    # Pick one to make
    $i = 0;                              
    if ( $type eq MULTIPLE ) {  $i = 1; }

    my $rtype =  $raidTypes[$i];

    #
    # create an array of the PDDs so we know what are working with
    #

    ######################
    # pdisk list                      # need to use only the data disks
    ######################
 
    @pddList = GetDataDisks($ctlr, FC_PREFERRED);

    if ( $pddList[0] == INVALID )
    {
        logError(">>>>>>>> Not enough drives for C/E/I/D test  <<<<<<<<");
        return (INVALID);
    }
        


    # Name:     calcRaidParms
    # Desc:     Based on the raid type passed in and how many disk we have
    #           returns the correct parameters to be used in the create vdisk
    #           packet
     

    ####################
    # calc Raid Parms
    ####################
    my $requestedBytes =  Math::BigInt->new(($space[$i]) * 2048);
#    logInfo("Space $requestedBytes");

    my $rtn = ValidateVdiskParams( \$depth, \$rtype, \$stripe, \$parity, \@pddList );

    my $str = "";


    # all parameters are ready for the call to create the vdisk
    $str .= "CAPACITY: $requestedBytes blocks  ";
    $str .= "RAID: $type  ";
    $str .= "STRIPE SIZE: $stripe  ";
    $str .= "MIRROR DEPTH: $depth  ";
    $str .= "PARITY: $parity  "; 
    $numPDs = scalar(@pddList);
    $str .= "NUMBER of PDs: $numPDs  ";   # second line
    $str .= "PD IDs:  @pddList \n";

    logInfo($str);


    if ( $rtn == INVALID )
    {
        logInfo("Parameters for creating the vdisk are invalid.");
        return INVALID;
    }




 #   my %raidParms = $ctlr->calcRaidParms(\@pddList, $raidTypes[$i]);
 #   foreach my $name (sort keys %raidParms)
 #   {
 #       logInfo("Name: $name, Value: $raidParms{$name}");
 #   }
 #
 #   my $requestedBytes =  Math::BigInt->new(((100 + $space[$i]) * 1024 * 1024 ) / 512 );
 #   logInfo("Space $requestedBytes");
 #   logInfo("Creating VD");
      
    ###############
    # VDISK create
    ###############
 #   logInfo("Creating Vdisk Raid:$raidTypes[$i], stripeSz:$raidParms{STRIPE_SIZE},");
 #   logInfo("mirrorDepth: $raidParms{MIRROR_DEPTH}, parity:$raidParms{PARITY}");
 #   logInfo("Using PDDs:@pddList");


    my $vdc = CreateSingleVdisk($ctlr, "NoName", $requestedBytes, $rtype, $stripe, $depth, $parity, \@pddList, undef);

    if ( $vdc == INVALID )
    {
        return INVALID;
    }

  #  my %rtn = $ctlr->virtualDiskCreate(   $requestedBytes,
  #                                      \@pddList,
  #                                      $raidTypes[$i],                                                                     
  #                                      $raidParms{STRIPE_SIZE},
  #                                      $raidParms{MIRROR_DEPTH},
  #                                      $raidParms{PARITY}); 
  #
  #
  #  if ( ! %rtn  )              # if no return from call
  #  {
  #      logInfo(">>>>>>>> Failed to get response from virtualDiskCreate <<<<<<<<");
  #      return INVALID;
  #  }
  #  if ( $rtn{STATUS} != PI_GOOD )      # if call returned an error
  #  {
  #      logInfo(">>>>>>>> Error from virtualDiskCreate <<<<<<<<");
  #      PrintError(%rtn);
  #      return INVALID;
  #  }

    if ( $type eq MULTIPLE  )
    {
        for( $l = 0; $l < 3; $l++)
        {

            ###############
            # VDISK expand
            ###############
  #          logInfo("Expanding Vdisk:$rtn{VID} Raid:$raidTypes[$i], stripeSz:$raidParms{STRIPE_SIZE},");
  #         logInfo("mirrorDepth: $raidParms{MIRROR_DEPTH}, parity:$raidParms{PARITY}");
  #          logInfo("Using PDDs:@pddList");
 
 
            my %info = $ctlr->virtualDiskExpand($vdc, 
                                            $requestedBytes, 
                                            \@pddList, 
                                            $rtype,
                                            $stripe,
                                            $depth,
                                            $parity,
                                            4,             # maxraids
                                            10,            # threshold
                                            0,             # flags
                                            0              # minPD
                                            );         
   #                 my %info = $ctlr->virtualDiskExpand($rtn{VID}, 
   #                                         $requestedBytes, 
   #                                         \@pddList, 
   #                                         $raidTypes[$i],
   #                                         $raidParms{STRIPE_SIZE},
   #                                         $raidParms{MIRROR_DEPTH},
   #                                         $raidParms{PARITY});


            if ( ! %info  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
                return INVALID;
            }
            if ( $info{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
                PrintError(%info);
                return INVALID;
            }

        }
    }


    #############
    # RAIDINIT
    #############
    logInfo("Now, initialize the VDD");
    $ret = InitVdiskRids($ctlr, $vdc); 
 
    if ( $ret != GOOD )
    {
        logError(">>>>>>>> Failure to initialize RAIDS <<<<<<<<");
        return INVALID;
    }
 
    

    # first, is this disk ready for use. (devstat = 0x10)
    if ( 0 != CheckInitProgress($ctlr, $vdc ) )
    {
        logInfo("Waiting for vdisk $vdc to become operational");
    
        while ( 0 != ( $remaining = CheckInitProgress($ctlr, $vdc ) ) )
        {
            print " $remaining percent left to initialize \r";
            # pause for a second or 2
            sleep 2;
        }
    }
        

    logInfo("\nRaid Init is complete. Destination vdisk is ready.");

    return $vdc;


}




##############################################################################
#
#          Name: DetermineLoopCount
#
#        Inputs: none
#
#       Outputs: number of files we can fit on the test drive 
#
#  Globals Used: $goldFileName
#
#   Description: 
#
# This function determines how many files will fit in the test vdisks
# indirectl, this is the number of loops of the file copy operation we
# use for the IO during the test.
#
###############################################################################
sub DetermineLoopCount
{
    
    my @fileInfo;

    @fileInfo = stat($goldFileName);

    print( "for file $goldFileName . . \n"); 
    #print( "    fs dev # = $fileInfo[0] \n");
    #print( "       inode = $fileInfo[1] \n");
    #print( "   file mode = $fileInfo[2] \n");
    #print( "       nlink = $fileInfo[3] \n");
    #print( "         uid = $fileInfo[4] \n");
    #print( "         gid = $fileInfo[5] \n");
    #print( "        rdev = $fileInfo[6] \n");
    print( " size(bytes) = $fileInfo[7] \n");
    #print( "       atime = $fileInfo[8] \n");
    #print( "       mtime = $fileInfo[9] \n");
    #print( "       ctime = $fileInfo[10] \n");
    #print( "     blksize = $fileInfo[11] \n");
    #print( "      blocks = $fileInfo[12] \n");


    my $allocSize;
    my $vdiskSpace;
    my $numFiles;

    # assuming 16kbyte allocation units...
    
    use integer;

    $allocSize = 16384 * (($fileInfo[7] + 16384) / 16384); 

    print( " \n");
    print( "  using size = $allocSize \n");
    
    # number of MB on a drive = $vdiskSize 
    
    $allocSize = $allocSize / 1024;            # file size in KB
    
    # disk size is reduced by 20 % to allow for some overhead in Windoze
     
    $vdiskSize = ($vdiskSize * 8) / 10;

    $vdiskSpace = ($vdiskSize - 100) * 1024;  # disk space in KB

    $numFiles = $vdiskSpace / $allocSize;  # files that fit

    print( " max # files = $numFiles \n");

    $allocSize = ( $numFiles - 107 )/2;          # approximate amount
    print( "       loops = $allocSize \n");  
    
#return 50;

    return $numFiles;
}
###############################################################################
###############################################################################
###############################################################################

=head2 PrepareVdisk function

This is a function that translates a test case number to the appropriate
action in the script. It is called once for each parameter to be 
determined.

=cut

=over 1

=item Usage:

 my $rc = Determine(TBD, $case, $parameter);
 
 where $case is the test case number and $parameter is which parameter
 to return.
       

=item Returns:

       $rc will be the parameter appropriate for the test case.

=item Description:
 
 The parameter is one of the following.
     "SOURCE"  for the source vdisk to use
     "DESTINATION" for the destination vdisk to use
     "OWNER" is the controller that will own the task
     "WAITACTIVITY" is what to do while the test is running
     
 The test case number is one of the documented values.
     1-28, 31-58 and 61-88 are already defined.
     200 is random
     all others will return invalid
     
     Note, 'random' is best handled outside this function and not by it. 

     Response to invalid test cases may be unexpected.

=back

=cut


##############################################################################
#
#          Name: PreRCValidate1
#
#        Inputs: controller object, dest vdisk, src vdisk
#
#       Outputs: Array to be qualified later 
#
#  Globals Used: none
#
#   Description: Collects the data for validation of the copy operation
#                The output is a data structure that will be checked after
#                the copy is complete 
#
##############################################################################

sub PreRCValidate1
{
    my ($ctlr, $dest, $src) = @_;

    trace();

    my %data;
    my %rsp;
    my $vd;
    my @owner1;
    my @owner2;
    my @raids1;
    my @raids2;
    my $totalRaids;
    my $i;
    my $j;
    my $msg;

    #############################
    # first the source drive
    #############################
    $vd = $src;

    $data{SRC_NUMRAIDS} = 0;

    # get the vdisk info
    %rsp = $ctlr ->virtualDiskInfo($vd);

    # extract raids to array
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>> Failed to get response from virtualDiskInfo  <<<<<");
        $data{STATUS} = ERROR;
        return %data;
    }

    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        
        if ( $rsp{ERROR_CODE} != $ctlr ->PI_ERROR_INV_VID )
        {
            # handle errors EXCEPT invalid vdisk (it is considered OK)
            logInfo(">>>>> Error from virtualDiskInfo <<<<<");
            PrintError(%rsp);
            $data{STATUS} = ERROR;
            return %data;
        }
    }
    else
    {
        # good path, display the data
        $totalRaids = $rsp{RAIDCNT} + $rsp{DRAIDCNT};
        $data{SRC_NUMRAIDS} = $totalRaids;

        #my $str =  "Raid IDs: ";
        for ($j = 0; $j < $totalRaids; $j++)
        {
            push (@raids1, $rsp{RIDS}[$j]); 

        }
    }
    
    # now do the owner and target info

    %rsp = $ctlr->virtualDiskOwner($vd);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from virtualDiskOwner  <<<<<");
        $data{STATUS} = ERROR;
        return %data;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Unable to retrieve virtual Disk Owner. <<<<<");
        PrintError(%rsp);
        $data{STATUS} = ERROR;
        return %data;
        
    }

    $data{SRC_NUMOWNERS} = $rsp{NDEVS};

    for ($i = 0; $i < $rsp{NDEVS}; $i++)
    {
        push ( @owner1, (  $rsp{OWNERS}[$i]{CHANNEL},
                            $rsp{OWNERS}[$i]{TID},
                            $rsp{OWNERS}[$i]{LUN},
                            $rsp{OWNERS}[$i]{SID}
                          ));
    }

    $data{SRC_VD} = $vd;
    $data{SRC_RAIDS} = [@raids1];
    $data{SRC_OWNERS} = [@owner1];

    #############################
    # now the destination drive
    #############################
    $vd = $dest;

    $data{DST_NUMRAIDS} = 0;

    # get the vdisk info
    %rsp = $ctlr ->virtualDiskInfo($vd);

    # extract raids to array
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>> Failed to get response from virtualDiskInfo  <<<<<");
        $data{STATUS} = ERROR;
        return %data;
    }

    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        
        if ( $rsp{ERROR_CODE} != $ctlr ->PI_ERROR_INV_VID )
        {
            # handle errors EXCEPT invalid vdisk (it is considered OK)
            logInfo(">>>>> Error from virtualDiskInfo <<<<<");
            PrintError(%rsp);
            $data{STATUS} = ERROR;
            return %data;
        }
    }
    else
    {
        # good path, display the data
        $totalRaids = $rsp{RAIDCNT} + $rsp{DRAIDCNT};
        $data{DST_NUMRAIDS} = $totalRaids;

        #my $str =  "Raid IDs: ";
        for ($j = 0; $j < $totalRaids; $j++)
        {
            push (@raids2, $rsp{RIDS}[$j]); 

        }
    }
    
    # now do the owner and target info

    %rsp = $ctlr->virtualDiskOwner($vd);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from virtualDiskOwner  <<<<<");
        $data{STATUS} = ERROR;
        return %data;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Unable to retrieve virtual Disk Owner. <<<<<");
        PrintError(%rsp);
        $data{STATUS} = ERROR;
        return %data;
        
    }

    $data{DST_NUMOWNERS} = $rsp{NDEVS};

    for ($i = 0; $i < $rsp{NDEVS}; $i++)
    {
        push ( @owner2, (  $rsp{OWNERS}[$i]{CHANNEL},
                            $rsp{OWNERS}[$i]{TID},
                            $rsp{OWNERS}[$i]{LUN},
                            $rsp{OWNERS}[$i]{SID}
                          ));
    }

    $data{DST_VD} = $vd;
    $data{DST_RAIDS} = [@raids2];
    $data{DST_OWNERS} = [@owner2];


    $data{STATUS} = GOOD;
    return %data;
} 


##############################################################################
#
#          Name: RCValidatePrint1
#
#        Inputs: controller object, dest vdisk, src vdisk, op type, orig data
#
#       Outputs:  
#
#  Globals Used: none
#
#   Description: Gets current validation data and compares it to the orig 
#                data set. THis comparision will be based upon the type of op.
#
##############################################################################

sub RCValidatePrint1
{
    my ($dPtr) = @_;
    trace();

    my %data;
    my $i;

    %data = %$dPtr;


    logInfo"      SOURCE vdd: $data{SRC_VD} \n";  
    logInfo"       num raids: $data{SRC_NUMRAIDS} \n";
      
    for ( $i = 0; $i < $data{SRC_NUMRAIDS}; $i++ )
    {
        logInfo"       raid used: $data{SRC_RAIDS}[$i] \n";
    }  
    
    logInfo"      num owners: $data{SRC_NUMOWNERS} \n";  
    
    for ( $i = 0; $i < $data{SRC_NUMOWNERS}; $i++ )
    {
        logInfo"    owner info $i:";
        logInfo"   chn: $data{SRC_OWNERS}[$i * 4 + 0],";
        logInfo"   tid: $data{SRC_OWNERS}[$i * 4 + 1],";
        logInfo"   lun: $data{SRC_OWNERS}[$i * 4 + 2],";
        logInfo"   sid: $data{SRC_OWNERS}[$i * 4 + 3] \n";
    }  
    
    logInfo"\n";
    # destination
    
    logInfo" DESTINATION vdd: $data{DST_VD} \n";  
    logInfo"       num raids: $data{DST_NUMRAIDS} \n";
      
    for ( $i = 0; $i < $data{DST_NUMRAIDS}; $i++ )
    {
        logInfo"       raid used: $data{DST_RAIDS}[$i] \n";
    }  
    
    logInfo"      num owners: $data{DST_NUMOWNERS} \n";  
    
    for ( $i = 0; $i < $data{DST_NUMOWNERS}; $i++ )
    {
        logInfo"      owner info $i:";
        logInfo"   chn: $data{DST_OWNERS}[$i * 4 + 0],";
        logInfo"   tid: $data{DST_OWNERS}[$i * 4 + 1],";
        logInfo"   lun: $data{DST_OWNERS}[$i * 4 + 2],";
        logInfo"   sid: $data{DST_OWNERS}[$i * 4 + 3] \n";
    }  
    
    logInfo"\n  status: $data{STATUS} \n";  

    logInfo"\n";

    return INVALID;
} 


##############################################################################
#
#          Name: RCValidate1
#
#        Inputs: controller object, dest vdisk, src vdisk, op type, orig data
#
#       Outputs:  
#
#  Globals Used: none
#
#   Description: Gets current validation data and compares it to the orig 
#                data set. THis comparision will be based upon the type of op.
#
##############################################################################

sub RCValidate1
{
    my ($ctlr, $dest, $src, $opType, $odPtr) = @_;

    trace();
    
    my $i;
    my $j;

    my %startCfg;
    my %endCfg;

    %startCfg = %$odPtr;   # turn pointer into hash

#    print ("Starting configuration...\n");
#    RCValidatePrint1($odPtr);

    %endCfg = PreRCValidate1($ctlr, $dest, $src,);

print ("Configuration pointers $odPtr,  %endCfg \n");

    print ("Starting configuration...\n");
    RCValidatePrint1($odPtr);

    print ("Current configuration...\n");
    RCValidatePrint1(\%endCfg);

    # now compare the two

    if ( $opType eq COPY_BREAK )
    {
        # COPY BREAK, the copy is done, connection broken
        # here, the raids don't move, copy is left laying around.
        # owners remain the same

        if ( ( $startCfg{SRC_NUMRAIDS}  ==  $endCfg{SRC_NUMRAIDS}  ) &&
             ( $startCfg{SRC_NUMOWNERS} ==  $endCfg{SRC_NUMOWNERS} ) &&
             ( $startCfg{DST_NUMRAIDS}  ==  $endCfg{DST_NUMRAIDS}  ) &&
             ( $startCfg{DST_NUMOWNERS} ==  $endCfg{DST_NUMOWNERS} ) 
           )
        {
            
            # verify the destination raids match
            for ( $i = 0; $i < $startCfg{DST_NUMRAIDS}; $i++ )
            {
                if ( $startCfg{DST_RAIDS}[$i] != $endCfg{DST_RAIDS}[$i] )
                {
                    logInfo ( " Destination RAIDs did not match ".
                    "   $startCfg{DST_RAIDS}[$i] != $endCfg{DST_RAIDS}[$i]");
                    return ERROR;
                }
            } 
                
            # verify the source raids match
            for ( $i = 0; $i < $startCfg{SRC_NUMRAIDS}; $i++ )
            {
                if ( $startCfg{SRC_RAIDS}[$i] != $endCfg{SRC_RAIDS}[$i] )
                {
                    logInfo ( " Source RAIDs did not match ".
                    "   $startCfg{SRC_RAIDS}[$i] != $endCfg{SRC_RAIDS}[$i]");
                    return ERROR;
                }
            }     
        
            # verify the source owners match
            for ( $i = 0; $i < $startCfg{SRC_NUMOWNERS}; $i++ )
            {
                if ( ( $startCfg{SRC_OWNERS}[$i * 4 + 0] != $endCfg{SRC_OWNERS}[$i * 4 + 0] )  ||  # channel 
                     ( $startCfg{SRC_OWNERS}[$i * 4 + 1] != $endCfg{SRC_OWNERS}[$i * 4 + 1] )  ||  # tid
                     ( $startCfg{SRC_OWNERS}[$i * 4 + 2] != $endCfg{SRC_OWNERS}[$i * 4 + 2] )  ||  # lun
                     ( $startCfg{SRC_OWNERS}[$i * 4 + 3] != $endCfg{SRC_OWNERS}[$i * 4 + 3] )      # sid
                )
                {
                    logInfo ( " Source owner information did not match ");
                    return ERROR;
                }
            }     
        
            # verify no destination owners

            if ( ( $startCfg{DST_NUMOWNERS} != 0 )  || 
                 ( $startCfg{DST_NUMOWNERS} != 0 ) 
            )
            {
                logInfo ("The destination vdisk incorrectly had an owner ");
                return ERROR;
            }
                 
        }


    }
    elsif (  $opType eq COPY_CONTINUOUS )
    {
        # COPY MIRROR, the copy is done, updates to src are mirrored
        # on dest. Dest is not associated.
        # owners don't change

        if ( ( $startCfg{SRC_NUMRAIDS}  ==  $endCfg{SRC_NUMRAIDS}  ) &&
             ( $startCfg{SRC_NUMOWNERS} ==  $endCfg{SRC_NUMOWNERS} ) &&
             ( $startCfg{DST_NUMRAIDS}  ==  $endCfg{DST_NUMRAIDS}  ) &&
             ( $startCfg{DST_NUMOWNERS} ==  $endCfg{DST_NUMOWNERS} ) 
           )
        {
            
            # verify the destination raids match
            for ( $i = 0; $i < $startCfg{DST_NUMRAIDS}; $i++ )
            {
                if ( $startCfg{DST_RAIDS}[$i] != $endCfg{DST_RAIDS}[$i] )
                {
                    logInfo ( " Destination RAIDs did not match ".
                    "   $startCfg{DST_RAIDS}[$i] != $endCfg{DST_RAIDS}[$i]");
                    return ERROR;
                }
            } 
                
            # verify the source raids match
            for ( $i = 0; $i < $startCfg{SRC_NUMRAIDS}; $i++ )
            {
                if ( $startCfg{SRC_RAIDS}[$i] != $endCfg{SRC_RAIDS}[$i] )
                {
                    logInfo ( " Source RAIDs did not match ".
                    "   $startCfg{SRC_RAIDS}[$i] != $endCfg{SRC_RAIDS}[$i]");
                    return ERROR;
                }
            }     
        
            # verify the source owners match
            for ( $i = 0; $i < $startCfg{SRC_NUMOWNERS}; $i++ )
            {
                if ( ( $startCfg{SRC_OWNERS}[$i * 4 + 0] != $endCfg{SRC_OWNERS}[$i * 4 + 0] )  ||  # channel 
                     ( $startCfg{SRC_OWNERS}[$i * 4 + 1] != $endCfg{SRC_OWNERS}[$i * 4 + 1] )  ||  # tid
                     ( $startCfg{SRC_OWNERS}[$i * 4 + 2] != $endCfg{SRC_OWNERS}[$i * 4 + 2] )  ||  # lun
                     ( $startCfg{SRC_OWNERS}[$i * 4 + 3] != $endCfg{SRC_OWNERS}[$i * 4 + 3] )      # sid
                )
                {
                    logInfo ( " Source owner information did not match ");
                    return ERROR;
                }
            }     
        
            # verify no destination owners

            if ( ( $startCfg{DST_NUMOWNERS} != 0 )  || 
                 ( $startCfg{DST_NUMOWNERS} != 0 ) 
            )
            {
                logInfo ("The destination vdisk incorrectly had an owner ");
                return ERROR;
            }
                 
        }




    } 
    elsif  ($opType eq COPY_SWAP )
    {
        # COPY SWAP, the copy is done and the raids hev been swapped
        # source raids are unassociated
        # owners don't change

        if ( ( $startCfg{SRC_NUMRAIDS}  ==  $endCfg{DST_NUMRAIDS}  ) &&
             ( $startCfg{SRC_NUMOWNERS} ==  $endCfg{SRC_NUMOWNERS} ) &&
             ( $startCfg{DST_NUMRAIDS}  ==  $endCfg{SRC_NUMRAIDS}  ) &&
             ( $startCfg{DST_NUMOWNERS} ==  $endCfg{DST_NUMOWNERS} ) 
           )
        {
            
            # verify the destination raids match
            for ( $i = 0; $i < $startCfg{DST_NUMRAIDS}; $i++ )
            {
                if ( $startCfg{DST_RAIDS}[$i] != $endCfg{SRC_RAIDS}[$i] )
                {
                    logInfo ( " The RAIDs did not swap ".
                    "   $startCfg{DST_RAIDS}[$i] != $endCfg{SRC_RAIDS}[$i]");
                    return ERROR;
                }
            } 
                
            # verify the source raids match
            for ( $i = 0; $i < $startCfg{SRC_NUMRAIDS}; $i++ )
            {
                if ( $startCfg{SRC_RAIDS}[$i] != $endCfg{DST_RAIDS}[$i] )
                {
                    logInfo ( " The RAIDs did not swap  ".
                    "   $startCfg{SRC_RAIDS}[$i] != $endCfg{SRC_RAIDS}[$i]");
                    return ERROR;
                }
            }     
        
            # verify the source owners match
            for ( $i = 0; $i < $startCfg{SRC_NUMOWNERS}; $i++ )
            {
                if ( ( $startCfg{SRC_OWNERS}[$i * 4 + 0] != $endCfg{SRC_OWNERS}[$i * 4 + 0] )  ||  # channel 
                     ( $startCfg{SRC_OWNERS}[$i * 4 + 1] != $endCfg{SRC_OWNERS}[$i * 4 + 1] )  ||  # tid
                     ( $startCfg{SRC_OWNERS}[$i * 4 + 2] != $endCfg{SRC_OWNERS}[$i * 4 + 2] )  ||  # lun
                     ( $startCfg{SRC_OWNERS}[$i * 4 + 3] != $endCfg{SRC_OWNERS}[$i * 4 + 3] )      # sid
                )
                {
                    logInfo ( " Source owner information did not match ");
                    return ERROR;
                }
            }     
        
            # verify no destination owners

            if ( ( $startCfg{DST_NUMOWNERS} != 0 )  || 
                 ( $startCfg{DST_NUMOWNERS} != 0 ) 
            )
            {
                logInfo ("The destination vdisk incorrectly had an owner ");
                return ERROR;
            }
                 
        }


    }
    else
    {
        # it wasn't one of the valid choices
        return INVALID;
    }

    logInfo ("The ending configuration was 'as expected'. ");

    return GOOD;            # INVALID for debug, change when done
} 

##############################################################################
#
#          Name: PrepareVdisk
#
#        Inputs: 
#
#       Outputs:  
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################

sub PrepareVdisk
{
    trace();
    return INVALID;
} 



##############################################################################
#
#          Name: GetDrvID
#
#        Inputs: pointer to map, owner, pointer to drive owner map
#
#       Outputs: map entry that is owned by the specified owner
#
#  Globals Used: none
#
#   Description: This function is will return the map entry that is owned by   
#                the specified owner.  If the initial map passed in is the 
#                drive cfg map, the function will return the VID of the drive 
#                that is owned by the specified owner.  If the initial map 
#                is the drive letter pool, the function will return the drive 
#                letter of the drive that is owned by the specified owner.
#
##############################################################################

sub GetDrvID
{
    trace();
    my ( $mapPtr, $owner, $ownerMapPtr ) = @_;

    my $i;
    my @map = @$mapPtr;
    my @ownerMap = @$ownerMapPtr;

    #
    # Find the index of the specified owner in the owner map.
    # Then return the corresponding item in the map.
    #
    for ($i = 0; $i < scalar(@ownerMap); ++$i)
    {
        if ( $ownerMap[$i] == $owner )
        {
            #
            # We found the owner.  Now return the corresponding entry in map.
            #
            return $map[$i];
        }
    }

    #
    # If we got here, something is wrong.  Did not find a matching owner.
    #
    logInfo(">>>>> No entry found in the owner map for owner $owner. <<<<<");
    logInfo("Owner:  $owner     Owner map:  @ownerMap");
    return ERROR; 
    
}

###############################################################################



###############################################################################



###############################################################################

=head2 WaitLoop function

This function watches the progress of the copy. It also provides the 
IO load while the copy is in process. IO is done using write, read, and 
copmare operations on a set of data files.

=cut

=over 1

=item Usage:

 my $rc = Determine( $coPtr. $master, $other, $activity, 
                                    $special, $numFiles, $testDrive));
 
 where $coPtr is a pointer ot comtroller objects
       $master is the owner of the task at the start
       $activity is a flage for pause/resume and owner chaange options
       $special is a flag for the abort options
       $numFiles is the maximum number of test files to use
       $testDrive is the drive letter to use       

=item Returns:

       three counts reflecting the number of files written

=item Description:
 
 The parameter is one of the following.
     "SOURCE"  for the source vdisk to use
     "DESTINATION" for the destination vdisk to use
     "OWNER" is the controller that will own the task
     "WAITACTIVITY" is what to do while the test is running
     
 The test case number is one of the documented values.
     1-28, 31-58 and 61-88 are already defined.
     200 is random
     all others will return invalid
     
     Note, 'random' is best handled outside this function and not by it. 

     Response to invalid test cases may be unexpected.

=back

=cut


##############################################################################
#
#          Name: WaitLoop
#
#        Inputs: $ctlr1, $ctlr2, $activity, $special, $numFiles, $testDrive
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: file names, currentOwner
#
#   Description: Loop while waiting for the copy to complete. The objective
#                here is to provide a lot of IO activity and also to perform
#                the 'stresses' that may be applied while the copy runs. For
#                the most part, this is copies and compares on the disk drive.
#
#                
#
##############################################################################

sub WaitLoop
{
    my ( $coPtr, $master, $other, $activity, $special, $numFiles, $testDrive, $vdisk) = @_;

    my $i;
    trace();

    my $progress;
    my $fileCount = 0;
    my $fyleCount = 0;
    my $overCount = 0;
    my $j;
    my $k;
    my $l;
    my $ret;
    my $ctlr1;
    my $ctlr2;
    my @coList;

    @coList = @$coPtr;
    $ctlr1 = $coList[$master];       # this is the copy owner
    $ctlr2 = $coList[$other];


print "     DEBUG: wait for the copy to complete     while = $activity, special = $special, \n";
print "            numFiles = $numFiles, testDrive = $testDrive, while = $activity, special = $special \n";

#return (GOOD, 0, 0);

    logInfo("Giving RediCopy a chance to start ");

    ###########################
    # initial progress check 
    ###########################
    
    # are we there yet?
    
    do 
    {
        $progress = CopyProgress( $ctlr1, $vdisk );
        sleep(1);
    } while ( $progress == 0 );
        

    
    ###########################
    # loop while copy executes
    ###########################
    
    # if not done
    while ( ( $progress > 0 ) && ( $progress < 100 ) )
    {
        # increment file name
        $fileCount++;

# since everything is commented out....
#sleep(1);  # slow things down


        ###################################
        # copy data files on source drive
        ###################################
        
        # copy silver to named file
        $ret = CopyFiles($testDrive.$silverFileNameEnd, 
                         $testDrive.$testFileStart.$fileCount.$testFileEnd  );
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> We failed to copy a file <<<<<<<<");
            return (INVALID, 0, 0);
        }


        ###########################
        # check/do wait condition
        ###########################

        $ret = CheckWait ( $coPtr, $master, $other, $activity, $special );
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Some error during our wait activity <<<<<<<<");
            return (ERROR, 0, 0);
        }


        #####################################
        # do some of the second set of files
        #####################################

        # if filenamecount > FILEDELAY 
        if (  $fileCount > FILEDELAY )
        {
            # incr 2nd filename count
            $fyleCount++;

            # copy file[n-100] to fyle[n]
            $k =  $fileCount - FILEDELAY;
            $ret = CopyFiles($testDrive.$testFileStart.$k.$testFileEnd, 
                             $testDrive.$testFyleStart.$fyleCount.$testFileEnd  );
            if ($ret != GOOD)
            {
                logInfo(">>>>>>>> We failed to copy a scratch file <<<<<<<<");
                return (INVALID, 0, 0);
            }


            # compare file[n-100] to silver
            $ret = CompareFiles($testDrive.$silverFileNameEnd,
                                $testDrive.$testFileStart.$k.$testFileEnd  );
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> Miscompare while the RediCopy is in progress (~ $progress % done) <<<<<<<<");
                return (INVALID, 0, 0);
            }
        }

        ################################
        # may need to do some compares
        ################################

        # if # files approaches numFiles
        if ( ( $fyleCount + $fileCount ) >= $numFiles )
        {
         
            # compare each file to silver
            for ( $k = 1; $k <= $fileCount; $k++ )
            {
                $ret = CompareFiles($testDrive.$silverFileNameEnd,
                                    $testDrive.$testFileStart.$k.$testFileEnd  );
                if ( $ret == ERROR )
                {
                    logInfo(">>>>>>>> Miscompare while the RediCopy is in progress (~ $progress % done) <<<<<<<<");
                    logInfo("         Miscompare was while checking a full vdisk ");
                    return (INVALID, 0, 0);
                }
            }
                
            # compare each fyle to silver
            for ( $k = 1; $k <= $fyleCount; $k++ )
            {
                $ret = CompareFiles($testDrive.$silverFileNameEnd,
                                    $testDrive.$testFyleStart.$k.$testFileEnd  );
                if ( $ret == ERROR )
                {
                    logInfo(">>>>>>>> Miscompare while the RediCopy is in progress (~ $progress % done) <<<<<<<<");
                    logInfo("         Miscompare was while checking a full vdisk ");
                    return (INVALID, 0, 0);
                }
            }

            # reset file counters, increment overflow count
            $fyleCount = 0;
            $fileCount = 0;
            $overCount++;

            # now go back and do it over, this time, overwriting the files
        }
        
        #############################
        # update progress indication 
        #############################

        # update progress to see if we do it again  
        $progress = CopyProgress( $coList[$currentOwner], $vdisk  );
              
    }   # end of while  (progress)

    logInfo ("");

    CtlrLogText($coList[$currentOwner], "Copy operation complete, dest = $vdisk ");

    print("\nEnd of Wait Loop function\n");

    return(GOOD, 0, $fyleCount);


} 

            

    
    




##############################################################################
#
#          Name: CheckWait
#
#        Inputs:  object list point, owner index, other index, activity 
#                 and special flags
#
#       Outputs: a parameter for the test 
#
#  Globals Used: current owner, current state 
#
#   Description:
#
# This is the 'other' activity done while the copy progresses
# we can,
#         move the vdisks to another controller
#         pause and resume the copy
#         abort the copy
# either singly or do multiple things.
##############################################################################
sub CheckWait
{
    my ( $coPtr, $owner, $other, $activity, $special ) = @_;
    
    trace();

#print("     DEBUG: checkWait      activity = $activity, special = $special \n");


    if ( ($special eq 0) && ($activity eq 0) )
    {
        # no aborts to do
        # no pauses or owner changes to do
        return GOOD;
    }


    # there needs to be some random consideration here
    # we don't do this every time through the loop

    if ( $special != 0 )
    {
        # add code here
    }

    if ( $activity != 0 )
    {
        # add code here
    }
    

    return GOOD;
}

##############################################################################
##############################################################################
#
#          Name: MapDrives
#
#        Inputs: vdList pointer, drive letter pointer
#
#       Outputs: the list of VDDs that match the drive letters 
#
#  Globals Used: none
#
#   Description:  Map System
#
# finds the mapping between the vdisks and the server drive letters
# (windows specific code follows)
#
##############################################################################
sub MapDrives
{
    trace();
    my ($ctlr,  $dlPtr) = @_;

    my %initial;

    my @vdList;
    my @dList;
    my @actives;
    my @map;

    my $drv;
    my $ret;
    my $i;
    my $msg;

    @dList = @$dlPtr;                # the drives letters to match

    # this has to return a list/map of the vdisks' drive letters. This is done by
    # writing to a drive letter and then seeing which vdisks accrued some activity.
    
    logInfo("");
    logInfo("(Mapping drive letters to vdisks, some error messages may be seen)");

    # for each drive letter
    for ($i = 0; $i < scalar( @dList ); $i++)
    {
        $drv = $dList[$i];
    
        print " testing drive $drv \n";

        # Get vdisk activity counts
        %initial = RCPControllerActiveVdiskListPart1($ctlr, "V");
    
        # create the test directory
        $ret = system("mkdir", $drv.$testDir);
        if ($ret != 0 )
        {
            logInfo("Creating test directory returned $ret . ");
            #next;
        }
        # copy the gold file to the silver file
        $ret = CopyFiles( $goldFileName, $drv.$silverFileNameEnd );
        if ($ret != 0 )
        {
            logInfo("Copying silver file returned $ret . ");
            next;
        }
        
        logInfo("");       # for screen appearance

        # get activity/find active vdisk
        DelaySecs(40);

        @actives = RCPControllerActiveVdiskListPart2($ctlr, \%initial, 1, 20, "V");

        if ( scalar(@actives) != 1 )
        {
            $msg = " The following drives were active, @actives, only a single active drive is allowed.";
            $map[$i] = INVALID;
        }
        elsif ( INVALID == $actives[0] )
        {
            $msg = " The active vdisk list was invalid, cannot continue.";
            $map[$i] = INVALID;
        }
        else
        {
            $msg = " Drive letter $drv maps to vdisk $actives[0].";
            $map[$i] = $actives[0];
        }
        logInfo($msg);
    }

    logInfo("Mapping drive letters is complete");
    logInfo ("");

    return @map;

}

##############################################################################
#
#          Name: MapOwners
#
#        Inputs: ctlr list pointer, drvCfgMap
#
#       Outputs: the list of controller indexes of the owners that match 
#                the vdisks in drvCfgMap 
#
#  Globals Used: none
#
#   Description: Finds the controllers that own each of the vdisks in
#                in drvCfgMap and returns an array of the indices of each 
#                controller corresponding to each vdisk in drvCfgMap  
#
#
##############################################################################
sub MapOwners
{
    trace();
    my ($coPtr,  $vdiskListPtr) = @_;

    my @coList = @$coPtr;
    my @vdiskList = @$vdiskListPtr;

    my $master;
    my $ctlr;
    my %info;
    my $i;
    my $idx;
    my $targ;
    my $j;
    my $k;
    my @ownerList;
    my $foundit;
    my @serialNumberList;

    #
    # Find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        logInfo(">>>>> Failed to find master <<<<<");
        $ownerList[0] = INVALID;
        return @ownerList;  
    }
    $ctlr = $coList[$master];

    # 
    # build an array of serial numbers
    #
    
    my @snList;
    
    for ($i = 0; $i < scalar(@coList); $i++)
    {
        push(@snList, $coList[$i]->{SERIAL_NUM});
    }    

    #
    # For each vdisk in vdiskList, go thru the server info and find 
    # the serial number of the controller that owns each vdisk
    #
    for ($i = 0; $i < scalar(@vdiskList); ++$i)
    {

        ($idx, $targ) = FindVdiskOwner($coPtr, \@snList, $vdiskList[$i]);
        
        if ($idx == INVALID)
        {
            logInfo(">>>>>>>>> Unable to map vdisk to an owner. <<<<<<<<");
            $ownerList[0] = INVALID;
            return @ownerList;  
        }
        else
        {
            $ownerList[$i] = $idx;
            logInfo("Vdisk $vdiskList[$i] is owned by controller ".
                    "$ownerList[$i] ( $coList[$idx]->{HOST} )");
        
        }

    }
    
    #
    # $ownerList now contains the index of the controller that owns each 
    # vdisk in the vdiskList passed in.
    #
    return @ownerList;  
}



###############################################################################

=head2 MoveVdisks function

This is a function that translates a test case number to the appropriate
action in the script. It is called once for each parameter to be 
determined.

=cut

=over 1

=item Usage:

 my $rc = Determine(TBD, $case, $parameter);
 
 where $case is the test case number and $parameter is which parameter
 to return.
       

=item Returns:

       $rc will be the parameter appropriate for the test case.

=item Description:
 
 The parameter is one of the following.
     "SOURCE"  for the source vdisk to use
     "DESTINATION" for the destination vdisk to use
     "OWNER" is the controller that will own the task
     "WAITACTIVITY" is what to do while the test is running
     
 The test case number is one of the documented values.
     1-28, 31-58 and 61-88 are already defined.
     200 is random
     all others will return invalid
     
     Note, 'random' is best handled outside this function and not by it. 

     Response to invalid test cases may be unexpected.

=back

=cut


##############################################################################
#
#          Name: MoveVdisks
#
#        Inputs: 
#
#       Outputs:  
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################

sub MoveVdisks
{
    trace();
    return INVALID;
} 



###############################################################################

=head2 CleanDst function

This is a function that translates a test case number to the appropriate
action in the script. It is called once for each parameter to be 
determined.

=cut

=over 1

=item Usage:

 my $rc = Determine(TBD, $case, $parameter);
 
 where $case is the test case number and $parameter is which parameter
 to return.
       

=item Returns:

       $rc will be the parameter appropriate for the test case.

=item Description:
 
 The parameter is one of the following.
     "SOURCE"  for the source vdisk to use
     "DESTINATION" for the destination vdisk to use
     "OWNER" is the controller that will own the task
     "WAITACTIVITY" is what to do while the test is running
     
 The test case number is one of the documented values.
     1-28, 31-58 and 61-88 are already defined.
     200 is random
     all others will return invalid
     
     Note, 'random' is best handled outside this function and not by it. 

     Response to invalid test cases may be unexpected.

=back

=cut


##############################################################################
#
#          Name: CleanDst
#
#        Inputs: 
#
#       Outputs:  
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################

sub CleanDst
{
    trace();
    return INVALID;
} 



###############################################################################

=head2 PrepareVdiskContents function

This is a function that translates a test case number to the appropriate
action in the script. It is called once for each parameter to be 
determined.

=cut

=over 1

=item Usage:

 my $rc = Determine(TBD, $case, $parameter);
 
 where $case is the test case number and $parameter is which parameter
 to return.
       

=item Returns:

       $rc will be the parameter appropriate for the test case.

=item Description:
 
 The parameter is one of the following.
     "SOURCE"  for the source vdisk to use
     "DESTINATION" for the destination vdisk to use
     "OWNER" is the controller that will own the task
     "WAITACTIVITY" is what to do while the test is running
     
 The test case number is one of the documented values.
     1-28, 31-58 and 61-88 are already defined.
     200 is random
     all others will return invalid
     
     Note, 'random' is best handled outside this function and not by it. 

     Response to invalid test cases may be unexpected.

=back

=cut


##############################################################################
#
#          Name: PrepareVdiskContents
#
#        Inputs:  
#
#       Outputs:   
#
#  Globals Used: none
#
#   Description: 
#
##############################################################################

sub PrepareVdiskContents
{
    trace();
    return INVALID;
} 







1;   # we need this for a PM

__END__

#################################################################

=head1 CHANGELOG

 $Log$
 Revision 1.2  2005/06/01 19:21:49  PalmiD
 TBolt00000000: Added code to capture global cache state, disable global cache until
 drives are mapped and restore cache to original state prior to test.  General cleanup.
 Reviewed by Craig Menning.

 Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
 import CT1_BR to shared/Wookiee

 Revision 1.14  2004/12/08 16:35:35  KohlmeyerA
 Tbolt00000000:  Updated for RediCopyTest to handle full WWNs and work without using the
 move vdisks command that is no supported.
 Reviewed by Craig.

 Revision 1.13  2004/04/15 18:50:08  KohlmeyerA
 Tbolt00000000 - Added additional parm to GetDataDisks calls due to changes for SATA.  Reviewed by Craig

 Revision 1.12  2003/08/29 18:45:11  MenningC
 tbolt00000000: numerous changes to vdisk creation to ensure the correct raid parameters are used. reviewed by Olga

 Revision 1.11  2003/03/26 21:24:53  WerningJ
 Removed calls to unused modules
 Reviewed by Craig M

 Revision 1.10  2003/01/14 15:26:39  MenningC
 Tbolt00000000: Changes to support BEUtils lib, removed UMC. Reveiewed by J Werning.

 Revision 1.9  2003/01/04 14:56:44  WerningJ
 Increased time to wait for VDisk activity
 Reviewed by Craig M

 Revision 1.8  2002/12/26 20:14:54  MenningC
 Tbolt00000000: fixes for defrag case 3 and redicp, reviewed by Jeff Werning

 Revision 1.7  2002/12/24 15:41:28  MenningC
 Tbolt00000000: increased delay in MapDrives, reviewed by Max.

 Revision 1.6  2002/12/23 15:15:39  MenningC
 Tbolt00000000: Fixed problems with serverdis command. reviewed by J W

 Revision 1.5  2002/11/22 14:25:05  MenningC
 tbolt00000000: check/compare the fyles, fix no suicide bit. reviewed by J Werning

 Revision 1.4  2002/11/20 17:21:29  MenningC
 TBOLT00000000: more defrag and redicp changes,
  reviewed by J. Werning

 Revision 1.3  2002/11/19 21:41:18  MenningC
 tbolt00000000: Updates to redicp, defrag and ctlrgrabber. Reviewed by Olga

 Revision 1.2  2002/11/19 16:29:32  MenningC
 tbolt00000000: Updates to redicp, defrag and ctlrgrabber. Reviewed by Olga

 Revision 1.1  2002/09/25 14:55:47  MenningC
 TBOLT00000000 new file; reviewed by Werning



=cut


