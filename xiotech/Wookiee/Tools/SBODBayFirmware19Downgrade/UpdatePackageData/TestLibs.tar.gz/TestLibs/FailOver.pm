#! /usr/bin/perl 
# $Header$
##############################################################################
# File name:  TestLibs::FailOver
#
# Desc: A set of library functions for integration testing. These focus on
#       controller fail-over algorithms.
#
# Date: 07/26/2002
#
# Original Author:  Craig Menning
#
# Last modified by  $Author: nick_elvester $
# Modified date     $Date: 2007-04-02 10:24:42 -0500 (Mon, 02 Apr 2007) $
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002-2003 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::FailOver - Perl Tests to Fail Over XIOtech Storage Devices

$Id: FailOver.pm 21617 2007-04-02 15:24:42Z nick_elvester $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document describes the Perl Scripts to Test Controller 
Fail-over. This library is a collection of functions for fail-over testing.

=head1 DESCRIPTION

Test Functions Available (exported)

         FailOverController()
         FailOverLoop()
         GetFailMethod()
         VcgFailRandom()
         SurvivorLoop()

=cut

#                         
# - what I am
#

package TestLibs::FailOver;

#
# - other modules used
#

use warnings;
use lib "../CCBE";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use TestLibs::Logging;
use TestLibs::Constants;
#use XIOTech::sanscript;
use TestLibs::Validate;
use TestLibs::IntegCCBELib;
#use TestLibs::IntegXMCLib;
use TestLibs::BEUtils;
use TestLibs::FailOverSupport;
use TestLibs::WrtCacheSupport;
#use TestLibs::ErrorInjection;
use TestLibs::utility;
use TestLibs::Fibre;
use Dumpvalue;
my $dumper = new Dumpvalue;
my $dumper2 = new Dumpvalue;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      
                      &BrocadeLoop
                      &BrocadeLooper

                      &DownFELoopLong
                      &DownFELoopTempRepeat
                           
                      &FailOverLoop
                      &FailOverNWayLoop

                      &HoldFEQLogicReset

                      &MoveTarget
                      &MvTgtLoop
                        
                      &PowerOneWayMate

                      &SurvivorLoop
                      
                      &VcgFailRandom
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 21617 $);
}
    our @EXPORT_OK;


###############################################################################

=head2 FailOverLoop function


This loop is common to many of the fail-over tests. Here is a short 
outline of the test. This reflects Aug. 6, 2002 code. 
As the code evolves, there may be changes.


=cut

=over 1

=item Usage:

 my $rc = FailOverLoop($coPtr, $moxaIP, $moxaPtr, $failType, $loopCount );
 
 where $coPtr is a pointer to a controller object list
       $moxaIP is the IP address for the Moxa power controller
       $moxaPtr is a pointer to the list of used Moax chennels
               ( the order must match the $coPtr list )
       $failType is desired failure method
       $loopCount is the number of loops to do. Default = 2000

       

=item Returns:

       $rc will be GOOD if all tests pass or INVALID or ERROR if failed

=item Description:
 


 FailOverLoop:
    Collect initial server activity information (active servers and vdisks, target map)
    Repeat for the desired number of loops (default is 2000 )
        Find the master controller
        Repeat for each non-master controller
            Determine how to fail
            Fail the controller
            Pause 120 seconds (to allow failover)
            Check for proper VCG operation (described below)
            Power cycle the controller
            Re-connect to the controller (60 second initial delay)
            Wait for boot to really complete (based on power up state)
            Find current master
            Un-fail the controller
            Pause for 120 seconds
            Check for proper VCG operation
        Check for proper VCG operation
        (the following are on the original master)
        Determine how to fail
        Fail the controller
        Pause 120 seconds (to allow failover)
        Check for proper VCG operation (described below)
        Power cycle the controller
        Re-connect to the controller (60 second initial delay)
        Wait for boot to really complete (based on power up state)
        Find current master
        Un-fail the controller
        Pause for 120 seconds
        Check for proper VCG operation

 The failure method is a user parameter and is one of the following.

 BEET - back end processor error trap
 FEET - front end processor error trap
 CCBET - CCB processor error trap
 RET - random processor error trap
 PC - power off the controller
 FC - fail using mrp command
 RND - random one of  BEET, FEET, CCBET, PC (this list may change)



=back

=cut


############# Target failover constants used in DownFELoop functions ###########

use constant    FAIL => 0;
use constant    UNFAIL => 1;
use constant    CONSTA0 => 1;
use constant    CONSTA1 => 2;
use constant    CONSTA2 => 4;
use constant    CONSTA3 => 8;
use constant    CONSTB0 => 16;
use constant    CONSTB1 => 32;
use constant    CONSTB2 => 64;
use constant    CONSTB3 => 128;
use constant    CONSTA => 256;
use constant    CONSTB => 512;
use constant    ALLCTRLS => 1024;
use constant    ENDCTRLS => 2048;
use constant    ENDSTEPS => 4096;

################################################################################
 

######################## Private Functions For DownFELoop functions ############
 
sub _MyIndex
{
    my ($iface) = @_ ;
    my @ifaceindex = (CONSTA0, CONSTA1, CONSTA2, CONSTA3, CONSTB0, CONSTB1, CONSTB2, CONSTB3, CONSTA, CONSTB);
    my $i;
    for ( $i = 0; $i < scalar(@ifaceindex); $i++ )
    {
        if ($ifaceindex[$i] == $iface)
        {
            
            return $i ;
        }
    }
    # just return off the end of the list.  The other side must check for this.
    return $i+1;
}

sub _MyPrintStep
{
    my ($Operation) = @_ ;
    my $msg ;

    if ($Operation == FAIL)
    {
        $msg = "FAIL " ;
    }
    elsif ($Operation == UNFAIL)
    {
        $msg = "UNFAIL " ;
    }
    logInfo($msg) ;
    return GOOD ;
}


##############################################################################

################################################################################




##############################################################################
#
#          Name: DownFELoopTempRepeat
#
#        Inputs: array of connected controller objects, array of brocade
#                switch IP's, map of ports to use for each switch, the number
#                of controllers in the controller array, the number of loops to
#                do. 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Downs the FE Loop for less than 10 seconds repeatedly.  A
#                failure is expected to occur.
#
##############################################################################
sub DownFELoopTempRepeat
{
    my ($coPtr, $brocadeIP, $brocadePtr, $numCtrls, $loopCount, $curTestParmHashPtr, $quiet ) = @_;
    my $TestSteps ;
    my $Operation ;
    my $iface ;
    my $Results ;
    my $altFail ;
    my $altFailMap ;
    my $ret ;
    my $i;
    my $j;
    my $k;
    my $l;
    my $t;
    my $currentIP;
    my @serialNums ;
    my @ifacesn;
    my @relativeiface ;
    my $index;
    my @map ;


    ########################################
    # You must also have the Net::Telnet   #
    # library. This file is in the release #
    # directory (  \Test\PerlLibs\Net  )   #
    # and can be copied to your perl       #
    # directory ( C:\Perl\site\lib\Net )   #
    ########################################
       
#    use Net::Telnet ();

    $TestSteps = [  [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #0
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #1
                    [FAIL, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #2
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #3
                    [FAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #4
                    [FAIL, CONSTA2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #5
                    [FAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],  #6
                    [UNFAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],#7
                    [FAIL, CONSTA3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #8
                    [FAIL, CONSTB2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #9
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #10
                    [FAIL, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #11
                    [UNFAIL, CONSTA3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #12
                    [FAIL, CONSTA2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #13
                    [UNFAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #14
                    [FAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #15
                    [UNFAIL, CONSTA2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #16
                    [FAIL, CONSTA3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #17
                    [UNFAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #18
                    [FAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #19
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #20
                    [FAIL, CONSTB3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #21
                    [FAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #22
                    [UNFAIL, CONSTB0, CONSTB1, CONSTB2, CONSTB3, ENDCTRLS, 0, 0, 0],#23
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #24
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #25
                    [UNFAIL, CONSTA0, CONSTA1, CONSTA3, ENDCTRLS, 0, 0, 0, 0],      #26
                    [FAIL, CONSTB0, CONSTB1, CONSTB2, CONSTB3, ENDCTRLS, 0, 0, 0],  #27
                    [UNFAIL, CONSTB0, CONSTB1, CONSTB2, CONSTB3, ENDCTRLS, 0, 0, 0],#28
                    [FAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],  #29
                    [UNFAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],#30
                    [ENDSTEPS,0,0,0,0,0,0,0,0]
            ];
    $Results = [    [CONSTA1,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #0   11111110
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #1	 11111111
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #2	 11111101
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #3	 11111100
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #4	 11101100
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #5	 11101000
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #6	 11100000
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #7	 11101111
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #8	 11100111
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #9 	 10100111
                    [CONSTA1,CONSTA1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #10	 10100110
                    [CONSTB1,CONSTB1,CONSTB3,CONSTB3,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #11	 10100100
                    [CONSTB1,CONSTB1,CONSTB3,CONSTB3,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #12	 10101100
                    [CONSTB1,CONSTB1,CONSTB3,CONSTB3,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #13	 10101000
                    [CONSTB0,CONSTB1,CONSTB3,CONSTB3,CONSTB0,CONSTB1,CONSTB3,CONSTB3],                  #14	 10111000
                    [CONSTB0,CONSTB0,CONSTB3,CONSTB3,CONSTB0,CONSTB0,CONSTB3,CONSTB3],                  #15	 10011000
                    [CONSTB0,CONSTB0,CONSTB3,CONSTB3,CONSTB0,CONSTB0,CONSTB3,CONSTB3],                  #16	 10011100
                    [CONSTB0,CONSTB0,CONSTB3,CONSTB3,CONSTB0,CONSTB0,CONSTB3,CONSTB3],                  #17	 10010100
                    [CONSTB0,CONSTB1,CONSTB3,CONSTB3,CONSTB0,CONSTB1,CONSTB3,CONSTB3],                  #18	 10110100
                    [CONSTB1,CONSTB1,CONSTB3,CONSTB3,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #19	 10100100
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #20	 10100101
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTA0,CONSTA0,CONSTA2,CONSTA2],                  #21	 00100101
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTA0,CONSTA0,CONSTA2,CONSTA2],                  #22	 00000101
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #23	 11110101
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #24	 11110101
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #25	 11110100
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #26	 11111111
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTA0,CONSTA1,CONSTA2,CONSTA3],                  #27	 00001111
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #28	 11111111
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #29	 11110000
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3]                   #30	 11111111
               ] ;

    # no doubt this is more complicated than I want.
    # there are a couple of places where things do not have to move where you expect them to.
    # luck of the draw sort of thing.  So we need to plan for that.
    # This is the altFail array.  the main index is the current step.  The second index
    # breaks out to number of alternate maps and where in the altFailMap array it's alternate
    # map starts.
    $altFail = [
                    [0,0],                                                          # 0
                    [0,0],                                                          # 1
                    [0,0],                                                          # 2
                    [0,0],                                                          # 3
                    [0,0],                                                          # 4
                    [0,0],                                                          # 5
                    [0,0],                                                          # 6
                    [0,0],                                                          # 7
                    [0,0],                                                          # 8
                    [0,0],                                                          # 9
                    [0,0],                                                          # 10
                    [0,0],                                                          # 11
                    [1,0],                                                          # 12
                    [1,0],                                                          # 13
                    [1,0],                                                          # 14
                    [1,1],                                                          # 15
                    [1,2],                                                          # 16
                    [1,2],                                                          # 17
                    [1,2],                                                          # 18
                    [1,3],                                                          # 19
                    [1,4],                                                          # 20
                    [0,0],                                                          # 21
                    [0,0],                                                          # 22
                    [0,0],                                                          # 23
                    [0,0],                                                          # 24
                    [0,0],                                                          # 25
                    [0,0],                                                          # 26
                    [0,0],                                                          # 27
                    [0,0],                                                          # 28
                    [0,0],                                                          # 29
                    [0,0],                                                          # 30
               ] ;
    $altFailMap = [
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],  # alt for step 12, 13, 14
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],  # alt for step 15
                    [CONSTB0,CONSTB0,CONSTB2,CONSTB3,CONSTB0,CONSTB0,CONSTB2,CONSTB3],  # alt for step 16, 17, 18
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],  # alt for step 19
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],  # alt for step 20
                  ] ;

    # some initial setup.

    my $timelineDuration = 90; # Secs to wait after target fail/unfail
    my $masterIndex;
    my @startingTmap;
    my @activeServers;
    my @initialVdisks;
    my @pdiskData;
    my @vdiskData;
    my @raidData;

    # Find the Master, do not assume 
    $masterIndex = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ($masterIndex == INVALID)
    {
        TestLibs::Logging::logError ("Failed to find the Master controller, needed to fail a controller");
    }
    
    # Supress lower level messages
    if ($quiet eq "true") {logControl(stdout => "false");}

    # Gather initial data and check some system states
    $ret = TestLibs::Validate::CheckAtStart($coPtr, $masterIndex, \@serialNums, \@startingTmap,
            \@activeServers, \@initialVdisks, \@pdiskData, \@vdiskData, \@raidData);

    # Restore stdout
    if ($quiet eq "true") {logControl(stdout => "true");}

    if ( $ret == ERROR )
    {
        TestLibs::Logging::logError("Controller state bad during CheckAtStart");
    }

    # okay get our controller SNs.
    for ($i = 0; $i < $numCtrls ; $i++)
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coPtr->[$i]);
        # setup ifacesn and relativeiface
        for ($j = 0; $j < 4; $j++)
        {
            $k = $i*4 + $j ;            # $ith controller
            $ifacesn[$k] = $serialNums[$i] ;    # we are on the $ith controller
            $relativeiface[$k] = $j ;   # $jth iface of the $ith controller
        }
    }
    
    # big loop.
    # full test runs loopcount times.
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        TestLibs::Logging::logInfo("Executing FE Failover Test\n") ;
        TestLibs::Logging::logInfo("Loop down less than 10 seconds done repeatedly to failure.\n") ;

        #make sure targets are mapped to A0, A1, CONSTA2, CONSTA3, CONSTB0, CONSTB1, CONSTB2, B3
        TestLibs::Logging::logInfo("Checking Initial State\n") ;

#        my %initialstate = GetTargetStatus($coPtr->[$masterIndex]);
#        LogTargetStatus( %initialstate);
#
#        @map = CreateTargetMap( \@serialNums, %initialstate);

        $ret = GroupTargetMap($coPtr, \@serialNums, \@map, $masterIndex, LOGTARGETSTATUS );
        if ( $ret != GOOD )  {return ERROR; }


        # okay, we have 
        $ret = CompareTargetMap(\@map, $Results->[30]); # item 30 in the result list is a default map
        if ($ret == GOOD)
        {
            TestLibs::Logging::logInfo("Initial State - Ok\n") ;
        }
        elsif ($ret == ERROR)
        {
            TestLibs::Logging::logInfo("Initial State - Invalid!\n"); 
            TestLibs::Logging::logInfo("Expected - \n");
            PrintTargetMap($Results->[30]);
            TestLibs::Logging::logInfo("Found - \n");
            PrintTargetMap(\@map);
            return ERROR ;
        }
        else
        {
            TestLibs::Logging::logInfo ("Unknown Error!\n"); 
            return ERROR ;
        }

        TestLibs::Logging::logInfo ("Start main loop $i\n");
        for ($j=0; $TestSteps->[$j][0] != ENDSTEPS; $j++)
        {
            $Operation = $TestSteps->[$j][0] ;
            TestLibs::Logging::logInfo("Loop $i  Step $j\n") ;
            $currentIP = "notrun" ;     ## reset

            for ($k=1; $TestSteps->[$j][$k] != ENDCTRLS ; $k++)
            {
                MyPrintStep ($Operation) ;
                print " " ;
                $iface = $TestSteps->[$j][$k] ;
                $ret = _MyPrintInterface($iface);
                if ($ret == ERROR)
                {
                    logInfo("Exiting Test\n") ;
                    return ERROR ;
                }
                TestLibs::Logging::logInfo("\n") ;

                # convert from Validate style iface to a simple index.  (A0 is 0, B3 is 7)
                $index = _MyIndex($iface);

                #okay, we need a connection to our brocade.
                #is it already open?
                if ($currentIP ne $brocadeIP->[$index])
                {
                    # it isn't open.
                    # do we have an open connection?
                    if ($currentIP ne "notrun")
                    {
                        BSWLogOutOfSwitch($t) ;
                    }
                    # save the ip of the connection we are going to be working with
                    $currentIP = $brocadeIP->[$index] ;
                    $t = BSWLogInToSwitch ($currentIP);
                    if (!defined($t))  # If Login failed, try again
                    {
                        $t = BSWLogInToSwitch ($currentIP);
                        if (!defined($t))
                        {
                            TestLibs::Logging::logInfo ("Could not login to switch\n");
                            return ERROR;
                        }
                    }
                }
        
                if ($Operation == FAIL)
                {
                    TestLibs::Logging::logInfo("    Toggling port $brocadePtr->[$index] on brocade $brocadeIP->[$index].\n") ;
                    BSWDisableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(4) ;
                    BSWEnableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(30) ;
                    BSWDisableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(4) ;
                    BSWEnableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(30) ;
                    BSWDisableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(4) ;
                    BSWEnableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(30) ;
                    BSWDisableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(4) ;
                    BSWEnableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(30) ;
                    BSWDisableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(4) ;
                    BSWEnableSwitchPort($t, $brocadePtr->[$index]);
                    logInfo("    Port should be failed.\n") ;
                }
                else
                {
                    # since the test only flips the port on and off for 4 seconds I do not
                    # have to do anything with the brocade.
#                    logInfo("Unfailing $relativeiface[$index] on $ifacesn[$index]\n");
#                    _unFailInterface($coPtr->[$masterIndex], $ifacesn[$index], $relativeiface[$index]) ;
                }
            }
            # we likely have a port left open.  So close our connection.
            if ($currentIP ne "notrun")
            {
                BSWLogOutOfSwitch($t) ;
            }

            #wait xxx seconds 
            #DelaySecs (90) ;

            # Run the Time Line to check the failover sequence
            TestLibs::Validate::FailOverTimeLine($coPtr->[$masterIndex], $timelineDuration, \@serialNums, 0);

            # check output here
#            my %stuff = GetTargetStatus($coPtr->[$masterIndex]);
#            LogTargetStatus( %stuff);
#
#            @map = CreateTargetMap( \@serialNums, %stuff);

            $ret = GroupTargetMap($coPtr, \@serialNums, \@map, $masterIndex, LOGTARGETSTATUS );
            if ( $ret != GOOD )  {return ERROR; }

            # okay, we have 
            $ret = CompareTargetMap(\@map, $Results->[$j]);

            # unfortunately this isn't as deterministic as I would like so
            # if THAT didn't work we see if we have other maps to check.
            if ($ret != GOOD)
            {
                #okay, atlFail[x][0] is number of alternate failover maps available
                # altFail[x][1] is the index of the first map in the altFailMAp list
                #okay, check if we have an alternate failover map
                if ($altFail->[$j][0] > 0)
                {
                    TestLibs::Logging::logInfo ("Checking alternative failover maps\n") ;
                    my $done = 0 ;
                    for ($k = 0; $k < $altFail->[$j][0] && $done == 0; $k++)
                    {
                        $index = $altFail->[$j][1] + $k ;   # 1 points to the starting index and we go $k in.
                        $ret = CompareTargetMap(\@map, $altFailMap->[$index]);
                        if ($ret == GOOD)
                        {
                            $done = 1;
                        }
                        
                    }

                }
            }

            # for good or ill we are done with this entry.
            if ($ret == GOOD)
            {
                TestLibs::Logging::logInfo("Success!\n") ;
            }
            elsif ($ret == ERROR)
            {
                TestLibs::Logging::logInfo ("Incorrect Result!\n"); 
                TestLibs::Logging::logInfo ("Expected - \n");
                PrintTargetMap($Results->[$j]);
                TestLibs::Logging::logInfo ("Found - \n");
                PrintTargetMap(\@map);
                return ERROR ;
            }
            else
            {
                logInfo ("Unknown Error!\n"); 
                return ERROR ;
            }
            TestLibs::Logging::logInfo ("\n") ;

            # Supress lower level messages
            if ($quiet eq "true") {logControl(stdout => "false");}

            # check the system state of the front end: server activity, vdisk activity, target map
            $ret = TestLibs::Validate::TestSystemState1($coPtr, \@activeServers, 0, \@initialVdisks, \@serialNums);

            # Restore stdout
            if ($quiet eq "true") {logControl(stdout => "true");}

            if ( $ret == ERROR )
            {
                if ($$curTestParmHashPtr{"nofailmanager"} eq "true")
                {
                    TestLibs::Logging::logInfo ("Disable Suicide on All Controllers");
                    # Stop the BE Processor
                    $ret = TestLibs::IntegCCBELib::NoFailureManager($coPtr);
                    if ( $ret == ERROR )
                    {
                        TestLibs::Logging::logError("Could not disable suicide state");
                    }
                }
                if ($$curTestParmHashPtr{"errortrapbe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping BE Proc <BEET>");
                        # Stop the BE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "BE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }
                if ($$curTestParmHashPtr{"errortrapfe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping FE Proc <FEET>");
                        # Stop the FE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "FE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }
                TestLibs::Logging::logError("Controller state bad during TestSystemState1");
            }

            # Supress lower level messages
            if ($quiet eq "true") {logControl(stdout => "false");}

            # check the back end state, vdisk status, pdisk status, raid status
            $ret = TestLibs::Validate::TestSystemState2($coPtr->[$masterIndex], \@pdiskData, \@vdiskData, \@raidData);

            # Restore stdout
            if ($quiet eq "true") {logControl(stdout => "true");}

            if ( $ret == ERROR )
            {
                if ($$curTestParmHashPtr{"nofailmanager"} eq "true")
                {
                    TestLibs::Logging::logInfo ("Disable Suicide on All Controllers");
                    # Stop the BE Processor
                    $ret = TestLibs::IntegCCBELib::NoFailureManager($coPtr);
                    if ( $ret == ERROR )
                    {
                        TestLibs::Logging::logError("Could not disable suicide state");
                    }
                }
                if ($$curTestParmHashPtr{"errortrapbe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping BE Proc <BEET>");
                        # Stop the BE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "BE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }
                if ($$curTestParmHashPtr{"errortrapfe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping FE Proc <FEET>");
                        # Stop the FE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "FE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }
                TestLibs::Logging::logError("Controller state bad during TestSystemState2");
            }
        }
    }
    return GOOD ;
}


##############################################################################
#
#          Name: DownFELoopLong
#
#        Inputs: array of connected controller objects, array of brocade
#                switch IP's, map of ports to use for each switch, the number
#                of controllers in the controller array, the number of loops to
#                do. 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Downs the FE Loop for greater than 10 seconds.  A
#                failure is expected to occur.
#
##############################################################################
sub DownFELoopLong
{
    my ($coPtr, $brocadeIP, $brocadePtr, $numCtrls, $loopCount, $curTestParmHashPtr, $quiet) = @_;

    my $TestSteps ;
    my $Operation ;
    my $iface ;
    my $Results ;
    my $altFail ;
    my $altFailMap ;
    my $ret ;
    my $i;
    my $j;
    my $k;
    my $l;
    my $t;
    my $currentIP;
    my @serialNums ;
    my @ifacesn;
    my @relativeiface ;
    my $index;
    my @map ;
    my $logMark;
    my $timelineDuration = 90; # Secs to wait after target fail/unfail
    my $masterIndex;
    my @startingTmap;
    my @activeServers;
    my @initialVdisks;
    my @pdiskData;
    my @vdiskData;
    my @raidData;



    ########################################
    # You must also have the Net::Telnet   #
    # library. This file is in the release #
    # directory (  \Test\PerlLibs\Net  )   #
    # and can be copied to your perl       #
    # directory ( C:\Perl\site\lib\Net )   #
    ########################################
       
#    use Net::Telnet ();



    $TestSteps = [  [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #0
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #1
                    [FAIL, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #2
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #3
                    [FAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #4
                    [FAIL, CONSTA2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #5
                    [FAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],  #6
                    [UNFAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],#7
                    [FAIL, CONSTA3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #8
                    [FAIL, CONSTB2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #9
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #10
                    [FAIL, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #11
                    [UNFAIL, CONSTA3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #12
                    [FAIL, CONSTA2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #13
                    [UNFAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #14
                    [FAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #15
                    [UNFAIL, CONSTA2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #16
                    [FAIL, CONSTA3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #17
                    [UNFAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #18
                    [FAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #19
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #20
                    [FAIL, CONSTB3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #21
                    [FAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #22
                    [UNFAIL, CONSTB0, CONSTB1, CONSTB2, CONSTB3, ENDCTRLS, 0, 0, 0],#23
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #24
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #25
                    [UNFAIL, CONSTA0, CONSTA1, CONSTA3, ENDCTRLS, 0, 0, 0, 0],      #26
                    [FAIL, CONSTB0, CONSTB1, CONSTB2, CONSTB3, ENDCTRLS, 0, 0, 0],  #27
                    [UNFAIL, CONSTB0, CONSTB1, CONSTB2, CONSTB3, ENDCTRLS, 0, 0, 0],#28
                    [FAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],  #29
                    [UNFAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],#30
                    [ENDSTEPS,0,0,0,0,0,0,0,0]
            ];
    $Results = [    [CONSTA1,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #0   11111110
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #1	 11111111
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #2	 11111101
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #3	 11111100
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #4	 11101100
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #5	 11101000
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #6	 11100000
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #7	 11101111
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #8	 11100111
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #9 	 10100111
                    [CONSTA1,CONSTA1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #10	 10100110
                    [CONSTB1,CONSTB1,CONSTB3,CONSTB3,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #11	 10100100
                    [CONSTB1,CONSTB1,CONSTB3,CONSTB3,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #12	 10101100
                    [CONSTB1,CONSTB1,CONSTB3,CONSTB3,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #13	 10101000
                    [CONSTB0,CONSTB1,CONSTB3,CONSTB3,CONSTB0,CONSTB1,CONSTB3,CONSTB3],                  #14	 10111000
                    [CONSTB0,CONSTB0,CONSTB3,CONSTB3,CONSTB0,CONSTB0,CONSTB3,CONSTB3],                  #15	 10011000
                    [CONSTB0,CONSTB0,CONSTB3,CONSTB3,CONSTB0,CONSTB0,CONSTB3,CONSTB3],                  #16	 10011100
                    [CONSTB0,CONSTB0,CONSTB3,CONSTB3,CONSTB0,CONSTB0,CONSTB3,CONSTB3],                  #17	 10010100
                    [CONSTB0,CONSTB1,CONSTB3,CONSTB3,CONSTB0,CONSTB1,CONSTB3,CONSTB3],                  #18	 10110100
                    [CONSTB1,CONSTB1,CONSTB3,CONSTB3,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #19	 10100100
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #20	 10100101
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTA0,CONSTA0,CONSTA2,CONSTA2],                  #21	 00100101
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTA0,CONSTA0,CONSTA2,CONSTA2],                  #22	 00000101
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #23	 11110101
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #24	 11110101
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #25	 11110100
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #26	 11111111
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTA0,CONSTA1,CONSTA2,CONSTA3],                  #27	 00001111
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #28	 11111111
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #29	 11110000
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3]                   #30	 11111111
               ] ;

    # no doubt this is more complicated than I want.
    # there are a couple of places where things do not have to move where you expect them to.
    # luck of the draw sort of thing.  So we need to plan for that.
    # This is the altFail array.  the main index is the current step.  The second index
    # breaks out to number of alternate maps and where in the altFailMap array it's alternate
    # map starts.
    $altFail = [
                    [0,0],                                                          # 0
                    [0,0],                                                          # 1
                    [0,0],                                                          # 2
                    [0,0],                                                          # 3
                    [0,0],                                                          # 4
                    [0,0],                                                          # 5
                    [0,0],                                                          # 6
                    [0,0],                                                          # 7
                    [0,0],                                                          # 8
                    [0,0],                                                          # 9
                    [0,0],                                                          # 10
                    [0,0],                                                          # 11
                    [1,0],                                                          # 12
                    [1,0],                                                          # 13
                    [1,0],                                                          # 14
                    [1,1],                                                          # 15
                    [1,2],                                                          # 16
                    [1,2],                                                          # 17
                    [1,2],                                                          # 18
                    [1,3],                                                          # 19
                    [1,4],                                                          # 20
                    [0,0],                                                          # 21
                    [0,0],                                                          # 22
                    [0,0],                                                          # 23
                    [0,0],                                                          # 24
                    [0,0],                                                          # 25
                    [0,0],                                                          # 26
                    [0,0],                                                          # 27
                    [0,0],                                                          # 28
                    [0,0],                                                          # 29
                    [0,0],                                                          # 30
               ] ;
    $altFailMap = [
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],  # alt for step 12, 13, 14
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],  # alt for step 15
                    [CONSTB0,CONSTB0,CONSTB2,CONSTB3,CONSTB0,CONSTB0,CONSTB2,CONSTB3],  # alt for step 16, 17, 18
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],  # alt for step 19
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],  # alt for step 20
                  ] ;

    # some initial setup.

    # okay get our controller SNs.
    for ($i = 0; $i < $numCtrls ; $i++)
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coPtr->[$i]);
        # setup ifacesn and relativeiface
        for ($j = 0; $j < 4; $j++)
        {
            $k = $i*4 + $j ;            # $ith controller
            $ifacesn[$k] = $serialNums[$i] ;    # we are on the $ith controller
            $relativeiface[$k] = $j ;   # $jth iface of the $ith controller
        }
    }

    # Find the Master, do not assume 
    $masterIndex = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ($masterIndex == INVALID)
    {
        TestLibs::Logging::logError ("Failed to find the Master controller, needed to fail a controller");
    }
    
    # Supress lower level messages
    if ($quiet eq "true") {logControl(stdout => "false");}

    # Gather initial data and check some system states
    $ret = TestLibs::Validate::CheckAtStart($coPtr, $masterIndex, \@serialNums, \@startingTmap,
            \@activeServers, \@initialVdisks, \@pdiskData, \@vdiskData, \@raidData);

    # Restore stdout
    if ($quiet eq "true") {logControl(stdout => "true");}

    if ( $ret == ERROR )
    {
        TestLibs::Logging::logError("Controller state bad during CheckAtStart");
    }

    # big loop.
    # full test runs loopcount times.
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        TestLibs::Logging::logInfo ("Executing FE Failover Test\n") ;
        TestLibs::Logging::logInfo ("Loop down greater than 10 seconds to failure.\n") ;

        #make sure targets are mapped to A0, A1, CONSTA2, CONSTA3, CONSTB0, CONSTB1, CONSTB2, B3
        TestLibs::Logging::logInfo("Checking Initial State\n") ;

#        my %initialstate = GetTargetStatus($coPtr->[$masterIndex]);
#        LogTargetStatus( %initialstate);
#
#        @map = CreateTargetMap( \@serialNums, %initialstate);

        $ret = GroupTargetMap($coPtr, \@serialNums, \@map, $masterIndex, LOGTARGETSTATUS);
        if ( $ret != GOOD )  {return ERROR; }


        # okay, we have 
        $ret = CompareTargetMap(\@map, $Results->[30]); # item 30 in the result list is a default map
        if ($ret == GOOD)
        {
            logInfo("Initial State - Ok\n") ;
        }
        elsif ($ret == ERROR)
        {
            TestLibs::Logging::logInfo("Initial State - Invalid!\n"); 
            TestLibs::Logging::logInfo("Expected - \n");
            PrintTargetMap($Results->[30]);
            TestLibs::Logging::logInfo("Found - \n");
            PrintTargetMap(\@map);
            return ERROR ;
        }
        else
        {
            TestLibs::Logging::logInfo ("Unknown Error!\n"); 
            return ERROR ;
        }

        TestLibs::Logging::logInfo ("Start main loop $i\n");
        for ($j=0; $TestSteps->[$j][0] != ENDSTEPS; $j++)
        {
            $Operation = $TestSteps->[$j][0] ;
            TestLibs::Logging::logInfo("Loop $i  Step $j\n");
            $currentIP = "notrun" ;     ## reset

            for ($k=1; $TestSteps->[$j][$k] != ENDCTRLS ; $k++)
            {
                _MyPrintStep ($Operation) ;
                print " " ;
                $iface = $TestSteps->[$j][$k] ;
                $ret = TestLibs::FailOverSupport::_MyPrintInterface($iface);
                if ($ret == ERROR)
                {
                    logInfo ("Exiting Test\n") ;
                    return ERROR ;
                }
                TestLibs::Logging::logInfo ("\n") ;

                # convert from Validate style iface to a simple index.  (A0 is 0, B3 is 7)
                $index = _MyIndex($iface);

                #okay, we need a connection to our brocade.
                #is it already open?
                if ($currentIP ne $brocadeIP->[$index])
                {
                    # it isn't open.
                    # do we have an open connection?
                    if ($currentIP ne "notrun")
                    {
                        TestLibs::Logging::logInfo ("Attempt to logout of switch:$currentIP\n");
                        BSWLogOutOfSwitch($t) ;
                    }
                    # save the ip of the connection we are going to be working with
                    $currentIP = $brocadeIP->[$index] ;
                    $t = BSWLogInToSwitch ($currentIP);
                    if (!defined($t))  # If Login failed, try again
                    {
                        $t = BSWLogInToSwitch ($currentIP);
                        if (!defined($t))
                        {
                            TestLibs::Logging::logInfo ("Could not login to switch\n");
                            return ERROR;
                        }
                    }
                }
        
                if ($Operation == FAIL)
                {
                    TestLibs::Logging::logInfo("    Disabling port $brocadePtr->[$index] : $brocadeIP->[$index]\n") ;

                    # Mark the controller logs with Port Disable
                    $logMark = "FailOver Script: Fail T$index, Disabling Switch Port $brocadePtr->[$index] : $brocadeIP->[$index]";
                    TestLibs::IntegCCBELib::CtlrLogTextAll($coPtr, $logMark);

                    BSWDisableSwitchPort($t, $brocadePtr->[$index]);
                }
                else
                {
                    TestLibs::Logging::logInfo("    Enabling port $brocadePtr->[$index] : $brocadeIP->[$index]\n") ;

                    # Mark the controller logs with Port Enable
                    $logMark = "FailOver Script: UnFail T$index, Enabling Switch Port $brocadePtr->[$index] : $brocadeIP->[$index]";
                    TestLibs::IntegCCBELib::CtlrLogTextAll($coPtr, $logMark);

                    BSWEnableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(10);
#                    TestLibs::Logging::logInfo ("Unfailing $relativeiface[$index] on $ifacesn[$index]\n") ;
#                    _unFailInterface($coPtr->[$masterIndex], $ifacesn[$index], $relativeiface[$index]) ;
                }
            }
            # we likely have a port left open.  So close our connection.
            if ($currentIP ne "notrun")
            {
                BSWLogOutOfSwitch($t) ;
            }

            #wait xxx seconds 
            #DelaySecs (90) ;

            # Run the Time Line to check the failover sequence
            TestLibs::Validate::FailOverTimeLine($coPtr->[$masterIndex], $timelineDuration, \@serialNums, 0);
            
            # check output here
#            my %stuff = GetTargetStatus($coPtr->[$masterIndex]);
#            LogTargetStatus( %stuff);
#
#            @map = CreateTargetMap( \@serialNums, %stuff);

            $ret = GroupTargetMap($coPtr, \@serialNums, \@map, $masterIndex, LOGTARGETSTATUS );
            if ( $ret != GOOD )  {return ERROR; }
            
            # okay, we have 
            $ret = CompareTargetMap(\@map, $Results->[$j]);

            # unfortunately this isn't as deterministic as I would like so
            # if THAT didn't work we see if we have other maps to check.
            if ($ret != GOOD)
            {
                #okay, atlFail[x][0] is number of alternate failover maps available
                # altFail[x][1] is the index of the first map in the altFailMAp list
                #okay, check if we have an alternate failover map
                if ($altFail->[$j][0] > 0)
                {
                    TestLibs::Logging::logInfo ("Checking alternative failover maps\n") ;
                    my $done = 0 ;
                    for ($k = 0; $k < $altFail->[$j][0] && $done == 0; $k++)
                    {
                        $index = $altFail->[$j][1] + $k ;   # 1 points to the starting index and we go $k in.
                        $ret = CompareTargetMap(\@map, $altFailMap->[$index]);
                        if ($ret == GOOD)
                        {
                            $done = 1;
                        }
                        
                    }

                }
            }

            # for good or ill we are done with this entry.
            if ($ret == GOOD)
            {
                TestLibs::Logging::logInfo("Success!\n") ;
            }
            elsif ($ret == ERROR)
            {
                TestLibs::Logging::logInfo ("Incorrect Result!\n"); 
                TestLibs::Logging::logInfo ("Expected - \n");
                PrintTargetMap($Results->[$j]);
                TestLibs::Logging::logInfo ("Found - \n");
                PrintTargetMap(\@map);
                return ERROR ;
            }
            else
            {
                TestLibs::Logging::logInfo ("Unknown Error!\n"); 
                return ERROR ;
            }
            TestLibs::Logging::logInfo ("\n") ;

            # Supress lower level messages
            if ($quiet eq "true") {logControl(stdout => "false");}

            # check the system state of the front end: server activity, vdisk activity, target map
            $ret = TestLibs::Validate::TestSystemState1($coPtr, \@activeServers, 0, \@initialVdisks, \@serialNums);

            # Restore stdout
            if ($quiet eq "true") {logControl(stdout => "true");}

            if ( $ret == ERROR )
            {
                if ($$curTestParmHashPtr{"nofailmanager"} eq "true")
                {
                    TestLibs::Logging::logInfo ("Disable Suicide on All Controllers");
                    # Stop the BE Processor
                    $ret = TestLibs::IntegCCBELib::NoFailureManager($coPtr);
                    if ( $ret == ERROR )
                    {
                        TestLibs::Logging::logError("Could not disable suicide state");
                    }
                }
                if ($$curTestParmHashPtr{"errortrapbe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping BE Proc <BEET>");
                        # Stop the BE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "BE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }
                if ($$curTestParmHashPtr{"errortrapfe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping FE Proc <FEET>");
                        # Stop the FE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "FE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }

                TestLibs::Logging::logError("Controller state bad during TestSystemState1");
            }

            # Supress lower level messages
            if ($quiet eq "true") {logControl(stdout => "false");}

            # check the back end state, vdisk status, pdisk status, raid status
            $ret = TestLibs::Validate::TestSystemState2($coPtr->[$masterIndex], \@pdiskData, \@vdiskData, \@raidData);

            # Restore stdout
            if ($quiet eq "true") {logControl(stdout => "true");}

            if ( $ret == ERROR )
            {
                if ($$curTestParmHashPtr{"nofailmanager"} eq "true")
                {
                    TestLibs::Logging::logInfo ("Disable Suicide on All Controllers");
                    # Stop the BE Processor
                    $ret = TestLibs::IntegCCBELib::NoFailureManager($coPtr);
                    if ( $ret == ERROR )
                    {
                        TestLibs::Logging::logError("Could not disable suicide state");
                    }
                }
                if ($$curTestParmHashPtr{"errortrapbe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping BE Proc <BEET>");
                        # Stop the BE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "BE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }
                if ($$curTestParmHashPtr{"errortrapfe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping FE Proc <FEET>");
                        # Stop the FE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "FE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }

                TestLibs::Logging::logError("Controller state bad during TestSystemState2");
            }

        } # End of step loop
    }
    return GOOD ;
}


##############################################################################
#
#          Name: DownFELoopLong2
#
#        Inputs: array of connected controller objects, array of brocade
#                switch IP's, map of ports to use for each switch, the number
#                of controllers in the controller array, the number of loops to
#                do. 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: On system with only two FE interfaces per controller.
#                Downs the FE Loop for greater than 10 seconds.  A
#                failure is expected to occur.
#
##############################################################################
sub DownFELoopLong2
{
    my ($coPtr, $brocadeIP, $brocadePtr, $numCtrls, $loopCount, $curTestParmHashPtr, $quiet ) = @_;
    my $TestSteps ;
    my $Operation ;
    my $iface ;
    my $Results ;
    my $altFail ;
    my $altFailMap ;
    my $ret ;
    my $i;
    my $j;
    my $k;
    my $l;
    my $t;
    my $currentIP;
    my @serialNums ;
    my @ifacesn;
    my @relativeiface ;
    my $index;
    my @map;
    my $logMark;
    my $timelineDuration = 90; # Secs to wait after target fail/unfail
    my $masterIndex;
    my @startingTmap;
    my @activeServers;
    my @initialVdisks;
    my @pdiskData;
    my @vdiskData;
    my @raidData;



    ########################################
    # You must also have the Net::Telnet   #
    # library. This file is in the release #
    # directory (  \Test\PerlLibs\Net  )   #
    # and can be copied to your perl       #
    # directory ( C:\Perl\site\lib\Net )   #
    ########################################
       
#    use Net::Telnet ();


                                                                                 # 8 Intf      4 Intf
    $TestSteps = [  [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #1           0
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #2           1
                    [FAIL, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #3           2
                    [UNFAIL, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #4           3
                    [FAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #5           4
                    [FAIL, CONSTA0, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0],              #7           5
                    [UNFAIL, CONSTA0, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0],            #8           6
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #11          7
                    [FAIL, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #12          8
                    [UNFAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #16          9
                    [FAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #17          10
                    [UNFAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #20          11
                    [FAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #21          12
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #22          13
                    [FAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #23          14
                    [UNFAIL, CONSTB0, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0],            #24          15
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #25          16
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #26          17
                    [UNFAIL, CONSTA0, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0],            #27          18
                    [FAIL, CONSTB0, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0],              #28          19
                    [UNFAIL, CONSTB0, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0],            #29          20
                    [FAIL, CONSTA0, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0],              #30          21
                    [UNFAIL, CONSTA0, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0],            #31          22
                    [ENDSTEPS,0,0,0,0,0,0,0,0]
            ];                                                                                    # 8 Intf   4 Intf
    $Results = [    [CONSTA1,CONSTA1,0,0,CONSTB0,CONSTB1,0,0],                  #1     0
                    [CONSTA0,CONSTA1,0,0,CONSTB0,CONSTB1,0,0],                  #2     1
                    [CONSTA0,CONSTA0,0,0,CONSTB0,CONSTB1,0,0],                  #3     2
                    [CONSTA0,CONSTA1,0,0,CONSTB0,CONSTB1,0,0],                  #4     3
                    [CONSTA0,CONSTA1,0,0,CONSTB1,CONSTB1,0,0],                  #5     4
                    [CONSTB1,CONSTB1,0,0,CONSTB1,CONSTB1,0,0],                  #7     5
                    [CONSTA0,CONSTA1,0,0,CONSTB1,CONSTB1,0,0],                  #8     6
                    [CONSTA1,CONSTA1,0,0,CONSTB1,CONSTB1,0,0],                  #11    7
                    [CONSTB1,CONSTB1,0,0,CONSTB1,CONSTB1,0,0],                  #12    8
                    [CONSTB0,CONSTB1,0,0,CONSTB0,CONSTB1,0,0],                  #16    9
                    [CONSTB0,CONSTB0,0,0,CONSTB0,CONSTB0,0,0],                  #17    10
                    [CONSTB0,CONSTB1,0,0,CONSTB0,CONSTB1,0,0],                  #20    11
                    [CONSTB1,CONSTB1,0,0,CONSTB1,CONSTB1,0,0],                  #21    12
                    [CONSTA0,CONSTA0,0,0,CONSTB1,CONSTB1,0,0],                  #22    13
                    [CONSTA0,CONSTA0,0,0,CONSTA0,CONSTA0,0,0],                  #23    14
                    [CONSTA0,CONSTA0,0,0,CONSTB0,CONSTB1,0,0],                  #24    15
                    [CONSTA0,CONSTA0,0,0,CONSTB0,CONSTB1,0,0],                  #25    16
                    [CONSTB0,CONSTB1,0,0,CONSTB0,CONSTB1,0,0],                  #26    17
                    [CONSTA0,CONSTA1,0,0,CONSTB0,CONSTB1,0,0],                  #27    18
                    [CONSTA0,CONSTA1,0,0,CONSTA0,CONSTA1,0,0],                  #28    19
                    [CONSTA0,CONSTA1,0,0,CONSTB0,CONSTB1,0,0],                  #29    20
                    [CONSTB0,CONSTB1,0,0,CONSTB0,CONSTB1,0,0],                  #30    21
                    [CONSTA0,CONSTA1,0,0,CONSTB0,CONSTB1,0,0]                   #31    22
               ] ;



    # no doubt this is more complicated than I want.
    # there are a couple of places where things do not have to move where you expect them to.
    # luck of the draw sort of thing.  So we need to plan for that.
    # This is the altFail array.  the main index is the current step.  The second index
    # breaks out to number of alternate maps and where in the altFailMap array it's alternate
    # map starts.
    $altFail = [
                    [0,0],                                                          # 1            
                    [0,0],                                                          # 2            
                    [0,0],                                                          # 3            
                    [1,0],                                                          # 4            
                    [0,0],                                                          # 5            
#                    [0,0],                                                          # 6
                    [0,1],                                                          # 7            
                    [0,0],                                                          # 8            
#                    [0,0],                                                          # 9
#                    [0,0],                                                          # 10
                    [0,0],                                                          # 11           
                    [0,0],                                                          # 12           
#                    [0,0],                                                          # 13
#                    [0,0],                                                          # 14
#                    [0,0],                                                          # 15
                    [0,0],                                                          # 16           
                    [0,0],                                                          # 17           
#                    [0,0],                                                          # 18
#                    [0,0],                                                          # 19
                    [0,0],                                                          # 20           
                    [0,0],                                                          # 21           
                    [0,0],                                                          # 22           
                    [0,0],                                                          # 23           
                    [0,0],                                                          # 24           
                    [0,0],                                                          # 25           
                    [1,2],                                                          # 26           
                    [0,0],                                                          # 27           
                    [1,3],                                                          # 28           
                    [0,0],                                                          # 29           
                    [1,6],                                                          # 30           
                    [0,0]                                                           # 31           
               ] ;
    $altFailMap = [                     
                    [CONSTB1,CONSTB0,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],  # alt for step 4
                    [CONSTB1,CONSTB1,CONSTA2,CONSTA3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],  # alt for step 7
                    [CONSTB1,CONSTB0,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],  # alt for step 26
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTA1,CONSTA0,CONSTB2,CONSTB3],  # alt for step 28
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTA1,CONSTA0,CONSTB2,CONSTB3],
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTA0,CONSTA1,CONSTB2,CONSTB3],
                    [CONSTB1,CONSTB0,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],  # alt for step 30
                    [CONSTB1,CONSTB0,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],
                    [CONSTB0,CONSTB1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3]
                  ] ;

    # some initial setup.

    # okay get our controller SNs.
    for ($i = 0; $i < $numCtrls ; $i++)
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coPtr->[$i]);
        # setup ifacesn and relativeiface
        for ($j = 0; $j < 4; $j++)
        {
            $k = $i*4 + $j ;            # $ith controller
            $ifacesn[$k] = $serialNums[$i] ;    # we are on the $ith controller
            $relativeiface[$k] = $j ;   # $jth iface of the $ith controller
        }
    }
    
    # Supress lower level messages
    if ($quiet eq "true") {logControl(stdout => "false");}

    # Find the Master, do not assume 
    $masterIndex = TestLibs::IntegCCBELib::FindMaster( $coPtr );

    # Restore stdout
    if ($quiet eq "true") {logControl(stdout => "true");}

    if ($masterIndex == INVALID)
    {
        TestLibs::Logging::logError ("Failed to find the Master controller, needed to fail a controller");
    }
    
    # Supress lower level messages
    if ($quiet eq "true") {logControl(stdout => "false");}

    # Gather initial data and check some system states
    $ret = TestLibs::Validate::CheckAtStart($coPtr, $masterIndex, \@serialNums, \@startingTmap,
            \@activeServers, \@initialVdisks, \@pdiskData, \@vdiskData, \@raidData) ;

    # Restore stdout
    if ($quiet eq "true") {logControl(stdout => "true");}

    if ( $ret == ERROR )
    {
        TestLibs::Logging::logError("Controller state bad during CheckAtStart");
    }



    # big loop.
    # full test runs loopcount times.
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        TestLibs::Logging::logInfo ("Executing FE Failover Test\n") ;
        TestLibs::Logging::logInfo ("Loop down greater than 10 seconds to failure.\n") ;

        #make sure targets are mapped to A0, A1, CONSTA2, CONSTA3, CONSTB0, CONSTB1, CONSTB2, B3
        TestLibs::Logging::logInfo("Checking Initial State\n") ;

#        my %initialstate = GetTargetStatus($coPtr->[$masterIndex]);
#        LogTargetStatus( %initialstate);
#
##$dumper->dumpValues(@map);
##$dumper->dumpValues(%initialstate);
#
#        @map = CreateTargetMap( \@serialNums, %initialstate);

        $ret = GroupTargetMap($coPtr, \@serialNums, \@map, $masterIndex, LOGTARGETSTATUS );
        if ( $ret != GOOD )  {return ERROR; }


        # okay, we have 
        $ret = CompareTargetMap(\@map, $Results->[22]); # item 22 in the result list is a default map
        if ($ret == GOOD)
        {
            TestLibs::Logging::logInfo("Initial State - Ok\n") ;
        }
        elsif ($ret == ERROR)
        {
            TestLibs::Logging::logInfo("Initial State - Invalid!\n"); 
            TestLibs::Logging::logInfo("Expected - \n");
            PrintTargetMap($Results->[22]);
            TestLibs::Logging::logInfo("Found - \n");
            PrintTargetMap(\@map);
            return ERROR ;
        }
        else
        {
            TestLibs::Logging::logInfo ("Unknown Error!\n"); 
            return ERROR ;
        }

        logInfo ("Start main loop $i\n");
        for ($j=0; $TestSteps->[$j][0] != ENDSTEPS; $j++)
        {
            $Operation = $TestSteps->[$j][0] ;
            TestLibs::Logging::logInfo("Loop $i  Step $j\n");
            $currentIP = "notrun" ;     ## reset

            for ($k=1; $TestSteps->[$j][$k] != ENDCTRLS ; $k++)
            {
                _MyPrintStep ($Operation) ;
                print " " ;
                $iface = $TestSteps->[$j][$k] ;
                $ret = _MyPrintInterface($iface);
                if ($ret == ERROR)
                {
                    logInfo ("Exiting Test\n") ;
                    return ERROR ;
                }
                TestLibs::Logging::logInfo ("\n") ;

                # convert from Validate style iface to a simple index.  (A0 is 0, B3 is 7)
                $index = _MyIndex($iface);
                TestLibs::Logging::debug( "Port Index: $index");

                #okay, we need a connection to our brocade.
                #is it already open?
                if ($currentIP ne $brocadeIP->[$index])
                {
                    # it isn't open.
                    # do we have an open connection?
                    if ($currentIP ne "notrun")
                    {
                        BSWLogOutOfSwitch($t) ;
                    }
                    # save the ip of the connection we are going to be working with
                    $currentIP = $brocadeIP->[$index] ;
                    $t = BSWLogInToSwitch ($currentIP);
                    if (!defined($t))  # If Login failed, try again
                    {
                        $t = BSWLogInToSwitch ($currentIP);
                        if (!defined($t))
                        {
                            TestLibs::Logging::logInfo ("Could not login to switch\n");
                            return ERROR;
                        }
                    }
                }
        
                if ($Operation == FAIL)
                {
                    TestLibs::Logging::logInfo("    Disabling port $brocadePtr->[$index] : $brocadeIP->[$index]\n") ;

                    # Mark the controller logs with Port Disable
                    $logMark = "FailOver Script: Fail T$index, Disabling Switch Port $brocadePtr->[$index] : $brocadeIP->[$index]";
                    TestLibs::IntegCCBELib::CtlrLogTextAll($coPtr, $logMark);

                    BSWDisableSwitchPort($t, $brocadePtr->[$index]);
                }
                else
                {
                    TestLibs::Logging::logInfo("    Enabling port $brocadePtr->[$index] : $brocadeIP->[$index]\n") ;

                    # Mark the controller logs with Port Enable
                    $logMark = "FailOver Script: UnFail T$index, Enabling Switch Port $brocadePtr->[$index] : $brocadeIP->[$index]";
                    TestLibs::IntegCCBELib::CtlrLogTextAll($coPtr, $logMark);

                    BSWEnableSwitchPort($t, $brocadePtr->[$index]);
                    DelaySecs(10);
#                    TestLibs::Logging::logInfo ("Unfailing $relativeiface[$index] on $ifacesn[$index]\n") ;
#                    _unFailInterface($coPtr->[$masterIndex], $ifacesn[$index], $relativeiface[$index]) ;
                }
            }
            # we likely have a port left open.  So close our connection.
            if ($currentIP ne "notrun")
            {
                BSWLogOutOfSwitch($t) ;
            }

            #wait xxx seconds 
            #DelaySecs (90) ;
            
            # Supress lower level messages
            if ($quiet eq "true") {logControl(stdout => "false");}

            # Run the Time Line to check the failover sequence
            TestLibs::Validate::FailOverTimeLine($coPtr->[$masterIndex], $timelineDuration, \@serialNums, 0);

            # Restore stdout
            if ($quiet eq "true") {logControl(stdout => "true");}

            # check output here

#            my %stuff = GetTargetStatus($coPtr->[$masterIndex]);
#            LogTargetStatus( %stuff);
#
#            @map = CreateTargetMap( \@serialNums, %stuff);

            $ret = GroupTargetMap($coPtr, \@serialNums, \@map, $masterIndex, LOGTARGETSTATUS );
            if ( $ret != GOOD )  {return ERROR; }


            
            # okay, we have 
            $ret = CompareTargetMap(\@map, $Results->[$j]);

            # unfortunately this isn't as deterministic as I would like so
            # if THAT didn't work we see if we have other maps to check.
            if ($ret != GOOD)
            {
                #okay, atlFail[x][0] is number of alternate failover maps available
                # altFail[x][1] is the index of the first map in the altFailMAp list
                #okay, check if we have an alternate failover map
                if ($altFail->[$j][0] > 0)
                {
                    TestLibs::Logging::logInfo ("Checking alternative failover maps\n") ;
                    my $done = 0 ;
                    for ($k = 0; $k < $altFail->[$j][0] && $done == 0; $k++)
                    {
                        $index = $altFail->[$j][1] + $k ;   # 1 points to the starting index and we go $k in.
                        $ret = CompareTargetMap(\@map, $altFailMap->[$index]);
                        if ($ret == GOOD)
                        {
                            $done = 1;
                        }
                        
                    }

                }
            }
            # for good or ill we are done with this entry.
            if ($ret == GOOD)
            {
                TestLibs::Logging::logInfo("Success!\n") ;
            }
            elsif ($ret == ERROR)
            {
                TestLibs::Logging::logInfo ("Incorrect Result!\n"); 
                TestLibs::Logging::logInfo ("Expected - \n");
                PrintTargetMap($Results->[$j]);
                TestLibs::Logging::logInfo ("Found - \n");
                PrintTargetMap(\@map);
                return ERROR ;
            }
            else
            {
                TestLibs::Logging::logInfo ("Unknown Error!\n"); 
                return ERROR ;
            }
            TestLibs::Logging::logInfo ("\n") ;

            # Supress lower level messages
            if ($quiet eq "true") {logControl(stdout => "false");}

            # check the system state of the front end: server activity, vdisk activity, target map
            $ret = TestLibs::Validate::TestSystemState1($coPtr, \@activeServers, 0, \@initialVdisks, \@serialNums);

            # Restore stdout
            if ($quiet eq "true") {logControl(stdout => "true");}

            if ( $ret == ERROR )
            {
                if ($$curTestParmHashPtr{"nofailmanager"} eq "true")
                {
                    TestLibs::Logging::logInfo ("Disable Suicide on All Controllers");
                    # Stop the BE Processor
                    $ret = TestLibs::IntegCCBELib::NoFailureManager($coPtr);
                    if ( $ret == ERROR )
                    {
                        TestLibs::Logging::logError("Could not disable suicide state");
                    }
                }
                if ($$curTestParmHashPtr{"errortrapbe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping BE Proc <BEET>");
                        # Stop the BE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "BE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }
                if ($$curTestParmHashPtr{"errortrapfe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping FE Proc <FEET>");
                        # Stop the FE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "FE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }

                TestLibs::Logging::logError("Controller state bad during TestSystemState1");
            }

            # Supress lower level messages
            if ($quiet eq "true") {logControl(stdout => "false");}

            # check the back end state, vdisk status, pdisk status, raid status
            $ret = TestLibs::Validate::TestSystemState2($coPtr->[$masterIndex], \@pdiskData, \@vdiskData, \@raidData);

            # Restore stdout
            if ($quiet eq "true") {logControl(stdout => "true");}

            if ( $ret == ERROR )
            {
                if ($$curTestParmHashPtr{"nofailmanager"} eq "true")
                {
                    TestLibs::Logging::logInfo ("Disable Suicide on All Controllers");
                    # Stop the BE Processor
                    $ret = TestLibs::IntegCCBELib::NoFailureManager($coPtr);
                    if ( $ret == ERROR )
                    {
                        TestLibs::Logging::logError("Could not disable suicide state");
                    }
                }
                if ($$curTestParmHashPtr{"errortrapbe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping BE Proc <BEET>");
                        # Stop the BE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "BE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }
                if ($$curTestParmHashPtr{"errortrapfe"} eq "true")
                {
                    for ($i = 0; $i < $numCtrls ; $i++)
                    {
                        TestLibs::Logging::logInfo ("Stopping FE Proc <FEET>");
                        # Stop the FE Processor
                        $ret = TestLibs::IntegCCBELib::ErrorTrapController($coPtr->[$i], "FE");
                        if ( $ret == ERROR )
                        {
                            TestLibs::Logging::logInfo("Could not error trap BE");
                        }
                    }
                }

                TestLibs::Logging::logError("Controller state bad during TestSystemState2");
            }
        }  # End of Step Loop
    }
    return GOOD ;
}


##############################################################################
#
#          Name: HoldFEQLogicReset
#
#        Inputs: array of connected controller objects, the number of controllers
#                in the controller array, the number of loops to perform 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Holds the FE QLogic cards reset to induce a failover.
#
##############################################################################
sub HoldFEQLogicReset
{
    my ($coPtr, $numCtrls, $loopCount ) = @_;
    my $ctrl ;
    my $chan ;
    my $TestSteps ;
    my $Operation ;
    my $iface ;
    my $Results ;
    my $altFail ;
    my $altFailMap ;
    my $ret ;
    my %rsp ;
    my $i;
    my $j;
    my $k;
    my $l;
    my $t;
    my @serialNums ;
    my @ifacesn;
    my @relativeiface ;
    my $index;
    my @map ;


    ########################################
    # You must also have the Net::Telnet   #
    # library. This file is in the release #
    # directory (  \Test\PerlLibs\Net  )   #
    # and can be copied to your perl       #
    # directory ( C:\Perl\site\lib\Net )   #
    ########################################
       
#    use Net::Telnet ();



    $TestSteps = [  [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #1
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #2
                    [FAIL, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #3
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #4
                    [FAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #5      
                    [FAIL, CONSTA2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #6
                    [FAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],  #7
                    [UNFAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],#8
                    [FAIL, CONSTA3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #9
                    [FAIL, CONSTB2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #10
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #11
                    [FAIL, CONSTA1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #12
                    [FAIL, CONSTB3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #13
                    [UNFAIL, CONSTA3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #14
                    [FAIL, CONSTA2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #15
                    [UNFAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #16
                    [FAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #17
                    [UNFAIL, CONSTA2, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #18
                    [FAIL, CONSTA3, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #19
                    [UNFAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #20
                    [FAIL, CONSTB0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #21
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #22
                    [FAIL, CONSTB1, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #23
                    [UNFAIL, CONSTB0, CONSTB1, CONSTB2, CONSTB3, ENDCTRLS, 0, 0, 0],#24
                    [UNFAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                  #25
                    [FAIL, CONSTA0, ENDCTRLS, 0, 0, 0, 0, 0, 0],                    #26
                    [UNFAIL, CONSTA0, CONSTA1, CONSTA3, ENDCTRLS, 0, 0, 0, 0],      #27
                    [FAIL, CONSTB0, CONSTB1, CONSTB2, CONSTB3, ENDCTRLS, 0, 0, 0],  #28
                    [UNFAIL, CONSTB0, CONSTB1, CONSTB2, CONSTB3, ENDCTRLS, 0, 0, 0],#29
                    [FAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],  #30
                    [UNFAIL, CONSTA0, CONSTA1, CONSTA2, CONSTA3, ENDCTRLS, 0, 0, 0],#31
                    [ENDSTEPS,0,0,0,0,0,0,0,0]
            ];
    $Results = [    [CONSTA1,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #1
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #2
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #3
                    [CONSTB0,CONSTB1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #4
                    [CONSTB1,CONSTB1,CONSTA2,CONSTA3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #5
                    [CONSTB1,CONSTB1,CONSTA3,CONSTA3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #6
                    [CONSTB1,CONSTB1,CONSTB2,CONSTB3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #7
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #8
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB2,CONSTB3],                  #9
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #10
                    [CONSTA1,CONSTA1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #11
                    [CONSTB1,CONSTB1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTB3,CONSTB3],                  #12
                    [CONSTB1,CONSTB1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTA2,CONSTA2],                  #13
                    [CONSTB1,CONSTB1,CONSTA2,CONSTA3,CONSTB1,CONSTB1,CONSTA2,CONSTA2],                  #14
                    [CONSTB1,CONSTB1,CONSTA3,CONSTA3,CONSTB1,CONSTB1,CONSTA3,CONSTA3],                  #15
                    [CONSTB1,CONSTB1,CONSTA3,CONSTA3,CONSTB0,CONSTB1,CONSTA3,CONSTA3],                  #16
                    [CONSTB0,CONSTB0,CONSTA3,CONSTA3,CONSTB0,CONSTB0,CONSTA3,CONSTA3],                  #17
                    [CONSTB0,CONSTB0,CONSTA2,CONSTA3,CONSTB0,CONSTB0,CONSTA3,CONSTA3],                  #18
                    [CONSTB0,CONSTB0,CONSTA2,CONSTA2,CONSTB0,CONSTB0,CONSTA2,CONSTA2],                  #19
                    [CONSTB0,CONSTB0,CONSTA2,CONSTA2,CONSTB0,CONSTB1,CONSTA2,CONSTA2],                  #20
                    [CONSTB1,CONSTB1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTA2,CONSTA2],                  #21
                    [CONSTA0,CONSTB1,CONSTA2,CONSTA2,CONSTB1,CONSTB1,CONSTA2,CONSTA2],                  #22
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTA0,CONSTA0,CONSTA2,CONSTA2],                  #23
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #24
                    [CONSTA0,CONSTA0,CONSTA2,CONSTA2,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #25
                    [CONSTB0,CONSTB1,CONSTA2,CONSTA2,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #26
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #27
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTA0,CONSTA1,CONSTA2,CONSTA3],                  #28
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #29
                    [CONSTB0,CONSTB1,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],                  #30
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3]                   #31
               ] ;

    # no doubt this is more complicated than I want.
    # there are a couple of places where things do not have to move where you expect them to.
    # luck of the draw sort of thing.  So we need to plan for that.
    # This is the altFail array.  the main index is the current step.  The second index
    # breaks out to number of alternate maps and where in the altFailMap array it's alternate
    # map starts.
    $altFail = [
                    [0,0],                                                          # 1
                    [0,0],                                                          # 2
                    [0,0],                                                          # 3
                    [1,0],                                                          # 4
                    [0,0],                                                          # 5
                    [0,0],                                                          # 6
                    [1,1],                                                          # 7
                    [0,0],                                                          # 8
                    [0,0],                                                          # 9
                    [0,0],                                                          # 10
                    [0,0],                                                          # 11
                    [0,0],                                                          # 12
                    [0,0],                                                          # 13
                    [0,0],                                                          # 14
                    [0,0],                                                          # 15
                    [0,0],                                                          # 16
                    [0,0],                                                          # 17
                    [0,0],                                                          # 18
                    [0,0],                                                          # 19
                    [0,0],                                                          # 20
                    [0,0],                                                          # 21
                    [0,0],                                                          # 22
                    [0,0],                                                          # 23
                    [0,0],                                                          # 24
                    [0,0],                                                          # 25
                    [1,2],                                                          # 26
                    [0,0],                                                          # 27
                    [3,3],                                                          # 28
                    [0,0],                                                          # 29
                    [3,6],                                                          # 30
                    [0,0],                                                          # 31
               ] ;
    $altFailMap = [                     
                    [CONSTB1,CONSTB0,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],  # alt for step 4
                    [CONSTB1,CONSTB1,CONSTB3,CONSTB2,CONSTB1,CONSTB1,CONSTB2,CONSTB3],  # alt for step 7
                    [CONSTB1,CONSTB0,CONSTA2,CONSTA2,CONSTB0,CONSTB1,CONSTB2,CONSTB3],  # alt for step 26
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTA1,CONSTA0,CONSTA2,CONSTA3],  # alt for step 28
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTA1,CONSTA0,CONSTA3,CONSTA2],
                    [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTA0,CONSTA1,CONSTA3,CONSTA2],
                    [CONSTB1,CONSTB0,CONSTB2,CONSTB3,CONSTB0,CONSTB1,CONSTB2,CONSTB3],  # alt for step 30
                    [CONSTB1,CONSTB0,CONSTB3,CONSTB2,CONSTB0,CONSTB1,CONSTB2,CONSTB3],
                    [CONSTB0,CONSTB1,CONSTB3,CONSTB2,CONSTB0,CONSTB1,CONSTB2,CONSTB3]
                  ] ;

    # some initial setup.

    my $masterIndex;
    my @startingTmap;
    my @activeServers;
    my @initialVdisks;
    my @pdiskData;
    my @vdiskData;
    my @raidData;

    # Find the Master, do not assume 
    $masterIndex = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ($masterIndex == INVALID)
    {
        TestLibs::Logging::logError ("Failed to find the Master controller, needed to fail a controller");
    }
    
    # Gather initial data and check some system states
    $ret = TestLibs::Validate::CheckAtStart($coPtr, $masterIndex, \@serialNums, \@startingTmap,
            \@activeServers, \@initialVdisks, \@pdiskData, \@vdiskData, \@raidData);
    if ( $ret == ERROR )
    {
        logError("Controller state bad during CheckAtStart");
    }

    # okay get our controller SNs.
    for ($i = 0; $i < $numCtrls ; $i++)
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coPtr->[$i]);
        # setup ifacesn and relativeiface
        for ($j = 0; $j < 4; $j++)
        {
            $k = $i*4 + $j ;            # $ith controller
            $ifacesn[$k] = $serialNums[$i] ;    # we are on the $ith controller
            $relativeiface[$k] = $j ;   # $jth iface of the $ith controller
        }
    }
    


    # big loop.
    # full test runs loopcount times.
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        logInfo ("Executing FE Failover Test\n") ;
        logInfo ("Holding QLogic cards in reset to induce failover.\n") ;

        #make sure targets are mapped to A0, A1, CONSTA2, CONSTA3, CONSTB0, CONSTB1, CONSTB2, B3
        logInfo("Checking Initial State\n") ;

#        my %initialstate = GetTargetStatus($coPtr->[$masterIndex]);
#        LogTargetStatus( %initialstate);
#
#        @map = CreateTargetMap( \@serialNums, %initialstate);

        $ret = GroupTargetMap($coPtr, \@serialNums, \@map, $masterIndex, LOGTARGETSTATUS);
        if ( $ret != GOOD )  {return ERROR; }



        # okay, we have 
        $ret = CompareTargetMap(\@map, $Results->[30]); # item 30 in the result list is a default map
        if ($ret == GOOD)
        {
            logInfo("Initial State - Ok\n") ;
        }
        elsif ($ret == ERROR)
        {
            logInfo("Initial State - Invalid!\n"); 
            logInfo("Expected - \n");
            PrintTargetMap($Results->[30]);
            logInfo("Found - \n");
            PrintTargetMap(\@map);
            return ERROR ;
        }
        else
        {
            logInfo ("Unknown Error!\n"); 
            return ERROR ;
        }

        logInfo ("Start main loop $i\n");
        for ($j=0; $TestSteps->[$j][0] != ENDSTEPS; $j++)
        {
            $Operation = $TestSteps->[$j][0] ;
            logInfo("Loop $i  Step $j\n");

            for ($k=1; $TestSteps->[$j][$k] != ENDCTRLS ; $k++)
            {
                MyPrintStep ($Operation) ;
                print " " ;
                $iface = $TestSteps->[$j][$k] ;
                $ret = _MyPrintInterface($iface);
                if ($ret == ERROR)
                {
                    logInfo ("Exiting Test\n") ;
                    return ERROR ;
                }
                logInfo ("\n") ;

                # convert from Validate style iface to a simple index.  (A0 is 0, B3 is 7)
                $index = _MyIndex($iface);

                # okay, which controller and which ql.
                my $ctlr;
                if ($index < 4)
                {
                    $ctlr = $coPtr->[0] ;
                    $chan = $index - 4 ;
                }
                else
                {
                    $ctlr = $coPtr->[1] ;
                    $chan = $index ;
                }
                
                #fail ?
                if ($Operation == FAIL)
                {
                    logInfo("    Putting QLogic channel $chan into reset.\n");
                    %rsp = $ctlr->resetQlogicFE($chan, 1);
                }
                else
                {
                    logInfo("    Initing QLocig channel $chan\n") ;
                    %rsp = $ctlr->resetQlogicFE($chan, 0);
                    DelaySecs(10);
#                    logInfo ("    Unfailing $relativeiface[$index] on $ifacesn[$index]\n") ;
#                    _unFailInterface($coPtr->[$masterIndex], $ifacesn[$index], $relativeiface[$index]) ;
                }
                if (%rsp)
                {
                    if ($rsp{STATUS} != PI_GOOD)
                    {
                        logInfo("    ====> Error resetting the QL card. <====");
                        PrintError(%rsp);
                        return ERROR;
                    }
                }
                else
                {
                    logInfo("    ====> Did not receive a response packet (resetQlogicXX) <====");
                    return ERROR;
                }
            }

            #wait xxx seconds 
            DelaySecs (90) ;
            
            # check output here

#            my %stuff = GetTargetStatus($coPtr->[$masterIndex]);
#            LogTargetStatus( %stuff);
#
#            @map = CreateTargetMap( \@serialNums, %stuff);

            $ret = GroupTargetMap($coPtr, \@serialNums, \@map, $masterIndex, LOGTARGETSTATUS );
            if ( $ret != GOOD )  {return ERROR; }
            
            # okay, we have 
            $ret = CompareTargetMap(\@map, $Results->[$j]);

            # unfortunately this isn't as deterministic as I would like so
            # if THAT didn't work we see if we have other maps to check.
            if ($ret != GOOD)
            {
                #okay, atlFail[x][0] is number of alternate failover maps available
                # altFail[x][1] is the index of the first map in the altFailMAp list
                #okay, check if we have an alternate failover map
                if ($altFail->[$j][0] > 0)
                {
                    logInfo ("Checking alternative failover maps\n") ;
                    my $done = 0 ;
                    for ($k = 0; $k < $altFail->[$j][0] && $done == 0; $k++)
                    {
                        $index = $altFail->[$j][1] + $k ;   # 1 points to the starting index and we go $k in.
                        $ret = CompareTargetMap(\@map, $altFailMap->[$index]);
                        if ($ret == GOOD)
                        {
                            $done = 1;
                        }
                        
                    }

                }
            }
            # for good or ill we are done with this entry.
            if ($ret == GOOD)
            {
                logInfo("Success!\n") ;
            }
            elsif ($ret == ERROR)
            {
                logInfo ("Incorrect Result!\n"); 
                logInfo ("Expected - \n");
                PrintTargetMap($Results->[$j]);
                logInfo ("Found - \n");
                PrintTargetMap(\@map);
                return ERROR ;
            }
            else
            {
                logInfo ("Unknown Error!\n"); 
                return ERROR ;
            }
            logInfo ("\n") ;
        }
    }
    return GOOD ;
}



##############################################################################
##############################################################################

##############################################################################
#
#          Name: BrocadeLoop
#
#        Inputs: item index list pointer, 
#                controller object list pointer,
#                Moxa IP Address list pointer, 
#                Brocade switch IP address list pointer,
#                Moxa/Brocade map pointer,  
#                Stress,
#                loop count
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: A loop that tests the Brocade switches in our application
#                We test the effects of rebooting, rezoning, power cycling,
#                LIPs. Validation consists of making sure the portmaps are 
#                unchanged. This is alogrithmically similar to the 
#                failover loop.
#
##############################################################################
sub BrocadeLoop
{
    my ( $coPtr, $bipPtr, $buPtr, $bpwPtr, $mipPtr, $mmPtr, $stress, $loops) = @_;
    # declare variables

    # we need the following info:
    # $coPtr  object list pointer for controllers
    # $mipPtr pointer to moxa controller list
    # $mmPtr  pointer to list of associated moxa channels
    # $bipPtr pointer to list of Brocade IP addrs
    # $stress which stress to use
    # $loops  how many times to do this

    my $i;
    my $master;
    my $ret;
    my $p1;
    my $p2;
    my $p3;
    my $p4;
    my $p5;
    my $slave;
    my @mNodes;
    my @sNodes;
    my $timeOut;

    my @coList;
    my @mipList;
    my @mmList;
    my @bipList;
    my $startPorts;
    my %statsB;
    

    @coList  = @$coPtr;
    @mipList = @$mipPtr;
    @mmList  = @$mmPtr;
    @bipList = @$bipPtr;


    # collect initial environment data, WWNs, configuration, whatever.

    # we are going to do this for a 2 way, not "N-WAY"  This is, after all,
    # a test to validate a switch and not the controller.


print "\n";
print "BrocadeLoopParameters:\n";
print "controller objects: @coList \n";
print "     Moxa IP addrs: @mipList \n";
print "     Moxa channels: @mmList \n";
print "  Brocade IP addrs: @bipList \n";
print "       Test stress: $stress\n";
print "        Loop Count: $loops \n";
print "\n";

    # zero out all the counters we make
    
    $statsB{PC} = 0;
    $statsB{RZ} = 0;
    $statsB{RQ} = 0;
    $statsB{RQA} = 0;
    $statsB{LIP} = 0;
    $statsB{LIPA} = 0;
    $statsB{RB} = 0;
    $statsB{PDC} = 0;

    $slave = 0;

    $master = FindMaster($coPtr);

    if ($master == 0)
    {
        $slave = 1;
    }

    @mNodes = FENodes( $coList[$master] );
    @sNodes = FENodes( $coList[$slave] );

    $startPorts = GetFEPortMap( $coPtr, 2);

    
    # we know what is here, now start the actual test

    # loop for the desired number of times 
    for ( $i = 0; $i < $loops; $i++ )
    {
        logInfo("--------------------------------------------------------------------");
        logInfo("                     Begin Brocade loop # $i . ");
        logInfo("--------------------------------------------------------------------");

        # determine the specifics of the stress we will apply
        ($p1, $p2, $p3, $p4, $p5) = BrocadeStressDetermine( $stress, $i, $coPtr, $mipPtr, $mmPtr, $bipPtr  );

        if ( $p1 eq "INVALID" )
        {
            # note: string compare was required
            logInfo("Error determining the specific details for the stress");
            return ERROR;
        }

        CtlrLogTextAll($coPtr, "Applying stress $p1 for the Brocade test, loop # $i ");

        # apply whatever stress we are using 
        $ret = BrocadeStressApply( $p1, $p2, $p3, $p4, $p5);

        if ($ret == ERROR) 
        {
            logInfo("Error while appling a stress to the Brocade switch");
            return ERROR;
        }

        $statsB{$p1}++;         # keep count by type of stress used

        # Verify we are really ready to resume
        
        $timeOut = 400;              # need longer for switch to reboot

        $ret = AreWeAlive($coPtr, $timeOut, $startPorts);
        
        if ( $ret != GOOD)
        {
            if ($ret == ERROR)
            {
                logInfo("An error occurred while waiting for the system to recover");
                logInfo("from the applied Brocade stress.");
                return ERROR;
            }
            
            if ( $ret == INVALID )
            {
                logInfo("We timed out ($timeOut seconds) while waiting for the system ");
                logInfo("to r4evocer from the applied Brocade stress.");
                return ERROR;
            }
        }

        # wait for the system to stabilize/recover
        logInfo("Pause an additional 60 seconds");
        DelaySecs(60);

        # evaluate the response to the stress/check system state
        
        CtlrLogTextAll($coPtr, "Checking system for the Brocade test, loop # $i ");
                
        $ret = BrocadeCheck1( $coList[$master], $coList[$slave], \@mNodes, \@sNodes );
        if ( $ret == ERROR )
        {
            logInfo("Status check after applying stress has failed");
            return ERROR;
        }
        

        # if necessary, undo any stress
        if ( $p1 eq "something we need to recover from")
        {
            # reverse the stress (Probably only needed for a Zoning change )

            # wait for stabilization

            # validate response
        }

        # print some interim status/statistics
        
        if ( (($i + 1) % 25) == 0 )
        {
            logInfo(" -------------------   Current Summary  ------------------------");
            PostBStats(%statsB);
            logInfo(" ---------------------------------------------------------------");
        }

        # end loop
    }
    
    # show any statistics collected

    logInfo(" -------------------   Test Summary   --------------------------");
    PostBStats(%statsB);
    logInfo(" ---------------------------------------------------------------");



     
    logInfo("Brocade loop completed ($i loops done).");

    return GOOD;


}

##############################################################################
#
#
##############################################################################



##############################################################################
#

##############################################################################

##############################################################################
#

##############################################################################
#

###############################################################################

=head2 FailOverLoop function

This is the main entry point for controller failover testing.



=cut

=over 1

=item Usage:

 my $rc = FailOverLoop($coPtr, $moxaIP, $moxaPtr, $failType, $loopCount, 
                  $tld, $rcd, $w4st, $inFlags   );
 
 where: $coPtr is a pointer to a list of controller objects
        $moxaIP is the ip address of the moxa controller
        $moxaPtr is a pointer to a list Moxa channel letters
        $failType is the type of failure to use
        $loopCount is the number of test loops to do
        $tld is the duration of the time line during failover/back
        $rcd is the reconnect delay
        $w4st is delay for the wait to get to the desired power up state
        $inFlags is flag byte 


    Failtype is one of: PC   (power cycle contoller)
                        FC   (issue fail controller command)
                        BEET (BE error trap)
                        FEET (FE error trap)
                        CCBET (CCB error trap)
                        RND  (random one of the above)
                        RET  (random error trap)

    inFlags is a bitmap of:
                        1 ( no server IO fail)
                        2 ( no BE chack fail)
                        4 ( no initial BE chack fail)

    Defaults for some parameters:
                        loopCount  2000
                        tld 120 (seconds)
                        rcd  60
                        w4st 360 
                        inFlags 0  (all checks done)

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 I/O must be something that is consistent over time. There should be both
 writes and reads to used vdisks.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut




##############################################################################
#
#          Name: FailOverLoop
#
#        Inputs: controller list pointer, Moxa IP Address, Moxa,  how to fail, loop count
#                time line duration, reconnect delay, wait for state time, flags
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Loop that tests failover for various failure types
#                Uses the moxa to cycle power   
#                Loop Count defaults to 2000 if not specified
#
##############################################################################
sub FailOverLoop
{
    trace();                        # This allows function tracability

    my ($coPtr, $moxaIP, $moxaPtr, $failType, $loopCount, $tld, $rcd, $w4st, $inFlags, $fCtlPtr, $xtcPtr, $mrw ) = @_;

    my $loop1;
    my $i;
    my $initMaster;
    my $initMasterSN;
    my $newMaster;
    my $slaveSN;
    my $masterSN;
    my $numCtlrs;
    my $j;
    my $chn;
    my $ret;
    my $failCount;
    my @serialNums;
    my $how2fail;
    my $tempMaster;

    my @startingTmap;
    my @initialVdisks;
    my %info1;
    my $vdiskListPtr;
    my @vCounts;
    my @sCounts;
    my @activeServers;

    my %mirrorData;
    my @moxaMap;
    my @moxaList;

    @moxaMap = @$moxaPtr;
    @moxaList = @$moxaIP;


    my @coList;
    @coList = @$coPtr;

    my $timelineDuration;
    my $reconnectDelay;
    my $wait4stateTime;
    my $flags;

    my %raidsHash; 
    my %pdisksHash;
    my %vdisksHash;
    
    my $MRWTimeout;

    my @deadList;                 # list of controller indices known to be 
                                  # dead, failed off, etc. skipped by 
                                  # timeline

    my $xtcDPtr = 0;              # same valueas the global xtcDataPtr;
    
    my $CBWminutes = 5;           # Countdown timer (WrtCache batteries)
        
    my $productID =  getMagProductID( 0, @coList );  # Get the product ID

    #################################################################
    ############## Neal, all numbers here ###########################
    #################################################################
    $flags = 0;
    
    if ($productID == 2750)
    {
    #
    # Reduce the timimgs for the 750 product.  All others do not change
    #
    
    $timelineDuration = 60;        # this is how long the time line runs

    
    $reconnectDelay = 45;           # this is how long we wait before 
                                    # attempting to reconnect after 
                                    # power cycle
                                    
    $wait4stateTime = 60;          # how long we wait for the controller
                                    # to be sufficiently booted  
                                    
    $MRWTimeout = 30;               # time allowed for resync to finish                                
    
        if (defined $xtcPtr)
        {
            if ( $xtcPtr > 0 )
            {   
                $xtcDPtr = $xtcPtr;
            }
        }

    
    }                                                                    
    else
    {
    #
    # Check for valid timings for 1000/3000 product.  
    #
    $timelineDuration = 120;        # this is how long the time line runs

    
    $reconnectDelay = 60;           # this is how long we wait before 
                                    # attempting to reconnect after 
                                    # power cycle
                                    
    $wait4stateTime = 360;          # how long we wait for the controller
                                    # to be sufficiently booted  
                                    
    $MRWTimeout = 30;               # time allowed for resync to finish                                
    
    
        if (defined $xtcPtr)
        {
            if ( $xtcPtr > 0 )
            {   
                $xtcDPtr = $xtcPtr;
            }
        }

        if (defined $mrw)
        {
            if ( $mrw > 0 )
            {   
                $MRWTimeout = $mrw;
            }
        }


        if (defined $tld)
        {
            if ( $tld > 0 )
            {   
                $timelineDuration = $tld;
            }
        }
    
        if (defined $rcd)
        {
            if ( $rcd > 0 )
            {   
                $reconnectDelay = $rcd;
            }
        }
    
        if (defined $w4st)
        {
            if ( $w4st > 0 )
            {   
                $wait4stateTime = $w4st;
            }
        }

    }

    if (defined $inFlags)
    {
        if ( $inFlags >= 0 )
        {   
            $flags = $inFlags;
        }
    }

    # Default to 2000 loops unless specified
    if (defined $loopCount)
    {
        if ($loopCount < 1 )
        {
            $loop1 = 2000;
        }
        else
        {
            $loop1 = $loopCount;
        }
    }



    logInfo("");
    logInfo(" Test parameters:");
    logInfo("     Time line duration: $timelineDuration");
    logInfo("        reconnect delay: $reconnectDelay");
    logInfo("    wait for state time: $wait4stateTime");
    logInfo("                  flags: $flags");
    logInfo("             loop count: $loop1"); 
    logInfo("         Failure method: $failType"); 
    logInfo("       XTC data pointer: $xtcDPtr"); 
    logInfo("     Mirror Resync Wait: $MRWTimeout");
    logInfo("");




#  return GOOD;





    #################################################################
    #################################################################
    #################################################################
    
    
    $numCtlrs = scalar( @coList );

    $failType = uc ( $failType );          # convert to upper case

    $ret = ValidateType ( $failType , $fCtlPtr);
    if ( $ret == ERROR )
    {
        logError("    ====> Unusable failure type specified  ( $failType ) <====");
        return ERROR;
    }

        
    # 
    # check ability to control the moxa power here. It beats waiting to have
    # a failed controller and no way to unfail it. The test just turns ON all
    # ports passed in to the test. 
    #     
        
    $ret = PowerCheck ($moxaIP, $moxaPtr);
    if ( $ret !=0 )
    {
        logError("    ====> Error: unable to control one or more Moxa ports <====");
        return ERROR;
    }

    ##########################################################################

    #
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    #


    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #
    
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
    }


    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $newMaster == INVALID )
    {
        logError("    ====> Failed to find the master controller [$failCount failovers completed] <====");
        return ERROR;
    }


    if ( 1 == GotRaid5($coList[$newMaster]) )
    {
        logInfo ( "Raid 5 configured in system, making sure R5 resync bit set.");
        $flags = $flags | ADD_R5RESYNC_CHECK;
    } 

 
    #
    # Wait for batteries to be charged
    #
    $ret = WrtCacheWaitForBatteries($coPtr, 12 * $CBWminutes);
    
 
    #
    # Rel 3.1 adds resync, need to wait for it to complete
    #
    logInfo( "Making sure all mirror resync is complete at start of test.");
    $ret = MirrorResyncWait($coPtr, 4 * $MRWTimeout);
    if ($ret != GOOD)
    {
        logInfo("Failed Mirror Resync wait at start of test.");
        return ERROR;
    }

    $ret = MirrorInitialData( $coPtr, \%mirrorData);


# return (GOOD);    
    #
    # display some starting info
    #
    
    $ret = TestLibs::IntegCCBELib::DispPdiskInfo($coList[$newMaster]);

    if ( $ret == ERROR )
    {
        logError("Failed to get pdisk info at start");
        return ERROR;
    }

    
    #
    # Add a pdisks FWV
    #

    %info1 = $coList[$newMaster]->physicalDisks();
    if ( ! %info1  )
    {
        logInfo("    ====> Failed to get response from physicalDisks <====");
        return ERROR;
    }
    if ($info1{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get physicalDisks info <====");
        PrintError(%info1);
        return ERROR;
    }

    logInfo(" Physical disk firmware information ");

    logPhysicalDisks("FWV", %info1);

    logInfo(" ");
    



    $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$newMaster] );
    if ( $ret == ERROR )
    {
        logError("Failed to get target list at start");
        return ERROR;
    }

    $failCount = 0;
    if ( $xtcDPtr )
    {
        $xtcDPtr->{TESTLOOPS} =  $failCount;
    }

    #
    # check to sse that everything is good at the start
    #

    logInfo("Check to see if everything is functioning at the start of the test");
    $ret = TestBEState($coPtr);

    if ( ($ret != GOOD) && !(NO_STARTUP_CHECK & $flags) )
    {
        logInfo("Test of the BE state failed");
        return ERROR;
    }

    #
    # find the currently active servers
    #
    
    logInfo("Getting initial data for activity measurements.");

    @vCounts = GetVdiskActivityCounts($coPtr);
    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);


    #
    # get the initial/starting target map
    #

    logInfo("Getting the target status, then building the target map");
    
#    %info1 = GetTargetStatus($coList[$newMaster]);
#
#    if ( ! %info1  )              # if no data from call
#    {
#        logInfo(">>>>>>>> Failed to get a response from GetTargetStatus <<<<<<<<");
#        return ERROR;
#    }
#
#    if ( $info1{STATUS} != PI_GOOD )      # if call returned an error
#    {
#        logInfo(">>>>>>>> Error from GetTargetStatus <<<<<<<<");
#        PrintError(%info1);
#        return ERROR;
#    }
#    
#    @startingTmap = CreateTargetMap(\@serialNums, %info1);
#    
#    PrintTargetMap (\@startingTmap);


    $ret = GroupTargetMap($coPtr, \@serialNums, \@startingTmap, $newMaster, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }



    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );

    $vdiskListPtr  = \@initialVdisks;

    if ( scalar(@initialVdisks) != 0 )
    {
        # we have some active vdisks
        if ( $initialVdisks[0] == INVALID )
        {
            # error case 
            logInfo("    ====> Warning - can't get an initial active vdisklist  <====");
            $vdiskListPtr  = 0;   # clear the point so we skip the following tests
        }
    }
    
    #
    # Check BE hashes (raids, pdisks, vdisks)
    #
    $ret = CheckBEHashes( \%mirrorData);
    if ( $ret == ERROR )
    {
        logInfo("Initial BE Hash indicated a bad state.");
        return ERROR;
    }

    #
    # startup parity scan, if we are doing any in the loop
    #
    if (  (ADD_PARITY_SCAN & $flags) || (ADD_MORE_PARITY_SCANS & $flags) )
    {
        # parity scan the world
        $ret = TestLibs::BEUtils::PScanCheck( \@coList, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("Initial parity scan reported an error - test failed.");
            return ERROR;
        }
    }


    #
    # The loop that is really the test
    #

    for ( $i = 0; $i < $loop1; $i++ )
    {
        # find the master,
        logInfo("Searching for the master controller in the group [$failCount failovers completed]");
        $initMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
        if ( $newMaster == INVALID )
        {
            logError("    ====> Failed to find the master controller [$failCount failovers completed] <====");
            return ERROR;
        }

        #
        # First we loop thru all the slaves and fail each one of them
        #

        for ( $j = 0; $j < $numCtlrs; $j++ )
        {
            if ( $j != $initMaster )     # for each slave ( actually, each non-master )
            {
                # get slave SN
                $slaveSN = TestLibs::IntegCCBELib::GetSerial( $coList[$j] );

                # decide how to fail the slave
                $how2fail = GetFailMethod($failType);

                # if we are going to ET the CCB, then we need to tweak 
                # the config of the controller a bit

                if ( $how2fail eq "CCBET" )
                {
                    $ret = TestLibs::IntegCCBELib::SuicideOK ($coPtr);
                    if ( $ret == ERROR )
                    {
                        logError("    ====> Failed to enable suicide for proc <====");
                        return ERROR;
                    }
                }

                logInfo("Failing a slave controller ($serialNums[$j], $how2fail) [$failCount failovers completed] ");

                ########################
                # now force the failure
                ########################
                
                CtlrLogTextAll(\@coList , "Forcing slave controller $serialNums[$j] to fail ($how2fail).");
                CtlrLogTextAll(\@coList , "Failovers completed = $failCount.");

                if ( $how2fail eq "PC" )
                {
                    # brute force power cycle handled here
                    $ret = TestLibs::IntegCCBELib::PowerChange($moxaList[$j], $moxaMap[$j], 0);
                    if ( $ret == ERROR )
                    {
                        logError("    ====> Failed to power down the controller [$failCount failovers completed] <====");
                        return ERROR;
                    }
                }
                elsif (  $how2fail eq "BEPULL" ||  $how2fail eq "FEPULL"  )
                {
                    # generic external function handler
                    $ret = ExtControl($j, $how2fail, "FAIL" , $fCtlPtr);
                    if ( $ret == ERROR )
                    {
                        logError("    ====> Failed to externally fail the controller [$failCount failovers completed] <====");
                        return ERROR;
                    }

                }
                else
                {
                    # other forms of failure here
                    $ret = FailOverController($coPtr, $j, $how2fail);
                    if ( $ret == ERROR )
                    {
                        logError("    ====> Could not fail the controller [$failCount failovers completed] <====");
                        return ERROR;
                    }
                }

                # allow all failover activity to complete and the 
                # servers to complete some operations
                logInfo("Pause for $timelineDuration seconds");        
#                DelaySecs(120);
                
                logInfo(" [$failCount failovers completed] ");

                #FailOverTimeLine( $coList[$initMaster], $timelineDuration, \@serialNums, 0);
                @deadList = ($j);
                FailOverTimeLineNway( $coPtr, $timelineDuration, \@serialNums, \@deadList);

                ##########################################################
                #
                # Test the state of the system (one controller IS failed)
                #
                ##########################################################

                logInfo(" [$failCount failovers completed] ");


                # ADD_R5RESYNC_CHECK

                if (  ADD_R5RESYNC_CHECK & $flags  )
                {
                    # wait for resync to finish on all raids
                    $ret = TestLibs::Validate::R5ResyncCheck( \@coList, 0, INVALID );
                    if ( $ret != GOOD )
                    {
                        logInfo("R5 resync check reported an error - test failed.");
                        return ERROR;
                    }
                }

                #
                # verify all write cache is unchanged
                #
                $ret = WrtCacheValidateCacheUnchanged($coPtr, \%mirrorData);
                if ( $ret != GOOD )
                {
                    logInfo("Write cache has changed");
                    return (ERROR);
                }

                #
                # Rel 3.1 adds resync, need to wait for it to complete
                #
                my @liveObjects;
                GetLiveObjects($coPtr, \@deadList, \@liveObjects);
                
                $ret = MirrorResyncWait(\@liveObjects, $MRWTimeout);
                if ($ret != GOOD)
                {
                    logInfo("Failed Mirror Resync wait.");
                    $ret = MirrorCheck( \@liveObjects, \%mirrorData);
                    return ERROR;
                }

                $ret = MirrorCheck( \@liveObjects, \%mirrorData);
                if ($ret != GOOD)
                {
                    logInfo("Failed Mirror State Check.");
                    return ERROR;
                }

                $ret = TestLibs::Validate::TestSystemState1(\@coList, \@activeServers, 0, $vdiskListPtr, \@serialNums);
                if ( ($ret == ERROR) && !(NO_SERVER_CHECK & $flags) )
                {
                    logInfo("    ====> Controller state bad with slave failed [$failCount failovers completed] <====");
                    return ERROR;
                }


                if (  $how2fail eq "BEPULL" ||  $how2fail eq "FEPULL"  )
                {
                    # generic external function handler
                    $ret = ExtControl($j, $how2fail, "RESTORE" , $fCtlPtr);
                    if ( $ret == ERROR )
                    {
                        logError("    ====> Failed to externally fail the controller [$failCount failovers completed] <====");
                        return ERROR;
                    }

                }

                # an FEPULL should not fail the controller so we can skip the next 
                # group of operations

                if (  $how2fail ne "FEPULL"  )
                {
                    # power cycle the slave
                    logInfo("Power Cycle the dead slave controller ($serialNums[$j]) [$failCount failovers completed] ");
                    $ret = TestLibs::IntegCCBELib::PowerCycle($moxaList[$j], $moxaMap[$j]);
                    if ( $ret == ERROR )
                    {
                        logError("    ====> Failed to power cycle the controller [$failCount failovers completed] <====");
                        return ERROR;
                    }

                    # need to reconnect to the controller
                    logInfo("Pause for 60 seconds and reconnect to slave($serialNums[$j]) [$failCount failovers completed] ");
                    $ret = TestLibs::IntegCCBELib::Reconnect( $coList[$j], $reconnectDelay );
                    if ( $ret == ERROR )
                    {
                        logError("    ====> Failed to reconnect to the controller [$failCount failovers completed] <====");
                        return ERROR;
                    }
        
                    # wait for the controller to sufficiently boot
                    Wait4MinPowerUpState($coList[$j], POWER_UP_INACTIVE, $wait4stateTime);          


                    # find the master, if it changed
                    logInfo("Searching for the master controller in the group");
                    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
                    if ( $newMaster == INVALID )
                    {
                        logError("    ====> Failed to find the master controller [$failCount failovers completed] <====");
                        return ERROR;
                    }

                    #
                    # unfail the slave
                    #
                
                    logInfo("Unfailing the controller ($serialNums[$newMaster], $slaveSN) [$failCount failovers completed] ");
                    $ret = TestLibs::IntegCCBELib::UnFailController( $coList[$newMaster], $slaveSN );
                    if (  $ret == ERROR )
                    {
                        logError("    ====> Failed to restore the controller to active duty [$failCount failovers completed] <====");
                        return ERROR;
                    }
                }

                # allow the failback to complete (takes about 1.5 minutes
                logInfo("-------- Pause as the controller fails back, $failCount failovers completed. -----------");
                #DelaySecs(120);
                #FailOverTimeLine( $coList[$newMaster], $timelineDuration, \@serialNums, $coList[$j]);
                @deadList = (INVALID);
                FailOverTimeLineNway( $coPtr, $timelineDuration, \@serialNums, \@deadList);
                
                ###################################################################
                #
                # Test the state of the system ( NO controllers should be failed )
                #
                ###################################################################

                logInfo(" [$failCount failovers completed] ");


# ADD_R5RESYNC_CHECK
                if (  ADD_R5RESYNC_CHECK & $flags  )
                {
                    # wait for resync to finish on all raids
                    $ret = TestLibs::Validate::R5ResyncCheck( \@coList, 0, INVALID );
                    if ( $ret != GOOD )
                    {
                        logInfo("R5 resync check reported an error - test failed.");
                        return ERROR;
                    }
                }


                #
                # Wait for batteries to come back
                #
                $ret = WrtCacheWaitForBatteries($coPtr, $CBWminutes);
                
                #
                # Batteries are still bad (return error)
                if ($ret != GOOD)
                {
                    logInfo("Failed: Batteries did not charge in time.");
                    return ERROR;
                }


                #
                # Rel 3.1 adds resync, need to wait for it to complete
                #
                $ret = MirrorResyncWait($coPtr, $MRWTimeout);
                if ($ret != GOOD)
                {
                    logInfo("Failed Mirror Resync wait.");
                    $ret = MirrorCheck( $coPtr, \%mirrorData);
                    return ERROR;
                }

                $ret = MirrorCheck( $coPtr, \%mirrorData);
                if ($ret != GOOD)
                {
                    logInfo("Failed Mirror State Check.");
                    return ERROR;
                }

                # check the front end conditions, server activity, target map, vdisk actifity
                $ret = TestLibs::Validate::TestSystemState1(\@coList, \@activeServers, \@startingTmap, $vdiskListPtr, \@serialNums);
                if (  ($ret == ERROR) && !(NO_SERVER_CHECK & $flags)  )
                {
                    logInfo("    ====> Controller state bad after slave unfailed [$failCount failovers completed] <====");
                    return ERROR;
                }
                
                logInfo(" [$failCount failovers completed] ");

                
                        #
                        # Added to allow EP testing to continue .. It gets Brady off my back
                        #
                        $ret = TestLibs::Validate::PScanReqdWait($coPtr, 0, 0);              # 2nd and 3rd parms are not used
                        if ( $ret == ERROR )
                        {
                            logError("    ====> Error while waiting for parity scans to complete [$failCount failovers completed] <====");
                            return ERROR;
                        }
                        # need to refresh the connection to the slave
                        $ret = TestNReconnectAll($coPtr);
                
                
                
                #
                # check the back end state, vdisk status, pdisk status, raid status
                #
                $ret = TestLibs::Validate::TestSystemState3($coList[$newMaster], \%mirrorData);
                if ( ($ret == ERROR) && !(NO_BED_CHECK & $flags) )
                {
                    logInfo("    ====> Controller state bad after slave unfailed [$failCount failovers completed] <====");
                    return ERROR;
                }
                $failCount++;

                ####################################################################
                #
                # Test the state of the system ( NO controllers should be failed )
                #
                ####################################################################

                logInfo(" [$failCount failovers completed] ");

                $ret = TestLibs::Validate::TestSystemState1(\@coList, \@activeServers, \@startingTmap, $vdiskListPtr, \@serialNums);
                if (  ($ret == ERROR) && !(NO_SERVER_CHECK & $flags)  )
                {
                    logInfo("    ====> Controller state bad after slave failure loop [$failCount failovers completed] <====");
                    return ERROR;
                }

                if (  ADD_MORE_PARITY_SCANS & $flags  )
                {
                    # parity scan the world
                    $ret = TestLibs::BEUtils::PScanCheck( \@coList, 0, INVALID );
                    if ( $ret != GOOD )
                    {
                        logInfo("Parity scan reported an error - test failed.");
                        return ERROR;
                    }
                }

            }   # end - if not master


        }   # end - slave/controller loop 
            
        #
        # verify all write cache is unchanged
        #
        $ret = WrtCacheValidateCacheUnchanged($coPtr, \%mirrorData);
        if ( $ret != GOOD )
        {
            logInfo("Write cache has changed");
            return (ERROR);
        }


        # begin - fail the master

        TestLibs::IntegCCBELib::DispVcgInfo($coList[$initMaster]); 
              
        # get master SN
        $masterSN = TestLibs::IntegCCBELib::GetSerial( $coList[$initMaster] );
        
        # fail the Master
        $how2fail = GetFailMethod($failType);

        # if we are going to ET the CCB, then we need to configure the 
        # controllers a bit first
        if ( $how2fail eq "CCBET" )
        {
            $ret = TestLibs::IntegCCBELib::SuicideOK ($coPtr);
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to enable suicide for proc <====");
                return ERROR;
            }
        }

        logInfo("Failing the master controller ($serialNums[$initMaster], $how2fail) [$failCount failovers completed] ");
        
        CtlrLogTextAll(\@coList , "Forcing master controller $serialNums[$initMaster] to fail ($how2fail).");
        CtlrLogTextAll(\@coList , "Failovers completed = $failCount.");

        # now we actually fail the controller
        if ( $how2fail eq "PC" )
        {
            # brute force power cycle handled here
            $ret = TestLibs::IntegCCBELib::PowerChange($moxaList[$initMaster], $moxaMap[$initMaster], 0);
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to power down the controller [$failCount failovers completed] <====");
                return ERROR;
            }
        }
        elsif (  $how2fail eq "BEPULL" ||  $how2fail eq "FEPULL"  )
        {
            # generic external function handler
            $ret = ExtControl($initMaster, $how2fail, "FAIL" , $fCtlPtr);
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to externally fail the controller [$failCount failovers completed] <====");
                return ERROR;
            }

        }
        else
        {
            # other forms of failure here
            $ret = FailOverController($coPtr, $initMaster, $how2fail);
            if ( $ret == ERROR )
            {
                logError("    ====> Could not Fail the master controller [$failCount failovers completed] <====");
                return ERROR;
            }
        }

        
        logInfo("Time line for $timelineDuration seconds");

        # can not use findmaster here as the master is moving at this time 
        # and we can't get a good number...
        # $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
        # so we are just going to have to use (one of) the slave(s)
        $tempMaster = 0;
        if ( $initMaster == 0 ) { $tempMaster = 1; }

        
        #FailOverTimeLine( $coList[$tempMaster], $timelineDuration, \@serialNums, 0);
        @deadList = ($initMaster);
        FailOverTimeLineNway( $coPtr, $timelineDuration, \@serialNums, \@deadList);
        #DelaySecs(120);

        # do this on something other than what we just failed
        ####################################################################
        #
        # Test the state of the system ( ONE controller should be failed )
        #
        ####################################################################
        
        logInfo(" [$failCount failovers completed] ");


# ADD_R5RESYNC_CHECK
        if (  ADD_R5RESYNC_CHECK & $flags  )
        {
            # wait for resync to finish on all raids
            $ret = TestLibs::Validate::R5ResyncCheck( \@coList, 0, INVALID );
            if ( $ret != GOOD )
            {
                logInfo("R5 resync check reported an error - test failed.");
                return ERROR;
            }
        }

        #
        # verify all write cache is unchanged
        #
        $ret = WrtCacheValidateCacheUnchanged($coPtr, \%mirrorData);
        if ( $ret != GOOD )
        {
            logInfo("Write cache has changed");
            return (ERROR);
        }

        my @liveObjects;
        GetLiveObjects($coPtr, \@deadList, \@liveObjects);
                
        #
        # Rel 3.1 adds resync, need to wait for it to complete
        #
        $ret = MirrorResyncWait(\@liveObjects, $MRWTimeout);
        if ($ret != GOOD)
        {
            logInfo("Failed Mirror Resync wait.");
            $ret = MirrorCheck( \@liveObjects, \%mirrorData);
            return ERROR;
        }
    
        $ret = MirrorCheck( \@liveObjects, \%mirrorData);
        if ($ret != GOOD)
        {
            logInfo("Failed Mirror State Check.");
            return ERROR;
        }


        $ret = TestLibs::Validate::TestSystemState1(\@coList, \@activeServers, 0, $vdiskListPtr, \@serialNums);
        if (  ($ret == ERROR) && !(NO_SERVER_CHECK & $flags)  )
        {
            logInfo("    ====> Controller state bad with master failed [$failCount failovers completed] <====");
            return ERROR;
        }


        if (  $how2fail eq "BEPULL" ||  $how2fail eq "FEPULL"  )
        {
            # generic external function handler
            $ret = ExtControl($initMaster, $how2fail, "RESTORE" , $fCtlPtr);
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to externally fail the controller [$failCount failovers completed] <====");
                return ERROR;
            }

        }

        # an FEPULL should not fail the controller so we can skip the next 
        # group of operations
        
        if (  $how2fail ne "FEPULL"  )
        {

            # power cycle the master
            logInfo("Power Cycle the dead (was master) controller ($serialNums[$initMaster]) [$failCount failovers completed] ");
            $ret = TestLibs::IntegCCBELib::PowerCycle($moxaList[$initMaster], $moxaMap[$initMaster ]);
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to power cycle the controller  [$failCount failovers completed] <====");
                return ERROR;
            }

            # need to reconnect to the controller
            logInfo("Pause for $reconnectDelay seconds and reconnect to the former master controller [$failCount failovers completed] ");
            $ret = TestLibs::IntegCCBELib::Reconnect( $coList[$initMaster], $reconnectDelay );
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to reconnect to the controller  [$failCount failovers completed] <====");
                return ERROR;
            }
     
            # wait for the controller to sufficiently boot
            Wait4MinPowerUpState($coList[$initMaster], POWER_UP_INACTIVE, $wait4stateTime);    


            # find the master, if it changed
            logInfo("Searching for the master controller in the group");
            $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
            if ( $newMaster == INVALID )
            {
                logError("    ====> Failed to find the new master controller  [$failCount failovers completed] <====");
                return ERROR;
            }

            # unfail the (old) master
            logInfo("Unfailing the controller  ($serialNums[$newMaster], $masterSN) [$failCount failovers completed] ");
            $ret = UnFailController( $coList[$newMaster], $masterSN );
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to make the controller useable [$failCount failovers completed]  <====");
                return ERROR;
            }
        }

        # allow failback to complete
        #FailOverTimeLine( $coList[$newMaster], $timelineDuration, \@serialNums, $coList[$initMaster]);
        @deadList = (INVALID);
        FailOverTimeLineNway( $coPtr, $timelineDuration, \@serialNums, \@deadList);
        #DelaySecs(120);

        ####################################################################
        #
        # Test the state of the system ( NO controllers should be failed )
        #
        ####################################################################

        # check the system state of the front end: server activity, vdisk activity, target map

        logInfo(" [$failCount failovers completed] ");

# ADD_R5RESYNC_CHECK
        if (  ADD_R5RESYNC_CHECK & $flags  )
        {
            # wait for resync to finish on all raids
            $ret = TestLibs::Validate::R5ResyncCheck( \@coList, 0, INVALID );
            if ( $ret != GOOD )
            {
                logInfo("R5 resync check reported an error - test failed.");
                return ERROR;
            }
        }


        #
        # Wait for batteries to come back
        #
        $ret = WrtCacheWaitForBatteries($coPtr, $CBWminutes);
        
        #
        # Batteries are still bad (return error)
        if ($ret != GOOD)
        {
            logInfo("Failed: Batteries did not fully charge in time.");
            return ERROR;
        }


        #
        # Rel 3.1 adds resync, need to wait for it to complete
        #
        $ret = MirrorResyncWait($coPtr, $MRWTimeout);
        if ($ret != GOOD)
        {
            logInfo("Failed Mirror Resync Wait.");
            $ret = MirrorCheck( $coPtr, \%mirrorData);
            return ERROR;
        }
        
        $ret = MirrorCheck( $coPtr, \%mirrorData);
        if ($ret != GOOD)
        {
            logInfo("Failed Mirror State Check.");
            return ERROR;
        }

        $ret = TestLibs::Validate::TestSystemState1(\@coList, \@activeServers, \@startingTmap, $vdiskListPtr, \@serialNums);
        if (  ($ret == ERROR) && !(NO_SERVER_CHECK & $flags)  )
        {
            logInfo("    ====> Controller state bad with (old) master unfailed  [$failCount failovers completed] <====");
            return ERROR;
        }
        
        logInfo(" [$failCount failovers completed] ");
   
                        #
                        # Added to allow EP testing to continue .. It gets Brady off my back
                        #
                        $ret = TestLibs::Validate::PScanReqdWait($coPtr, 0, 0);              # 2nd and 3rd parms are not used
                        if ( $ret == ERROR )
                        {
                            logError("    ====> Error while waiting for parity scans to complete [$failCount failovers completed] <====");
                            return ERROR;
                        }
                        # need to refresh the connection to the slave
                        $ret = TestNReconnectAll($coPtr);
   
        #
        # check the back end state, vdisk status, pdisk status, raid status
        #
        $ret = TestLibs::Validate::TestSystemState3($coList[$newMaster], \%mirrorData);
        if ( ($ret == ERROR) && !(NO_BED_CHECK & $flags) )
        {
            logInfo("    ====> Controller state bad after slave unfailed [$failCount failovers completed] <====");
            return ERROR;
        }


        if (  (ADD_PARITY_SCAN & $flags) || (ADD_MORE_PARITY_SCANS & $flags) )
        {
            # parity scan the world
            $ret = TestLibs::BEUtils::PScanCheck( \@coList, 0, INVALID );
            if ( $ret != GOOD )
            {
                logInfo("Parity scan reported an error - test failed.");
                return ERROR;
            }
        }

        # end - failing the master
     
        #
        # verify all write cache is unchanged
        #
        $ret = WrtCacheValidateCacheUnchanged($coPtr, \%mirrorData);
        if ( $ret != GOOD )
        {
            logInfo("Write cache has changed");
            return (ERROR);
        }

        $failCount++;
        if ( $xtcDPtr )
        {
            $xtcDPtr->{TESTLOOPS} =  $failCount;
        }

        logInfo("--------------------- Loop $i completed, $failCount failovers completed. -------------------");
    }
    # end loop

    logInfo("End of Fail Over Loop test, $failCount failovers completed.");
    return GOOD;

}
###############################################################################
###############################################################################

=head2 FailOverNWayLoop function

This is the main entry point for controller failover testing.



=cut

=over 1

=item Usage:

 my $rc = FailOverNWayLoop($coPtr, $moxaIP, $moxaPtr,  
                  $resListPtr, $parmsPtr, $fCtlPtr );
 
 where: $coPtr is a pointer to a list of controller objects
        $moxaIP is the ip address of the moxa controller
        $moxaPtr is a pointer to a list Moxa channel letters
        $resListPtr is a pointer to items that will be failed array
        $parmsPtr is a pointer to a hash  of misc parameters
        $fCtlPtr is a pointer to and array of strings for external 
                 control

    The parmsPtr hash has the following keys. Defaults in ()

        {FAILTYPE}     Failtype, see below
        {LOOPCOUNT}    Number of loops to do (2000)
        {TIMELINEDUR}  Duration of timeline in seconds (120)
        {RECONNECTDEL} Reconnect delay in seconds (60)
        {WAIT4STIME}   Timeout waiting for powerupstate (360)
        {FLAGS}        validation flags, see below (0)
        and others as needed.

    Failtype is one of: PC   (power cycle contoller)
                        FC   (issue fail controller command)
                        BEET (BE error trap)
                        FEET (FE error trap)
                        CCBET (CCB error trap)
                        RND  (random one of the above)
                        RET  (random error trap)
                        SITE (Geo-raid site)
                        FES  (Front end switch)
                        BES  (Back End switch)
                        RNDALL  (Random ctlr or switch)

    inFlags is a bitmap of:
                        1 ( no server IO fail)
                        2 ( no BE chack fail)
                        4 ( no initial BE chack fail)
                        8 ( add some parity scans)
                       16 ( add more parity scans)
                       32 ( add raid 5 resync check)


    ResListPtr pointed to an array of hashes. Each has the following
    keys.

        {TYPE}    Device type, see below
        {IPADDR}  IP Address of device
        {MOXAIP}  IP Address of associated Moxa
        {MOXACHAN} Channel(s) used on Moxa
        {   TBD }


=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 I/O must be something that is consistent over time. There should be both
 writes and reads to used vdisks.

 There should be no defrag, copy, or init operation running when the test 
 is started. 




=back

=cut




##############################################################################
#
#          Name: FailOverNWayLoop
#
#
##############################################################################
sub FailOverNWayLoop
{
    trace();                        # This allows function tracability

    my ($coPtr, $moxaIP, $moxaPtr, $resListPtr, $parmsPtr, $fCtlPtr, $xtcPtr ) = @_;

    my $loop1;
    my $i;
    my $initMaster;
    my $initMasterSN;
    my $newMaster;
    my $slaveSN;
    my $masterSN;
    my $numCtlrs;
    my $j;
    my $chn;
    my $ret;
    my $failCount;
    my @serialNums;
    my @serialNumss;
    my $how2fail;
    my $tempMaster;

    my @startingTmap;
    my @initialVdisks;
    my %info1;
    my $vdiskListPtr;
    my @vCounts;
    my @sCounts;
    my @activeServers;

    my %raidsHash; 
    my %pdisksHash;
    my %vdisksHash;

    my @moxaMap;
    my @moxaList;
    my %mirrorData;

    @moxaMap = @$moxaPtr;
    @moxaList = @$moxaIP;

    my @coList;
    @coList = @$coPtr;

    my $timelineDuration;
    my $reconnectDelay;
    my $wait4stateTime;
    my $flags;
    my $MRWTimeout;               # time allowed for resync to finish                                
    
    my @deadList;                 # list of controller indices known to be dead,
                                  # failed off, etc. skipped by timeline

    my $xtcDPtr = 0;              # same valueas the global xtcDataPtr;

 #   my @resources;                # things to fail and control parameters
 
    my %gcInfo;
    my $gcStatus;
    
    my $loopVal;                   # used for mirror validations
    my $loopRnd;
    my $mirrorVal;    

    my $CBWminutes = 5;            # Countdown timer (WrtCache batteries)

    logInfo("-------------------------------------------------------------");
    logInfo("------------------ N-way failover test ----------------------");
    logInfo("-------------------------------------------------------------");

    # Chris can't remember these
    logInfo("Grep on 'inner loop' to find inner loop starts in logs.");
    logInfo("Grep on 'failovers completed' to find how many loops were completed.");
    logInfo("Grep on 'PostSummary' to find how many failovers were completed by device.");

          
    #
    # What makes this test work is the @resources array. It contains
    # what to do, what to do it to and summary statistics. It is an 
    # array of hashs, one hash for each device that can be failed.
    #
    # Each has contains the following keys.
    #     {TYPE}        Device type, one of
    #                      NWF_CTLR  
    #                      NWF_DBAY  
    #                      NWF_FEBSW 
    #                      NWF_BEBSW 
    #                      NWF_BEQSW 
    #     {IPADDR}      IP Address of device
    #     {MOXAIP}      IP Address of associated Moxa
    #     {MOXACHAN}    Channel(s) used on Moxa
    #     {STATE}       current state of the device
    #     {HOWTOFAIL}   one of the possible failtypes
    #     {NUMFAILS}    number of times failed
    #     {NUMUNFAILS}  number of times unfailed
    #     {LINKEDCTLR}  associated controller
    #     {SERIALNUM}   if controller, serial number
    #     {OBJECT}      if controller, object pointer
    #     {GEOSITE}     for geo-raid
    #     {STAGGER}     flag for stagger or all-at-once


    #################################################################
    ############## Extract parms from hash ##########################
    #################################################################
        
    #
    # Set up the initial defaults and then see if there are new values
    # in the parameter hash. If the values are there, update the test
    # values. FInally, print them.
    #

    $timelineDuration = 120;        # this is how long the time line runs

    $reconnectDelay = 60;           # this is how long we wait before 
                                    # attempting to reconnect after 
                                    # power cycle
                                    
    $wait4stateTime = 360;          # how long we wait for the controller
                                    # to be sufficiently booted                                     

    $flags = 0;                     # default operation

    $loop1 = 2000;                  # default loopcount
    
    $MRWTimeout = 30;               # time allowed for resync to finish                                
                                                                        

    if (defined $parmsPtr->{MIRRORRESYNCWAIT} )
    {
        if ( $parmsPtr->{MIRRORRESYNCWAIT} > 0 )
        {   
            $MRWTimeout = $parmsPtr->{MIRRORRESYNCWAIT};
        }
    }

    if (defined $parmsPtr->{TIMELINEDUR} )
    {
        if ( $parmsPtr->{TIMELINEDUR} > 0 )
        {   
            $timelineDuration = $parmsPtr->{TIMELINEDUR};
        }
    }
    
    if (defined $parmsPtr->{RECONNECTDEL} )
    {
        if ( $parmsPtr->{RECONNECTDEL} > 0 )
        {   
            $reconnectDelay = $parmsPtr->{RECONNECTDEL};
        }
    }
    
    if (defined $parmsPtr->{WAIT4STIME} )
    {
        if ( $parmsPtr->{WAIT4STIME} > 0 )
        {   
            $wait4stateTime = $parmsPtr->{WAIT4STIME};
        }
    }

    if (defined $parmsPtr->{FLAGS} )
    {
        if ( $parmsPtr->{FLAGS} >= 0 )
        {   
            $flags = $parmsPtr->{FLAGS};
        }
    }

    if (defined $parmsPtr->{LOOPCOUNT} )
    {
        if ( $parmsPtr->{LOOPCOUNT} >= 0 )
        {   
            $loop1 = $parmsPtr->{LOOPCOUNT};
        }
    }

    my $failType = "PC";

    if (defined $parmsPtr->{FAILTYPE} )
    {
        $failType = $parmsPtr->{FAILTYPE};
    }

    if (defined $xtcPtr)
    {
        if ( $xtcPtr > 0 )
        {   
            $xtcDPtr = $xtcPtr;
        }
    }

    logInfo("");
    logInfo(" Test parameters:");
    logInfo("     Time line duration: $timelineDuration");
    logInfo("        reconnect delay: $reconnectDelay");
    logInfo("    wait for state time: $wait4stateTime");
    logInfo("                  flags: $flags");
    logInfo("             loop count: $loop1"); 
    logInfo("         Failure method: $failType");
    logInfo("     Mirror Resync Wait: $MRWTimeout");
    logInfo("");


    
    

    #
    # Build the resource list from supplied data. This list determines 
    # what we will fail and how. It is also used to maintain status 
    # during the test.
    #


    $ret = 0;

    if ( scalar( @$resListPtr) > 0 )
    {
        # pointer has data behind it, fill in missing parts
        $ret = BuildResources( $resListPtr, $resListPtr, $coPtr );
    }
    else
    {
        # pointer has not data, create from controller info
        $ret = BuildResourcesFromControllers( $resListPtr,
                                              $coPtr,
                                              $moxaIP,
                                              $moxaPtr
                                            );
    }
 
    if ( $ret != GOOD )
    {
        logInfo("Error building list. Can't continue without it.");
        return ERROR;
    } 


    #
    # make sure there are at least two controllers to play with
    #

    if ( scalar( @coList) < 2 )
    {
        # not enough controllers
        logInfo("Failover testing is not supported on one-way systems.");
        return ERROR;
    }

    
    # 
    # This will clean up a previous test that has failed and left one or more controllers in a bad state
    #
    # Assuming this is on a 750 only, there is no need to re-power-cycle the controllers
    # Check both controllers and unfail
    # 
    logInfo("FailoverNWayLoop: CLEANUP");

    $numCtlrs = scalar( @coList );

    # Get the serial numbers first
    
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNumss[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
    }

    $ret = CleanUpUnfailAll ($resListPtr, $coPtr, \@serialNumss, $moxaIP, 
                       $moxaPtr, $timelineDuration, $failCount );

    if ( $ret != GOOD )
    {
        logInfo("Errors while CLEANINGUP controllers, $failCount failovers completed.");
        return ERROR;
    }


# return GOOD;
    #################################################################
    #################### Validate some parameters ###################
    #################################################################
    
    
    #
    # Validate the fail type
    #    

    $failType = uc ( $failType );          # convert to upper case

    $ret = ValidateType ( $failType , $fCtlPtr);
    if ( $ret == ERROR )
    {
        logError("    ====> Unusable failure type specified  ( $failType ) <====");
        return ERROR;
    }

        
    # 
    # check ability to control the moxa power here. It beats waiting to have
    # a failed controller and no way to unfail it. The test just turns ON all
    # ports passed in to the test. This will only cover the controllers. 
    # 
    #     
        
    $ret = PowerCheck ($moxaIP, $moxaPtr);
    if ( $ret !=0 )
    {
        logError("    ====> Error: unable to control one or more Moxa ports <====");
        return ERROR;
    }
 
    #
    # This covers the items specificed in the resources hash. There will be 
    # some duplication for the controllers.
    #

    $ret = PowerCheck2 ($resListPtr);
    if ( $ret !=0 )
    {
        logError("    ====> Error: unable to control one or more Moxa ports <====");
        return ERROR;
    }




    ##########################################################################

    #
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    #


    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #
    
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
    }


    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $newMaster == INVALID )
    {
        logError("    ====> Failed to find the master controller at beginning of the test <====");
        return ERROR;
    }

    #
    # If there are Raid 5 arrays present we need to wait for the resync 
    # to complete on failback. Check the raids and add the option
    # bit if needed. Also needed on failovers.
    #


    if ( 1 == GotRaid5($coList[$newMaster]) )
    {
        logInfo ( "Raid 5 configured in system, making sure R5 resync bit set.");
        $flags = $flags | ADD_R5RESYNC_CHECK;
    } 



    #
    # Wait for batteries to be charged
    #
    $ret = WrtCacheWaitForBatteries($coPtr, 12 * $CBWminutes);

    
    #
    # Rel 3.1 adds resync, need to wait for it to complete
    #
    logInfo( "Making sure all mirror resync is complete at start of test.");
    $ret = MirrorResyncWait($coPtr, 4 * $MRWTimeout);
    if ($ret != GOOD)
    {
        logInfo("Failed Mirror Resync wait at start of test.");
        return ERROR;
    }

    $ret = MirrorInitialData($coPtr, \%mirrorData);

# return (GOOD);    
    #
    # display some starting info: pdisks and targetstatus
    #
    
    $ret = TestLibs::IntegCCBELib::DispPdiskInfo($coList[$newMaster]);

    if ( $ret == ERROR )
    {
        logError("Failed to get pdisk info at start");
        return ERROR;
    }
    
    
    #
    # Adda a pdisks FWV
    #

    %info1 = $coList[$newMaster]->physicalDisks();
    if ( ! %info1  )
    {
        logInfo("    ====> Failed to get response from physicalDisks <====");
        return ERROR;
    }
    if ($info1{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get physicalDisks info <====");
        PrintError(%info1);
        return ERROR;
    }

    logInfo(" Physical disk firmware information ");

    logPhysicalDisks("FWV", %info1);

    logInfo(" ");
    
    

    $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$newMaster] );
    if ( $ret == ERROR )
    {
        logError("Failed to get target list at start");
        return ERROR;
    }

    $failCount = 0;


    #
    # check to see that everything is good at the start
    #

    logInfo("Check to see if everything is functioning at the start of the test");
    $ret = TestBEState($coPtr);

    if ( ($ret != GOOD) && !(NO_STARTUP_CHECK & $flags) )
    {
        logInfo("Test of the BE state failed");
        return ERROR;
    }

    #
    # find the currently active servers
    #
    
    logInfo("Getting initial data for activity measurements.");

    @vCounts = GetVdiskActivityCounts($coPtr);
    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause 20 seconds to allow activity to accumulate");
    DelaySecs(20);


    #
    # get the initial/starting target map
    #

#    logInfo("Getting the target status, then building the target map");
#    

    $ret = GroupTargetMap($coPtr, \@serialNums, \@startingTmap, $newMaster, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }



    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );

    $vdiskListPtr  = \@initialVdisks;

    if ( scalar(@initialVdisks) != 0 )
    {
        # we have some active vdisks
        if ( $initialVdisks[0] == INVALID )
        {
            # error case 
            logInfo("    ====> Warning - can't get an initial active vdisklist  <====");
            $vdiskListPtr  = 0;   # clear the pointer so we skip the following tests
        }
    }
    

    #
    # get initial BE data used for validation
    #
    $ret = CheckBEHashes( \%mirrorData);
    if ( $ret == ERROR )
    {
        logInfo("Initial BE Hash indicated a bad state.");
        return ERROR;
    }

    #
    # startup parity scan, if we are doing any in the loop
    #

    if (  (ADD_PARITY_SCAN & $flags) || (ADD_MORE_PARITY_SCANS & $flags) )
    {
        # parity scan the world
        $ret = TestLibs::BEUtils::PScanCheck( \@coList, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("Initial parity scan reported an error - test failed.");
            return ERROR;
        }
    }

#return GOOD;
#PrintResources( $resListPtr );
#PrintResources( $coPtr );


    #
    # The loop that is really the test
    #

    for ( $i = 0; $i < $loop1; $i++ )
    {

        TestLibs::IntegCCBELib::CtlrLogTextAll($coPtr, "---------- Beginning failover inner loop # $i. ------------");


    #    # find the master,
    #   logInfo("Searching for the master controller in the group [$failCount failovers completed]");
    #    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    #    if ( $newMaster == INVALID )
    #    {
    #        logError(">>>>>>>> Failed to find the master controller [$failCount failovers completed]  <<<<<<<<");
    #        return ERROR;
    #    }

        #
        # Determine what will be failed. This fills in flags in @resources.
        # This also fills in how the item will be failed.
        #

        logInfo("FailoverNWayLoop: determining what and how to fail.");


#PrintResources( $resListPtr );


        $ret = WhatToFail( $resListPtr, $failType, $failCount, $coPtr );

        if ( $ret != GOOD )
        {
            # we can't decide what to fail, or ran into some problem
            logInfo("Failure determining what to fail in loop $i, $failCount failovers completed.");
            return ERROR;
        }


#PrintResources( $resListPtr );


        
        #
        # Now fail the item(s). This may be one or more devices to
        # fail. If multiple controllers are to be failed they may
        # be failed as a group or cascaed with a timeline between
        # failures.
        #

        logInfo("FailoverNWayLoop: failing items.");

        $ret = FailThings( $resListPtr, $timelineDuration, 
                           $coPtr, \@serialNums, 
                           $failCount, $fCtlPtr 
                           );

        if ( $ret != GOOD )
        {
            logInfo("    ====> Error generated while failing items. Test fails.  <====");
            return ERROR;
        }


        #
        # We've failed stuff, now do the timeline and I/O checks
        #

        
   #     logInfo("Time line for $timelineDuration seconds [$failCount failovers completed]. ");
   #
   #     FailOverTimeLineNway( $coPtr, $timelineDuration, \@serialNums, \@deadList);
        
        
        if (  ADD_R5RESYNC_CHECK & $flags  )
        {
            logInfo("[$failCount failovers completed] Begin resync wait.");
            
            # wait for resync to finish on all raids
            $ret = TestLibs::Validate::R5ResyncCheck( \@coList, 0, INVALID );
            if ( $ret != GOOD )
            {
                logInfo("R5 resync check reported an error - test failed, $failCount failovers completed.");
                return ERROR;
            }
        }



        #
        # Build a list of good controller objects for the Mirror related calls
        #
        
        my @goodIndex;
        my @goodObjects;
        my $index1;
      
        
        @goodObjects = ();
        @goodIndex = ();
        
        GetGoodCtlrs($resListPtr, \@goodIndex);
       
        
        for ($index1 = 0; $index1 < scalar(@goodIndex); $index1++)
        {
            
            push (@goodObjects, $coList[$goodIndex[$index1]]);
        }     

        
        #
        # Rel 3.1 adds resync, need to wait for it to complete
        #
        
        # determine if full or partial validation (used here and after failback)       
        $loopVal = ($failCount + 1) % 5;
        $loopRnd = randomInt(0, 3);
        $mirrorVal = MIRROR_FULL;
        
        if (  (MIRROR_LIMITED_BIT & $flags) && ($loopVal != 0)  ||   
              (MIRROR_RANDOM_BIT  & $flags) && ($loopRnd > 0)   )
        {
            $mirrorVal = MIRROR_LIMITED;
        	logInfo("Entering Limited Mirror Validation \(skipping MirrorResyncWait\)\n");
        }
        else
        {
        	logInfo("Entering Full Mirror Validation\n");
            # we wait if we are doing full validation
            $ret = MirrorResyncWait(\@goodObjects, $MRWTimeout);
            if ($ret != GOOD)
            {
                logInfo("Failed Mirror Resync wait.");
                $ret = MirrorCheck( \@goodObjects, \%mirrorData, $mirrorVal);
                return ERROR;
            }
        }
        
        $ret = MirrorCheck( \@goodObjects, \%mirrorData, $mirrorVal);
        if ($ret != GOOD)
        {
            logInfo("Failed Mirror State Check.");
            return ERROR;
        }

        logInfo("[$failCount failovers completed] Begin validation after failover ");

        $ret = TestLibs::Validate::TestSystemState1(\@coList, \@activeServers, 0, $vdiskListPtr, \@serialNums);
        if ( ($ret == ERROR) && !(NO_SERVER_CHECK & $flags) )
        {
            logInfo(">>>>>>>> Controller state bad with slave failed [$failCount failovers completed]  <<<<<<<<");
            return ERROR;
        }

        #
        # Now, for all the controllers that are failed, we turn off the 
        # power. This more accurately reproduces how a customer would do 
        # things.
        #


        logInfo("FailoverNWayLoop: assuring all failed controllers are off.");

        for ( $j = 0; $j < scalar(@$resListPtr); $j++ )
        {
            if ( ($$resListPtr[$j]->{STATE} == NWF_FAILED) &&
                 ($$resListPtr[$j]->{TYPE} == NWF_CTLR)
               )
            {
                #
                # controller is failed, power it off
                #
                
                #
                # If we are using ssh and previously powercycled (rebooted),
                # it is not necessary to reboot again.
                #
                if ( (lc($$resListPtr[$j]->{MOXACHAN}) eq 'ssh') &&
                     ($$resListPtr[$j]->{HOWTOFAIL} eq "PC") )
                {
                    logInfo("Controller previously cycled, skip extra reboot");
                }
                else
                {
                    $ret = TestLibs::IntegCCBELib::PowerChange( $$resListPtr[$j]->{MOXAIP},
                        $$resListPtr[$j]->{MOXACHAN}, 0 );
                    if ( $ret != GOOD )
                    {
                        logInfo("Failure to turn off controllers (unable to control power).");
                        return ERROR;
                    }
                }
            }
        }


        #
        # Add a check to verify that the failed controllers in the VCG are 
        # those that we failed and there were no additional volunteers.
        #
        $ret = VCGInfoCheck2($coPtr, $resListPtr);
        if ( $ret != GOOD )
        {
            logInfo("VCG controller state check has failed.");
            return ERROR;
        }

        #
        # Before we unfail stuff, write a log to the master controller
        # This tags the debug console so we can better merge the 
        # script and controller logs. Need to figure out who is the 
        # current master first.
        #
        $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
        if ( $newMaster == INVALID )
        {
            logError("    ====> Failed to find the master controller [$failCount failovers completed] <====");
            return ERROR;
        }

        #
        # verify all write cache is unchanged
        #
        $ret = WrtCacheValidateCacheUnchanged($coPtr, \%mirrorData);
        if ( $ret != GOOD )
        {
            logInfo("Write cache has changed");
            return (ERROR);
        }


        TestLibs::IntegCCBELib::CtlrLogText($$coPtr[$newMaster], 
                "------ Beginning to unfail devices, failover loop # $i. ------");


        #
        # Now we get to unfail the mess. We may have powered off switches, 
        # drives bays and failed controllers. First we restore any non-
        # controllers to life.
        #

#PrintResources( $resListPtr );

        logInfo("FailoverNWayLoop: beginning unfails on non-controllers. [$failCount failovers completed]");

        $ret = UnfailNonControllers( $resListPtr );
        if ( $ret != GOOD )
        {
            logInfo("Errors while unfailing switeches/bays, $failCount failovers completed.");
            return ERROR;
        }

        #
        # OK, now we can unfail the controllers. We use the UnfailAll
        # functionality in case any controller failed unexpectedly. If an
        # unexpected controller is found, then flag the fact and 
        # launch some messages. This is also probably a failure that
        # needs to be reported.
        #

    
        logInfo("FailoverNWayLoop: beginning unfails on controllers. [$failCount failovers completed]");

        $ret = UnfailAll2 ($resListPtr, $coPtr, \@serialNums, $moxaIP, 
                           $moxaPtr, $timelineDuration, $failCount );

        if ( $ret != GOOD )
        {
            logInfo("Errors while unfailing controllers, $failCount failovers completed.");
            return ERROR;
        }


        #
        # With everything unfailed, do the timeline and I/O checks. We
        # are looking at a system that should have all parts working.
        #

   #     logInfo("Time line after failback for $timelineDuration seconds [$failCount failovers completed]. ");
   #
   #     FailOverTimeLineNway( $coPtr, $timelineDuration, \@serialNums, \@deadList);
        
        
        if (  ADD_R5RESYNC_CHECK & $flags  )
        {
            logInfo("[$failCount failovers completed] Begin resync wait after failback(s).");

            # wait for resync to finish on all raids
            $ret = TestLibs::Validate::R5ResyncCheck( \@coList, 0, INVALID );
            if ( $ret != GOOD )
            {
                logInfo("R5 resync check reported an error - test failed, $failCount failovers completed.");
                return ERROR;
            }
        }

PrintResources( $resListPtr );

        #
        # Wait for batteries to come back
        #
        $ret = WrtCacheWaitForBatteries($coPtr, $CBWminutes);
        
        #
        # Batteries are still bad (return error)
        if ($ret != GOOD)
        {
            logInfo("Failed: Batteries did not charge in time after unfailing controller(s).");
            return ERROR;
        }


        #
        # Rel 3.1 adds resync, need to wait for it to complete
        #

        if (  (MIRROR_LIMITED_BIT & $flags) && ($loopVal != 0)  ||   
              (MIRROR_RANDOM_BIT  & $flags) && ($loopRnd > 0)   )
        {
            $mirrorVal = MIRROR_LIMITED;
            logInfo("Entering Limited \(unfail\) Mirror Validation \(skipping MirrorResyncWait\)\n");
        }
        else
        {
            logInfo("Entering Full Mirror Validation\n");
            # we wait if we are doing full validation
            $ret = MirrorResyncWait($coPtr, $MRWTimeout);
            if ($ret != GOOD)
            {
                logInfo("Failed Mirror Resync wait.");
                $ret = MirrorCheck($coPtr, \%mirrorData, $mirrorVal);
                return ERROR;
            }
        }

        $ret = MirrorCheck($coPtr, \%mirrorData, $mirrorVal);
        if ($ret != GOOD)
        {
            logInfo("Failed Mirror State Check.");
            return ERROR;
        }
        

        logInfo("[$failCount failovers completed] Validation after failback ");

        $ret = TestLibs::Validate::TestSystemState1(\@coList, \@activeServers, \@startingTmap, $vdiskListPtr, \@serialNums);
        if ( ($ret == ERROR) && !(NO_SERVER_CHECK & $flags) )
        {
            logInfo("    ====> Controller state bad with slave failed [$failCount failovers completed] <====");
            return ERROR;
        }
       
        #
        # While everything should be in good shape, do one more
        # check to verify we had no unexpected failures. This should be 
        # relatively simple. We can check vcginfo to make sure nobody has 
        # failed. This is after about thre minutes of timeline and 
        # I/O chencks
        #

        logInfo("Check of VCG Info after failback. [$failCount failovers completed]");
        
        $ret = VCGInfoCheck ( $coPtr ); 
        if ( $ret !=GOOD )
        {
            logInfo("Error verifying VCG Info after failback, test fails, $failCount failovers completed.");
            return ERROR;
        }
        
        #
        # check the back end state, vdisk status, pdisk status, raid status
        #
        $ret = TestLibs::Validate::TestSystemState3($coList[$newMaster], \%mirrorData);
        if ( ($ret == ERROR) && !(NO_BED_CHECK & $flags) )
        {
            logInfo("    ====> Controller state bad after unfail(s) [$failCount failovers completed] <====");
            return ERROR;
        }

        #
        # verify all write cache is unchanged
        #
        $ret = WrtCacheValidateCacheUnchanged($coPtr, \%mirrorData);
        if ( $ret != GOOD )
        {
            logInfo("Write cache has changed");
            return (ERROR);
        }


        #
        # do user requested parity scan
        #
        if (  (ADD_PARITY_SCAN & $flags) || (ADD_MORE_PARITY_SCANS & $flags) )
        {
            # parity scan the world
            $ret = TestLibs::BEUtils::PScanCheck( \@coList, 0, INVALID );
            if ( $ret != GOOD )
            {
                logInfo("Parity scan reported an error - test failed.");
                return ERROR;
            }
        }
        
        # this is the CTE stuff, we will enter the block if the $xtcPtr has the 'CTE' key
        # which should have been set up in the XTC.pl.  The db is only getting updated
        # in the failover_run and server_table tables if it is mod 2.
        # We are using mod 2 because CTE counts a f/o cycle as each controller down and up
        #  - I am sure we'll have to change this for N > 2
        if (defined($xtcPtr->{CTE}{FID}) && $failCount % 2 == 0)
        {
            # eval load the CTE lib, it has a bunch of required libs (DBI, etc.)
            eval("use TestLibs::CTE");
            if($@)
            {
                logError("Need the TestLibs::CTE module and its dependencies, $@\n");
                return(ERROR);
            }
        
            if (UpdateFailoverRun(${$xtcPtr->{CTE}{FID}}) == ERROR)
            {
                logError("Could not update failover_run table for FID ${$xtcPtr->{CTE}{FID}}\n");
            }
            
            if (UpdateServerTable(${$xtcPtr->{CTE}{FID}}) == ERROR)
            {
                logError("Could not update failover_run table for FID ${$xtcPtr->{CTE}{FID}}\n");
            }
        }

        #
        # Bump the fail count and go back and do it again.
        #
        $failCount++;
        if ( $xtcDPtr )
        {
            $xtcDPtr->{TESTLOOPS} =  $failCount;
        }
        
        

        logInfo("--------------------- Loop $i completed, $failCount failovers completed. -------------------");

        
        #
        # Every 'n' loops we post a summary of the number of failovers 
        # done by each component in the resource list.
        #
        $ret = PostSummary( $resListPtr, $failCount );

        if ( $ret != GOOD )
        {
            logInfo(" Some error while posting the summary, test failed, $failCount failovers completed. ");
            return ERROR;
        }


    }   # end of for # $loop1 failovers
    
    
    #
    # Do a final summary at the end
    # 

    logInfo("---------------------- Summary at end of $i failovers -----------------------------------");

    $ret = PostSummary( $resListPtr, $failCount );

    if ( $ret != GOOD )
    {
        logInfo(" Some error while posting the summary, test failed, $failCount failovers completed. ");
        return ERROR;
    }


    # done!
    logInfo("End of N-way Fail Over Loop test, $failCount failovers completed.");
    return GOOD;

}



###############################################################################
###############################################################################



###############################################################################

=head2 FailOver function

XTC interface to the Exerciser fail-over loop function.



=cut

=over 1

=item Usage:

 my $rc = FailOver( the following list of parameters );
 
 where,
        $ptrVcgGroups  
        $curTestGroup
        $curTestArgument
        $ptrBigfootIP
        $ptrBigfootSN
        $ptrBigfootName
        $ptrBigfootGroup
        $ptrPowerName
        $ptrPowerIP
        $ptrPowerChannel
        $ptrCurTestParmHash

       

=item Returns:

       $rc GOOD  although this will probably change.


=item Description:
 
        For each controller...disconnect from the XMC
        Build needed data structures for upcoming calls. Also connect
            to each controller (CCBE style).
        Call FailOverLoop function.
        Disconnect from each controller (CCBE style).
        Puase for a random number of seconds.


=back

=cut


###############################################################################

=head2 VcgFailRandom function

A function to do a random failover and fail-back on a controller.



=cut

=over 1

=item Usage:

 my $rc = VcgFailRandom( the following list of parameters );
 
 where,
        $ptrVcgGroups,
        $curTestGroup,
        $curTestArgument,
        $ptrBigfootIP,
        $ptrBigfootSN,
        $ptrBigfootName,
        $ptrBigfootGroup,
        $ptrPowerName,
        $ptrPowerIP,
        $ptrPowerChannel,
        $ptrCurTestParmHash

       

=item Returns:

       $rc GOOD if no errors, ERROR otherwise. 


=item Description:
 
        For each controller...DO an XMC disconnect
        For each controller
            Build needed data structure
            Connect ( CCBE style)
        Select a random controller to fail
        Find the master controller in the group
        Validate the failure method
        Fail the controller according to the method
             (BEET, FEET, CCBET, or FC)
        Delay a random number of seconds
        Power Cycle the failed controller
        Reconnect tothe controller
        Find the master controller
        Unfail the failed controller
        Disconnect from all controllers ( CCBE style) 
        Pause a random number of seconds.


=back

=cut


#######################################################################
### Function name: VcgFailRandom
###
### Purpose: randomly fail controllers within a VCG
##
## INPUT:    
## Outputs: GOOD, if successful, ERROR otherwise
#######################################################################

sub VcgFailRandom
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

# Local Variables
    my $returnValue;
    my $masterIndex;
    my $groupIPptr;
    my $groupSNptr;
    my $groupNameptr;
    my @groupCCBE;
    my $controllerIP;
    my $controllerName;
    my $controllerSerial;
    my $controllerCCBE;
    my $failType;
    my $indexName = 0;
    my $logMark;
    my $timelineDuration = 120; # Secs to display Timeline
    my @startingTmap;
    my @activeServers;
    my @initialVdisks;
    my @pdiskData;
    my @vdiskData;
    my @raidData;
    my $minDelay;
    my $ret;
    
    $groupIPptr   = $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'};
    $groupSNptr   = $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgSN'};
    $groupNameptr = $xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgName'};
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@groupCCBE);

    TestLibs::Logging::logInfo ("Select a controller at random");
    $indexName = rand @$groupIPptr;                     # Select a controller at random

    $controllerIP     = $$groupIPptr[$indexName];
    $controllerSerial = $$groupSNptr[$indexName];
    $controllerName   = $$groupNameptr[$indexName];
    $controllerCCBE   = $groupCCBE[$indexName];

    TestLibs::Logging::logInfo ("Find the current Master of the group");

    # Supress lower level messages
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "false");}

    # Find the current Master of the group
    $masterIndex = TestLibs::IntegCCBELib::FindMaster(\@groupCCBE);

    # Restore stdout
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "true");}

    if ($masterIndex == INVALID)
    {
        TestLibs::Logging::logError ("Failed to find the Master controller, needed to fail a controller");
    }

    TestLibs::Logging::logInfo ("Checking System State at Start");

    # Supress lower level messages
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "false");}

    # Gather initial data and check some system states
    $ret = TestLibs::Validate::CheckAtStart(\@groupCCBE, $masterIndex, \@$groupSNptr, \@startingTmap,
            \@activeServers, \@initialVdisks, \@pdiskData, \@vdiskData, \@raidData) ;

    # Restore stdout
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "true");}

    if ( $ret == ERROR )
    {
        logError("Controller state bad during CheckAtStart");
    }

    $failType = GetFailMethod(uc (${$xtcDataPtr->{CURTESTARGUMENT}}));

    # Mark the controller logs with Port Disable
    $logMark = "VCG Fail Rnd Script: Fail IP: $controllerIP Serial Number: $controllerSerial, Method $failType";
    TestLibs::IntegCCBELib::CtlrLogTextAll(\@groupCCBE, $logMark);

    FAILURE_Case:                                  # Select the Failure Type
    {
        $failType eq "BEET" && do
        {
            TestLibs::Logging::logInfo ("Failing Controller <BEET> IP: $controllerIP Serial Number: $controllerSerial");
            # Fail the controller
            $returnValue = TestLibs::IntegCCBELib::ErrorTrapController($controllerCCBE, "BE");
            last FAILURE_Case;
        };

        $failType eq "FEET" && do
        {
            TestLibs::Logging::logInfo ("Failing Controller - <FEET> IP: $controllerIP Serial Number: $controllerSerial");
            # Fail the controller
            $returnValue = TestLibs::IntegCCBELib::ErrorTrapController($controllerCCBE, "FE");
            last FAILURE_Case;
        };

        $failType eq "CCBET"    && do
        {
            TestLibs::Logging::logInfo ("Failing Controller - <CCBET> IP: $controllerIP Serial Number: $controllerSerial");
            # Fail the controller
            $returnValue = TestLibs::IntegCCBELib::ErrorTrapController($controllerCCBE, "CCB");
            last FAILURE_Case;
        };

        $failType eq "FC"   && do
        {
            TestLibs::Logging::logInfo ("Failing Controller - <VCG Fail> IP: $controllerIP Serial Number: $controllerSerial");
            # Fail the controller
            $returnValue = TestLibs::IntegCCBELib::FailController($groupCCBE[$masterIndex], $controllerSerial);
            last FAILURE_Case;
        };
#        $failType eq "QLFALL"   && do
#        {
#            TestLibs::Logging::logInfo ("Failing Controller - <All FE QLogics> IP: $controllerIP Serial Number: $controllerSerial");
#            # Fail the controller
#            print "Failing using RESET QLOGIC FE ALL 5 (twice) \n";
#            $returnValue = TestLibs::IntegCCBELib::QLReset($controllerCCBE, "FE", "ALL", 5 );    # 1 is reset only
#            DelaySecs(10);
#            $returnValue = TestLibs::IntegCCBELib::QLReset($controllerCCBE, "FE", "ALL", 5 );    # 1 is reset only
#            last FAILURE_Case;
#        };
        TestLibs::Logging::logError ("Invalid Failure Type:$failType");
    }

    if ($returnValue != GOOD )
    {
        TestLibs::Logging::logError ("Could not fail controller");
        return ERROR;
    }

    TestLibs::utility::delay(20);  # Wait for the fail-over to start
    
    TestLibs::Logging::logInfo ("Find the current Master of the group");

    # Supress lower level messages
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "false");}

    # Find the current Master of the group
    $masterIndex = TestLibs::IntegCCBELib::FindMaster(\@groupCCBE);

    # Restore stdout
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "true");}

    if ($masterIndex == INVALID)
    {
        TestLibs::Logging::logWarning ("Failed to find the Master controller, delay and try again");
        TestLibs::utility::delay(70);  # Wait for the mastership to change
    
        # Supress lower level messages
        if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "false");}

        # Find the current Master of the group
        $masterIndex = TestLibs::IntegCCBELib::FindMaster(\@groupCCBE);

        # Restore stdout
        if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "true");}

        if ($masterIndex == INVALID)
        {
            TestLibs::Logging::logError ("Failed to find the Master controller on the second attempt");
        }
    }

    TestLibs::Logging::logInfo ("Checking FailOver Time Line and System State");

    # Supress lower level messages
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "false");}

    # Run the Time Line to check the failover sequence
    TestLibs::Validate::FailOverTimeLine($groupCCBE[$masterIndex], $timelineDuration, \@$groupSNptr, 0);
    
    # check the system state of the front end: server activity, vdisk activity, target map
    $ret = TestLibs::Validate::TestSystemState1(\@groupCCBE, \@activeServers, 0, \@initialVdisks, \@$groupSNptr);
    if ( $ret == ERROR )
    {
        # Restore stdout
        if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "true");}

        logError("Controller state bad during TestSystemState1");
    }

    # check the back end state, vdisk status, pdisk status, raid status
    $ret = TestLibs::Validate::TestSystemState2($groupCCBE[$masterIndex], \@pdiskData, \@vdiskData, \@raidData);

    # Restore stdout
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "true");}

    if ( $ret == ERROR )
    {
        logError("Controller state bad during TestSystemState2");
    }

    # Remove the Fail over time delay from the randomdelay time if possible
    $minDelay = $testParms{"failcontrollerwaitmin"} >= $timelineDuration ? 
                   $testParms{"failcontrollerwaitmin"} - $timelineDuration : 0;
    
    # Wait a random time between min and max values passed in from config file
    TestLibs::utility::randomDelay($minDelay, $testParms{"failcontrollerwaitmax"});

    # power cycle and unfail controller
    $indexName = 0;
    foreach my $deviceName (@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerName'}})
    {
        if ($deviceName eq $controllerName)
        {
            TestLibs::Logging::logInfo ("Power cycle controller $controllerIP");
            # Power cycle failed controller
            my $retPower = TestLibs::IntegCCBELib::PowerCycle(
                ${$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}}[$indexName],
                ${$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}}[$indexName]);
            
            if ($retPower != GOOD)
            {
                TestLibs::Logging::logError ("Failed Moxa Power Cycle IP:" . 
                ${$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}}[$indexName] . 
                " Channel:" . ${$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}}[$indexName] .
                ", You must manually power cycle");
            }
            TestLibs::utility::pingWait($controllerIP, 300); # Wait upto 300 secs for the controller to come ready
        }
    $indexName++;
    }

    # Need to reconnect to failed controller
    # If it fails to reconnect, we will just get errors from the failed controller
    # So no error checking is performed
    TestLibs::Logging::logInfo ("Reconnect to failed controller");
    $returnValue = TestLibs::IntegCCBELib::Reconnect($controllerCCBE, 10);

    # Supress lower level messages
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "false");}

    # Find the current Master of the group
    TestLibs::Logging::logInfo ("Find the current Master of the group, you can ignore errors from the failed controller");
    $masterIndex = TestLibs::IntegCCBELib::FindMaster(\@groupCCBE);

    # Restore stdout
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "true");}

    if ($masterIndex == INVALID)
    {
        TestLibs::Logging::logError ("Failed to find the Master controller, needed to unfail a controller");
    }

    # Mark the controller logs with Port Disable
    $logMark = "VCG Fail Rnd Script: UnFail IP: $controllerIP Serial Number: $controllerSerial";
    TestLibs::IntegCCBELib::CtlrLogTextAll(\@groupCCBE, $logMark);

    TestLibs::Logging::logInfo ("Unfailing Controller - Controller IP: $controllerIP Serial Number: $controllerSerial");
    # Unfail the controller
    $returnValue = TestLibs::IntegCCBELib::UnFailController($groupCCBE[$masterIndex], $controllerSerial);
    if ($returnValue != GOOD )
    {
        TestLibs::Logging::logError ("Could not unfail controller, going to abort and return FAILED");
        return ERROR;
    }

    # Supress lower level messages
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "false");}

    # Run the Time Line to check the failover sequence
    TestLibs::Validate::FailOverTimeLine($groupCCBE[$masterIndex], $timelineDuration, \@$groupSNptr, 0);

    # Restore stdout
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "true");}

    TestLibs::Logging::logInfo ("Checking System State after unfail");
    
    # Supress lower level messages
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "false");}

    # check the system state of the front end: server activity, vdisk activity, target map
    $ret = TestLibs::Validate::TestSystemState1(\@groupCCBE, \@activeServers, \@startingTmap, \@initialVdisks, \@$groupSNptr);

    if ( $ret == ERROR )
    {
        # Restore stdout
        if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "true");}
        logError("Controller state bad during TestSystemState1");
    }
    
    # check the back end state, vdisk status, pdisk status, raid status
    $ret = TestLibs::Validate::TestSystemState2($groupCCBE[$masterIndex], \@pdiskData, \@vdiskData, \@raidData);

    # Restore stdout
    if (${$xtcDataPtr->{QUIET}} eq "true") {logControl(stdout => "true");}

    if ( $ret == ERROR )
    {
        logError("Controller state bad during TestSystemState2");
    }
    
    foreach my $controllerCCBE (@groupCCBE)             # Disconnect from all controllers in this VCG
    {
        ccbe_disconnect($controllerCCBE);
    }

    # Remove the Fail over time delay from the randomdelay time if possible
    $minDelay = $testParms{"failcontrollerwaitmin"} >= $timelineDuration ? 
                   $testParms{"failcontrollerwaitmin"} - $timelineDuration : 0;
    
    # Wait a random time between min and max values passed in from config file
    TestLibs::utility::randomDelay($minDelay, $testParms{"failcontrollerwaitmax"});

    return GOOD;
}

#######################################################################
### Function name: InjectErrorLoop
###
### Purpose: randomly fail controllers within a VCG
##
## INPUT:    
## Outputs: GOOD, if successful, ERROR otherwise
#######################################################################

sub InjectErrorLoop
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms    = %{$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};

## Local Variables
#    my $returnValue;
#    my $masterIndex;
#    my @groupIP;
#    my @groupSN;
#    my @groupName;
#    my @groupCCBE;
#    my $controllerIP;
#    my $controllerName;
#    my $controllerSerial;
#    my $controllerCCBE;
#    my $failType;
#    my $indexName = 0;
#    my $indexMoxa;
#    my $indexInject;
#    my $logMark;
#    my $timelineDuration = 120; # Secs to display Timeline
#    my @startingTmap;
#    my @activeServers;
#    my @initialVdisks;
#    my @pdiskData;
#    my @vdiskData;
#    my @raidData;
#    my $minDelay;
#    my $ret;
#    my $checkIP;
#    my $checkCCB;
#    my $deviceName;
#    my @MoxaIPs; 
#    my @MoxaChans;
#    my $filename;
#
#    if (defined $$ptrCurTestParmHash{"logfile"})
#    {
#        # Set Logging to dump into given file
#        $filename = $$ptrCurTestParmHash{"logfile"};
#        if (open(InjectLog, ">>$filename"))
#        {
#            print ("Loggin Output to $filename\n");
#            TestLibs::Logging::log_to(\*InjectLog);
#        }
#        else
#        { 
#            TestLibs::Logging::logError ("Can't Open Log File for append $filename: $!");
#        }
#    }
#
#    TestLibs::Logging::debug ("Find all controllers in the VCG");
#    foreach $controllerIP (@bigfootIP)              # Find all the controllers in this VCG
#    {
#        if ($bigfootGroup[$indexName] eq $curTestGroup)
#        {
#            print "Inject IP: $$ptrCurTestParmHash{'errorinjectip'}\n";
#            if ($controllerIP eq $$ptrCurTestParmHash{"errorinjectip"})
#            {
#                $indexInject = $indexName;
#            }
#            push (@groupIP, $controllerIP);         # Build the arrays that define this group
#            push (@groupSN, $bigfootSN[$indexName]);
#            push (@groupName, $bigfootName[$indexName]);
#            push (@groupCCBE, TestLibs::IntegCCBELib::ccbe_connect($controllerIP));
#            # Build Moxa Array
#            $indexMoxa = 0;
#            foreach $deviceName (@powerName)
#            {
#                if ($deviceName eq $bigfootName[$indexName])
#                {
#                    push (@MoxaIPs, $powerIP[$indexMoxa]);
#                    push (@MoxaChans, $powerChannel[$indexMoxa]);
#                }
#            $indexMoxa++;
#            }
#        }
#        $indexName++;
#    }
#
#    TestLibs::Logging::logInfo ("Operation: Inject error on controller IP:$$ptrCurTestParmHash{'errorinjectip'}");
#    $controllerIP = $groupIP[$indexInject];
#    $controllerSerial = $groupSN[$indexInject];
#    $controllerName = $groupName[$indexInject];
#    $controllerCCBE = $groupCCBE[$indexInject];
#
#    TestLibs::Logging::logInfo ("Find the current Master of the group");
#
#    # Supress lower level messages
#    if ($quiet eq "true") {logControl(stdout => "false");}
#
#    # Find the current Master of the group
#    $masterIndex = TestLibs::IntegCCBELib::FindMaster(\@groupCCBE);
#
#    # Restore stdout
#    if ($quiet eq "true") {logControl(stdout => "true");}
#
#    if ($masterIndex == INVALID)
#    {
#        TestLibs::Logging::logError ("Failed to find the Master controller");
#    }
#
#    TestLibs::Logging::logInfo ("Fail controllers other than IP:$controllerIP");
#    # Fail all other controllers, this hocus makes the Error Ijection Controller the Master for the first failure
#    $indexName = 0;
#    foreach $checkIP (@groupIP)
#    {
#        if ($checkIP ne $$ptrCurTestParmHash{"errorinjectip"})
#        {
#            $returnValue = TestLibs::IntegCCBELib::FailController($groupCCBE[$masterIndex], $groupSN[$indexName]);
#            if ($returnValue != GOOD)
#            {
#                TestLibs::Logging::logError ("Unable to Fail Controller IP:$checkIP");
#            }
#        }
#        $indexName++;
#    }
#
#    TestLibs::utility::delay(60);  # Wait
#
#    # Unfail All Controllers before Injecting Error
#    $returnValue = TestLibs::BEUtils::UnfailAll (\@groupCCBE, \@groupSN, \@MoxaIPs, \@MoxaChans); 
#
#    TestLibs::Logging::logInfo ("Find the current Master of the group");
#
#    # Supress lower level messages
#    if ($quiet eq "true") {logControl(stdout => "false");}
#
#    # Find the current Master of the group
#    $masterIndex = TestLibs::IntegCCBELib::FindMaster(\@groupCCBE);
#
#    # Restore stdout
#    if ($quiet eq "true") {logControl(stdout => "true");}
#
#    if ($masterIndex == INVALID)
#    {
#        TestLibs::Logging::logError ("Failed to find the Master controller");
#    }
#
#    TestLibs::Logging::logInfo ("Checking System State at Start");
#
#    # Supress lower level messages
#    if ($quiet eq "true") {logControl(stdout => "false");}
#
#    # Gather initial data and check some system states
#    $ret = TestLibs::Validate::CheckAtStart(\@groupCCBE, $masterIndex, \@groupSN, \@startingTmap,
#            \@activeServers, \@initialVdisks, \@pdiskData, \@vdiskData, \@raidData) ;
#
#    # Restore stdout
#    if ($quiet eq "true") {logControl(stdout => "true");}
#
#    if ( $ret == ERROR )
#    {
#        logError("Controller state bad during CheckAtStart");
#    }
#
#    $curTestArgument = uc( $curTestArgument);      # make sure upper case
#
#    # Mark the controller logs
#    $logMark = "Error Inject Script: Fail IP: $controllerIP Serial Number: $controllerSerial, Method $failType";
#    TestLibs::IntegCCBELib::CtlrLogTextAll(\@groupCCBE, $logMark);
#
#    TestLibs::Logging::logInfo ("Injecting Error:$curTestArgument at Controller IP: $controllerIP Serial Number: $controllerSerial");
#    # Inject the Error
#    $returnValue = TestLibs::ErrorInjection::InjectErrorEntry($curTestArgument, uc $$ptrCurTestParmHash{"errorinjectcom"});
#
#    if ($returnValue != GOOD )
#    {
#        TestLibs::Logging::logError ("Could not Inject Error");
#        return ERROR;
#    }
#
#    TestLibs::utility::delay(30);  # Wait
#    
#    TestLibs::Logging::logInfo ("Find the current Master of the group");
#
#    # Supress lower level messages
#    if ($quiet eq "true") {logControl(stdout => "false");}
#
#    # Find the current Master of the group
#    $masterIndex = TestLibs::IntegCCBELib::FindMaster(\@groupCCBE);
#
#    # Restore stdout
#    if ($quiet eq "true") {logControl(stdout => "true");}
#
#    if ($masterIndex == INVALID)
#    {
#        TestLibs::Logging::logError ("Failed to find the Master controller");
#    }
#
#    TestLibs::Logging::logInfo ("Dumping some logs from all Controller, this may fail on some controllers");
#
## Expect fail-over or just log message?
#
#    # Dump logs from all controllers, this may fail on some controllers
#    $indexName = 0;
#    foreach $checkCCB (@groupCCBE)
#    {
#        $returnValue = TestLibs::IntegCCBELib::DispLogs($checkCCB, 100, 0x00);
#        if ($returnValue != GOOD)
#        {
#            TestLibs::Logging::logWarning ("Unable to get this controller's logs");
#        }
#        $indexName++;
#    }
#
#    TestLibs::Logging::logInfo ("Checking FailOver Time Line and System State");
#
#    # Supress lower level messages
#    if ($quiet eq "true") {logControl(stdout => "false");}
#
#    # Run the Time Line to check the failover sequence
#    TestLibs::Validate::FailOverTimeLine($groupCCBE[$masterIndex], $timelineDuration, \@groupSN, 0);
#    
#    # check the system state of the front end: server activity, vdisk activity, target map
#    $ret = TestLibs::Validate::TestSystemState1(\@groupCCBE, \@activeServers, 0, \@initialVdisks, \@groupSN);
#    if ( $ret == ERROR )
#    {
#        # Restore stdout
#        if ($quiet eq "true") {logControl(stdout => "true");}
#
#        logError("Controller state bad during TestSystemState1");
#    }
#
#    # check the back end state, vdisk status, pdisk status, raid status
#    $ret = TestLibs::Validate::TestSystemState2($groupCCBE[$masterIndex], \@pdiskData, \@vdiskData, \@raidData);
#
#    # Restore stdout
#    if ($quiet eq "true") {logControl(stdout => "true");}
#
#    if ( $ret == ERROR )
#    {
#        logError("Controller state bad during TestSystemState2");
#    }
#
#    # Remove the Fail over time delay from the randomdelay time if possible
#    $minDelay = $$ptrCurTestParmHash{"erroinjectwaitmin"} >= $timelineDuration ? 
#                   $$ptrCurTestParmHash{"erroinjectwaitmin"} - $timelineDuration : 0;
#    
#    # Wait a random time between min and max values passed in from config file
#    TestLibs::utility::randomDelay($minDelay, $$ptrCurTestParmHash{"erroinjectwaitmax"});
#
#    # power cycle and unfail controller
#    $indexName = 0;
#    foreach $deviceName (@powerName)
#    {
#        if ($deviceName eq $controllerName)
#        {
#            TestLibs::Logging::logInfo ("Power cycle controller $controllerIP");
#            # Power cycle failed controller
#            my $retPower = TestLibs::IntegCCBELib::PowerCycle($powerIP[$indexName], $powerChannel[$indexName]);
#            if ($retPower != GOOD)
#            {
#                TestLibs::Logging::logError ("Failed Moxa Power Cycle IP:$powerIP[$indexName] Channel:$powerChannel[$indexName], You must manually power cycle");
#            }
#            TestLibs::utility::pingWait($controllerIP, 300); # Wait upto 300 secs for the controller to come ready
#        }
#    $indexName++;
#    }
#
#    # Need to reconnect to failed controller
#    # If it fails to reconnect, we will just get errors from the failed controller
#    # So no error checking is performed
#    TestLibs::Logging::logInfo ("Reconnect to failed controller");
#    $returnValue = TestLibs::IntegCCBELib::Reconnect($controllerCCBE, 10);
#
#    # Supress lower level messages
#    if ($quiet eq "true") {logControl(stdout => "false");}
#
#    # Find the current Master of the group
#    TestLibs::Logging::logInfo ("Find the current Master of the group, you can ignore errors from the failed controller");
#    $masterIndex = TestLibs::IntegCCBELib::FindMaster(\@groupCCBE);
#
#    # Restore stdout
#    if ($quiet eq "true") {logControl(stdout => "true");}
#
#    if ($masterIndex == INVALID)
#    {
#        TestLibs::Logging::logError ("Failed to find the Master controller");
#    }
#
#    # Mark the controller logs
#    $logMark = "Error Inject Script: UnFail IP: $controllerIP Serial Number: $controllerSerial";
#    TestLibs::IntegCCBELib::CtlrLogTextAll(\@groupCCBE, $logMark);
#
#    TestLibs::Logging::logInfo ("Unfailing Controller - Controller IP: $controllerIP Serial Number: $controllerSerial");
#    # Unfail the controller
#    $returnValue = TestLibs::IntegCCBELib::UnFailController($groupCCBE[$masterIndex], $controllerSerial);
#    if ($returnValue != GOOD )
#    {
#        TestLibs::Logging::logError ("Could not unfail controller, going to abort and return FAILED");
#        return ERROR;
#    }
#
#    # Supress lower level messages
#    if ($quiet eq "true") {logControl(stdout => "false");}
#
#    # Run the Time Line to check the failover sequence
#    TestLibs::Validate::FailOverTimeLine($groupCCBE[$masterIndex], $timelineDuration, \@groupSN, 0);
#
#    # Restore stdout
#    if ($quiet eq "true") {logControl(stdout => "true");}
#
#    TestLibs::Logging::logInfo ("Checking System State after unfail");
#    
#    # Supress lower level messages
#    if ($quiet eq "true") {logControl(stdout => "false");}
#
#    # check the system state of the front end: server activity, vdisk activity, target map
#    $ret = TestLibs::Validate::TestSystemState1(\@groupCCBE, \@activeServers, \@startingTmap, \@initialVdisks, \@groupSN);
#
#    if ( $ret == ERROR )
#    {
#        # Restore stdout
#        if ($quiet eq "true") {logControl(stdout => "true");}
#        logError("Controller state bad during TestSystemState1");
#    }
#    
#    # check the back end state, vdisk status, pdisk status, raid status
#    $ret = TestLibs::Validate::TestSystemState2($groupCCBE[$masterIndex], \@pdiskData, \@vdiskData, \@raidData);
#
#    # Restore stdout
#    if ($quiet eq "true") {logControl(stdout => "true");}
#
#    if ( $ret == ERROR )
#    {
#        logError("Controller state bad during TestSystemState2");
#    }
#    
#    foreach my $controllerCCBE (@groupCCBE)             # Disconnect from all controllers in this VCG
#    {
#        ccbe_disconnect($controllerCCBE);
#    }
#
#
## Reset the controller with the Error Injection Active
## Add a check of the logs here to see if the error was detected on boot up
#    # JSW TBD
#
#
## Need to pass in Master Log file from XTC if we want to switch back to it?
##    if (defined $$ptrCurTestParmHash{"logfile"})
##    {
##        # Reset the logging file
##        TestLibs::Logging::log_to (\*LOG);
##    }
#
#    # Remove the Fail over time delay from the randomdelay time if possible
#    $minDelay = $$ptrCurTestParmHash{"failcontrollerwaitmin"} >= $timelineDuration ? 
#                   $$ptrCurTestParmHash{"failcontrollerwaitmin"} - $timelineDuration : 0;
#    
#    # Wait a random time between min and max values passed in from config file
#    TestLibs::utility::randomDelay($minDelay, $$ptrCurTestParmHash{"failcontrollerwaitmax"});
#
    return GOOD;
}

###############################################################################

=head2 PowerOneWayMate function

Checks to see if the requested failure method is valid or not.



=cut

=over 1

=item Usage:

 my $rc = PowerOneWayMate( $method );
 
 where,
        $method is the desired means to fail the controller

=item Returns:

       $rc GOOD if valid, ERROR otherwise. 

=item Description:
 
 Just checks the requested method against a list of valid values.

=back

=cut

##############################################################################
#
#          Name: PowerOneWayMate
#
#        Inputs: failure method
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Generic means to failover a controller. Possible methods
#                are: 
#                     BE = back end error trap
#                     FE = front end error trap
#                     CCB = CCB error trap
#                     QLF = hold fe qlogics reset
#                     FC = Fail using VCGFAILCONTROLLER
#
##############################################################################
sub PowerOneWayMate
{
    trace();                        # This allows function tracability
    my ($coPtr, $moxaIP, $moxaPtr, $victim, $loopCount ) = @_;

    my $i;
    my $master;
    my @moxaList;
    my @coList;
    my $ret;

    @moxaList = @$moxaPtr;
    @coList = @$coPtr;

    logInfo(" Neal's power cycle test...");

    # power off the victim ( gets the controller to fail over )

    $ret = PowerChange($moxaIP, $moxaList[$victim], 0);
    if ( $ret != GOOD )
    {
        logInfo("Error turning off power to $victim ");
        return ERROR;
    }

    DelaySecs(10);           # Let it fail


    # power victim back on let system stabilize

    $ret = PowerChange($moxaIP, $moxaList[$victim], 1);
    if ( $ret != GOOD )
    {
        logInfo("Error turning on power to $victim ");
        return ERROR;
    }

    logInfo("wait while the controller boots");

    # fimd the master, we want this ID for later
    logInfo("Pause for 60 seconds and reconnect to the  controller  ");
    $ret = TestLibs::IntegCCBELib::Reconnect( $coList[$victim], 60 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to reconnect to the controller   <<<<<<<<");
        return ERROR;
    }

    $master = FindMaster($coPtr);

    # now we are where we want to be, configuration-wise SO, 
    # do the long loop

    logInfo("Begin the power cycle loop");

    for ( $i = 0; $i < $loopCount; $i++ )
    {

        logInfo("Loop number $i beginning...");

        # power off the victim
        $ret = PowerChange($moxaIP, $moxaList[$victim], 0);
        if ( $ret != GOOD )
        {
            logInfo("Error turning off power to $victim ");
            return ERROR;
        }

        # wait a short while ( 10 sec)

        DelaySecs(10);           # Let 


        # turn victim back on

        $ret = PowerChange($moxaIP, $moxaList[$victim], 1);
        if ( $ret != GOOD )
        {
            logInfo("Error turning on power to $victim ");
            return ERROR;
        }



        # wait the magic number of seconds...
        logInfo("Waiting for <magic number> seconds");

        ######################
        #                    #
        # NEAL.... EDIT HERE #
        #                    #
        ######################

        DelaySecs(96);

        # do devstat PD on the master
        $ret = DispPdiskInfo($coList[$master]);

        # if bad, we outta here
        if ( $ret != GOOD )
        {
            logInfo("Error getting devstat PD. Loop count = $i ");
            return ERROR;
        }
    


        # do it again
    }

    return GOOD;
}



###############################################################################


###############################################################################

=head2 SurvivorLoop function    (subject to change)


This loop is common to many of the fail-over tests. Here is a short 
outline of the test. This reflects Aug. 6, 2002 code. 
As the code evolves, there may be changes.


=cut

=over 1

=item Usage:

 my $rc = SurvivorLoop($coPtr, $moxaIP, $moxaPtr, $failType, $loopCount );
 
 where $coPtr is a pointer to a controller object list
       $moxaIP is the IP address for the Moxa power controller
       $moxaPtr is a pointer to the list of used Moax chennels
               ( the order must match the $coPtr list )
       $failType is desired failure method
       $loopCount is the number of loops to do. Default = 2000

       

=item Returns:

       $rc will be GOOD if all tests pass or INVALID or ERROR if failed

=item Description:
 


 FailOverLoop:
    Collect initial server activity information (active servers and vdisks, target map)
    Repeat for the desired number of loops (default is 2000 )
        Find the master controller
        Repeat for each non-master controller
            Determine how to fail
            Fail the controller
            Pause 120 seconds (to allow failover)
            Check for proper VCG operation (described below)
            Power cycle the controller
            Re-connect to the controller (60 second initial delay)
            Wait for boot to really complete (based on power up state)
            Find current master
            Un-fail the controller
            Pause for 120 seconds
            Check for proper VCG operation
        Check for proper VCG operation
        (the following are on the original master)
        Determine how to fail
        Fail the controller
        Pause 120 seconds (to allow failover)
        Check for proper VCG operation (described below)
        Power cycle the controller
        Re-connect to the controller (60 second initial delay)
        Wait for boot to really complete (based on power up state)
        Find current master
        Un-fail the controller
        Pause for 120 seconds
        Check for proper VCG operation

 The failure method is a user parameter and is one of the following.

 BEET - back end processor error trap
 FEET - front end processor error trap
 CCBET - CCB processor error trap
 RET - random processor error trap
 PC - power off the controller
 FC - fail using mrp command
 RND - random one of  BEET, FEET, CCBET, PC (this list may change)

=back

=cut



##############################################################################
#
#          Name: SurvivorLoop
#
#        Inputs: controller list pointer, Moxa IP Address, Moxa, loop count
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This loop attempts to fail the surviving controller once
#                all other controllers have failed.
##############################################################################
sub SurvivorLoop
{
    trace();                        # This allows function tracability

    my ($coPtr, $moxaIP, $moxaPtr, $loopCount ) = @_;

    my $loop1;
    my $i;
    my $initMaster;
    my $initMasterSN;
    my $newMaster;
    my $slaveSN;
    my $masterSN;
    my $numCtlrs;
    my $j;
    my $chn;
    my $ret;
    my $failCount;
    my @serialNums;
    my $how2fail;
    my $failType;
    my $survivor;
    my $ctlrSN;
    my $failedSN;
    my $index;

    
    my @startingTmap;
    my @initialVdisks;
    my %info;
    my %info1;
    my $vdiskListPtr;

    my @moxaMap;

    @moxaMap = @$moxaPtr;

    my @coList;
    @coList = @$coPtr;

    $numCtlrs = scalar( @coList );

    $failType = "RND";          # convert to upper case

    $ret = ValidateType ( $failType );
    if ( $ret == ERROR )
    {
        logError("    ====> Unuseable failure type specified  ( $failType ) <====");
        return ERROR;
    }


    ##########################################################################
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    ##########################################################################


    #
    # get a list of serial numbers to make the output a little 
    # more user friendly. also used by one of the tests.
    #
    
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
    }


    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $newMaster == INVALID )
    {
        logError("    ====> Failed to find the master controller [$failCount failovers completed] <====");
        return ERROR;
    }
    
    #
    # display some starting info
    #
    
    $ret = TestLibs::IntegCCBELib::DispPdiskInfo($coList[$newMaster]);

    if ( $ret == ERROR )
    {
        logError("Failed to get pdisk info at start");
        return ERROR;
    }

    $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$newMaster] );
    if ( $ret == ERROR )
    {
        logError("Failed to get target list at start");
        return ERROR;
    }

    $failCount = 0;

    # Default to 2000 loops unless specified
    if (!$loopCount)
    {
        $loop1 = 2000;
    }
    else
    {
        $loop1 = $loopCount;
    }

    #
    # find the currently active servers
    #

    my @activeServers = TestLibs::Validate::ActiveServerList($coPtr);


    #
    # get the initial/starting target map
    #

    logInfo("Getting the target status, then building the target map");
    
#    %info1 = GetTargetStatus($coList[$newMaster]);
#
#    if ( ! %info1  )              # if no data from call
#    {
#        logInfo(">>>>>>>> Failed to get a response from GetTargetStatus <<<<<<<<");
#        return ERROR;
#    }
#
#    if ( $info1{STATUS} != PI_GOOD )      # if call returned an error
#    {
#        logInfo(">>>>>>>> Error from GetTargetStatus <<<<<<<<");
#        PrintError(%info1);
#        return ERROR;
#    }
#    
#    @startingTmap = CreateTargetMap(\@serialNums, %info1);
#
#    PrintTargetMap (\@startingTmap);

    $ret = GroupTargetMap($coPtr, \@serialNums, \@startingTmap, $newMaster,  LOGTARGETMAP);
    if ( $ret != GOOD )  {return ERROR; }



    


    #
    # get the initial active vdisks for the test
    #


    @initialVdisks =  ActiveVdiskList($coPtr);

    $vdiskListPtr  = \@initialVdisks;

    if ( scalar(@initialVdisks) != 0 )
    {
        # we have some active vdisks
        if ( $initialVdisks[0] == INVALID )
        {
            # error case 
            logInfo("    ====> Warning - can't get an initial active vdisklist  <====");
            $vdiskListPtr  = 0;   # clear the point so we skip the following tests
        }
    }

    ############################################################################

    #####################################
    # The loop that is really the test
    #####################################

    for ( $i = 0; $i < $loop1; $i++ )
    {
        # pick a survivor. this is one of the controllers, randomly chosen,
        
        $survivor = TestLibs::utility::randomInt( 0, ($numCtlrs - 1) );

        ###############################################################
        # First we loop thru all the victims and fail each one of them
        ###############################################################

        for ( $j = 0; $j < $numCtlrs; $j++ )
        {
            if ( $j != $survivor )     # for each slave ( actually, each non-master )
            {
                # get ctlr SN
                $ctlrSN = TestLibs::IntegCCBELib::GetSerial( $coList[$j] );

                # decide how to fail the controller
                $how2fail = GetFailMethod($failType);

                # if we are going to ET the CCB, then we need to tweak 
                # the config of the controller a bit

                if ( $how2fail eq "CCBET" )
                {
                    $ret = TestLibs::IntegCCBELib::SuicideOK ($coPtr);
                    if ( $ret == ERROR )
                    {
                        logError("    ====> Failed to enable suicide for proc <====");
                        return ERROR;
                    }
                }

                logInfo("Failing a controller ($serialNums[$j], $how2fail) [$failCount failovers completed] ");

                ########################
                # now force the failure
                ########################

                if ( $how2fail eq "PC" )
                {
                    # brute force power cycle handled here
                    $ret = TestLibs::IntegCCBELib::PowerChange($moxaIP, $moxaMap[$j], 0);
                    if ( $ret == ERROR )
                    {
                        logError("    ====> Failed to power down the controller [$failCount failovers completed]  <====");
                        return ERROR;
                    }
                }
                else
                {
                    # other forms of failure here
                    $ret = FailOverController($coPtr, $j, $how2fail);
                    if ( $ret == ERROR )
                    {
                        logError("    ====> Could not fail the controller [$failCount failovers completed]  <====");
                        return ERROR;
                    }
                }

                # allow all failover activity to complete and the 
                # servers to complete some operations
                logInfo("Pause for 120 seconds");        
                #DelaySecs(120);

                FailOverTimeLine( $coList[$survivor], 120, \@serialNums, 0);

                ##################################################################
                #
                # Test the state of the system (at least one controller IS failed)
                #
                ##################################################################
                $ret = TestLibs::Validate::TestSystemState(\@coList, \@activeServers, 0, $vdiskListPtr, \@serialNums);
                if ( $ret == ERROR )
                {
                    logInfo("    ====> Controller state bad with some failed [$failCount failovers completed]  <====");
                    return ERROR;
                }



                $failCount++;
            }

        }

        ###################################################
        # all controllers except the survivor are failed
        ##################################################

        #######################################################
        # find the master, it really should be the survivor
        #######################################################

        logInfo("Searching for the master controller in the group");
        $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
        if ( $newMaster == INVALID )
        {
            logError("    ====> Failed to find the master controller [$failCount failovers completed]  <====");
            return ERROR;
        }
            
        TestLibs::IntegCCBELib::DispVcgInfo($coList[$newMaster]); 
              

        ########################################################
        # now determine how we will attempt to fail the survivor
        ########################################################

       
        # fail the Master
        $how2fail = GetNonFailMethod($failType);                                   #<<<<<<< work to do <<<<<<<<<<<<<<<<<<<

        # if we are going to ET the CCB, then we need to configure the 
        # controllers a bit first
        if ( $how2fail eq "CCB" )
        {
            $ret = TestLibs::IntegCCBELib::SuicideOK ($coPtr);
            if ( $ret == ERROR )
            {
                # A bunch WILL fail (all of the non-survivors)
                logInfo("    ====> Failed to enable suicide for proc  <====");
            }
        }

        logInfo("Trying to fail the surviving controller ($serialNums[$newMaster], $how2fail) [$failCount failovers completed] ");

        ########################################
        # now we attempt to fail the controller
        ########################################
        if ( $how2fail eq "PC" )
        {
            # brute force power cycle handled here
            $ret = TestLibs::IntegCCBELib::PowerCycle($moxaIP, $moxaMap[$newMaster]);
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to power cycle the controller [$failCount failovers completed]  <====");
                return ERROR;
            }

            # we are going to need to reconnect here....

            logInfo("Pause for 60 seconds and reconnect to the surviving controller [$failCount failovers completed] ");
            $ret = TestLibs::IntegCCBELib::Reconnect( $coList[$newMaster], 60 );
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to reconnect to the controller  [$failCount failovers completed] <====");
                return ERROR;
            }
     
     
            $ret = Wait4MinPowerUpState($coList[$newMaster], POWER_UP_COMPLETE, 360);    # wait for the controller to sufficiently boot

            # this guy should be good here
            if ( $ret != GOOD )
            {   
                # ok, it didn't come ready
                logError("    ====> Surviving controller didn't survive a reboot.  [$failCount failovers completed] <====");
                return ERROR;
                    
            }

        }
        else
        {
            # other forms of failure here
            $ret = FailOverController($coPtr, $newMaster, $how2fail);         #<<<<<<<<<<<<<<< work to do <<<<<<<<<<<<<<<<<<<<<
            if ( $ret == ERROR )
            {
                logError("    ====> Could not fail the master controller [$failCount failovers completed]  <====");
                return ERROR;
            }
        }

        logInfo("Pause for 120 seconds");
        #DelaySecs(120);
        FailOverTimeLine( $coList[$survivor], 120, \@serialNums, 0);

        ####################################################################
        #
        # Test the state of the system ( ONE controller should be alive )
        #
        ####################################################################
        $ret = TestLibs::Validate::TestSystemState(\@coList, \@activeServers, 0, $vdiskListPtr, \@serialNums);
        if ( $ret == ERROR )
        {
            logInfo("    ====> Controller state bad with master failed [$failCount failovers completed]  <====");
            return ERROR;
        }


        ## now we need to unfail ALL the debris along the side of the road

        ############################################
        # Loop to unfail each of the non-survivors 
        ############################################

        # note: this will not work for a serial # = 0 !!!

        while ( 0 < ($failedSN = FindNextFailedCtlr($coList[$survivor])) )
        {
            # we got the SN, nor get the coList index.    
            $index = WhichCtlr($failedSN, \@serialNums);

            if ( $index == INVALID )
            {
                # shouldn't happen we are outta here
                logInfo("    ====> MATCHING serial number NOT found. Something is wrong! (SN = $failedSN )  <====");
                return ERROR;
            }
            
            # power cycle the controller
            logInfo("Power Cycle the dead  controller ($serialNums[$index]) [$failCount failovers completed] ");
            $ret = TestLibs::IntegCCBELib::PowerCycle($moxaIP, $moxaMap[$index ]);
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to power cycle the controller  [$failCount failovers completed] <====");
                return ERROR;
            }
        
            # need to reconnect to the controller
            logInfo("Pause for 60 seconds and reconnect to the controller [$failCount failovers completed] ");
            $ret = TestLibs::IntegCCBELib::Reconnect( $coList[$index], 60 );
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to reconnect to the controller  [$failCount failovers completed] <====");
                return ERROR;
            }
     
            Wait4MinPowerUpState($coList[$index], POWER_UP_INACTIVE, 360);    # wait for the controller to sufficiently boot

            # unfail the controller
            logInfo("Unfailing the controller  ($serialNums[$survivor], $failedSN) [$failCount failovers completed] ");
            $ret = UnFailController( $coList[$survivor], $failedSN );
            if ( $ret == ERROR )
            {
                logError("    ====> Failed to make the controller useable [$failCount failovers completed]  <====");
                return ERROR;
            }
        
            # allow failback to complete
            #DelaySecs(120);
            FailOverTimeLine( $coList[$survivor], 120, \@serialNums, $coList[$index]);


            ####################################################################
            #
            # Test the state of the system ( as each controller is unfailed )
            #
            ####################################################################
  ##          $ret = TestLibs::Validate::TestSystemState(\@coList, \@activeServers, 0, $vdiskListPtr, \@serialNums);
            if ( $ret == ERROR )
            {
                logInfo("    ====> Controller state bad with controller unfailed  [$failCount failovers completed]  <====");
                return ERROR;
            }



        }


        ## now everyone should be happily moving data

       
        ####################################################################
        #
        # Test the state of the system ( all controllers working )
        #
        ####################################################################
        $ret = TestLibs::Validate::TestSystemState(\@coList, \@activeServers, \@startingTmap, $vdiskListPtr, \@serialNums);
        if ( $ret == ERROR )
        {
            logInfo("    ====> Controller state bad with (old) master unfailed  [$failCount failovers completed]  <====");
            return ERROR;
        }

        logInfo("--------------------- Loop $i completed, $failCount failovers completed. -------------------");
    }
    # end loop

    logInfo("End of Fail Over Loop test, $failCount failovers completed.");
    return GOOD;

}


###############################################################################

    
#################################################################################


###############################################################################

=head2 MvTgtLoop function

A failover test that just moves targets, controllers are not actually failed..

=cut

=over 1

=item Usage:

 my $rc = MvTgtLoop( TBD);
 
 where,
        $
        $

=item Returns:

       $rc is GOOD if the test passes, ERROR otherwise


=item Description:
 
 Tests the ability to move targets from one controller to another.

=back

=cut



##############################################################################
#                                                                               
#          Name: MvTgtLoop
#
#        Inputs: 
#
#       Outputs: 
#
#  Globals Used: none
#
#   Description: 
# 
#
##############################################################################
sub MvTgtLoop
{
    trace();                        # This allows function tracability

    my ($coPtr,  $loopCount ) = @_;

    my $i;
    my $numCtlrs;
    my $master;
    my $slave;
    my @serialNums;
    my @coList;
    my $ret;
    my $retVal;

    $retVal = GOOD;
     
    @coList = @$coPtr;

    $numCtlrs = scalar(@coList);

    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
    }
    
    $master = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    
    $slave = 1;
    if ( $master == 1 ) { $slave = 0; }

    for ( $i = 0; $i < $loopCount; $i++)
    {
        
        ###################
        # Move All to Slave
        ###################
        MoveTarget($coList[$master], $serialNums[$slave], 0 );
        MoveTarget($coList[$master], $serialNums[$slave], 1 );
        MoveTarget($coList[$master], $serialNums[$slave], 2 );
        MoveTarget($coList[$master], $serialNums[$slave], 3 );

        FailOverTimeLine( $coList[$master], 120, \@serialNums, $coList[$slave]);

        $ret =  TargetList( $coList[$master] );
        if ( $ret == ERROR )
        {
            logInfo("    ====> Failed - Display target status  <====");
            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;
        }

        ######################
        # Move back to Master
        ######################
        MoveTarget($coList[$master], $serialNums[$master], 0 );
        MoveTarget($coList[$master], $serialNums[$master], 1 );
        MoveTarget($coList[$master], $serialNums[$master], 2 );
        MoveTarget($coList[$master], $serialNums[$master], 3 );

        FailOverTimeLine( $coList[$master], 120, \@serialNums, $coList[$slave]);

        $ret =  TargetList( $coList[$master] );
        if ( $ret == ERROR )
        {
            logInfo("    ====> Failed - Display target status  <====");
            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;
        }
        #####################
        # Move All to Master
        #####################
        MoveTarget($coList[$master], $serialNums[$master], 4 );
        MoveTarget($coList[$master], $serialNums[$master], 5 );
        MoveTarget($coList[$master], $serialNums[$master], 6 );
        MoveTarget($coList[$master], $serialNums[$master], 7 );

        FailOverTimeLine( $coList[$master], 120, \@serialNums, $coList[$slave]);

        $ret =  TargetList( $coList[$master] );
        if ( $ret == ERROR )
        {
            logInfo("    ====> Failed - Display target status  <====");
            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;
        }

        #####################
        # Move back to Slave
        #####################
        MoveTarget($coList[$master], $serialNums[$slave], 4 );
        MoveTarget($coList[$master], $serialNums[$slave], 5 );
        MoveTarget($coList[$master], $serialNums[$slave], 6 );
        MoveTarget($coList[$master], $serialNums[$slave], 7 );

        FailOverTimeLine( $coList[$master], 120, \@serialNums, $coList[$slave]);

        $ret =  TargetList( $coList[$master] );
        if ( $ret == ERROR )
        {
            logInfo("    ====> Failed - Display target status  <====");
            $retVal = ERROR;   # defer the return until all tests are done
            #return ERROR;
        }
    

    }    # end of for..loopCount
 
    return $retVal;
}
####################################################################################

#######################################################################################

=head2 BrocadeLooper function

XTC interface to the Brocade stress loop function.

=cut

=over 1

=item Usage:

 my $rc = BrocadeLoop( the following list of parameters );
 
=item Returns:

       $rc GOOD or ERROR.

=item Description:
 
        Build needed data structures for upcoming calls. Also connect
            to each controller (CCBE style).
        Call BrocadeLoop function.
        Disconnect from each controller (CCBE style).

=back

=cut

#######################################################################
### Function name: BrocadeLooper
###
### Purpose: Process configuration data and then call FailOverLoop
##
## INPUT:    
## Outputs: GOOD, if successful, ERROR otherwise
#######################################################################

sub BrocadeLooper
{
    trace();                        # This allows function tracability

    my (
        $curBigfootIPPtr,  
        $curSwitchNamePtr,
        $curSwitchIPPtr,
        $curSwitchUsernamePtr,
        $curSwitchPasswordPtr,
        $curTestArgument,
        $moxaNamesPtr,
        $moxaIPsPtr,
        $moxaChannelsPtr,
        $loopCount,
        $vcgGroupsPtr,
        $curTestGroup,
        $curTestParmHashPtr,
        $useXMC
       ) = @_;

# Local Variables
    my $returnValue;
    my $indexName = 0;
    my $indexMoxa;
    my $brocadeReturn;
    my @ccbeObjArray;
    my @switchesToTest;
    my $switchToTest;
    my $switchName;
    my @brocadeIPs;
    my @brocadeUsers;
    my @brocadePWs;
    my @moxaIPs;
    my @moxaChannels;

    my @SortBy = sort(keys( %$curTestParmHashPtr ));     
    for (my $ i = 0; $i < scalar( @SortBy ); $i++)
    {
        if ($SortBy[$i] =~ /^\s*switch/i)
        {
            push (@switchesToTest, $$curTestParmHashPtr{$SortBy[$i]} );
        }
    }


    # Connect to all the controllers in this VCG
    TestLibs::Logging::debug ("Connect to all controllers in the VCG");
    TestLibs::IntegCCBELib::CcbeConnectAll($curBigfootIPPtr, \@ccbeObjArray); 

    # Check each switch name
    foreach $switchName (@$curSwitchNamePtr)              
    {
        # Against each switch to test
        foreach $switchToTest (@switchesToTest)              
        {
            if ($switchName eq $switchToTest)
            {
                # Build the arrays that define this group
                push (@brocadeIPs, @$curSwitchIPPtr[$indexName]);         
                push (@brocadeUsers, @$curSwitchUsernamePtr[$indexName]);         
                push (@brocadePWs, @$curSwitchPasswordPtr[$indexName]);         

                # Build Moxa Array
                $indexMoxa = 0;
                foreach my $deviceName (@$moxaNamesPtr)
                {
                    if ($deviceName eq $switchName)
                    {
                        push (@moxaIPs, @$moxaIPsPtr[$indexMoxa]);
                        push (@moxaChannels, @$moxaChannelsPtr[$indexMoxa]);
                    }
                    $indexMoxa++;
                }
            }
        }
        $indexName++;
    }
    
# Debug
logInfo ("CCBE Objs:@ccbeObjArray,
         brocadeIPs:@brocadeIPs,
         brocadeUsers:@brocadeUsers,
         brocadePWs:@brocadePWs,
         moxaIPs:@moxaIPs,
         moxaChannels:@moxaChannels,
         curTestArgument:$curTestArgument,
         brocadestressloops:$$curTestParmHashPtr{'brocadestressloops'}");

    # Call the BrocadeLoop function
    $brocadeReturn = BrocadeLoop (\@ccbeObjArray,
                                  \@brocadeIPs,
                                  \@brocadeUsers,
                                  \@brocadePWs,
                                  \@moxaIPs,
                                  \@moxaChannels,
                                  $curTestArgument,
                                  $$curTestParmHashPtr{"brocadestressloops"});
    if ($brocadeReturn != GOOD)
    {
        return $brocadeReturn;
    }
    
    # Disconnect from all controllers in this VCG
    Testlibs::IntegCCBELib::CcbeDisconnectAll(\@ccbeObjArray);

    TestLibs::utility::randomDelay($$curTestParmHashPtr{"brocadestresswaitmin"}, $$curTestParmHashPtr{"brocadestresswaitmax"});

    return GOOD;
}

#######################################################################################

1;   # we need this for a PM

__END__

#######################################################################################

=head1 CHANGELOG

 $Log$
 Revision 1.6  2006/11/15 20:40:59  HoltyB
 TBolt00000000:Prevent double powercycle if ssh and last failure PC

 Revision 1.5  2006/09/20 13:56:32  EidenN
 tbolt00000000:
 Added CleanUpUnFailAll sub to check for a failed controller at the start of the test and unfail it.

 Revision 1.4  2006/09/18 15:17:47  EidenN
 tbolt00000000:
 Added a cleanup before starting the test cycle

 Revision 1.3  2006/08/07 20:20:38  EidenN
 tbolt00000000
 Add 750 check with shorter timeline setting

 Revision 1.2  2005/09/13 14:14:36  ElvesterN
 Added CTE update conditional.
 Reviewed by Neal Eiden.

 Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
 import CT1_BR to shared/Wookiee

 Revision 1.70  2005/05/04 18:11:21  PalmiD
 TBolt00000000: Added a flexible wait for the cache batteries after an unfail.
 Reviewed by Craig Menning.

 Revision 1.69  2005/03/08 19:50:08  ElvesterN
 Tbolt0000000: Added ability to send additional information to the Validate.pm allowing for a more limited resync validation cycle to speed failover times - Reviewed By:  CraigM

 Revision 1.68  2005/01/12 23:18:15  PalmiD
 TBolt00000000: Changed calls to "CheckBEHashes" to use mirror data hash.
 Added Write Cache support to FailOverLoop and FailOverNWayLoop. General
 cleanup of error message syntax.
 Reviewed by Craig Menning.

 Revision 1.67  2004/11/09 21:37:49  MenningC
 TBOLT00000000: fix for mirror resync wait and syswrite problem. Reviewed by Al

 Revision 1.66  2004/10/26 22:35:08  MenningC
 Tbolt00000000: updates to support resync in Rel 3.1/Yeti. reviewed by Al

 Revision 1.65  2004/08/09 20:07:28  MenningC
 tbolt00000000: display more info during validations, reviewed by Chris

 Revision 1.64  2004/06/29 14:52:09  KohlmeyerA
 Tbolt00000000:  Updated results table in DownFELoopLong2 for latest failover behavior.
 Modified by Gopinadh.  Reviewed by Allen

 Revision 1.63  2004/06/16 16:18:40  MenningC
 Tbolt00000000: fix some function paths, reviewed by Al

 Revision 1.62  2004/06/15 21:25:16  MenningC
 tbolt00000000: updates for tclaunch for eng test; reviewed by Al

 Revision 1.61  2004/06/14 21:10:59  MenningC
 tbolt00000000: fail when we can't connect to a controller at the start of failover. reviewed by Al

 Revision 1.60  2004/05/24 13:55:21  MenningC
 tbolt00000000: Detect errors failing items in failover nway, ignore R10 miscompare in parity scan, updates to logged info, detect inop raids in failover. . reviewed by Al

 Revision 1.59  2004/04/14 18:09:10  MenningC
 tbolt00000000: changed BE validation for failover to eliminate the hex from a BE state failure., reviewed by Al

 Revision 1.58  2004/02/25 17:58:23  MenningC
 tbolt00000000:Additional output and changes requested by Chris. reviewed by Al

 Revision 1.57  2004/02/05 19:54:09  MenningC
 tbolt00000000: new power control script and related changes; reviewed by Al.

 Revision 1.56  2004/01/27 19:52:41  MenningC
 TBOLT00000000:changes for readability and additional data collection.
 Reviewed by Al

 Revision 1.55  2004/01/19 22:49:52  MenningC
 TBOLT00000000:added vcg inactivate controller (IC) as a failure mechanism; reviewed by Carlos.

 Revision 1.54  2003/12/30 14:08:58  MenningC
 TBOLT00000000: Additions for nwayfailover

 Revision 1.53  2003/12/23 20:48:14  MenningC
 TBOLT00000000: Additions for the nway failover test. Reviewed by Olga

 Revision 1.52  2003/10/21 16:27:07  MenningC
 tbolt00000000: added check for moxa control at beginning of failover test

 Revision 1.51  2003/10/17 15:57:05  WerningJ
 Tbolt00000000: fixes for FEPULL failover. reviewed by Olga

 Revision 1.50  2003/09/29 18:16:20  MenningC
 tbolt00000000: Take out an extra validation; Reviewed by Jim S

 Revision 1.49  2003/09/26 22:43:02  ThiemanE
 Updated include library names to make them Linux compatible

 Revision 1.48  2003/09/25 21:59:03  MenningC
 tbolt00000000: fix option bit for and reviewed by Jim S.

 Revision 1.47  2003/09/24 19:59:10  MenningC
 tbolt00000000: support for a r5 resync check for failover; for and reviewed by Jim S.

 Revision 1.46  2003/07/23 14:04:16  MenningC
 tbolt00000000: added support for an additional loop parameter, add initial parityscan support to failover; reviewed by Olga

 Revision 1.45  2003/07/17 19:51:53  MenningC
 Tbolt00000000: add support for optional failover parameters, reviewed by Olga

 Revision 1.44  2003/06/13 15:06:46  MenningC
 TBOLT00000000: log serial number rather than index. reviewed by Eric

 Revision 1.43  2003/06/05 21:32:21  MenningC
 TBOLT00000000: cosmetic changes for failover; reviewed by Eric.

 Revision 1.42  2003/06/05 15:09:46  MenningC
 TBOLT00000000: fixes for nvram pt1 selection and failover timeline changes;
  reviewed by Eric.

 Revision 1.41  2003/05/29 12:56:44  WerningJ
 Rewrote all XTC data structures
 Reviewed by Craig M

 Revision 1.40  2003/04/15 19:11:46  MenningC
 tbolt00000000: broke failover into two parts, fixed links; reviewed by JW

 Revision 1.39  2003/03/27 21:29:39  MenningC
 Fix BEPULL in failover, remove case14 in bestress; reviewed by JW

 Revision 1.38  2003/03/27 17:36:18  WerningJ
 Removed calls XMC disconnect which are no longer required
 Reviewed by Olga

 Revision 1.37  2003/03/14 16:24:38  WerningJ
 Updated DownFELoopLong for the Latest RM changes
 Reviewed by Craig M

 Revision 1.36  2003/03/03 23:03:29  MenningC
 tbolt00000000 fix for BEStress and new failover test case for Neal, reviewed by JW

 Revision 1.35  2003/02/05 15:41:07  WerningJ
 Added Log File parm to the Error Inject
 Reviewed by Craig M

 Revision 1.34  2003/01/29 16:28:22  WerningJ
 Add Error Inject Function
 Reviewed by Craig M

 Revision 1.33  2003/01/21 19:49:14  MenningC
 Tbolt00000000: more debug of the BEstress tests, reviewed by J Werning

 Revision 1.32  2003/01/14 15:26:39  MenningC
 Tbolt00000000: Changes to support BEUtils lib, removed UMC. Reveiewed by J Werning.

 Revision 1.31  2003/01/07 22:39:16  NigburC
 TBolt00000000: fix moxa pointer; Reviewed by Jeff W.

 Revision 1.30  2003/01/07 22:27:50  MenningC
 Tbolt00000000: Many changes to handle the new content of targetstatus, reveiwed by Jeff Werning

 Revision 1.29  2003/01/04 14:53:55  WerningJ
 Added Quiet flags to DownFE and VCGfailRandom
 Used NoFailureManager instead of NoSuicide
 Reviewed by Craig M

 Revision 1.28  2003/01/03 20:43:22  MenningC
 Tbolt00000000:fixed moxa Ip address list, reveiwed by Jeff Werning

 Revision 1.27  2002/12/04 14:23:16  MenningC
 tbolt00000000 modiifcation to IO and BE checks for Neal, reviewed by Olga and/or Jeff W.

 Revision 1.26  2002/11/20 16:50:46  WerningJ
 Qualified calls to logError
 Added options to Suicide or Error trap when Port tests fail
 Reviewed by Craig M

 Revision 1.25  2002/11/13 20:30:18  MenningC
 tbolt00000000: Additional changes for the defrag test ; reviewed by J Werning

 Revision 1.24  2002/11/11 22:01:48  MenningC
 TBOLT00000000: brocade switch test was added; reviewed by J. Werning

 Revision 1.23  2002/11/11 21:27:08  WerningJ
 Added a launcher for BrocadeLoop
 Reviewed by Craig M

 Revision 1.22  2002/11/01 21:33:56  WerningJ
 Added validation checks to all Failover routines
 Reviewed by Craig M

 Revision 1.20  2002/10/03 19:05:44  MenningC
 tbolt00000000 fix a type reviewed by Olga

 Revision 1.19  2002/10/01 19:29:50  WerningJ
 Added flag to check for Use of XMC, true or false
 Reviewed by Craig M

 Revision 1.18  2002/09/25 14:58:11  WerningJ
 Added Controller log markers when enabling and disabling ports
 Reviewed by Craig M

 Revision 1.17  2002/09/25 14:46:50  MenningC
 TBOLT00000000 moved some constants; reviewed by Werning

 Revision 1.16  2002/09/10 19:08:24  MenningC
 TBOLT00000000 added move target test, reviewed by Jeff Werning

 Revision 1.15  2002/08/22 20:14:30  WerningJ
 Added DownFELoopLong2 for Systems with only two FE interfaces per controller
 Reviewed by Eric T

 Revision 1.14  2002/08/21 14:11:34  MenningC
 Tbolt00000000 fise suicide when error trapping ccb. reviewed by Jeff Werning

 Revision 1.13  2002/08/20 21:03:31  MenningC
 Tbolt00000000 updates to testSystemState, reveiwed by Tim

 Revision 1.12  2002/08/20 16:13:44  ThiemannE
 Integrated Tom Swansons test functions into the library.
 Reviewed by Craigm.

 Revision 1.11  2002/08/14 15:25:34  MenningC
 Tbolt00000000 more timeline changes  reviewed by Jeff

 Revision 1.10  2002/08/11 20:10:09  MenningC
 TBOLT00000000 added timeline and initial BE check. reveiwed by Jeff Werning

 Revision 1.9  2002/08/10 14:54:56  MenningC
 detab

 Revision 1.8  2002/08/10 14:41:23  WerningJ
 Added check of return code when calling FailOverLoop and Add the QLFALL option to the
 VCGFailRandom function
 Reviewed by Craig M

 Revision 1.7  2002/08/10 13:04:31  MenningC
 TBOLT00000000 perldoc added

 Revision 1.6  2002/08/09 19:54:49  MenningC
 TBOLT00000000 cleaned up some prints, check for no sn one place, add some new (untested) functions.  reviewed by Eric.

 Revision 1.5  2002/08/06 21:32:00  MenningC
 TBOLT00000000 fixed my bad spelling and change logic in validation. reviewed by Eric

 Revision 1.4  2002/08/05 14:12:47  MenningC
 tbolt00000000 fail-over validation changes reviewed by Jeff Werning

 Revision 1.3  2002/08/02 01:44:55  HouseK
 Added or corrected some POD (perldoc)

 Revision 1.2  2002/07/31 19:44:18  HouseK
 Result of merge from tag LOGGING_CHANGES

 Revision 1.1.2.7  2002/07/31 18:19:54  MenningC
 Tbolt00000000  fixed some error checking

 Revision 1.1.2.6  2002/07/31 16:26:07  MenningC
 Tbolt00000000

 Revision 1.1.2.5  2002/07/31 12:49:32  MenningC
 Tbolt00000000 adjusted paths to some functions

 Revision 1.1.2.4  2002/07/30 20:54:08  MenningC
 Tbolt00000000 changes to facilitate compiling and power cycle as a failover method

 Revision 1.1.2.3  2002/07/29 15:41:39  WerningJ
 Changes to support merge between Failover routines and functions
  moved to other libraries.
 Reviewed by Craig M

 Revision 1.1.2.2  2002/07/28 19:07:48  MenningC
 Tbolt00000000 continued changes for logging

 Revision 1.1.2.1  2002/07/27 04:49:51  WerningJ
 Initial FailOver Library

=cut
