#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library - User Error tests
#
#   112/26/2002  XIOtech   Craig Menning
#
#   A set of library functions for integration testing. This set try to do
#   actions a user might do incorrectly.
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2002 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::UETest.pm - Test that may simulate user errors.

$Id: UETest.pm 5002 2005-09-13 14:16:55Z ElvesterN $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL>
     <LI>Linux</LI>
     <LI>Windows</LI>
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing the robustness
of the design of the controller.



=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

            UETestEntry()

        The less significant ones

              <none>

=cut


#
# - what I am
#

package TestLibs::UETest;

#
# - other modules used
#
use Data::Dumper ;

use warnings;
use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use XIOTech::cmdMgr;
use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;
use TestLibs::UETestSupport;


#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - local Constants used
#

#use constant ALLCTLRS     => 17;
#use constant SINGLECTLR   => 18;
#use constant MASTERCTLR   => 19;
#use constant SLAVECTLR    => 20;
#use constant ALLSLAVES    => 21;

#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 5002 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &UETestEntry
                        &UETestCase51


                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 5002 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.

 $moxaPtr: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.

 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller.

 $retIn: This is a controle variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the
          attached servers. When configuring systems, this list determines
          which WWNs will be associated with vdisks. If an entry in this
          list is not found on the system, it will be ignored. A WWN
          found on the system that is not included in the list will not
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this
        is the pointer to that controller object. It is one of the
        members of the list that $coPtr points to.




=back

=cut


###############################################################################


###############################################################################



###############################################################################


##############################################################################
#
#               Private Functions, but made public for debug
#
##############################################################################

#############################################################################


###############################################################################

=head2 UETestCase01 function

Orphaned RAID test. Deletes a vdisk during raid init. The test has these
basic steps...

     0) Houseclean system
     1) get a list of vdisks and raids
     2) create a vdisk and expand it several times
     3) start raid init on all the parts
     4) delete the vdisk
     5) look for orphaned raids
     6) repeat 2-5 for other raid types
     7) repeat 2-6 for different raid sizes
     8) clean up, if possible
     9) verify any existing I/O is still OK

=cut

=over 1

=item Usage:

 my $rc = UETestCase01( $coPtr, $retIn, $snPtr   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 Any failures should come from orphaned raids (what the test is 
 looking for). Failure dure to I/O problems are not expected.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: UETestCase01
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#
##############################################################################
sub UETestCase01
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my %vdisks;
    my %raids;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;
    my @currentVdisks;

    my @raids;
    my @sizes;
    my @disks;
    my @vdisks;
    my $raid;
    my $pdskPtr;
    my $sIdx;
    my $rIdx;
    my $size;
    my $expSize;
    my $newVDD;
    my $i;
    my %ret;

    my $sps;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ UE Test Case 1: Delete a vdisk during raid init  ---------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # With a redi-CP running, fail one of the data pdisks.
    ######################################################################

    # setup - need to houseclean

    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
#    $ret = DefragAll($ctlr);
#    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );

    # system is 'packed' ready for the test
    logInfo("-------------- Setup complete for UE test case 1. ---------------------");



    #
    # Get the background data on the current list of raids and vdisks.
    # This info is in a vdisks packet. We will also need the raids
    # packet.
    #

    # - get the vdisks hash

    %vdisks = $ctlr->virtualDisks();
    if ( ! %vdisks  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
        return ERROR;
    }
    if ( $vdisks{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
        PrintError(%vdisks);
        return ERROR;
    }



    # - get the raids hash

    %raids = $ctlr->raids();
    if ( ! %raids  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $raids{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%raids);
        return ERROR;
    }

    logInfo("UE test 01: Initial raids");
    $msg = $ctlr->displayRaids( %raids);
    logInfo("\n".$msg);
            


    #
    # With both raids and vdisks hashes, we can verify that there are no
    # orphaned raids at the start of the test.
    #

    # - look for orphans
    
    logInfo("UE test 01: Initial orphan check");

    $ret = OrphanedRaidCheck( \%vdisks, \%raids );
    if ($ret != GOOD)
    {
        logInfo("Failed initial orphaned raids check.");
        return ERROR;
    }




    #
    # We need to work with different RAID types and sizes. This gives us
    # two nested loops, one for size and the other for RAID type. First,
    # we setup the data arrays to be used by the loops. We also need
    # to generate groups of pdisks to use, one data, one unsafes. 
    #

    # - raids array, the raid types to test
    @raids = ( RAID_5, RAID_10 );   # raids 5 and 10

    # - sizes array, the array of sizes to use
    @sizes = (100, 10000);

    # - get a disk set(s) to use - need DATA for raid 5/10
    @disks = GetDataDisks($ctlr, FC_PREFERRED);    
    if ( $disks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of data disks. <<<<<<<<");
        return ERROR;
    }


    # - get initial vdisks (these we don't init)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }

    #
    # Now do the loops that are the test
    #

    for ( $rIdx = 0; $rIdx < scalar(@raids); $rIdx++ )
    {
        
        #
        # this is the raids loop.
        #

        $raid = $raids[$rIdx];

        if ( $raid == RAID_5 )
        {
            $sps = 64;
        }
        else
        {
            $sps = 512;
        }
        
        #
        # Given the raid type, also pick the disk group to use.
        #


        # - select one disk group(safe/unsafe)
        $pdskPtr = \@disks;          # raid 5/10 only

        for ( $sIdx = 0; $sIdx < scalar(@sizes); $sIdx++ )
        {


            # - get initial vdisks (these we don't init)
            @vdisks = GetVdiskList( $ctlr );
            if ( $vdisks[0] == INVALID )
            {
                logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
                return ERROR;
            }


            logInfo(" ");
            logInfo("--------------------------------------------------------------------------");
            logInfo(" ");
        

            #
            # This is the size loop
            #

            $size = $sizes[$sIdx];
            $expSize =  $size * 2048;

            #
            # Indicate which iteration we are on
            #

            logInfo("UE test 01: Creating and expanding a vdisk using raid $raid, each raid $size mbytes.");
            logInfo(" ");
            logInfo("--------------------------------------------------------------------------");
            logInfo(" ");

            #
            # create the vdisk and initial raid
            #

            logInfo("UE test 01: Create using   ORPHAN, size= $size, raid= $raid, $sps, 2, 3 ");

            $newVDD = CreateSingleVdisk($ctlr, "ORPHAN", $size, $raid, $sps, 2, 3, $pdskPtr, undef);
            if ( $newVDD == INVALID )
            {
                logInfo ("failure creating new vdisk for test.");
                return ERROR;
            }

            #
            # Log the created vdisk number
            #

            logInfo ("Vdisk $newVDD was created.");

            #
            # now do several expansions
            #


            for ( $i = 0; $i < 5; $i++ )
            {
                
                #
                # we expand by the same amount
                #


                logInfo("Expanding vdisk $newVDD.");

                # vdisk expand
                %ret = $ctlr->virtualDiskExpand( $newVDD,     #  vdd to expand
                                                $expSize,     #  $capacity,
                                                $pdskPtr,     #  $pdPointer,
                                                $raid,        #  $rtype,
                                                $sps,         #  $stripe,
                                                2,            #  $depth,
                                                3 );          #  $parity);


                if ( ! %ret  )              # if no return from call
                {
                    logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
                    return ERROR;
                }

                if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
                {
                    logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
                    PrintError(%ret);

                    #
                    # if we run out of space, don't expand any more. Just
                    # ignore the failure and go on.  
                    # PI_ERROR_INS_DEV_CAP => 0x10;  # Insufficient device capacity
                    #
                    if (  $ret{ERROR_CODE} == 0x10 )
                    {
                        # ran out of space
                        last;
                    }
                    else
                    {
                        # other error
                        return ERROR;
                    }
                }



            }

            #
            # Indicate the expansions are done
            #

            logInfo("UE test 01: Expansions complete, starting raid inits.");


            #
            # Init all the (just created) raids
            #


            # - init newer raids - no wait
            $ret = InitNewerVdisks( $ctlr, \@vdisks );
            if ( $ret != GOOD ) 
            { 
                logInfo("Error starting inits on newer raids.");
                return ERROR; 
            }

            #
            # Now delete the vdisk. This should also take out
            # all the associated raids.
            #


                # - delete vdisk
            $ret = DeleteUnusedVdisks($ctlr);
            if ( $ret == ERROR )
            {
                logInfo("Failure deleting vdisks during inits");
            }

            #
            # Now the vdisk is gone and supposedly, all the raids.
            # Check to see if any inits are running and also check to 
            # see if any raids got orphaned. (There should be no
            # inits running and there should be no orphans.)
            #
            
                # - look for running inits, report and fail if found
  
                logInfo("UE test 01: Looking for any running raid inits.");
  
                # - get current  vdisks 
                @currentVdisks = GetVdiskList( $ctlr );

                if ( $currentVdisks[0] == INVALID )
                {
                    logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
                    return ERROR;
                }

                for( my $r = 0; $r < scalar(@currentVdisks); $r++)
                {
                    # if there is one initializing, then we have a failure
                    if ( 0 != CheckInitProgress($ctlr, $currentVdisks[$r] ) )
                    {
                        logInfo("Vdisk  $currentVdisks[$r] is still initializing.");
                        return ERROR;
                    }
                }

                # look for any rebuilds happening.

                logInfo("UE test 01: Looking for running rebuilds.");
                
                $ret = DegradeCheck( $ctlr);
                if ( $ret != GOOD )
                {
                    print "\n";
                    logInfo("One or more drives are degraded - test fails");
                    return ERROR;
                }




            # - look for orphans (need raids and vdisks hashes)
            # - get the vdisks hash

            %vdisks = $ctlr->virtualDisks();
            if ( ! %vdisks  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
                return ERROR;
            }
            if ( $vdisks{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
                PrintError(%vdisks);
                return ERROR;
            }



            # - get the raids hash

            %raids = $ctlr->raids();
            if ( ! %raids  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
                return ERROR;
            }
            if ( $raids{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from raids command <<<<<<<<");
                PrintError(%raids);
                return ERROR;
            }

            logInfo("UE test 01: Current raids");
            $msg = $ctlr->displayRaids( %raids);
            logInfo("\n".$msg);
            
            logInfo("UE test 01: Performing orphan check.");

            $ret = OrphanedRaidCheck( \%vdisks, \%raids );
            if ($ret != GOOD)
            {
                logInfo("Failed orphaned raids check after deletes.");
                return ERROR;
            }

            logInfo("UE test 01: Checks complete for this pass");

            # - Report problems and fail if any found


        }   # end of size loop


    }   # end of raid loop


    #
    # Now do a final I/O check. This should be good.
    #


    # verify IO
    logInfo("UE test 01: Confirm IO after test is done.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );

    if ($ret != GOOD)
    {
        logInfo("Failed I/O check at end of orphan test.");
        return ERROR;
    }


    logInfo("------------------------ End of UE test case 1. ----------------------");


    return GOOD;

}
###############################################################################
sub UETestCase20
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 20, 0  );

    return $ret;
}

###############################################################################
###############################################################################
sub UETestCase21
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 21, 1  );

    return $ret;
}

###############################################################################
###############################################################################
sub UETestCase22
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 22, 2  );

    return $ret;
}

###############################################################################
###############################################################################
sub UETestCase23
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;

    $ret = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 23, 3  );

    return $ret;
}

###############################################################################
###############################################################################
sub UETestCase24
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 24, 17  );

    return $ret;
}

###############################################################################
###############################################################################
sub UETestCase25
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 25, 18  );

    return $ret;
}

###############################################################################
###############################################################################
sub UETestCase26
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 26, 33  );

    return $ret;
}

###############################################################################
sub UETestCase27
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 27, 34  );

    return $ret;
}

###############################################################################
sub UETestCase28
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 28, 49  );

    return $ret;
}
###############################################################################
sub UETestCase29
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 29, 50  );

    return $ret;
}
###############################################################################
###############################################################################


=head2 UETestCase2x function

This test case sends Loop Primitive option 0 to all devices on the BE loop.

Loop Primitive option 0 is  LIP Reset loop = LIP(FF,al_ps)

The test has these
basic steps...
    1) initial startup stuff
    2) Identify list of LID to work on.
    3) LIP each one, wait ?? seconds between each LIP
    4) Check I/O
    5) Any other validation
    6) LIP each one, wait ?? seconds between each LIP
    7) Check I/O
    8) do any other validation




=cut

=over 1

=item Usage:

 my $rc = UETestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMean  );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serian numbers - unused
        $loopCount determines how many test loops are done
        $pDFailMean - unused

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.

 Here is the CCBE command we use.

      LOOPPRIMITIVE  processor  option  id  port  lid

        processor      Issue primitive to: FE|BE
        option         options -
                          0 - LIP Reset loop       = LIP(FF,al_ps)
                          1 - LIP Reset lid port   = LIP(al_pd,al_ps)
                          2 - LIP Reset sid or pid = LIP(al_pd,al_ps)
                          3 - Initiate LIP         = LIP(F7,al_ps)
                         17 - Login lid
                         18 - Login pid
                         33 - Logout lid
                         34 - Logout pid
                         49 - Target Reset lid
                         50 - Target Reset pid
                         65 - Loop Port Bypass (LPB) lid
                         66 - Loop Port Bypass (LPB) pid
                         81 - Loop Port Enable (LPE) lid
                         82 - Loop Port Enable (LPE) pid
                         Test modes below valid until next RESCAN LOOP
                         241 - Port bypass test lid
                         242 - Port bypass test pid
        id             pid (BE) or sid (FE)
        port           port
        lid            loop id



=back

=cut

##############################################################################
#
#          Name: UETestCase2x
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCounts
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub UETestCase2x
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, $tcNum, $lprim ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my $loops = 1;
#    my $newVd;


    if ( $loopCount )
    {
        $loops = $loopCount;
    }

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ UE Test Case $tcNum: Loop Primitive option $lprim on all BE devices.  --------";
    $msg0 = "------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

#    1) initial startup stuff









    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);



    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }

    #
    # get the initial active vdisks for the test
    #

    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    #
    # 2) Identify list of LID to work on.
    # Get a list of LIDs on each port for each controller in the group.
    # Each list item is a hash with the controller, lid, and port as 
    # elements. These will be used in a later call.
    #

    my @lids;
    
    $ret = GetBELids($coPtr, \@lids);
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>>>>>>>>>  Failure getting a list of LIDs fo the test. <<<<<<<<");
        return ERROR; 
    }


    ######################################################################
    # loops to LIP the BE devices.
    ######################################################################


    #
    #  3) LIP each one, wait 20 seconds between each LIP
    # First we do this rather slowly and not for many loops. Most of the 
    # fcn parms are set here, then changed as neede for the later call.
    #
    my $delay = 20;
    my $flags = ALLCTLRS;
    my $parm = 0;

    $ret = LoopPrimUsingList($coPtr, $lprim, \@lids, $loops, $delay, $flags, $parm );
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>>>>>>>>>  Error during loop primitives. <<<<<<<<");
        return ERROR; 
    }


    
    #
    #    4) Check I/O
    #
    logInfo("Verify IO after first set of loop primitive option $lprim. ");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>> I/O validation failed after first set of loop primitive option $lprim <<<<");
        return ERROR; 
    }



    #    5) Any other validation


    #
    #    6) LIP each one, wait ?? seconds between each LIP
    # This one is faster (we'll see what can be tolerated by the system)
    #
    $delay = 5;
    $ret = LoopPrimUsingList($coPtr, $lprim, \@lids, $loops, $delay, $flags, $parm );
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>>>>>>>>>  Error during loop primitives. <<<<<<<<");
        return ERROR; 
    }



    #
    #    7) Check I/O
    #
    logInfo("Verify IO after first set of loop primitive option $lprim. ");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>> I/O validation failed after second set of loop primitive option $lprim <<<<");
        return ERROR; 
    }

    #
    #    8) do any other validation
    #

#add code here

    #   10) Verify IO


    logInfo("End of UE stress test case $tcNum.");


    return GOOD;

}
###############################################################################



###############################################################################

=head2 UETestCase03 function

This test case observes what happens when the master moves while doing a 
defrag. Initially there will be not fail criteria, other than making sure
each command sent to the controllers is successful. Once the FW design
stabilizes in this area, then a failure mechanism may be added.




=cut

=over 1

=item Usage:

 my $rc = UETestCase03( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMean  );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serian numbers - unused
        $loopCount determines how many test loops are done
        $pDFailMean - unused

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 The test will appear to hang after the mastership changes. The test will
 be waiting to see if defrag restarts or not.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.

 There must be no ICON connection to the controllers.


=back

=cut

##############################################################################
#
#          Name: UETestCase03
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCounts
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub UETestCase03
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ret;
    my $ret2;
    my @oldVds;
    my $i;
    my $newVd;
    my $loop;
    my $mIdx;
    my $sIdx;
    my @living;
    my $timeOut;
    my %rsp;
    my @newVds;
    my $elStateM;
    my $newMaster;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ UE Test Case 3: Change master during a defrag ------";
    $msg0 = "---------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);



    # get measure of the current IO



    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }




    ###################################################################### 
    # delete all inactive vdisks, defrag. This essentially packs the disk.
    # and pack the IO.
    ######################################################################

    #####################
    # clean up the system
    #####################

    # delete them
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }
    

    # defrag all pdisks
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }


    # verify IO
    logInfo("I/O check after system cleaned up/before actual test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    ########################
    # make holes for defrag
    ########################


    # find the first 5 early vdisks
    @oldVds = FindEarlyVdisk( $ctlr, 5 );     # find  vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # create 5 vdisks for copies
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
        #push ( @newVds, $newVd);
    }

    # do 5 redicp operations
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    # delete the source vdisks
    for ($i = 1; $i < scalar( @oldVds); $i++ )
    {
        logInfo("Deleting $oldVds[$i]");
        if ( ERROR == DeleteSingleVdisk($ctlr, $newVds[$i]) ) 
        {
            return ERROR;
        }
    }

    ######################################################
    # now start the defrag (all) operation on the master
    ######################################################



    $ret = DefragAllBegin($ctlr);
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to start defragAll. <<<<<<<<");
        return (ERROR);
    }

    

    ############################################################
    # now start the loop that moves the master (defrag running)
    ############################################################


    for ( $loop = 0; $loop < $loopCount; $loop++ )
    {

        #
        # identify the master, get a random slave
        #
        ($mIdx, $sIdx) = FindMasterPickSlave($coPtr);

        if ( ($mIdx == INVALID) || ($sIdx == INVALID) )
        {
            logInfo("Failure getting master and selecting a slave.");
            return ERROR;
        }

        #
        # Get list of current controllers
        #

        $ret = GetOperationalIPs($coPtr, $mIdx, \@living);
        if ( $ret != GOOD )
        {
            logInfo("Unable to get a list of operational contollers - failure");
            return ERROR;
        }

        #
        # ping each controller in group, see if defrag still running
        # ping satisfied by the defrag check
        #
        $timeOut = 30;

# the is a new function to be written
        $ret = IsDefragReallyRunning($coPtr, \@living, $timeOut );
# figure out what to do here


        #
        # wait 45 seconds
        #
        DelaySecs(45);

        #
        # start election on slave
        #
        $ctlr = $$coPtr[$sIdx];

        %rsp = $ctlr->genericCommand("ELECTION", 0 );

        # see how the start of the election went

        if (!%rsp)                        # no response
        {
            logInfo(">>>>>>>> Failed to receive a response from ELECTION start <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} == 1)            # 1 is bad
        {
            logInfo(">>>>>>>> Failed: starting an election returned an error <<<<<<<<");
            PrintError(%rsp);
            logError("Failure in test");
            return ERROR;
        }


        #
        # wait for election to complete
        #
        $elStateM = 0;

        # loop getting state and printing changes until election finishes
        while ( $elStateM != 0 )
        {
            ##
            # get the master's election state
            ##
            %rsp = $ctlr->vcgElectionState();

            # see how getting the master's status went
            if (!%rsp)                        # no response
            {
                logInfo(">>>>>>>> Failed to receive a response from ELECTION status <<<<<<<<");
                return ERROR;
            }

            if ($rsp{STATUS} == 1)            # 1 is bad
            {
                logInfo(">>>>>>>> Failed: getting election status returned an error <<<<<<<<");
                PrintError(%rsp);
                logInfo("Failure in elections test");
                return ERROR;
            }

        }

        #
        # see who the master is now
        #
        $newMaster = FindMaster($coPtr);
        
        $msg = "UEtest03 Result: Mastership change from $mIdx to ";
        $msg .= "$newMaster. Election run from $sIdx.";
        logInfo $msg;
    

        #
        # see what happens over next (up to) 10 minutes
        #
#THis is a new function to look to see if a defrag is running and if so, log and bail if not, timeout and 
# go on.
        $ret = DefragMonitor($coPtr, \@living, 600);


        #
        # check I/O , make sure it is still OK
        #
        logInfo("I/O check after attempted mastership change.");
        $ret2 = VerifyIO( $coPtr,
                         \@activeServers, 
                         \@tMap, 
                         \@initialVdisks,
                         $snPtr
                       );

        if ( $ret2 != GOOD ) { return ERROR; }


        #
        # See if we still need to defrag
        #
        $ret2 = CheckSosTables( $coPtr,  ISFRAGMENTED );     # look for ??? state
 #       if ( $ret != GOOD ) { do the right thing }

        #
        # if defrag needed, re-start defrag
        #

        if ( ($ret2 == GOOD) && ($ret != GOOD)  )
        {
            
            # note: this will log what happened, but at this level we don't know
            # what did happen
            $ret = DefragAllBegin( $$coPtr[$newMaster]);
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> Failed to start defragAll. <<<<<<<<");
                return (ERROR);
            }
       }

            #
            # record response to defrag start
            #
# was it started, or already running, etc.
    }



    #
    # See if we still need to defrag
    #
    $ret = CheckSosTables( $coPtr, (ISFRAGMENTED) );     # look for ??? state
#    if ( $ret != GOOD ) { do the right thing }

    #
    # if defrag needed, re-start defrag
    #
    if ($ret == GOOD )
    {
        $ret = IsDefragReallyRunning($coPtr, \@living, 15 );

        #
        # If running, log message and exit
        #
        if ( $ret != DEFRAGGING )
        {
            $ret = DefragAllBegin($$coPtr[$newMaster]);
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> Failed to start defragAll. <<<<<<<<");
                return (ERROR);
            }
            sleep(15);
        }
    }
    
    
    
        #
        # record response to defrag start (already done)
        #

   #
   # wait for defrag to end
   #
    # wait for something to start

    # now wait for the defrags to end

    $ret = DefragWait( $$coPtr[$newMaster] );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed waiting for defrags to end. <<<<<<<<");
        return (ERROR);
    }






    # verify IO
    logInfo("I/O check at end of test.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $$coPtr[$newMaster] );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }



    logInfo("End of UE test case 03.");

    
    return GOOD;

}

###############################################################################

=head2 UETestCase04 function

This test case creates, expands, initializes vdisks. Different raid types
and drive types are used.

It has these basic steps...
    1) initial startup
    2) create a vdisk
    3) expand it a couple of times
    4) init it
    5) delete it

    repeat 2-5 using different raid and pdisk types






=cut

=over 1

=item Usage:

 my $rc = UETestCase04( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done
        $pDFailMeans in unused

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: UETestCase04
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
##############################################################################
sub UETestCase04
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
#    my $newVd;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ UE Test Case 4: various create, expand an inits.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);



    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }

    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # loops to LIP the BE cards.
    ######################################################################


#add code here

    #   10) Verify IO

    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 7.");


    return GOOD;

}
###############################################################################
###############################################################################

=head2 UETestCase51 function

This test case just prints mirror information for field use





=cut

=over 1

=item Usage:

 my $rc = UETestCase51( $coPtr );

 where: $coPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: UETestCase51
#
#        Inputs: $coPtr
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: List mirror info
#
#                LIPs the BE loops
#
#
#
#
#
#
##############################################################################
sub UETestCase51
{
    trace();
    my ( $coPtr ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $master;
    my @coList;
    my $ctlr;
    my $i;
    my %rsp;
    my $ret;
    my $msg0;

    $msg = "------ Test Case 51: List Mirror Information  --------";
    $msg0 = "------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    @coList = @$coPtr;

    $ctlr = $coList[$master];


    %rsp = $ctlr->virtualDisks();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }


    $msg = "";
    
    $msg .= sprintf( "Virtual Disk Mirror Information\n");
    $msg .= sprintf(  "\n");




    $msg .= "                                                                    SOURCE   SEC COPY\n";
    $msg .= " VID    SCDHEAD       SCDTAIL   MIRROR State     MIRROR ATTRIBUTES     VID    % COMP    OWNER    NAME\n";
    $msg .= " ---    -------     ----------  ------------  --------------------  -------  --------   -----  --------\n";

    my $mText;
    my $aText;
    
    for ( $i = 0; $i < $rsp{COUNT}; $i++)
    {
        
        #
        #        .set    vdnomirror,0            # 00 # no mirror active
        #        .set    vdcopyto,1              # 01 # Sec. copy destination
        #        .set    vdcopymirror,2          # 02 # Sec. copy mirror
        #        .set    vdcopyuserpause,3       # 03 # copy user paused
        #        .set    vdcopyautopause,4       # 04 # copy auto paused
        #
        $mText = "unknown: $rsp{VDISKS}[$i]{MIRROR} ";
        if ( $rsp{VDISKS}[$i]{MIRROR} == 0 ) { $mText = "          "; }
        if ( $rsp{VDISKS}[$i]{MIRROR} == 1 ) { $mText = "Copying   "; }
        if ( $rsp{VDISKS}[$i]{MIRROR} == 2 ) { $mText = "Mirrored  "; }
        if ( $rsp{VDISKS}[$i]{MIRROR} == 3 ) { $mText = "User Pause"; }
        if ( $rsp{VDISKS}[$i]{MIRROR} == 4 ) { $mText = "Auto Pause"; }

        
        # --- this mask assumes that the CCB will not modifiy the following 
        #     attribute bits.
        #                       0x0008  suspend
        #                       0x0010  device is destination of copy
        #                       0x0020  device is source of copy
        #                       0x0040  vlink lock flag
        #                       0x0080  vlink flag
        $aText = "";
        if ( $rsp{VDISKS}[$i]{ATTR} ==  0 ) { $aText = "No Mirror"; }
        if ( $rsp{VDISKS}[$i]{ATTR} &   8 ) { $aText .= "Susp "; }
        if ( $rsp{VDISKS}[$i]{ATTR} &  16 ) { $aText .= "Dest "; }
        if ( $rsp{VDISKS}[$i]{ATTR} &  32 ) { $aText .= "Src "; }
        if ( $rsp{VDISKS}[$i]{ATTR} &  64 ) { $aText .= "Lock "; }
        if ( $rsp{VDISKS}[$i]{ATTR} &  128) { $aText .= "Vlink "; }
        
        
        $msg .= sprintf( " %3hu    0x%8.8x  0x%8.8x    %10s  %20s  %7d   %7d    0x%2.2x  %s\n", 
                $rsp{VDISKS}[$i]{VID},
                $rsp{VDISKS}[$i]{SCHEAD},
                $rsp{VDISKS}[$i]{SCTAIL},
                $mText,
                $aText,
                $rsp{VDISKS}[$i]{SCORVID},
                $rsp{VDISKS}[$i]{SCPCOMP},
                $rsp{VDISKS}[$i]{OWNER},
                $rsp{VDISKS}[$i]{NAME});
    }

    $msg .= sprintf( "\n");


    logInfo($msg);








    logInfo("End of UE stress test case 51.");


    return GOOD;

}
###############################################################################
###############################################################################

=head2 UETestCase05 function

This test records the I/O transfer rate to vdisks and servers. The total
server and vdisk I/O counts are recorded along with MB read and written. Note: 
the code is not finished and the MB numbeers are suspect, probably due to big int 
related errors. Measurements are taken every 
1 minute. This test case
is a data collection exercise for looking at controller performance. It is not 
intended to be run as a 'test'. Currently 5000 samples are taken, so in normal use
will probably be run until aborted by the user. The log file can be grepped for
"Total Activity" and the resulsts imported into Excel for further processing.
Import should be done as a delimited test file with space and comma as the 
delimiters.


=cut

=over 1

=item Usage:

 my $rc = UETestCase05( $coPtr, $retIn,  $loopCount   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.



=back

=cut

##############################################################################
#
#          Name: UETestCase05
#
##############################################################################
sub UETestCase05
{
    trace();
    my ( $coPtr, $retIn, $loopCount) = @_;

    my @shortResults;
    
    my %results;
    
    my $loop;
    my $i;
    my $ctlr;
    my @vCounts;
    my @newCounts;
    my @activities;
    my $totalSActivity;
    my $totalVActivity;
    my $readBytes;
    my $writeBytes;
    my $j;
    my $vid;
    my $count;
    my $sReads;
    my $sWrites;
    my $msg;
    my $msg0;
    my @sCounts;
    my @nowVCounts;
    my @nowSCounts;
    my $sid;
    
    
    

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg =  "--------- UE Test Case 5: Record vdisks I/O rates over time  -----------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    #
    # Validate loopcount. Not less than 5, defaul to 100
    #

    if ( !defined($loopCount) )
    {
        $loopCount = 100;
    }
    if ( $loopCount < 5 )
    {
        $loopCount = 100;
    }

    #
    # First get an initial set of data
    #
    
    @vCounts = GetVdiskActivityCounts($coPtr);
    @sCounts = GetServerActivityCounts($coPtr);


    #
    # Next, a loop to collect the samples.
    #

    $loop = 0;

    while ( $loop < $loopCount )
    {

        #
        # Delay until the next sample
        #
        print "Delay until next sample.\n";
        DelaySecs(60);
        
        #
        # Get the next set of data
        #
    
        @nowVCounts = GetVdiskActivityCounts($coPtr);
        @nowSCounts = GetServerActivityCounts($coPtr);

        #
        # Determine net activity - this is the difference between the 
        # previous number to the cruuent numbers and is based upon 
        # those vdisks seen in the initial data, If a vdisk is deleted
        # this chould break. This may also get interesting on a sparse
        # list.
        #
        
        
        #
        # First the vdisks 
        #
        $totalVActivity = 0;
        
        for ($i = 0; $i < scalar( @vCounts ); $i++ )
        {
            # for each item in the first array...extract the data
            $vid = $vCounts[$i]{VID2};
            $count = $vCounts[$i]{COUNTS};

            #print " got $vid, $count \n";

            # get the matching entry in the second array
            for( $j = 0; $j < scalar(@nowVCounts); $j++)
            {
                if ( $vid == $nowVCounts[$j]{VID2} )
                {
                    # item matched, now combine results
                    $count = $nowVCounts[$j]{COUNTS} - $count;
                    $totalVActivity += $count;
                    # logInfo(" Vdisk activity VID: $vid, count: $count");

                }

            }
        }
        
        $totalSActivity = 0;
        $readBytes = 0;
        $writeBytes = 0;
        
        #
        # Now the servers
        #
        for ($i = 0; $i < scalar( @sCounts ); $i++ )
        {
            # for each item in the first array...extract the data
            $sid     = $sCounts[$i]{SID};
            $count   = $sCounts[$i]{COUNTS};
            $sReads  = $sCounts[$i]{READSECTORS};
            $sWrites = $sCounts[$i]{WRITESECTORS};
            
            #print " got $sid, $count \n";

            # get the matching entry in the second array
            for( $j = 0; $j < scalar(@nowSCounts); $j++)
            {
                if ( $sid == $nowSCounts[$j]{SID} )
                {
                    # item matched, now combine results
                    
                    #print " old_count now_count old_sreads now_sreads old_swrites now_swrites \n";
                    #print " $count  $nowSCounts[$j]{COUNTS} $sReads  $nowSCounts[$j]{READSECTORS}  $sWrites  $nowSCounts[$j]{WRITESECTORS} \n";
                    
                    
                    $count   = $nowSCounts[$j]{COUNTS} - $count;
                    $sReads  = $nowSCounts[$j]{READSECTORS} - $sReads;
                    $sWrites = $nowSCounts[$j]{WRITESECTORS} - $sWrites;
                    
                    #print " Net: $count   $sReads   $sWrites \n";

                    $totalSActivity += $count;
                    
                    #
                    # Note, the read/write byte counts are 32 bit numbers, 
                    # However, they are being truncated to 16 bits and this 
                    # results in negative numbers for servers. Rather than fix
                    # the problem which is in the ccbe or ccb, the error is
                    # corrected here.
                    #
                    # If a negative number is seen, add 4096 which reflects what is 
                    # lost when the number wraps.
                    #
                    
                    if ( $sReads < 0 ) { $sReads += 4096; }
                    if ( $sWrites < 0 ) { $sWrites += 4096; }
                    
                    # accumulate the results
                    $readBytes += $sReads;
                    $writeBytes += $sWrites;
     
                    #print (" Server activity SID: $sid, count: $count,  MB read:  $sReads,  MB written: $writeBytes");

                }

            }
        }
        
        #
        # Log the current sample
        #
        
        logInfo(" Total Activity  - Vdisk Counts: $totalVActivity, ".
                "Server Counts: $totalSActivity, MB Read: $readBytes, ".
                "MB written: $writeBytes ");
        
        
        #
        # Display the last several readings (screen only, not logged)
        # (maybe later)
        
        
        @vCounts =  @nowVCounts; 
        @sCounts =  @nowSCounts; 
        
    }    
    #
    # post some sort of summary
    # (later)
    
    
    #
    # Done
    #
    

    logInfo("End of UE stress test case 5.");

    return GOOD        

}
###############################################################################



###############################################################################
#
#    Additional test cases 
#
#    Mostly Write Cache related ---
#
#    1) Turn on and off cache repeatedly while running I/O. Do this 
#       slowly at first, then much faster. (Attempt to overlap on/off
#       requests.)
#    2) Failover with cache enabled. Do we want a cache on and cache off
#       set of test cases, or a wrapper on failover that can also make 
#       sure we restore cache to the original setting.
#    3) Rolling code updates with cache on. Write a ccbe script that 
#       emulates RCU on the ICON. (Or calls the ICON scripting.)
#    4) Cache on, do redi copies, swaps, mirrror, etc
#    5) with cache on make/break vlinks (needs a vlink test library)
#    6) enable cache on the destination of a vlink (needs a vlink test
#       library)
#    7) Update failover to handle case were caching is on and the
#       failover would trash both copies of the cache. (Do not fail
#       adjacent controllers simultaneously when cache is on.) Use the
#       mirror partner list when determining what to fail.(Is this the 
#       same as vcgmplist? If so, make it a flag passed to WhatToFail() )
#    8) Ctlr fails, battery dies, another controller has posted the data,      
#       ctlr comes online, checks other controller for the data. Not really
#       good to script, but should be done manually.
#
#
#
#    11) Enable cache, fail controller, verify cache is now off, unfail controller
#        verify cache now on. (determine response in n-way environement
#    12) Characterize, observe cache behavior in a Rolling Code Update
#        environment
#    13) Cache integrity thru a power cycle of all controllers. This does a
#        number on the I/O that will be running. Look at errors logged by the 
#        controllers. (also look at events)
#    14) Turn cache off and on multiple times, verify that caching state on
#        each vdisks ate each on or off cycle. Verify that only the correct 
#        vdisks turn on/off cache.
#    15) Look at cache statistics, verify correct change as cache is 
#        enabled/disabled and during and after a failover/ failback cycle.
#    16) Power off a controller, wait a while, power on, Observe the 
#        charging of the battery (env statistics) and when cache turns 
#        back on. Do this for cases where the the controller is unfailed
#        immediately and unfailed after some delay. Need to look at cache
#        state of all controllers in the CNC. (Output is some sort of
#        timeline?)
#    17) Check ability to enable/disable cache on the slaves as well as 
#        he master controller.
#    18) Observe effect of failing the cache partner of a controller. 
#        Does the LUN owner disable cache of the partner fails?
#    19) In an N-way. Fail the lun owner, see who picks up the LUNs and 
#        does the cache partner change?
#    20) Is cache re-enable after failback manual or automatic? (Affects 
#        test cases)
#    21) Look at statsvdisks to determine if cache is on or off and the 
#        apparent performance change. Assuming consistant I/O load this
#        may be a good metric.
#    22) Try to make a vdisk with some SATA raids and some FC raids. How
#        does cache behave?    See #9.
#    23) Make a timeline of events as cache is turned off. (Assuming 
#        it takes more than a second or two to turn off cache.)
#
#
#    Non-write cache related ones ----
#
#    9) Build a vdisk with fc drive, expand using sata drives, is this a
#       performance solution or not.
#    10) Start a defrag, start it again(fails), stop defrag, restart.
#
#    23) A test for messed up target mapping. Map more than 8 luns to a 
#        target, then do a config change (of the right type) and confirm that
#        the target mappings are still valid on all controllers. This needs 
#        to have both a test and a callable function for the validation.
#
#
#    24) (DONE) Loop Primitive, option 0 on all pdisks. Loop thru all devices slow
#               and fast. Check that I/O survives.
#    25) (DONE) Loop Primitive, option 1 on all pdisks. Loop thru all devices slow
#               and fast. Check that I/O survives.
#    26) (DONE) Loop Primitive, option 2 on all pdisks. Loop thru all devices slow
#               and fast. Check that I/O survives.
#               (One of the above should LIP every device.)
#
#    27) Delete a vdisk during
#                   raid init      see Integccbelib::CreateExpandInitDelete
#                   rebuild
#                   redi-copy      see Defrag case 2
#                   defrag         see Dafrag Case 2
#                   parity scan
#                   cache off and cache on cases for all
#
#        Some of these may already be done, but the test should do the 
#        delete on a vdisk unrelated to the activity, and on one related
#        to the activity. If there are two related vdisks, the delete
#        delete should be done to each one separately. SOme deletes
#        will break the operation, some won't. None should trash the
#        controlleer or I/O. (within reason)
#
#    28) Add vdiskmove to the regression tests.
#    29) Test to validate an expanded raid
#              Time to come ready
#              Size inreases as expected
#              Init completes
#        Check each raid type, and on FC and SATA drives.
#
#
#
###############################################################################
###############################################################################


###############################################################################




###############################################################################


###############################################################################


###############################################################################
###############################################################################


###############################################################################

=head2 UETestCaseX function

This test case repeatedly LIPs the BE qlogic cards.
The test has these
basic steps...






=cut

=over 1

=item Usage:

 my $rc = UETestCaseX( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: UETestCaseX
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                LIPs the BE loops
#
#
#
#
#
#
##############################################################################
sub UETestCaseX
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
#    my $newVd;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 7: Lots of LIPs on the BE Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);



    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }

    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # loops to LIP the BE cards.
    ######################################################################


#add code here

    #   10) Verify IO

    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 7.");


    return GOOD;

}

#
# Here
#
##############################################################################
#
#          Name: MultiResyncMirrorPauseStartCommand
#
#        Inputs: controller object, command, vdisk cnt, dest vdisk 
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Inits a Multi Resync/Mirror Pause sequence.
#
##############################################################################
sub MultiResyncMirrorPauseStartCommand
{
    my ($ctlr, $vdcmd, $cnt, $dest) = @_;
    my $specialSrc ;

    trace();

    logInfo("      Sending Start command for Deferred Break ");

    $specialSrc = (16384)+$cnt ;

    logInfo("        with ctlr = $ctlr->{HOST}, cnt = $cnt, specialSrc = $specialSrc, dest = $dest");

    return $ctlr->virtualDiskControl($vdcmd, $specialSrc, $dest);
}

##############################################################################
#
#          Name: MultiResyncMirrorPauseDeferredCommand
#
#        Inputs: controller object, command, dest vdisk to be added
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Adds a vdisk to the list of disks to be operated on my
#                a Multi Resync/Mirror Pause sequence.
#
##############################################################################
sub MultiResyncMirrorPauseDeferredCommand
{
    my ($ctlr, $vdcmd, $dest) = @_;

    trace();

    logInfo("      Adding a disk for Deferred Break ");

    logInfo("        with ctlr = $ctlr->{HOST}, dest = $dest");

    return $ctlr->virtualDiskControl($vdcmd, 32768, $dest);
        
}

##############################################################################
#
#          Name: MultiResyncMirrorPauseGoCommand
#
#        Inputs: controller object, command, dest vdisk
#
#       Outputs: varies
#
#  Globals Used: none
#
#   Description: Sends the go command to virtualDiskControl.
#
##############################################################################
sub MultiResyncMirrorPauseGoCommand
{
    my ($ctlr, $vdcmd, $dest) = @_;

    trace();
    my $src = 16640 ;

    logInfo("      Go command! ");

    logInfo("        with ctlr = $ctlr->{HOST}, dest = $dest");

    return $ctlr->virtualDiskControl($vdcmd, $src, $dest);

}

sub CopyContinuousVdisks
{
    my ($ctlr, $src, $dest) = @_;
    trace();

    logInfo("      Starting a redi-copy operation ");
    logInfo("        with ctlr = $ctlr->{HOST}, src = $src, dest = $dest");

    my %rsp = $ctlr->virtualDiskControl(0x03, $src, $dest);

    if (!%rsp)                        # no response
    {
        logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != GOOD )            # 0 is good
    {
        logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    return GOOD;
}

sub WaitForMultiMirrorStatus
{
    my ($coPtr, $bitstate, $vdiskListPtr ) = @_;
    my @vdiskList ;
    my $ret ;
    my $count ;
    my $srchVd ;
    my %rsyncpausedata ;
    my $master ;
    my $ctlr ;
    my $bitisset ;          # is the bit we want set or no
    my $pausebyte ;         # which byte are we looking for
    my $pausebit ;          # which bit are we looking for
    my $pauseline ;         # data is broken up into lines of 16 bytes each  (4 max)
    my $interestingline ;   # data is broken up into lines of 16 bytes each  (4 max)
    my $interestingbyte ;   # actual byte value
    my $cnt ;
    my @ourbitmask = ( 1, 2, 4, 8, 16, 32, 64, 128 ) ;
    my @coList ;
    my $allgood ;


    @vdiskList = @$vdiskListPtr ;

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];

    for ( $count = 0; $count < 60 ; $count ++)
    {
        # get bit mask      
        %rsyncpausedata = $ctlr->resyncData(3);  # pause
        $cnt = $rsyncpausedata{COUNT};

        $allgood = 1 ; # assume good
        foreach $srchVd (@vdiskList)
        {
            my $bitisset = 0 ;
            # if cnt is 0 it means the entire map is 0.
            # if it is 4 it is fully populated.  (I don't know why.)
            if ( $cnt != 0 )
            {
                # which byte do we want (8 vdisks per byte)
                $pausebyte = int( $srchVd / 8 );
                # which line do we want (each line has 16 bytes)
                $pauseline = int( $pausebyte / 16 );
                # which byte on that line do we want
                $pausebyte = $pausebyte % 16 ;
                # which bit do we want
                $pausebit =  $srchVd % 8 ;
                # let's get our byte.
                $interestingline = $rsyncpausedata{RDATA}[$pauseline]{TRECORD} ;
                $interestingbyte = unpack( "C", substr( $interestingline, $pausebyte, 1) );
                # isolate the bit.
                if ( ( $interestingbyte & $ourbitmask[$pausebit] ) == $ourbitmask[$pausebit] )
                {
                    $bitisset = 1; 
                }
            }
            if ($bitisset != $bitstate)
            {
                $allgood = 0 ;
                last ;          # break from the loop
            }
        }
        if ($allgood == 1 )
        {
            logInfo ("Mirror bitmap is as expected.");
            return GOOD ;
        }
        DelaySecs(1) ;
    }
    logInfo(">>>>> Failed: Mirror bitmap was not as expected.<<<<<" );
    return ERROR ;
}

#
# coPtr is the controller
# vdisklist is a list of vdisks
# vdiskstate is the state I expect to find.  And is defined as the MIRROR states
#    (VD_NOMIRROR, VD_COPYTO, VD_COPYMIRROR, etc.)
# 
# we want to compare the contents of virtualDisks and the multi mirror
# data area.
# 
sub MultiMirrorCheck
{

    my ($coPtr, $vdiskstate, $attrval, $vdiskListPtr, $fuzzymirror ) = @_;

    my %vdiskData;
    my $ret ;
    my $master ;
    my @coList ;
    my $ctlr ;
    my $srchVd ;
    my $idx ;

    my @vdiskList = @$vdiskListPtr ;

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];

    #
    # vdiskData is the current state of the mirrors.
    # 
    $ret =  MirrorInitialData( $coPtr, \%vdiskData );
    if ( $ret != GOOD )
    {
        logInfo("Error fetching the current mirror data - validation failed");
        return ERROR;
    }   
    #
    # We also need to grab the resyncdata pause data.
    # for our vdisks this should be the same as the virtualdisks
    # information.
    #
    my %rsyncpausedata = $ctlr->resyncData(3);  # pause

    #
    # we have our data. 
    # time to search through it for each Vdisk.
    foreach $srchVd (@vdiskList)
    {
        logInfo( "Find $srchVd in vdiskData" );
        # run the list.  (silly way of doing it but there aren't that many.)
        for ( $idx = 0; $idx < $vdiskData{VDISKS}{COUNT}; $idx++)
        {
            if ( $srchVd == $vdiskData{VDISKS}{VDISKS}[$idx]{VID} )
            {
                # we've found it
                logInfo ("VID $srchVd found.  ( ATTR = $vdiskData{VDISKS}{VDISKS}[$idx]{ATTR} )") ;
                # is the state correct?
                if ( $vdiskData{VDISKS}{VDISKS}[$idx]{MIRROR} != $vdiskstate )
                {
                    # if fuzzymirror we treat mirror state 1 the same as mirror state 2.
                    # (state 1 is copyto.  state 2 is copymirror.  the difference is one mirror 
                    # is in sync and the other is not.)
                    if (($fuzzymirror == 1) && ($vdiskstate == 2) && ($vdiskData{VDISKS}{VDISKS}[$idx]{MIRROR} == 1) )
                    {
                        logInfo ("Expected COPYMIRROR state.  Actual COPYTO.");
                    }
                    else
                    {
                        logInfo ("Error! vdiskData ( $vdiskData{VDISKS}{VDISKS}[$idx]{MIRROR} ) does not match expected state $vdiskstate!") ;
                        return ERROR ;
                    }
                }
                if ( $vdiskData{VDISKS}{VDISKS}[$idx]{ATTR} != $attrval )
                {
                    logInfo ("Error! vdiskData ( $vdiskData{VDISKS}{VDISKS}[$idx]{ATTR} ) does not match expected attr $attrval!") ;
                    return ERROR ;
                }
                # stop the search we check results outside this loop.
                last ;  
            }
        }
        # did we go off the end without finding our vid
        if ( $idx == $vdiskData{VDISKS}{COUNT})
        {
            logInfo ("Error!  VID $srchVd not found.") ;
            return ERROR ;
        }

        #
        # Let's find srcVd's state in the resyncdata list.
        my @ourbitmask = ( 1, 2, 4, 8, 16, 32, 64, 128 ) ;
        # $mirrortopausestate[MIRROR] == the bit in the pause data array
        my @mirrortopausestate = (0,1,1,0,1) ; 
        my $bitisset ;          # is the bit we want set or no
        my $pausebyte ;         # which byte are we looking for
        my $pausebit ;          # which bit are we looking for
        my $pauseline ;         # data is broken up into lines of 16 bytes each  (4 max)
        my $interestingline ;   # data is broken up into lines of 16 bytes each  (4 max)
        my $interestingbyte ;   # actual byte value
        my $cnt = $rsyncpausedata{COUNT};
        # if cnt is 0 it means the entire map is 0.
        # if it is 4 it is fully populated.  (I don't know why.)
        if ( $cnt != 0 )
        {
            # there is probably an easy way to do this.  This should work for our purposes
            # which byte do we want (8 vdisks per byte)
            $pausebyte = int( $srchVd / 8 );
            # which line do we want (each line has 16 bytes)
            $pauseline = int( $pausebyte / 16 );
            # which byte on that line do we want
            $pausebyte = $pausebyte % 16 ;
            # which bit do we want
            $pausebit =  $srchVd % 8 ;
            # let's get our byte.
            $interestingline = $rsyncpausedata{RDATA}[$pauseline]{TRECORD} ;
            $interestingbyte = unpack( "C", substr( $interestingline, $pausebyte, 1) );
            logInfo ("We are checking $interestingbyte byte  (Byte $pausebyte Bit $pausebit) " );
            # isolate the bit.
            if ( ( $interestingbyte & $ourbitmask[$pausebit] ) == $ourbitmask[$pausebit] )
            {
                $bitisset = 1 ;
            }
            else
            {
                $bitisset = 0 ;
            }
        }
        else
        {
            logInfo( "Bitmap is null." );
            $bitisset = 0 ;
        }

        logInfo( "VID $srchVd Pause bit is set to $bitisset" );

        # okay, we know what we want to see.
        # we know what the ATTR and MIRROR states are
        # we know what the bit in the array is.
        # we have already confirmed that the state we want to see (vdiskstate) is correct 
        # when checked against ATTR and MIRROR.
        # just check the bit.
        if ( $mirrortopausestate[$vdiskstate] != $bitisset )
        {
            # error!  log it.
            logInfo( "Error!  Expected: $mirrortopausestate[$vdiskstate] (state: $vdiskstate) found: $bitisset." );
            return ERROR ;
        }
        # okay
        # we need vdiskinfo's attr and mirror.  Not so much the attr.
        # The vdiksks I'm checking should have an ATTR of 18h or 10h.  (Destination disk or 
        # if ATTR == 18h xor mirror == 3 then we have a problem and must wait for the states to settle out.
        # if ATTR == 18h and mirror == 3 then resyncdata pause should == 0
        # if ATTR == 10 then resyncdata pause should == 0
        # if ATTR != 10 and ATTR != 18 then resycndata pause should == 0
        # mirror trails attr
    }
    logInfo( "Mirror states are as expected and consistent." );
    return GOOD ;
}

sub MultiMirrorCheckAndPrint
{
    my ($coPtr, $vdiskstate, $attrval, $vdiskListPtr ) = @_;
    my $fuzzymirror=1; # we want to treat copyto's the same as copydestinations.
    my $ret = MultiMirrorCheck( $coPtr, $vdiskstate, $attrval, $vdiskListPtr, $fuzzymirror );
    if ($ret == ERROR)
    {
        logInfo(">>>>>>>> Failed - Mirror State check failed. <<<<<<<<");
        return ERROR ;
    }
    logInfo("Mirrors are happy.");
    return GOOD ;
}

#
# 
sub WaitUntilMirrored
{
    my ($coPtr, $vdiskstate, $vdiskListPtr, $delaytime, $maxdelay ) = @_;
    my @vdiskList;
    my @coList;
    my $ctlr ;
    my %vdiskData ;
    my $ret ;
    my $allgood ;
    my $master ;
    my $srchVd ;
    my $idx ;
    my $delaycount = 0 ;

    @vdiskList = @$vdiskListPtr ;

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];

    $allgood = 0 ;
    while ( ($allgood == 0) && ($delaycount < $maxdelay) )
    {
        logInfo ("Waiting for mirrors to sync.");
        DelaySecs ( $delaytime );
        $delaycount += $delaytime ;
        #
        # vdiskData is the current state of the mirrors.
        # 
        $ret =  MirrorInitialData( $coPtr, \%vdiskData );
        if ( $ret != GOOD )
        {
            logInfo("Error fetching the current mirror data - validation failed");
            return ERROR;
        }   
        $allgood = 1 ;
        # check all the disks
        foreach $srchVd (@vdiskList)
        {
            # need to find it.
            for ( $idx = 0; $idx < $vdiskData{VDISKS}{COUNT}; $idx++)
            {
                # have we found it?
                if ( $srchVd == $vdiskData{VDISKS}{VDISKS}[$idx]{VID} )
                {
                    # is its state correct?
                    if ( $vdiskData{VDISKS}{VDISKS}[$idx]{MIRROR} != $vdiskstate )
                    {
                        # nope.  Mark it bad.
                        $allgood = 0 ;
                    }
                    # found this disk.
                    last ;          # drop out of the foreach loop
                }
            }
        }
    }
    # are we here because the mirrors are all good or because we timed out.
    if ($allgood == 1)
    {
        logInfo ("Vdisks are mirrored.");
        return GOOD ;
    }
    else
    {
        logInfo("Error timed out waiting for mirror state to sync with expected state. ($vdiskstate)");
        return ERROR;
    }
}

sub MultiMirrorExecute
{

    my  ($ctlr, $cmd, $cnt, $vdsPtr) = @_ ;
    my @vds ;
    my %rsp ;
    my $i ;
    @vds = @$vdsPtr ;


    # send start
    %rsp = MultiResyncMirrorPauseStartCommand ($ctlr, $cmd, $cnt, $vds[0] ); 
    if ($rsp{STATUS} != GOOD ) 
    {
        logInfo(">>>>>>>> Failed -  Start command failed <<<<<<<<");
        return ERROR ;
    }
    # send defers.
    for ( $i = 0 ; $i < $cnt ; $i++ )
    {
        %rsp = MultiResyncMirrorPauseDeferredCommand ($ctlr, $cmd, $vds[$i] ); 
        if ( $rsp{STATUS} != GOOD )
        {
            logInfo(">>>>>>>> Failed -  Deferred command failed <<<<<<<<");
            return ERROR ;
        }
    }
    #send go
    %rsp = MultiResyncMirrorPauseGoCommand ($ctlr, $cmd, $vds[0] ); 
    if ( $rsp{STATUS} != GOOD )
    {
        logInfo(">>>>>>>> Failed -  Go command failed <<<<<<<<");
        return ERROR ;
    }
    return GOOD ;
}

##############################################################################
#
#          Name: ResetFELoop
#
#        Inputs: controller object, loops, , eight, data
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Executes a generic MRP
#   
#
#
##############################################################################
sub ResetFELoop
{
    trace();
    my ($ctlr, $loop ) = @_;

    my %rsp;

    


    %rsp = $ctlr->loopPrimitiveFE(0, 0, $loop, 0);


                                           
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get a response from loopPrimitiveFE. <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD && $rsp{ERROR_CODE} == 0x36)
    {
        # missing card, 
        return INVALID;
    }

    if ($rsp{STATUS} != PI_GOOD && $rsp{ERROR_CODE} == 0x3d)
    {
        # card present, but unconnected 
        return INVALID;
    }



    if ($rsp{STATUS} != PI_GOOD && $rsp{ERROR_CODE} != 0x36)
    {
        logInfo(">>>>>>>> Error from loopPrimitiveFE. <<<<<<<<");
        PrintError(%rsp);

        return ERROR;
    }

    return GOOD;
}

=head2 Xcase6 function

Pause, resume and break during failover.

=cut

=over 1

=item Usage:

 my $rc = Xcase6( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of (16 minimum) vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: Xcase6#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#
##############################################################################
sub XCase6
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $countNewVds = 0 ;
    my $i;
    my $k;
    my %rsp;
    my $ret;
    my @pdds;
    my $srcVd;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my $idx ;
    my $ses;
    my $slot;
    my $lid;
    my $port;
    my $waittime = 60 ; # first use is to get the mirrors completely synced
    my $maxwait = 600 ; #


    #
    # These added to allow the file to compile
    #

    my $slave;
    my $moxaIP;
    my $mmPtr;
    
    #
    # return added to terminate this unfinished test case
    #
    logInfo("This test is unfinished - aborting now.");
    return (ERROR);
    
    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }                                                                                          

    $msg  = "------ Test Case 6 : Multiple Resync/Mirror Pause/Unpause during failover. --------";
    $msg0 = "--------------------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 5 : Multiple Resync/Mirror Pause/Unpause during failover." );


    # find the master controller
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    # Execute cleanup and data collection at start
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    # get measure of the current IO
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
   
    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 6.");

    # We need 32 mirrors.  Lets make this defragable.
    @oldVds = GetRandomVdisks( $ctlr, 16 );     # find vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    for $i (0..1)
    {
        foreach $srcVd (@oldVds)
        {
            # make a new one
            $newVd =  CreateReplacementVdisk($ctlr, $srcVd );
            if ( $newVd < 0 ) { return ERROR; }

            # save it!
            push @newVds, $newVd ;

            # and mirror it srcVd to newVd
            $ret = CopyContinuousVdisks ($ctlr, $srcVd, $newVd);
            if ( $ret != GOOD ) { return ERROR; }
            $countNewVds ++ ;
        }
    }

    # quick check that we have enough mirrors to continue.
    if ( $countNewVds < 32 )
    {
        logInfo(">>>>>>>> Failed -  Need 16 assigned vdisks (doubled to 32 mirrors) to run test. <<<<<<<<");
        return ERROR ; 
    }

    logInfo("Now we wait for our mirrors to sync.");
    $ret = WaitUntilMirrored( $coPtr, 2, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    # check that all are running as expected. (copy mirror state is ATTR 0x10 and MIRROR 2)
    $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
    if ( $ret == ERROR ) { return ERROR ; }

#
# Actual test goes here.
# 
    $lc = 0;
    #variables for this section.
    my @twostep = ( 7, 6 ) ;            # 7 is resume  6 is pause
    my @twomirror = ( 2, 3 );           # 2 is COPYMIRROR 3 is COPYUSERPAUSE
    my @twoattr = ( 0x10, 0x18 ) ;      # 0x10 is copy destination 0x18 is copy destination with suspended flag
    my @twobits = ( 1, 0 ) ;            # Not paused bit map value
    $idx = 0 ;
    # 101 iterations.  This leaves us in the proper final state.
    for ($lc = 0; $lc < 101 ; $lc++)
    {
        # Pause/unpause
        $idx = $lc % 2 ;
        logInfo(sprintf("loop iteration: %5d - ", $lc));
        logInfo ( "(cmd $twostep[$idx] mirror $twomirror[$idx] attr $twoattr[$idx])" ) ;
        # 
        $ret = MultiMirrorExecute( $ctlr, $twostep[$idx], $countNewVds, \@newVds) ;
        if ($ret == ERROR) { return ERROR; }

#
#   we fail the slave controller here.
#
        # Steps are 1) Locate a slave controller
        $slave = 1;
        if ( $master == 1 ) { $slave = 0; }
        
        $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 0);
        if ( $ret != GOOD ) { return ERROR; }

        # failover timeline from master

        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        # wait for the mirror status bit map to come correct
        $ret = WaitForMultiMirrorStatus( $coPtr, $twobits[$idx], \@newVds );
        if ( $ret == ERROR ) { return ERROR ; }
        
        # By the time we get here we should have waited 30-60 seconds.
        $waittime = 20 ;    # 
        $ret = WaitUntilMirrored( $coPtr, $twomirror[$idx%2], \@newVds, $waittime, $maxwait ) ;
        if ( $ret == ERROR ) { return ERROR ; }

#
# we power that sucker back up and unfail it.
#
# Did that work?
        $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 1);
        if ( $ret != GOOD ) { return ERROR; }

        CtlrLogText($$coPtr[$master], "Test Case 21: unfailing all failed controllers" );

        #           8) reconnect and unfail
        $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
        if ( $ret != GOOD ) { return ERROR; }


        #check that all are running as expected.
        $ret = MultiMirrorCheckAndPrint( $coPtr, $twomirror[$idx%2], $twoattr[$idx%2], \@newVds );
        if ( $ret == ERROR ) 
        { 
            logInfo (">>>>>>>> Failed - Mirror Status should be $twomirror[$idx%2] <<<<<<<<"); 
            return ERROR ; 
        }
    }

#
# here we fail the master controller.
#

#
# We swap then break.
# 

    # cleanup.
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of QRE Test Case 6");
    
    CtlrLogTextAll($coPtr, "End of QRE test case 6." );

    return GOOD;
}

=head2 Xcase5 function

Pause, resume and break during pdisk failure.

=cut

=over 1

=item Usage:

 my $rc = Xcase5( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of (16 minimum) vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: Xcase5#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#
##############################################################################
sub XCase5
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $countNewVds = 0 ;
    my $i;
    my $k;
    my %rsp;
    my $ret;
    my @pdds;
    my $srcVd;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my $idx ;
    my $ses;
    my $slot;
    my $lid;
    my $port;
    my $waittime = 60 ; # first use is to get the mirrors completely synced
    my $maxwait = 600 ; #

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }                                                                                          

    $msg  = "------ Test Case 5 : Multiple Resync/Mirror Pause/Unpause during pdisk failure. --------";
    $msg0 = "--------------------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 5 : Multiple Resync/Mirror Pause/Unpause during pdisk failure." );


    # find the master controller
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    # Execute cleanup and data collection at start
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    # get measure of the current IO
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
   
    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 5.");

    # We need 32 mirrors.  Lets make this defragable.
    @oldVds = GetRandomVdisks( $ctlr, 16 );     # find vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    for $i (0..1)
    {
        foreach $srcVd (@oldVds)
        {
            # make a new one
            $newVd =  CreateReplacementVdisk($ctlr, $srcVd );
            if ( $newVd < 0 ) { return ERROR; }

            # save it!
            push @newVds, $newVd ;

            # and mirror it srcVd to newVd
            $ret = CopyContinuousVdisks ($ctlr, $srcVd, $newVd);
            if ( $ret != GOOD ) { return ERROR; }
            $countNewVds ++ ;
        }
    }

    # quick check that we have enough mirrors to continue.
    if ( $countNewVds < 32 )
    {
        logInfo(">>>>>>>> Failed -  Need 16 assigned vdisks (doubled to 32 mirrors) to run test. <<<<<<<<");
        return ERROR ; 
    }

    logInfo("Now we wait for our mirrors to sync.");
    $ret = WaitUntilMirrored( $coPtr, 2, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    # check that all are running as expected. (copy mirror state is ATTR 0x10 and MIRROR 2)
    $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    #variables for this section.
    my @step = ( 6, 7, 4, 5 ) ;             # 7 is resume  6 is pause 4 is a swap  5 is a break
    my @mirror = ( 3, 2, 2, 0 );            # 2 is COPYMIRROR 3 is COPYUSERPAUSE
    my @attr = ( 0x18, 0x10, 0x10, 0x0 ) ;  # 0x10 is copy destination 0x18 is copy dest w/suspend flag
                                            # 0x0 is no copy
    my @twobits = ( 0, 1, 1, 0 ) ;          # Not paused bit map value
    for $idx (0..3)
    {
        logInfo ("Getting PDDs for a little later.");
        @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
        if ( $pdds[0] == INVALID) { return ERROR; }

        logInfo ( "(cmd $step[$idx] mirror $mirror[$idx] attr $attr[$idx])" ) ;
        # send command
        $ret = MultiMirrorExecute( $ctlr, $step[$idx], $countNewVds, \@newVds) ;
        if ($ret == ERROR) { return ERROR; }

#
#   fail pdisk here
#
        # bad things can happen if you fail a disk in the middle of a swap.  So
        # do not fail a disk on the swap step.
        if ($step[$idx] != 4)
        {
            logInfo ("Failing pdisk"); 
            GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

            $ret = FailPdisk( $ctlr, $pdds[1], $pDFailMeans );
            if ( $ret != GOOD ) { return ERROR; }
        }
            
        # wait for the mirror status bit map to come correct
        $ret = WaitForMultiMirrorStatus( $coPtr, $twobits[$idx], \@newVds );
        if ( $ret == ERROR ) { return ERROR ; }
        
        # By the time we get here we should have waited 30-60 seconds.
        $waittime = 20 ;    # 
        $ret = WaitUntilMirrored( $coPtr, $mirror[$idx], \@newVds, $waittime, $maxwait ) ;
        if ( $ret == ERROR ) { return ERROR ; }

        #check that all are running as expected.
        $ret = MultiMirrorCheckAndPrint( $coPtr, $mirror[$idx], $attr[$idx], \@newVds );
        if ( $ret == ERROR ) 
        { 
            logInfo (">>>>>>>> Failed - Mirror Status should be $mirror[$idx] <<<<<<<<"); 
            return ERROR ; 
        }

        # bad things can happen if you fail a disk in the middle of a swap.  So
        # do not fail a disk on the swap step.
        if ($step[$idx] != 4)
        {
            logInfo ("Unfailing Pdisk");
            # unfail the drive
            $ret = UnfailPdisk($ctlr, $pdds[1], $ses, $slot, 0, $lid, $port);
            if ( $ret != GOOD ) { return ERROR; }

            $ret = FixPdiskLabels ($ctlr, 0);
            if ( $ret != GOOD ) { return ERROR; }

            $ret = INVALID;
            $lc = 0;
            while ( $ret != GOOD )
            {       
                $lc++;
                logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));
                
                $ret = DegradeCheck( $ctlr );
                if ( $ret == ERROR )
                {
                    return ERROR;
                }
                DelaySecs( 15 );
            }
        }
        # just wait a bit
        DelaySecs (120) ;
    }

    # cleanup.
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of QRE Test Case 5");
    
    CtlrLogTextAll($coPtr, "End of QRE test case 5." );

    return GOOD;

}

=head2 Xcase4 function

This pausing, resuming and breaking FE LIPs




=cut

=over 1

=item Usage:

 my $rc = Xcase4( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of (16 minimum) vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: Xcase4#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $feliptest
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#
##############################################################################
sub XCase4
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $feliptest ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my $slave ;
    my @coList;
    my $ctlr;
    my $ctlr1;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $countNewVds = 0 ;
    my $i;
    my $k;
    my %rsp;
    my $ret;
    my @pdds;
    my $srcVd;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my $idx ;
    my $ses;
    my $slot;
    my $lid;
    my $port;
    my $waittime = 60 ; # first use is to get the mirrors completely synced
    my $maxwait = 600 ; #

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }                                                                                          

    if ($feliptest == TRUE)
    {
        $msg  = "------ Test Case 4 : Multiple Resync/Mirror repeatedly Pause/Unpause during FE resets. --------";
    }
    else
    {
        $msg  = "------ Test Case 4 : Multiple Resync/Mirror repeatedly Pause/Unpause during BE LIPs. --------";
    }
    $msg0 = "--------------------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    if ($feliptest == TRUE)
    {
        CtlrLogTextAll($coPtr, "Test Case 4 : Multiple Resync/Mirror repeatedly Pause/Unpause during FE resets." );
    }
    else
    {
        CtlrLogTextAll($coPtr, "Test Case 4 : Multiple Resync/Mirror repeatedly Pause/Unpause during BE LIPs." );
    }


    # find the master controller and a slave
    ($master, $slave) = FindMasterPickSlave( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    # if we got a slave lets grab the obj
    if ( $slave != INVALID) 
    {
        # check $slave == invalid before using $ctlr1
        $ctlr1 = $coList[$slave] ;
    }
    
    # Execute cleanup and data collection at start
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    # get measure of the current IO
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
   
    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 4.");

    # We need 32 mirrors.  Lets make this defragable.
    @oldVds = GetRandomVdisks( $ctlr, 16 );     # find vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    for ( $i = 0; $i < 2 ; $i++ )
    {
        foreach $srcVd (@oldVds)
        {
            # make a new one
            $newVd =  CreateReplacementVdisk($ctlr, $srcVd );
            if ( $newVd < 0 ) { return ERROR; }

            # save it!
            push @newVds, $newVd ;

            # and mirror it srcVd to newVd
            $ret = CopyContinuousVdisks ($ctlr, $srcVd, $newVd);
            if ( $ret != GOOD ) { return ERROR; }
            $countNewVds ++ ;
        }
    }

    # quick check that we have enough mirrors to continue.
    if ( $countNewVds < 32 )
    {
        logInfo(">>>>>>>> Failed -  Need 16 assigned vdisks (doubled to 32 mirrors) to run test. <<<<<<<<");
        return ERROR ; 
    }

    logInfo("Now we wait for our mirrors to sync.");
    $ret = WaitUntilMirrored( $coPtr, 2, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    # check that all are running as expected. (copy mirror state is ATTR 0x10 and MIRROR 2)
    $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    $ret = INVALID;

use constant MMRESUME => 7 ;
use constant MMPAUSE  => 6 ;
use constant MMSWAP   => 4 ;
use constant MMBREAK  => 5 ;
use constant MMCDEST    => 0x10 ;
#use constant MMCPAUSE => 0x18 ;
use constant MMCTO  => 1 ;
use constant MMCMIR => 2 ;
use constant MMCPAUSE => 3 ;

    $lc = 0;
    #variables for this section.
    my @twostep = ( 7, 6 ) ;            # 7 is resume  6 is pause
    my @twomirror = ( 2, 3 );           # 2 is COPYMIRROR 3 is COPYUSERPAUSE
    my @twoattr = ( 0x10, 0x18 ) ;      # 0x10 is copy destination 0x18 is copy destination with suspended flag
    my @twobits = ( 1, 0 ) ;            # Not paused bit map value
    $idx = 0 ;
    # 101 iterations.  This leaves us in the proper final state.
    for ($lc = 0; $lc < 101 ; $lc++)
    {
        # Pause/unpause
        $idx = $lc % 2 ;
        logInfo(sprintf("loop iteration: %5d - ", $lc));
        logInfo ( "(cmd $twostep[$idx] mirror $twomirror[$idx] attr $twoattr[$idx])" ) ;
        # 
        $ret = MultiMirrorExecute( $ctlr, $twostep[$idx], $countNewVds, \@newVds) ;
        if ($ret == ERROR) { return ERROR; }

        if ($feliptest == TRUE)
        {
            logInfo ("Reset Qlogic FE ports"); 
        }
        else
        {
            logInfo ("LIP BE ports"); 
        }
        # LIP ports
        #   sequentially LIP each QL card
        for $k (0..3)
        {
            if ($feliptest == TRUE)
            {
                %rsp = $ctlr->resetQlogicFE($k, RESET_QLOGIC_RESET_INITIALIZE);             
                if ($slave != INVALID)
                {
                    $ctlr1->resetQlogicFE($k, RESET_QLOGIC_RESET_INITIALIZE);
                }
                # not real concerned about the slave controller.
                # check the master's response.
                if (%rsp)
                {
                    if ($rsp{STATUS} == PI_GOOD)
                    {
                        print "FE Reset Good On channel $k.\n";
                        DelaySecs(15);                  
                    }
                    else
                    {
                        if($rsp{ERROR_CODE} == $ctlr->PI_ERROR_INV_CHAN)
                        {
                            print "No card on channel $k\n";
                        }
                        else
                        {
                            my $msg = "Unable to reset Qlogic on channel $k.";
                            displayError($msg, %rsp);
                            return ERROR ;
                        }
                    }
                }
                else
                {
                    print "ERROR: Did not receive a response packet.\n";
                    return ERROR;
                }
            }
            else # BE test
            {
                logInfo ("Resetting $k");
                $ret = ResetBELoop ($ctlr, $k );
                if ( $ret == ERROR )
                {
                    print ("\n");
                    logInfo("Error from ResetBELoop. Card = $k.");
                    return ERROR;
                }
                # wait 15 secs between LIPs
                if ( $ret != INVALID )
                {
                    DelaySecs(15);
                }
            }
        }

        # wait for the mirror status bit map to come correct
        $ret = WaitForMultiMirrorStatus( $coPtr, $twobits[$idx], \@newVds );
        if ( $ret == ERROR ) { return ERROR ; }
        
        # By the time we get here we should have waited 30-60 seconds.
        $waittime = 20 ;    # 
        $ret = WaitUntilMirrored( $coPtr, $twomirror[$idx%2], \@newVds, $waittime, $maxwait ) ;
        if ( $ret == ERROR ) { return ERROR ; }

        #check that all are running as expected.
        $ret = MultiMirrorCheckAndPrint( $coPtr, $twomirror[$idx%2], $twoattr[$idx%2], \@newVds );
        if ( $ret == ERROR ) 
        { 
            logInfo ("Mirror Status Incorrect." );
            logInfo ("Mirror Status Trails.   Wait additional 60 seconds for Mirror status.");
            DelaySecs(120) ;
            $ret = MultiMirrorCheckAndPrint( $coPtr, $twomirror[$idx%2], $twoattr[$idx%2], \@newVds );
            if ( $ret == ERROR ) 
            { 
                logInfo (">>>>>>>> Failed - Mirror Status should be $twomirror[$idx%2] <<<<<<<<"); 
                return ERROR ; 
            }
        }
    }

    # swap our raids.  Then break em.
    # we are synced so do a copy swap.
    logInfo ( "Doing a copy swap" );
    $ret = MultiMirrorExecute ($ctlr, 4, $countNewVds, \@newVds);
    if ($ret == ERROR) { return ERROR ; }

    $ret = WaitForMultiMirrorStatus( $coPtr, 1, \@newVds );  # should not be user paused.
    if ( $ret == ERROR ) { return ERROR ; }

    # wait swap to complete.
    $waittime = 10 ;    # shrink the time down (2 is copy mirror)
    $ret = WaitUntilMirrored( $coPtr, 2, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    #check that all are running as expected. (2 is copy mirror.  0x10 is copy destination)
    $ret = MultiMirrorCheckAndPrint( $coPtr, 2, 0x10, \@newVds );
    if ( $ret == ERROR ) { return ERROR ; }

    # break mirrors
    logInfo ( "Breaking mirrors" ) ;
    # send the commands down
    $ret = MultiMirrorExecute ($ctlr, 5, $countNewVds, \@newVds);
    if ($ret == ERROR) { return ERROR ; }

    # wait for the mirror status bit map to come correct (no mirrors means these
    # should go to 0.)
    $ret = WaitForMultiMirrorStatus( $coPtr, 0, \@newVds );
    if ( $ret == ERROR ) { return ERROR ; }

    # wait for mirrors to break.
    $waittime = 10 ;    # shrink the time down (0 is no mirror state)
    $ret = WaitUntilMirrored( $coPtr, 0, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    #check that all are running as expected.
    $ret = MultiMirrorCheckAndPrint( $coPtr, 0, 0, \@newVds );
    if ( $ret == ERROR ) { return ERROR ; }

    # cleanup.
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of QRE Test Case 4");
    
    CtlrLogTextAll($coPtr, "End of QRE test case 4." );

    return GOOD;

}


=head2 Xcase3 function

This pausing, resuming and breaking during defrag.




=cut

=over 1

=item Usage:

 my $rc = Xcase3( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of (16 minimum) vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: Xcase3#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#
##############################################################################
sub XCase3
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $tmpVd;
    my @tmpVds;
    my $countNewVds = 0 ;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my $srcVd;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my $idx ;
    my $failedDisk;
    my $ses;
    my $slot;
    my $lid;
    my $port;
    my $waittime = 60 ; # first use is to get the mirrors completely synced
    my $maxwait = 600 ; #

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }                                                                                          

    $msg  = "------ Test Case 3 : Multiple Resync/Mirror repeatedly Pause/Unpause during rebuild. --------";
    $msg0 = "--------------------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 3 : Multiple Resync/Mirror repeatedly Pause/Unpause during rebuild." );

    # find the master controller
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    # Execute cleanup and data collection at start
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    # get measure of the current IO
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
   
    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 3.");

    # We need 32 mirrors.  Lets make this defragable.
    @oldVds = GetRandomVdisks( $ctlr, 16 );     # find vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    for ( $i = 0; $i < 2 ; $i++ )
    {
        foreach $srcVd (@oldVds)
        {
            # make a new one
            $newVd =  CreateReplacementVdisk($ctlr, $srcVd );
            if ( $newVd < 0 ) { return ERROR; }

            # save it!
            push @newVds, $newVd ;

            # and mirror it srcVd to newVd
            $ret = CopyContinuousVdisks ($ctlr, $srcVd, $newVd);
            if ( $ret != GOOD ) { return ERROR; }
            $countNewVds ++ ;
        }
    }

    # quick check that we have enough mirrors to continue.
    if ( $countNewVds < 32 )
    {
        logInfo(">>>>>>>> Failed -  Need 16 assigned vdisks (doubled to 32 mirrors) to run test. <<<<<<<<");
        return ERROR ; 
    }

    logInfo("Now we wait for our mirrors to sync.");
    $ret = WaitUntilMirrored( $coPtr, 2, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    # check that all are running as expected. (copy mirror state is ATTR 0x10 and MIRROR 2)
    $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    # kill a disk

    logInfo("Going to fail a pdisk now");

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 1: now failing pdd $pdds[1]" );

    $failedDisk = $pdds[1];

    GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $ctlr, $failedDisk, $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin

    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    #variables for this section.
    my @twostep = ( 7, 6 ) ;            # 7 is resume  6 is pause
    my @twomirror = ( 2, 3 );           # 2 is COPYMIRROR 3 is COPYUSERPAUSE
    my @twoattr = ( 0x10, 0x18 ) ;      # 0x10 is copy destination 0x18 is copy destination with suspended flag
    my @twobits = ( 1, 0 ) ;            # Not paused bit map value
    $idx = 0 ;
# put something here to make sure we do not end paused
# so keep going until rebuildret == good and we've not just done
# a pause
    my $rebuildret = ERROR ;
    while ( ($rebuildret != GOOD) || ($idx != 0))
#    while ( $rebuildret != GOOD )
    {
        # Pause/unpause
        $idx = $lc % 2 ;
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));
        logInfo ( "(cmd $twostep[$idx] mirror $twomirror[$idx] attr $twoattr[$idx])" ) ;
        # 
        $ret = MultiMirrorExecute( $ctlr, $twostep[$idx], $countNewVds, \@newVds) ;
        if ($ret == ERROR) { return ERROR; }

        # wait for the mirror status bit map to come correct
        $ret = WaitForMultiMirrorStatus( $coPtr, $twobits[$idx], \@newVds );
        if ( $ret == ERROR ) { return ERROR ; }

        # check our rebuild
        $rebuildret = DegradeCheck( $ctlr );
        if ( $rebuildret == ERROR )
        {
            return ERROR;
        }

        # the original rebuild code did a delay here.  But we have more than enough delay in the 
        # WaitUntilMirrored code

        $waittime = 20 ;    # shrink the time down
        $ret = WaitUntilMirrored( $coPtr, $twomirror[$idx%2], \@newVds, $waittime, $maxwait ) ;
        if ( $ret == ERROR ) { return ERROR ; }

        #check that all are running as expected.
        $ret = MultiMirrorCheckAndPrint( $coPtr, $twomirror[$idx%2], $twoattr[$idx%2], \@newVds );
        if ( $ret == ERROR ) 
        { 
            logInfo ("Mirror Status Incorrect." );
            logInfo ("Mirror Status Trails.   Wait additional 60 seconds for Mirror status.");
            DelaySecs(120) ;
            $ret = MultiMirrorCheckAndPrint( $coPtr, $twomirror[$idx%2], $twoattr[$idx%2], \@newVds );
            if ( $ret == ERROR ) 
            { 
                logInfo (">>>>>>>> Failed - Mirror Status should be $twomirror[$idx%2] <<<<<<<<"); 
                return ERROR ; 
            }
        }
    }

    PSDCheck( $ctlr );

    # unfail the drive
    $ret = UnfailPdisk($ctlr, $failedDisk, $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    # swap our raids.  Then break em.
    # we are synced so do a copy swap.
    logInfo ( "Doing a copy swap" );
    $ret = MultiMirrorExecute ($ctlr, 4, $countNewVds, \@newVds);
    if ($ret == ERROR) { return ERROR ; }

    $ret = WaitForMultiMirrorStatus( $coPtr, 1, \@newVds );  # should not be user paused.
    if ( $ret == ERROR ) { return ERROR ; }

    # wait swap to complete.
    $waittime = 10 ;    # shrink the time down (2 is copy mirror)
    $ret = WaitUntilMirrored( $coPtr, 2, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    #check that all are running as expected. (2 is copy mirror.  0x10 is copy destination)
    $ret = MultiMirrorCheckAndPrint( $coPtr, 2, 0x10, \@newVds );
    if ( $ret == ERROR ) { return ERROR ; }

    # break mirrors
    logInfo ( "Breaking mirrors" ) ;
    # send the commands down
    $ret = MultiMirrorExecute ($ctlr, 5, $countNewVds, \@newVds);
    if ($ret == ERROR) { return ERROR ; }

    # wait for the mirror status bit map to come correct (no mirrors means these
    # should go to 0.)
    $ret = WaitForMultiMirrorStatus( $coPtr, 0, \@newVds );
    if ( $ret == ERROR ) { return ERROR ; }

    # wait for mirrors to break.
    $waittime = 10 ;    # shrink the time down (0 is no mirror state)
    $ret = WaitUntilMirrored( $coPtr, 0, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    #check that all are running as expected.
    $ret = MultiMirrorCheckAndPrint( $coPtr, 0, 0, \@newVds );
    if ( $ret == ERROR ) { return ERROR ; }

    # cleanup.
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of QRE Test Case 3");
    
    CtlrLogTextAll($coPtr, "End of QRE test case 3." );

    return GOOD;



}

=head2 Xcase2 function

This pausing, resuming and breaking during defrag.




=cut

=over 1

=item Usage:

 my $rc = Xcase2( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of (16 minimum) vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: Xcase2#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#
##############################################################################
sub XCase2
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $tmpVd;
    my @tmpVds;
    my $countNewVds = 0 ;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my $srcVd;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my $idx ;
    my $waittime = 60 ; # first use is to get the mirrors completely synced
    my $maxwait = 600 ; #

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }                                                                                          

    $msg  = "------ Test Case 2 : Multiple Resync/Mirror repeatedly Pause/Unpause during defrag. --------";
    $msg0 = "--------------------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 2 : Multiple Resync/Mirror repeatedly Pause/Unpause during defrag." );

    # find the master controller
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    # Execute cleanup and data collection at start
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    # get measure of the current IO
    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
   
    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 2.");

    # We need 32 mirrors.  Lets make this defragable.
    @oldVds = GetRandomVdisks( $ctlr, 16 );     # find vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    for ( $i = 0; $i < 2 ; $i++ )
    {
        foreach $srcVd (@oldVds)
        {
            # make a temporary one
            $tmpVd =  CreateReplacementVdisk($ctlr, $srcVd );
            if ( $tmpVd < 0 ) { return ERROR; }

            #save it
            push @tmpVds, $tmpVd ;

            # make a new one
            $newVd =  CreateReplacementVdisk($ctlr, $srcVd );
            if ( $newVd < 0 ) { return ERROR; }

            # save it!
            push @newVds, $newVd ;

            # and mirror it srcVd to newVd
            $ret = CopyContinuousVdisks ($ctlr, $srcVd, $newVd);
            if ( $ret != GOOD ) { return ERROR; }
            $countNewVds ++ ;
        }
    }

    # quick check that we have enough mirrors to continue.
    if ( $countNewVds < 32 )
    {
        logInfo(">>>>>>>> Failed -  Need 16 assigned vdisks (doubled to 32 mirrors) to run test. <<<<<<<<");
        return ERROR ; 
    }
    # delete the temp disks.
    foreach $srcVd (@tmpVds)
    {
        # delete the first copied disk (after we make the new ones)
        if ( ERROR == DeleteSingleVdisk($ctlr, $srcVd) ) { return ERROR; }
    }

    logInfo("Now we wait for our mirrors to sync.");
    $ret = WaitUntilMirrored( $coPtr, 2, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    # check that all are running as expected. (copy mirror state is ATTR 0x10 and MIRROR 2)
    $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    #
    # We have a bunch of mirrors and a fragmented system.
    #
    # We are ready to begin.
    #

       # loop
        # create a dummy vdisk
        # create a vdisk for Qre
        # delete the dummy vdisks
       # now we have the newvd array for qre testing sitting
       # in a defragable state.

    # initiate defrag
    $ret = DefragAllBegin($ctlr);                                      # parallel
    if ( $ret != GOOD ) { return ERROR; }
            
    # loop through pause/resume while defrag is running
    # time for the twostep.  We are simply pausing and unpausing
    # in this test.

    #variables for this section.
    my @twostep = ( 7, 6 ) ;            # 7 is resume  6 is pause
    my @twomirror = ( 2, 3 );           # 2 is COPYMIRROR 3 is COPYUSERPAUSE
    my @twoattr = ( 0x10, 0x18 ) ;      # 0x10 is copy destination 0x18 is copy destination with suspended flag
    my @twobits = ( 1, 0 ) ;            # Not paused bit map value
    # 201 times through
    for ( $idx = 0; $idx < 201; $idx++)
    {
        logInfo ( "Loop $idx (cmd $twostep[$idx%2] mirror $twomirror[$idx%2] attr $twoattr[$idx%2])" ) ;
        # 
        $ret = MultiMirrorExecute( $ctlr, $twostep[$idx % 2], $countNewVds, \@newVds) ;
        if ($ret == ERROR) { return ERROR; }

        # wait for the mirror status bit map to come correct
        $ret = WaitForMultiMirrorStatus( $coPtr, $twobits[$idx%2], \@newVds );
        if ( $ret == ERROR ) { return ERROR ; }

        $waittime = 30 ;    # shrink the time down
        $ret = WaitUntilMirrored( $coPtr, $twomirror[$idx%2], \@newVds, $waittime, $maxwait ) ;
        if ( $ret == ERROR ) { return ERROR ; }

        #check that all are running as expected.
        $ret = MultiMirrorCheckAndPrint( $coPtr, $twomirror[$idx%2], $twoattr[$idx%2], \@newVds );
        if ( $ret == ERROR ) 
        { 
            logInfo ("Mirror Status Incorrect." );
            logInfo ("Mirror Status Trails.   Wait additional 60 seconds for Mirror status.");
            DelaySecs(120) ;
            $ret = MultiMirrorCheckAndPrint( $coPtr, $twomirror[$idx%2], $twoattr[$idx%2], \@newVds );
            if ( $ret == ERROR ) 
            { 
                logInfo (">>>>>>>> Failed - Mirror Status should be $twomirror[$idx%2] <<<<<<<<"); 
                return ERROR ; 
            }
        }
    }

    # we are synced so do a copy swap.
    logInfo ( "Doing a copy swap" );
    $ret = MultiMirrorExecute ($ctlr, 4, $countNewVds, \@newVds);
    if ($ret == ERROR) { return ERROR ; }

    $ret = WaitForMultiMirrorStatus( $coPtr, 1, \@newVds );  # should not be user paused.
    if ( $ret == ERROR ) { return ERROR ; }

    # wait swap to complete.
    $waittime = 10 ;    # shrink the time down (2 is copy mirror)
    $ret = WaitUntilMirrored( $coPtr, 2, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    #check that all are running as expected. (2 is copy mirror.  0x10 is copy destination)
    $ret = MultiMirrorCheckAndPrint( $coPtr, 2, 0x10, \@newVds );
    if ( $ret == ERROR ) { return ERROR ; }

#
# Wait here until cs has executed.

    # break mirrors
    logInfo ( "Breaking mirrors" ) ;
    # send the commands down
    $ret = MultiMirrorExecute ($ctlr, 5, $countNewVds, \@newVds);
    if ($ret == ERROR) { return ERROR ; }

    # wait for the mirror status bit map to come correct (no mirrors means these
    # should go to 0.)
    $ret = WaitForMultiMirrorStatus( $coPtr, 0, \@newVds );
    if ( $ret == ERROR ) { return ERROR ; }

    # wait for mirrors to break.
    $waittime = 10 ;    # shrink the time down (0 is no mirror state)
    $ret = WaitUntilMirrored( $coPtr, 0, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    #check that all are running as expected.
    $ret = MultiMirrorCheckAndPrint( $coPtr, 0, 0, \@newVds );
    if ( $ret == ERROR ) { return ERROR ; }

    # wait for defrag to complete.
    $ret = DefragWait( $ctlr );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed waiting for defrags to end. <<<<<<<<");
        return (ERROR);
    }
    # cleanup.
    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of QRE Test Case 2");
    
    CtlrLogTextAll($coPtr, "End of QRE test case 2." );

    return GOOD;

}

=head2 Xcase1 function

This case just parameter checks the Multiple Mirror Pause feature.




=cut

=over 1

=item Usage:

 my $rc = Xcase1( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: Xcase1#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#
##############################################################################
sub XCase1
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $countNewVds = 0 ;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my $srcVd;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my $idx ;
    my $waittime = 60 ; # first use is to get the mirrors completely synced
    my $maxwait = 600 ; #



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg  = "------ Test Case 1 : Multiple Resync/Mirror Pause feature parameter checking. --------";
    $msg0 = "--------------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 1 : Multiple Resync/Mirror Pause feature parameter checking." );

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # Parameter checking.
    ######################################################################

    # setup - need to houseclean

    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 1.");

    ##############################
    # Simple Parameter Checking
    ##############################

    # We need 32 mirrors.  Standard config is 26 so just grab 16 mirror
    # them twice
    @oldVds = GetRandomVdisks( $ctlr, 16 );     # find vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    for ( $i = 0; $i < 2 ; $i++ )
    {
        foreach $srcVd (@oldVds)
        {
            # make a new one
            $newVd =  CreateReplacementVdisk($ctlr, $srcVd );
            if ( $newVd < 0 ) { return ERROR; }

            # save it!
            push @newVds, $newVd ;

            # and mirror it srcVd to newVd
            $ret = CopyContinuousVdisks ($ctlr, $srcVd, $newVd);
            if ( $ret != GOOD ) { return ERROR; }
            $countNewVds ++ ;
        }
    }

    # quick check that we have enough mirrors to continue.
    if ( $countNewVds < 32 )
    {
        logInfo(">>>>>>>> Failed -  Need 16 assigned vdisks (doubled to 32 mirrors) to run test. <<<<<<<<");
        return ERROR ; 
    }

    logInfo("Now we wait for our mirrors to sync.");
    $ret = WaitUntilMirrored( $coPtr, 2, \@newVds, $waittime, $maxwait ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    # check that all are running as expected. (copy mirror state is ATTR 0x10 and MIRROR 2)
    $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    # So, going forward oldVds are the orginal Vdisks and newVds are the replacement Vdisks.

    logInfo ("(Errors are expected in this test.  Test will stop if they are a problem.)");

    #
    # Go command with no start.
    #
    CtlrLogTextAll($coPtr, "Sub Test Case 1 : Go with no start." );
    # we do this for all 4 valid command types.
    for ( $i = 4 ; $i < 8 ; $i++ )
    {
        logInfo ("Go ($i) command with no start.");
        %rsp = MultiResyncMirrorPauseGoCommand ($ctlr, $i, $newVds[0] ); 
        if ( $rsp{STATUS} == GOOD ) 
        { 
            logInfo(">>>>>>>> Failed -  Go command accepted without start <<<<<<<<");
            return ERROR ; 
        }
        else
        {
            logInfo("Command was rejected.  Test SUCCESS."); 
        }
        # make sure we are in our expected state (unchanged)
        $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
        if ( $ret == ERROR ) {  return ERROR ;  }
    }


    #
    # Send deferred with no start
    #
    CtlrLogTextAll($coPtr, "Sub Test Case 2 : Deferred with no start." );
    # we do this for all 4 valid command types.
    for ( $i = 4 ; $i < 8 ; $i++)
    {
        %rsp = MultiResyncMirrorPauseDeferredCommand ($ctlr, $i, $newVds[0] ); 
        if ($rsp{STATUS} == GOOD )            # 0 is good
        { 
            logInfo(">>>>>>>> Failed -  Deferred command accepted without start <<<<<<<<");
            return ERROR ; 
        }
        else
        {
            logInfo("Command was rejected.  Test SUCCESS."); 
        }
        $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
        if ( $ret == ERROR ) {  return ERROR ; }
    }

    #
    # check with op code > 8
    #
    CtlrLogTextAll($coPtr, "Sub Test Case 3 : Command out of range." );
    logInfo("Start");
    %rsp = MultiResyncMirrorPauseStartCommand ($ctlr, 9, 10, $newVds[0] ); 
    if ($rsp{STATUS} == GOOD )            # 0 is good
    { 
        logInfo(">>>>>>>> Failed - Invalid command accepted.<<<<<<<<");
        return ERROR ; 
    }
    logInfo("Deferred");
    %rsp = MultiResyncMirrorPauseStartCommand ($ctlr, 4, 10, $newVds[0] ); 
    if ($rsp{STATUS} != GOOD )            # 0 is good
    { 
        logInfo(">>>>>>>> Failed - Command rejected .<<<<<<<<");
        return ERROR ; 
    }
    %rsp = MultiResyncMirrorPauseDeferredCommand ($ctlr, 9, $newVds[0] ); 
    if ($rsp{STATUS} == GOOD )            # 0 is good
    { 
        logInfo(">>>>>>>> Failed - Invalid command accepted.<<<<<<<<");
        return ERROR ; 
    }
    logInfo("Go");
    %rsp = MultiResyncMirrorPauseStartCommand ($ctlr, 4, 1, $newVds[0] ); 
    if ($rsp{STATUS} != GOOD )            # 0 is good
    { 
        logInfo(">>>>>>>> Failed - Start command rejected .<<<<<<<<");
        return ERROR ; 
    }
    %rsp = MultiResyncMirrorPauseDeferredCommand ($ctlr, 4, $newVds[0] ); 
    if ($rsp{STATUS} != GOOD )            # 0 is good
    { 
        logInfo(">>>>>>>> Failed - Deferred command accepted.<<<<<<<<");
        return ERROR ; 
    }
    %rsp = MultiResyncMirrorPauseGoCommand ($ctlr, 9, $newVds[0] ); 
    if ( $rsp{STATUS} == GOOD ) 
    { 
        logInfo(">>>>>>>> Failed -  Invalid command accepted <<<<<<<<");
        return ERROR ; 
    }
    else 
    { 
        logInfo("Command was rejected.  Test SUCCESS."); 
    }
    $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    #
    # Tell it you are sending 10 but only send 5.
    #
    CtlrLogTextAll($coPtr, "Sub Test Case 4 : Wrong number of defers." );
    %rsp = MultiResyncMirrorPauseStartCommand ($ctlr, 4, 10, $newVds[0] ); 
    if ($rsp{STATUS} != GOOD )
    { 
        logInfo(">>>>>>>> Failed -  Start command rejected<<<<<<<<");
        return ERROR ; 
    }
    for ( $i = 0 ; $i < 5; $i ++ )
    {
        # send deferred
        %rsp = MultiResyncMirrorPauseDeferredCommand ($ctlr, 4, $newVds[$i] ); 
        if ($rsp{STATUS} != GOOD )            # 0 is good
        { 
            logInfo(">>>>>>>> Failed -  Command was rejected. <<<<<<<<"); 
            return ERROR ; 
        }
    }
    %rsp = MultiResyncMirrorPauseGoCommand ($ctlr, 4, $newVds[$i] ); 
    if ( $rsp{STATUS} == GOOD ) 
    { 
        logInfo(">>>>>>>> Failed -  Go command accepted with wrong number of defers <<<<<<<<");
        return ERROR ; 
    }
    else
    {
        logInfo("Command was rejected.  Test SUCCESS."); 
    }
    $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    #
    # do the reverse.  Say 5 do 10.
    CtlrLogTextAll($coPtr, "Sub Test Case 5 : Wrong number of defers." );
    %rsp = MultiResyncMirrorPauseStartCommand ($ctlr, 4, 5, $newVds[0] ); 
    if ($rsp{STATUS} != GOOD )
    { 
        logInfo(">>>>>>>> Failed -  Start command rejected<<<<<<<<");
        return ERROR ; 
    }
    # give it 10 defers.
    for ( $i = 0 ; $i < 10; $i ++ )
    {
        # send deferred
        %rsp = MultiResyncMirrorPauseDeferredCommand ($ctlr, 4, $newVds[$i] ); 
        if ( $rsp{STATUS} != GOOD )
        { 
            # there are two ways this can go.
            # it can reject all commands over 5.
            # or it can simply reject the go command.
            if ( $i < 5 ) # shouldn't happen yet
            {
                logInfo(">>>>>>>> Failed -  Command was rejected. <<<<<<<<"); 
                return ERROR ; 
            }
            else
            {
                logInfo("Command was rejected"); 
            }
        }
    }
    # if we have an error above then we've no need to send the Go.
    if ( $rsp{STATUS} == GOOD ) 
    {
        %rsp = MultiResyncMirrorPauseGoCommand ($ctlr, 4, $newVds[$i] ); 
    }
    # same final check
    if ( $rsp{STATUS} == GOOD ) 
    { 
        logInfo(">>>>>>>> Failed -  Go command accepted with wrong number of defers <<<<<<<<");
        return ERROR ; 
    }
    else
    {
        logInfo("Command was rejected.  Test SUCCESS."); 
    }
    $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
    if ( $ret == ERROR ) { return ERROR ; }
    
    #
    # Tell it you are sending 257. 
    #
    CtlrLogTextAll($coPtr, "Sub Test Case 6 : 257 defers.  (Out of range.)" );
    %rsp = MultiResyncMirrorPauseStartCommand ($ctlr, 4, 257, $newVds[0] ); 
    if ($rsp{STATUS} == GOOD ) 
    {  
        logInfo(">>>>>>>> Failed -  257 Mirrors was accepted <<<<<<<<");
        return ERROR ; 
    } 
    else 
    { 
        logInfo("Command was rejected.  Test SUCCESS."); 
    }
    $ret = MultiMirrorCheckAndPrint($coPtr, 2, 0x10, \@newVds ) ;
    if ( $ret == ERROR ) { return ERROR ; }

    # 
    # Do real commands and confirm that they work.
    #
    # time for the twostep.  We are simply pausing and unpausing
    # in this test.
    CtlrLogTextAll($coPtr, "Sub Test Case 7 : Pause/unpause many times." );
    #variables for this section.
    my @twostep = ( 7, 6 ) ;            # 7 is resume  6 is pause
    my @twomirror = ( 2, 3 );           # 2 is COPYMIRROR 3 is COPYUSERPAUSE
    my @twoattr = ( 0x10, 0x18 ) ;      # 0x10 is copy destination 0x18 is copy destination with suspended flag
    my @twobits = ( 1, 0 ) ;            # Not paused bit map value
    # 200 times through
    for ( $idx = 0; $idx < 200; $idx++)
    {
        logInfo ( "Loop $idx (cmd $twostep[$idx%2] mirror $twomirror[$idx%2] attr $twoattr[$idx%2])" ) ;
        # send down the commands
        $ret = MultiMirrorExecute( $ctlr, $twostep[$idx % 2], $countNewVds, \@newVds) ;
        if ($ret == ERROR) { return ERROR; }

        # wait for the mirror status bit map to come correct
        $ret = WaitForMultiMirrorStatus( $coPtr, $twobits[$idx%2], \@newVds );
        if ( $ret == ERROR ) { return ERROR ; }

        # the Mirror status trails ATTR and the bitmap.  So, wait a touch.
        DelaySecs(20) ;

        #check that all are running as expected.
        $ret = MultiMirrorCheckAndPrint( $coPtr, $twomirror[$idx%2], $twoattr[$idx%2], \@newVds );
        if ( $ret == ERROR ) 
        { 
            logInfo ("Mirror Status Incorrect." );
            logInfo ("Mirror Status Trails.   Wait additional 60 seconds for Mirror status.");
            DelaySecs(120) ;
            $ret = MultiMirrorCheckAndPrint( $coPtr, $twomirror[$idx%2], $twoattr[$idx%2], \@newVds );
            if ( $ret == ERROR ) 
            { 
                logInfo (">>>>>>>> Failed - Mirror Status should be $twomirror[$idx%2] <<<<<<<<"); 
                return ERROR ; 
            }
        }

        #
        # Get everything back in sync.
        #
        $waittime = 15 ;    # shrink the time down
        $ret = WaitUntilMirrored( $coPtr, $twomirror[$idx%2], \@newVds, $waittime, $maxwait ) ;
        if ( $ret == ERROR ) { return ERROR ; }
    }


    CtlrLogTextAll($coPtr, "Sub Test Case 8 : Real commands." );
    #variables for this section.
    my @cmds     = ( 7, 6, 7, 5 );  # commands we are sending down
    my @vdMirror = ( 2, 3, 2, 0 );  # what the status (mirror value) of the copies should be.
    my @vdAttr   = ( 0x10, 0x18, 0x10, 0x00 );    # what the attr value of hte copies should be.
    # we do a resume, pause, resume, break.
    for ( $idx = 0 ; $idx < scalar(@cmds) ; $idx ++)
    {
        # send down the commands
        $ret = MultiMirrorExecute( $ctlr, $cmds[$idx], $countNewVds, \@newVds) ;
        if ($ret == ERROR) { return ERROR; }

        # wait until mirrored.  (Don't wait forever.)
        $ret = WaitUntilMirrored( $coPtr, $vdMirror[$idx], \@newVds, $waittime, $maxwait ) ;
        if ( $ret == ERROR ) { return ERROR ; }

        #check that all are running as expected.
        $ret = MultiMirrorCheckAndPrint( $coPtr, $vdMirror[$idx], $vdAttr[$idx], \@newVds );
        if ( $ret == ERROR ) { return ERROR ; }
    }

    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("End of QRE Test Case 1");
    
    CtlrLogTextAll($coPtr, "End of QRE test case 1." );

    return GOOD;

}


###############################################################################



###############################################################################

=head2 UETestEntry function

The primary entry point for the Bigfoot UE tests.

A function used for debugging the code as a generic entry. The final
parameter represents the test case to be run. A test case of 99 will
run most tests sequentially. There is no guarantee that the tests can actually
run sequentially and give full coverage.

The test system should be configured as desired and IO from the
servers should be running. Most likely this will mean a two-way system.
IO from the servers needs to be consistent over time or the IO validation
checks may fail. For the most part, RAIDs should be redundant as many tests
will fail pdisks and require rebuilds. The test will hang if a drive
becomes permanently degraded.

Tests can be run individually by specifying the test case number. ( 1...25+)
Not all test case numbers exist ( the list is not contiguous). Specifying
an invalid number just means no test will be run. Test case 99 will run most
test cases sequentially. Test that are designed to cause a fatal condition
will not be part of the 99 sequence.

Some test require a minimum of a 2 way configuration, others will run on
1-way or n-way configurations.

Refer to the individual test cases for more information on the
individual tests.

=cut

=over 1

=item Usage:

 my $rc = UETestEntry($coPtr, $retIn, $snPtr, $moxaPtr, $mmPtr, $case );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaPtr is a pointer to a list of Moxa controller IP addresses
        $mmPtr is a pointer to a list of tha Moxa channel mappings
        $case is the test case to run

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the test(s)
           ran to completion without error. Test logs must be reviewed to
           ensure the test ran correctly.



=back

=cut


##############################################################################
#
#          Name: UETestEntry
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:
#
##############################################################################
sub UETestEntry
{
    trace();
    my ( $coPtr,  $snPtr, $moxaIP, $mmPtr, $wwnPtr, $ipPtr, $case, $loopCount ) = @_;

    my $ret;
    my $autoLoop;

    $autoLoop = 0;
    $ret = GOOD;



    my @coList = @$coPtr;

    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "                starting UETest Case $case. ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
 #   DelaySecs(300);

    StatsProcAll($coPtr);

    if ( !$loopCount )
    {
        logInfo("LoopCount was not specified, default values will be used.");
        $autoLoop = 1;
    }

    if ( $case == 99 )
    {
        logInfo("All test cases selected, default loop count values will be used.");
        $autoLoop = 1;
    }


    if ( $case == 1  || $case == 99 ) { $ret = UETestCase01( $coPtr, GOOD, $snPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 3  || $case == 99 ) { $ret = UETestCase03( $coPtr, GOOD, $snPtr, 5, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 5   ) { $ret = UETestCase05( $coPtr, GOOD, 5000); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 10 || $case == 99 ) { $ret = XCase1( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 11 || $case == 99 ) { $ret = XCase2( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 12 || $case == 99 ) { $ret = XCase3( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 13 || $case == 99 ) { $ret = XCase4( $coPtr, GOOD, $snPtr, 1, TRUE ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 14 || $case == 99 ) { $ret = XCase4( $coPtr, GOOD, $snPtr, 1, FALSE ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 15 || $case == 99 ) { $ret = XCase5( $coPtr, GOOD, $snPtr, 1, 0); }
    if ( $ret != GOOD ) { return $ret; }

    # loop primitive group
    if ( $case == 20 || $case == 99 ) { $ret = UETestCase20( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 21 || $case == 99 ) { $ret = UETestCase21( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 22 || $case == 99 ) { $ret = UETestCase22( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 23 || $case == 99 ) { $ret = UETestCase23( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 24 || $case == 99 ) { $ret = UETestCase24( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 25 || $case == 99 ) { $ret = UETestCase25( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 26 || $case == 99 ) { $ret = UETestCase26( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 27 || $case == 99 ) { $ret = UETestCase27( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 28 || $case == 99 ) { $ret = UETestCase28( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 29 || $case == 99 ) { $ret = UETestCase29( $coPtr, GOOD, $snPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    #-----------------




    StatsProcAll($coPtr);
    #PeriodicDataGather($coPtr);

    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
    CtlrLogTextAll( $coPtr, "           UETest Case $case ends. ");
    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
#    DelaySecs(300);

    return $ret;

}


##############################################################################
#
#          Name: Support Functions
#
#  These are probably not exported.
#
##############################################################################

###############################################################################


###############################################################################


###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################


###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################




###############################################################################



###############################################################################





###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################

###############################################################################


##############################################################################


1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.4  2005/09/13 14:16:55  ElvesterN
# Commented out re-declared MMCPAUSE constant (causes warnings in 5.8).
# Reviewed by Neal Eiden.
#
# Revision 1.3  2005/06/27 13:26:47  MenningC
# Tbolt00000000:This updates the file to compile properly,
#  removed tabs and adds a return to XCase6.
#
# Revision 1.2  2005/06/27 13:21:35  MenningC
# Tbolt00000000:This adds the work that Tom Swanson did for QRE feature. It appears as test cases 10-15.
# THese have not been validated.
#
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
# Revision 1.3  2004/12/07 21:54:09  MenningC
# tbolt00000000: Add data collection for perf testing; reviewed by Al
#
# Revision 1.2  2004/09/02 21:20:54  KohlmeyerA
# Tbolt00000000:  Broke UETest up into separate UETest and UETestSupport files.
# Reviewed by Craig.
#
# Revision 1.1  2004/07/12 15:28:55  MenningC
# tbolt00000000: new file for orphan raids test.  reviewed by Al
#
#
#
#
##############################################################################
