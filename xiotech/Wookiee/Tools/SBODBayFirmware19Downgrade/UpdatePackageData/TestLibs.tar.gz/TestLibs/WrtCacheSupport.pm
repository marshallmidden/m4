#! /usr/bin/perl 
# $Header$
##############################################################################
# File name:  TestLibs::WrtCacheSupport
#
# Desc: A set of library functions for integration testing of the
#       write cache feature.
#
# Date: 04/15/2003
#
# Original Author:  Craig Menning
#
# Last modified by  $Author: RustadM $
# Modified date     $Date: 2006-09-07 11:37:18 -0500 (Thu, 07 Sep 2006) $
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002-2006 Xiotech Corporation. All rights reserved.
#
#   For Xiotech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::WrtCacheSupport - Perl functions to support Write Cache Tests

$Id: WrtCacheSupport.pm 13469 2006-09-07 16:37:18Z RustadM $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

A set of library functions for integration testing of the write cache feature.

=head1 DESCRIPTION

Test Functions Available (exported)

=cut
##############################################################################

#                         
# - what I am
#
package TestLibs::WrtCacheSupport;

#
# - other modules used
#
use warnings;
use lib "../CCBE";
use XIOTech::xiotechPackets;
use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::IntegCCBELib;
use TestLibs::BEUtils;
use TestLibs::utility;


#
# - perl compiler/interpreter flags 'n' things
#
use strict;

#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    #
    # set the version for version checking
    #
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        WRTCACHE_DISABLED
                        WRTCACHE_ENABLED
                        WRTCACHE_ENABLE_PENDING

                        WRTCACHE_BAT_FE
                        WRTCACHE_BAT_BE
                        WRTCACHE_BAT_FEBE

                        WRTCACHE_BAT_GOOD
                        WRTCACHE_BAT_BAD

                        WRTCACHE_MIRROR_LOCAL
                        WRTCACHE_MIRROR_REMOTE

                        WRTCACHE_GLOBAL_SET_ENABLE
                        WRTCACHE_GLOBAL_SET_DISABLE
                        WRTCACHE_VDISKS_SET_ENABLE
                        WRTCACHE_VDISKS_SET_DISABLE

                        WRTCACHE_GLOBAL_SET_ENABLE_TEXT
                        WRTCACHE_GLOBAL_SET_DISABLE_TEXT
                        WRTCACHE_VDISKS_SET_ENABLE_TEXT
                        WRTCACHE_VDISKS_SET_DISABLE_TEXT

                        &WrtCacheValidateFull
                        &WrtCacheValidateDSCCacheGlobal
                        &WrtCacheValidateCacheGlobal
                        &WrtCacheValidateDSCBatteries
                        &WrtCacheValidateBattery
                        &WrtCacheValidateDSCMirrors
                        &WrtCacheValidateMirror
                        &WrtCacheValidateDSCCacheVDisks
                        &WrtCacheValidateCacheVDisks
                        &WrtCacheValidateCacheVDiskList
                        &WrtCacheValidateCacheVDisk
                        &WrtCacheValidateDSCCacheInUse

                        &WrtCacheControl
                        &WrtCacheControlGlobal
                        &WrtCacheControlVdisksAll
                        &WrtCacheControlVdisksMultiple
                        &WrtCacheControlVdisksSingle
                        &WrtCacheBatteryHealth

                        &WrtCacheDisplayGlobalCacheInfo
                        &WrtCacheDisplayTimeLine
                        
                        &WrtCacheRestoreCacheState
                        &WrtCacheValidateCacheUnchanged
                        &WrtCacheVdisksSelectAllAltRandom
                        &WrtCacheTimeLine
                        &WrtCacheWaitForBatteries
                      );

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 13469 $);
}

our @EXPORT_OK;


##############################################################################
#
#               Public Definitions
#
##############################################################################
use constant WRTCACHE_DISABLED                  => 0x0;
use constant WRTCACHE_ENABLED                   => 0x1;
use constant WRTCACHE_ENABLE_PENDING            => 0x4;  # This may need to be 0x4 as per defect 12602

use constant WRTCACHE_BAT_FE                    => 0x1;
use constant WRTCACHE_BAT_BE                    => 0x2;
use constant WRTCACHE_BAT_FEBE                  => (WRTCACHE_BAT_FE | WRTCACHE_BAT_BE);

use constant WRTCACHE_BAT_GOOD                  => 0x0;
use constant WRTCACHE_BAT_BAD                   => 0x1;

use constant WRTCACHE_MIRROR_LOCAL              => 0x0;
use constant WRTCACHE_MIRROR_REMOTE             => 0x1;

use constant WRTCACHE_GLOBAL_SET_DISABLE        => 0x80;
use constant WRTCACHE_GLOBAL_SET_ENABLE         => 0x81;
use constant WRTCACHE_VDISKS_SET_DISABLE        => 0x0;
use constant WRTCACHE_VDISKS_SET_ENABLE         => 0x1;

use constant WRTCACHE_DISABLED_TEXT             => "WRTCACHE_DISABLED";
use constant WRTCACHE_ENABLED_TEXT              => "WRTCACHE_ENABLED";

use constant WRTCACHE_GLOBAL_SET_DISABLE_TEXT   => "WRTCACHE_GLOBAL_SET_DISABLE";
use constant WRTCACHE_GLOBAL_SET_ENABLE_TEXT    => "WRTCACHE_GLOBAL_SET_ENABLE";
use constant WRTCACHE_VDISKS_SET_DISABLE_TEXT   => "WRTCACHE_VDISKS_SET_DISABLE";
use constant WRTCACHE_VDISKS_SET_ENABLE_TEXT    => "WRTCACHE_VDISKS_SET_ENABLE";


##############################################################################
#
#               Public Functions
#
##############################################################################

##############################################################################
=head2 WrtCacheValidateFull function

This function will do a full write cache validation including the following
tasks: DSC Global Cache, DSC Battery, DSC Mirror, DSC VDisks and DSC Cache
In Use.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateFull( $ptrControllers, $enabled );
 
 where: 
        $ptrControllers: Pointer to a list of controller objects
        
        $enabled: Cache value to check for, possible values are
           WRTCACHE_ENABLED
           WRTCACHE_DISABLED.
           
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors
         
=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateFull
{
    trace();
    my ($ptrControllers, $enabled) = @_;

    my $retVal = GOOD;
    my $bInUse;

    #
    # If we are validating caching is enabled, set the "in use" flag to TRUE
    # to indicate cache must be in use, otherwise set the flag to FALSE.
    #
    if ($enabled)
    {
        $bInUse = TRUE;
    }
    else
    {
        $bInUse = TRUE;
    }

    #
    # Validate the global cache settings for the controllers.
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($ptrControllers, $enabled);
    if ($retVal != GOOD) { return $retVal; }

    #
    # Validate the battery state for the controllers
    #
    $retVal = WrtCacheValidateDSCBatteries($ptrControllers);
    if ($retVal != GOOD) { return $retVal; }

    #
    # Validate the mirroring state for the controllers
    #
    $retVal = WrtCacheValidateDSCMirrors($ptrControllers);
    if ($retVal != GOOD) { return $retVal; }

    #
    # Validate the vdisks cache settings for the controllers.
    #
#    $retVal = WrtCacheValidateDSCCacheVDisks($ptrControllers, $enabled);
#    if ($retVal != GOOD) { return $retVal; }

    #
    # Validate the cache is actually being used (TRUE for second parameter
    # tells the validation routine to look for cache in use).
    #
    $retVal = WrtCacheValidateDSCCacheInUse($ptrControllers, $bInUse);
    if ($retVal != GOOD) { return $retVal; }

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateDSCCacheGlobal function

This function will validate the DSC global cache is in the expected state 
  (enabled variable).

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateDSCCacheGlobal( $ptrControllers, $enabled );
 
 where: 
        $ptrControllers: Pointer to a list of controller objects
        
        $enabled: Cache value to check for, possible values are:
           WRTCACHE_ENABLED
           WRTCACHE_DISABLED
           
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors
         
=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateDSCCacheGlobal
{
    trace();
    my ($ptrControllers, $enabled) = @_;

    my $retVal = GOOD;
    my $rc;
    my @controllers;
    my $iController;
    my $controller;
    my $msg;


    #
    # Cast the pointer to the list of controller to the actual list
    # of controllers.
    #
    @controllers = @$ptrControllers;

    #
    # Loop through the controller list and run the validation
    # for each one.
    #
    for ($iController = 0; $iController < scalar(@controllers); $iController++)
    {
        #
        # Get the controller object from the list.
        #
        $controller = $controllers[$iController];

        $rc = WrtCacheValidateCacheGlobal($controller, $enabled);

        #
        # If the validation for this controller failed, set the overall
        # return value to failed.
        #
        if ($rc != GOOD)
        {
            $retVal = ERROR;
        }

    }

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateCacheGlobal function

This function will validate the global cache is in the expected state 
  (enabled variable).

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateCacheGlobal( $controller, $enabled );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $enabled: Cache value to check for, possible values are:
           WRTCACHE_ENABLED
           WRTCACHE_DISABLED
           WRTCACHE_ENABLE_PENDING.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateCacheGlobal
{
    trace();
    my ($controller, $enabled) = @_;

    my $retVal = GOOD;
    my %rspGlobalCache;
    my $msg;
    my $mask;
    my $expected;
    my $timer = 60;     # Countdown timer

    #
    # Mask off the bits we don't care about
    #
    $enabled = $enabled & 0x05;

    #
    # Setup the expected cache value.
    #
    if ($enabled == WRTCACHE_ENABLED)
    {
        $mask = 0x5;
        $expected = 0x1;
    }
    elsif ($enabled == WRTCACHE_DISABLED)
    {
        $mask = 0x5;
        $expected = 0x0;
    }
    elsif ($enabled == WRTCACHE_ENABLE_PENDING)
    {
        $mask = 0x5;
        $expected = 0x4;
    }
    else
    {
        $msg = sprintf "    ====> Invalid cache state test request (0x%x) <====", $enabled;
        logInfo($msg);
        $retVal = ERROR;
    }

    # Delay for 20 secs to get the correct mirror partner info
    DelaySecs(20);

    #
    # Get the global cache information from the controller
    #
    %rspGlobalCache = _WrtCacheGlobalCacheInfo($controller);

    #
    # If the global cache was retrieved successfully continue, otherwise,
    # set the error return value and exit.
    #
    if (%rspGlobalCache)
    {

        while ((($rspGlobalCache{CA_STATUS} & $mask) != $expected) && ($timer != 0))
        {
            DelaySecs(5);
            $timer--;
            logInfo("*** Check CA_STATUS: on both controllers to ensure they match");
            %rspGlobalCache = _WrtCacheGlobalCacheInfo($controller);
            #
            # No response from GCinfo
            #
            if (!%rspGlobalCache) 
            { 
                return ERROR; 
            }
        }

        #
        # Check if the cache is in the correct state and if it is not log
        # an appropriate message and set the error return value.
        #
        if (($rspGlobalCache{CA_STATUS} & $mask) != $expected)
        {
            $msg = sprintf "    ====> Global Cache State not as expected on " .
                            "controller (0x%x), expected: 0x%x, actual: 0x%x <====",
                            $controller->{SERIAL_NUM},
                            $expected,
                            ($rspGlobalCache{CA_STATUS} & $mask);

            logInfo($msg);
            logInfo("    ====> $controller->{HOST}      <====");
            $retVal = ERROR;
        }
            
    }
    else
    {
        $retVal = ERROR;
    }

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateDSCBatteries function

This function will validate the DSC battery states to  make sure they are all in 
  a valid state.  This function will validate both FE and BE battery states and 
  determine if all controllers have good FE and BE batteries.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateDSCBatteries( $ptrControllers );

 where: 
        $ptrControllers: Pointer to a list of controller objects.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateDSCBatteries
{
    trace();
    my ($ptrControllers) = @_;

    my $retVal = GOOD;
    my $rc;
    my @controllers;
    my $iController;
    my $controller;
    my $msg;

    #
    # Cast the pointer to the list of controller to the actual list
    # of controllers.
    #
    @controllers = @$ptrControllers;

    #
    # Loop through the controller list and run the validation
    # for each one.
    #
    for ($iController = 0; $iController < scalar(@controllers); $iController++)
    {
        #
        # Get the controller object from the list.
        #
        $controller = $controllers[$iController];

        $rc = WrtCacheValidateBattery($controller,
                                        WRTCACHE_BAT_FEBE,
                                        WRTCACHE_BAT_GOOD);

        #
        # If the validation for this controller failed, set the overall
        # return value to failed.
        #
        if ($rc != GOOD)
        {
            $retVal = ERROR;
        }
    }

    return $retVal;
}

##############################################################################
=head2 WrtCacheValidateDSCBatteriesDelayed function

This function will validate the DSC battery states to  make sure they are all in 
  a valid state.  This function will validate both FE and BE battery states and 
  determine if all controllers have good FE and BE batteries.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateDSCBatteries( $ptrControllers );

 where: 
        $ptrControllers: Pointer to a list of controller objects.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheWaitForBatteries
{
    trace();
    my ( $coPtr, $minutes ) = @_;

    my $retVal = GOOD;
    my $timer = $minutes * 4;     # Countdown timer

   
    #
    # Wait for batteries to come back (While Charging)
    #
    while (($retVal != GOOD) && ($timer > 0))
    {
        DelaySecs(15);
        $timer--;
        $retVal = WrtCacheValidateDSCBatteries($coPtr);
    }
    
    return $retVal;
}



##############################################################################
=head2 WrtCacheValidateBattery function

This function will validate the battery state for one or both of the batteries. 
  Depending on the current mirroring state of the system the BE battery may be 
  the local battery or the battery of a remote controller.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateBattery( $controller, $battery, $state );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $battery: Battery to check, possible values are:
           WRTCACHE_BAT_FE
           WRTCACHE_BAT_BE
           
        $state: Battery value to check for, possible values are:
           WRTCACHE_BAT_GOOD
           WRTCACHE_BAT_BAD.
        
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateBattery
{
    trace();
    my ($controller, $battery, $state) = @_;

    my $retVal = GOOD;
    my %rspGlobalCache;
    my $msg;
    my $expected = 0x0;

    #
    # Setup the expected cache value.
    #
    if ($state == WRTCACHE_BAT_BAD)
    {
        if ($battery & WRTCACHE_BAT_FE)
        {
            $expected = $expected | 0x1;
        }

        if ($battery & WRTCACHE_BAT_BE)
        {
            $expected = $expected | 0x2;
        }
    }

    #
    # Get the global cache information from the controller
    #
    %rspGlobalCache = _WrtCacheGlobalCacheInfo($controller);

    #
    # If the global cache was retrieved successfully continue, otherwise,
    # set the error return value and exit.
    #
    if (%rspGlobalCache)
    {
        #
        # Check the current battery state versus the expected state and if
        # it does not match log a message and setup the error return value.
        #
        if (($rspGlobalCache{CA_BATTERY} & $battery) != $expected)
        {
            $msg = sprintf "    ====> Battery State(s) not as expected on " .
                            "controller (0x%x), expected: 0x%x, actual: 0x%x <====",
                            $controller->{SERIAL_NUM},
                            $expected,
                            ($rspGlobalCache{CA_BATTERY} & $battery);

            logInfo($msg);
            $retVal = ERROR;
        }
    }
    else
    {
        return ERROR;
    }

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateDSCMirrors function

This function will validate the DSC mirror states to make sure they are all in 
  a valid state.  This function will validate all controllers are mirroring to 
  a remote controller if there are multiple controllers and will validated a 
  single controller is mirroring to itself.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateDSCMirrors( $ptrControllers );

 where: 
        $ptrControllers: Pointer to a list of controller objects.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateDSCMirrors
{
    trace();
    my ($ptrControllers) = @_;

    my $retVal = GOOD;
    my $rc;
    my @controllers;
    my $iController;
    my $controller;
    my $mirrorState;
    my $msg;

    #
    # Cast the pointer to the list of controller to the actual list
    # of controllers.
    #
    @controllers = @$ptrControllers;

    #
    # If the controller list contains only one controller assume this is
    # a one way configuration and check to make sure the controller is
    # mirroring localally.  Otherwise, verify all controllers are mirroring
    # to a remote controller.
    #
    if (scalar(@controllers) == 1)
    {
        $mirrorState = WRTCACHE_MIRROR_LOCAL;
    }
    else
    {
        $mirrorState = WRTCACHE_MIRROR_REMOTE;
    }

    #
    # Loop through the controller list and run the validation
    # for each one.
    #
    for ($iController = 0; $iController < scalar(@controllers); $iController++)
    {
        #
        # Get the controller object from the list.
        #
        $controller = $controllers[$iController];

        $rc = WrtCacheValidateMirror($controller, $mirrorState);

        #
        # If the validation for this controller failed, set the overall
        # return value to failed.
        #
        if ($rc != GOOD)
        {
            $retVal = ERROR;
        }
    }

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateMirror function

This function will validate the mirror state of the controller.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateMirror( $controller, $mirror );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $mirror: Mirror state, possible values are
           WRTCACHE_MIRROR_LOCAL
           WRTCACHE_MIRROR_REMOTE.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateMirror
{
    trace();
    my ($controller, $mirror) = @_;

    my $index;
    my $retVal = GOOD;
    my %rspGlobalCache;
    my $msg;
    my $expected = 0x0;

    #
    # Setup the expected cache value.
    #
    if ($mirror == WRTCACHE_MIRROR_LOCAL)
    {
        $expected = 0x0;
    }
    else
    {
        $expected = 0x8;
    }

    #
    # Get the global cache information from the controller
    #
    %rspGlobalCache = _WrtCacheGlobalCacheInfo($controller);

    #
    # If the global cache was retrieved successfully continue, otherwise,
    # set the error return value and exit.
    #
    if (%rspGlobalCache)
    {
        #
        # Check the current battery state versus the expected state and if
        # it does not match log a message and setup the error return value.
        #
        if (($rspGlobalCache{CA_STATUS} & 0x8) != $expected)
        {
            $msg = sprintf "    ====> Mirror State not as expected on " .
                            "controller (0x%x), expected: 0x%x, actual: 0x%x <====",
                            $controller->{SERIAL_NUM},
                            $expected,
                            ($rspGlobalCache{CA_STATUS} & 0x8);

            logInfo($msg);
            $retVal = ERROR;
        }
    }
    else
    {
        $retVal = ERROR;
    }

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateDSCCacheVdisks function

This function will validate the cache for all the virtual disks in the DSC are 
  in the expected state (enabled variable).  This function will locate
  the master controller and use it for the validation.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateDSCCacheVdisks( $ptrControllers, $enabled );

 where: 
        $ptrControllers: Pointer to a list of controller objects.
        
        $enabled: Cache value to check for, possible values are
           WRTCACHE_ENABLED
           WRTCACHE_DISABLED.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateDSCCacheVDisks
{
    trace();
    my ($ptrControllers, $enabled) = @_;

    my $retVal = GOOD;
    my @controllerList;
    my $masterIndex;
    my $masterController;

    #
    # Get the list of controllers
    #
    @controllerList = @$ptrControllers;

    #
    # Attempt to locate the index of the master controller in the list
    # of controller objects.
    #
    $masterIndex = TestLibs::IntegCCBELib::FindMaster($ptrControllers);

    #
    # If the master could not be found, return an error.
    #
    if ( $masterIndex == INVALID ) 
    { 
        logInfo("    ====> Unable to identify the master controller <====");
        return ERROR; 
    }

    #
    # The master was found so get the controller object for that controller
    #
    $masterController = $controllerList[$masterIndex];  

    #
    # Validate the cache settings
    #
    $retVal = WrtCacheValidateCacheVDisks($masterController, $enabled);

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateCacheVDisks function

This function will validate the cache for all the virtual disks in the DSC are 
  in the expected state (enabled variable).

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateCacheVDisks($controller, $enabled);

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $enabled: Cache value to check for, possible values are:
           WRTCACHE_ENABLED
           WRTCACHE_DISABLED

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateCacheVDisks
{
    trace();
    my ($controller, $enabled) = @_;

    my $retVal = GOOD;
    my $rc;
    my %vdisks;
    my $ptrVDiskInfo;
    my %vdiskInfo;
    my $i;

    #
    # Request all the information for all the virtual disks in the system.
    #
    %vdisks = $controller->virtualDisks();

    #
    # If the request failed, return an error.
    #
    if (!%vdisks)
    {
        logInfo("    ====> Failed to get response from virtualDisks <====");
        return ERROR;
    }

    #
    # If the request failed, return an error.
    #
    if ($vdisks{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get virtual disks information) <====");
        PrintError(%vdisks);
        return ERROR;
    }

    #
    # Loop through each of the virtual disks and check its cache state
    #
    for ($i = 0; $i < $vdisks{COUNT}; $i++)
    {
        #
        # Get a pointer to the virtual disk information for this particular
        # virtual disk from the overall VDISKS hash.
        #
        $ptrVDiskInfo = $vdisks{VDISKS}[$i];

        #
        # Validate the cache settings for this virtual disk, make sure
        # the pointer to the virtual disk information is passed, otherwise
        # the function would again retrieve the information.
        #
        $rc = WrtCacheValidateCacheVDisk($controller,
                                            $vdisks{VDISKS}[$i]{VID},
                                            $enabled,
                                            $ptrVDiskInfo);
        
        #
        # If the cache was not correct, signal an overall error for this
        # validation routine but continue checking the rest of the virtual
        # disks in the system.
        #
        if ($rc == ERROR)
        {
            $retVal = ERROR;
        }
    }

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateCacheUnchanged function

This function will handle comparison of the initial cache state (from mirror data)
  to the current write cache state to ensure the write cache is unchanged.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateCacheVDisks($coPtr, $mirrorDataPtr,);

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.
                     
        $mirrorDataPtr: Pointer to the initial state of the DSC.
       
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateCacheUnchanged
{
    trace();
    my ($coPtr, $mirrorDataPtr) = @_;

    my $master;
    my $retVal;
    my %vdisksCurrent;
    my $ptrVDiskInfo;
    my $i;
    my $gcStatusOriginal;
    my $numVdisks;
    my $vdiskCacheState;
    my %mirrorData;
    my @coList;
    my $globalCacheFlag = 0;
    my $vdiskCacheFlag = 0;

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    @coList = @$coPtr;         # recreate the controller array

    #
    # Request information for all the virtual disks in the system.
    #
    %vdisksCurrent = $coList[$master]->virtualDisks();

    if ( ! %vdisksCurrent  )
    {
        logInfo("    ====> Failed to get response from vdisks <====");
        return ERROR;
    }

    if ($vdisksCurrent{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get vdisks <====");
        TestLibs::IntegCCBELib::PrintError(%vdisksCurrent);
        return ERROR;
    }

    #
    # If pointer is valid
    #
    if ( $mirrorDataPtr )
    {
        %mirrorData = %$mirrorDataPtr;
        
        #
        # Capture original global write cache state
        #
        $gcStatusOriginal = $mirrorData{GLOBALCACHEINFO}{CA_STATUS} & 0x05;

        #
        # Compare to current global write cache state
        #
        $retVal = WrtCacheValidateCacheGlobal($coList[$master], $gcStatusOriginal);
        if ( $retVal != GOOD )
        {
            $globalCacheFlag = 1;
        }

        #
        # Compare original vdisks write cache states
        #
        $numVdisks = $mirrorData{VDISKS}{COUNT};

        for($i = 0; $i < $numVdisks; $i++)
        {
            #
            # Capture original vdisk write cache state
            #
            $vdiskCacheState = $mirrorData{VDISKS}{VDISKS}[$i]{ATTR} & 0x0100;
        
            #
            # Get a pointer to the current information for this vdisk
            #
            $ptrVDiskInfo = $vdisksCurrent{VDISKS}[$i];

            #
            # Compare to original vdisk cache state
            #
            $retVal = WrtCacheValidateCacheVDisk($coList[$master],
                                                 $i, 
                                                 $vdiskCacheState, 
                                                 $ptrVDiskInfo);
            if ( $retVal != GOOD )
            {
                $vdiskCacheFlag = 1;
            }

        }

    }
    
    if(($globalCacheFlag == 1) || ($vdiskCacheFlag == 1)) 
    {
        logInfo("Global and/or vdisk write cache have changed");
        return (ERROR);
    }


    logInfo("Global and Vdisk write cache is unchanged");
    logInfo("");

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateCacheVdiskList function

This function will validate the cache for the given list of virtual disks
  in the DSC are in the expected state (enabled variable).

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateCacheVdiskList( $controller, $enabled, $ptrVDiskList );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $enabled: Cache value to check for, possible values are:
           WRTCACHE_ENABLED
           WRTCACHE_DISABLED
           
        $ptrVDiskList: Pointer to an array of virtual disk identifiers.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateCacheVDiskList
{
    trace();
    my ($controller, $enabled, $ptrVDiskList) = @_;

    my $retVal = GOOD;
    my $rc;
    my @vdiskList;
    my $i;

    #
    # Get a list of virtual disks
    #
    @vdiskList = @$ptrVDiskList;

    #
    # Check for empty array (if empty .. nothing to do)
    #
    if(scalar(@vdiskList == 0))
    {
        logInfo("Empty vdisk list, nothing to verify");
        return GOOD;
    }

    #
    # Check for first location INVALID
    #
    if($vdiskList[0] eq INVALID)
    {
        logInfo("    ====> vdiskList is invalid <====");
        return INVALID;
    }

    #
    # verify vdisk cache on/off
    #
    for($i = 0; $i < scalar(@vdiskList); $i++)
    {
        $rc = WrtCacheValidateCacheVDisk($controller,
                                            $vdiskList[$i],
                                            $enabled,
                                            0);
        
        #
        # If the cache was not correct, signal an overall error for this
        # validation routine but continue checking the rest of the virtual
        # disks in the system.
        #
        if ($rc == ERROR)
        {
            $retVal = ERROR;
        }
    }

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateCacheVDisk function

This function will validate the cache for the given virtual disk (vid or virtual 
  disk information pointer) is in the expected state (enabled variable).

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateCacheVDisk( $controller, $vid, $enabled, $ptrVDiskInfo );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $vid: Virtual Disk Identifier, this value is used if the virtual disk 
              pointer is not passed in.
              
        $enabled: Cache value to check for, possible values are:
           WRTCACHE_ENABLED
           WRTCACHE_DISABLED
           
        $ptrVDiskInfo: Pointer to the virtual disk information to use instead
                       of retrieving the data from the controller.  Pass 0 if
                       you do not want this pointer used.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateCacheVDisk
{
    trace();
    my ($controller, $vid, $enabled, $ptrVDiskInfo) = @_;

    my $retVal = GOOD;
    my $msg;
    my %vdiskInfo;
    my $expected;

    #
    # Setup the expected cache value.
    #
    if ($enabled)
    {
        $expected = 0x100;
    }
    else
    {
        $expected = 0x0;
    }

    #
    # If the user passed in a pointer to some virtual disk information
    # we will use that information.  Otherwise request the virtual disk
    # information from the controller.
    #
    if ($ptrVDiskInfo != 0)
    {
        %vdiskInfo = %$ptrVDiskInfo;
    }
    else
    {
        %vdiskInfo = $controller->virtualDiskInfo($vid);
    }

    #
    # If we don't have virtual disk information we can't continue.
    #
    if (!%vdiskInfo)
    {
        logInfo("    ====> Failed to get response from rspVDisks <====");
        return ERROR;
    }

    #
    # If the virtual disk information has a bad status we can't continue.
    #
    if ($vdiskInfo{STATUS_MRP} != PI_GOOD)
    {
        logInfo("    ====> Unable to get virtual disk information <====");
        PrintError(%vdiskInfo);
        return ERROR;
    }

    #
    # Everything looks good so far, now check the cache value.  The cache
    # value is a bit in the attributes field so "AND" the attribute with the
    # cache bit (0x100) and compare the result against the expected value.
    # If the results don't match log a message and set an error return value.
    #
    if (($vdiskInfo{ATTR} & 0x100) != $expected)
    {
        $msg = sprintf "    ====> Virtual Disk (%d) Cache State not as expected, " .
                        "expected: 0x%x, actual: 0x%x <====",
                        $vid,
                        $expected,
                        ($vdiskInfo{ATTR} & 0x100);

        logInfo($msg);

        $retVal = ERROR;
    }

    return $retVal;
}


##############################################################################
=head2 WrtCacheValidateDSCCacheInUse function

This function will validate the cache is actually being used.  The "in use"
is determined by retrieving the global cache information and checking that
the free cache tags is different than the total number of cache tags.  If
this is the case the controller is considered to be using write cache.  This
function will loop for approximately 30 seconds or until all controllers are
shown to be in the correct state before exiting.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheValidateDSCCacheInUse($ptrControllers);

 where: 
        $ptrControllers: Pointer to a list of controller objects.
        
        $bInUse: Flag indicated whether cache should be checked for
        "in use" or "free", TRUE indicates "in use", FALSE indicates "free".

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheValidateDSCCacheInUse
{
    trace();
    my ($ptrControllers, $bInUse) = @_;

    my $retVal;
    my @controllers;
    my $iController;
    my $controller;
    my %rspGlobalCache;
    my $msg;
    my $counter = 30;
    my @inUse;

    #
    # Cast the pointer to the list of controller to the actual list
    # of controllers.
    #
    @controllers = @$ptrControllers;

    #
    # Initialized the "inUse" array to the correct value depending on what
    # we are testing for.
    #
    for ($iController = 0; $iController < scalar(@controllers); $iController++)
    {
        $inUse[$iController] = !$bInUse;
    }

    #
    # Assume all controllers are set opposite of what we are looking for
    # and set the return value to error to indicate that.  This is used to
    # allow the loop to execute at least once.
    #
    $retVal = ERROR;

    #
    # Loop while we still have a counter value and we have not seen that
    # all controllers are in the desired state (return value equals ERROR).
    #
    while ($counter > 0 && $retVal == ERROR)
    {
        #
        # Assume all controller are now correct unless we see otherwise.
        #
        $retVal = GOOD;

        #
        # Loop through the controller and determine if the cache is being
        # used.
        #
        for ($iController = 0; $iController < scalar(@controllers); $iController++)
        {
            #
            # If this controller is already known to be in the correct state
            # then skip it and go to the next controller.
            #
            if (($bInUse && $inUse[$iController] != 0) ||
                (!$bInUse && $inUse[$iController] == 0))
            {
                next;
            }

            #
            # Get the controller object from the list.
            #
            $controller = $controllers[$iController];

            #
            # Get the global cache information from the controller
            #
            %rspGlobalCache = _WrtCacheGlobalCacheInfo($controller);

            if (%rspGlobalCache)
            {
                #
                # Save the difference between the total number of tags
                # and the currently free number of tags.
                #
                $inUse[$iController] = $rspGlobalCache{CA_NUMTAGS} -
                                        $rspGlobalCache{CA_TAGSFREE};

                #
                # If the free cache tags equals the total number of cache
                # tags, the controller is not currently using cache.  Setup
                # the return code correctly based on if cache is supposed to
                # be used or not.
                #
                if ($inUse[$iController] == 0)
                {
                    #
                    # If the controller is suppose to be using cache set
                    # the error return since it is currently not using cache.
                    #
                    if ($bInUse)
                    {
                        $retVal = ERROR;
                    }
                }
                else
                {

                    #
                    # If the controller is not suppose to be using cache set
                    # the error return since it is currently using cache.
                    #
                    if (!$bInUse)
                    {
                        $retVal = ERROR;
                    }
                }
            }
        }

        #
        # If the all the controllers are not in the correct state, decrement
        # the loop counter, sleep for a second and then continue.
        #
        if ($retVal == ERROR)
        {
            #
            # Decrement the loop counter
            #
            $counter--;

            #
            # Sleep for one second
            #
            sleep(1);
        }
    }

    if ($retVal == ERROR)
    {
        $msg = sprintf "    ====> Write Cache In Use not as expected (0x%x) <====",
                        $bInUse;

        logInfo($msg);
    }

    return $retVal;
}


##############################################################################
=head2 WrtCacheControl function

This function will enable or disable all global and vdisk write cache.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheControl( $controller, $request );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $request: The operation requested, possible values are:
           WRTCACHE_ENABLED
           WRTCACHE_DISABLED
                                                                                                                                    
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheControl
{
    trace();
    my ($controller, $request) = @_;

    my $retVal = GOOD;
    my $globalRequest;
    my $vdisksRequest;
    
    
    if($request eq WRTCACHE_ENABLED)
    {
        $globalRequest = WRTCACHE_GLOBAL_SET_ENABLE;
        $vdisksRequest = WRTCACHE_VDISKS_SET_ENABLE;
    }
    elsif($request eq WRTCACHE_DISABLED)
    {
        $globalRequest = WRTCACHE_GLOBAL_SET_DISABLE;
        $vdisksRequest = WRTCACHE_VDISKS_SET_DISABLE;
    }
    else
    {
        logInfo("    ====> INVALID request in WrtCacheControl ($request) <====");
        logInfo("    ====> request = $request                            <====");
        return INVALID;
    }
    
    #
    # control global write cache
    #
    $retVal = WrtCacheControlGlobal($controller, $globalRequest);

    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed while controlling global write cache <====");
        logInfo("    ====> $controller->{HOST} <====");
        logInfo("    ====> globalRequest = $globalRequest <====");

        return (ERROR);
    }

    #
    # control all vdisk write cache
    #
    $retVal = WrtCacheControlVdisksAll($controller, $vdisksRequest);

    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed while controlling vdisks write cache <====");
        logInfo("    ====> $controller->{HOST} <====");
        logInfo("    ====> vdisksRequest = $vdisksRequest <====");
        return (ERROR);
    }

    return $retVal;
}


##############################################################################
=head2 WrtCacheControlGlobal function

This function will enable or disable global cache

=cut

=over 1

=item Usage:

 my $rc = WrtCacheControl( $controller, $request );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $request: The operation requested, possible values are:
           WRTCACHE_GLOBAL_SET_ENABLE
           WRTCACHE_GLOBAL_SET_DISABLE

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheControlGlobal
{
    trace();
    my ($controller, $request) = @_;

    my %rsp;
    my $globalRequest = WRTCACHE_GLOBAL_SET_ENABLE_TEXT;
    my $doAgain = 1;
    my $retryCount = 5;


    if($request == WRTCACHE_GLOBAL_SET_DISABLE)
    {
        $globalRequest = WRTCACHE_GLOBAL_SET_DISABLE_TEXT;
    }
    
    #
    # Turn on/off globalcache
    #
    logInfo("");
    logInfo("Controlling global write cache");
    logInfo("globalRequest is: $globalRequest");
    logInfo("");


    #
    # While GC is in a "pending" state
    #
    while ($doAgain ==1)
    {
        
        #
        # Enable/disable GC based on request
        #
        %rsp = $controller->globalCacheSet($request);
    

        #
        # If no response from the command
        #
        if ( ! %rsp  )
        {
            logInfo("    ====> Failed to get response from globalCacheSet <====");
            logInfo("    ====> $controller->{HOST} <====");
            return ERROR;
        }
    
        
        #
        # Get set to break out of while loop
        #
        $doAgain = 0;

        # 
        # If we don't get a good response
        #
        if ($rsp{STATUS} != PI_GOOD)
        {
            #
            # If the response status is NOT "pending"
            #
            if($rsp{STATUS} != 0x04) 
            {
                logInfo("    ====> Unable to update global caching <====");
                logInfo("    ====> $controller->{HOST} <====");
                PrintError(%rsp);
                return ERROR;
            }
            else    # statis is 0x04 (ie "pending")
            {
                #
                # Retry if there are more retries available 
                #
                if ( $retryCount-- > 0 )
                {
                    print "retrying command\n";
                    $doAgain = 1;
                }
                #
                # We are out of retries
                #
                else
                {
                    logInfo("    ====> Unable to update global caching <====");
                    logInfo("    ====> $controller->{HOST} <====");
                    PrintError(%rsp);
                    return ERROR;
                }
            }
        }
    }
    return GOOD;
}


##############################################################################
=head2 WrtCacheControlVdisksAll function

This function will enable or disable write cache on all vdisks.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheControlVdisksAll( $controller, $request );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $request: The operation requested, possible values are:
           WRTCACHE_VDISKS_SET_ENABLE
           WRTCACHE_VDISKS_SET_DISABLE

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheControlVdisksAll
{
    trace();
    my ($controller, $request) = @_;

    my $retVal = GOOD;
    my @vdiskListArray;
    my $vdisksRequest = WRTCACHE_VDISKS_SET_ENABLE_TEXT;

    if($request == WRTCACHE_DISABLED)
    {
        $vdisksRequest = WRTCACHE_VDISKS_SET_DISABLE_TEXT;
    }
    
    #
    # Get a list of virtual disks (Displays list to screen)
    #
    @vdiskListArray = TestLibs::IntegCCBELib::GetVdiskList($controller);

    #
    # Check for first location INVALID
    #
    if($vdiskListArray[0] eq INVALID)
    {
        logInfo("    ====> vdiskList is INVALID <====");
        return INVALID;
    }

    $retVal = WrtCacheControlVdisksMultiple($controller,
                                            $request,
                                            \@vdiskListArray);

    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed during WrtCacheControlVdisksMultiple <====");
        logInfo("    ====> $controller->{HOST}                         <====");
        logInfo("    ====> vdisksRequest = $vdisksRequest              <====");
        return (ERROR);
    }
                
    
    return $retVal;
}


##############################################################################
=head2 WrtCacheControlVdisksSingle function

This function will enable or disable write cache on a single vdisk.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheControlVdisksSingle( $controller, $request, $vid );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $request: The operation requested, possible values are:
           WRTCACHE_VDISK_SET_ENABLE
           WRTCACHE_VDISK_SET_DISABLE.
           
        $vid: The Virtual Disk Identifier.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheControlVdisksSingle
{
    trace();
    my ($controller, $request, $vid) = @_;

    my %rsp;

    #
    # turn on/off vdisk cache
    #
    %rsp = $controller->virtualDiskSetCache($vid, $request);

    if ( ! %rsp  )
    {
        logInfo("    ====> Failed to get response from virtualDiskSetCache <====");
        logInfo("    ====> $controller->{HOST} <====");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Failed to enable cache on Vdisk $vid <====");
        logInfo("    ====> $controller->{HOST} <====");
        
        PrintError(%rsp);

        return ERROR;
    }
    
    return GOOD;
}


##############################################################################
=head2 WrtCacheControlVdisksMultiple function

This function will enable or disable write cache on vdisks supplied by a pointer 
 to an array of vdisk vid's.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheControlVdisksMultiple( $controller, $request, $ptrVDisks );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $request: The operation requested, possible values are:
           WRTCACHE_VDISKS_SET_ENABLE
           WRTCACHE_VDISKS_SET_DISABLE
           
        $ptrVDisks: Pointer to an array of virtual disks to use.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheControlVdisksMultiple
{
    trace();
    my ($controller, $request, $ptrVDisks) = @_;

    my $retVal = GOOD;
    my @vdiskListArray;
    my $index;
    my $vdisksRequest = WRTCACHE_VDISKS_SET_ENABLE_TEXT;

    if($request == WRTCACHE_DISABLED)
    {
        $vdisksRequest = WRTCACHE_VDISKS_SET_DISABLE_TEXT;
    }

    #
    # Get a list of virtual disks (What about checking if the $vid's are valid)
    #
    @vdiskListArray = @$ptrVDisks;

    #
    # Check for empty array (if empty .. nothing to do)
    #
    if(scalar(@vdiskListArray == 0))
    {
        logInfo("Empty vdisk list, nothing to verify");
        return GOOD;
    }

    #
    # Check for first location INVALID (?????)
    #
    if($vdiskListArray[0] eq INVALID)
    {
        logInfo("    ====> vdiskList is invalid <====");
        return INVALID;
    }

    logInfo("Controlling vdisk write cache");
    logInfo("vdisksRequest is: $vdisksRequest");
    logInfo("vdisks involved: @vdiskListArray");

    #
    # turn on/off vdisk cache
    #
    for($index = 0; $index < scalar(@vdiskListArray); $index++)
    {
        $retVal = WrtCacheControlVdisksSingle($controller,
                                                $request,
                                                $vdiskListArray[$index]);
        
        #
        # If the cache control request failed we do not want to continue
        # to make any more changes.
        #
        if ($retVal == ERROR)
        {
            logInfo("    ====> Failed inside WrtCacheControlVdisksMultiple <====");
            logInfo("    ====> $controller->{HOST}                         <====");
            logInfo("    ====> vdisksRequest = $vdisksRequest              <====");
            last;
        }
    }
    
    logInfo("");

    return $retVal;
}


##############################################################################
=head2 WrtCacheBatteryHealth function

This function will change the battery health for a given controller.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheBatteryHealth( $controller, $request );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $request: Operation requested, possible values are:
           WRTCACHE_BAT_GOOD
           WRTCACHE_BAT_BAD

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheBatteryHealth
{
    trace();
    my ($controller, $request) = @_;

    my %rsp;
    my $msg;

    if ($request != WRTCACHE_BAT_GOOD && $request != WRTCACHE_BAT_BAD)
    {
        $msg = sprintf "    ====> Invalid battery health request (0x%x) <====", $request;

        logInfo($msg);
        return INVALID;
    }

    #
    # Set battery good/bad
    #
    %rsp = $controller->batteryHealthSet(0, $request);

    if ( ! %rsp  )
    {
        logInfo("    ====> Failed to get response from batteryHealthSet <====");
        logInfo("    ====> $controller->{HOST} request = $request <====");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to update battery health <====");
        logInfo("    ====> $controller->{HOST} <====");
        PrintError(%rsp);
        return ERROR;
    }

    return GOOD;
}


##############################################################################
=head2 WrtCacheDisplayGlobalCacheInfo function

This function will log the global cache information for a given controller.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheDisplayGlobalCacheInfo( $controller );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheDisplayGlobalCacheInfo
{
    trace();
    my ($controller) = @_;

    my %rsp;
    my $msg;

    %rsp = _WrtCacheGlobalCacheInfo($controller);
    if (!%rsp)
    {
        logInfo("    ====> Failed to retrieve global cache information <====");
        logInfo("    ====> $controller->{HOST} <====");
        return (ERROR);
    }

    $msg = $controller->displayGlobalCacheInfo(%rsp);
    logInfo($msg);

    return GOOD;
}


##############################################################################
=head2 WrtCacheDisplayTimeLine function

This function will display select global cache statistics in a timeline for a  
  specific controller.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheDisplayTags( $batteryStatsPtr, $timeLine, $cNode, $gcStatus,  
           $gcBattery, $gcStopCount, $gcTagsDirty, $gcTagsResident );

 where: 
        $batteryStatsPtr: References a hash of the battery stats for $cNode
        
        $timeLine: Point in time of the statistics snapshot
         
        $cNode: The controller
        
        $gcStatus: Global cache status
        
        $gcBattery: Global cache battery status
        
        $gcStopCount: Global cache stop count
        
        $gcTagsDirty: Global cache dirty tags
        
        $gcTagsResident: Global cache resident tags
        
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This function assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheDisplayTimeLine
{
    my ( $batteryStatsPtr, $timeLine, $cNode, $gcStatus, $gcBattery, $gcStopCount, 
          $gcTagsDirty, $gcTagsResident ) = @_;

    my %batteryStats;
    my $totalTags;
    my $msg = "";
    
    # TimeLine
    $msg = sprintf("TL:%5s ", $timeLine);
    
    # Controller
    $msg .= sprintf("CN:%2d ", $cNode);    
    
    # GlobalCache status
    $msg .= sprintf("GS:0x%01x ", $gcStatus);
    
    # GlobalCache battery status
    $msg .= sprintf("BS:0x%01x ", $gcBattery);
    
    # GlobalCache stopCount
    $msg .= sprintf("SC:%1d ", $gcStopCount);
    
    #
    # If we have a valid pointer (diplay the battery statistics)
    #
    if ( $batteryStatsPtr )
    {
        %batteryStats = %$batteryStatsPtr;
    
        # Battery Count    
        $msg .= sprintf( "BC:%02x ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_COUNT} );
    
        # Battery 1 Status   
        $msg .= sprintf( "B1S:0x%01x ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_1_STATUS} );

        # Battery 1 Voltage
        $msg .= sprintf( "B1V:%4dmV ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_1_VOLTAGE} );
    
        # Battery 1 Charge
        $msg .= sprintf( "B1C:%4d ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_1_CHARGE_PERCENT} );

        # Battery 2 Status   
        $msg .= sprintf( "B2S:0x%01x ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_2_STATUS} );
    
        # Battery 2 Voltage
        $msg .= sprintf( "B2V:%4dmV ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_2_VOLTAGE} );
    
        # Battery 2 Charge
        $msg .= sprintf( "B2C:%4d ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_2_CHARGE_PERCENT} );

        # Battery 3 Status   
        $msg .= sprintf( "B3S:0x%01x ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_3_STATUS} );
    
        # Battery 3 Voltage
        $msg .= sprintf( "B3V:%4dmV ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_3_VOLTAGE} );
    
        # Battery 3 Charge
        $msg .= sprintf( "B3C:%4d ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_3_CHARGE_PERCENT} );

        # Battery 4 Status   
        $msg .= sprintf( "B4S:0x%01x ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_4_STATUS} );
    
        # Battery 4 Voltage
        $msg .= sprintf( "B4V:%4dmV ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_4_VOLTAGE} );
    
        # Battery 4 Charge
        $msg .= sprintf( "B4C:%4d ", 
                          $batteryStats{BUFFER_BOARD_BATTERY_4_CHARGE_PERCENT} );
    }

    #
    # display cache tags
    #
    else
    {
        # GlobalCache dirty tags
        $msg .= sprintf("TD:%5d ", $gcTagsDirty);
    
        # GlobalCache resident tags
        $msg .= sprintf("TR:%5d ", $gcTagsResident);
    
        $totalTags =  $gcTagsDirty + $gcTagsResident;
        #$msg .= sprintf("Total Tags: $totalTags");
        $msg .= sprintf("Total Tags:%5d ", $totalTags);
    }
    
    logInfo($msg);

    return GOOD;
}

##############################################################################
=head2 WrtCacheRestoreCacheState function

This function will display select global cache statistics in a timeline for a  
  specific controller.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheRestoreCacheState( $coPtr, $mirrorDataPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $mirrorDataPtr: Pointer to collected mirror state data.
        
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This function assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheRestoreCacheState
{
    my ( $coPtr, $mirrorDataPtr ) = @_;

    my $master;
    my @coList;
    my $ctlr;
    my $initialGlobalCacheState;
    my $initialVdiskCacheState;
    my $retVal;
    my $numVdisks;
    my $i;
    my %mirrorData;
    
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    @coList = @$coPtr;         # recreate the controller array

    $ctlr = $coList[$master];  # Get master object


    if ( $mirrorDataPtr )
    {
        %mirrorData = %$mirrorDataPtr;
        
        logInfo( "Restoring original write cache state" );
        logInfo("");
    
        #
        # Capture original global write cache state
        #
        $initialGlobalCacheState = $mirrorData{GLOBALCACHEINFO}{CA_STATUS} & 0x05;

        #
        # Restore original global write cache state
        #
        if ($initialGlobalCacheState == 0)
        {
            #
            # disable global write cache
            #
            logInfo("Controlling global write cache");
            logInfo("globalRequest is: WRTCACHE_GLOBAL_SET_DISABLE");
            $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
        }
        else
        {
            #
            # enable global write cache
            #
            logInfo("Controlling global write cache");
            logInfo("globalRequest is: WRTCACHE_GLOBAL_SET_ENABLE");
            $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
        }
        
        #
        # Restore origional vdisks write cache states
        #
        $numVdisks = $mirrorData{VDISKS}{COUNT};

        for($i = 0; $i < $numVdisks; $i++)
        {
            #
            # Capture origional vdisk write cache state
            #
            $initialVdiskCacheState = $mirrorData{VDISKS}{VDISKS}[$i]{ATTR} & 0x0100;
        
            #
            # Restore origional vdisk cache state
            #
            if ($initialVdiskCacheState == 0)
            {
                #
                # Disable vdisk write cache
                $retVal = WrtCacheControlVdisksSingle($ctlr,
                                                      WRTCACHE_VDISKS_SET_DISABLE,
                                                      $i);
                if ( $retVal != GOOD )
                {
                    logInfo("    ====> Failed while disabling vdisk write cache <====");
                    logInfo("    ====> $coList[$master]{HOST} vid = $i          <====");
                    return (ERROR);
                }
                
            }
            else
            {
                #
                # Enable vdisk write cache
                $retVal = WrtCacheControlVdisksSingle($ctlr,
                                                      WRTCACHE_VDISKS_SET_ENABLE,
                                                      $i);
                if ( $retVal != GOOD )
                {
                    logInfo("    ====> Failed while enabling vdisk write cache <====");
                    logInfo("    ====> $coList[$master]{HOST} vid = $i         <====");
                    return (ERROR);
                }
                
            }
        
        }

    }
    logInfo("");

    return GOOD;
}


##############################################################################
=head2 WrtCacheVdisksSelectAllAltRandom function

This function will .

=cut

=over 1

=item Usage:

 my $rc = WrtCacheVdisksSelectAllAltRandom( $controller, $request, $vid );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
        $request: The operation requested, possible values are:
           WRTCACHE_VDISK_SET_ENABLE
           WRTCACHE_VDISK_SET_DISABLE.
           
        $vid: The Virtual Disk Identifier.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheVdisksSelectAllAltRandom
{
    trace();
    my ($coPtr, $vdisksPtr, $vdiskListSelect) = @_;

    my $master;
    my @coList;
    my $ctlr;
    my @vdiskListOn;
    my $vdiskListOnPtr;
    my @vdisks;
    my $numVDDs;
    my $needed;
    my $i;

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    @coList = @$coPtr;         # recreate the controller array

    $ctlr = $coList[$master];  # Get master object
    
    @vdisks = @$vdisksPtr;

    ### Start of ALL, ALT, RANDOM routine

    if ( $vdisks[0] == INVALID )
    {
        logInfo("    ====> Unable to retrieve list of virtual disk identifiers. <====");
        logInfo("    ====> $coList[$master]{HOST}                               <====");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    #
    # Get all vdisks
    #
    if($vdiskListSelect eq "all")
    {
        #
        # do all vdisks TC01
        #
        @vdiskListOn = @vdisks;
        $vdiskListOnPtr = \@vdiskListOn;
    
    }

    #
    # Get every other vdisk
    #
    elsif($vdiskListSelect eq "alt")
    {
        for($i = 0; $i < $numVDDs; $i++)
        {
            #
            # if no remainder ie even (add to vdiskListOn)
            #
            if($i%2 == 0)
            {
                push (@vdiskListOn, $vdisks[$i]);
            }

        }
        $vdiskListOnPtr = \@vdiskListOn;
        
    }

    #
    # Get half the vdisks (randomly)
    #
    elsif($vdiskListSelect eq "random")
    {
        #
        # Turn on half the vdisks (randomly)
        #
        $needed = $numVDDs / 2;    
        @vdiskListOn = GetRandomVdisks( $ctlr, $needed );
        $vdiskListOnPtr = \@vdiskListOn;
    
    }

    else
    {
        #
        # INVALID request
        #
        logInfo("    ====> INVALID request in TC03 (vdiskListSelect = $vdiskListSelect) <====");
        return (INVALID);
    }

    ### End of ALL, ALT, RANDOM routine
    
    return $vdiskListOnPtr;
}


##############################################################################
=head2 WrtCacheTimeLine function

This function builds a Time Line the watches the outstanding cache tags go to zero.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTimeLine( $coPtr, $snPtr, $victim, $maxTimeLineDuration, $displayBatteryStats );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $victim: Controller selected
                
        $maxTimeLineDuration: Maximum amount of time before the timeline gives up
        
        $displayBatteryStats: Flag for getting the battery statistics
        
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.
         GOOD if all tests pass
         ERROR if one or more fails
         INVALID  on other errors

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This function assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub WrtCacheTimeLine
{
    my ( $coPtr, $snPtr, $victim, $maxTimeLineDuration, $displayBatteryStats ) = @_;

    my $startTime;
    my $stopTime;
    my $oldStopTime;
    my $gcTagsDirty;
    my $someTagsDirty;
    my $timePrinted;
    my $gcStatus;
    my $gcBattery;
    my $gcStopCount;
    my $gcTagsResident;
    my $cNode;
    my %gcInfo;
    my $timeLine;
    my $duration = 1;
    my %batteryStats;
    my $batteryStatsPtr;
    my $i;
    my $numControllers;
    my $msg;
    my $retVal;

    my @coList = @$coPtr;         # recreate the controller array


    #
    # Get number of controllers
    #
    $numControllers = scalar(@coList);

    #
    # Ininitialize flag
    #
    if ($displayBatteryStats != 1)
    {
        $displayBatteryStats = 0;
    }


####### Watch cache tags go to zero (below)

    #
    # Capture start time and initialize stop Time
    #
    $startTime = time;
    $stopTime = $startTime;

    logInfo("");
    logInfo("");

    logInfo ("WrtCache time line begin....");
    logInfo("");

    #
    # Set $someTagsDirty to 1 (ensure we enter loop at least once)
    #
    $someTagsDirty = 1;
    
    #
    # Ensure cache is flushed (no cache tags outstanding)
    # while timeout not reached and dirty cache tags outstanding
    #
    while (( ($startTime + $maxTimeLineDuration) > $stopTime ) && ($someTagsDirty > 0))
    {
        $timePrinted = 0;
        $someTagsDirty = 0;

        #
        # loop thru each controller and collect data for the timeline
        #
        for ( $i = 0; $i < $numControllers; $i++ )
        {
            #
            # initialize the data for this controller to defaults
            #
            $gcStopCount = "-";                 # stop count
            $cNode = $$snPtr[$victim] & 0x0f;   # CNC Node
        
            #
            # Initialize global cache status, battery status, stop counts, 
            # dirty tags, and resident tags
            #
            $gcStatus = -1;
            $gcBattery = -1;
            $gcStopCount = -1;
            $gcTagsDirty = -1;
            $gcTagsResident = -1;

            #
            # Capture global cache info to a hash
            #
            %gcInfo = $coList[$victim]->globalCacheInfo();

            if ( ! %gcInfo  )
            {
                logInfo("    ====> Failed to get globalCacheInfo from controller $coList[$victim]{HOST} <====");
            }
            else
            {

                #
                # Capture relevant data
                #
                if ($gcInfo{STATUS} == PI_GOOD)
                {
                    $gcStatus       = $gcInfo{CA_STATUS};
                    $gcBattery      = $gcInfo{CA_BATTERY};
                    $gcStopCount    = $gcInfo{CA_STOPCNT};
                    $gcTagsDirty    = $gcInfo{CA_TAGSDIRTY};
                    $gcTagsResident = $gcInfo{CA_TAGSRESIDENT};
                }
                else
                {
                    logInfo("    ====> Error getting globalCacheInfo from controller $coList[$victim]{HOST} <====");
                    PrintError(%gcInfo);
                }
            }

            if (  $gcTagsDirty > 0 )
            {
                $someTagsDirty += $gcTagsDirty;
            }
        
            #
            # Capture Buffer Board Battery Stats (for this controller)
            #
            $batteryStatsPtr = 0;
            if ($displayBatteryStats != 0)
            {
                %batteryStats = $coList[$i]->statsBufferBoard( 0 );

                if (%batteryStats)
                {
                    if ($batteryStats{STATUS} == PI_GOOD)
                    {
                        $batteryStatsPtr = \%batteryStats;
                    }
                    else
                    {
                        $msg = "    ====> Unable to retrieve buffer board statistics <==== \n";
                        TestLibs::scrub::displayError($msg, %batteryStats);
                    }
                }
                else
                {
                    print "    ====> ERROR: Did not receive a response packet <==== \n";
                }
            
            }
        
            #
            # Backup old stop time, capture this stop time and calculate time line
            #
            $oldStopTime = $stopTime;
            $stopTime = time;
            if ( $timePrinted == 0 )
            {
                $timeLine = sprintf("[%3d]", ($stopTime - $startTime));
                $timePrinted = 1;
            }
            else
            {
                $timeLine = "     ";
            }        
        
            #
            # Print TimeLine
            #
            $retVal = WrtCacheDisplayTimeLine( $batteryStatsPtr, $timeLine, $cNode,  
                                                $gcStatus, $gcBattery, $gcStopCount,
                                                $gcTagsDirty, $gcTagsResident );
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
           
        }

        #
        # Ensure enough time has passed (at least 1 sec between timeLines)
        #
        while(($oldStopTime + $duration) > $stopTime)
        {
            DelaySecs(1);
            $stopTime = time;
        }

    } # end while loop


    logInfo("All cache tags have been flushed (Dirty moved to resident)");

####### Watch cache tags go to zero (above)


    return GOOD;
}
###############################################################################



##############################################################################
#
#               Private Functions
#
##############################################################################

##############################################################################
=head2 _WrtCacheGlobalCacheInfo function

This function will retrieve the global cache information for the given controller.

=cut

=over 1

=item Usage:

 my $rc = _WrtCacheGlobalCacheInfo( $controller );

 where: 
        $controller: For functions that work with a single specific controller, 
                     this is the pointer to that controller object. It is one 
                     of the members of the list that $coPtr points to.
       
=item Returns:

       $rc will be a Global Cache Information hash or undef if the information
         could not be retrieved.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    
=back
=cut
##############################################################################
sub _WrtCacheGlobalCacheInfo
{
    my ($controller) = @_;

    my %rsp;
    my $msg;

    #
    # Get the global cache information from the controller
    #
    %rsp = $controller->globalCacheInfo();

    #
    # If the request for the global cache information failed, log
    # an appropriate message and set the error return value.
    #
    if (!%rsp)
    {
        $msg = sprintf "    ====> Failed to get response to globalCacheInfo " .
                        "from controller (0x%x) <====",
                        $controller->{SERIAL_NUM};
        
        logInfo($msg);
    }
    elsif ($rsp{STATUS} != PI_GOOD)
    {
        $msg = sprintf "    ====> Unable to get global cache information " .
                        "from controller (0x%x) <====",
                        $controller->{SERIAL_NUM};
        
        logInfo($msg);
        PrintError(%rsp);

        undef %rsp;
    }

    return %rsp;
}



###############################################################################
1;   # we need this for a PM


