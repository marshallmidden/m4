#! /usr/bin/perl 
# $Header$
##############################################################################
#  
#   CCBE Integration test library - UE Test Suport Functions
#
#   08/25/2004  XIOtech   Allen Kohlmeyer
#
#   A set of library functions for integration testing. These functions 
#   are for support of UE as well as other tests.
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2004 XIOtech
#
#   For XIOtech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::UETestSupport - Perl functions to support UE Tests

$Id: UETestSupport.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This library contains functions to support testing of simulated user 
errors, unexpected errors, ugly errors, or whatever.   

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

              
        The less significant ones


=cut


#                         
# - what I am
#

package TestLibs::UETestSupport;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
 
use TestLibs::Logging;
# use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
# use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - local Constants used
#



#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 4298 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #


    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        &BELoopPrimitive
                        &DefragMonitor
                        &GetOperationalIPs
                        &GetBELids
                        &IsDefragReallyRunning
                        &LoopPrimUsingList
                        &OrphanedRaidCheck 
                        &OrphanedRaidCheck2
                        
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################


##############################################################################
=head2 IsDefragReallyRunning function

Checks for orhpaned raids. An orphaned raid is a raid whose associated vdisk
is missing. 
=cut

=over 1

=item Usage:

    my $rc = IsDefragReallyRunning($coPtr, $ipPtr, $timeOut );

 where: $coPtr is a pointer to list of controller objects
        $ipPtr is a pointer to a list of operation IP addresses
        $timeout is the number of attempts to try to find running defrags

=item Returns:

       $rc will be INVALID if error
                   ISFRAGMENTED if fragmented but not defrag running
                   NOTFRAGMENTED if not fragmented and no defrag running
                   DEFRAGGING if active defrag was detected


=item Details:

 This function looks at pdisks data on all operational controllers to 
 see if defrag is running. It looks at the MISCSTAT and %REM values to
 determine if defrag is running. It looks at LAS and TAS to see if the 
 drives are fragmented. (Currently a rebuild may also be detected.)
 The function loops until it times out after a specified number of 
 iterations or it finds a pdisk being defragged.
 


=back

=cut

###############################################################################
###############################################################################
#
# Purpose detect if a defrag is running by getting pdisks to see if there 
# is a rebuild state indicated (and %rem). TImes out if no defrag found
#
sub IsDefragReallyRunning
{
    my ($coPtr, $ipPtr, $timeOut ) = @_;

    my $defragging = 0;
    my $fragmented = 0;
    my $ctlr;
    my $match;
    my $ip;
    my $passCount = 0;
    my %pdisks;

    #
    # if not timed out
    #
    while( $passCount <= $timeOut  )    
    {

print "pass # $passCount \n";
        
        #
        #  for each good controller
        #
        for ( $ctlr = 0; $ctlr < scalar(@$coPtr); $ctlr++ )
        {

            $match = 0;
            for ( $ip = 0; $ip < scalar(@$ipPtr); $ip++ )
            {
                if ( $$coPtr[$ctlr]->{HOST} eq $$ipPtr[$ip] )
                {
                    # found it, set flag, done
                    $match = 1;
                    last;
                }
            }

            # controller not in ip list, skip it
            if ( $match == 0 ) { next; }

            #
            # get pdisks
            #

            %pdisks = $$coPtr[$ctlr]->physicalDisks();
            if ( ! %pdisks  )
            {
                logInfo(">>>>>>>> Failed to get response from physicalDisks <<<<<<<<");
                next;
                # return ERROR;
            }
            if ($pdisks{STATUS} != PI_GOOD)
            {
                logInfo(">>>>>>>> Unable to get physicalDisks info <<<<<<<<");
                PrintError(%pdisks);
                next;
                # return ERROR;
            }

            #
            # for each pdisk
            #
            for (my $i = 0; $i < $pdisks{COUNT}; $i++)
            {

                #
                # skip non-data disks 
                #

                if ( CCBEDATATYPE != $pdisks{PDISKS}[$i]{PD_CLASS} )
                {
                    # not data, skip to next pdisk
                    next;
                }


            
                #
                # look at hash to see if we are fragmented
                #

                if ( $pdisks{PDISKS}[$i]{TAS}  > $pdisks{PDISKS}[$i]{LAS} )
                {
                    $fragmented = 1;
                }



                #
                # look at hash to see if a defrag is currently active
                # 0x04 is defrag bit, 0x02 is rebuild bit

                if ( ( 0x06 &  $pdisks{PDISKS}[$i]{PD_MISCSTAT} ) ||
                     ( 0 <  $pdisks{PDISKS}[$i]{PCTREM} ) )

                {
                    # we know we are defragging, we can bail out now
                    # first log something

                    # 
                    # if active defrag, return logging pdisk, ctlr, %rem
                    #
                    $defragging = 1;
                    logInfo("$$ipPtr[$ip] defragging on ".
                            "pdisk $pdisks{PDISKS}[$i]{PD_PID},". 
                            " $pdisks{PDISKS}[$i]{PCTREM} percent ramaining");
                    return DEFRAGGING;

                }
                

            } # end each pdisk



        } # end each controller



        $passCount++;

    } # end not timed out


    #
    # timed out, no defrag found
    #

    if ( $fragmented == 1)
    {
        logInfo("System is fragmented, but no active defrag found");
        return ISFRAGMENTED;
    }
    
    return NOTFRAGMENTED; 


}
###############################################################################
##############################################################################
=head2 GetOperationalIPs function

Gets a list of operational IP addresses.
 
=cut

=over 1

=item Usage:

    my $rc = GetOperationalIPs($coPtr, $master, $destPtr);

 where: $coPtr is a pointer to list of controller objects
        $master is the index to the master controller
        $destPtr is a pointer to the destination list

=item Returns:

       $rc will be INVALID, GOOD or ERROR. The user should verify correct
           operation by reviewing the logs.

=item Details:

 This function looks at vcginfo on the master controller and extracts
 a list of the operation IP addresses. The resulting list is placed in 
 caller specified location. If the master is not supplied (value is
 either INVALID or undefined) then the function will determine the master
 for itself. (If the master is supplied, this function will create no log
 entries if successful. Getting the master will generate log entries.)
 


=back

=cut

###############################################################################
sub GetOperationalIPs
{
    my ($coPtr, $master, $destPtr) = @_;

    my $getMaster = 0;
    my @opIPs;
    my %vcginfo;
    my $j;

    #
    # if master was not supplied, we need to get it
    #
    if (defined($master))
    {
        $getMaster = 1;
    }
    elsif ($master == INVALID)
    {
        $getMaster = 1;
    }

    if ( $getMaster == 1 )
    {
        $master = FindMaster($coPtr);
    }

    if ($master == INVALID)
    {
        # still no master, fail
        logInfo("GetOperationalIPs: do not have a master");
        return ERROR;
    }
    
    # 
    # get vcginfo from master, us it to identify operational controllers
    #
    %vcginfo = $$coPtr[$master]->vcgInfo(0);

    if ( ! %vcginfo  )
    {
        logInfo(">>>>>>>> Failed to get vcginfo from master <<<<<<<<");
        return (ERROR);
    }

    if (%vcginfo)
    {
        if ($vcginfo{STATUS} == PI_GOOD)
        {
            
            # check each controller listed
            for ( $j = 0; $j < $vcginfo{VCG_MAX_NUM_CONTROLLERS}; $j++ )   
            {
                if ( $vcginfo{CONTROLLERS}[$j]{FAILURE_STATE} == FD_STATE_OPERATIONAL )     
                {
                    # save the IP address of the good controller
                    push( @opIPs, $vcginfo{CONTROLLERS}[$j]{IP_ADDRESS} );

                }
            }
            
            #
            # give data to caller
            #
            if (defined ($destPtr))
            {
                if ($destPtr > 0 )
                {
                    @$destPtr = @opIPs;
                }
            }

            
            return GOOD;
        }
        else
        {
            logInfo(">>>>>>>> Error getting vcginfo from master <<<<<<<<");
            PrintError(%vcginfo);
        }
    }
    
    return ERROR;

}

###############################################################################
##############################################################################
=head2 DefragMonitor function

Monitor defrag state after an event. Will wait until times out or finds defrag
is running. Logs results.
 
=cut

=over 1

=item Usage:

    my $rc = DefragMonitor($coPtr, $ipPtr, $timeout);

 where: $coPtr is a pointer to a list of controller objects
        $ipPtr is a pointer to a list of IP addresses
        $timeout is how long to run

=item Returns:

       $rc will be INVALID, GOOD or ERROR. The user should verify correct
           operation by reviewing the logs.

=item Details:

 This function basically waits until a defrag is detected or it times out.
 The purpose is to help characterize what happens wrt defrag after some 
 event.
 


=back

=cut

###############################################################################
sub DefragMonitor
{
    my ($coPtr, $ipPtr, $timeout) = @_;

    my $getMaster = 0;
    my @opIPs;
    my %vcginfo;
    my $j;
    my $start;
    my $ret;


    $start = time();

    #
    # Log start of function
    #
    logInfo(" DefragMonitor begins at ".scalar localtime($start) );

    #
    # While not timed out
    #

    $start += $timeout;

    while ( $start > time() )
    {
        #
        # Check to see if defrag is running
        #
        $ret = IsDefragReallyRunning($coPtr, $ipPtr, 5 );

        #
        # If running, log message and exit
        #
        if ( $ret == DEFRAGGING )
        {
            logInfo(" DefragMonitor detected defrag is running at ". scalar localtime());
            return GOOD;
        }

        # $timeout--;

    } # end while

    #
    # Timed out, log the fact and return
    #

    logInfo(" DefragMonitor timed out, defrag not detected. Time = ". scalar localtime());

    return ERROR;

}
##############################################################################



##############################################################################
=head2 GetBELids function

Checks for orhpaned raids. An orphaned raid is a raid whose associated vdisk
is missing. 
=cut

=over 1

=item Usage:

    my $rc = GetBELids($coPtr, \@lids);

 where: $ctlr is a controller object
        \@lids is a pointer to the output array 

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Details:

 The function checks each controller in the vcg and gets information about
 loop id of the BE devices. The output array is an array of hashes where each
 hash has the port, lid and controller index.

 The function returns good if it was able to collect the data. ERROR or 
 INVLAID will be returned if the function cannot get the whole list. Note:
 errors on ports where cards are not installed are handled in a benign manner.
 


=back

=cut

###############################################################################
# Gets an array with LIB, PORT and controller info
###############################################################################
sub GetBELids
{
    my ( $coPtr, $lidPtr ) = @_;
    # $ret = GetBELids($coPtr, \@lids);

    my $oIdx;
    my $port;
    my %pdisks;
    my %bays;
    my %devList;
    my $ret;
    my $retVal = GOOD;
    my $device;
    my @lidList;
    my $lidData;
    my $i;
    my $lIdx = 0;

    my @coList = @$coPtr;

    #
    # for each controller object
    #
    for ( $oIdx = 0; $oIdx < scalar( @coList); $oIdx++ )
    {

        #
        # if the object is valid and controller available
        #

        if ( GOOD == IsControllerAlive( $coList[$oIdx] ) )
        { 

            #
            # get pdiskinfo ( need WWNs )
            #
            %pdisks = $coList[$oIdx]->physicalDisks();
        
            if (! %pdisks )        
            {
                logInfo (">>>>>>>>>> no response from pdisks in GetBELids <<<<<<<<<<<");
                $retVal = ERROR;
                next;
            }

            if ( $pdisks{STATUS} != PI_GOOD )
            {
                logInfo (">>>>>>>>>> Error from pdisks in GetBELids <<<<<<<<<<<");
                PrintError(%pdisks);
                $retVal = ERROR;
                next;
            }
            

            #
            # get bay info  ( need WWNs )
            # 

            %bays = $coList[$oIdx]->diskBays();
        
            if (! %pdisks )        
            {
                logInfo (">>>>>>>>>> no response from diskBays in GetBELids <<<<<<<<<<<");
                $retVal = ERROR;
                next;
            }

            if ( $bays{STATUS} != PI_GOOD )
            {
                logInfo (">>>>>>>>>> Error from diskBays in GetBELids <<<<<<<<<<<");
                PrintError(%bays);
                $retVal = ERROR;
                next;
            }
            

            #
            # for each BE port
            #
            for ( $port = 0; $port < 4; $port++ )
            {

                #
                # Get devicelist for port
                #
                %devList = $coList[$oIdx]->deviceList("BE", $port);

                if ( ! %devList  )
                {
                    logInfo(">>>>>>>> Failed to get device list info <<<<<<<<");
                   $retVal = ERROR;
                    next;
                }

                if (%devList)
                {
                    
                    if ($devList{STATUS} != PI_GOOD)
                    {
                        if ($devList{ERROR_CODE} == 0x36 ) #PI_ERROR_INV_CHAN )   # 0x36
                        {
                            # card not installed, no problem, skip to next
                            # print "   skipping missing card \n";
                            next;

                        }
                        else
                        {
                            logInfo(">>>>>>>> Error getting device list (proc = BE chan = ".$port."  <<<<<<<<");
                            PrintError(%devList);
                            $retVal = ERROR;
                            next;
                        }
                    }
                }




                #
                # for each device
                #
                for ($device = 0; $device < $devList{NDEVS}; ++$device)
                {
                    #     $devList{LIST}[$device]{LID},
                    #     $devList{LIST}[$device]{MST},
                    #     $devList{LIST}[$device]{SST},
                    #     $devList{LIST}[$device]{PORT_ID},
                    #     $devList{LIST}[$device]{PORT_WWN_LO},
                    #     $devList{LIST}[$device]{PORT_WWN_HI},
                    #     $devList{LIST}[$device]{NODE_WWN_LO},
                    #     $devList{LIST}[$device]{NODE_WWN_HI};

                    #
                    # is it a  drive (by matching WWNs)
                    #
                    for ( $i = 0; $i <  $pdisks{COUNT} ; $i++ )
                    {
                        if (( $devList{LIST}[$device]{NODE_WWN_LO} ==  $pdisks{PDISKS}[$i]{WWN_LO} ) &&
                            ( $devList{LIST}[$device]{NODE_WWN_HI} ==  $pdisks{PDISKS}[$i]{WWN_HI} ) )
                        {


                            #
                            # WWN has matched
                            # add to the array ( lid, port, ctlr)
                            #

                            $lidData = {};

                            $lidData->{LID}  = $devList{LIST}[$device]{LID}; # $pdisks{PDISKS}[$i]{PD_ID};
                            $lidData->{PORT} = $port;                        # $pdisks{PDISKS}[$i]{PD_CHANNEL};
                            $lidData->{CTLR} = $oIdx;                       
                            $lidData->{PID}  = $pdisks{PDISKS}[$i]{PD_PID};

                            # print "adding pdisk $lidData->{CTLR} $lidData->{PID} $lidData->{PORT} $lidData->{LID}\n";
                            
                            push ( @lidList, $lidData );
                            
                            last;
                        }
                    }

                                
                                            #
                                            # is it a bay (by matching WWNs)
                                            #

                                                #
                                                # add to the array ( lid, port, ctlr)
                                                #


                } # end device

            } # end port

        }   # end valid object
        

    } # end each object

    #
    # copy results
    #

    @$lidPtr = @lidList;

    #
    # done
    #

    return GOOD;
}

##############################################################################

##############################################################################
=head2 LoopPrimUsingList function

Does a loop primitive on each of the items in the supplied list. Caller
Specifies which primitive to use.
 
=cut

=over 1

=item Usage:

 my $rc = LoopPrimUsingList( $coPtr, $prim, $lids, $loops, $delay, $flags, $parm  );

 where: $coPtr is a pointer to a list of copntroller objects
        $prim is the loop primitive option to use (See: ccbe loopprimitive )
        $lids is a pointer to a lids of lids. Each lid is actually a hash
        $loops is the number of iterations to do
        $delay is the delay between each loop primitive
        $flags is a bit mapped set of flags
        $parm is an optional paramter for some options

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Details:

 For each item in the lid list, the function sends  the chosen loop primitive. 
 This should not completely trash the I/O, but too many resets, too often may 
 lead to timeouts and other issues on the back end. THere will be some impact 
 on controller performance and one should not expect to be able to use every 
 loop primitive on all the drives wothout some side effects.

 The flags can be one of 
 
        ALLCTLRS does all controllers
        SINGLECTLR only does the controller specified in $parm
        MASTERCTLR does only the master controller
        SLAVECTLR does one slave controller (determined by function)

=back

=cut

##############################################################################
###############################################################################
# Performs Loop Primities on each LID
###############################################################################
sub LoopPrimUsingList
{
    my (  $coPtr, $prim, $lidPtr, $loops, $delay, $flags, $parm ) = @_;

    my $master;
    my $slave;
    my $ctlr;
    my $lid;
    my $ret;
    my $loop;


    #
    # Validate options
    #

    #
    # find master (if needed), Identify a slave (if needed)
    #

    $master = FindMaster($coPtr);
    if ( $master == INVALID )
    {
        logInfo("LoopPrimUsingList: unable to determine master controller at start.");
        logInfo("Test fails.");
        return ERROR;
    }


    #
    # For each requested loop
    #
    for ( $loop = 0; $loop < $loops; $loop++ )
    {
        
        #
        # For each lid in the list...
        #

        my $x =  scalar(@$lidPtr);
        print" there are $x lids to process \n";
         

        for ( $lid = 0; $lid < scalar(@$lidPtr); $lid++)
        {
            #
            # Determine if we do this one (or if we skip it)
            #

            if (( $flags == MASTERCTLR ) && ($master != $$lidPtr[$lid]->{CTLR} ))
            {
                # doing master only and this one not on master
                next;
            }

            if (( $flags == SINGLECTLR ) && ($parm != $$lidPtr[$lid]->{CTLR} ))
            {
                # doing specific ctlr and this one not on that ctlr
                next;
            }

            if (( $flags == ALLSLAVES ) && ($master == $$lidPtr[$lid]->{CTLR} ))
            {
                # doing any slave and this one is one the master
                next;
            }

            if (( $flags == SLAVECTLR ) && ($slave == $$lidPtr[$lid]->{CTLR} ))
            {
                # doing any slave and this one is one the master
                next;
            }


            #
            # on anythng that is left,
            # Send the loop primitive
            #                          $ctlr, $pid, $port, $lid

       #     print  "Lid Data is ". $lidPtr->[$lid]." \n";
       #
       #     print " lp prim on( $$coPtr[$lidPtr->[$lid]->{CTLR}] ) ";
       #     print "           (  $lidPtr->[$lid]->{PID},  ) ";
       #     print "           (  $lidPtr->[$lid]->{PORT}) ";
       #     print "           (  $lidPtr->[$lid]->{LID}) ";
       #     print "           ( $prim )\n\n";
    
            $ret = BELoopPrimitive( $$coPtr[$$lidPtr[$lid]->{CTLR}],
                                    $$lidPtr[$lid]->{PID}, 
                                    $$lidPtr[$lid]->{PORT}, 
                                    $$lidPtr[$lid]->{LID}, 
                                    $prim );
       
            if ( $ret != GOOD)
            {
                logInfo(" Error sending loop primitive, test fails.");
                return ERROR;
            }
       
            DelaySecs(1);


        }
         
        #
        # Verify nothing catastrophic has happened
        #    
    
        $ret = TestBEState( $coPtr);
        if ( $ret == ERROR )
        {
            logInfo("BE state check failed.");
            return ERROR;
        }

    }
 
 
    #
    # done
    #

    return GOOD;

}

##############################################################################
=head2 BELoopPrimitive function

Checks for orhpaned raids. An orphaned raid is a raid whose associated vdisk
is missing. 
=cut

=over 1

=item Usage:

    my $rc = BELoopPrimitive( $ctlr, $pid, $port, $lid, $prim );

 where:  $ctlr = a controller object
         $pid - the pid of the device
         $port = the port the device is connected to
         $lid = loop ID at the indicated port
         $prim = which primitive to use 
 
 
 
 
 =item Returns:

       $rc will be GOOD or ERROR based upon the execution of the 
           command

=item Details:

 This function just sends the requiested loop primitive to the indicated 
 drive.
 


=back

=cut

###############################################################################

##############################################################################
#
#          Name: BELoopPrimitive
#
#        Inputs: controller object, pdisk number , BE port, loop id, primitive
#
#       Outputs:GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Does a LIP reset to the pdisk specified in the 
#                call. Does both ports that the pdisk may appear on.    
#
#
##############################################################################
sub BELoopPrimitive
{
    my ( $ctlr, $pid, $port, $lid, $prim)= @_;
    
    my %info;
    my $msg;

    $msg = sprintf ("BE loop primitive: (%s) port:%1d, pid:%4d, lid:%4d, primitive:%2d ",
                    $ctlr->{HOST}, $port, $pid, $lid, $prim );

print $msg."\n";
return GOOD; 
    
    %info = $ctlr->loopPrimitiveBE($prim, $pid, $port, $lid);
    
    if ( ! %info  )
    {
        # no data was returned
        loginfo $msg;
        logInfo(">>>>>>>> Failed to get response from loopPrimitiveBE <<<<<<<<");
        return ERROR;
    }

    #
    # if the  data is bad, indicate the error
    #

    if ($info{STATUS} != PI_GOOD)
    {

        #
        # data gave an error, return with a bad indication
        #
        
        loginfo $msg;
        logInfo(">>>>>>>> Error returned from loopPrimitiveBE  <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
    
    return GOOD;
    
    
        
}    



###############################################################################
=head2 OrphanedRaidCheck2 function

Checks for orhpaned raids. An orphaned raid is a raid whose associated vdisk
is missing. 
=cut

=over 1

=item Usage:

 my $rc = OrphanedRaidCheck2( $ctlr   );

 where: $ctlr is a controller object
=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Details:

 The function gets the raids and vdisks information from the controller
 and then looks at each raid in the raids hash, getting the vidsk
 number the raid belongs to. Then it walks the vdisks hash looking for
 the indicated vdisk. The vdisk is evaluated to see that the raid appears
 exactly once. If the vdisk is missing, or the raid is not found in the 
 vdisk or the raid is found more than once, the function will return ERROR.

 The function also verifies that each raid appears exactly once in the 
 raids hash. Multiple occurrences of the same raid ID will return ERROR.
 
 This function interacts with the controllers to get the data for the check.

 To return GOOD the following must occur.
   1) Each raid is owned by exactly 1 vdisk
   2) Each raid ID is unique
   3) The owning vdisk must match the vdisk in the raids structure


=back

=cut

##############################################################################
###############################################################################
# An orphan raids check that just needs a controller object
###############################################################################
sub OrphanedRaidCheck2
{
    my ( $ctlr ) = @_;

    my %vdisks;
    my %raids;
    my $msg = "";
    my $ret;
    

    # - look for orphans (need raids and vdisks hashes)
    # - get the vdisks hash

    %vdisks = $ctlr->virtualDisks();
    if ( ! %vdisks  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
        return ERROR;
    }
    if ( $vdisks{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
        PrintError(%vdisks);
        return ERROR;
    }



    # - get the raids hash

    %raids = $ctlr->raids();
    if ( ! %raids  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $raids{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%raids);
        return ERROR;
    }

    logInfo("OrphanedRaidCheck2: Current raids");
    $msg = $ctlr->displayRaids( %raids);
    logInfo("\n".$msg);
    
    logInfo("OrphanedRaidCheck2: Performing orphan check.");

    $ret = OrphanedRaidCheck( \%vdisks, \%raids );
    if ($ret != GOOD)
    {
        logInfo("Orphaned RAIDs have been detected.");
        return ERROR;
    }

    return $ret;


}
###############################################################################

=head2 OrphanedRaidCheck function

Checks for orhpaned raids. An orphaned raid is a raid whose associated vdisk
is missing. 
=cut

=over 1

=item Usage:

 my $rc = OrphanedRaidCheck( $vPtr, $rPtr   );

 where: $vPtr is a pointer to a 'vdisks' hash
        $rPtr is a pointer to a 'raids' hash

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Details:

 The function looks at each raid in the raids hash, getting the vidsk
 number the raid belongs to. Then it walks the vdisks hash looking for
 the indicated vdisk. The vdisk is evaluated to see that the raid appears
 exactly once. If the vdisk is missing, or the raid is not found in the 
 vdisk or the raid is found more than once, the function will return ERROR.

 The function also verifies that each raid appears exactly once in the 
 raids hash. Multiple occurrences of the same raid ID will return ERROR.
 
 This function only looks at data, it does not interact with the 
 controller(s).

 To return GOOD the following must occur.
   1) Each raid is owned by exactly 1 vdisk
   2) Each raid ID is unique
   3) The owning vdisk must match the vdisk in the raids structure


=back

=cut

##############################################################################


#
# Walk the raids list and for each raid, look at its associated vdisk. Find
# that vdisk in the vdisks data and see if that raid is there. Also,
# make sure that each raid is unique.
#


sub OrphanedRaidCheck
{
    my ( $vPtr, $rPtr ) = @_;

    my %raids = %$rPtr;
    my %vdisks = %$vPtr;

    my $i;
    my $j;
    my $k;
    my $newVdd;
    my $vid;
    my $found; 
    my $match;



    my @ridsFound;
    my $numRaids;

    my $ret = GOOD;

    logInfo("Orphaned Raid Check: begin");
    logInfo("Orphaned Raid Check: checking all raids have vdisk owners");

    for ( $i = 0; $i < $raids{COUNT}; $i++ )
    {
        
        # save the RID
        push (@ridsFound, $raids{RAIDS}[$i]{RID} );

        $vid = $raids{RAIDS}[$i]{VID};

        #
        # find the matching vdisk
        #
        
        $found = 0;
        $match = 0;

        for ( $j = 0; $j < $vdisks{COUNT}; $ j++ )
        {
            # for the vdisk, walk the raids and deferred raids
            $numRaids = $vdisks{VDISKS}[$j]{RAIDCNT} + $vdisks{VDISKS}[$j]{DRAIDCNT};

            for ( $k = 0; $k < $numRaids; $k++ )
            {
                if (  $raids{RAIDS}[$i]{RID} ==  $vdisks{VDISKS}[$j]{RIDS}[$k] )
                {
                    # found the matching raid, count it
                    $found += 1;

                    if ($vdisks{VDISKS}[$j]{VID} == $vid )
                    {
                        # the raid and vdisk match
                        $match += 1;
                    }
                }



            }
        }

        if ( $found == 0 )
        {
            logInfo("Raid $raids{RAIDS}[$i]{RID} was NOT OWNED by any vdisk - orphan detected.");
            $ret = ERROR;
        }
        
        if ( $found > 1 )
        {
            # this would be really bad
            logInfo("Raid $raids{RAIDS}[$i]{RID} was owned by MULTIPLE vdisks - orphan detected.");
            $ret = ERROR;
        }

        if ( $match != 1)
        {
            logInfo("Raid $raids{RAIDS}[$i]{RID} was not owned by the referenced vdisk ($vid) - orphan detected.");
            $ret = ERROR;
        }

    }

    #
    # now look that the rids that were found and make sure there are no duplicates
    #

    logInfo("Orphaned Raid Check: checking for unique raid IDs");

    for ( $i = 0; $i < scalar(@ridsFound); $i++)
    {
        for ( $j = ($i+1);  $j < scalar(@ridsFound); $j++)
        {
            if ( $ridsFound[$i] ==  $ridsFound[$j] )
            {
                logInfo("Raid ID $ridsFound[$i] was found multiple times - duplicate detected.");
                $ret = ERROR;
            }
        }
    }


    #
    # done
    #

    logInfo("Orphaned Raid Check: complete (returning $ret)");
    

    return $ret;

}



1;   # we need this for a PM

##############################################################################
#
# $Log$
# Revision 1.1  2005/05/04 18:53:52  RysavyR
# Initial revision
#
# Revision 1.2  2004/09/14 20:22:19  MenningC
# tbolt00000000: Updates for standalone orphaned raid script
#
# Revision 1.1  2004/09/02 21:20:54  KohlmeyerA
# Tbolt00000000:  Broke UETest up into separate UETest and UETestSupport files.
# Reviewed by Craig.
#
#
#
##############################################################################
