#!/usr/bin/perl -w
# $Header$
##############################################################################
# File name:  TestLibs::AnarchyCode
#                              
# Desc: AnarchyCode is used with the Seagate Drive code to injection failure 
#       conditions
#
# Date: 03/04/2005
#
# Original Author:  Neal Eiden
#
# Last modified by  $Author: EidenN $
# Modified date     $Date: 2006-07-31 10:19:45 -0500 (Mon, 31 Jul 2006) $
#
# Copyright Xiotech Corporation 2001-2005
#
# For XIOtech internal use only.
#
##############################################################################

=head1 NAME

TestLibs::AnarchyCode - Support for Seagate Anarchy drive testing

$Id: AnarchyCode.pm 12236 2006-07-31 15:19:45Z EidenN $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

This document describes usage of the Perl functions to Test the Anarchy Drive

=head1 DESCRIPTION

Test Functions Available
                AnarchyEntry
                AnarchyLoop

=cut

##############################################################################


package TestLibs::AnarchyCode;

#
# - other modules used
#

use warnings;
use lib "../CCBE";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::Validate;
use TestLibs::IntegCCBELib;
use TestLibs::IntegXMCLib;
use TestLibs::BEUtils;
use TestLibs::FailOverSupport;
use TestLibs::utility;
use TestLibs::Fibre;
use Dumpvalue;
my $dumper = new Dumpvalue;
my $dumper2 = new Dumpvalue;

#
# - perl compiler/interpreter flags 'n' things
#

use strict;

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      
                     
                      &AnarchyEntry
                      &AnarchyLoop
                      &AnarchyTestCases
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 12236 $);
}
    our @EXPORT_OK;




=head2 AnarchyLoop function

Check the testcase profile for the correct testparms (FAILTYPE) and calls the AnarchyLoop function



=cut

=over 1

=item Usage:

 my $rc = AnarchyLoop($coPtr, $moxaIP, $moxaPtr, $parmsPtr, $fCtlPtr, $tcLoopCount, $modePageData, $tcDelay);
 
 where,
        $coPtr is a pointer to a list of controller objects
        $moxaIP is the ip address of the moxa controller
        $moxaPtr is a pointer to a list Moxa channel letters
        $parmsPtr is a pointer to a hash  of misc parameters
        $fCtlPtr is a pointer to and array of strings for external 
                 control
        $tcLoopCount is the number of loop of executing the same command before going to the next testcase
        $modePageData is the mode page data that triggers error injection on the drive
        $tcDelay is the delay between executions of each command within a loop         

    The parmsPtr hash has the following keys. Defaults in ()

        {LOOPCOUNT}       Number of loops to do (1)
        {FLAGS}           validation flags, see below (0)
        and others as needed.
        DRIVEIDCORRUPT    Drive PID to corrupt

    Description of failure types {CURTESTARGUMENT}:
    
                        1 - Assert - Mode 8
                        2 - Data I/O Errors - Mode 7
                        3 - I/O Timeout - Mode 3
                        4 - Mechinical Error - Mode 6
                        5 - Corrupt Long - Mode 0 
                        6 - Corrupt Length - Mode 1
                        99 - execute all test case 1-6


    inFlags is a bitmap of:
                        1 ( no server IO fail)
                        2 ( no BE check fail)
                        4 ( no initial BE chack fail)
                        8 ( add some parity scans)
                       16 ( add more parity scans)
                       32 ( add raid 5 resync check)

=item Returns:

       $rc GOOD if valid, ERROR otherwise. 

=item Description:
 
 Checks the method against a list of valid values.

=back

=cut

##############################################################################
#
#          Name: AnarchyLoop
#
#        Inputs: $coPtr, $moxaIP, $moxaPtr, $parmsPtr, $fCtlPtr, $tcLoopCount, $modePageData, $tcDelay
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  Used for validations before and after calling the AnarchyTestCases function
#
##############################################################################
sub AnarchyLoop
{
    trace();                        # This allows function tracability

    my ($coPtr, $moxaIP, $moxaPtr, $parmsPtr, $fCtlPtr, $tcLoopCount, $modePageData, $tcDelay) = @_;

    my $loop1;
    my $i;
    my $newMaster;
    my $numCtlrs;
    my $j;
    my $ret;
    my $failCount;
    my @serialNums;
    my $how2fail;
    my $tempMaster;

    my @startingTmap;
    my @initialVdisks;
    my %info1;
    my $vdiskListPtr;
    my @vCounts;
    my @sCounts;
    my @activeServers;

    my %raidsHash; 
    my %pdisksHash;
    my %vdisksHash;
    my $failType;


    my @moxaMap;
    my @moxaList;
    my %mirrorData;
    my $DriveIdCorrupt;
    my $cdb;
    my $writeBufferPtr;
    my %PDInfo;
    my @Return;
    my @FunctionRet;
    my @coList;
    @coList = @$coPtr;
    my @tMap;
  

    my $flags;
    my $MRWTimeout;
    my $length;
    my %FunctionRet;

   


    #
    # Select the Mode page for this test
    #
    my $pageNum = 165;
                                                                                             


    logInfo("-------------------------------------------------------------");
    logInfo("---------------------- Anarchy Test -------------------------");
    logInfo("-------------------------------------------------------------");

         

    #################################################################
    ############## Extract parms from hash ##########################
    #################################################################
        
    #
    # Set up the initial defaults and then see if there are new values
    # in the parameter hash. If the values are there, update the test
    # values. Finally, print them.
    #
    
    $ret = 0;
    
    $flags = 0;                     # default operation

    $loop1 = 1;                     # default loopcount
    
    $MRWTimeout = 90;               # time allowed for resync to finish                                 
    
    $failType = 99;                 # Default to run all testcases unless defined
                                
                                                                        

    if (defined $parmsPtr->{MIRRORRESYNCWAIT} )
    {
        if ( $parmsPtr->{MIRRORRESYNCWAIT} > 0 )
        {   
            $MRWTimeout = $parmsPtr->{MIRRORRESYNCWAIT};
        }
    }


    if (defined $parmsPtr->{FLAGS} )
    {
        if ( $parmsPtr->{FLAGS} >= 0 )
        {   
            $flags = $parmsPtr->{FLAGS};
        }
    }

    if (defined $parmsPtr->{LOOPCOUNT} )
    {
        if ( $parmsPtr->{LOOPCOUNT} >= 0 )
        {   
            $loop1 = $parmsPtr->{LOOPCOUNT};
        }
    }

    if (defined $parmsPtr->{CURTESTARGUMENT} )
    {
        $failType = $parmsPtr->{CURTESTARGUMENT};
    }
    
    if (defined $parmsPtr->{DRIVEIDCORRUPT} )
    {
        $DriveIdCorrupt = $parmsPtr->{DRIVEIDCORRUPT};
    }
    else
    {
        logError("    ====> Failed to find the Anarchy Drive.  DRIVEIDCORRUPT testparm must have a valid PID <====");
        return ERROR;
    }
    
        


    logInfo("");
    logInfo(" Test parameters:");
    logInfo("                  flags: $flags");
    logInfo("             loop count: $loop1"); 
    logInfo("         Failure method: $failType");
    logInfo("         Mode Page Data: $modePageData");
    logInfo("     Mirror Resync Wait: $MRWTimeout");
    logInfo("          Anarchy Drive: $DriveIdCorrupt");
    logInfo("");


    
    #################################################################
    #################### Validate some parameters ###################
    #################################################################
    
    $numCtlrs = scalar( @coList );


    ##########################################################################

    #
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    #


    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNums[$i] = $coList[$i]{SERIAL_NUM};                                   }


    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $newMaster == INVALID )
    {
        logError("    ====> Failed to find the master controller at beginning of the test <====");
        return ERROR;
    }

    #
    # If there are Raid 5 arrays present we need to wait for the resync 
    # to complete on failback. Check the raids and add the option
    # bit if needed. Also needed on failovers.
    #
    if ( 1 == GotRaid5($coList[$newMaster]) )
    {
        logInfo ( "Raid 5 configured in system, making sure R5 resync bit set.");
        $flags = $flags | ADD_R5RESYNC_CHECK;
    } 
    
    #
    # Rel 3.1 adds resync, need to wait for it to complete
    #
    logInfo( "Making sure all mirror resync is complete at start of test.");
    $ret = MirrorResyncWait($coPtr, 4 * $MRWTimeout);
    if ($ret != GOOD)
    {
        logInfo("Failed Mirror Resync wait at start of test.");
        return ERROR;
    }

    $ret = MirrorInitialData($coPtr, \%mirrorData);

    #
    # Disable Write Cache
    #
    logInfo("    ====> Checking that all Pdisks have Write Cache Disabled  <====");
    $ret = TestLibs::SCSI::SCSIWriteCacheDisable($coList[$newMaster]);
    
    if ( $ret == ERROR )
    {
        logError("Write Cache could not be disabled on one or more drives");
        return ERROR;
    }

    
    #
    # Add a pdisks FWV
    #
    %info1 = $coList[$newMaster]->physicalDisks();
    if ( ! %info1  )
    {
        logInfo("    ====> Failed to get response from physicalDisks <====");
        return ERROR;
    }
    if ($info1{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Unable to get physicalDisks info <====");
        PrintError(%info1);
        return ERROR;
    }

    logInfo(" Physical disk firmware information ");

    logPhysicalDisks("FWV", %info1);
 
 
    
    #
    # Display target list                                                            
    #
    $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$newMaster] );
    if ( $ret == ERROR )
    {
        logError("Failed to get target list at start");
        return ERROR;
    }

    #
    # check to see that everything is good at the start
    #
    logInfo("Check to see if everything is functioning at the start of the test");
    $ret = TestBEState($coPtr);

    if ( ($ret != GOOD) && !(NO_STARTUP_CHECK & $flags) )
    {
        logInfo("Test of the BE state failed");
        return ERROR;
    }


    
    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, \@serialNums, $newMaster, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);
                         
    if ( $ret == ERROR )
    {
        logInfo("Failed to gether I/O information");
        return ERROR;
    }

    #
    # Validating BE data                                         
    #
    $ret = CheckBEHashes( \%mirrorData);
    if ( $ret == ERROR )
    {
        logInfo("Initial BE Hash indicated a bad state.");
        return ERROR;
    }

    #
    # startup parity scan, if we are doing any in the loop
    #
    if (  (ADD_PARITY_SCAN & $flags) || (ADD_MORE_PARITY_SCANS & $flags) )
    {
        # parity scan the world
        $ret = TestLibs::BEUtils::PScanCheck( \@coList, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("Initial parity scan reported an error - test failed.");
            return ERROR;
        }
    }


    $failCount = 0;
    my $intcnt = 0;
    #
    # The loop that is really the test
    #
    for ( $i = 0; $i < $loop1; $i++ )
    {

        TestLibs::IntegCCBELib::CtlrLogTextAll($coPtr, "---------- Beginning Anarchy inner loop # $intcnt . ------------");

    $intcnt = $intcnt +1;

        #
        # Retrieve WWN/LUN from the specified physical disk
        #
        %PDInfo = $coList[$newMaster]->XIOTech::cmdMgr::physicalDiskInfo($DriveIdCorrupt);
        
        logInfo("Getting information for pd id $DriveIdCorrupt ");
        if( ! %PDInfo )
        {
            logInfo("Failed to get pdisk information for drive $DriveIdCorrupt.");
            $Return[0]{STATUS} = ERROR; 
            return @Return;
        }

        if ( $PDInfo{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from physicalDiskInfo command <<<<<<<<");
            PrintError(%PDInfo);
            $Return[0]{STATUS} = ERROR; 
            return @Return; 
        }    
       
   
        #
        # Assume that there's no raids on the drive set the last raid poss in 
        # the array to 0, check if there's any raids and if there're set the last
        # raids poss. 
        #
        my %info = $coList[$newMaster]->getSos($DriveIdCorrupt);                                                                                                                 #         or you may end up working with bad data.

        logInfo("Getting information for pd id $DriveIdCorrupt ");
        if( ! %info )
        {
            logInfo("Failed to get pdisk information for drive $DriveIdCorrupt.");
            $Return[0]{STATUS} = ERROR; 
            return @Return;
        }

    #    if( %info{STATUS} != PI_GOOD )      # if call returned an error
    #    {
    #        logInfo(">>>>>>>> Error from physicalDiskInfo command <<<<<<<<");
    #        PrintError(%info);
    #        $Return[0]{STATUS} = ERROR; 
    #        return @Return; 
    #    }    
       


        my $Element = 0;
        
        #
        # Starting address to write to
        #
        my $lba = 327680;
        
        my $AddLength = 0;
        my $Flag = 0;
       
        #
        # Data to write
        #
        my $writeBuffer = "00000000";

        #
        # If there are raids on the drive
        #
        if($info{COUNT})
        {
            $Element = $info{COUNT} - 1;
            
            #
            # Add 512 to the length
            #
            if($Flag == 1)
            {
                $AddLength = $info{LIST}[$Element]{LEN} + 512;  
            }
            
            #
            # Find the begging address of where to write data
            #
            $lba = ($info{LIST}[$Element]{SDA} + $AddLength);
        }


        logInfo("Checking for Valid READ/WRITE Long Length in range of:  512 - 650");
        
        #
        # Loop until valid length is found and verify we can talk to the drive.
        #
        for($length = 512; $length < 650; $length++)
        {

            @FunctionRet = TestLibs::SCSI::SCSIReadLong($coList[$newMaster], 
                                                         $PDInfo{WWN_HI}, 
                                                         $PDInfo{WWN_LO},
                                                         $PDInfo{PD_LUN},
                                                         $lba,
                                                         $length,
                                                         \$writeBuffer,
                                                         0);
            if($FunctionRet[0] == ERROR)
            {
            $length++;
            }
            else
            {
            logInfo("Valid Length FOUND of $length ");
            last;
            }
        }  
 
        #
        # Check to verify this is an Anarchy drive by attempting to read MODE PAGE 25
        #
        #
        # get the mode page and check write cache bit
        #
        $pageNum = TestLibs::utility::AsciiHexToBin($pageNum, "byte");
        ($ret, %FunctionRet) = TestLibs::SCSI::SCSIModeSense10($coList[$newMaster], 
                                                         $PDInfo{WWN_HI}, 
                                                         $PDInfo{WWN_LO},
                                                         $PDInfo{PD_LUN},
                                                         64,$pageNum);                                   
        if (! %FunctionRet )        
        {
            print ("     >>>>>>>>>> no response from Mode Sense - cannot continue <<<<<<<<<<<\n");
            return ERROR;

        }



        if ( $FunctionRet{STATUS} != PI_GOOD )
        {
            logInfo("    ====> Error generated while Viewing the Mode Page settings. Test fails.  <====");
            logInfo("    ====> Verify correct PID is being used for Anarchy drive.                <====");
            logInfo( "      Sense Key: 0x%02X, $FunctionRet[0]{SENSE_KEY}");
            logInfo( "     Sense Code: 0x%02X, $FunctionRet[0]{ADTL_SENSE_CODE}");
            logInfo( "Sense Code Qual: 0x%02X, $FunctionRet[0]{ADTL_SENSE_CODE_QUAL}");
            
            logInfo(sprintf("            WWN: %8.8X%8.8X ", $PDInfo{WWN_LO}, $PDInfo{WWN_HI} ));                                            
   

            return ERROR;
        } 

       
        #
        # Testcases
        #
        @FunctionRet = AnarchyTestCases(\@coList, \%PDInfo, $tcLoopCount, $modePageData, $tcDelay);            
                
        if ( $FunctionRet[0] != GOOD )
        {
            logInfo("    ====> TestCase FAILED while sending error command  $modePageData   to drive  <====");

            return ERROR;
        }

  
  
       
        #
        # Let's put the MODE PAGE 25 back to normal - Clean up
        #                                                          TestLibs::utility::AsciiHexToBin(, "byte");
        $writeBuffer = "0016000000000000A50E00000000000000000000000000";
        print ("Clean it up:   $writeBuffer\n");
        $writeBuffer = TestLibs::utility::AsciiHexToBin($writeBuffer, "byte");
         ($ret, %FunctionRet) = TestLibs::SCSI::SCSIModeSelect10($coList[$newMaster], 
                                                         $PDInfo{WWN_HI}, 
                                                         $PDInfo{WWN_LO},
                                                         $PDInfo{PD_LUN},
                                                         $writeBuffer);                                   
        if (! %FunctionRet )        
        {
            print ("     >>>>>>>>>> no response from Mode Sense - cannot continue <<<<<<<<<<<\n");
            return ERROR;

        }



        if ( $FunctionRet{STATUS} != PI_GOOD )
        {
            logInfo("    ====> Error generated while Viewing the Mode Page settings. Test fails.  <====");
            logInfo("    ====> Verify correct PID is being used for Anarchy drive.                <====");
            logInfo( "      Sense Key: 0x%02X, $FunctionRet[0]{SENSE_KEY}");
            logInfo( "     Sense Code: 0x%02X, $FunctionRet[0]{ADTL_SENSE_CODE}");
            logInfo( "Sense Code Qual: 0x%02X, $FunctionRet[0]{ADTL_SENSE_CODE_QUAL}");
            
            logInfo(sprintf("            WWN: %8.8X%8.8X ", $PDInfo{WWN_LO}, $PDInfo{WWN_HI} ));                                            
   

            return ERROR;
        }

        #
        # Wait 120 seconds for I/O to get back to full speed
        #
        DelaySecs(5);

        if (  ADD_R5RESYNC_CHECK & $flags  )
        {
            logInfo("[$failCount Anarchy Testloops completed] Begin resync wait.");
    
            #
            # wait for resync to finish on all raids
            #
            $ret = TestLibs::Validate::R5ResyncCheck( \@coList, 0, INVALID );
            if ( $ret != GOOD )
            {
                logInfo("R5 resync check reported an error - test failed, $failCount Anarchy completed.");          
                return ERROR;
            }
        }



        #
        # Rel 3.1 adds resync, need to wait for it to complete
        #
        $ret = MirrorResyncWait(\@coList, $MRWTimeout);
        if ($ret != GOOD)
        {
            logInfo("Failed Mirror Resync wait.");
            $ret = MirrorCheck( \@coList, \%mirrorData);
            return ERROR;
        }

        $ret = MirrorCheck( \@coList, \%mirrorData);
        if ($ret != GOOD)
        {
            logInfo("Failed Mirror State Check.");
            return ERROR;
        }

        logInfo("[$failCount Anarchy Testloops completed] Begin validation after drive error introduced ");

        $ret = TestLibs::Validate::TestSystemState1(\@coList, \@activeServers, 0, $vdiskListPtr, \@serialNums);
        if ( ($ret == ERROR) && !(NO_SERVER_CHECK & $flags) )
        {
            logInfo(">>>>>>>> Controller state bad with slave failed [$failCount Anarchy Testloops completed]  <<<<<<<<");
            return ERROR;
        }


        #
        # While everything should be in good shape, do one more
        # check to verify we had no unexpected failures. 
        logInfo("Check of VCG Info after drive error Corrected. [$failCount Anarchy Test completed]");

        $ret = VCGInfoCheck ( $coPtr ); 
        if ( $ret !=GOOD )
        {
            logInfo("Error verifying VCG Info after drive error Corrected, test fails, $failCount Anarchy Test completed.");
            return ERROR;
        }

        #
        # check the back end state, vdisk status, pdisk status, raid status
        #
        $ret = TestLibs::Validate::TestSystemState3($coList[$newMaster], \%mirrorData);
        if ( ($ret == ERROR) && !(NO_BED_CHECK & $flags) )
        {
            logInfo("    ====> Controller state bad after drive error Corrected [$failCount Anarchy Test completed] <====");
            return ERROR;
        }


        #
        # do user requested parity scan                                                                 
        #
        if (  (ADD_PARITY_SCAN & $flags) || (ADD_MORE_PARITY_SCANS & $flags) )
        {
            #
            # parity scan the world
            #
            $ret = TestLibs::BEUtils::PScanCheck( \@coList, 0, INVALID );
            if ( $ret != GOOD )
            {
                logInfo("Parity scan reported an error - test failed.");
                return ERROR;
            }
        }

        #
        # Bump the fail count and go back and do it again.
        #
        $failCount++;                                                                            
                
        if ( $parmsPtr )         
        {
            $parmsPtr->{TESTLOOPS} =  $failCount;
        }



        logInfo("--------------------- Loop $i completed, $failCount Anarchy Test completed. -------------------");



        if ( $ret != GOOD )
        {
            logInfo(" Some error while posting the summary, test failed, $failCount Anarchy Test completed. ");
            return ERROR;
        }


    }   # end of for # $loop1 drive errors
    
    

    #
    # done!
    #
    logInfo("End of Anarchy Test, $failCount Test(s) completed.");
    return GOOD;

}
=head2 AnarchyEntry function

Check the testcase profile for the correct testparms (FAILTYPE) and calls the AnarchyLoop function



=cut

=over 1

=item Usage:
                                 
 my $rc = AnarchyEntry($coPtr, $moxaIP, $moxaPtr, $parmsPtr, $fCtlPtr);
 
 where,
        $coPtr is a pointer to a list of controller objects
        $moxaIP is the ip address of the moxa controller
        $moxaPtr is a pointer to a list Moxa channel letters
        $parmsPtr is a pointer to a hash  of misc parameters
        $fCtlPtr is a pointer to and array of strings for external 
                 control

    The parmsPtr hash has the following keys. Defaults in ()

        {LOOPCOUNT}       Number of loops to do (1)
        {FLAGS}           validation flags, see below (0)
        and others as needed.
        

    Description of failure types {CURTESTARGUMENT}:
    
         Failure Cases
     1 = Silent Miscompare
     2 = Command Timout Method 1
     3 = Command Timout Method 2
     4 = Corrupt Frames
     5 = Force Buffer IOEDC Errors
     6 = Any Sense To Any Command
     7 = Persistent Hard Error
     8 = Persistent Hard Error
     9 = Cold Hard Reset/Watchdog Timeout
    10 = Assert Failure
    11 = Hang drive
    12 = Set Queue to Full
    13 = LIP The Loop
    14 = Drop Off Loop/Bus
    15 = Hang On Loop/Bus During Data In
    16 = Hang Loop by changing transmit and receive speed
    17 = Hang Loop by powering down tranceiver
    18 = Corrupt Outbound Traffic
    19 = Send Primitive
    20 = Set Busy on the requested port
    21 = Set Pause on the requested port



    inFlags is a bitmap of:
                        1 ( no server IO fail)
                        2 ( no BE check fail)
                        4 ( no initial BE chack fail)
                        8 ( add some parity scans)
                       16 ( add more parity scans)
                       32 ( add raid 5 resync check)

=item Returns:

       $rc GOOD if valid, ERROR otherwise. 

=item Description:
 
 Checks the method against a list of valid values.

=back

=cut

##############################################################################
#
#          Name: AnarchyEntry
#
#        Inputs: $coPtr, $moxaIP, $moxaPtr,  $parmsPtr, $fCtlPtr
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  Used to send the proper mode page data based on the 
#                 CURTESTARGUMENT vale.  Then calls AnarchyLoop
##############################################################################
sub AnarchyEntry
{
    trace();                                                  
    my ($coPtr, $moxaIP, $moxaPtr,  $parmsPtr, $fCtlPtr ) = @_;                                      
    
    my $ret = GOOD;
    my $failType = 0;
    my @coList = @$coPtr;
    my $return;
   
    if (defined $parmsPtr->{FAILTYPE } )
    {
        $failType = $parmsPtr->{FAILTYPE };
    }

    if ( $failType == 99 )
    {
        logInfo("All test cases selected, default loop count values will be used.");
    }

    
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "           Starting Anarchy Case $failType            ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");

    
    
    #############################################
    #                                                                                                                 
    # Test Case descriptions needed here
    #
    #############################################

    #     Failure Cases
    # 1 = Silent Miscompare
    # 2 = Command Timout Method 1
    # 3 = Command Timout Method 2
    # 4 = Corrupt Frames
    # 5 = Force Buffer IOEDC Errors
    # 6 = Any Sense To Any Command
    # 7 = Persistent Hard Error
    # 8 = Persistent Hard Error
    # 9 = Cold Hard Reset/Watchdog Timeout
    #10 = Assert Failure
    #11 = Hang drive
    #12 = Set Queue to Full
    #13 = LIP The Loop
    #14 = Drop Off Loop/Bus
    #15 = Hang On Loop/Bus During Data In
    #16 = Hang Loop by changing transmit and receive speed
    #17 = Hang Loop by powering down tranceiver
    #18 = Corrupt Outbound Traffic
    #19 = Send Primitive
    #20 = Set Busy on the requested port
    #21 = Set Pause on the requested port

    #                           Failure Type or types   
    #                                Times to run same test (repeater)
    #                                     Mode Page data                                                                     Delay between commands
 if ( $failType==1  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Silent Miscompare - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0200000000000000000000000000020e01f80001000500004d0000000000", 2); 
        CtlrLogTextAll( $coPtr, "Silent Miscompare - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }

 if ( $failType==2  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Command Timout Method 1 - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0200000000000000000000000000020e01f80010000500004d0000000000", 2); 
        CtlrLogTextAll( $coPtr, "Command Timout Method 1 - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==3  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Command Timout Method 2 - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 1, "0026000000000000A50E0200000000000000000000000000020e01780011000000004d0000000000", 2); 

        CtlrLogTextAll( $coPtr, "Command Timout Method 2 - Cycle Complete");
        DelaySecs(5);                   
    }
    if ( $ret != GOOD ) { return $ret; }



 if ( $failType==4  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Corrupt Frames - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0200000000000000000000000000020e01f80020000500004d0000000000", 2); 
        CtlrLogTextAll( $coPtr, "Corrupt Frames - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }



 if ( $failType==5  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Force Buffer IOEDC Errors - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0200000000000000000000000000020e01f80030100500004d0000000000", 2); 
        CtlrLogTextAll( $coPtr, "Force Buffer IOEDC Errors - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==6  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Any Sense To Any Command - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000030e02f8000100000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Any Sense To Any Command - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==7  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Persistent Hard Error - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000030e02f8002000000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Persistent Hard Error - Cycle Complete");
        DelaySecs(5);                   
    }
    if ( $ret != GOOD ) { return $ret; }

 if ( $failType==8  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Persistent Hard Error - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000030e02f8003000000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Persistent Hard Error - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==9  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Cold Hard Reset/Watchdog Timeout - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000040e0230000100000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Cold Hard Reset/Watchdog Timeout - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==10  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Assert Failure - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000040e023000100000000000000000CC00", 2); 
        CtlrLogTextAll( $coPtr, "Assert Failure - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==11  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Hang drive - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000040e0230002000000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Hang drive - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==12  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Set Queue to Full - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000040e0230003000000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Set Queue to Full - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==13  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "LIP The Loop - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000050e0230000100000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "LIP The Loop - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==14  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Drop Off Loop/Bus - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000050e0230001000000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Drop Off Loop/Bus - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==15  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Hang On Loop/Bus During Data In - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000050e0230002000000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Hang On Loop/Bus During Data In - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==16  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Hang Loop by changing transmit and receive speed - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000050e0230002800000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Hang Loop by changing transmit and receive speed - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==17  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Hang Loop by powering down tranceiver - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000050e0230002900000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Hang Loop by powering down tranceiver - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==18  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Corrupt Outbound Traffic - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000050e0230003000000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Corrupt Outbound Traffic - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==19  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Send Primitive - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000050e0230004000000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Send Primitive - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==20  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Set Busy on the requested port - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000050e0230005000000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Set Busy on the requested port - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }


 if ( $failType==21  || $failType == 99 )
    {  
        CtlrLogTextAll( $coPtr, "Set Pause on the requested port - Cycle Start");
        $ret = AnarchyLoop(\@coList, $moxaIP, $moxaPtr, $parmsPtr,
                           $fCtlPtr, 50, "0026000000000000A50E0400000000000000000000000000050e0230005100000000000000000000", 2); 
        CtlrLogTextAll( $coPtr, "Set Pause on the requested port - Cycle Complete");
        DelaySecs(5);
    }
    if ( $ret != GOOD ) { return $ret; }
    

    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
    CtlrLogTextAll( $coPtr, "           Anarchy Case $failType ends. ");
    CtlrLogTextAll( $coPtr, "---------------------------------------------------");

    return $ret;

}

=head2 AnarchyTestCases function

Check the testcase profile for the correct testparms (FAILTYPE) and calls the AnarchyLoop function



=cut

=over 1

=item Usage:

 my $rc = AnarchyTestCases($coPtr, $PDInfoPtr, $tcLoopCount, $modePageData, $tcDelay);
 
 where,
        $coPtr is a pointer to a list of controller objects
        $PDInfoPtr is the PID for the drives to inject error on
        $tcLoopCount is the number of loop of executing the same command before going to the next testcase
        $modePageData is the mode page data that triggers error injection on the drive
        $tcDelay is the delay between executions of each command within a loop         


=item Returns:

       $rc GOOD if valid, ERROR otherwise. 

=item Description:
 
 Checks the method against a list of valid values.

=back

=cut

##############################################################################
#
#          Name: AnarchyTestCases
#
#        Inputs: $coPtr, $PDInfoPtr, $tcLoopCount, $modePageData, $tcDelay
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  Uses Seagate Mode Page 25 to set Anarchy Drive for error conditions.  
##############################################################################
sub AnarchyTestCases
{
    trace();
    my ($coPtr, $PDInfoPtr, $tcLoopCount, $modePageData, $tcDelay) = @_;

    my $ret;
    my $writeBuffer = "000000";
    my $i;
    $ret = GOOD;
    my %PDInfo = %$PDInfoPtr;
    my %FunctionRet;
    my @FunctionRet = %FunctionRet;
    my @coList;
    @coList = @$coPtr;

    #
    # Find the Master Controller
    #
    my $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );

    if ( $newMaster == INVALID )
    {
        logError("    ====> Failed to find the master controller at beginning of the test <====");
        return ERROR;
    }

    CtlrLogTextAll( $coPtr, "----------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "                  Starting Anarchy Test                   ");
    CtlrLogTextAll( $coPtr, "                  LoopCount: $tcLoopCount                 ");
    CtlrLogTextAll( $coPtr, "                  ModePage:  $modePageData                ");
    CtlrLogTextAll( $coPtr, "                  Delay:     $tcDelay                     ");
    CtlrLogTextAll( $coPtr, "----------------------------------------------------------");

    for ( $i = 0; $i < $tcLoopCount; $i++ )
    {
    #TestLibs::utility::AsciiHexToBin(, "byte")
        $writeBuffer = TestLibs::utility::AsciiHexToBin($modePageData,"byte");

        #
        # Using ModeSelect to send the mode settings to the drive
        #
         
                  ($ret, %FunctionRet) = TestLibs::SCSI::SCSIModeSelect10($coList[$newMaster], 
                                                         $PDInfo{WWN_HI}, 
                                                         $PDInfo{WWN_LO},
                                                         $PDInfo{PD_LUN},
                                                         $writeBuffer);                                   
        if (! %FunctionRet )        
        {
            print ("     >>>>>>>>>> no response from Mode Sense - cannot continue <<<<<<<<<<<\n");
            return ERROR;

        }



        if ( $FunctionRet{STATUS} != PI_GOOD )
        {
            logInfo("    ====> Error generated while Viewing the Mode Page settings. Test fails.  <====");
            logInfo("    ====> Verify correct PID is being used for Anarchy drive.                <====");
            logInfo(sprintf("            WWN: %8.8X%8.8X ", $PDInfo{WWN_LO}, $PDInfo{WWN_HI} ));                                            
   

            return ERROR;
        } 
        
        DelaySecs($tcDelay);
 
    }
    return $ret;
}




1;
__END__

=head1 NAME

NAME OF THE MODULE

TestLibs::Anarchycode - Anarchycode used by TestLibs

$Id: AnarchyCode.pm 12236 2006-07-31 15:19:45Z EidenN $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

  use TestLibs::Anarchycode;

=head1 DESCRIPTION

AnarchyCode should be used when developing tests to work with error injection code from Seagate.  Checking for
the correct code is supported by attempting to read mode page 25.

=head1 AUTHOR
Neal Eiden neal_eiden@xiotech.com

=head1 CHANGELOG

$Log$
Revision 1.8  2006/07/31 15:19:45  EidenN
tbolt00000000
Updated parms

Revision 1.7  2006/07/09 16:34:54  EidenN
tbolt00000000
Updated parms

Revision 1.6  2006/07/07 12:37:34  EidenN
tbolt00000000
Updated comments

Revision 1.5  2006/07/07 12:17:03  EidenN
tbolt00000000
Added support for 21 test cases built from the new Anarchy code.  Removed ModeSelect6 and replaced with ModeSelect10.  Better logging and cleanup support.

Revision 1.4  2006/07/05 16:19:43  EidenN
Tbolt00000000
Updated code from Seagate.  Added support for 21 cases

Revision 1.3  2005/12/21 22:56:35  EidenN
no message

Revision 1.2  2005/06/03 13:57:52  EidenN
tbolt00000000:   Fixed mode page issue

Revision 1.1.1.1  2005/05/04 18:53:51  RysavyR
import CT1_BR to shared/Wookiee

Revision 1.5  2005/04/01 15:51:28  EidenN
Tbolt00000:  Correct error in modes

Revision 1.4  2005/03/02 18:16:59  EidenN
Tbolt0000000:Fixed end header section to show history    Reviewed By:  FlemingS


=cut

