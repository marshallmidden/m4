#! /usr/bin/perl s
# $Header$
####s##########################################################################
# File name:  TestLibs::SCSI
#
# Desc: A set of library functions for calling SCSI commands targeted for the Storage Devices via the CCBE.
#
# Date: 08/30/2002
#
# Original Author:  Jeff Werning
#
# Last modified by  $Author: EidenN $
# Modified date     $Date: 2006-07-07 07:15:55 -0500 (Fri, 07 Jul 2006) $
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################
=pod
=head1 NAME

TestLibs::SCSI - Perl Functions to Execute SCSI Commands to the XIOtech Storage Devices via the CCBE

$Id: SCSI.pm 11495 2006-07-07 12:15:55Z EidenN $

=head1 SUPPORTED Devices

=begin html

<UL>
    <LI>Drive</LI>
    <LI>Drive Enclosure</LI>
</UL>

=end html

=head1 SYNOPSIS

This document describes usuage of the Perl Scripts to Execute SCSI Commands to the XIOtech Storage Devices

=head1 DESCRIPTION

SCSI Commands Available
    TestUnitReady
    SCSIRead
    SCSIWrite

=cut

#                         
# - what I am
#

package TestLibs::SCSI;

#
# - other modules used
#

use warnings;
use lib "../../CCBE";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
#use XIOTech::logMgr;
use TestLibs::Logging;
use TestLibs::Constants;
#use TestLibs::IntegCCBELib;
#use TestLibs::IntegXMCLib;
use Dumpvalue;

my $dumper = new Dumpvalue;

#
# - perl compiler/interpreter flags 'n' things
#

#use strict;

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      &getPIDInfo
                      &SCSITUR
                      &SCSIFormat
                      &SCSIRead
                      &SCSIWrite
                      &SCSIReadLong
                      &SCSIWriteLong
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 11495 $);
}
    our @EXPORT_OK;


########################################################################
### Function name: SCSICommand
###
### Purpose: Send a SCSI Test Unit Ready command
##
## INPUT:   Controller Obj, Device WWN Hi, WWN Lo, Lun, CDB, Pointers => Read Buffer, Write Buffer
## OUTPUT:  ood  or ERROR, Return of CCBE Response Hash or undefined
##          
## Write Data must be binary, not ASCII         
##          
## The Response Hash from CCBE Contains the Following Keys:         
##          
##  'ADTL_SENSE_CODE'
##  'STATUS'
##  'ERROR_CODE'
##  'DATA'         
##  'SENSE_KEY'
##  'ADTL_SENSE_CODE_QUAL'
##          
#######################################################################

sub SCSICommand
{
    trace();                        # This allows function tracability

    my ($controller, $wwnHi, $wwnLo, $lun, $cdb, $readDataPtr, $writeDataPtr) = @_;

    my @deviceID;
    my $cdbBin;

    #
    # Parse CDB
    #
    if (!defined($cdb))
    {
        TestLibs::Logging::logWarning ("Missing CDB on SCSI Command");
        return ERROR, undef;
    }

    TestLibs::Logging::debug ("SCSI CDB Issued:$cdb");
    $cdbBin = TestLibs::utility::AsciiHexToBin($cdb, "byte");
    if(!defined $cdb) 
    {
        TestLibs::Logging::logWarning ("Invalid CDB format for SCSI command");
        return ERROR, undef;
    }

    #
    # Set WWN/LUN
    #
    if (defined($wwnHi) && defined($wwnLo) && defined($lun))
    {
        $deviceID[0]{WWN_LO} = $wwnLo;
        $deviceID[0]{WWN_HI} = $wwnHi;
        $deviceID[0]{PD_LUN} = $lun;
    }
    else
    {
        TestLibs::Logging::logWarning ("Invalid WWN / LUN for SCSI command");
        return ERROR, undef;
    }

    #
    # Call the scsi cmd handler
    #
    my %rsp = $controller->scsiCmd($cdbBin, $$writeDataPtr, @deviceID);
#$dumper->dumpValues(%rsp);
    if (%rsp)
    {
        #
        # If successful, format the output data
        #
        if ($rsp{STATUS} == PI_GOOD)
        {
#            TestLibs::Logging::logInfo ("SCSI Commmad CDB:$cdb successful");
            if(defined($readDataPtr)) 
            {
                $$readDataPtr = $rsp{DATA};
#                $controller->FormatData($rsp{DATA}, 0x00000000,
#                    "byte", undef, 1024);
            }
        }
        #
        # If failure, display sense data
        #
        else
        {
#$dumper->dumpValues(%rsp);
#            TestLibs::Logging::logWarning ("SCSI Commmad CDB:$cdb failed");
#
#            printf "Sense Key:      0x%02X\n", $rsp{SENSE_KEY};
#            printf "Sense Code:     0x%02X\n", $rsp{ADTL_SENSE_CODE};
#            printf "Sense Code Qual:0x%02X\n", $rsp{ADTL_SENSE_CODE_QUAL};
            return ERROR, %rsp;
        }
    }
    else
    {
        print "ERROR: Did not receive a response packet from SCSI command.\n";
        return ERROR, %rsp;
    }

# Debug
#$dumper->dumpValues(%rsp);

    return GOOD, %rsp;

}

########################################################################
### Function name: SCSITUR
###
### Purpose: Send a SCSI Test Unit Ready command
##
## INPUT:   Controller Obj, Device WWN Hi, WWN Lo, Lun
## OUTPUT:  Return of CCBE Response Hash or ERROR
#######################################################################

sub SCSITUR
{
    trace();                        # This allows function tracability

    my ($controller, $wwnHi, $wwnLo, $lun) = @_;

    my $returnValue;
    
    my $cdb = "000000000000";         # TUR CDB

    # Generic SCSI Command (Controller Obj, Upper WWN, Lower WWN, LUN, CDB, Read Data, Write Data Pointers)
    return SCSICommand($controller, $wwnHi, $wwnLo, $lun, $cdb, undef, undef);

}

########################################################################
### Function name: SCSIFormat
###
### Purpose: Send a SCSI Test Unit Ready command
##
## INPUT:   Controller Obj, Device WWN Hi, WWN Lo, Lun
## OUTPUT:  Return of CCBE Response Hash or ERROR
#######################################################################

sub SCSIFormat
{
    trace();                        # This allows function tracability

    my ($controller, $wwnHi, $wwnLo, $lun) = @_;

    my $returnValue;
    my $defectHeader;
    
    my $cdb = "040000000000";        # Format CDB

    # Format defectHeader
    $defectHeader = TestLibs::utility::AsciiHexToBin("00020000", "byte");
#    $defectHeader = TestLibs::utility::AsciiHexToBin("00000000", "byte");

    # Insert FmtData Bit into CDB
    substr($cdb, 2, 1, 1); 

    # Generic SCSI Command (Controller Obj, Upper WWN, Lower WWN, LUN, CDB, Read Data, Write Data Pointers)
    return SCSICommand($controller, $wwnHi, $wwnLo, $lun, $cdb, undef, \$defectHeader);

}

########################################################################
### Function name: SCSIRead
###
### Purpose: Send a SCSI Read 10 command
##
## INPUT:    Controller Obj, WWN Hi, WWN Lo, Lun, LBA, Length (hex), Pointer => Read Buffer
## UPDATED:  WWN Hi, WWN Lo, Lun
## OUTPUT:   Return of CCBE Response Hash or ERROR
#######################################################################

sub SCSIRead
{
    trace();                        # This allows function tracability

    my ($controller, $wwnHi, $wwnLo, $lun, $lba, $length, $readBufferPtr) = @_;

    my $returnValue;

    # Read 10 CDB, FUA bit set
              #00112233445566778899
    my $cdb = "28080000000000000000"; 

    # Insert LUN into CDB
    $lun = $lun * 2;                # Shift up 1 bit
    $lun = sprintf("%01X", $lun);
    substr($cdb, 2, 1, $lun); 

    # Insert LBA into CDB
    $lba = sprintf("%08X", $lba);
    substr($cdb, 4, 8, $lba); 

    # Insert Transfer Length into CDB
    $length = sprintf("%04X", $length);
    substr($cdb, 14, 4, $length); 

    # Generic SCSI Command (Controller Obj, Upper WWN, Lower WWN, LUN, CDB, Read Data Pointer, Write Data Pointer)
    return SCSICommand($controller, $wwnHi, $wwnLo, $lun, $cdb, $readBufferPtr, undef);

}

########################################################################
### Function name: SCSIWrite
###
### Purpose: Send a SCSI Write 10 command
##
## INPUT:    Controller Obj, WWN Hi, WWN Lo, Lun, LBA, Length (hex), Pointer => Read Buffer
## UPDATED:  WWN Hi, WWN Lo, Lun
## OUTPUT:   Return of CCBE Response Hash or ERROR
##          
## Write Data must be binary, not ASCII         
##          
## The Response Hash from CCBE Contains the Follwing Keys:         
##          
##  'ADTL_SENSE_CODE'
##  'STATUS'
##  'ERROR_CODE'
##  'DATA'         
##  'SENSE_KEY'
##  'ADTL_SENSE_CODE_QUAL'
##          
#######################################################################

sub SCSIWrite
{
    trace();                        # This allows function tracability

    my ($controller, $wwnHi, $wwnLo, $lun, $lba, $length, $writeBufferPtr) = @_;

    my $returnValue;

    # Write 10 CDB, FUA bit set
              #00112233445566778899
    my $cdb = "2A080000000000000000"; 

    # Insert LUN into CDB
    $lun = $lun * 2;                # Shift up 1 bit
    $lun = sprintf("%01X", $lun);
    substr($cdb, 2, 1, $lun); 

    # Insert LBA into CDB
    $lba = sprintf("%08X", $lba);
    substr($cdb, 4, 8, $lba); 

    # Insert Transfer Length into CDB
    $length = sprintf("%04X", $length);
    substr($cdb, 14, 4, $length); 

    # Generic SCSI Command (Controller Obj, Upper WWN, Lower WWN, LUN, CDB, Read Data Pointer, Write Data Pointer)
    return SCSICommand($controller, $wwnHi, $wwnLo, $lun, $cdb, undef, $writeBufferPtr);

}

########################################################################
### Function name: SCSIReadLong
###
### Purpose: Send a SCSI ReadLong command
##
## INPUT:    Controller Obj, WWN Hi, WWN Lo, Lun, LBA, Length (hex),
##           Pointer => Read Buffer, Correct <0,1>
## UPDATED:  WWN Hi, WWN Lo, Lun
## OUTPUT:   Return of CCBE Response Hash or ERROR
#######################################################################

sub SCSIReadLong
{
    trace();                        # This allows function tracability

    my ($controller, $wwnHi, $wwnLo, $lun, $lba, $length, $readBufferPtr, $correct) = @_;

    my $returnValue;

    # ReadLong CDB
              #00112233445566778899
    my $cdb = "3E000000000000000000"; 

    # Insert LUN into CDB
    $lun = $lun * 2;                # Shift up 1 bit
    $lun = sprintf("%01X", $lun);
    substr($cdb, 2, 1, $lun); 

    # Insert Correct Bit into CDB
    if ($correct == 1)
    {
        substr($cdb, 3, 1, 2); 
    }

    # Insert LBA into CDB
    $lba = sprintf("%08X", $lba);
    substr($cdb, 4, 8, $lba); 

    # Insert Transfer Length into CDB
    $length = sprintf("%04X", $length);
    substr($cdb, 14, 4, $length); 

    # Generic SCSI Command (Controller Obj, Upper WWN, Lower WWN, LUN, CDB, Read Data Pointer, Write Data Pointer)
    return SCSICommand($controller, $wwnHi, $wwnLo, $lun, $cdb, $readBufferPtr, undef);

}

########################################################################
### Function name: SCSIWriteLong
###
### Purpose: Send a SCSI WriteLong command
##
## INPUT:    Controller Obj, WWN Hi, WWN Lo, Lun, LBA, Length (hex),
##           Pointer => Read Buffer
## UPDATED:  WWN Hi, WWN Lo, Lun
## OUTPUT:   Return of CCBE Response Hash or ERROR
#######################################################################

sub SCSIWriteLong
{
    trace();                        # This allows function tracability

    my ($controller, $wwnHi, $wwnLo, $lun, $lba, $length, $writeBufferPtr) = @_;

    my $returnValue;

    # WriteLong CDB
              #00112233445566778899
    my $cdb = "3F000000000000000000"; 

    # Insert LUN into CDB
    $lun = $lun * 2;                # Shift up 1 bit
    $lun = sprintf("%01X", $lun);
    substr($cdb, 2, 1, $lun); 

    # Insert LBA into CDB
    $lba = sprintf("%08X", $lba);
    substr($cdb, 4, 8, $lba); 

    # Insert Transfer Length into CDB
    $length = sprintf("%04X", $length);
    substr($cdb, 14, 4, $length); 

    # Generic SCSI Command (Controller Obj, Upper WWN, Lower WWN, LUN, CDB, Read Data Pointer, Write Data Pointer)
    return SCSICommand($controller, $wwnHi, $wwnLo, $lun, $cdb, undef, $writeBufferPtr);

}

########################################################################
### Function name: getPIDInfo
###
### Purpose: Send a SCSI Test Unit Ready command
##
## INPUT:    Controller Obj, PDisk ID, Pointers => Device WWN Hi, WWN Lo, Lun
## UPDATED:  WWN Hi, WWN Lo, Lun
## OUTPUT:   Return of GOOD or ERROR
##
#######################################################################

sub getPIDInfo
{
    trace();                        # This allows function tracability

    my ($controller, $pid, $wwnHiPtr, $wwnLoPtr, $lunPtr) = @_;

    my $returnValue;
    
    #
    # Retrieve WWN/LUN from the specified physical disk
    #
    my %pdisks = $controller->physicalDiskInfo($pid);
    if (%pdisks)
    {
        if ($pdisks{STATUS} == PI_GOOD)
        {
            $$wwnLoPtr = $pdisks{WWN_LO};
            $$wwnHiPtr = $pdisks{WWN_HI};
            $$lunPtr = $pdisks{PD_LUN};
        }
        else
        {
            TestLibs::Logging::logWarning("ERROR: Unable to retrieve pdisk info");
            return ERROR;
        }
    }
    else
    {
        TestLibs::Logging::logWarning("ERROR: Did not receive a response packet from physicalDiskInfo()");                       return ERROR;
        return ERROR;
    }


    return GOOD;
}

########################################################################
### Function name: PrintResponse
###
### Purpose: Print out the sense data returned from a SCSI command
##
## INPUT:    Response Hash
## OUTPUT:   Return of GOOD or ERROR
##
#######################################################################

sub PrintResponse
{
    trace();                        # This allows function tracability

    my (%rsp) = @_;


    printf "Sense Key:      0x%02X\n", $rsp{SENSE_KEY};
    printf "Sense Code:     0x%02X\n", $rsp{ADTL_SENSE_CODE};
    printf "Sense Code Qual:0x%02X\n", $rsp{ADTL_SENSE_CODE_QUAL};

#                $controller->FormatData($rsp{DATA}, 0x00000000,
#                    "byte", undef, 64);

    return GOOD;
}

########################################################################
### Function name: SCSIModeSense10
###
### Purpose: Mode Sense command (10 Byte)
##
## INPUT:    Controller Obj, WWN Hi, WWN Lo, Lun, Length (hex), $page
## OUTPUT:   Return of CCBE Response Hash or ERROR
##          
## Write Data must be binary, not ASCII         
##          
## The Response Hash from CCBE Contains the Follwing Keys:         
##          
##  'ADTL_SENSE_CODE'
##  'STATUS'
##  'ERROR_CODE'
##  'DATA'         
##  'SENSE_KEY'
##  'ADTL_SENSE_CODE_QUAL'
##          
#######################################################################
sub SCSIModeSense10
{
    my ($controller, $wwnHi, $wwnLo, $lun, $length,  $page) = @_;

    my $returnValue;

    # Write 10 CDB, FUA bit set
    my $cdb = sprintf("5A00%02x00000000010000",$page); 

    # Insert LUN into CDB
    $lun = $lun * 2;                # Shift up 1 bit
    $lun = sprintf("%01X", $lun);
    substr($cdb, 2, 1, $lun); 

    # Insert Transfer Length into CDB
    $length = sprintf("%04X", $length);
    substr($cdb, 14, 4, $length); 

    # Generic SCSI Command (Controller Obj, Upper WWN, Lower WWN, LUN, CDB, Read Data Pointer, Write Data Pointer)
    return TestLibs::SCSI::SCSICommand($controller, $wwnHi, $wwnLo, $lun, $cdb, undef, undef);

}





########################################################################
### Function name: SCSIModeSelect10
###
### Purpose: Mode Select command (10 byte)
##
## INPUT:    Controller Obj, WWN Hi, WWN Lo, Lun, $page, $writeBufferPtr
## 
## OUTPUT:   Return of CCBE Response Hash or ERROR
##          
## Write Data must be binary, not ASCII         
##          
## The Response Hash from CCBE Contains the Follwing Keys:         
##          
##  'ADTL_SENSE_CODE'
##  'STATUS'
##  'ERROR_CODE'
##  'DATA'         
##  'SENSE_KEY'
##  'ADTL_SENSE_CODE_QUAL'
##          
#######################################################################
sub SCSIModeSelect10
{
    my ($controller, $wwnHi, $wwnLo, $lun, $writeBufferPtr) = @_;

    my $returnValue;

    my $cdb; 
   
    $cdb = "55110000000000". sprintf("%04X", length($writeBufferPtr)). "00";
    $cdb = TestLibs::utility::AsciiHexToBin($cdb,"byte");
    
    # Generic SCSI Command (Controller Obj, Upper WWN, Lower WWN, LUN, CDB, Read Data Pointer, Write Data Pointer)
    return TestLibs::SCSI::SCSICommand($controller, $wwnHi, $wwnLo, $lun, $cdb, undef, \$writeBufferPtr);

}

########################################################################
### Function name: SCSIModeSelect6
###
### Purpose: Mode Select command (6 byte)
##
## INPUT:    Controller Obj, WWN Hi, WWN Lo, Lun, $page, $writeBufferPtr
## 
## OUTPUT:   Return of CCBE Response Hash or ERROR
##          
## Write Data must be binary, not ASCII         
##          
## The Response Hash from CCBE Contains the Follwing Keys:         
##          
##  'ADTL_SENSE_CODE'
##  'STATUS'
##  'ERROR_CODE'
##  'DATA'         
##  'SENSE_KEY'
##  'ADTL_SENSE_CODE_QUAL'
##          
#######################################################################
sub SCSIModeSelect6
{
    my ($controller, $wwnHi, $wwnLo, $lun, $writeBufferPtr) = @_;

    my $returnValue;

    my $cdb; 
   
    $cdb = "151000". sprintf("%04X", length($$writeBufferPtr)). "00";
    
    # Generic SCSI Command (Controller Obj, Upper WWN, Lower WWN, LUN, CDB, Read Data Pointer, Write Data Pointer)
    return TestLibs::SCSI::SCSICommand($controller, $wwnHi, $wwnLo, $lun, $cdb, undef, $writeBufferPtr);

}


########################################################################
### Function name: SCSIWriteCacheDisable
###
### Purpose: Disables Write Cache on all Pdisks
##
## INPUT:    Controller Obj{Master}
## 
## OUTPUT:   Return of CCBE Response Hash or ERROR
##          
## Write Data must be binary, not ASCII         
##          
## The Response Hash from CCBE Contains the Follwing Keys:         
##          
##  'ADTL_SENSE_CODE'
##  'STATUS'
##  'ERROR_CODE'
##  'DATA'         
##  'SENSE_KEY'
##  'ADTL_SENSE_CODE_QUAL'
##          
#######################################################################
sub SCSIWriteCacheDisable
{
my ($obj1) = @_;


my %pdisks;
my $i;
my $wwnHi;
my $wwnLo;
my $lun;
my $j;

my $byte;
my %senseData;
my $msg2;
my $msg;
my $pageStart;
my $pgNum;
my $fmt;
my $drv;
my $dLen;
my $wcBitLoc;
my $buffer;
my $inf;
our $opt_l;
our $opt_u;
our $opt_i;
my $len2;
my $len1;
my $len0;
my $part2;
my $part1;
my $part0;
my $pagesValid;
my %selectResp;
my @p0;

use constant WCBITVAL => 4;

#
# get pdisks data
#

%pdisks = $obj1->physicalDisks();

if (! %pdisks )        
{
    print (">>>>>>>>>> no response from pdisks - cannot continue <<<<<<<<<<<\n");
    exit(1);
}

if ( $pdisks{STATUS} != PI_GOOD )
{
    print (">>>>>>>>>> Error from pdisks - cannot continue <<<<<<<<<<<\n");
    PrintError(%pdisks);
    exit(1);
}

# data is good, now scan it

for ( $i = 0; $i < $pdisks{COUNT} ; $i++ )
{
    
    print "\n--------------------------------------------------------------------------\n\n";
    
    if ( $pdisks{PDISKS}[$i]{PD_DEVSTAT} == 0x10 )      # only look at operational drives   ask Jeff about criteria
    {
        $wwnHi = $pdisks{PDISKS}[$i]{WWN_HI};
        $wwnLo = $pdisks{PDISKS}[$i]{WWN_LO};
        $lun =  $pdisks{PDISKS}[$i]{PD_LUN};
        $msg = sprintf("Pdisk #%3d: PID %3d, WWN %8.8X%8.8X", 
               $i,
               $pdisks{PDISKS}[$i]{PD_PID}, 
               $wwnLo, 
               $wwnHi);
        #
        # print extra info about the drive, if requested
        #
        if ( $extraInfo )
        {
            $drv = $pdisks{PDISKS}[$i]{PS_PRODID};
            $drv = join ('', split(/\s+/,$drv));     # Remove any spaces
            $msg .= sprintf(", Prod ID %16s, FW_REV %4s, Serial %12s, bay %2d, slot %2d",
                    $drv,
                    $pdisks{PDISKS}[$i]{PD_REV},
                    $pdisks{PDISKS}[$i]{PS_SERIAL}, 
                    $pdisks{PDISKS}[$i]{SES},
                    $pdisks{PDISKS}[$i]{SLOT},
                    );
        }
        #
        # get the mode page and check write cache bit
        #

        ($ret, %senseData) = SCSIModeSense10($obj1, $wwnHi, 
                                    $wwnLo, $lun, 
                                    64, 8);

        if (! %senseData )        
        {
            print $msg;
            print ("\n\nFor PID $pdisks{PDISKS}[$i]{PD_PID}, \n");
            print ("     >>>>>>>>>> no response from Mode Sense - cannot continue <<<<<<<<<<<\n");
            exit(1);
        }

        if ( $senseData{STATUS} != PI_GOOD )
        {
            print $msg;
            print ("\n\nFor PID $pdisks{PDISKS}[$i]{PD_PID}, \n");
            print ("    >>>>>>>>>> Error from Mode Sense - cannot continue <<<<<<<<<<<\n");
            PrintError(%senseData);
            exit(1);
        }

                    #######################################################
                    # debug stuff
                    #
                    if ( 0 ) 
                    {
                        print "sense data:\n";
                        #for ($j = 0; $j < length($senseData{DATA}); $j++)
                        for ($j = 0; $j < 36; $j++)
                        {
                            $byte = sprintf("x%d c",$j);
                            $byte = unpack($byte, $senseData{DATA});
                            $msg2 = sprintf("%2.2X ",$byte & 0xff);
                            print $msg2;
                            if ((($j+1) % 8) == 0) {print "- ";}
                            if ((($j+1) % 16) == 0) {print "\n";}
                        }
                        print "\n";   
                    }
                    #######################################################
        #
        # pick apart the packet to find the offset to the data we need
        #
        
       
        ($dl) = unpack("n", $senseData{DATA});      # data length following 
                                                    # first two bytes
        ($bdl) = unpack ("x7C", $senseData{DATA});  # block Descripter length
        $pageStart = 8 + $bdl;                      # start of first page
        
        $fmt = sprintf("x%dC", $pageStart);          # offset to bage number
        $pgNum = 0x7f & unpack ($fmt, $senseData{DATA});   # get page number                                        
        # print "\npage $pgNum at offset $pageStart \n";
        $fmt =  sprintf("x%dC", ($pageStart + 1));   # offset to data len
        $dLen = unpack ($fmt, $senseData{DATA});     # data bytes in page
        
        #
        # Walk pages until we find page 8
        #
        $pagesValid = 1;
        while ( ($pgNum != 8) && ($pagesValid == 1) )
        {
            if ( ($pgNum == 0) || ($dLen == 00 ) )
            {
                # page or length is 0, this is not good
                print "\n>>>>> Invalid mode page data detected - cannot process. <<<<<\n";
                print $msg;
                print "\n\n";
                $pagesValid = 0;
                #exit 1;
                next;
            }
            $pageStart = $pageStart + 2 + $dLen;         # advance to next page
            $fmt = sprintf("x%dC", $pageStart);          # offset to bage number
            $pgNum = 0x7f & unpack ($fmt, $senseData{DATA});   # get page number                                        
            print "page $pgNum at offset $pageStart  \n";
            $fmt =  sprintf("x%dC", ($pageStart + 1));   # offset to data len
            $dLen = unpack ($fmt, $senseData{DATA});     # data bytes in page
        }
        
                    #######################################################
                    # debug stuff  -  print page 8
                    if ( 0 ) 
                    {
                        print "mode page 8: \n";
                        for ($j = 0; $j < (2 + $dLen); $j++)
                        {
                            $byte = sprintf("x%d c", ($j + $pageStart));
                            $byte = unpack($byte, $senseData{DATA});
                            $msg2 = sprintf("%2.2X ",$byte & 0xff);
                            print $msg2;
                            if ((($j+1) % 8) == 0) {print "- ";}
                        }
                        print "\n";   
                    }
                    #######################################################
        
        if ($pagesValid == 0)
        {
            # skipt the rest of the loop as the page data is not valid
            next;
        }
        
        #
        # we know where page 8 is, dig out the WC bit and breal the buffer
        # into parts to work with
        #
        $wcBitLoc =  $pageStart + 2;
        $fmt =  sprintf("x%dC", $wcBitLoc);   # offset to data byte
        $wcVal = unpack($fmt, $senseData{DATA});
        $wcState = "disabled";
        if ($wcVal & WCBITVAL) {$wcState = "enabled";}
        $msg .= sprintf(", WC %8s", $wcState);
        
        # get the header
        $len0 = $wcBitLoc - 2;
        $part0 = substr($senseData{DATA}, 0, $len0);
        
        # get the (page length)
        $len1 = $wcBitLoc - $pageStart;
        $part1 = substr($senseData{DATA}, $pageStart + 1, $len1 - 1);
        
        # get the bytes after the wc byte
        $len2 = $dl + 2 - $wcBitLoc - 1;
        $part2 = substr($senseData{DATA}, ($wcBitLoc + 1), $len2);

        @p0 = unpack("C16", $senseData{DATA});
        $p0[1] = 0;
        $p0[3] = 0;
        $p0[8] = 0;
        $p0[9] = 0;
        $p0[10] = 0;
        $p0[11] = 0;
        $part0 = pack("C16",@p0);
        
        # print ("doUpdate = $doUpdate, wcState = $wcState, len0 = $len0, len1 = $len1, len2 = $len2 \n");

        if ( $doUpdate && ($wcState eq "enabled") )
        #if ( $doUpdate  )
        {
            #
            # we have to change the mode page, need to update the bit
            # in $senseData{DATA} offset $wcBitLoc and send the page
            # back to the drive
            # 

            #
            # This line changes the write cache bit 
            #
            $wcVal = $wcVal & ~WCBITVAL;           # disable
            #$wcVal = $wcVal | WCBITVAL;           # enable
            
            $msg .= ", - updating...";
            $fmt = sprintf("a%d C a%d C a%d", $len0, ($len1 - 1), $len2); 
            $buffer = pack($fmt, $part0,  0x08, $part1, $wcVal, $part2); 
            
                    #######################################################
                    # debug stuff  -  print page 8
                    if ( 0 ) 
                    {
                        print "    mode page 8: \n";
                        for ($j = 0; $j < (2 + $dLen); $j++)
                        {
                            $byte = sprintf("x%d c", ($j + $pageStart));
                            $byte = unpack($byte, $senseData{DATA});
                            $msg2 = sprintf("%2.2X ",$byte & 0xff);
                            print $msg2;
                            if ((($j+1) % 8) == 0) {print "- ";}
                        }
                        print "\n";   
                    }
            
                    # debug stuff  -  print modified buffer
                    if ( 0 ) 
                    {
                        print "modified buffer: \n";
                        for ($j = 0; $j < length($buffer); $j++)
                        {
                            $byte = sprintf("x%d c", $j);
                            $byte = unpack($byte, $buffer);
                            $msg2 = sprintf("%2.2X ", ($byte & 0xff));
                            print $msg2;
                            if ((($j+9) % 16) == 0) {print "- ";}
                            if ((($j+1) % 16) == 0) {print "\n";}
                        }
                        print "\n";   
                    }
                    #######################################################
            
            print $msg;
            
            ($ret, %selectResp) = SCSIModeSelect10($obj1, $wwnHi, 
                                                 $wwnLo, $lun,
                                                 \$buffer);
            
            if (! %selectResp )        
            {
                $msg = "\nUpdate failed.\n";
                print ("\n\nFor PID $pdisks{PDISKS}[$i]{PD_PID}, \n");
                print ("     >>>>>>>>>> no response from Mode Select - drive not updated <<<<<<<<<<<\n");
                #exit(1);
            }
            elsif ( $selectResp{STATUS} != PI_GOOD )
            {
                $msg = "\nUpdate failed.\n";;
                print ("\n\nFor PID $pdisks{PDISKS}[$i]{PD_PID}, \n");
                print ("    >>>>>>>>>> Error from Mode Select - drive not updated <<<<<<<<<<<\n");
                PrintError(%selectResp);
                        print ("cmd returned : $ret \n");
                        print %selectResp;
                        print " \n";
                #exit(1);
            }
            else
            {    
                $msg = "done.";
                #$senseData{DATA}   
            }

        }


        $msg .= "\n";
        print $msg;
    }
  return GOOD  
}
}

########################################################################
### Function name: SCSIWriteCacheEnable
###
### Purpose: Enables Write Cache on all Pdisks
##
## INPUT:    Controller Obj{Master}
## 
## OUTPUT:   Return of CCBE Response Hash or ERROR
##          
## Write Data must be binary, not ASCII         
##          
## The Response Hash from CCBE Contains the Follwing Keys:         
##          
##  'ADTL_SENSE_CODE'
##  'STATUS'
##  'ERROR_CODE'
##  'DATA'         
##  'SENSE_KEY'
##  'ADTL_SENSE_CODE_QUAL'
##          
#######################################################################
sub SCSIWriteCacheEnable
{
my ($obj1) = @_;


my %pdisks;
my $i;
my $wwnHi;
my $wwnLo;
my $lun;
my $j;

my $byte;
my %senseData;
my $msg2;
my $msg;
my $pageStart;
my $pgNum;
my $fmt;
my $drv;
my $dLen;
my $wcBitLoc;
my $buffer;
my $inf;
our $opt_l;
our $opt_u;
our $opt_i;
my $len2;
my $len1;
my $len0;
my $part2;
my $part1;
my $part0;
my $pagesValid;
my %selectResp;
my @p0;



#
# get pdisks data
#

%pdisks = $obj1->physicalDisks();

if (! %pdisks )        
{
    print (">>>>>>>>>> no response from pdisks - cannot continue <<<<<<<<<<<\n");
    exit(1);
}

if ( $pdisks{STATUS} != PI_GOOD )
{
    print (">>>>>>>>>> Error from pdisks - cannot continue <<<<<<<<<<<\n");
    PrintError(%pdisks);
    exit(1);
}

# data is good, now scan it

for ( $i = 0; $i < $pdisks{COUNT} ; $i++ )
{
    
    print "\n--------------------------------------------------------------------------\n\n";
    
    if ( $pdisks{PDISKS}[$i]{PD_DEVSTAT} == 0x10 )      # only look at operational drives   ask Jeff about criteria
    {
        $wwnHi = $pdisks{PDISKS}[$i]{WWN_HI};
        $wwnLo = $pdisks{PDISKS}[$i]{WWN_LO};
        $lun =  $pdisks{PDISKS}[$i]{PD_LUN};
        $msg = sprintf("Pdisk #%3d: PID %3d, WWN %8.8X%8.8X", 
               $i,
               $pdisks{PDISKS}[$i]{PD_PID}, 
               $wwnLo, 
               $wwnHi);
        #
        # print extra info about the drive, if requested
        #
        if ( $extraInfo )
        {
            $drv = $pdisks{PDISKS}[$i]{PS_PRODID};
            $drv = join ('', split(/\s+/,$drv));     # Remove any spaces
            $msg .= sprintf(", Prod ID %16s, FW_REV %4s, Serial %12s, bay %2d, slot %2d",
                    $drv,
                    $pdisks{PDISKS}[$i]{PD_REV},
                    $pdisks{PDISKS}[$i]{PS_SERIAL}, 
                    $pdisks{PDISKS}[$i]{SES},
                    $pdisks{PDISKS}[$i]{SLOT},
                    );
        }
        #
        # get the mode page and check write cache bit
        #

        ($ret, %senseData) = SCSIModeSense10($obj1, $wwnHi, 
                                    $wwnLo, $lun, 
                                    64, 8);

        if (! %senseData )        
        {
            print $msg;
            print ("\n\nFor PID $pdisks{PDISKS}[$i]{PD_PID}, \n");
            print ("     >>>>>>>>>> no response from Mode Sense - cannot continue <<<<<<<<<<<\n");
            exit(1);
        }

        if ( $senseData{STATUS} != PI_GOOD )
        {
            print $msg;
            print ("\n\nFor PID $pdisks{PDISKS}[$i]{PD_PID}, \n");
            print ("    >>>>>>>>>> Error from Mode Sense - cannot continue <<<<<<<<<<<\n");
            PrintError(%senseData);
            exit(1);
        }

                    #######################################################
                    # debug stuff
                    #
                    if ( 0 ) 
                    {
                        print "sense data:\n";
                        #for ($j = 0; $j < length($senseData{DATA}); $j++)
                        for ($j = 0; $j < 36; $j++)
                        {
                            $byte = sprintf("x%d c",$j);
                            $byte = unpack($byte, $senseData{DATA});
                            $msg2 = sprintf("%2.2X ",$byte & 0xff);
                            print $msg2;
                            if ((($j+1) % 8) == 0) {print "- ";}
                            if ((($j+1) % 16) == 0) {print "\n";}
                        }
                        print "\n";   
                    }
                    #######################################################
        #
        # pick apart the packet to find the offset to the data we need
        #
        
       
        ($dl) = unpack("n", $senseData{DATA});      # data length following 
                                                    # first two bytes
        ($bdl) = unpack ("x7C", $senseData{DATA});  # block Descripter length
        $pageStart = 8 + $bdl;                      # start of first page
        
        $fmt = sprintf("x%dC", $pageStart);          # offset to bage number
        $pgNum = 0x7f & unpack ($fmt, $senseData{DATA});   # get page number                                        
        # print "\npage $pgNum at offset $pageStart \n";
        $fmt =  sprintf("x%dC", ($pageStart + 1));   # offset to data len
        $dLen = unpack ($fmt, $senseData{DATA});     # data bytes in page
        
        #
        # Walk pages until we find page 8
        #
        $pagesValid = 1;
        while ( ($pgNum != 8) && ($pagesValid == 1) )
        {
            if ( ($pgNum == 0) || ($dLen == 00 ) )
            {
                # page or length is 0, this is not good
                print "\n>>>>> Invalid mode page data detected - cannot process. <<<<<\n";
                print $msg;
                print "\n\n";
                $pagesValid = 0;
                #exit 1;
                next;
            }
            $pageStart = $pageStart + 2 + $dLen;         # advance to next page
            $fmt = sprintf("x%dC", $pageStart);          # offset to bage number
            $pgNum = 0x7f & unpack ($fmt, $senseData{DATA});   # get page number                                        
            print "page $pgNum at offset $pageStart  \n";
            $fmt =  sprintf("x%dC", ($pageStart + 1));   # offset to data len
            $dLen = unpack ($fmt, $senseData{DATA});     # data bytes in page
        }
        
                    #######################################################
                    # debug stuff  -  print page 8
                    if ( 0 ) 
                    {
                        print "mode page 8: \n";
                        for ($j = 0; $j < (2 + $dLen); $j++)
                        {
                            $byte = sprintf("x%d c", ($j + $pageStart));
                            $byte = unpack($byte, $senseData{DATA});
                            $msg2 = sprintf("%2.2X ",$byte & 0xff);
                            print $msg2;
                            if ((($j+1) % 8) == 0) {print "- ";}
                        }
                        print "\n";   
                    }
                    #######################################################
        
        if ($pagesValid == 0)
        {
            # skipt the rest of the loop as the page data is not valid
            next;
        }
        
        #
        # we know where page 8 is, dig out the WC bit and breal the buffer
        # into parts to work with
        #
        $wcBitLoc =  $pageStart + 2;
        $fmt =  sprintf("x%dC", $wcBitLoc);   # offset to data byte
        $wcVal = unpack($fmt, $senseData{DATA});
        $wcState = "disabled";
        if ($wcVal & WCBITVAL) {$wcState = "enabled";}
        $msg .= sprintf(", WC %8s", $wcState);
        
        # get the header
        $len0 = $wcBitLoc - 2;
        $part0 = substr($senseData{DATA}, 0, $len0);
        
        # get the (page length)
        $len1 = $wcBitLoc - $pageStart;
        $part1 = substr($senseData{DATA}, $pageStart + 1, $len1 - 1);
        
        # get the bytes after the wc byte
        $len2 = $dl + 2 - $wcBitLoc - 1;
        $part2 = substr($senseData{DATA}, ($wcBitLoc + 1), $len2);

        @p0 = unpack("C16", $senseData{DATA});
        $p0[1] = 0;
        $p0[3] = 0;
        $p0[8] = 0;
        $p0[9] = 0;
        $p0[10] = 0;
        $p0[11] = 0;
        $part0 = pack("C16",@p0);
        
        # print ("doUpdate = $doUpdate, wcState = $wcState, len0 = $len0, len1 = $len1, len2 = $len2 \n");

        if ( $doUpdate && ($wcState eq "enabled") )
        #if ( $doUpdate  )
        {
            #
            # we have to change the mode page, need to update the bit
            # in $senseData{DATA} offset $wcBitLoc and send the page
            # back to the drive
            # 

            #
            # This line changes the write cache bit 
            #
            #$wcVal = $wcVal & ~WCBITVAL;           # disable
            $wcVal = $wcVal | WCBITVAL;           # enable
            
            $msg .= ", - updating...";
            $fmt = sprintf("a%d C a%d C a%d", $len0, ($len1 - 1), $len2); 
            $buffer = pack($fmt, $part0,  0x08, $part1, $wcVal, $part2); 
            
                    #######################################################
                    # debug stuff  -  print page 8
                    if ( 0 ) 
                    {
                        print "    mode page 8: \n";
                        for ($j = 0; $j < (2 + $dLen); $j++)
                        {
                            $byte = sprintf("x%d c", ($j + $pageStart));
                            $byte = unpack($byte, $senseData{DATA});
                            $msg2 = sprintf("%2.2X ",$byte & 0xff);
                            print $msg2;
                            if ((($j+1) % 8) == 0) {print "- ";}
                        }
                        print "\n";   
                    }
            
                    # debug stuff  -  print modified buffer
                    if ( 0 ) 
                    {
                        print "modified buffer: \n";
                        for ($j = 0; $j < length($buffer); $j++)
                        {
                            $byte = sprintf("x%d c", $j);
                            $byte = unpack($byte, $buffer);
                            $msg2 = sprintf("%2.2X ", ($byte & 0xff));
                            print $msg2;
                            if ((($j+9) % 16) == 0) {print "- ";}
                            if ((($j+1) % 16) == 0) {print "\n";}
                        }
                        print "\n";   
                    }
                    #######################################################
            
            print $msg;
            
            ($ret, %selectResp) = SCSIModeSelect10($obj1, $wwnHi, 
                                                 $wwnLo, $lun,
                                                 \$buffer);
            
            if (! %selectResp )        
            {
                $msg = "\nUpdate failed.\n";
                print ("\n\nFor PID $pdisks{PDISKS}[$i]{PD_PID}, \n");
                print ("     >>>>>>>>>> no response from Mode Select - drive not updated <<<<<<<<<<<\n");
                #exit(1);
            }
            elsif ( $selectResp{STATUS} != PI_GOOD )
            {
                $msg = "\nUpdate failed.\n";;
                print ("\n\nFor PID $pdisks{PDISKS}[$i]{PD_PID}, \n");
                print ("    >>>>>>>>>> Error from Mode Select - drive not updated <<<<<<<<<<<\n");
                PrintError(%selectResp);
                        print ("cmd returned : $ret \n");
                        print %selectResp;
                        print " \n";
                #exit(1);
            }
            else
            {    
                $msg = "done.";
                #$senseData{DATA}   
            }

        }


        $msg .= "\n";
        print $msg;
    }
  return GOOD  
}
}


1;

__END__

=head1 CHANGELOG

 $Log$
 Revision 1.2  2006/07/07 12:15:55  EidenN
 tbolt00000000
 Added $cdb = TestLibs::utility::AsciiHexToBin($cdb,"byte"); to ModeSelect6 and ModeSelect10 commands for support in the Anarchy code

 Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
 import CT1_BR to shared/Wookiee

 Revision 1.5  2005/03/02 18:06:53  EidenN
 Tbolt0000000:  Fixed XSSACodeUpdate pointer deref - Reviewed By:  PalmiD

 Revision 1.4  2003/01/14 16:22:30  WerningJ
 Add CVS Log to the end
 Reviewed by Craig M


=cut

