#! /usr/bin/perl -I ../ccbe -w 
# $Header$
##############################################################################
#
#   CCBE Integration test library
#
#   20/12/2005  XIOtech   Prashant Ghungurde/Gopinadh Anasuri
#
#   A set of library functions for integration testing. 
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2004-2005 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################


package TestLibs::Cleanuplib;

use strict;
use XIOTech::cmUtils;
use XIOTech::xiotechPackets;
use TestLibs::Constants qw(:DEFAULT  :CCBE);
use TestLibs::Logging;
use TestLibs::Validate;
use TestLibs::IntegCCBELib;
use TestLibs::Workload;

##############################################################################

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 4298 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                         &CleanupMirrors
                     );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;

##############################################################################

###############################################################################

=head2 CleanupMirrors function

This function breaks the mirrors which are not present in the original mirror list.

=cut

=over 1

=item Usage:

 my $rc = CleanupMirrors($ctlr, $origMirrorListPtr);
 
 where $ctlr is a reference to master controller object
 where $origMirrorListPtr hold list of mirrors pre-existing on controller

=item Returns:

      Good on successful execution of function.
      ERROR on function failure.

=item Description:
 
    Gets all the mirror info from resyncData and breaks the specified mirrors.

=back

=cut

##############################################################################
#
#          Name: CleanupMirrors
#
#        Inputs: controller object, pointer to original Mirror List
#
#       Outputs: GOOD    - successful,  
#                          broken the respective mirrors and did system defrag. 
#
#                ERROR   - function failed   
#
#  Globals Used: none
#
#   Description: - Function breaks the mirrors which are not present in the original 
#                  mirror list. This function gets all the mirrors info from resyncData 
#                  command.    
#
##############################################################################

sub CleanupMirrors
{
    my ($masterCtlr, $origMirrorListPtr) = @_;

    my %info;
    my %rsp2;
    my $i;
    my $j;
    my $k = 0;
    my $ret;
    my $mirrorfound;
    my @mirrorbroken;
          

    %info = $masterCtlr->resyncData(1);
    
    if (%info)
    {
        if ($info{STATUS} == PI_GOOD)
        { 
            for ($i = 0; $i < $info{COUNT}; $i++)
            {
                # Need to break and mirrors which are created for the test and should not 
                # delete the mirrors pre-existing to the test.
                
                # Inorder to identify the mirrors created for the test, check all the mirror 
                # disks available against pre-existing mirror list, and break mirrors which 
                # are not in the pre-existing list.  
                
                for ($j = 0 ; $j < scalar (@$origMirrorListPtr) ; $j++)
                { 
                    $mirrorfound = 0;
                    
                    if ( $$origMirrorListPtr[$j] == $info{DTLCPY}[$i]{RCDDV} )
                    {
                        $mirrorfound = 1;
                        last;
                    }
                }
                
                if ( $mirrorfound == 0 )
                {
                    %rsp2 = $masterCtlr->virtualDiskControl(0x05, $info{DTLCPY}[$i]{RCSDV}, $info{DTLCPY}[$i]{RCDDV});

                    if (!%rsp2)                        # no response
                    {
                        logInfo(">>>>> Failed to receive a response from Break Mirror <<<<<");
                        return ERROR;
                    }
                    elsif ($rsp2{STATUS}  != PI_GOOD)            # 1 is bad
                    {
                        logInfo("Mirror Break Failure.");
                        PrintError(%rsp2);
                        return ERROR;
                    }
                    else
                    {
                        logInfo(" Vdisk Mirror $info{DTLCPY}[$i]{RCDDV} broken.");
                    }
                    
                    # Store all the mirror broken vdisks for deleting later
                    
                    $mirrorbroken[$k] = $info{DTLCPY}[$i]{RCDDV} ;
                    $k++;
                    next;
                }
            }   
        } 
        else
        {
            logInfo("Unable to retrieve the resync data.");
            PrintError(%info);
        }
    }  
    else
    {
        logInfo( "ERROR: Did not receive a response packet from function resyncData.\n" );
        return ERROR;
    } 
        
    # After mirrors are broken then delete all those vdisks. 
    
    for ($k = 0 ; $k < scalar(@mirrorbroken) ; $k++ )
    { 
        $ret = &TestLibs::IntegCCBELib::DeleteSingleVdisk($masterCtlr, $mirrorbroken[$k]);
        logInfo (" Deleted Vdisk Mirror $mirrorbroken[$k]\n ");
        if ( $ret != GOOD ) { return ERROR; }
    }
   
   return GOOD;
}


################################################################################
1;  # We need this for a pm.
__END__

################################################################################
=head1 CHANGELOG


 ##############################################################################
 # Change log:
 # $Log$
 # Revision 1.1  2005/05/04 18:53:52  RysavyR
 # Initial revision
 #
 # Revision 1.1  2005/03/08 10:18:19  BalemarthyS
 # New File For Cleaning Mirrors, Created By Prashant/Gopinadh
 #
 #
 ##############################################################################

=cut
