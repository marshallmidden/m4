#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library
#
#   06/07/2005  XIOtech   Gopinadh Anasuri
#
#   A set of library functions for integration testing. 
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2005-2006 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::VdiskPriority - Perl Tests to test vdiskpriority feature

$Id: VdiskPriority.pm 6514 2006-01-09 12:11:21Z AnasuriG $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing the WorkLoad on backend 
and frontend of the controllers. Much of this is testing in a two-way
environment.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

               SetRandomPriority
               SetDefaultPriority
               VdiskPriorityEntry
               VdiskPrioritycase1
               VdiskPriorityCase2
        The less significant ones
               None   

=cut

#
# - what I am
#

package TestLibs::VdiskPriority;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use XIOTech::cmVDisk;

use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;

use strict;

#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 6514 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker


    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &SetRandomPriority
                        &SetDefaultPriority
                        &VdiskPriorityEntry
                        &VdiskPriorityCase1
                        &VdiskPriorityCase2
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 6514 $);
}
    our @EXPORT_OK;

##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $objPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.


 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.


=back

=cut


###############################################################################

###############################################################################

=head2 SetRandomPriority function

This subroutine sets priorities to different levels on on the vdisks.

=cut

=over 1

=item Usage:

 my $rc = SetRandomPriority( $objPtr );
 
 where: $objPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Vdisks should be created.
 
=back

=cut
##############################################################################
#
#          Name: SetRandomPriority
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine sets the vdisk priorities at different levels
#
##############################################################################
sub SetRandomPriority
{
    trace();

    my ( $objPtr ) = @_;

    my $i = 0;
    my $j = 0;
    my $k = 0;
    my $ret;
    my $master;
    my $ctlr;
    my $loopcount = 0;
    my $numCtlrs = 0;
    my @coList;
    my @serialNums;
    my @initialVdisks;
    my @VDiskList;
    my @vpripairs;
    my $msg;
    my $cnt;
    my $msg0;
    my %data;
    my %data1;
    my %data2;
    my %rsp;

    
    #
    # Find the master controller
    #
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    @coList = @$objPtr;

    $ctlr = $coList[$master];
 
    # Show the current BE configuration
    $ret = &TestLibs::IntegCCBELib::DispVdiskInfo($ctlr);
    
    #
    # Get the VIDs of all the current vdisks
    #
    
    %rsp = $ctlr->virtualDisks();
    
    if ( ! %rsp  )              
    {
       logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
       return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
       TestLibs::IntegCCBELib::PrintError(%rsp);
       return ERROR;
    }
        
    # Get the list of existing vdisks
    
    for ($i = 0; $i < $rsp{COUNT}; $i++)
    {
       $VDiskList[$i] = $rsp{VDISKS}[$i]{VID};
    }
    
    $cnt = scalar (@VDiskList);
  
    $j = 0;
    $k = 0;
    
    while ( $j < $cnt )
    {
         $vpripairs[$k] = $VDiskList[$j];
         $k++;
         $vpripairs[$k] = $j%3;
         logInfo("Vdisk $VDiskList[$j] will be set with priority $vpripairs[$k]\n");
         $k++;
         $j++;
     }
       
     %rsp = $ctlr->virtualDiskSetPriority ($cnt, $cnt, 0, @vpripairs); 

    if ( ! %rsp  )              
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskSetPriority command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from virtualDiskSetPriority command <<<<<<<<");
       TestLibs::IntegCCBELib::PrintError(%rsp);
       return ERROR;
    }
       
    return GOOD;
}                      

##############################################################################


=head2 SetDefaultPriority function

This subroutine sets priority on all vdisks to default 

=cut

=over 1

=item Usage:

 my $rc = SetDefaultPriority( $objPtr );
 
 where: $objPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks.

=back

=cut

##############################################################################
#
#          Name: SetDefaultPriority
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine sets default priority on all vdisks.
#
##############################################################################
sub SetDefaultPriority
{
    trace();

    my ( $objPtr ) = @_;

    my $i = 0;
    my $j = 0;
    my $ret;
    my $master;
    my $ctlr;
    my @coList;
    my @serialNums;
    my @initialVdisks;
    my @vpripairs;
    my $msg;
    my $msg0;
    my %rsp;

    @coList = @$objPtr;
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 


    $ctlr = $coList[$master];
    
    $vpripairs[0]=0;
    $vpripairs[1]=0;
    
    %rsp = $ctlr->virtualDiskSetPriority (1, 512, 1, @vpripairs); 
       
    if ( ! %rsp  )              
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskSetPriority command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from virtualDiskSetPriority command <<<<<<<<");
       TestLibs::IntegCCBELib::PrintError(%rsp);
       return ERROR;
    }
    if ( ! %rsp  )              
    {
       logInfo(">>>>>>>> Failed to get response from virtualDiskSetPriority command <<<<<<<<");
       return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from virtualDiskSetPriority command <<<<<<<<");
       TestLibs::IntegCCBELib::PrintError(%rsp);
       return ERROR;
    }
    
    logInfo("DefaultPri:  Default priority set on all vdisks ");
    return GOOD;
}                      
       
###############################################################################

###############################################################################


###############################################################################

=head2 VdiskPriorityEntry function

A function used for debugging the code as a generic entry. The final 
parameter represents the test case to be run. A test case of 99 will
run most tests. There is no guarantee that the tests can actually 
run sequentially and give full coverage.


=cut

=over 1

=item Usage:

 my $rc = VdiskPriorityEntry($coPtr, $snPtr, $moxaIP, $wwnPtr, $case );
 
 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is the IP address of the Moxa controller
        $wwnPtr is a pointer to a list WWNs
        $case is the test case to run

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the 
           expected state is found.


=back

=cut


##############################################################################
#
#          Name: VdiskPriorityEntry
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
##############################################################################

sub VdiskPriorityEntry
{
    trace();
    my ( $coPtr,  $snPtr, $moxaIP, $mmPtr, $wwnPtr, $ipPtr, $case ) = @_;

    my $loopCount;
    my $ret;
    $ret = GOOD;

    my @coList = @$coPtr;

 TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");
 TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "                starting VdiskPriority Case $case. ");
 TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");


    if ( $case==1   || $case == 99 ) { $ret = VdiskPriorityCase1( $coPtr, GOOD, $snPtr, $ipPtr, $wwnPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==2   || $case == 99 ) { $ret = VdiskPriorityCase2( $coPtr, GOOD, $snPtr ); }
    if ( $ret != GOOD ) { return $ret; }

   PeriodicDataGather($coPtr);

  TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");
  TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "                 VdiskPriority Case $case ends. ");
  TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    
    return $ret;

}

###############################################################################

=head2 VdiskPriorityCase1 function

This test case measures the drive performance when vdisk priorities are being repeatedly
changed.

Test Steps ...

	 1) Create 32 vdisks
	 2) Set High priority on 16 vdisks
	 3) Associate vdisks with HIGH priority to first server
	 4) Associate vdisks with LOW priority to Second server
         5) Collect system information
	 6) Display server and vdisks statistics
	 7) Now set vdisks associated on second server with HIGH priority
	 8) Display server and vdisks statistics

=cut

=over 1

=item Usage:

 my $rc = VdiskPriorityCase1( $objPtr, $retIn, $snPtr, $ipPtr, wwnPtr );
 
 where: $objPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr  is a pointer to a list of controller serial numbers
        $ipPtr is a pointer to ip addresses
        $wwnPtr is a pointer to WWNs

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The test requires two servers and before running the test make sure N=2
 is configured.

 No vdisks needs to created since test creates vdisks and also associates to
 servers as per the test requirement.

 I/O needs to be run with queue depth of 25, Write/Read percentage as 100 and 
 Random/Sequential percentage as 100 on XIOTACH.

=back

=cut
##############################################################################
#
#          Name: VdiskPriorityCase1
#
#        Inputs: controller, wwn pointer
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine measure the performance of the drives.
#
##############################################################################
sub VdiskPriorityCase1
{
    trace();

    my ( $objPtr, $retIn, $snPtr, $ipPtr, $wwnPtr ) = @_;

    my $i = 0;
    my $j = 0;
    my $k = 0;
    my $r = 0;
    my $ret;
    my $cnt;
    my $master;
    my $ctlr;
    my $loopcount = 0;
    my $numCtlrs = 0;
    my $sidcnt1 = 0;
    my $sidcnt2 = 0;
    my @coList;
    my @serialNums;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @VDiskList;
    my @vpripairs;
    my $msg;
    my $msg0;
    my %rsp;
    my %info;
    my @vdd;
    my @vdd1;
    my @Select_Server_ID1;
    my @Select_Server_ID2;
    my @wwnList;
    my @wwn1;
    my @wwn2;
    my $sid1 = 0;
    my $sid2 = 0;
    my $remaining;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    
    $msg = "------------ Test Case : vdisk priority performance measure test ---------------";
    $msg0 = "-------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);
    
    
    @coList = @$objPtr;
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    $ctlr = $coList[$master];
    
    $ret = &TestLibs::IntegCCBELib::MakeVdisks($ctlr, 7, 0 );
    $ret = &TestLibs::IntegCCBELib::MakeVdisks($ctlr, 7, 0 );
    $ret = &TestLibs::IntegCCBELib::MakeVdisks($ctlr, 7, 0 );
    $ret = &TestLibs::IntegCCBELib::MakeVdisks($ctlr, 7, 0 );
    
    # Show the current BE configuration
    TestLibs::IntegCCBELib::DispVdiskInfo($ctlr);
    
    #
    # Get the VIDs of all the current vdisks
    #
    
    %rsp = $ctlr->virtualDisks();
    
    if ( ! %rsp  )              
    {
       logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
       return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
       &TestLibs::IntegCCBELib::PrintError(%rsp);
       return ERROR;
    }
        
    $cnt = 16;
    
    $k = 0; 
    
    for ($j = 0; $j < 16; $j++)
    {
           $vpripairs[$k] = $j;
           $k++;
           $vpripairs[$k] = 2;
           logInfo("Vdisk $j will be set with priority $vpripairs[$k]\n");
           $k++;
    }
    
     %rsp = $ctlr->virtualDiskSetPriority ($cnt, 512, 1, @vpripairs); 
     
    if ( ! %rsp  )              
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskSetPriority command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from virtualDiskSetPriority command <<<<<<<<");
       TestLibs::IntegCCBELib::PrintError(%rsp);
       return ERROR;
    }
           
        @wwnList = @$wwnPtr;
        
    $msg = "\n\n Using server WWNs:\n";
    
    for ( $i = 0; $i < scalar(@wwnList); $i++ )
    {
        if ( ($i%4) == 0 )
        {
            $msg .= "\n";
        }
        
        $msg .= sprintf("   %s ", $wwnList[$i] );
        $msg .= "\t";
    }
    
    logInfo($msg);
    
        if (scalar(@wwnList) != 1)
        {
           # Get SIDs based on the first wwn
           %{$wwn1[0]} = %{$wwnList[0]};
           @Select_Server_ID1 = TestLibs::IntegCCBELib::FindSIDs( $ctlr, 0, \@wwn1);

           # Get SIDs based on the first wwn
           %{$wwn2[1]} = %{$wwnList[1]};
           @Select_Server_ID2 = TestLibs::IntegCCBELib::FindSIDs( $ctlr, 0, \@wwn2);
        } 
    
        logInfo("Server IDs for wwn0: @Select_Server_ID1");
        
        logInfo("Server IDs for wwn1: @Select_Server_ID2");
        
        $sidcnt1 = scalar(@Select_Server_ID1);
        $sidcnt2 = scalar(@Select_Server_ID2);
   
    TestLibs::IntegCCBELib::DispVdiskInfo($ctlr);
    
    # Now associate vdisks with HIGH priotity to first server
    
    PromptUser( 3 );        # have user rescan servers, wait for inits
    
    #
    # Test for CCBTIMEOUT and re-login if needed
    #
    
    $ret = TestNReconnectAll(\@coList);
    
    if($ret != GOOD)
    {
        logInfo("    ====> Unable to reconnect to one or more of the controllers. <====");
        return ERROR;
    }

    for( $r = 0; $r < 16; $r++)
    {
        # first, is this disk ready for use. (devstat = 0x10)
        if ( 0 !=TestLibs::IntegCCBELib::CheckInitProgress($ctlr, $r ) )
        {
            logInfo("Waiting for vdisk $r to become operational");

            while ( 0 != ( $remaining =TestLibs::IntegCCBELib::CheckInitProgress($ctlr, $r ) ) )
            {
                print " $remaining percent left to initialize \r";
                # pause for a second or 2
                sleep 2;
            }
        }
        
        $ret =TestLibs::IntegCCBELib::AssociateSingleVdisk($ctlr, $Select_Server_ID1[$sid1], $r, $r);

        $sid1++;
        
        if ( $sid1 == $sidcnt1)
        { 
           $sid1 = 0;
        }
        
        if ( $ret == ERROR )
        {
            logWarning(">>>>> Failed mapping Vdisk <<<<<");
            return (ERROR);
        }
    }

    # Now associate remaining vdisks with LOW priority to second server
    
    for( $r = 16; $r < 32; $r++)
    {
        # first, is this disk ready for use. (devstat = 0x10)
        if ( 0 != TestLibs::IntegCCBELib::CheckInitProgress($ctlr, $r ) )
        {
            logInfo("Waiting for vdisk $r to become operational");

            while ( 0 != ( $remaining =TestLibs::IntegCCBELib::CheckInitProgress($ctlr, $r ) ) )
            {
                print " $remaining percent left to initialize \r";
                # pause for a second or 2
                sleep 2;
            }
        }
        
        $ret = TestLibs::IntegCCBELib::AssociateSingleVdisk($ctlr, $Select_Server_ID2[$sid2], $r, $r);
        
        $sid2++;
        
        if ( $sid2 == $sidcnt2)
        { 
           $sid2 = 0;
        }
        
        if ( $ret == ERROR )
        {
            logWarning(">>>>> Failed mapping Vdisk <<<<<");
            return (ERROR);
        }
    }
    
        PromptUser( 9 );        # Start IO
    
    #
    # We collect data that will be used later for test validation. 
    # The data collected is BE status arrays and FE I/O performance data.  
    #
    
    # Get measure of the current IO
    
    $ret = VerifyIOGather($objPtr, $snPtr, $master, \@activeServers, \@initialVdisks, \@tMap, 20, 10);
    
    my @serverIDs;
    
    # find SIDs based on wwn list
    @serverIDs = TestLibs::IntegCCBELib::GetSIDs( $ctlr, 0);

    # the next line generates an error if no matching servers were found.
    # need to bail out in that case, or go into prompt mode.

    if ( INVALID == $serverIDs[0] )
    {
        logInfo(">>>>>>>> Failed to get server number(s) <<<<<<<<");
        return ERROR;
    }

    for ( $i = 0; $i < scalar(@serverIDs); $i++ )
    {

        ###################
        # STATSSERVER                # need a loop thru servers
        ###################

        logInfo("Getting statistics for server $serverIDs[$i]");
        %info = $ctlr->statsServer($serverIDs[$i]);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from statsServer <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            if ( $info{ERROR_CODE} == 0x2f )
            {
                logInfo("Not my server");
            }
            else
            {
                logInfo(">>>>>>>> Error from statsServer <<<<<<<<");
                PrintError(%info);
                return ERROR;
            }
        }

        if ( $info{STATUS} == PI_GOOD )      # if call returned an error
        {
            logStatsServer(%info);
        }
    }
    
   ###################
    # STATSVDISK
    ###################

    %rsp = $ctlr->statsVDisk();     # get the initial reading
    
    if ( ! %rsp  )
    {
        logInfo("No response from statsVDisk");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("Error returned from statsVdisk ");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo  "Virtual Disk Statistics ($rsp{COUNT} disks):";
    logInfo  "";
    logInfo  " VID       RPS        AVGSC         RREQ           WREQ         SPRC        SPSC   ";
    logInfo  "-----  ----------  ----------  -------------  -------------  ----------  ----------";


    for (my $i = 0; $i < $rsp{COUNT}; $i++)
    {
        $msg = "";
        $msg .= sprintf "%5hu  ",  $rsp{VDISKS}[$i]{VID};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{RPS};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{AVGSC};
        $msg .= sprintf "%13s  ",  $rsp{VDISKS}[$i]{RREQ};
        $msg .= sprintf "%13s  ",  $rsp{VDISKS}[$i]{WREQ};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{SPRC};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{SPSC};
        logInfo($msg);
    }

    logInfo("");
 
   
   # Change the priorities on the vdisks associated  and measure 
   # the performance
    
    $cnt = 16;
    
    for ($j = 16,$k=16; $j < 32; $j++)
    {
           $vpripairs[$k] = $j;
           $k++;
           $vpripairs[$k] = 2;
           logInfo("Vdisk $j is set with priority $vpripairs[$k]\n");
           $k++;
    }
    
    %rsp = $ctlr->virtualDiskSetPriority ($cnt, 512, 1, @vpripairs); 
           
    if ( ! %rsp  )              
     {
          logInfo(">>>>>>>> Failed to get response from virtualDiskSetPriority command <<<<<<<<");
          return ERROR;
     }
    if ( $rsp{STATUS} != PI_GOOD )      
     {
          logInfo(">>>>>>>> Error from virtualDiskSetPriority command <<<<<<<<");
     }
    
    # Sleep for 400 seconds
    logInfo("Pause for 400 seconds.......");
    sleep 400;
    
    #
    # We make sure that the I/O has not been interrupted.
    #
    $ret = VerifyIO( $objPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }
    
   # Measure the performance after changing the priorities on the vdisks 
    
    # find SIDs based on wwn list
    @serverIDs = TestLibs::IntegCCBELib::GetSIDs( $ctlr, 0);

    # the next line generates an error if no matching servers were found.
    # need to bail out in that case, or go into prompt mode.

    if ( INVALID == $serverIDs[0] )
    {
        logInfo(">>>>>>>> Failed to get server number(s) <<<<<<<<");
        return ERROR;
    }

    for ( $i = 0; $i < scalar(@serverIDs); $i++ )
    {

        ###################
        # STATSSERVER                # need a loop thru servers
        ###################

        logInfo("Getting statistics for server $serverIDs[$i]");
        %info = $ctlr->statsServer($serverIDs[$i]);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from statsServer <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            if ( $info{ERROR_CODE} == 0x2f )
            {
                logInfo("Not my server");
            }
            else
            {
                logInfo(">>>>>>>> Error from statsServer <<<<<<<<");
                PrintError(%info);
                return ERROR;
            }
        }

        if ( $info{STATUS} == PI_GOOD )      # if call returned an error
        {
            logStatsServer(%info);
        }
    }
 
    
   ###################
    # STATSVDISK
    ###################

    %rsp = $ctlr->statsVDisk();     # get the initial reading
    
    if ( ! %rsp  )
    {
        logInfo("No response from statsVDisk");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("Error returned from statsVdisk ");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo  "Virtual Disk Statistics ($rsp{COUNT} disks):";
    logInfo  "";
    logInfo  " VID       RPS        AVGSC         RREQ           WREQ         SPRC        SPSC   ";
    logInfo  "-----  ----------  ----------  -------------  -------------  ----------  ----------";


    for (my $i = 0; $i < $rsp{COUNT}; $i++)
    {
        $msg = "";
        $msg .= sprintf "%5hu  ",  $rsp{VDISKS}[$i]{VID};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{RPS};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{AVGSC};
        $msg .= sprintf "%13s  ",  $rsp{VDISKS}[$i]{RREQ};
        $msg .= sprintf "%13s  ",  $rsp{VDISKS}[$i]{WREQ};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{SPRC};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{SPSC};
        logInfo($msg);
    }

    $msg0 = "-------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);
    
    return GOOD;
}

###############################################################################

=head2 VdiskPriorityCase2 function

This subroutine changes the priorities on vdisks many times and then checks I/O
to check if there is any data corruption.

Test Steps ...

     1) I/O should be running
	 2) Collect system information
	 3) Set Random Priority on available vdisks
	 4) Set MEDIUM priority on all vdisks
	 5) Set HIGH priority on few vdisks and remaining LOW 
	 6) Verify if there is any data corruption


=cut

=over 1

=item Usage:

 my $rc = VdiskPriorityCase2( $objPtr, $retIn, $snPtr );
 
 where: $objPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr  is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.

 There should be no defrag, copy, or init operation running when the test 
 is started. 


=back

=cut
##############################################################################
#
#          Name: VdiskPriorityCase2
#
#        Inputs: controller, wwn pointer
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine changes the priorities on vdisks many times 
#                and then checks I/O to check if there is any data corruption.
#
##############################################################################
sub VdiskPriorityCase2
{
    trace();

    my ( $objPtr, $retIn, $snPtr ) = @_;

    my $i = 0;
    my $j = 0;
    my $k = 0;
    my $ret;
    my $cnt;
    my $master;
    my $ctlr;
    my $loopcount = 0;
    my $numCtlrs = 0;
    my @coList;
    my @serialNums;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @VDiskList;
    my @vpripairs;
    my $msg;
    my $msg0;
    my %rsp;
    my @vdd;
    my @vdd1;
    my @Select_Server_ID1;
    my @Select_Server_ID2;
    my $sid1 = 0;
    my $sid2 = 0;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    @coList = @$objPtr;
    
    $msg = "------------ Test Case : vdisk priority stress test ---------------";
    $msg0 = "-------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 


    $ctlr = $coList[$master];
    
    
    # Show the current vdisk list
    DispVdiskInfo($ctlr);
    
    #
    # We collect data that will be used later for test validation. 
    # The data collected is BE status arrays and FE I/O performance data.  
    #
    
    # Get measure of the current IO
    
    $ret = VerifyIOGather($objPtr, $snPtr, $master, \@activeServers, \@initialVdisks, \@tMap, 20, 10);
    
    #
    # Get the VIDs of all the current vdisks
    #
    
    %rsp = $ctlr->virtualDisks();
    
    if ( ! %rsp  )              
    {
       logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
       return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
       TestLibs::IntegCCBELib::PrintError(%rsp);
       return ERROR;
    }
        
    # Get the list of existing vdisks
    
    for ($i = 0; $i < $rsp{COUNT}; $i++)
    {
       $VDiskList[$i] = $rsp{VDISKS}[$i]{VID};
    }
   
    $cnt = scalar (@VDiskList);
  
     # Changes priorities on the vdisks many times 
     
      SetRandomPriority($objPtr); 

       
      # Show the current vdisk list
      
      DispVdiskInfo($ctlr);
      # Pause 250 seconds 
      logInfo("Pause for 250 seconds.......");
      sleep 250;
     
     # Set all vdisks to HIGH priority  
      
       $j = 0;
       $k = 0;
      
       while ( $j < $cnt )
       {
           $vpripairs[$k] = $VDiskList[$j];
           $k++;
           $vpripairs[$k] = 2;
           logInfo("Vdisk $VDiskList[$j] will be set with priority $vpripairs[$k]\n");
           $k++;
           $j++;
       }
       
       %rsp = $ctlr->virtualDiskSetPriority ($cnt, $cnt, 0, @vpripairs); 
       
        if ( ! %rsp  )              
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskSetPriority command <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      
        {
            logInfo(">>>>>>>> Error from virtualDiskSetPriority command <<<<<<<<");
            TestLibs::IntegCCBELib::PrintError(%rsp);
            return ERROR;
        }
       
        # Show the current vdisk list
        DispVdiskInfo($ctlr);
       # Pause 250 seconds 
       
       logInfo("Pause for 250 seconds.......");
       sleep 250;
       
     # Set all vdisks to MEDIUM priority
       $j = 0;
       $k = 0;
      
       while ( $j < $cnt )
       {
           $vpripairs[$k] = $VDiskList[$j];
           $k++;
           $vpripairs[$k] = 1;
           logInfo("Vdisk $VDiskList[$j] will be set with priority $vpripairs[$k]\n");
           $k++;
           $j++;
       }
       
           %rsp = $ctlr->virtualDiskSetPriority ($cnt, $cnt, 0, @vpripairs);
           
        if ( ! %rsp  )              
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskSetPriority command <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      
        {
            logInfo(">>>>>>>> Error from virtualDiskSetPriority command <<<<<<<<");
            TestLibs::IntegCCBELib::PrintError(%rsp);
            return ERROR;
        }
          
        # Show the current vdisk list
        DispVdiskInfo($ctlr);
        #Pause 250 seconds 
       
        logInfo("Pause for 250 seconds.......");
        sleep 250;
       
        # Set some vdisks to high and remaining low     
      
        $j = 0;
      
        $k = 0;
        $cnt /= 2;
        while ( $j < $cnt )
        {
           $vpripairs[$k] = $VDiskList[$j];
           $k++;
           $vpripairs[$k] = 2;
           logInfo("Vdisk $VDiskList[$j] will be set with priority $vpripairs[$k]\n");
           $k++;
           $j++;
        }
       
        %rsp = $ctlr->virtualDiskSetPriority ($cnt, 512, 1, @vpripairs);
           
        if ( ! %rsp  )              
        {
           logInfo(">>>>>>>> Failed to get response from virtualDiskSetPriority command <<<<<<<<");
           return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      
        {
           logInfo(">>>>>>>> Error from virtualDiskSetPriority command <<<<<<<<");
           TestLibs::IntegCCBELib::PrintError(%rsp);
           return ERROR;
        }
        
        # Show the current vdisk list
        DispVdiskInfo($ctlr);
        #Pause 250 seconds 
       
        logInfo("Pause for 250 seconds.......");
        sleep 250;
        
        #
        # We make sure that the I/O has not been interrupted.
        #
         $ret = VerifyIO( $objPtr,
                          \@activeServers,
                          \@tMap,
                          \@initialVdisks,
                          $snPtr
                        );
         if ( $ret != GOOD ) { return ERROR; }
    
        
         # Show the current vdisk list
         DispVdiskInfo($ctlr);

    return GOOD;        
}
#########################################################################################################

##############################################################################

1;   # we need this for a PM

##############################################################################
=head1 CHANGE       LOG
        
##############################################################################
# Change log:
# $Log$
# Revision 1.2  2006/01/09 12:11:21  AnasuriG
# Updated server association and added ccbe reconnection part after time out
#
# Revision 1.1  2005/08/16 10:13:14  BalemarthyS
# New file for vdiskpriority test cases created by gopinadh
#
# Revision 1.1  2005/08/16 10:04:38  BalemarthyS
# New File for vdiskpriority tests
#
#
##############################################################################
