#!/usr/bin/perl -w


package TestLibs::vdisklib;

use IO::Socket;
use IO::Select;

use XIOTech::cmPDisk;
use XIOTech::cmVDisk;
use XIOTech::cmLogs;
use XIOTech::cmStats;
use XIOTech::cmVCG;
use XIOTech::cmServer;
use XIOTech::cmTarget;

#Setup inheritance
use XIOTech::initializeable;
@ISA = qw(XIOTech::initializeable);

use XIOTech::xiotechPackets;
use XIOTech::seqNumber;
use XIOTech::constants;
use XIOTech::error;
use XIOTech::cmdMgr;
use Math::BigInt;

use XIOTech::logMgr;

use strict;


use constant GOOD => 0; 
use constant BAD => 1;

##############################################################################
# Name:     delete_all
#
# Desc:    Deletes all the VD's on the system     
#           
# In:       None      
#
# Returns:  Print Statments  
#
##############################################################################


sub delete_all
{
 my ($self) = @_;
 my %info = $self-> serverList();
 my $ServerList = $info{LIST};
 my @ServerList = @$ServerList;
 my @DoNotDelete;
 
 for(my $i = GOOD; $i < scalar(@ServerList); $i++)
 {
    my %ServerInfo = $self -> serverInfo($ServerList[$i]);
    if($ServerInfo{NLUNS} > GOOD)
    {
        for (my $e = 0; $e < $ServerInfo{NLUNS}; $e++)
        {
            print "---------------------------------------------- \n";
            my %ServerInfoCommmadResult = $self->serverDisassociate($ServerInfo{SID}, $ServerInfo{LUNMAP}[$e]{LUN});
            if (NoError("serverDisassociate", %ServerInfoCommmadResult) == GOOD)
            {
                print "VD ID: ", $ServerInfo{LUNMAP}[$e]{VID}, " WAS DISASSOCIATED FROM SERVER ID ", $ServerInfo{SID}, "\n";
            }
            else
            {
                print "FATAL ERROR: DID NOT DISASSOCIATE VD ID: ", $ServerInfo{LUNMAP}[$e]{VID};
                print  " FROM SERVER ID ", $ServerInfo{SID}, "\n";
                die;
            
            } 
        }
    }
 }

 my %VIDs = $self->virtualDiskList();
 my $listsub = $VIDs{LIST};
 my @list = @$listsub; 
    
 if(scalar(@list))
    {
        for (my $i = 0; $i < scalar(@list); $i++)
            {  
                my($sec_b, $min_b, $hour_b, $mday_b, $mon_b, $year_b, $wday_b, $yday_b, $isdst_b) = localtime(time);
                my %rc = $self->virtualDiskDelete($list[$i]);
                my ($sec_e, $min_e, $hour_e, $mday_e, $mon_e, $year_e, $wday_e, $yday_e, $isdst_e) = localtime(time);

                print "----------------------- \n";
                if (NoError("virtualDiskDelete", %rc) == 0)
                    {
                        print "\n";
                        my $TimeExectute = CalcTime("virtualDiskDelete", $sec_b, $min_b, $hour_b, $sec_e, $min_e, $hour_e);
                        print " VDisk ID =  $list[$i] was deleted \n";  
                    }
            
                else
                    {
                        print "\nLook for Error Above \n";
                    }
            }
    }   

 else
    {
        print "THERE ARE NO VD'S TO DELETE \n";
    }

}



##############################################################################
# Name:     VDiskInit
#
# Desc:     Initializes all VD's on the system 
#           
# In:       None      
#
# Returns:  Print Statements   
#
##############################################################################


sub VDiskInit
{
 
 my ($self) = @_;
 my %rc = $self->raidList();
 my $Sub_ArrayVD = $rc{LIST};
 my @Raid_Array = @$Sub_ArrayVD;
 if(NoError("raidList", %rc) == 0)
    {
        for(my $i = 0; $i < scalar(@Raid_Array); $i++)
            {
                %rc = $self->virtualDiskInit($Raid_Array[$i]);
                if(NoError("virtualDiskInit", %rc) == 0)
                    {
                        print "VD Raid_ID $Raid_Array[$i] was Initialized  \n"; 
                    }
                else
                    {
                        print "ERROR---VD Raid_ID $Raid_Array[$i] was NOT Initialized  \n";
                    }
            }
    }

}


##############################################################################
# Name:     Create_Any_VD
#
# Desc:     
#           
# In:       $name - Virtual disk name
#           $capacity    - MB requested bytes in MB
#           @physicalDisks - Array of physical disks
#           $rtype - raid type
#           $stripe - stripe size
#           $depth - mirrow depth
#           $parity - parity        
#
# Returns:  Print Statements   
#
##############################################################################

sub Create_VD
{
 my ($self, $name, $capacity_org, $rtype, $stripe, $depth, $parity, @physicalDisks) = @_;
 my @array; my $capacity; 

 my %ret = $self->calcRaidParms(\@physicalDisks, $rtype);

 if(%ret)
 {
    print " \n------------------------ \n";
    print ">>>>>>> CREATING: <<<<<<< \n";
    print "PASS: calcRaidParms \n";
    if(($capacity_org != 0) && ($rtype != 0) && (scalar(@physicalDisks) != 0))
    {
        $capacity =  Math::BigInt->new(($capacity_org * 1024 * 1024) / 512 );
    
        if($stripe == 0)
        {
            $stripe = $ret{STRIPE_SIZE};
        }

        if($depth == 0)
        {
            $depth = $ret{MIRROR_DEPTH}; 
        }
        
        if(($parity == 0) || ($parity > scalar(@physicalDisks)))
        {
            $parity = $ret{PARITY};
        }
    }
 
 else
 
    {
        print "\nInsufficiant resouces, check the function call \n";
    }
    
 
    print "NAME: ", $name, "\n";
    print "NUNBER of PD: ", scalar(@physicalDisks), "\n";
    print "PD IDs: ", @physicalDisks, "\n";
    print "CAPACITY: ", $capacity_org;
    print " MG", "\n"; 
    print "STRIPE SIZE: ", $stripe, "\n";
    print "MIRROR DEPTH: ", $depth, "\n";
    print "PARITY: ", $parity, "\n"; 

   my($sec_b, $min_b, $hour_b, $mday_b, $mon_b, $year_b, $wday_b, $yday_b, $isdst_b) = localtime(time);
   
   %ret = $self->virtualDiskCreate( $capacity,
                                        \@physicalDisks,
                                        $rtype,                                                                     
                                        $stripe,
                                        $depth,
                                        $parity,
                                        undef,        # vid
                                        4,             # maxraids
                                        10,           # threshold
                                        0,             # flags
                                        0);           # minPD

   my ($sec_e, $min_e, $hour_e, $mday_e, $mon_e, $year_e, $wday_e, $yday_e, $isdst_e) = localtime(time);


 if (NoError("virtualDiskCreate", %ret) == 0)
    {
        print " VDisk ID = $ret{VID} WAS CREATED \n";
        print ">>>>>>>>> CREATED: <<<<<<<<<< \n";
        my %info = $self ->virtualDiskInfo($ret{VID});
        if(NoError("virtualDiskInfo", %info) == 0)
        {
            
            #$self ->displayVirtualDiskInfo(%info);
            my $msg = $self->displayVirtualDiskInfo(%info);
            print $msg;

            my $TimeExectute = CalcTime("virtualDiskCreate", $sec_b, $min_b, $hour_b, $sec_e, $min_e, $hour_e);
            $array[0] = "------------------------- \n";
            $array[1] = " 0 NAME: $name ";
            $array[2] = "$ret{VID}";
            $array[3] = " NUNBER of PD: ";
            $array[4] = scalar(@physicalDisks);
            $array[5] = "PD IDs: @physicalDisks";
            $array[6] = "CAPACITY:  $capacity"; 
            $array[7] = "STRIPE SIZE: $stripe";
            $array[8] = "MARROW DEPTH: $depth";
            $array[9] = "PARITY: $parity";
            $array[10] = " >> WAS CREATED";
            $array[11] = "Time = $TimeExectute;";
        }
    }

 else
    {
        print "\nLook for Error Above \n";
        print "ERROR: VDisk NAME: $name WAS NOT CREATED \n"; 
        $array[0] =  "-------------------------";
        $array[1] = " 1 NAME:  $name";
        $array[2] = "NUNBER of PD: ";
        $array[3] = scalar(@physicalDisks);
        $array[4] = "PD IDs: @physicalDisks";
        $array[5] = "CAPACITY:  $capacity"; 
        $array[6] = "STRIPE SIZE: $stripe";
        $array[7] = "MARROW DEPTH: $depth";
        $array[8] = "PARITY: $parity";
        $array[9] = "$ret{VID} - WAS NOT CREATED"; 
        if (defined($ret{ERROR_CODE}))
        {
            $array[10] =" $ret{ERROR_CODE}";
        }
        else
        {
            $array[10] = " NO ERROR CODE DEFINED";
        }
        if (defined($ret{MESSAGE}))
        {
                $array[11] = " $ret{MESSAGE} ";
        }
    }
 }
 return @array;
}

##############################################################################
# Name:     Expand
#
# Desc:     Checks for an error
#           
# In:       hash %ret - Returned hash from the a function        
#
# Returns:  Print Statements   
#
##############################################################################


sub Expand
{
 
 my ($self, $name, $vid, $capacity_org, $rtype, $stripe, $depth, $parity, @physicalDisks) = @_;
 my @array; my $capacity;

 my %raidParms = $self->calcRaidParms(\@physicalDisks, $rtype);

 if(($capacity_org != 0) && ($rtype != 0) && (scalar(@physicalDisks) != 0))
    {
        $capacity =  Math::BigInt->new(($capacity_org * 1024 * 1024) / 512 );
    
        if($stripe == 0)
            {
                $stripe = $raidParms{STRIPE_SIZE};
            }

        if($depth == 0)
            {
                $depth = $raidParms{MIRROR_DEPTH}; 
            }
        
        if($parity == 0)
            {
                $parity = $raidParms{STRIPE_SIZE};
            }
    }
 
 else
 
    {
        print "Inseficiant resouces, check FUNCTION CALL \n";
    }

my($sec_b, $min_b, $hour_b, $mday_b, $mon_b, $year_b, $wday_b, $yday_b, $isdst_b) = localtime(time);
print " >>>>>>>>>>> EXPANDING <<<<<<<<<<< \n";   
print "VID $vid \n", "capacity", $capacity, "\n", "physicalDisks", @physicalDisks, "\n";
print "rtype $rtype \n", "stripe $stripe \n", "depth $depth \n", "parity $parity \n";

my %rc = $self->virtualDiskExpand(  $vid,
                                    $capacity,
                                    \@physicalDisks,
                                    $rtype,
                                    $stripe,
                                    $depth,
                                    $parity);


if (NoError("virtualDiskExpand", %rc) == 0)
    {
        my ($sec_e, $min_e, $hour_e, $mday_e, $mon_e, $year_e, $wday_e, $yday_e, $isdst_e) = localtime(time);
        my $TimeExectute = CalcTime("virtualDiskExpand", $sec_b, $min_b, $hour_b, $sec_e, $min_e, $hour_e);
        print " VDisk ID = $rc{VID} was EXPANDED \n";
        print ">>>>>>>>> EXPANDED: <<<<<<<<<< \n";
        my %info = $self ->virtualDiskInfo($vid);
        if(NoError("virtualDiskInfo", %info) == 0)
        {
            
            # $self ->displayVirtualDiskInfo(%info);
            my $msg = $self->displayVirtualDiskInfo(%info);
            print $msg;

            $array[0] = 1;
            $array[1] ="VD Name $name";
            $array[2] =" VD Name ID ";
            $array[3] = " - Was Expended";
            $array[4] = "Time = $TimeExectute";
        } 
    }
 else
    {
        print "\nLook for Error Above \n";
        $array[0] = 0;
        $array[1] ="VD Name $name";
        $array[2] = " - Was not Expanded ";
    }
 
  return @array;
}


##############################################################################
# Name:     NoError
#
# Desc:     Checks for an error
#           
# In:       hash %ret - Returned hash from the a function        
#
# Returns:  Print Statements   
#
##############################################################################

sub NoError
{
 my ($command, %ret) = @_;
 my $ i = 1;
 if (%ret)
 {
    if($ret{STATUS} == 1)
    {
        $i = 1;
        printf "Status Code:    0x%02x  ", $ret{STATUS};
        if(defined($ret{STATUS_MSG}))
        {
            printf " \"%s\"", $ret{STATUS_MSG};
        }
        
        printf "Error Code:     0x%02x  ", $ret{ERROR_CODE};
        
        if (defined($ret{ERROR_MSG}))
        {
            printf " \"%s\"", $ret{ERROR_MSG};
        }
        else
        {
            print "FAILD: $command \n";
            print "ERROR: Did not receive a response packet.\n";
        }
    }
    elsif($ret{STATUS} == 0)
    {
        $i = 0;
        print "PASS: $command \n"; 
    }
 }
 return $i;

}

##############################################################################
# Name:     CalcTime
#
# Desc:     Calculates time for single command execution 
#           
# In:       $sec_b  - Sec at the Beginning  
#           $min_b  - Min at the Beginning                 
#           $hour_b - Hour at the Beginning 
#           $sec_e  - Sec at the End
#           $min_e  - Min at the End
#           $hour_e - Hour at the End        
#
# Returns:  Print Statements   
#
##############################################################################

sub CalcTime
{
 my ($command, $sec_b, $min_b, $hour_b, $sec_e, $min_e, $hour_e) = @_;
 my $TimeStampB = (($hour_b * 3600) + ($min_b * 60) + $sec_b);
 my $TimeStampE = (($hour_e * 3600) + ($min_e * 60) + $sec_e);
 my $TimeExectute = $TimeStampE - $TimeStampB;
 print "TimeStampB   ",   " >>>>>>>>>>>> ", "$TimeStampB time of the day in sec \n";
 print "TimeStampE   ",   " >>>>>>>>>>>> ", "$TimeStampE time of the day in sec \n";
 print "TimeExectute ",   " >>>>>>>>>>>> ", "$TimeExectute sec\n";
 if($TimeExectute > 5)
 {
    print "WARNING: TOOK $TimeExectute sec to EXECUTE $command  \n \n";
 }
 else
 {
    print "TIME: TOOK $TimeExectute sec to EXECUTE $command \n \n";
 }

 return $TimeExectute;   
}


#===========================================================================================#
# May 13 Modified Delete_all to disassociate first and then Delete 



                                