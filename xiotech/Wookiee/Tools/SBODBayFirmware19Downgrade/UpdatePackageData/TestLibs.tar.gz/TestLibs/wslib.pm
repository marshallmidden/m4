#! /usr/bin/perl -w
# $Header:
##############################################################################
#  
#   wslib Test Library
#
#   06/05/2006  Xiotech
#
#   A set of library functions to make XioWebService calls.  Any subs
#   beginning with "ws" are using the same name as the Xiotech Web
#   Service call
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2006 Xiotech
#
#   For Xiotech internal use only.
#
##############################################################################

# what I am
package TestLibs::wslib;

# libs
use lib "../CCBE";
use lib "../../CCBE";
use lib "../";

# Core perl libs
use warnings;
use strict;

# Xiotech libs
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::Logging;

# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    
    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        &WebServicesModuleTest
                        &wsCreateSession1
                        &wsDeleteSession1
                        &wsHello1
                        &wsUpdateCtrlrFwOpEnd1
                        &wsUpdateCtrlrFwOpStart1
                        &wsUpdateDscFwOpEnd1
                        &wsUpdateDscFwOpStart1
                        &wsUpdateSw1
                        &wsUpdateXwsSw1
    );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 10183 $);
}
our @EXPORT_OK;

###############################################################################
#  WebServicesModuleTest
#
#   DOES:   Tests the module to make sure things are working
#
#   IN:     Nothing
#
#   OUT:    GOOD
#
#   REQUIRES:
#           Nothing
#
#   TODO:   Eventually delete this sub
#
###############################################################################
sub WebServicesModuleTest
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line...\n");
    return(GOOD);
}

###############################################################################
#  wsHello1
#
#   DOES:   Calls the Hello1 XWS method
#
#   IN:     Nothing
#
#   OUT:    GOOD or ERROR
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#
###############################################################################
sub wsHello1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    return(GOOD);
}

###############################################################################
#  wsCreateSession1
#
#   DOES:   Calls the CreateSession1 XWS method:
#           The CreateSession1 method must be used to create a session with
#           the Xiotech Web Service prior to calling any other methods.  The
#           session context token provided by CreateSession1 response must be
#           used in the SOAP header of all other method requests to associate
#           the requests with the session.  Also, a client is obligated to
#           delete the session using the DeleteSession1 method when the client
#           no longer needs to communicate with the Xiotech Web Service.
#
#   IN:     String
#               username:  Username
#           String
#               password:  Password
#           String
#               version:   Client Xiotech Web Service protocol version.
#
#   OUT:    String
#               Session ID (to be used in the wsDeleteSession1
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#
###############################################################################
sub wsCreateSession1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    logInfo("Inputs were @_\n");
    return(GOOD);
}

###############################################################################
#  wsDeleteSession1
#
#   DOES:   Calls the DeleteSession1 XWS method:
#           Each session created with the CreateSession1 method must be
#           deleted with the DeleteSession1 method when the client no longer
#           needs to communicate with the Xiotech Web Service.
#
#   IN:     String
#               Session ID
#
#   OUT:    GOOD or ERROR
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#
###############################################################################
sub wsDeleteSession1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    return(GOOD);
}

###############################################################################
#  wsGetXwsInfo1
#
#   DOES:   Calls the GetXwsInfo1 XWS method:
#           Returns the xws info
#
#   IN:     Nothing
#
#   OUT:    String(?)
#               XWS info(?)
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#
###############################################################################
sub wsGetXwsInfo1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    logInfo("Inputs were @_\n");
    return(GOOD);
}

###############################################################################
#  wsGetDscInfo1
#
#   DOES:   Calls the GetDscInfo1 XWS method:
#           The array of identifier input can be a specific identifier to
#           select a single object, a variable number of identifiers to select
#           a variable number of objects, or an empty array to select all
#           objects of this type.  If a single object is selected, then only
#           a single output item corresponding to the single selected object
#           will be returned.  If a variable number of objects are selected,
#           then an output item for each of the objects selected will be
#           returned.  If all objects of this type are selected with an empty
#           array, then an output item for each of the objects of this type
#           will be returned.
#
#   IN:     Array of Strings
#               DSC IDs
#
#   OUT:    Array of Strings
#               DSC Info
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#
###############################################################################
sub wsGetDscInfo1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    logInfo("Inputs were @_\n");
    return(GOOD);
}

###############################################################################
#  wsUpdateSw1
#
#   DOES:   Calls the UpdateSw1 XWS method:
#           The provided update file is used to update software local to the
#           Xiotech Web Service (i.e., on the same local hardware).
#
#   IN:     String
#               update_name:  Name of update file
#
#   OUT:    GOOD or ERROR
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#           Add binary input as direct file (as in XWS spec)
#
###############################################################################
sub wsUpdateSw1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    return(GOOD);
}

###############################################################################
#  wsUpdateXwsSw1
#
#   DOES:   Calls the UpdateXwsSw1 XWS method:
#           The Xiotech Web Service server software is updated according to
#           the provided update file.  Note that an update of the Xiotech Web
#           Service server software requires the Xiotech Web Service server to
#           restart which will require sessions to be reestablished.
#
#   IN:     String
#               update_name:  Name of update file
#
#   OUT:    GOOD or ERROR
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#           Add binary input as direct file (as in XWS spec)
#
###############################################################################
sub wsUpdateXwsSw1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    return(GOOD);
}

###############################################################################
#  wsUpdateDscFwOpStart1   
#
#   DOES:   Calls the UpdateDscFwOpStart1 XWS method:
#           The DSC firmware is updated according to the provided update file.
#           Note that the update is applied with respect to fault tolerance
#           among controllers.  See UpdateCtrlrFw1 for an alternative that
#           does not respect fault tolerance while updating the firmware
#           of multiple controllers.
#
#   IN:     String
#               DSC Number
#           String
#               Name of xzp file for update
#
#   OUT:    GOOD or ERROR
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#           Add binary input as direct file (as in XWS spec)
#
###############################################################################
sub wsUpdateDscFwOpStart1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    return(GOOD);
}

###############################################################################
#  wsUpdateDscFwOpEnd1
#
#   DOES:   Calls the UpdateDscFwOpEnd1 XWS method:
#           The DSC firmware is updated according to the provided update file.
#           Note that the update is applied with respect to fault tolerance
#           among controllers.  See UpdateCtrlrFw1 for an alternative that
#           does not respect fault tolerance while updating the firmware
#           of multiple controllers.
#
#   IN:     String
#               DSC Number
#           String
#               Name of xzp file for update (?)
#
#   OUT:    GOOD or ERROR
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#           Add binary input as direct file (as in XWS spec)
#
###############################################################################
sub wsUpdateDscFwOpEnd1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    return(GOOD);
}

###############################################################################
#  wsUpdateCtrlrFwOpStart1
#
#   DOES:   Calls the UpdateCtrlrFwOpStart1 XWS method:
#           The array of identifier input can be a specific identifier to
#           select a single object, a variable number of identifiers to select
#           a variable number of objects, or an empty array to select all
#           objects of this type.  The controller firmware is updated
#           according to the provided update file.  Note that the update is
#           not applied with respect to fault tolerance among controllers.
#           See UpdateDscFw1 for an alternative that does respect fault
#           tolerance while updating the firmware of multiple controllers.
#
#           Note: Although the XWS call allows controllers to be upgraded
#                 independantly, this sub will look at the DSC number and
#                 do both controllers.  This is intended to simulate the
#                 "Reset All" code update method for platform.
#
#   IN:     String
#               DSC Number
#           String
#               Name of xzp file for update (?)
#               
#
#   OUT:    GOOD or ERROR
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#           Add binary input as direct file (as in XWS spec)
#
###############################################################################
sub wsUpdateCtrlrFwOpStart1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    return(GOOD);
}

###############################################################################
#  wsUpdateCtrlrFwOpEnd1
#
#   DOES:   Calls the UpdateCtrlrFwOpEnd1 XWS method:
#           The array of identifier input can be a specific identifier to
#           select a single object, a variable number of identifiers to select
#           a variable number of objects, or an empty array to select all
#           objects of this type.  The controller firmware is updated
#           according to the provided update file.  Note that the update is
#           not applied with respect to fault tolerance among controllers.
#           See UpdateDscFw1 for an alternative that does respect fault
#           tolerance while updating the firmware of multiple controllers.
#
#           Note: Although the XWS call allows controllers to be upgraded
#                 independantly, this sub will look at the DSC number and
#                 do both controllers.  This is intended to simulate the
#                 "Reset All" code update method for platform.
#
#   IN:     String
#               DSC Number
#           String
#               Name of xzp file for update (?)
#               
#
#   OUT:    GOOD or ERROR
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#           Add binary input as direct file (as in XWS spec)
#
###############################################################################
sub wsUpdateCtrlrFwOpEnd1
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    return(GOOD);
}

###############################################################################
#  wsCodeUpdateWrapper
#
#   DOES:   Updates the code using XWS methods
#           Currently three types of updates are supported:
#               "rolling"
#                   perform rolling code update using the UpdateDscFwOpStart1
#                   and UpdateDscFwOpEnd1 XWS methods
#               "resetall"
#                   perform a code update, but reset both controllers at the
#                   same time by calling UpdateCtrlrFwOpStart1 and
#                   UpdateCtrlrFwOpEnd1 XWS methods
#               "xws"
#                   update the XWS code with UpdateSw1 or UpdateXwsSw1 (TBD)
#
#   IN:     String
#               Type of update (see above)
#           String
#               Name of xzp file for update
#           String
#               DSC (not required for "xws" method)
#
#   OUT:    GOOD or ERROR
#
#   REQUIRES:
#           ?
#
#   TODO:   Add XWS method call
#           Add binary input as direct file (as in XWS spec)
#
###############################################################################
sub wsCodeUpdateWrapper
{
    my ($package, $filename, $line) = caller();
    logInfo("Looks like the $package sub of $filename is working on line $line\n");
    return(GOOD);
}
























1;
