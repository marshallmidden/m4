#!/usr/bin/perl -w
# $Header$

###############################################################################
# File name:  TestLibs::srub
#
# Desc: A set of library functions for integration testing. These focus on
#       the background scrub function.
#
# Date: 07/26/2002
#
# Original Author:  Olga Grigorenko
#
# Last modified by  $Author: AnasuriG $
# Modified date     $Date: 2006-11-14 00:08:29 -0600 (Tue, 14 Nov 2006) $
#
#   It is expected that the user will write a perl script that calls 
#   these library.
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################

=head1 NAME

TestLibs::scrub - Perl support for  bigfoot robusntess (endurance) testing

$Id: scrub.pm 15324 2006-11-14 06:08:29Z AnasuriG $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

This document describes usage of the Perl functions to test scrub

=head1 DESCRIPTION

Test Functions Available
                



=cut

package TestLibs::scrub;

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
use POSIX; 


use Socket;
use IO::Handle;


use File::Temp qw/ :mktemp  /;
use File::Path;
#use Archive::Tar;

use warnings;
use lib "../CCBE";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;


use TestLibs::Validate;
use TestLibs::IntegCCBELib;
use TestLibs::utility;
use TestLibs::Fibre;
use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :XSSA :CCBE :GRABBER);
use TestLibs::BEUtils;
use TestLibs::SCSI;

#
# Local constants
#

use constant SCRUBIDENB  =>  0x001A;
use constant SCRUBSTRENB => "SCRUB-Enable OK";

use constant SCRUBIDFIN  => 0x1000;
use constant SCRUBSTRFIN => "SCRUB-cycle OK";

use constant SCRUBIDDIS  =>  0x001A;
use constant SCRUBSTRDIS =>  "SCRUB-Disable OK";
use constant PDISKFAILID => " ";  


 #   @LogId = (0x8085);      
 #   @LogString = ("FAIL no hotspares");


  #  @LogId = (0x4062);
  #  @LogString = ("HOTSPARED");
    



#016020 0x001A2350 08:14:53pm 03/28/2003   Info    SCRUB-Enable OK
#String did not match to  RAID-0 control op OK
# count update: added  1  to 6


use constant DATADRDATAALL =>  1; 
use constant DATADRNODATA => 2;
use constant DATADRDATAONE =>  3;


use Dumpvalue;
my $dumper = new Dumpvalue;
my $dumper2 = new Dumpvalue;


STDOUT->autoflush(1);
STDERR->autoflush(1);


use strict;

BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 15324 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      &CntrOwnedRdVd
                      &ControllersValidateAll
                      &CorrectError
                      &CreateLogBitMap
                      &displayError
                      &FindDegradedRaids
                      &FindEmptySlots
                      &FindEmptySlots
                      &getVdiskRaids
                      &InList
                      &MakeFaildDriveOpr
                      &max
                      &OptNumberOfReads
                      &pdiskRestore
                      &PreTestSnapShot
                      &ReturnLastLog
                      &ScrubAddHotSpare
                      &ScrubFailController
                      &ScrubFaildDriveLetRebuild
                      &ScrubFailDrive
                      &ScrubFindError
                      &ScrubGoodPath
                      &ScrubMain
                      &ScrubPowerCycle
                      &ScrubRunDegraded
                      &ScrubShallNotFindError
                      &ScrubUnfailContr
                      &SearchLogs
                      &UnbaypassAll
                      &UnUsedDisks
                      &WriteError
                      
                     );

    #%EXPORT_TAGS = ();     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 15324 $);
}
    our @EXPORT_OK;

################################################################################

=head2 PreTestSnapShot
          
Gets initial information about system state such as
Back End info, IO activity info and Front End info.

=over 4

=item Usage:

 my $FuctionReturn = GetFwversion( $Obj, $Option );    
 
 where: $coPtr Pointer to the Controllers objects list 
        $Opt - ACTIVESERVERLIST (1)
                  TARGETMAP (2)                  
                  INITIALVDISKS (3)
                  SERIALNUMBERS (4)
                  PDISKDATA (5)
                  VDISKDATA (6)
                  RAIDDATA (7)

 
 my @FuctionReturn = @$FuctionReturn;
 if( $FuctionReturn[0] < 0)
 {
    print "Unable to retrieve information \n";
 } 

 Notes:
 
 None

=item Returns:

 On success - Returns array with information.
 On error - First element in the array is less then 0.

=back

=cut


##############################################################################
#
#          Name: PreTestSnapShot
#
#        Inputs: $coPtr Pointer to the Controllers objects list
#                $Opt Which item to return 
#
#               ACTIVESERVERLIST (1)
#               TARGETMAP (2)            
#               INITIALVDISKS (3)
#               SERIALNUMBERS (4)
#               PDISKDATA (5)
#               VDISKDATA (6)
#               RAIDDATA (7)
#
#       Outputs: Array of desired data 
#
#  Globals Used: none
#
#   Description: Gets initial information about system state such as 
#                Back End info, IO activity info and Front End info 
#                 
#                
#
##############################################################################

sub PreTestSnapShot
{
    my ( $coPtr, $Opt  ) = @_;
    trace();
        
    my @coList = @$coPtr ;      #-list of controller objects
    my $newMaster = INVALID;    #-will become an object of a master controller
    my $ret;                    #-display fuctions return 
    my @vCounts;                #-begining count for server activity
    my @sCounts;                #-end server count activity
    my %info1;                  #-target STATUS information
    my @serialNums;             #-serial numbers
    my @startingTmap;           #-Initial Target map
    my @activeServers;          #-Array of servers with IO
    my @initialVdisks;          #-Virtual disks with OI
    my $vdiskListPtr;           #-Instance of virtual disks pointer
    my @pdiskData;              #-Array of physical disks states
    my @vdiskData;              #-Array of virtual disks states
    my @raidData;               #-Array of raids states
    my $i = 0;                  #-Forloop count

    my @ReturnArray;

    ##########################################################################

    #
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    #


    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #    
    for ( $i = 0; $i < scalar(@coList); $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
        
    }


    #- Get Info on which controller is the master
     
    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    
    if ( $newMaster == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller  <<<<<<<<");
        $ReturnArray[0] = INVALID; 
    }

    if( $Opt == ACTIVESERVERLIST)
    {
        #
        # find the currently active servers
        #

        logInfo("Getting initial server activity counts");
        @sCounts = GetServerActivityCounts($coPtr);
                
        logInfo("Pause to allow server activity to accumulate");
        DelaySecs(20);

        @ReturnArray = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    }

    
    if( $Opt == TARGETMAP)
    {
        #
        # display target list
        #

        $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$newMaster] );
    
        if ( $ret != GOOD )
        {
            logError("Failed to get target list at start");
            $ReturnArray[0] = INVALID;
        }

        #
        # get the initial/starting target map
        #

        logInfo("Getting the target STATUS, then building the target map");

        $ret = GroupTargetMap($coPtr, \@serialNums, \@ReturnArray, $newMaster,  LOGTARGETMAP);
        if ( $ret != GOOD )  {$ReturnArray[0] = INVALID; }


    }

    
    if( $Opt == INITIALVDISKS)
    {
        #
        # get the initial active vdisks for the test
        #

        
        logInfo("Getting initial data for activity measurements.");
        @vCounts = GetVdiskActivityCounts($coPtr);
                
        logInfo("Pause to allow vdisk activity to accumulate");
        DelaySecs(20);

        @ReturnArray = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
        if ( scalar(@ReturnArray) != 0 )
        {
            # we have some active vdisks
            if ( $ReturnArray[0] == INVALID )
            {
                # error case 
                logInfo(">>>>>>>> Warning - can't get an initial active vdisklist  <<<<<<<<");
            }
        }
    }

    if( $Opt == SERIALNUMBERS)
    {
        @ReturnArray = @serialNums;
    }


    #
    # get initial BE data used for validation
    #

    if( $Opt == PDISKDATA )
    {
        #
        # display physical disk info
        #

        $ret = TestLibs::IntegCCBELib::DispPdiskInfo($coList[$newMaster]);

        if ( $ret != GOOD )
        {
            logError("Failed to get pdisk info at start");
            $ReturnArray[0] = INVALID;    
        }
        else
        {
            @ReturnArray = GetPdiskStateArray($coList[$newMaster]);
        }
    }
    
    if( $Opt == VDISKDATA)
    { 
        @ReturnArray = GetVdiskStateArray($coList[$newMaster]);
    }
    
    if( $Opt == RAIDDATA)
    {
        @ReturnArray = GetRaidStateArray($coList[$newMaster]); 
    }
    
    return @ReturnArray;

}

##############################################################################

=head2 ControllersValidateAll
          
Validate controllers state, virtual disk state, raids state, 
target state and if the targets have been moved back after fail over 
and rest of the appropriate controller, physical disk state and server activity.

=over 4

=item Usage:

 my $FuctionReturn = ControllersValidateAll ( $coPtr, 
                                              $activeServersRef, 
                                              $startingTmapRef,
                                              $vdiskListRef,
                                              $serialNumsRef,
                                              $pdiskDataRef,
                                              $vdiskDataRef,
                                              $raidDataRef);    
 
 where: $coPtr              - pointer to the list of controllers objects.
        $activeServersRef   - pointer to the server activity array obtained 
                                from GetServerActivityCounts();
        $startingTmapRef    - pointer to the targets activity obtained 
                                from CreateTargetMap().
        $vdiskListRef       - pointer to the virtual disk activity 
                                Obtained from GetVdiskActivityCounts().
        $serialNumsRef      - pointer to the list containing serial 
                                numbers of the controllers.
        $pdiskDataRef       - pointer to the list containing physical 
                                disk information obtained from GetPdiskStateArray(). 
        $vdiskDataRef       - pointer to the list containing physical
                                disk information obtained from GetVdiskStateArray().
        $raidDataRef        - pointer to the list containing physical
                                disk information obtained from GetRaidStateArray().
 
 if($FuctionReturn != 0)
 {
    print "Controller validation failed \n";
 }

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error - Returns 1 (ERROR).

=back

=cut





##############################################################################
#
#          Name: ControllersValidateAll
#
#        Inputs:
#               $coPtr              - pointer to the list of controllers objects.
#               $activeServersRef   - pointer to the server activity array obtained 
#                                       from GetServerActivityCounts();
#               $startingTmapRef    - pointer to the targets activity obtained 
#                                       from CreateTargetMap().
#               $vdiskListRef       - pointer to the virtual disk activity 
#                                       Obtained from GetVdiskActivityCounts().
#               $serialNumsRef      - pointer to the list containing serial 
#                                       numbers of the controllers.
#               $pdiskDataRef       - pointer to the list containing physical 
#                                       disk information obtained from GetPdiskStateArray(). 
#               $vdiskDataRef       - pointer to the list containing physical
#                                       disk information obtained from GetVdiskStateArray().
#               $raidDataRef        - pointer to the list containing physical
#                                       disk information obtained from GetRaidStateArray().
#
#       Outputs: Good (0), Error (1)
#
#  Globals Used: none
#
#   Description: Validate controllers state, virtual disk state, raids state, 
#                target state and if the targets have been moved back after fail over 
#                and rest of the appropriate controller, physical disk state and server activity.
#
#
##############################################################################


sub ControllersValidateAll
{
    
    my ( $coPtr, 
         $activeServersRef, 
         $startingTmapRef, 
         $vdiskListRef, 
         $serialNumsRef, 
         $pdiskDataRef, 
         $vdiskDataRef, 
         $raidDataRef  ) = @_;

    trace();
    
    my @ControllerObjectList = @$coPtr;
    
    logInfo(" ");

    my $FuntionRet = TestLibs::Validate::TestSystemState1(  $coPtr, 
                                                            $activeServersRef, 
                                                            $startingTmapRef, 
                                                            $vdiskListRef, 
                                                            $serialNumsRef);
    logInfo(" ");

    if ( $FuntionRet != GOOD )
    {
        logInfo("ERROR: Test Failed while comparing system general info [TestSystemState1]");
        return ERROR;
    }                                                                                  
    
    
    # check the back end state, vdisk status, pdisk status, raid status
    
    my $MasterObj = FindMaster($coPtr);

    logInfo(" ");
    
    $FuntionRet = TestLibs::Validate::TestSystemState2( $ControllerObjectList[$MasterObj], 
                                                        $pdiskDataRef, 
                                                        $vdiskDataRef, 
                                                        $raidDataRef);
    logInfo(" ");
    if ( $FuntionRet == ERROR )
    {
            logInfo("ERROR: Test Failed while comparing system general info [TestSystemState2");
            return ERROR;
    }

    logInfo("System validation is done...contunue SCRUB test....");   
    return GOOD;
}



##############################################################################

=head2 OptNumberOfReads
          
For each controller in VCG, based on number of raids and raid ownership, 
calculates the number of expected reads ( verify commands) to be issued 
to each physical disk.

=over 4

=item Usage:

 my @FuctionReturn = PrintScrubResulHash (  $ObjListRef );    
  
 
 where: $ObjListRef - Reference to the list of controller objects

 print "Number of controllers in the VCG that own raids  $FuctionReturn[0]{NUMLOGS}\n";
 
 shift(@FuctionReturn);

 for(my $i = 0; $i < scalar(@FuctionReturn); $i++)
 {
    print " For physical disk Id $FuctionReturn[$i]{PDID} \n";
    print " Number of expected reads $FuctionReturn[$i]{READNUM} \n";
 }
  
 Notes:
 
 None

=item Returns:

 On success $FuctionReturn[0]{STATUS} - Returns 0 (GOOD).
 On error $FuctionReturn[0]{STATUS} - Returns 1 (ERROR).

=back

=cut

##############################################################################
#
#          Name: OprNumberOfReads
#
#        Inputs: $ObjListRef - Reference to the list of controller objects
#
#       Outputs: Array of hashes
#
#  Globals Used: none
#
#   Description: For each controller, based on number of raids and raid 
#                ownership, calculates the number of expected 
#                reads ( verify commands ) to be issued to each physical disk.
#
#
##############################################################################

sub OptNumberOfReads
{
    my ( $ObjListRef ) = @_;

    trace();
    logInfo(" ");
    logInfo("-------------------------------------------------------");
    logInfo(" ");


    my %info;
    my @drives;
    my $i;
    my $j;
    my $msg;

    my $Beg;            #-Beggining address
    my $End;            #-End address
    my $Size;           #-Number of blocs occupided by the raid
 
    my $ReadNumberPerRaid; #-rounded number of reads per raid 
    my $ReadNumberPerDrive = 0;     #-number of reads per drive
                                    # needs to be 0 in case controller does
                                    # not have any owned raids on that drive

    
    my @MyOwnedRaids;

    my @UnsortedDrives;

    my @OprReadNum;     # full
    my $Count = 1;

    my @ObjList = @$ObjListRef;
    my $Master;                     # master controller
    my $Flag = FALSE;               # flag to see if controllers owns any 
                                    # raids
    
    #
    # Find master controller with in the group
    #
    
    $Master = FindMaster($ObjListRef);
        
    if($Master < 0)
    {
        logInfo("ERROR: unable to find master controller ");
        $OprReadNum[0]{STATUS} = ERROR;
        return @OprReadNum;     
    }
    
    
    #
    #  get a list of physical disks
    #
    
    @UnsortedDrives = GetPddList( $ObjList[$Master] );
     


    if ( $UnsortedDrives[0] == INVALID )
    {
        logInfo("ERROR: unable to get physical disk list");
        $OprReadNum[0]{STATUS} = ERROR;
        return @OprReadNum; 
    }
    
    #
    # sort the drives
    #
    
    @drives = sort{ $a <=> $b }@UnsortedDrives;
        
    #
    # Get controller owned raids
    #
    #
    
    my %MyRaids = CntrOwnedRdVd($ObjListRef);
    
    if($MyRaids{STATUS} != GOOD)
    {
        logInfo("ERROR: anable to get controller owned raids");
        $OprReadNum[0]{STATUS} = ERROR;
        return @OprReadNum;
    }
    
    
    #
    # Print some info about controllers that own reaids
    # Check if there's atleast one controller that ownes some raids
    #
    my @CtrOwnerSr = keys( %MyRaids );

    # need to shift to get red of status

    shift(@CtrOwnerSr);

    logInfo("Number of controller that own raids ". scalar(@CtrOwnerSr));
        
    if(scalar(@CtrOwnerSr) == 0)
    {
        logInfo("None of the controllers in VCG own any raids");
        $OprReadNum[0]{STATUS} = ERROR;
        return @OprReadNum;
    }



    for(my $Sr = 0; $Sr < scalar(@ObjList); $Sr++)
    {
        
        # - Comment
        # The controller owned raids hash has following format:
        # $hash{Controller serial } = $ Reference to the array with raid Ids 
        # owned by the controller if controller does not own any raids 
        # its serial number will not be present with in the keys of the hash
    
        #
        # Get serial numbers for all controllers
        #

        
        my $CtrSerial = TestLibs::IntegCCBELib::GetSerial($ObjList[$Sr]);
    
        if($CtrSerial < 0)
        {
            logInfo("ERROR: Faild to get controller serial number ");
            $OprReadNum[0]{STATUS} = ERROR;
            return @OprReadNum;
        }
        
        #
        # Create a temp variable for Convenience 
        # Check if Controller owns raid
        #
        
        my $TemRaidRef = $MyRaids{$CtrSerial}; 
        
        
        # reset flag
        # if there is a value in the temp variable 
        # set the flag to True
 
        $Flag = FALSE;

        if($TemRaidRef)
        {
            @MyOwnedRaids = @$TemRaidRef;
            # set the flag to true
            $Flag = TRUE;
        }
        
        logInfo("  Evaluating current SOS tables for controller ". $ObjList[$Sr]->{HOST});

        #
        # for each physical disk id get SOStable 
        #
        
        for ( $i = 0; $i < scalar(@drives); $i++ )
        {
       
            #
            # get the SOS table
            #

            %info = $ObjList[$Sr]->getSos($drives[$i]);
       
            if( ! %info )
            {
                logInfo(">>>>>>>> Failed to get SOS information. <<<<<<<<");
                $OprReadNum[0]{STATUS} = ERROR;             
                return @OprReadNum; 

            }

            if ( $info{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from getSOS command <<<<<<<<");
                PrintError(%info);
                $OprReadNum[0]{STATUS} = ERROR;
                return @OprReadNum; 
            }       
       
            #
            # If flag is True, that means that controller owns some raids, 
            # for all raids owned by the controller check if any of them 
            # are present on the physical disk 
            #
             
                        #
            # Reset number of reads for each drive to 0
            #

            $ReadNumberPerDrive = 0; 


            if($Flag == TRUE)
            {
                #
                # Raids on the drive are owned by the controllers
                # there are reads expected for the drives
                #
            
                for ($j = 0; $j < $info{COUNT}; $j++)
                {       
                    for(my $p = 0; $p < scalar(@MyOwnedRaids); $p++ )
                    {   
                                                
                        if( $MyOwnedRaids[$p] == $info{LIST}[$j]{RID} )
                        {
                            # Reset number of reads per raid

                            $ReadNumberPerRaid = 0;
                            
                            # Calculate number of reads for raid on each physical drive    
                            
                            $ReadNumberPerRaid = ceil(( $info{LIST}[$j]{LEN} * 512 ) / (1024 * 1024));                          
                            
                            # Add number of reads 
                            
                            $ReadNumberPerDrive = ($ReadNumberPerDrive + $ReadNumberPerRaid);    
                        }
                    }
                }
            }
        
            logInfo("Pd Id ". $drives[$i]. " should have ".$ReadNumberPerDrive." number of reads");
            $OprReadNum[$Count]{PDID} = $drives[$i];
            $OprReadNum[$Count]{READNUM} = $ReadNumberPerDrive;
            $Count++;
        }
    }
    
    # Number of controllers that have ownership 
    # Number of log messager of scurb state change expected

    $OprReadNum[0]{NUMLOGS} = scalar(@CtrOwnerSr); 
    
    $OprReadNum[0]{STATUS} = GOOD;
    return @OprReadNum;
}


##############################################################################

=head2 ScrubFailController


Test case description:

          
1.  If required, stop IO and power down the servers.
2.  Baseline the baseline number of reads on each physical disk from all controllers.
3.  Enable scrubbing or mirror scanning - ensure that a scrub enabled, 
with a scrub state of 0x01, log event appears (0x1E)
4.  Issue a fail controller command.
5.  Wait until a (Scrub cycle complete) log event (0x00) appears when the 
first scrub cycle completes.
6.  Check the number of reads made on each physical disk and calculate a 
difference from step 2 above.  Display the delta.
7.  Disable scrubbing - ensure that a "scrub disabled" with a scrub state 
of 0x00 log event appears (0x1E).

=over 4

=item Usage:

 my $FuctionReturn = ScrubFailController (  $ObjListRef,
                                            $TimeToRunTheTest );    
  
 
 where: $ObjListRef - Reference to the list of controller objects
        $TimeToRunTheTest - Number of times to run the test

  
 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut



##############################################################################
#
#          Name: ScrubFailController
#
#        Inputs: $ObjListRef - Reference to the list of controller objects
#                $TimeToRunTheTest - Number of times to run the test
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Tests scrub trough fail over 
#
#
##############################################################################

sub ScrubFailController
{
    trace();

    my( $ObjListRef,  $CntSrlRef, $ParityControl, $MoxaIp, $MoxaChan ) = @_;
    
    # $MasterObj, $FailSerialNumber, $RebootObj, $MoxaIp, $Chan
    
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo(">>>>>>>>>>   Scrub Fail Controller test case    <<<<<<<<<<");
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");


    my @LogId; 
    my @LogString;
    my @ExpReads;
    my $ScrubControl;               #-Enable disable scrub option 
    my $FunctionRet;                #-return from variose functions
    my @ObjList = @$ObjListRef;

    
    
    my @CntSrl = @$CntSrlRef;
    my $Master;                     #-possition of the master controller on the list
    my $CntFailSrl;                 #-controller to be failed serial number

    my @CtrSerial;                  #-serial number(s) of the controller(s)

    
    if(scalar(@ObjList) < 2)
    {
        logInfo("ERROR: VCG has only one controller");
        logInfo("Unable to run the test, the test will be invalid");
        return ERROR;
    }
    

    #
    # Find master controller
    # ( Will fail master controller )

    $Master = FindMaster( $ObjListRef );

    if( $Master < 0)
    {
        logInfo("ERROR: Faild to find master controller");
        return ERROR;
    }

    # Enable scrub
    # number of messages for scrub enable is 1 
    # does not depend on ownership of raids by the controllers
    #

    $ScrubControl = "ENABLE";

    @LogId = ( SCRUBIDENB ); # log id for scrub 
    @LogString = ( SCRUBSTRENB );
                
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,          # number of logs
                                        FALSE,
                                        $ParityControl);

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile changing scrub state ");
        return ERROR;
    }

    # Fail master controller

    $FunctionRet = FailController($ObjList[$Master], 
                                  $CntSrl[$Master]);

    if( $FunctionRet != GOOD)
    {
        logInfo(" ");
        logInfo("ERROR: Can not fail controller serial number ". $CntFailSrl);
        return ERROR;
    }
    
    logInfo("Controller serial ". $CntSrl[$Master] ." was failed");
    
    # - allow targets to move

    delay(120);
    
    # Since maser controller is faild
    # Removed object of master controller object from the list of objects

	my @GoodObjList = @ObjList;
	 
    splice(@GoodObjList, $Master, 1);
    
    print "Number of objects is ", scalar(@GoodObjList), " \n";
    

    # Get expeceted number of reads for all controllers

    @ExpReads = OptNumberOfReads( \@GoodObjList );
    
    
    if($ExpReads[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: while getting expected reads data");
        return ERROR;
    }
    
    #
    # Find message of scrub cycle finish, 
    # number of expected logs = to number of 
    # controllers that own raids
    #

    @LogId = (SCRUBIDFIN);
    @LogString = ( SCRUBSTRFIN);
    
    $FunctionRet = _SubSetSubroutine(   \@GoodObjList, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        $ExpReads[0]{NUMLOGS},
                                        TRUE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile looking for scrub finish cycle log ");
        return ERROR;
    }

    # Disable scrub
    #
    # number of messages for scrub enable is 1 
    # does not depend on ownership

    $ScrubControl = "DISABLE";      
    @LogId = ( SCRUBIDDIS ); # log id for scrub 
    @LogString = ( SCRUBSTRDIS );

    $FunctionRet = _SubSetSubroutine(   \@GoodObjList, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,          # logs
                                        FALSE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }   


    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo(">>>>>>>>>>   Scrub Un-fail Controller test case  <<<<<<<<<<");
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    
    
    logInfo(" ");
    logInfo("Enabling scrub ");
    logInfo(" ");

    $ScrubControl = "ENABLE";
    @LogId = ( SCRUBIDENB ); # log id for scrub 
    @LogString = (SCRUBSTRENB);
                
    $FunctionRet = _SubSetSubroutine(   \@GoodObjList, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,              # number of log massages expected
                                        FALSE,          # is scrub set - false - setting scrub
                                        $ParityControl);
    
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile changing scrub state ");
        return ERROR;
    }

    # Unfail controller(s)
	
    $FunctionRet = TestLibs::BEUtils::UnfailAll(\@ObjList, 
                                                $CntSrlRef, 
                                                $MoxaIp, 
                                                $MoxaChan);
    
    if($FunctionRet != GOOD)
    {
        logInfo("Unable to unfail failed controller");
        return ERROR;   
    }
    
        
    # Get expeceted number of reads for all controllers

    @ExpReads = OptNumberOfReads( $ObjListRef);

    if($ExpReads[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: while getting expected reads data");
        return ERROR;
    }
    
    # Look for the first cycle to finish

    logInfo(" ");
    logInfo("Looking for scrub cycle to complete ");
    logInfo(" ");
    @LogId = ( SCRUBIDFIN );
    @LogString = ( SCRUBSTRFIN );
    
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        $ExpReads[0]{NUMLOGS},
                                        TRUE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile looking for scrub finish cycle log ");
        return ERROR;
    }

    #
    # Disable scrub
    #
    # number of messages for scrub enable is 1 
    # does not depend on ownership
    #


    logInfo(" ");
    logInfo("Disabling scrub  ");
    logInfo(" ");

    $ScrubControl = "DISABLE";
    
    @LogId = ( SCRUBIDDIS ); # log id for scrub 
    @LogString = ( SCRUBSTRDIS );

    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,
                                        FALSE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }   

    
    logInfo("Test completion ..... GOOD ");
    return GOOD;    
      
}
    


##############################################################################

=head2 ScrubGoodPath

Test case description:
            
1.  If required, stop IO and power down the servers.
2.  Enable scrubbing or mirror scanning - ensure that a scrub enabled, 
with a scrub state of 0x01, log event appears (0x1E)
3.  Power cycle both controllers.
4.  Wait until a Scrub cycle complete log event (0x00) appears when the 
first scrub cycle completes.
5.  Check the number of reads made on each physical disk.  Since power 
cycling the controller will clear the read counters there is no need to 
calculate a difference from the beginning of the test.  Display the read counts.
6.  Disable scrubbing - ensure that a scrub disabled with a scrub state 
of 0x00 log event appears (0x1E).


=over 4

=item Usage:

 my $FuctionReturn = ScrubGoodPath (    $ObjListRef,
                                        $TimeToRunTheTest );    
  
 
 where: $ObjListRef - Reference to the list of controller objects
        $TimeToRunTheTest - Number of times to run the test

  
 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut




##############################################################################
#
#          Name: ScrubGoodPath
#
#        Inputs: $ObjListRef - Reference to the list of controller objects
#                $TimeToRunTheTest - Number of times to run the test
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Test scrub functionality with no intervention 
#
#
##############################################################################

sub ScrubGoodPath
{
    trace();

    my( $ObjListRef, $ParityControl ) = @_;

 
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo(">>>>>>>>>>   Scrub Good Path test case          <<<<<<<<<<");
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");

    my @LogId; 
    my @LogString;

    
    my $ScrubControl;       #-Enable disable scrub option 
    
    my $FunctionRet;
    my $LogNumExp = 0;

    my @ObjList = @$ObjListRef;

    my @startingTmapRef; 
    
    # - Get the info about the VCG for validation.

    my @startingTmap = PreTestSnapShot( $ObjListRef, TARGETMAP );
    my @serialNums = PreTestSnapShot( $ObjListRef, SERIALNUMBERS );
    my @pdiskData = PreTestSnapShot( $ObjListRef, PDISKDATA );
    my @vdiskData = PreTestSnapShot( $ObjListRef, VDISKDATA );
    my @raidData = PreTestSnapShot( $ObjListRef, RAIDDATA );

    # Check is data was successfully retrieved

    if( ( $startingTmap[0] == INVALID )  ||
        ( $serialNums[0] == INVALID )    ||
        ( $pdiskData[0] == INVALID )     ||
        ( $vdiskData[0] == INVALID )     ||
        ( $raidData[0] == INVALID )) 
        
    {
        logInfo("Failed while getting validate information...");
        return ERROR;
    }


    # Get expeceted number of reads for all controllers
    # in order to know how many log messages to expect bassed on 
    # controllers owning raids
    
    my @ExpReads = OptNumberOfReads( $ObjListRef);
    
    if($ExpReads[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: while getting expected reads data");
        return ERROR;
    }
    
    $LogNumExp = $ExpReads[0]{NUMLOGS};

    logInfo("Number of controllers owning raids $LogNumExp ");

    #
    # Enable scrub
    #
    # number of messages for scrub enable is 1 
    # does not depend on controller raid ownership
    #


    $ScrubControl = "ENABLE";
    @LogId = (  SCRUBIDENB ); # log id for scrub 
    @LogString = ( SCRUBSTRENB );
            
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,              # number of log messages expected 
                                        FALSE,
                                        $ParityControl);


    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile changing scrub state ");
        return ERROR;
    }


    # Look for log message of the first scrub cycle to compete
    
   #    $ParityControl = "NONE";
   #    $ScrubControl = "NONE"; 
    
    @LogId = ( SCRUBIDFIN );
    @LogString = ( SCRUBSTRFIN );

    $FunctionRet = _SubSetSubroutine($ObjListRef, 
                                     $ScrubControl, 
                                     \@LogId, 
                                     \@LogString, 
                                     $LogNumExp,
                                     TRUE,
                                     $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile looking for scrub finish cycle log ");
        return ERROR;
    }

    # number of messages for scrub disable is 1 
    # does not depend on raid ownership

    logInfo("Scrub cycle compete - disableing scrub....");

    $ScrubControl = "DISABLE";

    @LogId = ( SCRUBIDDIS ); # log id for scrub 
    @LogString = (SCRUBSTRDIS);

    $FunctionRet = _SubSetSubroutine($ObjListRef, 
                                     $ScrubControl, 
                                     \@LogId, 
                                     \@LogString, 
                                     1,
                                     FALSE,
                                     $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }   

    # - Do the system check 

    $FunctionRet = ControllersValidateAll(  $ObjListRef,
                                            0,
                                            \@startingTmap,
                                            0,
                                            \@serialNums,
                                            \@pdiskData,
                                            \@vdiskData,
                                            \@raidData);

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed: system data mismatch");
        return ERROR;
    } 
    return GOOD;    
}


##############################################################################

=head2 ScrubFindError

Test case description:
            
1.  If required, stop IO and power down the servers.
2.  Stop IO on a VDisk.  If we are testing the scrubbing function use the 
SOS function to locate an LBA used by this VDisk,  Then use the SCSICMD
command to send a WriteLongDiag command to corrupt this sector.  If we 
are testing the mirror scanning function, then use the SOS function to 
locate 100 LBAs used by this VDisk (somehow make sure we dont write both 
the primary copy and the mirror of any piece of data).  In this case use 
the SCSICMD to send a write command to zero out each one of these LBAs.
3.  Enable scrubbing or mirror scanning - ensure that a scrub enabled, 
with a scrub state of 0x01, log event appears (0x1E)
4.  At some point the scrub or mirror scanning should detect these errors.  
If scaning is being tested then the disk should fail and a rebuild should 
occur.  If mirror scanning is being tested then each LBA in error should 
be found but no fail-over should occur.
5.  Wait until a Scrub cycle complete log event (0x00) appears when the 
first scrub cycle completes.
6.  Disable scrubbing - ensure that a scrub disabled with a scrub state 
of 0x00 log event appears (0x1E).
7.  Issue a write to each sector corrupted in step 2 above to correct each 
corrupted sector.
8.  If a disk failed during this test then un-fail the disk, make it a hot 
spare, and fail the disk that the data was rebuilt on in step 4.  Finally, 
un-fail that disk and label it as a hot spare.

=over 4

=item Usage:

 my $FuctionReturn = ScrubFindError (   $ObjListRef,
                                        $TimeToRunTheTest );    
  
 
 where: $ObjListRef - Reference to the list of controller objects
        $TimeToRunTheTest - Number of times to run the test

  
 Notes: This test case is current not finished (waiting for Jeff :) )
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut


##############################################################################
#
#          Name: ScrubFindErrorAllDr
#
#        Inputs: Pointer to the list of controller objects
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: This test writes errors to parts of the disks that should
#                not be scrubbed or mirror scanned and makes sure that 
#                scrubbing does not detect these errors.
#
#
##############################################################################

sub ScrubFindError
{
    trace();

    my( $ObjListRef, $ParityControl, $Option) = @_;
    my $ret;
    
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo("  Scrub Hard Errors on the Drives Return Check Conditions ");
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");

    my @LogId; 
    my @LogString;
    my @ExpReads;

    my $FunctionRet;
    
    my $ErrorNum;

    my @ErrorWriteData;
    
    my $ScrubControl;       #-Enable disable scrub option 
      
    my $SrubEnbleCount = 0; #-number of times scurb command has been issued

    my @ObjList = @$ObjListRef;

    # Check to see if only on one or physical disk the data has to be 
    # corupted
    
    my $DrivesCorruptOption = DATADRDATAONE; 
    
    if($Option)
    {
        if("$Option" eq "ALL")
        {
            $DrivesCorruptOption = DATADRDATAALL;       
        }
    }     

    # System validation variables

    my @startingTmapRef;
    my @serialNums; #-validate serial numbers
    my @pdiskData;  #-validate pdisk info
    my @vdiskData;  #-validate vdisk info
    my @raidData;   #-validate raid info
    my @startingTmap;
    

    # - Get the info about the VCG, Collect the system data at the 
    #   begging of the test 

    @startingTmap = PreTestSnapShot( $ObjListRef, TARGETMAP );
    @serialNums = PreTestSnapShot( $ObjListRef, SERIALNUMBERS );
    @pdiskData = PreTestSnapShot( $ObjListRef, PDISKDATA );
    @vdiskData = PreTestSnapShot( $ObjListRef, VDISKDATA );
    @raidData = PreTestSnapShot( $ObjListRef, RAIDDATA );

    if(( $startingTmap[0] == INVALID )  ||
       ( $serialNums[0] == INVALID )    ||
       ( $pdiskData[0] == INVALID )     ||
       ( $vdiskData[0] == INVALID )     ||
       ( $raidData[0] == INVALID )) 
    {
        logInfo("Failed while getting validate information...");
        return ERROR;
    }
    
    # Get expeceted number of reads for all controllers

    @ExpReads = OptNumberOfReads( $ObjListRef );
    
    if($ExpReads[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: while getting expected reads data");
        return ERROR;
    }

    #
    # Write errors on each data or unsafe drive that contains data (raids)
    # inside of last raid data range, so that hard errors will be detected 
    # by scrub
    #
    
    logInfo("Looking for master controller in VCG ");

    my $Master = FindMaster( $ObjListRef );
    
    if($Master == INVALID)
    {
        logInfo("Can not find master controller");
        return ERROR;
    }

    @ErrorWriteData = WriteError($ObjList[$Master],$DrivesCorruptOption);
    
    # - Check return for Errors
    
    if($ErrorWriteData[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: occured while writing errors to physical drives");
        return ERROR;
    }
    
    # - Get red of status
    
    shift(@ErrorWriteData);
    
    $ErrorNum = scalar(@ErrorWriteData);
    
    logInfo("Number of scrub check condition messages: $ErrorNum ");
    
    #
    # Enable scrub
    #
    # number of messages for scrub enable is 1 
    # does not depend on Controller ownership of the virtual disks
    #

    $ScrubControl = "ENABLE";
    @LogId = ( SCRUBIDENB ); # log id for scrub 
    @LogString = (SCRUBSTRFIN);
                
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,          # number of expected logs 
                                        FALSE,
                                        $ParityControl);
    

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile changing scrub state ");
        return ERROR;
    }

    #
    # Look for the scrub first cycle to finish
    # Since each controller scrubs only its own raids, number of 
    # expected log messages of indicating that scrub cycle is 
    # compete depends on the number of controllers that own virtual 
    # disks hence raids  
    #

    @LogId = (SCRUBIDFIN);
    @LogString = (SCRUBSTRFIN);
    
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        $ExpReads[0]{NUMLOGS},
                                        TRUE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile looking for scrub finish cycle log ");
        return ERROR;
    }
    
    #
    # number of messages for scrub enable is 1 
    # does not depend on ownership
    # Scrub disable works the same way as scrub enable, hence there's 
    # only one log message expected of scrub state change issued on 
    # the master controller, master then will propagate scrub state 
    # to the slave(s) controller(s) 
    #


    $ScrubControl = "DISABLE";
    @LogId = (SCRUBIDDIS); # log id for scrub 
    @LogString = (SCRUBSTRDIS);

    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,          # number of expected logs
                                        FALSE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }   
    
    # Correct all created error on the physical disks
    
    logInfo(" ");
    logInfo("Correcting error written to the physical drives ");
    
    $FunctionRet = CorrectError($ObjList[$Master], @ErrorWriteData);



    
    # - Do the system validation check 

    $FunctionRet = ControllersValidateAll($ObjListRef,
                                          0,
                                          \@startingTmap,
                                          0,
                                          \@serialNums,
                                          \@pdiskData,
                                          \@vdiskData,
                                          0); # \@raidData);
    
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed: system data mismatch");
        return ERROR;
    }       

    logInfo("Test completion ..... GOOD ");
    return GOOD;      
}



##############################################################################

=head2 ScrubFindError

Test case description:
            
1.  If required, stop IO and power down the servers.
2.  Stop IO on a VDisk.  If we are testing the scrubbing function use the 
SOS function to locate an LBA used by this VDisk,  Then use the SCSICMD
command to send a WriteLongDiag command to corrupt this sector.  If we 
are testing the mirror scanning function, then use the SOS function to 
locate 100 LBAs used by this VDisk (somehow make sure we dont write both 
the primary copy and the mirror of any piece of data).  In this case use 
the SCSICMD to send a write command to zero out each one of these LBAs.
3.  Enable scrubbing or mirror scanning - ensure that a scrub enabled, 
with a scrub state of 0x01, log event appears (0x1E)
4.  At some point the scrub or mirror scanning should detect these errors.  
If scaning is being tested then the disk should fail and a rebuild should 
occur.  If mirror scanning is being tested then each LBA in error should 
be found but no fail-over should occur.
5.  Wait until a Scrub cycle complete log event (0x00) appears when the 
first scrub cycle completes.
6.  Disable scrubbing - ensure that a scrub disabled with a scrub state 
of 0x00 log event appears (0x1E).
7.  Issue a write to each sector corrupted in step 2 above to correct each 
corrupted sector.
8.  If a disk failed during this test then un-fail the disk, make it a hot 
spare, and fail the disk that the data was rebuilt on in step 4.  Finally, 
un-fail that disk and label it as a hot spare.

=over 4

=item Usage:

 my $FuctionReturn = ScrubFindError (   $ObjListRef,
                                        $TimeToRunTheTest );    
  
 
 where: $ObjListRef - Reference to the list of controller objects
        $TimeToRunTheTest - Number of times to run the test

  
 Notes: This test case is current not finished (waiting for Jeff :) )
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut





##############################################################################
#
#          Name: ScrubShallNotFindError
#
#        Inputs: Pointer to the list of controller objects
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Comapares Controller(s) Version(s), if all the same returns
#                GOOD if defferent return ERROR;
#
#
##############################################################################

sub ScrubShallNotFindError
{
    trace();

    my( $ObjListRef, $ParityControl ) = @_;

    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo(">>>  Scrub Hard Errors on the Drives No Check Conditions <<<");
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");

    my @LogId; 
    my @LogString;
    my @ExpReads;

    my @ErrorWriteData;
    
    my $ScrubControl;       #-Enable disable scrub option     
    my $FunctionRet;        #-return from functions
  
    my @ObjList = @$ObjListRef;

         
    #
    # - Get the info about the VCG, Collect the system data at the 
    #   begging of the test 
    #

    my @startingTmap = PreTestSnapShot( $ObjListRef, TARGETMAP );
    my @serialNums = PreTestSnapShot( $ObjListRef, SERIALNUMBERS );
    my @pdiskData = PreTestSnapShot( $ObjListRef, PDISKDATA );
    my @vdiskData = PreTestSnapShot( $ObjListRef, VDISKDATA );
    my @raidData = PreTestSnapShot( $ObjListRef, RAIDDATA );

    if(( $startingTmap[0] == INVALID )  ||
       ( $serialNums[0] == INVALID )    ||
       ( $pdiskData[0] == INVALID )     ||
       ( $vdiskData[0] == INVALID )     ||
       ( $raidData[0] == INVALID )) 
    {
        logInfo("Failed while getting validate information...");
        return ERROR;
    }

    
    #
    # Get expeceted number of reads for all controllers
    # need this functin to figer out how many controllers own raids
    # in order to know how many controllers will issue a message of scrub
    # cycle compete
    #

    @ExpReads = OptNumberOfReads( $ObjListRef, DATADRNODATA);
    
    
    if($ExpReads[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: while getting expected reads data");
        return ERROR;
    }
 
    
    #
    # Wright error on each data drive that contains data (raids)
    # out side of data range, so that hard errors will not be detected 
    # by scrub
    #
    
    logInfo("Looking for master controller in VCG ");

    my $Master = FindMaster( $ObjListRef );
    
    if($Master == INVALID)
    {
        logInfo("Can not find master controller");
        return ERROR;
    }
    
    
    @ErrorWriteData = WriteError($ObjList[$Master],DATADRNODATA);
    
    # - Check return for Errors
    
    if($ErrorWriteData[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: occured while writing errors to physical drives");
        return ERROR;
    }
    
    # - Get red of status
    
    shift(@ErrorWriteData);
    
    #
    # Enable scrub
    #
    # number of messages for scrub enable is 1 
    # does not depend on Controller ownership of the virtual disks
    #

    $ScrubControl = "ENABLE";
    @LogId = ( SCRUBIDENB );    
    @LogString = (SCRUBSTRENB);
                
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,              # number of expected messages
                                        FALSE,
                                        $ParityControl);
    

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }

    #
    # Look for the scrub first cycle to finish
    # Since each controller scrubs only its own raids, number of 
    # expected log messages of indicating that scrub cycle is 
    # compete depends on the number of controllers that own virtual 
    # disks hence raids  
    #

    @LogId = ( SCRUBIDFIN );
    @LogString = ( SCRUBSTRFIN );
    
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl,          # is no used this time
                                        \@LogId, 
                                        \@LogString, 
                                        $ExpReads[0]{NUMLOGS},  # number of log messages expected based on ownership
                                        TRUE,                   # scrub is set - true
                                        $ParityControl);        # is not used this time
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile looking for scrub finish cycle log ");
        return ERROR;
    }
    
    #
    # number of messages for scrub enable is 1 
    # does not depend on ownership
    # Scrub disable works the same way as scrub enable, hence there's 
    # only one log message expected of scrub state change issued on 
    # the master controller, master then will propagate scrub state 
    # to the slave(s) controller(s) 
    #


    $ScrubControl = "DISABLE";
    
    @LogId = ( SCRUBIDDIS ); # log id for scrub 
    @LogString = (SCRUBSTRDIS);

    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,               # number of log messages expected
                                        FALSE,           # changeing scrub state
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }   
    
    # Correct all created error on the physical disks

    logInfo(" ");
    logInfo("Correcting error written to the physical drives ");
    
    $FunctionRet = CorrectError($ObjList[$Master], @ErrorWriteData);

    
    # - Do the system validation check 

    $FunctionRet = ControllersValidateAll($ObjListRef,
                                          0,
                                          \@startingTmap,
                                          0,
                                          \@serialNums,
                                          \@pdiskData,
                                          \@vdiskData,
                                          \@raidData);
    
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed: system data mismatch");
        return ERROR;
    } 
    
    logInfo("Test completion ..... GOOD ");
    return GOOD;    
      
}

##############################################################################
#
#          Name: ScrubShallNotFindError
#
#        Inputs: Pointer to the list of controller objects
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Comapares Controller(s) Version(s), if all the same returns
#                GOOD if defferent return ERROR;
#
#
##############################################################################

sub WriteError
{
    my ($MasterObj, $Option) = @_;
    
    my @Return;
    my $FunctionRet;
    my @FunctionRet;
    my @DriveIdsCorrupt;
    my $length;
    my $AddLength = 0;      #-Number to add to the begging address, allowes 
                        # to write where data exist of write where there's 
                        # no data

    my $i = 0;          #-General for loop count
    my $Flag = 0;       #-Flag to know if corrupt data or write to empty
                        # space on the drive 
    
    my $NumberOfDriveToCorrupt = 0;


    #
    # If option is corrupt data drives data, select all the drives that have data
    # written on them, and write one error on the first raids (if more raids 
    # then one present) per drive 
    #
        
    #
    # If option is corrupt data drives no data, write one error per each 
    # drive 
    #

    
    #
    # Need to get all the drives that are not labeled as hotspare
    # 1. Get all drives labeled as Data
    # 2. Get all drives labeld as unsafe
    
    logInfo(" ");
    logInfo("Getting list of all drives labeled as Data");

    my @Temp = TestLibs::IntegCCBELib::GetTheseDisks($MasterObj, 
                                                     CCBEDATATYPE);
    
    if($Temp[0]) 
    {
        if($Temp[0] < 0)
        {
            logInfo("Error: can not get list of data drives");
            $Return[0]{STATUS} = ERROR; 
            return @Return;
        }
    }

    
    #
    # Push all the drive on a array
    #
            
    for( $i = 0; $i < scalar(@Temp); $i++)
    {
        push(@DriveIdsCorrupt, $Temp[$i]);
    }   
    
    logInfo("Getting list of all drives labeled as Unsafe");

    @Temp = TestLibs::IntegCCBELib::GetTheseDisks($MasterObj, 
                                                  CCBEUNSAFETYPE);
    
    if($Temp[0])
    {
        if( $Temp[0] < 0)
        {
            logInfo("Error: can not get list of unsafe data drives");
            $Return[0]{STATUS} = ERROR; 
            return @Return;
        }
    }

    #
    # Push all the drive on a array
    #
    
    for( $i = 0; $i < scalar(@Temp); $i++)
    {
        push(@DriveIdsCorrupt, $Temp[$i]);
    }   

    if(scalar(@DriveIdsCorrupt) == 0)
    {
        logInfo("There are no physical disk to corrupt :( ");
        $Return[0]{STATUS} = ERROR; 
        return @Return;
    }

    if($Option == DATADRNODATA)
    {
        #
        # Write 0000's on all physcal drives
        #
        $Flag = 1;
        $NumberOfDriveToCorrupt = scalar(@DriveIdsCorrupt);

    }
    if($Option == DATADRDATAALL)
    {
        #
        # Corupt data on all physical drives
        #

        $Flag = 0;
        $NumberOfDriveToCorrupt = scalar(@DriveIdsCorrupt);
    
    }
    
    if($Option == DATADRDATAONE)
    {
        #
        # Corupt data on 1 physical drive
        #

        $Flag = 3;
        $NumberOfDriveToCorrupt = 1;
    
    }       
    
    

    logInfo(" ");
    logInfo("Getting SOS tables for Drives: @DriveIdsCorrupt");
    
    my $RetCount = 1; # count of the return array of hashes


    for( $i = 0; $i < $NumberOfDriveToCorrupt; $i++)
    {
        logInfo("Getting SOStable for drive id $DriveIdsCorrupt[$i]");

        my %info = $MasterObj->getSos($DriveIdsCorrupt[$i]);
        
        if( ! %info )
        {
            logInfo("Failed to get SOS information for drive $DriveIdsCorrupt[$i].");
            $Return[0]{STATUS} = ERROR; 
            return @Return;
        }

        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from getSOS command <<<<<<<<");
            PrintError(%info);
            $Return[0]{STATUS} = ERROR; 
            return @Return; 
        }       
        
        my %PDInfo = $MasterObj->XIOTech::cmdMgr::physicalDiskInfo($DriveIdsCorrupt[$i]);
        
        logInfo("Getting information for pd id $DriveIdsCorrupt[$i] ");
        if( ! %PDInfo )
        {
            logInfo("Failed to get pdisk information for drive $DriveIdsCorrupt[$i].");
            $Return[0]{STATUS} = ERROR; 
            return @Return;
        }

        if ( $PDInfo{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from physicalDiskInfo command <<<<<<<<");
            PrintError(%PDInfo);
            $Return[0]{STATUS} = ERROR; 
            return @Return; 
        }       

        #
        # Set the flag of either corrupting raids or "empty space on the drive" 
        # 1. Get the last element in the array of hashed from the sos table
        #    in other words get the last data location 
        # 2. It flag is set to anyting else then 1 corupt data adding lenth of 
        #    to the starting address = to the last raids lenth + one blok of data
        #
        
        
        # 1.


        #
        # Assume that there's not raids on the drive set the last raid poss in 
        # the array to 0, check if there's any raids and if there're set the last
        # raids poss. 
        #
    
        my $Element = 0;
        
        #
        # Starting address to write to
        #
        
        my $lba = 327680;
        
        $AddLength = 0;
        
       
        #
        # Data to write
        #

        my $writeBuffer = "00000000";

        #
        # If there are raids on the drive
        #
        
        if($info{COUNT})
        {
            $Element = $info{COUNT} - 1;
            
            # 2. Write pass data

            if($Flag == 1)
            {
                $AddLength = $info{LIST}[$Element]{LEN} + 512;  
            }
            
            #
            # Find the begging address of where to write data
            #
            
            $lba = ($info{LIST}[$Element]{SDA} + $AddLength);
        }


        logInfo("Checking for Valid READ/WRITE Long Length in range of:  512 - 650");
        
        #
        # Loop until valid length is found 
        #
        for($length = 512; $length < 650; $length++)
        {

            @FunctionRet = TestLibs::SCSI::SCSIReadLong($MasterObj, 
                                                         $PDInfo{WWN_HI}, 
                                                         $PDInfo{WWN_LO},
                                                         $PDInfo{PD_LUN},
                                                         $lba,
                                                         $length,
                                                         \$writeBuffer,
                                                         0);
            if($FunctionRet[0] == ERROR)
            {
            $length++;
            }
            else
            {
            logInfo("Valid Length FOUND of $length ");
            last;
            }
        }    
       
        
        
        #
        # Log all passed data before issuing the WriteLong
        #
        logInfo(" ");
        logInfo("Master obj "); 
        logInfo("PDInfo{WWN_HI} $PDInfo{WWN_HI}");
        logInfo("PDInfo{WWN_LO} $PDInfo{WWN_LO} ");

        logInfo("PDInfo{PD_LUN} $PDInfo{PD_LUN} ");
        logInfo("lba $lba ");
        logInfo("length $length");
        logInfo("writeBuffer $writeBuffer");


        #
        # Issue WriteLong Command
        #
        @FunctionRet = TestLibs::SCSI::SCSIWriteLong($MasterObj, 
                                                     $PDInfo{WWN_HI}, 
                                                     $PDInfo{WWN_LO},
                                                     $PDInfo{PD_LUN},
                                                     $lba,
                                                     $length,
                                                     \$writeBuffer);
        if($FunctionRet[0] != GOOD)
        {
            $Return[0]{STATUS} = ERROR; 
            return @Return;     
        }

        $Return[$RetCount]{PDID} = $DriveIdsCorrupt[$i];
        $Return[$RetCount]{HI} = $PDInfo{WWN_HI}; 
        $Return[$RetCount]{LOW} = $PDInfo{WWN_LO};
        $Return[$RetCount]{LUN} = $PDInfo{PD_LUN};
        $Return[$RetCount]{START} = $lba;
        

        #
        # Increment count
        #
        $RetCount++;
        
#        for (my $j = 0; $j < $info{COUNT}; ++$j)
#           {
#            $msg .= sprintf " 0x%08X  0x%08X  0x%08X  0x%08X\n", 
#                                   $info{LIST}[$j]{GAP_SIZE},
#                                   $info{LIST}[$j]{SDA},
#                                   $info{LIST}[$j]{LEN},
#                                   $info{LIST}[$j]{RID};
#
#        }

    }
    
    #
    # Return array of hashes where {PDID} = Physical disk id
    #                              {HI} = first part of WWN
    #                              {LOW} = second part of the WWN
    #                              {START} = starting address of error  
    #                              {LUN} =  device lun
    
    $Return[0]{STATUS} = GOOD; 
    return @Return;  
}


###############################################################################
##
##          Name: ScrubShallNotFindError
##
##        Inputs: Pointer to the list of controller objects
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Comapares Controller(s) Version(s), if all the same returns
#                GOOD if defferent return ERROR;
#
#
##############################################################################

sub CorrectError
{
    my ($MasterObj, @ErrorData) = @_;
    
    my $Return;
    my @FunctionRet;

    my $lba;
    my $writeBuffer = "00000000";
    my $length;
    my $ret;

    for(my $i = 0; $i < scalar(@ErrorData); $i++)
    {

        #
        # Number of sectors
        #
        
        $length = 1;

        $lba = $ErrorData[$i]{START};
        
        
        logInfo(" ");
        logInfo("Master obj ");         
        logInfo("ErrorData[$i]{HI} $ErrorData[$i]{HI}");
        logInfo("ErrorData[$i]{LOW} $ErrorData[$i]{LOW} ");

        logInfo("ErrorData[$i]{LUN} $ErrorData[$i]{LUN} ");
        logInfo("lba $lba ");
        logInfo("length $length");
        logInfo("writeBuffer $writeBuffer");

       
        @FunctionRet = TestLibs::SCSI::SCSIWrite($MasterObj, 
                                                 $ErrorData[$i]{HI}, 
                                                 $ErrorData[$i]{LOW},
                                                 $ErrorData[$i]{LUN},
                                                 $lba,
                                                 $length,
                                                 \$writeBuffer);
        if($FunctionRet[0] != GOOD)
        {
            $Return = ERROR; 
            return $Return;     
        }
 
 

        # unfail the drive                        {PDID}
        $ret = TestLibs::BEUtils::UnfailPdisk( $MasterObj, $ErrorData[$i]{PDID}, 0, 0, 0);
        if ( $ret != GOOD ) 
        { 
            logInfo("Failed to restore drive $ErrorData[$i]{PDID}.");
            return ERROR; 
        }
    


    }
    

    # now wait for rebuild(s) to complete
    $ret = TestLibs::BEUtils::WaitRebuild($MasterObj);

    if($ret != GOOD)
    {
        logInfo("ERROR: failed while waiting for rebuild to complete");
        return ERROR;
    }

    logInfo(" ");
    logInfo("Rebuild is finished");
    logInfo(" ");






    $Return = GOOD; 
    return $Return;  
 
}


##############################################################################

=head2 _SubSetSubroutine

Internal function, used for scrub state set as well as searching through 
the logs to find appropriate log message ID.

=over 4

=item Usage:

 my $FuctionReturn = _SubSetSubroutine(  $ObjListRef, 
                                        $ScrubControl, 
                                        $LogId, 
                                        $LogString, 
                                        $LogNumExp, 
                                        $ScrubSet, 
                                        $ParityControl );    
  
 
 where: $ObjListRef - Reference to the list of controller objects
        $ScrubControl - Scrub control
        $LogId - reference to an array of log ids
        $LogString - Reference to an array of log messages that correspond 
                     to the log ids         
        $LogNumExp - Number of logs expected
        $ScrubSet - if True set scurb, if False - do not change scrub state
        $ParityControl - parity control 

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut


##############################################################################
#
#          Name: _SubSetSubroutine
#
#        Inputs: $ObjListRef - reference to the list of controller objects
#                $ScrubControl - scrub control                                      # <<<<<<< need to specify legit values
#                $LogId - reference to an array of log ids
#                $LogString - reference to an array of log messages that correspond 
#                             to the log ids        
#                $LogNumExp - Number of logs expected
#                $ScrubSet - if True set scrub, if False - do not change scrub state
#                $ParityControl - parity control 
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Internal function, used for scrub state set as well as 
#                searching through the logs to find appropriate log message ID.
#
#
##############################################################################

sub _SubSetSubroutine
{
    my ($ObjListRef, $ScrubControl, $LogIdRef, $LogStringRef, $LogNumExp, $ScrubSet, $ParityControl) = @_;
    
    
    my $LoopCheck = TRUE;
    my @LogIdNum = @$LogIdRef;
    my $BitMapRef;
    my %LastLogs;
    my $FunctionRet;
    my @LogMap;
    # does not have a value just needs to be initialized for scrub set function 
    my $RaidId;                    
    my $LastLogRef;
    my @LastLogSeq;


    $BitMapRef = CreateLogBitMap(scalar(@LogIdNum));                      # <<<<<<< need to say what this does
    
    #-Get the last log for all the controllers
    # extract the last log sequence number and create array 
    # of last logs sequence numbers
    
    %LastLogs = ReturnLastLog( $ObjListRef );            
    
    for(my $u = 0; $u < keys(%LastLogs); $u++)
    {
        if($LastLogs{$u}->{STATUS} != GOOD)
        {
            logInfo("Can not get last log message from controller ". $u);
            return ERROR
        }
        # Create array of last log messages sequence for each controller
         
        push(@LastLogSeq, $LastLogs{$u}->{MASTER_SEQUENCE_NUMBER});
    }  

  
    # make it to be a reference in order to update with in the log seach function
    my $LastSeqNumRef = \@LastLogSeq;
    
    
    logInfo("Looking for message ID(s): @$LogIdRef, Message: @$LogStringRef");       
    
    while($LoopCheck == TRUE )
    {                    


        # if scrub has not been set, set scrub

        if($ScrubSet == FALSE)            
        {
            logInfo("Setting scrub to :" . $ScrubControl);
           
            $FunctionRet = TestLibs::BEUtils::ScrubSet( $ScrubControl, 
                                                        $ParityControl, 
                                                        $RaidId, 
                                                        $ObjListRef);

           
            if($FunctionRet == GOOD)                                      
            {
                # function executed sucsesfully 
                # set the $ScrubSet - meaning that there's not need to set scrub again
                # can screap the scrub set and loop for logs
                # since the function can go throught the while loop a number of times 
                # (until finds the right message) there has to be some sort of check
                # to make sure that the scrub has been set (if requred)  
                $ScrubSet = TRUE;                                    
            }
            else
            {
                logInfo("ERROR: scrub enable command faild...");
                return ERROR;
            }                   
        }
                
        #-Let logs accumulate
        
        delay(180);

        
        # - Check logs 
                
        
        $FunctionRet = SearchLogs(  $ObjListRef, 
                                    $LogIdRef, 
                                    $LogStringRef, 
                                    $BitMapRef, 
                                    $LastSeqNumRef);
                
        # Check to see if any errors occured while scrip was searching for logs
        if($FunctionRet == GOOD)
        {                                                                   
            @LogMap = @$BitMapRef;
            
            for(my $m = 0; $m < scalar(@$BitMapRef); $m++)
            {
                if($LogMap[$m] > 0)
                {
                    my $Times = $LogMap[$m] >> 2; 
                            

                    if($LogNumExp <= $Times )
                    {
                        logInfo("Log message found ". $Times ." time(s)");
                        
                        logInfo(" ");
                        logInfo(" ");
                        logInfo("Expected to find $LogNumExp ");
                        logInfo("The message was found $Times time(s)");           
                        logInfo(" ");
                        logInfo(" ");


                        $LoopCheck = FALSE;
                    } 
                }
            }
        }
        else
        {
            logInfo("Log check function failed...");
            return ERROR;
        }
    }
    return GOOD;
}
           

##############################################################################

=head2 ScrubPowerCycle

1.  If required, stop IO and power down the servers.
2.  Enable scrubbing or mirror scanning - ensure that a scrub enabled, 
with a scrub state of 0x01, log event appears (0x1E)
3.  Power cycle both controllers.
4.  Wait until a Scrub cycle complete log event (0x00) appears when the 
first scrub cycle completes.
5.  Check the number of reads made on each physical disk.  Since power 
cycling the controller will clear the read counters there is no need to 
calculate a difference from the beginning of the test.  Display the read counts.
6.  Disable scrubbing - ensure that a scrub disabled with a scrub state of 
0x00 log event appears (0x1E).

=over 4

=item Usage:

 my $FuctionReturn = ScrubPowerCycle( $ObjListRef, 
                                      $MaxaIpRef, 
                                      $ChanRef, 
                                      $TimeToRunTheTest 
                                    );    
  
 
 where: $ObjListRef - Reference to the list of controller objects
        $MaxaIpRef - Pointer to an array of Moxa IP addresses  
        $ChanRef - Reference to an array containing Moxa channels 
        $TimeToRunTheTest - Number of times to run the test

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut


##############################################################################
#
#          Name: ScrubPowerCycle
#
#        Inputs: 
#               $ObjListRef - Reference to the list of controller objects
#               $MaxaIpRef - Pointer to an array of Moxa IP addresses       
#               $ChanRef - Reference to an array containing Moxa channels
#               $TimeToRunTheTest - Number of times to run the test
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: This will test if the processor firmware saves the 
#                scrub state if a all controllers in the VCG are power cycled.
#
#
##############################################################################

sub ScrubPowerCycle
{
    trace();

    my(  $ObjListRef, $MoxaIp, $Chan, $ParityControl ) = @_;

    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo(">>>>>>>>>>  Scrub Powercycle controller  test case <<<<<<<<<<");
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo(" ");

    my @LogId; 
    my @LogString;
    my @ExpReads;

    
    my $ScrubControl;       #-Enable disable scrub option 
    
    my $FunctionRet;
    my $LogNumExp = 0;

    my @ObjList = @$ObjListRef;

    my @startingTmapRef; 
    
    my @serialNums; #-validate serial numbers
    my @pdiskData;  #-validate pdisk info
    my @vdiskData;  #-validate vdisk info
    my @raidData;   #-validate raid info
    my @startingTmap;
    my $Master;

    # check moxa confiquration
    # - controllers have to be on the same moxa in order to perform the test
    # - if the moxa IP's passed into the function as different test should
    # - should exit
    # Loop comments
    #   Each possible combinaition is checked once

    for(my $MoxaCheckExt = 1; $MoxaCheckExt < scalar( @$MoxaIp ); $MoxaCheckExt++)
    {
    
        if( $$MoxaIp[0]  ne $$MoxaIp[$MoxaCheckExt]  )
        {
            logInfo("Unsupported MOXA confiquration: controllers are on differenct moxas");
            return ERROR;
        }       
    } 
    
    # In the moxa function need to pass a string containing the channels
    # Make a string from the channal array
    
    my $ChanString = "";
    
    for(my $MoxaChan = 0; $MoxaChan < scalar(@$Chan); $MoxaChan++)
    {
        $ChanString .= sprintf $$Chan[$MoxaChan]; 
    }
    
    
    #
    # - Get the info about the VCG
    #

    @startingTmap = PreTestSnapShot( $ObjListRef, TARGETMAP );
    @serialNums = PreTestSnapShot( $ObjListRef, SERIALNUMBERS );
    @pdiskData = PreTestSnapShot( $ObjListRef, PDISKDATA );
    @vdiskData = PreTestSnapShot( $ObjListRef, VDISKDATA );
    @raidData = PreTestSnapShot( $ObjListRef, RAIDDATA );

    if(( $startingTmap[0] == INVALID )  ||
       ( $serialNums[0] == INVALID )    ||
       ( $pdiskData[0] == INVALID )     ||
       ( $vdiskData[0] == INVALID )     ||
       ( $raidData[0] == INVALID )) 
    {
        logInfo("Failed while getting validate information...");
        return ERROR;
    }    
    
    # Get raid ownership and number of logs expected

    @ExpReads = OptNumberOfReads( $ObjListRef);
    
    
    if($ExpReads[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: while getting expected reads data");
        return ERROR;
    }
    
    # Update expected number of log messagers of scrub cycle compelete

    $LogNumExp = $ExpReads[0]{NUMLOGS};


    logInfo("Number of controller that own raids ". $LogNumExp);
    
    if(scalar($LogNumExp) == 0)
    {
        return ERROR;
    }
    
    #
    # enable scrub and look for the message of scrub enable
    # number of logs expected is 1 scrub enable give message only 
    # on the master
    #

    $LogNumExp = 1;
    $ScrubControl = "ENABLE";
    @LogId = ( SCRUBIDENB );  
    @LogString = SCRUBSTRFIN; 
                
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        $LogNumExp,
                                        FALSE,
                                        $ParityControl);
    

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }

    # Reboot all controllers

    my $DebugMes = ("Attempting to reboot all controller ");
    logInfo($DebugMes);
        
    $FunctionRet = CtlrLogTextAll($ObjListRef, $DebugMes);
        
    if($FunctionRet != GOOD)
    {
        logInfo("Unable to send message to debug console");
        return ERROR;   
    }

   
    $FunctionRet = PowerCycle( $$MoxaIp[0], $ChanString);
    
    if($FunctionRet != GOOD)
    {
        logInfo(" ");
        logInfo("ERROR: Can not power cycle controller on chanels $Chan");
        return ERROR;
    }
        
    logInfo("");
    logInfo("Controllers on channels $Chan have been powercycled ");
    logInfo("Allow controllers to come on ready"); 
    delay(180);
    
    #
    # After rebooting controllers log in 
    # Find master and get vcg info from the controller
    # Make sure no controllers are in failed state
    #

    for(my $con = 0; $con < scalar(@ObjList); $con++)
    {
        $FunctionRet = Reconnect($ObjList[$con], 10); 
    
        if($FunctionRet != GOOD)
        {
            logInfo(" ");
            logInfo("ERROR: Can not reconnect to controller $con");
            return ERROR;
        }
        
        logInfo("Conection to controller $con - GOOD ");
    }
    
    $Master = TestLibs::IntegCCBELib::FindMaster( $ObjListRef );

    if( $Master < 0)
    {
        logInfo("ERROR: Failed to find master controller");
        return ERROR;
    }

            
    # Get vcg info through master controller
    # make sure there not controllers in failed sate
    
    
    my %VcgHash = $ObjList[$Master]->vcgInfo(0);

    if (%VcgHash)
    {
        if ($VcgHash{STATUS} == PI_GOOD)
        {
           
            #my @controllers = $VcgHash{CONTROLLERS};
            
            for (my $i = 0; $i < $VcgHash{VCG_MAX_NUM_CONTROLLERS}; $i++)
            {
                if ($VcgHash{CONTROLLERS}[$i]{FAILURE_STATE} != FD_STATE_OPERATIONAL)
                {
                    logInfo(" ");
                    logInfo(" ");
                    logInfo("ERROR: One of the controller in the vcg in in failed state");
                    return ERROR;
                }
            }
        }
        else
        {
            my $msg = "Unable to retrieve virtual controller group information.";
            displayError($msg, %VcgHash);
            return ERROR;
        }
    }
    else
    {
        print "ERROR: Did not receive a response packet.\n";
        return ERROR        
    }


    
    

    #
    # Look for the scrub first cycle to finish
    # there should be as many messagers as the number of controllers 
    # that own raids
    #

    $LogNumExp = $ExpReads[0]{NUMLOGS};     
    @LogId = ( SCRUBIDFIN );
    @LogString = ( SCRUBSTRFIN );
    
    $FunctionRet = _SubSetSubroutine(    $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        $LogNumExp,
                                        TRUE,          # scrub is set not need to set it again
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile looking for scrub finish cycle log ");
        return ERROR;
    }

    #
    # Look for scurb disable message 
    # there should be only 1 message of scrub disable
    #
    
    
    $LogNumExp = 1;
    $ScrubControl = "DISABLE";
    
    @LogId = ( SCRUBIDDIS ); # log id for scrub 
    @LogString = ( SCRUBSTRDIS);

    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        $LogNumExp,
                                        FALSE,            # need to disable scrub
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }   

        
    
    #
    # - Do the system check 
    #

    $FunctionRet = ControllersValidateAll($ObjListRef,
                                          0,
                                          \@startingTmap,
                                          0,
                                          \@serialNums,
                                          \@pdiskData,
                                          \@vdiskData,
                                          \@raidData);
    
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed: system data mismatch");
        return ERROR;
    }     
    
    logInfo("Test completion ..... GOOD ");
    return GOOD;    
}


##############################################################################
#
#          Name: ReadDataOneDrive
#
#        Inputs: Pointer to the list of controller objects
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Comapares Controller(s) Version(s), if all the same returns
#                GOOD if defferent return ERROR;
#
#
##############################################################################
#
#sub ReadDataOneDrive
#{
#   my( $PdId, $Obj ) = @_;
#   
#   trace();
#   
#   my %Error;
#   my $msg;
#   my %RetHash;
#   my $j; 
#
#   my $ReadNumberPerRaid;
#   my $ReadNumberPerDrive = 0;        
#        
#   # get the SOS table
#   
#   my %info = $Obj->getSos( $PdId );
#       
#   if( ! %info )
#   {
#       logInfo(">>>>>>>> Failed to get SOS information. <<<<<<<<");
#       return %Error;
#   }
#
#   if ( $info{STATUS} != PI_GOOD )      # if call returned an error
#   {
#       logInfo(">>>>>>>> Error from getSOS command <<<<<<<<");
#       PrintError(%info);
#       return %Error;
#   }
#       
#   # display the table(if it exists) 
#           
#   $msg = ">>>> SOS table for PDD $PdId:   \n\n";
#        
#   $msg .= sprintf "\n";
#    
#   $msg .= sprintf "  GAP_SIZE      SDA         LEN         RID\n";
#   $msg .= sprintf " ----------  ----------  ----------  ----------\n";
#        
#   for ($j = 0; $j < $info{COUNT}; ++$j)
#   {
#       $msg .= sprintf " 0x%08X  0x%08X  0x%08X  0x%08X\n", 
#               $info{LIST}[$j]{GAP_SIZE},
#               $info{LIST}[$j]{SDA},
#               $info{LIST}[$j]{LEN},
#               $info{LIST}[$j]{RID};
#   }
#   logInfo($msg);
#           
#
#    logInfo(" ");
#   logInfo("Calculating number of reads for physical disk Id ". $PdId);
#
#   for ($j = 0; $j < $info{COUNT}; ++$j)
#   {
#       $ReadNumberPerRaid = ceil(( $info{LIST}[$j]{LEN} * 512 ) / (1024 * 1024));
#       $ReadNumberPerDrive = ($ReadNumberPerDrive + $ReadNumberPerRaid);    
#   }
#
#   logInfo("Pd Id ". $PdId. " should have ".$ReadNumberPerDrive." number of reads");
#   logInfo(" ");
#   logInfo("-------------------------------------------------------");
#   logInfo(" ");
#
#   $RetHash{PDID} = $PdId;
#   $RetHash{OPTREADNUM} = $ReadNumberPerDrive;
#
#   my %PdiskInfo = $Obj->XIOTech::cmdMgr::physicalDiskInfo($PdId);
#        
#   if (%PdiskInfo)
#   {
#       if ($PdiskInfo{STATUS} == PI_GOOD)
#        {
#            $RetHash{RREQCOUNTS} = $PdiskInfo{RREQ};
#        }
#        else
#        {
#            my $msg = "Unable to retrieve pdisk info.";
#            displayError($msg, %PdiskInfo);
#            return %Error;
#        }
#   }
#    
#    else
#    {
#        logInfo("ERROR: Did not receive a response packet");
#        logInfo("While getting infomation for Pd Id ". $PdId);
#        return %Error;
#    }
#
#   return %RetHash;
#
#}
#



##############################################################################

=head2 ScrubFaildDriveLetRebuild

1.  If required, stop IO and power down the servers.
2.  Baseline the baseline number of reads on each physical disk from all 
controllers.
3.  Enable scrubbing or mirror scanning - ensure that a scrub enabled, 
with a scrub state of 0x01, log event appears (0x1E)
4.  Fail a drive.  A device failed event should occur.
5.  Wait until a Scrub cycle complete log event (0x00) appears when the 
first scrub cycle completes.
6.  Check the number of reads made on each physical disk and calculate a 
difference from step 2 above.  Display the delta.
7.  Disable scrubbing - ensure that a scrub disabled with a scrub state 
of 0x00 log event appears (0x1E).

=over 4

=item Usage:

 my $FuctionReturn = ScrubFaildDriveLetRebuild( $ObjListRef, 
                                                $TimeToRunTheTest 
                                                );    
  
 
 where: $ObjListRef - Reference to the list of controller objects
        $TimeToRunTheTest - Number of times to run the test

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut



#################################################################################
#          Name: ScrubFaildDriveLetRebuild
#
#        Inputs: $ObjListRef - Reference to the list of controller objects
#                $TimeToRunTheTest - Number of times to run the test
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: This will test if the correct drives are scrubbed when 
#                a drive is failed.  This test assumes no hot spare is 
#                present and the system should run degraded after the 
#                drive has been failed.
#
##############################################################################

sub ScrubFaildDriveLetRebuild
{
    trace();

    my( $ObjListRef, $ParityControl) = @_;
    
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo(">>>>>>>>>>         Scrub Hot Sparing           <<<<<<<<<<");
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");


    my @LogId; 
    my @LogString;
    my @ExpReads;

    my $ScrubControl;       #-Enable disable scrub option 

    my $FunctionRet;
    my @ObjList = @$ObjListRef;

    my @serialNums;         #-validate serial numbers
    my @pdiskData;          #-validate pdisk info
    my @vdiskData;          #-validate vdisk info
    my @raidData;           #-validate raid info
    my @startingTmap;
    
    my @HotSpare;           # array of ids of all hotspare drives
    my $FailedDrive;        # Id of data drive that will be failed
    my $Master;
    my $FailDrive;

    my $ses;
    my $slot;
    my $ret;
    my $lid;
    my $port;


    #
    # - Get the info about the VCG
    #

    @startingTmap = PreTestSnapShot( $ObjListRef, TARGETMAP );
    @serialNums = PreTestSnapShot( $ObjListRef, SERIALNUMBERS );
    @vdiskData = PreTestSnapShot( $ObjListRef, VDISKDATA );
    @raidData = PreTestSnapShot( $ObjListRef, RAIDDATA );

    if(( $startingTmap[0] == INVALID )  ||
       ( $serialNums[0] == INVALID )    ||
       ( $vdiskData[0] == INVALID )     ||
       ( $raidData[0] == INVALID )) 
    {
        logInfo("Failed while getting validate information...");
        return ERROR;
    }


    logInfo(" ");
    logInfo("Looking for hotspare drives and data drive to fail");
    logInfo(" ");
    
    #
    # Do the physical disk checking
    # Chech if there is at least one hot spare avaluable 
    # Check if there is at least 2 data drives
    #
    
    
    $Master = FindMaster($ObjListRef);
    if($Master < 0)
    {
        logInfo("ERROR: Failed while looking for master controller");
        return ERROR;
    }

    my $productID =  getMagProductID( 0, $ObjList[$Master]);
    
    logInfo(" ");
    logInfo("Looking for hotspare drive to perform the test...");
 
    
    @HotSpare = GetTheseDisks($ObjList[$Master], CCBEHOTSPARETYPE );
   
    # If no hotspare found fail the test
    
    if(scalar(@HotSpare) == 0)
    {
        logInfo("ERROR: no hot spare drives available to perform the test");
        return ERROR;
    }

    if($HotSpare[0] < 0)
    {
        logInfo("ERROR: Error occured while looking for drives labeled as hot spare");
        return ERROR;
    }

    logInfo(" ");
    logInfo("Getting read infomation for all physical disks on each controller ");
    logInfo(" ");

    # Get expected number of reads for all controllers

    @ExpReads = OptNumberOfReads( $ObjListRef);

    if($ExpReads[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: while getting expected reads data");
        return ERROR;
    }
    
    # Find the drive to fail
    # Go through the drives with data written to them
    # Make sure that the drive that will be failed is a data drive

    for( my $r = 1; $r < scalar(@ExpReads); $r++)
    {
        # number of reads on the drive is greater then 0
        # means the drive has data

        if($ExpReads[$r]{READNUM} > 0)
        {
            my $Label = GetDriveLabel($ObjList[$Master], $ExpReads[$r]{PDID}); 
            
            if($Label == INVALID)
            {
                logInfo("Error while getting pdisk id label $ExpReads[$r]{PDID}");
                return ERROR;
            }
            
            # and if the drive is a data drive that is the the
            # drive that we want to fail

            if($Label == CCBEDATATYPE)
            {
                $FailDrive = $ExpReads[$r]{PDID};
                last;
            }
        }
    }
    
    logInfo("PDISK $FailDrive has been selected to be failed.");
    
    # Enable scrub
    
    $ScrubControl = "ENABLE";
    @LogId = ( SCRUBIDENB ); # log id for scrub 
    @LogString = (SCRUBSTRFIN);
                
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,          # number of logs
                                        FALSE,
                                        $ParityControl);
    

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile changing scrub state ");
        return ERROR;
    } 

    logInfo(" ");
    logInfo("Failing drive id ". $FailDrive);
    logInfo(" ");

    if ( $productID == 2750 )
    {
    
        $FunctionRet = FailPdisk( $ObjListRef, $FailDrive, PDISKFAIL );
        if ( $FunctionRet != GOOD ) { return ERROR; }
    }
    else
    {
    TestLibs::BEUtils::GetSesAndSlot($ObjList[$Master], $FailDrive, \$ses, \$slot, \$lid, \$port);

    CtlrLogTextAll($ObjListRef, "Bypassing PDISK $FailDrive (SES = $ses,SLOT = $slot)." );


    $FunctionRet = TestLibs::BEUtils::PdiskIdBypass( $ObjList[$Master], 
                                                     $FailDrive );
    }

    # Look for message of device failed and rebuild start

    @LogId = (0x8062);
    @LogString = ("hotspared");
    
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,           # number of logs
                                        TRUE,
                                        $ParityControl);

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile looking for device failed message and rebild start message");
        return ERROR;
    }

    # now wait for rebuild to competele

    $FunctionRet = TestLibs::BEUtils::WaitRebuild($ObjList[$Master]);

    if($FunctionRet != GOOD)
    {
        logInfo("ERROR: failed while waiting for rebuild to complete");
        return ERROR;
    }

    logInfo(" ");
    logInfo("Rebuild for drive $FailDrive is finished");
    logInfo(" ");
    
    # need to refresh the connection to the slave
    $FunctionRet = TestLibs::IntegCCBELib::TestNReconnectAll($ObjListRef);

    # Look for the first scrub cycle to finish
    
    logInfo("Looking for scrub cycle finish");

    @LogId = (SCRUBIDFIN);
    @LogString = (SCRUBSTRFIN);
    
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        $ExpReads[0]{NUMLOGS},
                                        TRUE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while looking for scrub finish cycle log ");
        return ERROR;
    }

    
    logInfo("Disabling scrub ");
    logInfo(" ");
    
    $ScrubControl = "DISABLE";
    
    @LogId = ( SCRUBIDDIS );
    @LogString = (SCRUBSTRDIS);

    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,
                                        FALSE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }   

    # - Do the system check 

    CtlrLogTextAll($ObjListRef, "Validating system states after rebuild." );
    
    logInfo("This will probably fail due to the change in disk status.");

    $FunctionRet = ControllersValidateAll($ObjListRef,
                                          0,
                                          \@startingTmap,
                                          0,
                                          \@serialNums,
                                          0,
                                          0,              # was \@vdiskData,
                                          0);             # was \@raidData);
    
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed: system data mismatch");
        return ERROR;
    } 
    
    CtlrLogTextAll($ObjListRef, "Unfailing the bypassed drive." );


    # unfail the drive, make hotspare

    $ret = TestLibs::BEUtils::UnfailPdisk($ObjList[$Master], $FailDrive, $ses, $slot, 0, $lid, $port);

    if ( $ret != GOOD ) 
    { 
        logInfo("Failed to restore drive $FailDrive.");
        return ERROR; 
    }
    
    DelaySecs( 60);  # Make sure there has been enough time for the 
                     # controller to recover.

    logInfo("Test completion ..... GOOD ");
    return GOOD;    
}


##############################################################################

=head2 pdiskRestore

Restores failed physical disk.

=over 4

=item Usage:

 my $FuctionReturn = pdiskRestore( $id, $Obj );    
  
 
 where: $Obj - Controller object
        $id - Physical disk Id

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut


#################################################################################
#          Name: UnbaypassAll
#
#        Inputs: $MasterObj   -  master controller objects
#                           
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Unbypasses all empty slots in the system
#
##############################################################################


sub UnbaypassAll
{
    my ( $MasterObj ) = @_;
    
    my @BaySES;
    my @EmptySlot;
    
    # get all the empty slots in corresponding bays

    my $return = FindEmptySlots($MasterObj, \@BaySES, \@EmptySlot );
    
    if($return != GOOD)
    {
        logInfo("Error occured while looking for empty slots");
        return ERROR;
    }
    
    # unbaypass all the empty slots
    for(my $loop = 0; $loop < scalar(@BaySES); $loop++)
    {
        # 0x0 is the setting for the unbaypass the drive command

        $return = TestLibs::BEUtils::PDiskBypass($MasterObj, 
                                                 $BaySES[$loop], 
                                                 $EmptySlot[$loop], 
                                                 0x0 );
        
        if($return != GOOD)
        {
            logInfo("Error occured while unbaypassing drive SES $BaySES[$loop] slot $EmptySlot[$loop]");
            return ERROR;
        }
        logInfo("Drive SES $BaySES[$loop] slot $EmptySlot[$loop] was unbaypassed");
    }
    
    # rescan the BE

    $return = RescanBE($MasterObj);
    
    if($return != GOOD)
    {
        logInfo("Unable to rescan BE");
        return ERROR;
    }
    return GOOD;        
}



#################################################################################
#          Name: FindEmptySlots
#
#        Inputs: $ctlr   -  master controller objects
#                $bayPtr -  pointer to the bay SES array, empty array
#                           array feeled within the funtion 
#                   
#                $slotPtr - pointer to teh slot array, empty array
#                           array feeled within the funtion
#                           
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Finds empty slots in the bay
#                Updates two arrays: array of bay SES, and corresponding
#                array of empty slots
#
##############################################################################
sub FindEmptySlots
{
    my ( $ctlr, $bayPtr, $slotPtr ) = @_;
    
    my $bay;
    my $k;
    my @slots;
    
    # get pdisks


    my %pdisks = $ctlr->physicalDisks();
    
    if (! %pdisks )        
    {
        logInfo (">>>>>>>>>> no response from pdisks command  <<<<<<<<<<<");
        return ERROR;
    }

    if ( $pdisks{STATUS} != PI_GOOD )
    {
        logInfo (">>>>>>>>>> Error from pdisks in pdisks command <<<<<<<<<<<");
        PrintError(%pdisks);
        return ERROR;
    }

    # data is good, now scan it
    # start with 1 count the first hash is the count
    
    my @baysFound;

    for ( my $i = 0; $i < $pdisks{COUNT} ; $i++ )
    {

        # set the by SES to the first SES founf

        $bay = $pdisks{PDISKS}[$i]{SES};
        
        # check to make use that the bay SES is not already on the list
        # if it is on the list, that means that we already have got throught
        # the slots and drives in that bay
        # if the bay is not on the list of bays that means that the bay
        # has not been looked at
        
        if ( InList(\@baysFound, $bay ) == FALSE )
        {
            # push the bay on the list, so that if statement 
            # next time around would not be true

            push (@baysFound, $bay);

            # initialise all the array with correnspodent bay slot possitions
            # to 1

            @slots = (1,1,1,1,1,1,1,1,1,1,1,1,1,1);
            print "Slots @slots ";

            # start the loop from the the possition in the disk array 
            # where the "if" statement is not tue
            # in other workds start the search from the first drive
            # in the array that is located in a bay that is not has been 
            # looked at
            # go to the end of the disk list, picking out the drives that
            # have the "new" (not looked at) bay SES. 
            # Initilize the possition in @slot (build in the function array)
            # ) from 1 to 0, meaning that the slot in the desegnated bay is taken 
            
            for ($k = $i; $k < $pdisks{COUNT}; $k++ ) 
            {
                
                if ( $pdisks{PDISKS}[$k]{SES} == $bay )
                {
                    print "Slot $pdisks{PDISKS}[$k]{SLOT} \n";
                    $slots[$pdisks{PDISKS}[$k]{SLOT}] = 0;
                }
            }

            # after the bay has been looked at
            # and all the slots have been feeled in
            # got throught the build in @slot array 
            # and if the element (slot posisiton ) in
            # the array has not been changed from 1 to 0
            # that means that the slot is impty
        
            for($k = 0; $k < scalar(@slots); $k++ )
            {
                if($slots[$k] == 1)
                {
                    push( @$bayPtr, $bay);
                    push( @$slotPtr, $k );
                }
            }
        }
    }

    return GOOD;
   
}

#################################################################################
#          Name: InList
#
#        Inputs: $ListRef   - reference to the list
#                $Item      - item to look for in the list
#
#       Outputs: TRUE - item has been found
#                FAULSE - item has not been found
#
#  Globals Used: none
#
#   Description: Searches the list to find an item
#
##############################################################################

sub InList
{
    my ( $ListRef, $Item ) = @_;
    
    # set check to false

    my $Check = FALSE;
    
    # go through the list looking for the item
    # if item is found set check to true
    # break the for loop
    # return check

    for(my $loop = 0; $loop < scalar(@$ListRef); $loop++)
    {
        if($Item == @$ListRef[$loop])
        {
            $Check = TRUE;
            last;
        }
    }
    return $Check;
}

#################################################################################
#          Name: pdiskRestore
#
#        Inputs: $Obj - Controller object
#                $id - Physical disk Id
#
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Restores failed physical disk.
#
##############################################################################


sub pdiskRestore
{
    my ($id, $Obj) = @_;

    logInfo(" ");

    #
    # Restore pd id
    # 
    
    my %rsp = $Obj->physicalDiskRestore($id);

    #
    # Do error checking
    #

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo("Physical disk ". ($id). " restored.");
            return GOOD;
        }
        else
        {
            my $msg = "Unable to restore physical disk id $id.";
            logInfo(" ");
            displayError($msg, %rsp);
        }
    }
    else
    {
        logInfo("ERROR: Did not receive a response packet.");
        return ERROR;
    }

    return GOOD;    
}


##############################################################################

=head2 ScrubRunDegraded

1.  If required, stop IO and power down the servers.
2.  Baseline the baseline number of reads on each physical disk from all 
controllers.
3.  Enable scrubbing or mirror scanning - ensure that a scrub enabled, 
with a scrub state of 0x01, log event appears (0x1E)
4.  Wait until a Scrub cycle complete log event (0x00) appears when the 
first scrub cycle completes.
5.  Check the number of reads made on each physical disk and calculate a 
difference from step 2 above.  Display the delta.
6.  Disable scrubbing - ensure that a scrub disabled with a scrub state 
of 0x00 log event appears (0x1E).

=over 4

=item Usage:

 my $FuctionReturn = ScrubRunDegraded(  $ObjListRef, 
                                        $TimeToRunTheTest);    
  
 
 where: $ObjListRef - Array reference to the list of controller objects         
        $TimeToRunTheTest - Number of times to run the test

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut




##############################################################################
#
#          Name: ScrubRunDegraded
#
#        Inputs: $ObjListRef - Array reference to the list of controller objects   
#                $TimeToRunTheTest - Number of times to run the test
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: This will test if the correct drives are scrubbed when 
#                some of the RAID's are degraded.
#
#
##############################################################################

sub ScrubRunDegraded
{

    my( $ObjListRef, $ParityControl ) = @_;
    
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo(">>>>>>>>>>  Scrub Run degraded <<<<<<<<<<");
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");


    my @LogId; 
    my @LogString;
    my @ExpReads;


    
    my $ScrubControl;               #-Enable disable scrub option 
    my $FunctionRet;
    my @ObjList = @$ObjListRef;
    my @startingTmapRef; 
    my $Master;

    #
    # Do the physical disk checking
    # Chech if there is at least one hot spare avaluable 
    # Check if there is at least 2 data drives
    #
    
    
    
    $Master = FindMaster($ObjListRef);
    
    if($Master < 0)
    {
        logInfo("ERROR: Failed while looking for master controller");
        return ERROR;
    }
    
    logInfo(" ");
    logInfo("Looking for degraded RAIDs");
    logInfo(" ");


    my @DegradedRaids = FindDegradedRaids($ObjList[$Master]);


    if($DegradedRaids[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: failed while looking for degraded raids");
        return ERROR;
    }

    shift(@DegradedRaids);
    
    if(scalar(@DegradedRaids))
    {
        for(my $Deg = 0; $Deg < scalar(@DegradedRaids); $Deg++)
        {
            logInfo("RIAD id(s) $DegradedRaids[$Deg]{RDID} status is $DegradedRaids[$Deg]{RDSTAT} ");
        }
    }
    else
    {
        logInfo("ERROR: there are no degraded raids ");
        return ERROR;
    }
    
    
    #
    # Get expeceted number of reads for all controllers
    #

    @ExpReads = OptNumberOfReads( $ObjListRef);
    
    
    if($ExpReads[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: while getting expected reads data");
        return ERROR;
    }
    
    #
    # Enable scrub
    #

    #
    # Number of log message for scrub enable is one
    # does not depend on ownership
    #
    
    $ScrubControl = "ENABLE";
    @LogId = ( SCRUBIDENB ); # log id for scrub 
    @LogString = (SCRUBSTRENB );
                
    $FunctionRet = _SubSetSubroutine(    $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,             # number of expected log messages
                                        FALSE,         # scrub has not been set yet
                                        $ParityControl);
    

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }

    # need to refresh the connection to the slave
    $FunctionRet = TestLibs::IntegCCBELib::TestNReconnectAll($ObjListRef);
        
    #
    # Look for the first scrub cycle to finish
    #


    logInfo("Looking for scrub cycle finish");
 
    @LogId = (SCRUBIDFIN);
    @LogString = (SCRUBSTRFIN);
    
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl,          # not setting scrub - value is not used this time
                                        \@LogId, 
                                        \@LogString,           
                                        $ExpReads[0]{NUMLOGS},  # number of log messages expected 
                                        TRUE,                   # scrub has been set already
                                        $ParityControl);        # not setting scrub - value is not used this time
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile looking for scrub finish cycle log ");
        return ERROR;
    }

    #
    # Number of log message for scrub enable is one
    # does not depend on ownership
    #

    
    logInfo("Disabling scrub ");
    logInfo(" ");
    
    $ScrubControl = "DISABLE";
    
    @LogId = ( SCRUBIDDIS );
    @LogString = ( SCRUBSTRDIS );

    $FunctionRet = _SubSetSubroutine(    $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,              # number of messages expected
                                        FALSE,          # scrub state is being changed
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }   
                    
    logInfo("Test completion ..... GOOD ");
    return GOOD;   

}


##############################################################################

=head2 ScrubFailDrive

1.  If required, stop IO and power down the servers.
2.  Baseline the baseline number of reads on each physical disk from all 
controllers.
3.  Enable scrubbing or mirror scanning - ensure that a scrub enabled, 
with a scrub state of 0x01, log event appears (0x1E)
4.  Wait until a Scrub cycle complete log event (0x00) appears when 
the first scrub cycle completes.
5.  Check the number of reads made on each physical disk and calculate a 
difference from step 2 above.  Display the delta.
6.  Disable scrubbing - ensure that a scrub disabled with a scrub state 
of 0x00 log event appears (0x1E).

=over 4

=item Usage:

 my $FuctionReturn = ScrubRunDegraded(  $ObjListRef, 
                                        $TimeToRunTheTest);    
  
 
 where: $ObjListRef - Array reference to the list of controller objects         
        $TimeToRunTheTest - Number of times to run the test

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut

##############################################################################
#
#          Name: ScrubFailDrive
#
#        Inputs: $ObjListRef - Array reference to the list of controller objects 
#                $TimeToRunTheTest - Number of times to run the test
#
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: This will test if the correct drives are scrubbed when 
#                some of the RAID's are degraded.#
##############################################################################

sub ScrubFailDrive

{
    trace();

    my( $ObjListRef, $ParityControl, $failMethod, $otherOption) = @_;
    
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo(">>>>>>>>>>  Fail Physical drive and run degraded <<<<<<<<<<");
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");

    my @LogId; 
    my @LogString;
    my @ExpReads;

    my $ScrubControl;       #-Enable disable scrub option 
    
    my $FunctionRet;

    my @ObjList = @$ObjListRef;
    
    my @serialNums;         #-validate serial numbers
    my @vdiskData;          #-validate vdisk info
    my @raidData;           #-validate raid info
    my @startingTmap;

    
    my @HotSpare;           # array of ids of all hotspare drives

    my $Master;

    my $ses;
    my $slot;
    my $ret;
    my $i;
    my $lid;
    my $port;

    logInfo(" ");
    logInfo("Looking for hotspare drive and data drive to fail");
    logInfo(" ");
    
    #
    # Do the physical disk checking
    # Chech if there is at least one hot spare avaluable 
    # Check if there is at least 2 data drives
    #
        
    $Master = FindMaster($ObjListRef);
    
    if($Master < 0)
    {
        logInfo("ERROR: Failed while looking for master controller");
        return ERROR;
    }

    logInfo(" ");
    logInfo("Checking for hotspare drives to perform the test...");
 
    
    @HotSpare = GetTheseDisks($ObjList[$Master], CCBEHOTSPARETYPE );

    # If hotspares are found, deal with the fact.

    if(scalar(@HotSpare) > 0)
    {
        logInfo("Warning:  hot spare drive(s) are present  @HotSpare ");
        #return ERROR;

        #
        # We could just unlabel the hotspares for the duration of the test. 
        # By doing this, we will be able to run the test from a single 
        # configuration and save setup time and effort.
        #

        
        logInfo("Unlabeling all hotspare drives for duration of the test.");
        
        for ( $i = 0; $i < scalar(@HotSpare); $i ++ )
        {

            $ret = TestLibs::IntegCCBELib::LabelSingleDrive( $ObjList[$Master], $HotSpare[$i], CCBEUNLABLEDTYPE );

        }
            
        
    }
    
    logInfo("No hot spare drives are present (desired condition for test).");
    logInfo(" ");
    
    # Find the drive to fail

    logInfo("Getting the list of drives labeled as data");

    my @DataDrives = $ObjList[$Master] ->getOperationalPhysicalDiskIDs();

    if(scalar(@DataDrives) == 0)
    {
        logInfo("ERROR: Bigfoot does not recongnize any physical drives");
        return ERROR;
    }

    if($DataDrives[0] < 0)
    {
        logInfo("ERROR: error occured while getting data drives");
        return ERROR;
    }

    if(scalar(@DataDrives) < 2)
    {
        logInfo("ERROR: Number of drives labeled as data is less then two");
        logInfo("Can not continue the test, invalid number of drives labeled as data");
        return ERROR;
    }

    
    logInfo(" ");
    logInfo("Getting read infomation for all physical disks on each controller ");
    logInfo(" ");
    
    # Get expeceted number of reads for all controllers

    @ExpReads = OptNumberOfReads( $ObjListRef);
    
    
    if($ExpReads[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: while getting expected reads data");
        return ERROR;
    }
    
    # Enable scrub

    $ScrubControl = "ENABLE";
    @LogId = ( SCRUBIDENB ); # log id for scrub 
    @LogString = (SCRUBSTRFIN);
                
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,      # number of expected logs
                                        FALSE,
                                        $ParityControl);
    

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile changing scrub state ");
        return ERROR;
    }

    logInfo(" ");
    logInfo("Failing drive id  ". $DataDrives[0]);
    logInfo(" ");
    

    TestLibs::BEUtils::GetSesAndSlot($ObjList[$Master], $DataDrives[0], \$ses, \$slot, \$lid, \$port);

    CtlrLogTextAll($ObjListRef, "Bypassing PDISK $DataDrives[0] (SES = $ses,SLOT = $slot)." );


    $FunctionRet = TestLibs::BEUtils::PdiskIdBypass( $ObjList[$Master], 
                                                     $DataDrives[0] );
       
# check this 


    # Look for message of device failed

    #@LogId = (0x10D3);      
    @LogId = (0x8085);      
    @LogString = ("FAIL no hotspares");

    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,      # number of logs expected
                                        TRUE,
                                        $ParityControl);

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while looking for device failed message ");
        return ERROR;
    }

    logInfo("Looking for degraded RAIDs");
    my @DegradedRaids = FindDegradedRaids($ObjList[$Master]);


    if($DegradedRaids[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: failed while getting degraded raids to complete");
        return ERROR;
    }

    shift(@DegradedRaids);
    
    if(scalar(@DegradedRaids))
    {
        for(my $Deg = 0; $Deg < scalar(@DegradedRaids); $Deg++)
        {
            if($DegradedRaids[$Deg]{RDSTAT} == 11)
            {
                logInfo("Raid id  $DegradedRaids[$Deg]{RDID} status is $DegradedRaids[$Deg]{RDSTAT} ");
            }
        }
    }
    else
    {
        logInfo("ERROR: there are not degraded raids ");
        return ERROR;
    }

    # need to refresh the connection to the slave
    $FunctionRet = TestLibs::IntegCCBELib::TestNReconnectAll($ObjListRef);

    # Look for the first cycle to finish

    logInfo("Looking for scrub cycle finish");
    @LogId = (SCRUBIDFIN);
    @LogString = (SCRUBSTRFIN);
    
    $FunctionRet = _SubSetSubroutine(    $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        $ExpReads[0]{NUMLOGS},  # number of logs
                                        TRUE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed wile looking for scrub finish cycle log ");
        return ERROR;
    }

    
    logInfo("Disabling scrub ");
    logInfo(" ");
    
    $ScrubControl = "DISABLE";
    @LogId = ( SCRUBIDDIS ); # log id for scrub 
    @LogString = (SCRUBSTRDIS);

    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,           # number of log messages
                                        FALSE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }    
    
    #
    # After failing the drive fix its label otherwise the situation may occur
    # when hot spare drive will have data
    #
    
    logInfo("Fixing Drive Label");

    $FunctionRet = TestLibs::BEUtils::FixPdiskLabels($ObjList[$Master], DONTMAKEHOTSPARE);
    
    
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while trying to fix physical disks labeles after drive fail ");
        return ERROR;
    }   
    
    ############################
    # Test case 7 inserted here
    ############################

    # $otherOption = 7

    if ( $otherOption == 7 )
    {
    
        CtlrLogTextAll($ObjListRef, "Start/stop scrub while a degraded condition exists (case 7)." );
    
    
        $ret = ScrubRunDegraded( $ObjListRef, 1 );
        if ( $ret != GOOD ) 
        { 
            logInfo("Failure during degraded portion of the test.");
            return ERROR; 
        }
    }

    ##################
    # End test case 7.
    ##################
 
 
 
    ############################
    # Test case 8 inserted here
    ############################
    
    # $otherOption = 8

    if ( $otherOption == 8 )
    {
        CtlrLogTextAll($ObjListRef, "Add hotspare to a degraded condition (case 8)." );
     
        $FunctionRet = TestLibs::scrub::ScrubAddHotSpare($ObjListRef, 1);
        if( $FunctionRet != GOOD)
        {
            print "Test failed \n";

        }
    }
    ##################
    # End test case 8.
    ##################
 
 
 
                 
    CtlrLogTextAll($ObjListRef, "Unfailing the bypassed drive." );


    # unfail the drive
    $ret = TestLibs::BEUtils::UnfailPdisk($ObjList[$Master], $DataDrives[0], $ses, $slot, NORELABEL, $lid, $port);
    if ( $ret != GOOD ) 
    { 
        logInfo("Failed to restore drive $DataDrives[0].");
        return ERROR; 
    }
    
    # now wait for rebuild to competele

    $FunctionRet = TestLibs::BEUtils::WaitRebuild($ObjList[$Master]);

    if($FunctionRet != GOOD)
    {
        logInfo("ERROR: failed while waiting for rebuild to complete");
        return ERROR;
    }

    logInfo(" ");
    logInfo("Rebuild for drive $DataDrives[0] is finished");
    logInfo(" ");

    #
    # After failing the drive fix its label otherwise the situation may occur
    # when hot spare drive will have data
    #
    
    logInfo("Fixing Drive Label");

    $FunctionRet = TestLibs::BEUtils::FixPdiskLabels($ObjList[$Master], DONTMAKEHOTSPARE);
    
    
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while trying to fix physical disks labeles after drive fail ");
        return ERROR;
    }   


    # If we had hotspares, put them back

    if(scalar(@HotSpare) > 0)
    {

        #
        # We could just unlabel the hotspares for the duration of the test. 
        # By doing this, we will be able to run the test from a single 
        # configuration and save setup time and effort.
        #

        
        logInfo("Re-labeling all former hotspare drives as hotspare.");
        
        for ( $i = 0; $i < scalar(@HotSpare); $i ++ )
        {

            $ret = TestLibs::IntegCCBELib::LabelSingleDrive( $ObjList[$Master], $HotSpare[$i], CCBEHOTSPARETYPE );

        }
        
        logInfo("Hotspare labeling complete.");    
        
    }

    

    logInfo("Test completion ..... GOOD ");
    return GOOD;    
}




##############################################################################

=head2 ScrubAddHotSpare

1.  If required, stop IO and power down the servers.
2.  Baseline the baseline number of reads on each physical disk from all 
controllers.
3.  Enable scrubbing or mirror scanning - ensure that a scrub enabled, 
with a scrub state of 0x01, log event appears (0x1E)
4.  Un-fail both physical disks if required and label them as hot spares.  
A rebuild should start and a PSD rebuild started and a PSD Rebuild successful 
events should occur.
5.  Wait until a Scrub cycle complete log event (0x00) appears when the 
first scrub cycle completes.
6.  Check the number of reads made on each physical disk and calculate a 
difference from step 2 above.  Display the delta.
7.  Disable scrubbing - ensure that a scrub disabled with a scrub state 
of 0x00 log event appears (0x1E).

=over 4

=item Usage:

 my $FuctionReturn = ScrubAddHotSpare(  $ObjListRef, 
                                        $TimeToRunTheTest);    
  
 
 where: $ObjListRef - Array reference to the list of controller objects         
        $TimeToRunTheTest - Number of times to run the test

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut


##############################################################################
#
#          Name: ScrubAddHotSpare
#
#        Inputs: $ObjListRef - Array reference to the list of controller objects  
#                $TimeToRunTheTest - Number of times to run the test
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: This will test if the correct drives are scrubbed when a 
#                scrub cycle starts with degraded RAIDs and hot spares are 
#                added so that those RAIDs can be rebuilt.  Start the test 
#                with two failed or unlabeled physical disks present and 
#                several RAIDs running in degraded mode due to a previous 
#                disk failure.
#
#
##############################################################################

sub ScrubAddHotSpare
{

    trace();

    my( $ObjListRef,$ParityControl ) = @_;
    
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");
    logInfo(">> Scrub: Unfail failed drives, add hot spare, let rebuild <<");
    logInfo(" ");
    logInfo("----------------------------------------------------------");
    logInfo(" ");


    my @LogId; 
    my @LogString;
    my @ExpReads;
    my $ScrubControl;
    my $FunctionRet;

    my @ObjList = @$ObjListRef;
    
    my @serialNums; #-validate serial numbers
    my @vdiskData;  #-validate vdisk info
    my @raidData;   #-validate raid info
    my @startingTmap;
    
    my @HotSpare;           # array of ids of all hotspare drives
    my $FailedDrive;        # Id of data drive that will be failed
    my $Master;

    #
    # - Get the info about the VCG
    #

    @startingTmap = PreTestSnapShot( $ObjListRef, TARGETMAP );
    @serialNums = PreTestSnapShot( $ObjListRef, SERIALNUMBERS );
    @vdiskData = PreTestSnapShot( $ObjListRef, VDISKDATA );
    @raidData = PreTestSnapShot( $ObjListRef, RAIDDATA );

    if(( $startingTmap[0] == INVALID )  ||
       ( $serialNums[0] == INVALID )    ||
       ( $vdiskData[0] == INVALID )     ||
       ( $raidData[0] == INVALID )) 
    {
        logInfo("Failed while getting validate information...");
        return ERROR;
    }

    $Master = FindMaster($ObjListRef);
    
    if($Master < 0)
    {
        logInfo("ERROR: Failed while looking for master controller");
        return ERROR;
    }

    # Get expeceted number of reads for all controllers

    @ExpReads = OptNumberOfReads( $ObjListRef);
    
    if($ExpReads[0]{STATUS} != GOOD)
    {
        logInfo("ERROR: while getting expected reads data");
        return ERROR;
    }
    
    # Enable scrub


    $ScrubControl = "ENABLE";
    @LogId = ( SCRUBIDENB ); # log id for scrub 
    @LogString = (SCRUBSTRFIN);
                
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,           # logs
                                        FALSE,
                                        $ParityControl);
    

    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }

    
    #
    # After failing the drive fix its label otherwise the situation may occur
    # when hot spare drive will have data
    #
    
    logInfo("Fixing Drive Label");

    $FunctionRet = TestLibs::BEUtils::FixPdiskLabels($ObjList[$Master], DONTMAKEHOTSPARE);
    
    
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while trying to fix physical disks labeles after drive fail ");
        return ERROR;
    }   


    my @DriveId;

    @DriveId = GetTheseDisks($ObjList[$Master], CCBEUNLABLEDTYPE );


    if(scalar(@DriveId) > 0)
    {

        #
        # We could just unlabel the hotspares for the duration of the test. 
        # By doing this, we will be able to run the test from a single 
        # configuration and save setup time and effort.
        #

        if ( $DriveId[0]  == INVALID )
        {
            logInfo("There were no unlabeled drives, the test fails, the \n".
                     "initial conditions were not correct.\n");

            return ERROR;
        }
        
        logInfo("Labeling first unlabeled drive as hotspare.");
        
        #
        # Note, we are only doing one hotspare, which we expect to be used.
        # If thre are actually multiple missing drives, then the raids may
        # remain degraded and the leter checks will fail (or run forever).
        #


   # check return !!
        TestLibs::IntegCCBELib::LabelSingleDrive( $ObjList[$Master], $DriveId[0], CCBEHOTSPARETYPE );

        logInfo("Hotspare labeling complete.");    
        
    }
    else
    {
        logInfo("There were no unlabeled drives, the test fails, the \n".
                 "starting conditions were not correct.\n");

        return ERROR;
    }

    # need to refresh the connection to the slave
    $FunctionRet = TestLibs::IntegCCBELib::TestNReconnectAll($ObjListRef);

    # Look for the first cycle to finish

    logInfo("Looking for scrub cycle finish");

    @LogId = (SCRUBIDFIN);
    @LogString = (SCRUBSTRFIN);
    
    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        $ExpReads[0]{NUMLOGS},
                                        TRUE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while looking for scrub finish cycle log ");
        return ERROR;
    }

    
    logInfo("Disabling scrub ");
    logInfo(" ");

    $ScrubControl = "DISABLE";    
    @LogId = ( SCRUBIDDIS ); # log id for scrub 
    @LogString = ( SCRUBSTRDIS );

    $FunctionRet = _SubSetSubroutine(   $ObjListRef, 
                                        $ScrubControl, 
                                        \@LogId, 
                                        \@LogString, 
                                        1,          # logs
                                        FALSE,
                                        $ParityControl);
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed while changing scrub state ");
        return ERROR;
    }   
      
    #
    # wait for any rebuilds to finish
    #
                 
    CtlrLogTextAll($ObjListRef, "Waiting for any rebuilds to finish." );



    $FunctionRet = TestLibs::BEUtils::WaitRebuild($ObjList[$Master]);

    if($FunctionRet != GOOD)
    {
        logInfo("ERROR: failed while waiting for rebuild to complete");
        return ERROR;
    }

    #
    # There must have been no more thatn one missing drive for this to 
    # work. If there were multiple bad drives, then we did not provide 
    # enough hotspares for this to work.
    #

    logInfo(" ");
    logInfo("Rebuild  is finished");
    logInfo(" ");

    # - Do the system check 





    $FunctionRet = ControllersValidateAll($ObjListRef,
                                          0,
                                          \@startingTmap,
                                          0,
                                          \@serialNums,
                                          0,
                                          \@vdiskData,
                                          \@raidData);
    
    if($FunctionRet != GOOD)
    {
        logInfo("Test failed: system data mismatch");
        return ERROR;
    } 

    logInfo("Test completion ..... GOOD ");
    return GOOD; 
} 




##############################################################################

=head2 MakeFaildDriveOpr

Discover all not operational physical drives attached to the Bigfoot and unfail them, 
label with passed in label.

=over 4

=item Usage:

 my $FuctionReturn = ScrubAddHotSpare( $obj, $label );    
  
 
 where: $obj - Controller object
        $label - Label to label unfail drive

 Notes:
 
 None

=item Returns:

 On success - Returns 0 (GOOD).
 On error   - Returns 1 (ERROR).

=back

=cut



##############################################################################
#
#          Name: MakeFaildDriveOpr
#
#
#        Inputs: $obj - Controller object
#                $label - Label to label unfail drive
#
#       Outputs: GOOD if none degraded, 
#                INVALID if some degraded,
#                ERROR if we get an error
#
#  Globals Used: none
#
#   Description: Discover all not operational physical drives attached to the 
#                Bigfoot and unfail them, label with passed in label. 
#
#
##############################################################################
sub MakeFaildDriveOpr
{
    my ( $obj, $label ) = @_;

    my $opt = "PD";     # option for devstat command
    my $swtch;          # need to initilize is not used
    my @FaildId;        # Faild drive ids
    my %info;
    my $return;

    #
    # Find failed drive(s)
    # Get devstat
    # For each drive check the status 
    # If status does not = to 0X10 (GOOD) push drive id on to the array
    #

    %info = $obj->deviceStatus($opt);

    if(%info)
    {
        if($info{STATUS} == PI_GOOD)
        {
            $obj->displayDeviceStatus($opt, $swtch, %info);

            for my $i (0..$#{$info{LIST}})
            {
                if($info{LIST}[$i]{PD_DEVSTAT} != 10)
                {
                    logInfo(" ");
                    push(@FaildId, $info{LIST}[$i]{PD_PID});
                    printf "Pd Id  %5d  status  %5x ", 
                            $info{LIST}[$i]{PD_PID},
                            $info{LIST}[$i]{PD_DEVSTAT};
                }

            }
        }
        else
        {
            my $msg = "Unable to retrieve device status.";
            displayError($msg, %info);
            return ERROR;
        }
    }
    else
    {
        logInfo("ERROR: Did not receive a response packet.");
        return ERROR;    
    }

    # Restore and label all failed drive(s)
    
    for(my $drive = 0; $drive < scalar(@FaildId); $drive++)
    {
        $return = PdiskIdUnbypass($FaildId[$drive]);
        
        if ($return != GOOD)
        {
            logInfo("Pd Id was not unbypassed");
            return ERROR;
        }   
        
        logInfo("Physical disk $FaildId[$drive] is restored.");

        # Recan 
        $return = RescanBE( $obj );
        
        if ( $return == ERROR )
        {
            logInfo("Failed to rescan the back end");
            return ERROR;
        }
        
        $return = TestLibs::IntegCCBELib::LabelSingleDrive( $obj,
                                    $FaildId[$drive], 
                                    CCBEUNLABLEDTYPE);
        if ( $return == ERROR )
        {
            logInfo("Failed to label Pd Id $FaildId[$drive] as CCBEUNLABLEDTYPE");
            return ERROR;
        }

        # Label failed drive(s) with the lable

        $return = TestLibs::IntegCCBELib::LabelSingleDrive( $obj, 
                                    $FaildId[$drive],
                                    $label );
        if($return != GOOD)
        {
            logInfo("ERROR: Unable to label PDID $FaildId[$drive] as $label ");
            return ERROR;
        }            
    }
    return GOOD;
}



##############################################################################

=head2 FindDegradedRaids

Look at the vdisks that are in the operating state and see if any are in a 
degraded state.

=over 4

=item Usage:

 my @FuctionReturn = FindDegradedRaids( $ctlr );    
  
 shift(@FuctionReturn);
 
 for(my $i = 0; $i < scalar(); $i++)
 {
    print "Raid Id $FuctionReturn[$i]{RDID} \n";
    print "Raid status $FuctionReturn[$i]{RDSTAT} \n";
 }
 
 where: $ctlr - Controller object

 Notes:
 
 None

=item Returns:

 Array of hashes

 On success - Returns $FuctionReturn[0]{STATUS} = 0 (GOOD).
 On error   - Returns $FuctionReturn[0]{STATUS} = 1 (ERROR).

=back

=cut

##############################################################################
#
#          Name: FindDegradedRaids
#
#
#        Inputs: controller object
#
#       Outputs: Array of hashes
#                On success -  Returns $FuctionReturn[0]{STATUS} = 0 (GOOD).
#                On error   -  Returns $FuctionReturn[0]{STATUS} = 1 (ERROR).
#                Raid Id -     $FuctionReturn[$i]{RDID}.
#                Raid status - $FuctionReturn[$i]{RDSTAT}.
#
#
#  Globals Used: none
#
#   Description: Look at the vdisks that are in the operating state and see if
#                any are in a degraded state   
#
#
##############################################################################

sub UnUsedDisks
{
    my ( $Master, $IdRef, $Label ) = @_;
    my %info;
    my $return;

#   # unbaypass all the bypassed drives in the slot
#
#   my $return = UnbaypassAll($Master);
#   
#   if($return != GOOD)
#   {
#       logInfo("Error occured durring drive unbypass attempt");
#       return ERROR;
#   }
    
    my @drives = GetPddList( $Master );
     
    if ( $drives[0] == INVALID )
    {
        logInfo("ERROR: unable to get physical disk list");
        return ERROR;
    }

    # get the drived with no data on them

    for (my $i = 0; $i < scalar(@drives); $i++ )
    {
        # get the SOS table
        
        %info = $Master->getSos($drives[$i]);
    
        if( ! %info )
        {
            logInfo(">>>>>>>> Failed to get SOS information. <<<<<<<<");
            return ERROR;             

        }

        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from getSOS command <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }       
        
        # if there's only one record in the sos table
        # and the raid id of the record is the file system
        # that means that the drive does not have any data written to it

        if( ($info{COUNT} == 1) && ($info{LIST}[0]{RID} == 0x0000FFFF))
        {       
            push( @$IdRef, $drives[$i]);
        }
        
        if($Label)
        {
            # unlabel the drive first

            $return = TestLibs::IntegCCBELib::LabelSingleDrive( $Master,
                                        $drives[$i], 
                                        CCBEUNLABLEDTYPE);
            if ( $return == ERROR )
            {
                logInfo("Failed to label Pd Id $drives[$i] as CCBEUNLABLEDTYPE");
                return ERROR;
            }
            
            # now label the drive with the label

            $return = TestLibs::IntegCCBELib::LabelSingleDrive( $Master,
                                        $drives[$i], 
                                        $Label);
            if ( $return == ERROR )
            {
                logInfo("Failed to label Pd Id $drives[$i] as $Label");
                return ERROR;
            }

        }
    }
    return GOOD;

}

##############################################################################
#
#          Name: FindDegradedRaids
#
#
#        Inputs: controller object
#
#       Outputs: Array of hashes
#                On success -  Returns $FuctionReturn[0]{STATUS} = 0 (GOOD).
#                On error   -  Returns $FuctionReturn[0]{STATUS} = 1 (ERROR).
#                Raid Id -     $FuctionReturn[$i]{RDID}.
#                Raid status - $FuctionReturn[$i]{RDSTAT}.
#
#
#  Globals Used: none
#
#   Description: Look at the vdisks that are in the operating state and see if
#                any are in a degraded state   
#
#
##############################################################################

sub FindDegradedRaids
{
    my ( $ctlr) = @_;
    trace();
    
    my @return;
    my $count = 1;
    my %info = $ctlr->raids();
    
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        $return[0]{STATUS} = ERROR;
        return @return;
    }
    
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%info);
        $return[0]{STATUS} = ERROR;
        return @return;
    }

    for (my $i = 0; $i < $info{COUNT}; $i++)
    {
        if($info{RAIDS}[$i]{DEVSTAT} == 0x11)
        {
            $return[$count]{RDID} = $info{RAIDS}[$i]{RID};
            $return[$count]{RDSTAT} = $info{RAIDS}[$i]{DEVSTAT};
            $count++;              
        }
    }


    $return[0]{STATUS} = GOOD;
    return @return;
 
}




##############################################################################

=head2 CntrOwnedRdVd

Finds all the raids that are owned by the controller. In other worlds 
finds all the raids that are being mapped to the targets that are belong 
to the controllers.

=over 4

=item Usage:

 my %FuctionReturn = CntrOwnedRdVd( $ObjListRef );    
  
 my @ControllerSerial = keys{%FuctionReturn};
 
 shift{@ControllerSerial};
 
 for(my $i = 0; $i < scalar(@ControllerSerial); $i++)
 {
    my $RaidIdRef = $FuctionReturn{$ControllerSerial{$i}};
    my @RaidId = @$RaidIdRef;
    print "Contoller serial $ControllerSerial{$i} owns following raids @RaidId \n "; 
 }
 
 
 where: $ObjListRe - Reference to the list of objects       

 Notes:
  
 None

=item Returns:

 Array of hashes

 On success - Returns $FuctionReturn{STATUS} - 0 (GOOD).
 On error   - Returns $FuctionReturn{STATUS} - 1 (ERROR).

=back

=cut



##############################################################################
#
#          Name: CntrOwnedRdVd
#
#        Inputs: $ObjListRe - Reference to the list of objects  
#
#       Outputs:  $FuctionReturn{STATUS} - 0 (GOOD). 
#                 $FuctionReturn{STATUS} - 1 (ERROR).
#                 the rest of the kyes controller serial numbers
#                 values is a reference to an array Containing raid ids 
#                 that below to the controller 
#
#
#  Globals Used: none
#
#   Description: Finds all the raids that are owned by the controller. 
#                In other worlds finds all the raids that are being 
#                mapped to the targets that are belong to the controllers.
#
##############################################################################

sub CntrOwnedRdVd
{
    my ( $ObjListRef ) = @_;

    my @ObjList = @$ObjListRef;

    my %Return;
    my $BuildRef;

    my $Master;
    my @VdiskList;
    my @Serial;
    my $TemSerial;
    my @TmpFindOwner;
    my $Owner;          # Owner of the virtual disk
    my $Target;         # Do not need this, just function return
    my @TmpRaids;
    my $count = 1;      # 0 hash is status, 1 is the first raid hash
    
    # - Find master 
    
    logInfo(" ");
    logInfo("Looking for master controller");
    $Master = TestLibs::IntegCCBELib::FindMaster( $ObjListRef );
    
    if ( $Master == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller  <<<<<<<<");
        $Return{STATUS} = INVALID;
        return %Return; 
    }

    
    # - Get list of virtual disk ID
    
    logInfo(" ");
    logInfo("Getting list of virtual disk Ids ");
    
    @VdiskList = GetVdiskList($ObjList[$Master]);
    
    if( @VdiskList )
    {
        if( $VdiskList[0] == INVALID)
        {
            logInfo("ERROR: error occured while getting list of Vd Ids ");
            
            $Return{STATUS} = INVALID;
            return %Return; 
        }
    }
    else
    {
        logInfo("ERROR: there no virtual disks created on the Bigfoot");
        
        $Return{STATUS} = INVALID;
        return %Return; 
    } 

    # - Get list of serial numbers for the controllers 

    logInfo(" ");
    logInfo("Getting serial number for controller(s)");
    
    for ( my $i = 0; $i < scalar(@ObjList); $i++)
    { 
        $TemSerial = GetSerial($ObjList[$i]);
        
        if( $TemSerial == INVALID)
        {
            logInfo("ERROR: error occured while getting list of controller serial num ");
            
            $Return{STATUS} = INVALID;
            return %Return; 
        }
        else
        {
            
            push(@Serial, $TemSerial);
        }
    }


    #
    # - For each virtual disk find Owner, 
    #           compare owners serail to passed in serial
    #           if both match 
    #                       find raid id(s) for the Vd Id
    #                       build an array of hashes
    #                       {OWNERSRL}  - Serial number of the owner of the vd
    #                       {VDID} - virtual disk id
    #                       {TARGETID} - target id
    #                       {RAIDS} - array of raid ids 
    
    # - If everything is well return full hash
    # - If error return empty hash
     
    logInfo(" ");
    
    #logInfo("Starting to look for for raids owned by controller serial ". $Serial);
    
    #
    # For each virtual disk find the owner
    # build an output hash
    #

    for(my $t = 0; $t < scalar( @VdiskList ); $t++)
    {
        ($Owner, $Target) = TestLibs::BEUtils::FindVdiskOwner ($ObjListRef, 
                                                                \@Serial, 
                                                                $VdiskList[$t]);

        if($Owner == INVALID)
        {
            logInfo("ERROR while getting Vd Id ". $VdiskList[$t]. " owner");
            logInfo("Virtual disk ID ". $VdiskList[$t] ." went off line");
            $Return{STATUS} = INVALID;
            return %Return;         
        }
        
        @TmpRaids = getVdiskRaids($ObjList[$Master], $VdiskList[$t] );
            
        if($TmpRaids[0] == INVALID)
        {
            logInfo("ERROR: error occure while getting raid ids for vd id ". $VdiskList[$t]);           
            $Return{STATUS} = INVALID;              
            return %Return;         

        }
        else
        {
            
            $BuildRef = $Return{$Serial[$Owner]}; 
            
            my @Build;

            if( $BuildRef )
            {
                @Build = @$BuildRef;
            }

            for (my $p = 0; $p < scalar(@TmpRaids); $p++)
            {
                
                push(@Build, $TmpRaids[$p]);
            }
            $Return{$Serial[$Owner]} = \@Build;     
        }    
                
    }
        
    $Return{STATUS} = GOOD;
    return %Return; 
}




##############################################################################

=head2 getVdiskRaids

Gets raid ids for a virtual disk.

=over 4

=item Usage:

 my @FuctionReturn = getVdiskRaids( $ctlr, $vdd );    
   
 shift(@FuctionReturn);
 
 for(my $i = 0; $i < scalar(@FuctionReturn); $i++)
 {
    print "Virtual disk id  $vdd  owned following raids @FuctionReturn \n "; 
 }
 
 
 where: $ctlr - Controller object       
        $vdd - Virutal disk Id      

 Notes:
  
 None

=item Returns:

 Array of hashes

 On success - Returns $FuctionReturn[0] - 0    (GOOD).
 On error   - Returns $FuctionReturn[0] - -999 (INVALID).

=back

=cut




###############################################################################
#
#          Name: getVdiskRaids
#
#        Inputs: controller object, vdisk ID
#
#       Outputs: array of RIDS or INVALID as the first element if an error
#                occurred
#
#  Globals Used: none
#
#   Description: Returns an array of the RID's that make up the specified
#                vdisk.
#
##############################################################################  
sub getVdiskRaids
{
    
    my ($ctlr, $vdd) = @_;

    my @raids;

    my %ret = $ctlr->virtualDiskInfo($vdd);

    #
    # Check to see if there was a return from the call.
    #
    if ( ! %ret  )            
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
        $raids[0] = INVALID;        
        return @raids;
        
    }

    #
    # Check to see if the call returned an error.
    #
    if ( $ret{STATUS} != PI_GOOD )     
    {
        logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
        PrintError(%ret);
        $raids[0] = INVALID;
        return @raids;
    }

    #
    # Put each raids ID in the return array.
    #
            
    my $totalRaids = $ret{RAIDCNT};    
    for (my $j = 0; $j < $totalRaids; $j++)
    {        
        $raids[$j] = $ret{RIDS}[$j];
    }
     
    return @raids;
}



##############################################################################

=head2 SearchLogs

Following function searches through generated logs, updating log message 
bit map, that has following form 1st bit - logs message string found 2nd 
bit logs id found the test of the bits is the number of times logs ID 
occurred.

=over 4

=item Usage:

 my @FuctionReturn = SearchLogs( $ObjListRef, 
                                 $LogIdRef, 
                                 $LogStringRef, 
                                 $BitMapRef, 
                                 %LastLogs );    
   
 shift(@FuctionReturn);
 
 for(my $i = 0; $i < scalar(@FuctionReturn); $i++)
 {
    print "Virtual disk id  $vdd  owned following raids @FuctionReturn \n "; 
 }
 
 
 where: $ObjListRef - Controller objest list reference   
        $LogIdRef - Log id list reference 
        $LogStringRef - Log message list reference 
        $BitMapRef - Reference to bit map  
        %LastLogs - Log info hash (retrieved from ReturnLastLog)    


 Notes:
  
 None

=item Returns:

 Array of hashes

 On success - Returns - 0 (GOOD).
 On error   - Returns - 1 (ERROR).

=back

=cut


##############################################################################
#
#          Name: SearchLogs
#
#        Inputs: $ObjListRef - Controller objest list reference    
#                $LogIdRef - Log id list reference 
#                $LogStringRef - Log message list reference 
#                $BitMapRef - Reference to bit map  
#                %LastLogs - Log info hash (retrieved from ReturnLastLog)  
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: Following function searches through generated logs, 
#                updating log message bit map, that has following form 1st bit - logs 
#                message string found, 2nd bit logs id found, the rest of the bits is the 
#                number of times logs ID occurred.
#
#          bit    15           9 8             1 0
#                | c c c c c c c c c c c c c c|f|f|
#                | ------ count --------------|| \flag: message string found
#                                               \flag: log ID found
#
##############################################################################
sub SearchLogs
{
    my ($ObjListRef, $LogIdRef, $LogStringRef, $BitMapRef, $LastLogSeqRef) = @_ ; 
    
    my $mode = 0x10;                    # - use sequence number, in hex is 0x10
                                        # - see ccbe help for more options
    my @ObjList = @$ObjListRef;         #- object list

    my @LogId = @$LogIdRef;             # list of log ids

    my @LogString = @$LogStringRef;     # list of log strings
    my @LastLogSeq = @$LastLogSeqRef;   # list of last log sequence numbers for each controller 
         
    my %LogHash;
    my $Log;                            # Matched message to the ID

    
    my $outfile;                        # is not used but need to be initialized
    my $gmt = 0;                        # is not used need to be initialzed

    my $LogSeqBeg;
    my $LogSeqEnd;

    my $bit;
    my $index;
    my @IdFound;
    my %CurrentLog;
    my @LastLog;
    
    # Array that keeps track of how many time the ID has been found with
    # in log messages

    # Number of elements in the 3 arrays have to match
    # log Id array 
    # log Message array
    # and bit map 
    
    if( scalar(@LogId) != scalar(@LogString))
    {
        logInfo("Number of elements in the log Id array ". scalar(@LogId));
        logInfo("Number of elements in the log String array ". scalar(@LogString));
        logInfo("The above must match!");
        return ERROR;
    }

    # initialize the array of how many times the log Id was found with in the logs
    # elements of the number of times found log id array match the lements of log Id array
    # log string array, and bit map array
    #

    # Array that keeps track of how many time the ID has been found with
    # in log messages

    for (my $t = 0; $t < scalar(@LogId); $t++)  
    {  
        $IdFound[$t] = 0;   
    }

    %CurrentLog = ReturnLastLog($ObjListRef);                                # <<<<<< gets current last log entry on each controller

    for(my $i = 0; $i < scalar(@ObjList); $i++)
    {
        logInfo("For controller - ". $ObjList[$i]->{HOST});
        
        # last log entry from the last time the log entry was retrieved 
        
        $LogSeqBeg = $LastLogSeq[$i];
        
        # after the function is done searching the logs the value in $LogSeqEnd will become
        # last log entry 

        $LogSeqEnd = $CurrentLog{$i}->{MASTER_SEQUENCE_NUMBER};                   
        
        print "Retrieved Log sequence End $LogSeqEnd \n";
        print "Up to $LogSeqBeg \n";

        # Create array of last log message looked at in order 
        # at teh end of the function to update $LastLogSeqRef

        push(@LastLog, $LogSeqEnd);
        
        # subtract the sequence number of the last log that has been retreived 
        # from the current log generated in order to figer out the number of logs to retreive 
        # and search through                                 
        
        if( ($LogSeqEnd -  $LogSeqBeg) == 0) 
        {
            logInfo("There are no new logs generated ");
        }
        else
        {
            # if there is at least one message generated that means that there may be two messages in 
            # reality that has not been check, in other wolds let's say we have last log message number
            # 3 that we have not checked, and we have current log message which is 5, doing the math
            # we get 5-3=2, meaning that we need to retrieve only 2 logs from log 5, meaning only log number
            # 5 and 4 will get retrieved, but not 3, this way 3 does not get checked with is a dug
            # So if is add 1 to the calculation (5-3) + 1 = 3, the we will get 3 messages from message 
            # number 5, and it would make it to be 5, 4, 3.
            # In other wolds if there's at least one message generated need to add one to the fomular, to insure that 
            # the generated message will be included

            print "Getting messages from  $LogSeqEnd number of mess ", ($LogSeqEnd -  $LogSeqBeg)," \n";

            my %LogHash = $ObjList[$i]->logInfo( ( ($LogSeqEnd -  $LogSeqBeg) + 1), # need to add one 5-3=2 but 3 messages generated 
                                                 $mode, 
                                                 $LogSeqEnd);
            if(!(%LogHash))
            {
                logInfo("ERROR: Did not receive a response packet.");
                return ERROR;
            }
        
            if ($LogHash{STATUS} != PI_GOOD)
            {
                my $msg = "Unable to retrieve log information.";
                displayError($msg, %LogHash);
                return ERROR;
            }
    
                    
            # number of log messagers retrieved in the hash
            
            for( my $t = 0; $t < $LogHash{EVENT_COUNT}; $t++ )
            {               
                for(my $p = 0; $p < scalar(@LogId); $p++)
                {
                
                    if($LogId[$p] == $LogHash{$t}{EVENT_CODE})
                    {
                    
                        # generate the log string to print

                        $Log = 0;
                        $Log .= sprintf $LogHash{$t}->{MASTER_SEQUENCE_NUMBER}. " ";
                        $Log .= sprintf "0x%04X", $LogHash{$t}->{EVENT_CODE}. " ";
                        $Log .= sprintf $LogHash{$t}->{SEQUENCE_NUMBER} . " ";
                        $Log .= sprintf $LogHash{$t}->{TIME_AND_DATE} . "  ";
                        $Log .= sprintf $LogHash{$t}->{MESSAGE_TYPE} . "  ";
                        $Log .= sprintf $LogHash{$t}->{MESSAGE_DESC} . " ";
                    
                        # update the count for the number of times the log id was found
                    
                        $IdFound[$p]++;
                    
                        $index = 1;

                        $bit = 1 << $index;

                        # update map

                        $BitMapRef->[$p] |= $bit;
                                                
                        if($LogHash{$t}->{MESSAGE_DESC} =~ /$LogString[$p]/)                                 
                        {
                            logInfo("Log string match to log id  ");
                                                        
                            # result of string match

                            $index = 0;
                            $bit = 1 << $index;

                            # update map

                            $BitMapRef->[$p] |= $bit;   
                        }   
                        else
                        {
                            logInfo("String did not match to  ". $LogString[$p]);
                        }    
                    } # end of if retreved log id matches looking for log id passed in to the function  
                } # end of number of log ids looking for - passed into the function
            }
        }
    } # end of loop through controllers
     
    
        
    for(my $y = 0; $y < scalar(@IdFound); $y++)     
    {
        # result of number of times log id was found
        
        $BitMapRef->[$y] +=  ($IdFound[$y] * 4);
print" count update: added  $IdFound[$y]  to $BitMapRef->[$y]  \n";

    }
    # print  bit map

    TestLibs::Validate::PrintTargetMap($BitMapRef);
    print "Current logs @$LastLogSeqRef \n";
    $LastLogSeqRef = \@LastLog; 
    print "Logs now  @$LastLogSeqRef \n";
    return GOOD;
}






##############################################################################

=head2 ReturnLastLog

Following function return log message for the controllers on the list.

=over 4

=item Usage:

 my %FuctionReturn = ReturnLastLog( $ObjListRef );    
   
 my @keys = keys(%FuctionReturn);

 for(my $i = 0; $i < scalar(@keys); $i++)
 {
    if($FuctionReturn{$i}{STATUS} == GOOD)
    {
        print "From controller $i last logs message has been retrieved \n";
    }
 }
 
 
 where: $ObjListRef - Controller objest list reference      


 Notes:
  
 None

=item Returns:

 Array of hashes

 On success - Returns - $FuctionReturn{$i}{STATUS} 0  (GOOD).
 On error   - Returns - $FuctionReturn{$i}{STATUS} 1 (ERROR).

=back

=cut



##############################################################################
#
#          Name: ReturnLastLog
#
#        Inputs: $ObjListRef - Controller objest list reference    
#
#       Outputs: $FuctionReturn{$i}{STATUS} 0  (GOOD). 
#                $FuctionReturn{$i}{STATUS} 1 (ERROR).
#
#  Globals Used: none
#
#   Description: Following function return log message for the controllers on the list.
#
#
##############################################################################


sub ReturnLastLog
{
    my ( $ObjListRef ) = @_;

    my @ObjList = @$ObjListRef;

    my $outfile;            # - is not used but needs to be initialized
        
    my $mode = 0x10;         # - use test mode                   
                            # - see ccbe help for more options

    my $count = 1;          # - number of logs to get and display
    
    my $gmt = 0;            # - default time display option
    
    my %Return;             # - each element contains a hash of controller    # <<<<<<< this is really an array of hases
                            # - log massege                                   # it would be better to use an array
                            # - Hash structure:
                            # -      
                            #   $Return{$i}->{STATUS} = GOOD/BAD
                            #   $Return{$i}->{MESSAGE_LEN_TOTAL} 
                            #   $Return{$i}->{EVENT_CODE}
                            #   $Return{$i}->{SEQUENCE_NUMBER}
                            #   $Return{$i}->{TIME_AND_DATE}
                            #   $Return{$i}->{MESSAGE_TYPE}
                            #   $Return{$i}->{MESSAGE_DESC}
                            #   $Return{$i}->{MESSAGE_LEN_BINARY}
                            #   $Return{$i}->{EVENT_TYPE_BINARY}
                            #   $Return{$i}->{MESSAGE_BINARY}
    my $sequence = 0;                           
    my %rsp;

        
    for(my $i = 0; $i < scalar(@ObjList); $i++)
    {
        %rsp = $ObjList[$i]->logInfo($count, $mode, $sequence);
        
        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                
                $Return{$i}->{STATUS} = GOOD;
                $Return{$i}->{MASTER_SEQUENCE_NUMBER} = $rsp{0}->{MASTER_SEQUENCE_NUMBER};
                $Return{$i}->{MESSAGE_LEN_TOTAL} = $rsp{0}->{STATUS}; 
                $Return{$i}->{EVENT_CODE} = $rsp{0}->{EVENT_CODE};
                $Return{$i}->{SEQUENCE_NUMBER} = $rsp{0}->{SEQUENCE_NUMBER};
                $Return{$i}->{TIME_AND_DATE} = $rsp{0}->{TIME_AND_DATE};
                $Return{$i}->{MESSAGE_TYPE} = $rsp{0}->{MESSAGE_TYPE};
                $Return{$i}->{MESSAGE_DESC} = $rsp{0}->{MESSAGE_DESC};
                $Return{$i}->{MESSAGE_LEN_BINARY} = $rsp{0}->{MESSAGE_LEN_BINARY};
                $Return{$i}->{EVENT_TYPE_BINARY} = $rsp{0}->{EVENT_TYPE_BINARY};
                $Return{$i}->{MESSAGE_BINARY} = $rsp{0}->{MESSAGE_BINARY};  
            }
            else
            {
                my $msg = "Unable to retrieve log information.";
                displayError($msg, %rsp);
                $Return{$i}->{STATUS} = ERROR;
            }
        }
        else
        {
            logInfo("ERROR: Did not receive a response packet.");
            $Return{$i}->{STATUS} = ERROR;

        }
    }
    return %Return;

}


##############################################################################

=head2 CreateLogBitMap

Creates bit map for logs search function, return reference to the bitmap 

=over 4

=item Usage:

 my $FuctionReturn = CreateLogBitMap( $NumOfMessages );    
   
 
 where: $NumOfMessages - Number of log messages bitmap has to be created for.     


 Notes:
  
 None

=item Returns:


 On success - reference to the bitmap.

=back

=cut




##############################################################################
#
#          Name: CreateLogBitMap
#
#        Inputs: $NumOfMessages - Number of log messages bitmap has to be created for. 
#
#       Outputs: On success - reference to the bitmap.
#
#  Globals Used: none
#
#   Description: Creates a bit map for all the messages to be checked durring 
#                the test
#
##############################################################################
sub CreateLogBitMap
{
    my ( $NumOfMessages ) = @_;
    
    my @map;
    
    #-create array of bit maps and initialize them to 0

    for(my $i = 0; $i < $NumOfMessages; $i++)
    {
        $map[$i] = 0;
    }  
    return \@map;
}


##############################################################################




##############################################################################

=head2 displayError

Displays an error message followed by the status and error codes from a command 
response.

=over 4

=item Usage:

 my $FuctionReturn = CreateLogBitMap( $msg, %rsp);    
   
 
 where: $msg - input message.
        %rsp - return hash from CCBE command.      


 Notes:
  
 None

=item Returns:

  Print statments.

=back

=cut




##############################################################################
# Name:     displayError
#
# Desc:     Displays an error message followed by the status and
#           error codes from a command response.
#
# Input:    message and command response hash.
##############################################################################

sub displayError
{
    my ($msg, %rsp) = @_;

    my $msg2 = "";
    logInfo( $msg );
    
    $msg2 .= sprintf ("Status Code:    0x%02x  \n", $rsp{STATUS});

    if (defined($rsp{STATUS_MSG}))
    {
        $msg2 .= sprintf (" \"%s\"  \n", $rsp{STATUS_MSG});
    }


    $msg2 .= sprintf ("Error Code:     0x%02x  \n", $rsp{ERROR_CODE});

    if (defined($rsp{ERROR_MSG}))
    {
        $msg2 .= sprintf (" \"%s\" \n", $rsp{ERROR_MSG});
    }

   logInfo($msg2);
}


##############################################################################
# Name:     max
#
# Desc:     return larger number of the two numbers.
#
# Input:    two numbers
#
##############################################################################

sub max
{
    my ( $a, $b ) = @_;

    if( $a > $b )
    {
        return $a;
    }
    
    return $b;
}


##############################################################################

=head2 ScrubMain

Logical main for scrub test cases

=over 4

=item Usage:

 my $FuctionReturn = ScrubMain($ObjRef, $Sn, $Opt, $MoxaIp, $MoxaChan );    
   
 
 where: 
        $ObjRef - Reference to the list of controller objects 
            $Sn - Reference to the list of serial numbers 
           $Opt - Test Case option  
              1 - Good Path 
              2 - Fail/Unfail Controller 
              3 - Power cycle both controllers 
              4 - By pass physical disk let rebuild 
              5 - Fail physical disk with not hot spare 
              6 - Run defraged 
              7 - Add hot spare 
              8 - write error to where no data is located 
              9 - corrupt data 
              99 - execute all test case 1-9 
       
              $MaxaIp - Pointer to an array of Moxa IP addresses        
              $MoxaChan - Reference to an array containing Moxa channels 
 
 Notes:
  
 None

=item Returns:

  GOOD or ERROR.

=back

=cut

##############################################################################
#
#          Name: ScrubMain
#
#        Inputs: 
#               $ObjRef - Reference to the list of controller objects
#                   $Sn - Reference to the list of serial numbers
#                  $Opt - Test Case option 
#                     1 - Good Path
#                     2 - Fail/Unfail Controller
#                     3 - Power cycle both controllers
#                     4 - By pass physical disk let rebuild
#                     5 - Fail physical disk with not hot spare
#                     6 - Run defraged
#                     7 - Add hot spare
#                     8 - write error to where no data is located
#                     9 - corrupt data
#                    99 - execute all test case 1-9
#                     
#               $MaxaIp - Pointer to an array of Moxa IP addresses       
#               $MoxaChan - Reference to an array containing Moxa channels
#
#       Outputs: GOOD, ERROR
#
#  Globals Used: none
#
#   Description: This is the logical main for scrub test cases
#
#
##############################################################################
sub ScrubMain
{
    my ($ObjRef, $Sn, $Opt, $MoxaIp, $MoxaChan ) = @_;

    if($Opt == 1)
    {
        if( ScrubGoodPath($ObjRef, 1) != GOOD)
        {
            logWarning("Test failed while executing test case N 1");
            return ERROR;   
        }   
    }
   
    if($Opt == 2)
    {
        if( ScrubFailController( $ObjRef, $Sn, 1, $MoxaIp, $MoxaChan ) != GOOD)
        {
            logWarning("Test failed while executing test case N 2");
            return ERROR;
        }

    } 
    
    if($Opt == 3)
    {

        if( ScrubPowerCycle( $ObjRef, $MoxaIp, $MoxaChan, 1) != GOOD)
        {
            logWarning("Test failed while executing test case N 3");
            return ERROR;           
        }
    
    } 
   
    if($Opt == 4)
    {
        if( ScrubFaildDriveLetRebuild($ObjRef, 1) != GOOD)
        {
            logWarning("Test failed while executing test case N 4");
            return ERROR;               
        }

    } 
    
    if($Opt == 5)
    {
        if( ScrubFailDrive($ObjRef, 1, 0, 0) != GOOD )
        {
            logWarning("Test failed while executing test case N 5");
            return ERROR;           
        }
    } 

    
    if($Opt == 6)
    {
        if( ScrubFailDrive($ObjRef, 1, 0, 7) != GOOD)
        {
            logWarning("Test failed while executing test case N 6");
            return ERROR;           
        }

    } 
    if($Opt == 7)
    {
        if( ScrubFailDrive($ObjRef, 1, 0, 8) != GOOD)
        {
            logWarning("Test failed while executing test case N 7");
            return ERROR;               
        }
    } 
    if($Opt == 8)
    {
        if( ScrubShallNotFindError($ObjRef, 1) != GOOD)
        {
            logWarning("Test failed while executing test case N 8");
            return ERROR;       
        }
    
    } 
    if($Opt == 9)
    {
        if( ScrubFindError($ObjRef, 1) != GOOD)
        {
            logWarning("Test failed while executing test case N 9");
            return ERROR;                   
        }
    } 
    
    if($Opt == 99)
    {
        
        if( ScrubGoodPath($ObjRef, 1) != GOOD)
        {
            logWarning("Test failed while executing test case N 1");
            return ERROR;   
        }

        # we are dealing with a two or more "way" system

        if( scalar(@$ObjRef) > 1)
        {

            if( ScrubFailController( $ObjRef, $Sn, 1,$MoxaIp, $MoxaChan ) != GOOD)
            {
                logWarning("Test failed while executing test case N 2");
                return ERROR;
            }
                        
            if( ScrubPowerCycle( $ObjRef, $MoxaIp, $MoxaChan, 1) != GOOD)
            {
                logWarning("Test failed while executing test case N 3");
                return ERROR;           
            }
        }

        if( ScrubFaildDriveLetRebuild($ObjRef, 1) != GOOD)
        {
            logWarning("Test failed while executing test case N 4");
            return ERROR;               
        }
        if( ScrubFailDrive($ObjRef, 1, 0, 0) != GOOD )
        {
            logWarning("Test failed while executing test case N 5");
            return ERROR;           
        }
        if( ScrubFailDrive($ObjRef, 1, 0, 7) != GOOD)
        {
            logWarning("Test failed while executing test case N 6");
            return ERROR;           
        }
        if( ScrubFailDrive($ObjRef, 1, 0, 8) != GOOD)
        {
            logWarning("Test failed while executing test case N 7");
            return ERROR;               
        }
        if( ScrubShallNotFindError($ObjRef, 1) != GOOD)
        {
            logWarning("Test failed while executing test case N 8");
            return ERROR;       
        }
        if( ScrubFindError($ObjRef, 1) != GOOD)
        {
            logWarning("Test failed while executing test case N 9");
            return ERROR;                   
        }       
    }

    return GOOD;


}

1;
