#! /usr/bin/perl 
# $Header$
##############################################################################
#  
#   CCBE Integration test library - NWay Config Tests
#
#   01/23/2004  XIOtech   Craig Menning, Mark Schibilla
#
#   A set of library functions for integration testing. This set support
#   testing the creation of an N way system.
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2004 XIOtech
#
#   For XIOtech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::ConfigTests - Perl Tests to test N Way Configuration

$Id: ConfigTests.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing the configuration
of an N way system.  This will involve building up and tearing down
a DSC.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

            NWayConfigLoopEntry() 
              
        The less significant ones

              <none>

=cut


#                         
# - what I am
#

package TestLibs::ConfigTests;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;

use TestLibs::ConfigTestSupport;
use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - local Constants used
#



#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 4298 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #


    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        &NWayConfigLoopEntry
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.
         
 $moxaPtr: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.
          
 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller. 

 $retIn: This is a controle variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be 
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the 
          attached servers. When configuring systems, this list determines 
          which WWNs will be associated with vdisks. If an entry in this 
          list is not found on the system, it will be ignored. A WWN 
          found on the system that is not included in the list will not 
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.
       



=back

=cut


###############################################################################


###############################################################################

=head2 NWayConfigLoopEntry function


Change text here to match what this really does! 


The primary entry point for the Bigfoot N Way Configuration tests.

A function used for debugging the code as a generic entry. The final 
parameter represents the test case to be run. A test case of 99 will
run most tests sequentially. There is no guarantee that the tests can actually 
run sequentially and give full coverage.

The test system should be configured as desired and IO from the 
servers should be running. Most likely this will mean a two-way system.
IO from the servers needs to be consistent over time or the IO validation
checks may fail. For the most part, RAIDs should be redundant as many tests 
will fail pdisks and require rebuilds. The test will hang if a drive 
becomes permanently degraded.

Tests can be run individually by specifying the test case number. ( 1...25+)
Not all test case numbers exist ( the list is not contiguous). Specifying 
an invalid number just means no test will be run. Test case 99 will run most
test cases sequentially. Test that are designed to cause a fatal condition 
will not be part of the 99 sequence.

Some test require a minimum of a 2 way configuration, others will run on 
1-way or n-way configurations.

Refer to the individual test cases for more information on the 
individual tests.

=cut

=over 1

=item Usage:

 my $rc = NWayConfigLoopEntry($coPtr, $retIn, $snPtr, $moxaPtr, $mmPtr, $case );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaPtr is a pointer to a list of Moxa controller IP addresses
        $mmPtr is a pointer to a list of tha Moxa channel mappings
        $case is the test case to run

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the test(s)
           ran to completion without error. Test logs must be reviewed to
           ensure the test ran correctly.



=back

=cut



##############################################################################
#
# Name:     NWayConfigLoopEntry
#
# Inputs:   $coPtr          Pointer to controller object array
#           $snPtr          Pointer to controller serial number array
#           $moxaPtr        Pointer to array of Moxa IP addresses
#           $moxaChPtr      Pointer to array of Moxa channels
#           $wwnPtr         Pointer to array of server WWNs
#           $ipPtr          Pointer to array of controller IP addresses
#           $case           Test case number
#
# Outputs:  GOOD or ERROR
#
# Comments: This is the main NWay function called by Launcher.pm.  Input
#           parms are the standard Launcher inputs.  
#
##############################################################################
sub NWayConfigLoopEntry
{
    trace();
    my ($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $wwnPtr, $ipPtr, $case) = @_;

    my $msg ="";
    my $msg0 = "";
    my @coList = @$coPtr;
    my $numCtlrs = scalar @coList;
    my $totalLoops = 1;
    my $ret = GOOD;
    my @snList;
    my @ipList;


    $msg  = "------ NWayConfigLoopEntry: Starting an NWay Config Test --------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);
    

    #
    # Call the appropriate test case.
    #
    if (($case == 0) || ($case == 99)) 
    { 
        $ret = NWayConfigCase00($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, 34); 
    }    
    if (($case == 1) || ($case == 99)) 
    { 
        $ret = NWayConfigCase01($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, 34, 2, 1); 

    }
    if (($case == 2) || ($case == 99)) 
    { 
        $ret = NWayConfigCase02($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, GOOD); 

    }


    
    # Used to test and debug new stuff
    if ($case == 77)
    { 
        $ret = NWayConfigCaseTemp($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, 4); 
    }
    
        
    if ( $ret != GOOD ) 
    { 
        return $ret; 
    }

    return $ret;
}


###############################################################################


##############################################################################
#
# NWay Configuration Test Cases   
#
##############################################################################



##############################################################################
#
# Name:     NWayConfigCase00
#
# Inputs:   $coPtr          Pointer to controller object array
#           $snPtr          Pointer to controller serial number array
#           $moxaPtr        Pointer to array of Moxa IP addresses
#           $moxaChPtr      Pointer to array of Moxa channels
#           $ipPtr          Pointer to array of controller IP addresses
#           $vdiskStrategy  How VDisks are created
#
# Outputs:  GOOD or ERROR
#
# Comments: Create a system configuration that can be used to run  
#           FailOverNWay.  This will take the place of a couple CCBE cmd
#           files that Chris uses.
#
##############################################################################
sub NWayConfigCase00
{
    trace();
    
    my ($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, $vdiskStrat) = @_;

    my @cnUsed;         # Flag for controller added to group
    my $loopCount = 1;
    my $totalLoops = 1;
    my $msg ="";
    my $msg0 = "";
    my $numServers = 0;
    my $numVdisks = 0;
    my $masterIndex;
    my $slaveIndex;
    my @coList;         # Controller object list
    my @snList;         # Controller SN list
    my $remaining;
    my $ctrl;
    my $master;
    my $i;
    my %rsp;
    my $ret;


    $msg  = "------ Test Case 0: 4 way setup to run FailOverNWay --------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # Set up a loop to do some stuff
    TEST: while ($loopCount)
    {
        logInfo "*******************************************\n";
        logInfo "*  Test loop ".($totalLoops-$loopCount+1)." of $totalLoops";
        logInfo "*******************************************\n";   

        #
        # Initialize the controllers in use array to indicate that all
        # controllers are available.
        #
        for ($i = 0; $i < NWAY_MAX_CONTROLLERS; $i++)
        {
            $cnUsed[$i] = 0;
        }

        #
        # Power cycle all controllers
        #
        last TEST if GOOD != PowerCycleAllControllers($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr);

        #
        # The controller list and SN list are not valid until after
        # PowerCycleAllControllers() has run.
        #
        @coList = @$coPtr;
        @snList = @$snPtr;

        #
        # Clean all controllers.  License for the maximum number of 
        # controllers allowed
        #
        last TEST if GOOD != CleanAndLicense($coPtr, $ipPtr, NWAY_MAX_CONTROLLERS);

        #
        # Find the master controller.
        #        
        $masterIndex = FindMaster($coPtr);

        if ($masterIndex == INVALID)
        {
            logInfo "Failed to find master controller";
            last TEST;
        }
        else
        {
            # Indicate that this controller is in use.
            $cnUsed[$masterIndex] = 1;
        }

        # Label all remaining drives before adding the next controller
        $ret = LabelAllDrives($coList[$masterIndex], 20, 1, 1, 0, 3);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>>>> Failed to label the drives <<<<<<<<");
            last MAIN;
        }
    
        #
        # Loop to add the remaining controllers in random order.
        # 
        $slaveIndex = $masterIndex;
        for ($i = 0; $i < NWAY_MAX_CONTROLLERS - 1; $i++)
        {
            # Pick another random slave
            while ($cnUsed[$slaveIndex] == 1)
            {
                $slaveIndex = int(rand(NWAY_MAX_CONTROLLERS));
            }
        
            # Indicate that this controller is in use
            $cnUsed[$slaveIndex] = 1;
        
            #
            # Add the controller
            #
            $ctrl = $i + 2;
            logInfo "Add controller $ctrl - SN $snList[$slaveIndex]";
            last TEST if GOOD != AddController($coPtr, $slaveIndex);
        }

        #
        # Prompt the user to rescan so Bigfoot will see the server(s)
        #
        PromptUser( 3 );

        #
        # After the prompt be sure we are still connected.
        #
        last TEST if GOOD != TestNReconnectAll($coPtr);

### start temp code    
#    START:
#        last TEST if GOOD != ConnectAllControllers($coPtr, $snPtr, $ipPtr);
#
#        @coList = @$coPtr;
#        @snList = @$snPtr;
#
#        ($masterIndex, $slaveIndex) = FindMasterPickSlave($coPtr);
### end temp code


        #
        # Find the master controller.
        #        
        $masterIndex = FindMaster($coPtr);
        if ($masterIndex == INVALID)
        {
            logInfo "Failed to find master controller";
            last TEST;
        }

        #
        # Find out how many servers there are.
        #
        last TEST if GOOD != GetServerCount($coList[$masterIndex], \$numServers);
        
        #
        # Create some VDisks
        #
        last TEST if GOOD != MakeSomeVDisks($coList[$masterIndex], $numServers, \$numVdisks, $vdiskStrat);

        #
        # Associate servers and VDisks
        #
        last TEST if GOOD != AssociateServersToVDisks($coList[$masterIndex], $numServers, 2);
        

        #
        # Prompt the user to start I/O
        #
        PromptUser( 9 );

        #
        # After the prompt be sure we are still connected.
        #
        last TEST if GOOD != TestNReconnectAll($coPtr);

        
        #
        # FailOverNWay will fail if all RAIDs are not done initializing.
        # Check them all before continuing.  We know some are already done 
        # (since associations were done above) but to keep things simple
        # just check 'em all.
        #
        print("All RAID inits must be complete before starting fail-over testing...\n");
        CheckVDiskInit($coList[$masterIndex], $numVdisks);
    }
    
    # NOTE: 'last' does not execute the 'continue' block. 
    # Everything else does.
    continue
    {
        --$loopCount;
        if ($loopCount == 0)
        {
            last;
        }
    }

    logInfo("*** End of NWayConfigCase00 ***");

    return GOOD;
}


##############################################################################
#
# Name:     NWayConfigCase01
#
# Inputs:   $coPtr          Pointer to controller object array
#           $snPtr          Pointer to controller serial number array
#           $moxaPtr        Pointer to array of Moxa IP addresses
#           $moxaChPtr      Pointer to array of Moxa channels
#           $ipPtr          Pointer to array of controller IP addresses
#           $vdiskStrat     How VDisks are created
#           $assocStrat     How Servers are associated with VDisks 
#           $option         Optional behavior - see the code
#
# Outputs:  GOOD or ERROR
#
# Comments: 
#           - Build up a complete 2 way system, create/associate VDisks and
#             start I/O.
#
#           - License for N=3 and add 3rd controller.  Associate new servers           
#             with existing VDisks or create more if necessary.  Restart I/O.
#             Expand all VDisks if option is set.
#             
#           - License for N=4 and add 4th controller.  Associate new servers
#             with existing VDisks or create more if necessary.  Restart I/O.
#
##############################################################################
sub NWayConfigCase01
{
    trace();
    
    my ($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, $vdiskStrat, $assocStrat, $option) = @_;

    my $loopCount = 1;
    my $totalLoops = 1;
    my $msg ="";
    my $msg0 = "";
    my $numServers = 0;
    my $numVdisks = 0;
    my $masterIndex;
    my $slaveIndex;
    my $server = 0;
    my $lun = 0;
    my $vdisk = 0;
    my @coList;         # Controller object list
    my @snList;         # Controller SN list
    my $remaining;
    my $ctrl;
    my $master;
    my %rsp;
    my $ret;


    $msg  = "------ Test Case 1: 2 way to 4 way build-up ----------------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);



    # Set up a loop to do some stuff
    TEST: while ($loopCount)
    {
        logInfo "*******************************************\n";
        logInfo "*  Test loop ".($totalLoops-$loopCount+1)." of $totalLoops";
        logInfo "*******************************************\n";   


        #
        # Power cycle all controllers
        #
        last TEST if GOOD != PowerCycleAllControllers($coPtr, $snPtr, 
                                                      $moxaPtr, $moxaChPtr, 
                                                      $ipPtr);

        #
        # The controller list and SN list are not valid until after
        # PowerCycleAllControllers() has run.
        #
        @coList = @$coPtr;
        @snList = @$snPtr;

        #
        # Clean all controllers.  License for N=2
        #
        last TEST if GOOD != CleanAndLicense($coPtr, $ipPtr, 2);

        #
        # Find the master and pick a random slave to start with.
        # This function call is really over-kill right now.  With
        # an N=2 license, once the master is specified, there is only
        # one choice for the slave.
        #        
        ($masterIndex, $slaveIndex) = FindMasterPickSlave($coPtr);

        if ($masterIndex == INVALID)
        {
            logInfo "Failed to find master controller";
            last TEST;
        }
        if ($slaveIndex == INVALID)
        {
            logInfo "Failed to find slave controller";
            last TEST;
        }
    
        #
        # Add a 2nd controller
        #
        logInfo "Add controller #2 - $snList[$slaveIndex]";
        last TEST if GOOD != AddController($coPtr, $slaveIndex);
          
        #
        # Find the master controller.
        #
        $masterIndex = FindMaster($coPtr);
        if ($masterIndex == INVALID)
        {
            logInfo "Failed to find master controller";
            last TEST;
        }
    
        # Label all remaining drives after adding the 2nd controller
        $ret = LabelAllDrives($coList[$masterIndex], 20, 1, 1, 0, 3);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>>>> Failed to label the drives <<<<<<<<");
            last MAIN;
        }

        #
        # Prompt the user to rescan so Bigfoot will see the server(s)
        #
        PromptUser( 3 );

        #
        # After the prompt be sure we are still connected.
        #
        last TEST if GOOD != TestNReconnectAll($coPtr);

        #
        # Find out how many servers there are.
        #
        last TEST if GOOD != GetServerCount($coList[$masterIndex], \$numServers);
        
        #
        # Create some VDisks
        #
        last TEST if GOOD != MakeSomeVDisks($coList[$masterIndex], $numServers, \$numVdisks, $vdiskStrat);

        #
        # Associate servers and VDisks
        #
        last TEST if GOOD != AssociateServersToVDisks($coList[$masterIndex], $numServers, 2);
        
        #
        # Prompt the user to start I/O
        #
        PromptUser( 9 );

        #
        # After the prompt be sure we are still connected.
        #
        last TEST if GOOD != TestNReconnectAll($coPtr);


        #
        # *** The 2 way is built and I/O is running.  Now add the 
        #     other controllers.
        #


        

        #
        # Apply a license for N=3
        #
        last TEST if GOOD != UpgradeLicense($coList[$masterIndex], 3);
        

        #
        # Add a 3rd controller
        #
        $slaveIndex = 2;
        logInfo "Add controller #3 - $snList[$slaveIndex]";
        last TEST if GOOD != AddController($coPtr, $slaveIndex);

        #
        # Find the master controller.
        #
        $masterIndex = FindMaster($coPtr);
        if ($masterIndex == INVALID)
        {
            logInfo "Failed to find master controller";
            last TEST;
        }

        #
        # Prompt the user to rescan so Bigfoot will see the server(s)
        #
        PromptUser( 3 );

        #
        # After the prompt be sure we are still connected.
        #
        last TEST if GOOD != TestNReconnectAll($coPtr);


### start temp code    
#    START:
#        last TEST if GOOD != ConnectAllControllers($coPtr, $snPtr, $ipPtr);
#
#        @coList = @$coPtr;
#        @snList = @$snPtr;
#
#        ($masterIndex, $slaveIndex) = FindMasterPickSlave($coPtr);
#        
#        $numVdisks = 30;
### end temp code


        #
        # Find out how many servers there are.  The new controller should 
        # have caused new servers to be reated.
        #
        last TEST if GOOD != GetServerCount($coList[$masterIndex], \$numServers);
        
        #
        # Create some VDisks if there aren't enough to cover the new servers.
        #
        last TEST if GOOD != MakeSomeVDisks($coList[$masterIndex], $numServers, \$numVdisks, $vdiskStrat);

        #
        # Associate servers and VDisks
        #
        last TEST if GOOD != AssociateServersToVDisks($coList[$masterIndex], $numServers, 2);

        #
        # Prompt the user to stop and restart start I/O
        #
        PromptUser( 10 );

        #
        # At this point do some other operation(s) based on the option input.
        #
        if ($option == 1)
        {
            #
            # Expand all existing VDisks.  These will NOT be initialized
            # so they should NOT be R5.
            #
            logInfo "ExpandVdisks on $coList[$masterIndex]->{HOST}";
            last TEST if GOOD != ExpandVdisks($coList[$masterIndex], 100, 1); 
        }


        #
        # Apply a licence for N=4
        #
        last TEST if GOOD != UpgradeLicense($coList[$masterIndex], 4);

        #
        # Add a 4th controller
        #
        $slaveIndex = 3;
        logInfo "Add controller #4 - $snList[$slaveIndex]";
        last TEST if GOOD != AddController($coPtr, $slaveIndex);

        #
        # Find the master controller.
        #
        $masterIndex = FindMaster($coPtr);
        if ($masterIndex == INVALID)
        {
            logInfo "Failed to find master controller";
            last TEST;
        }
        
        #
        # Prompt the user to rescan so Bigfoot will see the server(s)
        #
        PromptUser( 3 );

        #
        # After the prompt be sure we are still connected.
        #
        last TEST if GOOD != TestNReconnectAll($coPtr);

        #
        # Find out how many servers there are.  The new controller should have
        # caused new servers to be reated.
        #
        last TEST if GOOD != GetServerCount($coList[$masterIndex], \$numServers);
        
        #
        # Create some VDisks if there aren't enough to cover the new servers.
        #
        last TEST if GOOD != MakeSomeVDisks($coList[$masterIndex], $numServers, \$numVdisks, $vdiskStrat);

        #
        # Associate servers and VDisks
        #
        last TEST if GOOD != AssociateServersToVDisks($coList[$masterIndex], $numServers, 2);

        #
        # Prompt the user to stop and restart start I/O
        #
        PromptUser( 10 );
        
        
                                           
        #
        # FailOverNWay will fail if all RAIDs are not done initializing.
        # Check them all before continuing.  We know some are already done 
        # (since associations were done above) but to keep things simple
        # just check 'em all.
        #
        print("All RAID inits must be complete before starting fail-over testing...\n");
        CheckVDiskInit($coList[$masterIndex], $numVdisks);
    }
    # NOTE: 'last' does not execute the 'continue' block. 
    # Everything else does.
    continue
    {
        --$loopCount;
        if ($loopCount == 0)
        {
            last;
        }
    }

    logInfo("*** End of NWayConfigCase01 ***");

    return GOOD;
}



###############################################################################

=head2 NWayConfigCase02 function

This test case fails a pdisk while adding slave controller(s) to a multiple 
controller system.
 
Steps:
     1) Wipe system
     2) Apply license
     3) Label drives
     4) Fail a pdisk
     5) Immediately add a slave controller
     6) Verify controller added to vcg
     7) Unfail pdisk
     8) Repeat for each controller in vcg
=cut

=over 1

=item Usage:

my $rc = NWayConfigCase02( $coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, $retIn );

where:  $coPtr          Pointer to controller object array
        $snPtr          Pointer to controller serial number array
        $moxaPtr        Pointer to array of Moxa IP addresses
        $moxaChPtr      Pointer to array of Moxa channels
        $ipPtr          Pointer to array of controller IP addresses
        $retIn          Control flag - Test will be skipped if flag is not GOOD

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 The core of the test (fail a pdisk while adding a controller) will repeat for 
 each slave controller in the vcg.  The whole test will also loop 4 times.
 - Failing the pdisk via spindown and bypass
 - Resetting and not resetting the controllers after labeling pdisks
 
=item Initial Conditions:

 Do not care.
 The test will wipe the system clean and return it to a wipe clean state when 
 finished.



=back

=cut

##############################################################################
sub NWayConfigCase02
{
    trace();
    my ( $coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, $retIn ) = @_;

    use constant    RESETDURINGADDCN => 0;
    use constant    RESETBEFOREADDCN => 1;

    my $msg;
    my $msg0;
    my $masterIndex;
    my $ctlrIndex;
    my $ret = GOOD;
    my $ctlr;
    my @coList;
    my @snList;
    my $masterCtlr;
    my @pdds;
    my $ses;
    my $slot;
    my %vcgRsp;
    my $numControllers;
    my $numDataDrives;
    my $pdiskFailType;
    my $resetTime;
    my $lid;
    my $port;
                

    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ NWayConfigCase02: Fail a pdisk while adding a controller to vcg ------";
    $msg0 = "-----------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    #
    # Power cycle all controllers
    # Need this to put us at known state and get controller list and SN 
    #
    $ret = PowerCycleAllControllers($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, FALSE);
    if ( $ret != GOOD )
    {
        logInfo(">>>>>>>> Failed to power cycle all controllers <<<<<<<<");
        return ($ret);
    }

    #
    # The controller list and SN list are now valid 
    #
    @coList = @$coPtr;
    @snList = @$snPtr;
    
    #
    # check the number of controllers
    #
    $numControllers = scalar(@$coPtr);
    if ( $numControllers < 2 )
    {
        logInfo("This test case requires multiple controllers.");
        logInfo("Current configuration only has $numControllers controllers.");
        logInfo("Test case is skipped.");
        return ($retIn);
    }

    #
    # main loop, fail pdisk by spindown, repeat for bypass 
    #
    MAIN: foreach $pdiskFailType ( PDISKSPINDOWN, PDISKBYPASS )
    { 
        if ( $pdiskFailType == PDISKSPINDOWN )
        {
            logInfo("Fail pdisk via spindown.");
        }
        else 
        {
            logInfo("Fail pdisk via bypass.");
        }

        #
        # Typical sequence of adding a controller:
        # - Get license
        # - Label pdisks
        # - addcontroller
        # One of the first things addcontroller has to do is reset the controller.  If we 
        # reset the controller after labelling the pdisks and then call addcontroller,
        # addcontroller does not have to reset the controller and the controller is immediately 
        # added to the vcg.  (averages 20-30 secs)
        # 
        # The test will loop twice, one time letting addcontroller do the reset so the pdisk
        # fail will probably occur during the reset.  Other pass will reset the controller 
        # before calling addcontroller so the pdisk fail should happen during the actual
        # adding of the controller.
        #
        foreach $resetTime ( RESETDURINGADDCN, RESETBEFOREADDCN )
        {
            if ( $resetTime == RESETDURINGADDCN ) 
            {
                logInfo("Let addcontroller function reset the controller.");
            }
            else 
            {
                logInfo("Reset controllers before calling addcontroller function.");
            }

            #
            # wipe the controllers
            #
            $ret = WipeControllersClean2($coPtr);
            if ( $ret != GOOD )
            {
                logInfo(">>>>>>>> Failed to wipe the controllers <<<<<<<<");
                last MAIN;
            }
  
            #
            # Wait for each controller to reach WAIT_LICENSE state (2 min)
            #
            foreach $ctlr (@coList)
            {
                $ret = Wait4MinPowerUpState($ctlr, POWER_UP_WAIT_LICENSE, 120);
                if ( $ret != GOOD )
                {
                    logInfo(">>>>>>>> Controller failed to reach the WAIT_LICENSE ".
                            "state <<<<<<<<");
                    last MAIN;
                }
            }

            #
            # Apply license 
            #
            $ret = GimmieLicense($coPtr, $ipPtr, scalar(@$coPtr) );
            if ($ret != GOOD)
            {
                logInfo(">>>>>>>> Failed to apply license <<<<<<<<");
                last MAIN;
            }

            #
            # Find the master controller.
            #
            $masterIndex = FindMaster($coPtr);
            if ($masterIndex == INVALID)
            {
                logInfo ">>>>>>>> Failed to find master controller <<<<<<<<";
                $ret = ERROR;
                last MAIN;
            }
            $masterCtlr = $coList[$masterIndex];
        
            #
            # Label all drives before adding controllers
            #
            $ret = LabelAllDrives($masterCtlr, 10, 0, 2, 0, 0);
            if ( $ret != GOOD )
            {
                logInfo(">>>>>>>> Failed to label the drives <<<<<<<<");
                last MAIN;
            }

            #
            # Get the data pdisks
            #
            @pdds = GetDataDisks( $masterCtlr );
            if ( $pdds[0] == INVALID)
            { 
                logInfo(">>>>>>>> Failed to get the data disks <<<<<<<<");
                $ret = ERROR;
                last MAIN
            }

            #
            # Verify we have enough data drives available so that we can 
            # fail a different one for each controller.
            # If not, fall out and skip rest of test.
            #
            $numDataDrives = scalar(@pdds);
            logInfo("There are $numControllers controllers.");
            logInfo("There are $numDataDrives data drives available.");
            logInfo("The data drives are:  @pdds");
            if ( $numDataDrives < $numControllers )
            {
                logInfo("This test case requires at least as many data drives as it has controllers.");
                logInfo("Current configuration has $numControllers controllers,");
                logInfo("but ony has $numDataDrives data drives.");
                $ret = ERROR;
                last MAIN
            }

            #
            # If RESETBEFOREADDCN, reset all the controllers now.
            #
            if ( $resetTime == RESETBEFOREADDCN )
            {
                $ret = RebootControllers ( $coPtr, 60 );
                if ( $ret != GOOD )
                {
                    logInfo(">>>>>>>> Failed to reboot all controllers <<<<<<<<");
                    last MAIN;
                }

                #
                # Wait for each controller to come ready (2 min)
                #
                foreach $ctlr (@coList)
                {
                    $ret = Wait4MinPowerUpState($ctlr, POWER_UP_WAIT_LICENSE, 120);
                    if ( $ret != GOOD )
                    {
                        logInfo(">>>>>>>> Controller failed to come ready after reboot <<<<<<<<");
                        last MAIN;
                    }
                }
            }

            #
            # loop thru remaining controllers failing the pdisk and adding them
            #
            for ( $ctlrIndex = 0; $ctlrIndex < $numControllers; $ctlrIndex++)
            {
                if ($ctlrIndex == $masterIndex) { next; }

                #
                # Log which controller we are going to add 
                #
                logInfo("Failing pdisk $pdds[$ctlrIndex] while adding controller $coList[$ctlrIndex]->{HOST}");

                #
                # Get ses and slot of pdisk we are failing so we can unfail it later 
                #
                
                
                $ret = GetSesAndSlot ($masterCtlr, $pdds[$ctlrIndex], \$ses, \$slot, \$lid, \$port);
                if ( $ret != GOOD )
                {
                    logInfo(">>>>>>>> Failed to get SES and slot info for pdisk  <<<<<<<<");
                    last MAIN;
                }

                #
                # log fail to the controllers
                #
                CtlrLogTextAll($coPtr, "NWayConfigCase02: failing pdisk $pdds[$ctlrIndex] ".
                                       "while adding controller $coList[$ctlrIndex]->{HOST}" );
    
                #
                # Fail pdisk by appropriate method
                #
                $ret = FailPdiskNoWait( $masterCtlr, $pdds[$ctlrIndex] , $pdiskFailType);
                if ( $ret != GOOD )
                {
                    logInfo(">>>>>>>> Failed to fail the pdisk <<<<<<<<");
                    last MAIN;
                }

                #
                # Add the next controller
                #
                $ret = AddController ($coPtr, $ctlrIndex);
                if ( $ret != GOOD )
                {
                    logInfo(">>>>>>>> Failed to add controller <<<<<<<<");
                    last MAIN;
                }

                #
                # Verify controller is in VCGinfo and is operational 
                #
                $ret = IsThisControllerGood($coPtr,$ctlrIndex);
                if ( $ret != GOOD )
                {
                    logInfo(">>>>>>>> Failed to verify controller operational <<<<<<<<");
                    last MAIN; 
                }
                     
                #
                # Find the master controller.
                #
                $masterIndex = FindMaster($coPtr);
                if ($masterIndex == INVALID)
                {
                    logInfo ">>>>>>>> Failed to find master controller <<<<<<<<";
                    $ret = ERROR;
                    last MAIN;
                }
                $masterCtlr = $coList[$masterIndex];
                 
                #
                # Unfail pdisk
                #
                $ret = UnfailPdisk($masterCtlr, $pdds[$ctlrIndex], $ses, $slot, NORELABEL, $lid, $port);
                if ( $ret != GOOD )
                {
                    logInfo(">>>>>>>> Failed to unfail pdisk <<<<<<<<");
                    last MAIN; 

                }

            }

        }   
            
    }

    #
    # If something failed, exit with error
    #
    if ( $ret != GOOD )
    {
        return $ret;
    }

    #
    # wipe the controllers
    #
    $ret = WipeControllersClean2($coPtr);
    if ( $ret != GOOD )
    {
        logInfo(">>>>>>>> Failed to wipe the controllers after test <<<<<<<<");
        return $ret;
    }

    #
    # Wait for each controller to reach WAIT_LICENSE state (2 min)
    #
    foreach $ctlr (@coList)
    {
        $ret = Wait4MinPowerUpState($ctlr, POWER_UP_WAIT_LICENSE, 120);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>>>> Controller failed to reach the WAIT_LICENSE ".
                    "state after test <<<<<<<<");
            return $ret;
        }
    }

    $msg = "---------------------------- End of NWayConfigCase02 ------------------------------";
    $msg0 = "-----------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    return GOOD;

}





##############################################################################
#
# Name:     NWayConfigCaseTemp
#
# Inputs:   $coPtr          Pointer to controller object array
#           $snPtr          Pointer to controller serial number array
#           $moxaPtr        Pointer to array of Moxa IP addresses
#           $moxaChPtr      Pointer to array of Moxa channels
#
# Outputs:  GOOD or ERROR
#
# Comments: Used for test and debug - NOT FOR PRIMETIME
#           
#           
#
##############################################################################
sub NWayConfigCaseTemp
{
    trace();
    
    my ($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, $vdiskStrat) = @_;

    my @cnUsed = (0, 0, 0, 0);      # Flag for controller added to group
    my $loopCount = 1;
    my $totalLoops = 1;
    my $msg ="";
    my $msg0 = "";
    my $numServers = 0;
    my $numVdisks = 0;
    my $masterIndex;
    my $slaveIndex;
    my $server = 0;
    my $lun = 0;
    my $vdisk = 0;
    my @coList;         # Controller object list
    my @snList;         # Controller SN list
    my $numCtlrs;
    my $ctlr;
    my $master;
    my %rsp;
    my $ret;


    $msg  = "------ Test Case TEMP: This is only a test -----------------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);



    # Set up a loop to do some stuff
    TEST: while ($loopCount)
    {
        logInfo "*******************************************\n";
        logInfo "*  Test loop ".($totalLoops-$loopCount+1)." of $totalLoops";
        logInfo "*******************************************\n";   

        #
        # Connect all controllers
        #
        last TEST if GOOD != ConnectAllControllers($coPtr, $snPtr, $ipPtr);
        
        #
        # Clean all controllers.  License for N=4
        #
        last TEST if GOOD != CleanAndLicense($coPtr, $ipPtr, 4);
        
        $loopCount--;
    }
}    

###############################################################################



1;   # we need this for a PM

##############################################################################
#
# $Log$
# Revision 1.1  2005/05/04 18:53:52  RysavyR
# Initial revision
#
# Revision 1.12  2004/08/04 15:29:48  MenningC
# tbolt00000000: updates to allow unbypass in fabric, reviewed by Al
#
# Revision 1.11  2004/04/30 21:00:00  KohlmeyerA
# Tbolt00000000 - Made changes to handle the possiblity of a different controller becoming master when a controller is added to vcg.  Reviewed by Craig
#
# Revision 1.10  2004/04/12 21:08:45  KohlmeyerA
# Tbolt00000000 - Added NWayConfigCase02:  Fail pdisk while adding controller to vcg.  Reviewed by Craig
#
# Revision 1.9  2004/02/19 23:52:25  SchibillaM
# TBolt00000000: Separate NWay algorithms and support functions into separate
# files.  Move max controllers constant into Constants.pm.  Minor changes to
# PromptUser().
#
# Revision 1.8  2004/02/16 19:34:22  SchibillaM
# TBolt00000000: Add comments, general clean up.
#
# Revision 1.7  2004/02/13 18:18:49  SchibillaM
# TBolt00000000: Changes to Case00 and Case01 based on suggestions
# from Chris.
#
# Revision 1.6  2004/02/11 20:53:04  SchibillaM
# TBolt00000000: Additional error checking on CCBE calls. Check that RAIDs
# have completed initialization (pre-condition for FailOverNWay).  Add option
# to expand RAIDs without initializing them in Case01.
#
# Revision 1.5  2004/02/10 21:08:02  SchibillaM
# TBolt00000000: NWayConfigCase00 and Case01 complete.
#
# Revision 1.4  2004/02/06 20:37:52  SchibillaM
# TBolt00000000: NWayConfigCase00 is close - changed to smart connection
# function after power cycle.  Fixed server associate by checking for VDisk init
# complete before associate.
#
# Revision 1.3  2004/02/05 21:45:09  SchibillaM
# TBolt00000000: NWayConfigCase00 works except for server associate.
#
# Revision 1.2  2004/02/03 21:26:10  SchibillaM
# TBolt00000000: NWay configuration tests 0 and 1 complete.
#
# Revision 1.1  2004/02/02 22:26:52  SchibillaM
# TBolt00000000: Starting point for NWay configuration scripts.
#
#
#
##############################################################################
