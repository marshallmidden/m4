#! /usr/bin/perl s
# $Header$
##############################################################################
# File name:  TestLibs::Configure
#
# Desc: A set of library functions for configuration of the XIOtech SAN device.
#
# Date: 07/26/2002
#
# Original Author:  Jeff Werning
#
# Last modified by  $Author: neal_eiden $
# Modified date     $Date: 2007-06-21 15:15:43 -0500 (Thu, 21 Jun 2007) $
#
#   It is expected that the user will write a perl script that calls 
#   these.  XTC.pl will be able to lanch these functions
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::Configuration - Perl Tests to Configure XIOtech Storage Devices

$Id: Configure.pm 25987 2007-06-21 20:15:43Z neal_eiden $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

This document describes usuage of the Perl Scripts to Configure XIOtech Controllers

=head1 DESCRIPTION

Test Scripts Available
    WipeCleanVCG
    VcgLicense

=cut

#                         
# - what I am
#

package TestLibs::Configure;

#
# - other modules used
#

use warnings;
use lib "../CCBE";
use lib 'TestLibs';
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
#use XIOTech::logMgr;
use XIOtech::sanscript (port => 10000);
use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :CCBE :XSSA);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::IntegXMCLib;
use TestLibs::SCSI;
use TestLibs::iscsi;
use TestLibs::VlinksLibs;
use TestLibs::WrtCacheSupport;
use Dumpvalue;

#
# - perl compiler/interpreter flags 'n' things
#

#use strict;

my $dumper = new Dumpvalue;

#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    #
    # set the version for version checking
    #
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      &AssociateCfgVdisks
                      &AssociateCfgVlinks
                      &BFDump
                      &BuildVCG
                      &CheckVdiskInit
                      &CreateCfgServers
                      &CreateCfgVdisks
                      &CreateCfgVlinks
                      &ConnectMasterCCBE
                      &convertConfigZonesToZoneArray
                      &DefineDiskGroup
                      &DeleteWorkports
                      &DeleteVdAll
                      &DeleteVBAll
                      &DisAssocAll
                      &FormatPDisk
                      &FormatAllPDisks
                      &GetCcbeRaidType
                      &ICtest
                      &LabelCfgDrives
                      &CallPowerCycle
                      &PrepareServersDisks
                      &PrepareWindowsDisks
                      &ServerCalls
                      &SetGlobalCache
                      &SetUpConfig
                      &showzoningconfig
                      &SwitchCalls
                      &WaitFormatComplete
                      &WipeCleanVCG
                      &VcgLicense
                      &UnConfig
                      &zoneSwitchesInGroup
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 25987 $);
}
    our @EXPORT_OK;

########################################################################
### Function name: WipeCleanVCG
###
### Purpose: wipe clean all Bigfoot controllers in a given Group
##
## INPUT:    NONE
## OUTPUT:   Return value from the called library function
#######################################################################

sub WipeCleanVCG
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $controllerIP;
    my $wipeCleanArgs = "";

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    #
    # Collect controller connections
    #
    foreach $controllerIP (@{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}})
    {
        $wipeCleanArgs = $wipeCleanArgs . "$controllerIP -l -s ";
        TestLibs::Logging::debug ("Wipe Clean Args: $wipeCleanArgs");
    }

    #
    # Build and execute the system call for Wipe CLean
    #
    my @args = ('perl wipe_clean.pl ' . "$wipeCleanArgs");
    TestLibs::Logging::logInfo ("Wipe Clean: @args");
    my $systemReturn = system(@args);

    if ($systemReturn == 0)
    {
        TestLibs::Logging::logInfo ("System Call Successfull: @args");
    }
    else
    {
        my $shiftRC = $systemReturn/256;
        TestLibs::Logging::logError ("Failed to run Wipe_Clean.pl => Error Code:$shiftRC");
        print "\n";
        return ERROR;
    }

    return GOOD;
}

########################################################################
### Function name: BFDump
###
### Purpose: BFDump all Bigfoot controllers in a given Group
##
## INPUT:    NONE
## OUTPUT:   Return value from the called library function
#######################################################################

sub BFDump
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $returnValue;
    my $controllerIP;
    my @controllerList;
    my $bfDumpArgs = "";

    my $testGroup    = ${$xtcDataPtr->{CURTESTGROUP}};
    my $testRecord   = ${$xtcDataPtr->{CURTESTRECORD}};
    my $recordGroup  = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][0];
    my $testIndex    = ${$xtcDataPtr->{TESTS}->{RECORD}}[$testRecord][2];
    my %testParms;

    # Can only get the testParms if they exists
    if (exists $xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex])
    {
        %testParms = ${$xtcDataPtr->{TESTS}->{$recordGroup}->{'testcase'}->{'testsParms'}[$testIndex]};
    }

    # Collect controller connections
    foreach $controllerIP (@{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}})
    {
        $bfDumpArgs = $bfDumpArgs . "$controllerIP ";
        TestLibs::Logging::debug ("BFDump Args: $bfDumpArgs");
    }

    if ($testParms{"bfdumpdir"})
    {
        $ENV{BFDUMP} = $testParms{"bfdumpdir"};
    }
    
    my @args = ('Perl BFDump.pl ' . "$bfDumpArgs");
    TestLibs::Logging::logInfo ("BFDump: @args");
    my $systemReturn = system(@args);

    if ($systemReturn == 0)
    {
        TestLibs::Logging::logInfo ("System Call Successfull: @args");
    }
    else
    {
        my $shiftRC = $systemReturn/256;
        TestLibs::Logging::logError ("Failed to run BFDump.pl => Error Code:$shiftRC");
        print "\n";
        return ERROR;
    }

    return GOOD;
}
########################################################################
### Function name: CCBCLs
###
### Purpose: Connect to all Bigfoot controllers in a given Group
##
## INPUT:    NONE
## OUTPUT:   Return value from the called library function
#######################################################################

sub CCBCLs
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $returnValue;
    my $controllerIP;
    my @args;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};
    
    # CCBE connections
    foreach $controllerIP (@{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}})
    {
        # Start CCBcl on the Windows system
        if (${$xtcDataPtr->{OSWIN}})
        {
            @args = ('start "CCBcl via XTC" /d..\ccbe ..\CCBE\CCBCL.pl ' . "$controllerIP ");
        }
        else  # Assume it is a Unix machine
        {
#            @args = ('xterm -T "CCBcl via XTC" -geometry 50 -bg black -fg green -e ../CCBE/CCBCL.pl ' . "$controllerIP ");
            @args = ('gnome-terminal --geometry=100x50 --title="CCBcl via XTC" --working-directory="../CCBE" -x ./CCBcl.pl ' . "$controllerIP ");
        }

        TestLibs::Logging::logInfo ("CCBCL: @args");
        my $systemReturn = system(@args);
        if ($systemReturn == 0)
        {
            TestLibs::Logging::logInfo ("System Call Successfull: @args");
        }
        else
        {
            my $shiftRC = $systemReturn/256;
            TestLibs::Logging::logError ("Failed to run CCBCL.pl => Error Code:$shiftRC");
            print "\n";
            return ERROR;
        }
        TestLibs::Logging::debug ("CCBCL Args: @args");
    }

    return GOOD;
}


########################################################################
### Function name: VcgLicense
###
### Purpose: Apply a VCG license if needed
##
## INPUT:    CCBE object, VCG Serial #, Array of serial # in the VCG
## OUTPUT:   Return value from the called library function
#######################################################################

sub VcgLicense
{
    trace();                        # This allows function tracability

    my ($ccbeConnection, $vcgID, $numControllers) = @_;
    
    TestLibs::Logging::logInfo ("VCG Apply License VCG ID:$vcgID Number of Controllers:$numControllers");

    my %licenseRsp = $ccbeConnection->vcgApplyLicense( $vcgID, $numControllers);

# Debug
#$dumper->dumpValues(%licenseRsp);

    if ( ! %licenseRsp  )
    {
        TestLibs::Logging::logError ("Apply License Command Failed via CCBE");
    }
    if ($licenseRsp{STATUS} != PI_GOOD)
    {
        TestLibs::Logging::logError ("Failed to Apply License to ID:$vcgID");
    }

}

########################################################################
### Function name: GetCcbeRaidType
###
### Purpose: Convert between Raid Indecies
##
## INPUT:    XMC RAID Type (0,1,5,10)
## OUTPUT:   CCBE RAID Type (1,2,3,4)
#######################################################################

sub GetCcbeRaidType
{
    trace();                        # This allows function tracability

    my ($XMCRaidType) = @_;

    if ($XMCRaidType == 0)  { return (1); }
    if ($XMCRaidType == 1)  { return (2); }
    if ($XMCRaidType == 5)  { return (3); }
    if ($XMCRaidType == 10) { return (4); }

    return INVALID;
    
}


##############################################################################
#
#          Name: PrepareWindowsDisks 
#
#        Inputs: server name or IP address of server to prepare
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Partitions and formats all unpartitioned drives on the 
#                specified server.  Note: This required that the controller
#                server program be installed on the server.
#
##############################################################################
sub PrepareWindowsDisks
{
    my $server = $_[0];     # The server name or IP to prepare.
    
    logInfo ("Preparing Disks on Server:$server"); 

    my $systemReturn = system ".\\common\\windows\\controller\\controller.exe /preparewindowsdisks $server";

    #
    # Get the correct return code by dividing by 256.
    #
    return ($systemReturn / 256); 
}

#############################################################################################
#
#           Name:  CCBE Integration test script
#
#         Inputs:  Array of IP Addresses, Array of Server WWNs
#
#        Outputs:  A small test file for evaluating the CCBE script library
#
#    Description:  Copyright 2002 XIOtech, A Seagate Company
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub ICtest
{
    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    print "testGroup:$testGroup\n";

    # Grab the arrays

    my @ipList = @{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}};
    my @wwn    = @{$xtcDataPtr->{SERVERS}->{$testGroup}->{'windows'}->{'serverWWN'}};

    my @iscsiTargetId    = @{$xtcDataPtr->{ISCSIINTERFACE}->{$testGroup}->{'ethernet'}->{'iscsiTargetId'}};
    my @iscsiParamId     = @{$xtcDataPtr->{ISCSIINTERFACE}->{$testGroup}->{'ethernet'}->{'iscsiParamId'}};
    my @iscsiTargetParam = @{$xtcDataPtr->{ISCSIINTERFACE}->{$testGroup}->{'ethernet'}->{'iscsiTargetParam'}};

    my @chapOption      = @{$xtcDataPtr->{ISCSICHAP}->{$testGroup}->{'chap'}->{'chapOption'}};
    my @chapTargetId    = @{$xtcDataPtr->{ISCSICHAP}->{$testGroup}->{'chap'}->{'chapTargetId'}};
    my @chapServerName  = @{$xtcDataPtr->{ISCSICHAP}->{$testGroup}->{'chap'}->{'chapServerName'}};
    my @chapSecret1     = @{$xtcDataPtr->{ISCSICHAP}->{$testGroup}->{'chap'}->{'chapSecret1'}};
    my @chapSecret2     = @{$xtcDataPtr->{ISCSICHAP}->{$testGroup}->{'chap'}->{'chapSecret2'}};

    my @coList;       # an array of connected objects
    my $mirrortype = 1;

    #
    # - some global variables/constant
    #

    my $currentConnection = -1;
    my $currentIP = "";
    my $currentPort = CCB_PORT;
    my $currentMgr;
    my $numNextConnection = 0;
    my %connections;

    my $i;

    my $ctlr1;        # master's IP
    my $ctlr2;        # slave's IP address

    my $masterSN;     # master's serial number
    my $slaveSN;      # slave's serial number
    my $msg;

    my $ret;          # a returned value
    my $obj1;
    my $option;
    my $flag = 1;
    my $master;
    my $ctlr;

    print "==================================================================================\n";
    $msg = "\n Using controller IP addresses: \n";
    for ( $i = 0; $i < scalar(@ipList); $i++ )
    {
        if ( ($i%4) == 0 )
        {
            $msg .= "\n";
        }
        $msg .= "   $ipList[$i]     ";
    }
    logInfo($msg);
    
    $msg = "\n\n Using server WWNs:\n";
    for ( $i = 0; $i < scalar(@wwn); $i++ )
    {
        if ( ($i%4) == 0 )
        {
            $msg .= "\n\t";
        }
        
        $msg .= sprintf("   %s ", $wwn[$i] );
        $msg .= "\t";
    }
    logInfo($msg);

    my $ans = IcTestMenu();


    if ( $ans < 0  )
    {
        return ERROR;
    }

    if ( $ans > 99 )
    {
        return GOOD;
    }

    $option = $ans;

    print "\n";


    # establish controller connections
    for ( $i = 0; $i < scalar(@ipList); $i++ )
    {
        #print " new on $ipList[$i] is ";

        $obj1 = XIOTech::cmdMgr->new(\*STDOUT);
        $coList[$i] = $obj1;

        #print "    $coList[$i] \n";

        logInfo("logging in to here $ipList[$i]");

        my $retry = 0;
        
        do 
        {
            debug("Attempting login " . ($retry + 1) . " of 3");
            $ret =  $obj1->login( $ipList[$i], CCB_PORT);       # connect to controller
            $retry += 1;
        }
        until ($retry == 3 || $ret);
        
        if ( ! $ret  )
        {
            logError(">>>>>>>> Failed to connect to $ipList[$i]  <<<<<<<<");
            return (ERROR);
        }

        debug("login complete, setting timeout");

        #---Set TimeOut
        $obj1->{TIMEOUT} = CCBETIMEOUT;

        # get the power up state to check if a license has been applied
        
        GetPowerUpState($obj1);
    }

    if ( $option == 80 )             # this is a SPECIAL case
    {
        $ret = ViewLicenseState( \@coList );   
        return GOOD;
    }

    GimmieLicense( \@coList, \@ipList, 0);      #   Verify/set up licenses

    logInfo("Starting up");

    # note: we pass objects around to the various function to
    # identify the controller we want to use

    $ctlr = $coList[0];

    #
    # Configuration of ISCSI target parameters
    #

    for ( my $k = 0; $k < 4; $k++ )
    {
        # Validate port and check if any ISCSI targets are available

        &TestLibs::iscsi::ValidateTargetType ( $ctlr, $k, \$flag );
    
        if ($flag == 0) #If a ISCSI target Found then configure paramters as given in station file
        {
            $ret = &TestLibs::iscsi::ConfigiSCSITargetParam( $ctlr, \@iscsiTargetId, \@iscsiParamId, \@iscsiTargetParam);

            if ( $ret == ERROR )
            {
                logError(">>>>>>>> Failed to configure iscsi target params. <<<<<<<<");
            }
        }
    }

    #
    # Configuration of ISCSI CHAP Information
    #

    for ( $k = 0; $k < 4; $k++ )
    {
        # Validate port and check if any ISCSI targets are available

        &TestLibs::iscsi::ValidateTargetType ( $ctlr, $k, \$flag );
    
        if ($flag == 0) #If a ISCSI target Found then configure CHAP information as given in station file
        {
            $ret = &TestLibs::iscsi::ConfigiSCSIChapInfo(\@coList, \@chapOption, 
                                                         \@chapTargetId, \@chapServerName, 
                                                         \@chapSecret1, \@chapSecret2);
    
            if ( $ret == ERROR )
            {
                logError(">>>>>>>> Failed to configure iscsi CHAP Information. <<<<<<<<");
            }
            else
            {
                last;
            }
        }
    }

    $ret = BasicConfig( \@coList,  $option, \@ipList, \@wwn,  0, $mirrortype );

    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to configure system. <<<<<<<<");
    }

    # terminate controller connections
    for ( $i = 0; $i < scalar(@coList); $i++ )
    {
        if ( $coList[$i] )
        {
            $coList[$i]->logout();
        }
    }

    return GOOD;
}

=head1 NAME

NAME OF THE MODULE

ICtest

$Id: Configure.pm 25987 2007-06-21 20:15:43Z neal_eiden $

=head1 SUPPORTED PLATFORMS

IF IT DOES NOT SUPPORT LINUX (MOXA FOR EXAMPLE), PLEASE STATE SO

=begin html

<UL>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

 ICtest.pl <station id>
 ICtest.pl 48
 ICtest.pl 20

=head1 DESCRIPTION

CCBE Integration test script

 A small test file for evaluating the CCBE script library

=over 4

=item OPTIONS

  1) 2 way for 14 drive bay (drives alternate between servers) 
  2) 2 way for 22 drive bay (drives alternate between servers) 
  3) san links  [using a shared drive bay] RAID 10 drives
  4) (incomplete)
  5) (2 way incomplete)
  6) 1 way  (needs lots of disks)
  7) 1 way
  8) wipe clean both controllers
  9) wipe clean master controller only
 10) 2 way for 22 drive bay (SIDs based upon WWNs)
 11) san links  [using a shared drive bay] RAID 5 drives
 12) 1 way for 14 drive bay
 13) 2 way for 14 drive bay all raid 5
 14) 2 way for 14 drive bay all raid 10

 70) 2 way for 22 drive bay, more vdisks (SIDs based upon WWNs)
 71) 2 way with few, small vdisks (SIDs based upon WWNs)
 72) 1 way with few, small vdisks (SIDs based upon WWNs)

 21) enable write caching
 22) disable (global) write caching
 28) enhanced wipe clean ALL controllers

 30) view configuration
;
 50) Test Menu
 51) Single task Menu
 52) Custom Configuration

 80) View License State

 90) Suicide prevention

 98), 99) Debug of the day.

 200) Exit

=head1 AUTHOR

 Craig_Menning@xiotech.com

=cut

=head2 PrepCCBE function

Function to prepare conncetions to a VCG via the CCBE.



=cut

=over 1

=item Usage:

 my $rc = FailOver( the following list of parameters );
 
 where,
        $ptrVcgGroups  
        $curTestGroup
        $curTestArgument
        $ptrBigfootIP
        $ptrBigfootSN
        $ptrBigfootName
        $ptrBigfootGroup
        $ptrPowerName
        $ptrPowerIP
        $ptrPowerChannel
        $ptrTestParmHash

       

=item Returns:

       $rc GOOD  although this will probably change.


=item Description:
 
        For each controller...disconnect from the XMC
        Build needed data structures for upcoming calls. Also connect
            to each controller (CCBE style).
        Call FailOverLoop function.
        Disconnect from each controller (CCBE style).
        Puase for a random number of seconds.


=back

=cut


#######################################################################
### Function name: FormatPDisk
###
### Purpose: Send SCSI Format command to PDisk via CCBE
##
##   INPUT: Controller Obj, PDisk ID
##   
## Outputs: GOOD or ERROR 
#######################################################################

sub FormatPDisk
{
    trace();                        # This allows function tracability

    my ($controller, $pid) = @_;

# Local Variables
    my $wwnHi;
    my $wwnLo;
    my $lun;
    my $returnValue;
    my %response;

    $returnValue = TestLibs::SCSI::getPIDInfo ($controller, $pid, \$wwnHi, \$wwnLo, \$lun);
    if ($returnValue == ERROR)
    {
        TestLibs::Logging::logWarning ("Failed to get PDisk Info for PID:$pid ");
        return ERROR;
    }

    TestLibs::Logging::logInfo("Format Physical Drive:$pid");

    ($returnValue, %response) = TestLibs::SCSI::SCSIFormat ($controller, $wwnHi, $wwnLo, $lun);
#$dumper->dumpValues(%response);

    if ($returnValue == ERROR)
    {
        TestLibs::Logging::logWarning ("Failed to complete SCSI Format command");
        TestLibs::SCSI::PrintResponse (%response);
        return ERROR;
    }

    return GOOD;
}

#######################################################################
### Function name: WaitFormatComplete
###
### Purpose: Send SCSI TUR command to PDisk and wait for format complete
##
##   INPUT: Controller Obj, PDisk ID
##   
## Outputs: GOOD or ERROR 
#######################################################################

sub WaitFormatComplete
{
    trace();                        # This allows function tracability

    my ($controller, $pid) = @_;

    # Local Variables
    my $wwnHi;
    my $wwnLo;
    my $lun;
    my $returnValue;
    my %response;
    my $i;

    $returnValue = TestLibs::SCSI::getPIDInfo ($controller, $pid, \$wwnHi, \$wwnLo, \$lun);
    if ($returnValue == ERROR)
    {
        TestLibs::Logging::logWarning ("Failed to get PDisk Info for PID:$pid ");
        return ERROR;
    }

    $returnValue = ERROR;
    $i = 1;

    while ($returnValue != GOOD)
    {
        ($returnValue, %response) = TestLibs::SCSI::SCSITUR ($controller, $wwnHi, $wwnLo, $lun);
        print "Waiting for Drive:$pid to complete format, check # $i           \r";
        sleep (20);     # Wait a little while, format can take a long time
        # need to add % complete from the request sense data
        $i++;
#$dumper->dumpValues(%response);
    }
    print "                                                             \n";

    if ($returnValue == ERROR)
    {
        TestLibs::Logging::logWarning ("Failed to complete SCSI TUR command");
        return ERROR;
    }

    return GOOD;
}

#######################################################################
### Function name: FormatAllPDisks
###
### Purpose: Send SCSI Format command to PDisk via CCBE
##
##   INPUT: Controller IP Address
##   
## Outputs: GOOD or ERROR 
#######################################################################

sub FormatAllPDisks
{
    trace();                        # This allows function tracability

    my ($ccbeConnection) = @_;

    # Local Variables
    my $returnValue;
    my %drives;

    # Rescan here to get the latest info 
    $returnValue = RescanBE( $ccbeConnection );          
    if( $returnValue == ERROR )
    {
        TestLibs::Logging::logWarning("Failed to rescan drives.");
        return (ERROR);
    }

    TestLibs::Logging::logInfo("Format All Physical Drives");

    # Get list of PDisks
    %drives = $ccbeConnection->physicalDisks();  # get list of drives present

    if( ! %drives || $drives{STATUS} != PI_GOOD )
    {
        # Got an error, report it and bail
        TestLibs::Logging::logWarning ("Failed to get physical disk info.");
        return (ERROR);
    }
    
#$dumper->dumpValues(%drives);

    # Do the low level formats, Immediate return on SCSI cmd
    for (my $i = 0; $i < $drives{COUNT}; $i++)     # for each drive
    {
        $returnValue = FormatPDisk($ccbeConnection, $drives{PDISKS}[$i]{PD_PID});
        if ($returnValue != GOOD)
        {
            return $returnValue;
        }
    }

    # Wait for Formats to complete
    for (my $i = 0; $i < $drives{COUNT}; $i++)     # for each drive
    {
        $returnValue = WaitFormatComplete($ccbeConnection, $drives{PDISKS}[$i]{PD_PID});
        if ($returnValue != GOOD)
        {
            return $returnValue;
        }
    }


    return GOOD;
}

#######################################################################
### Function name: CreateCfgVdisks
###
### Purpose: Create VDisk set up in the Config Files
##
## INPUT:    XTC Data Structure Pointer 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub CreateCfgVdisks
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;          
    my $ccbeConnection;
    my $indexDrive;
    my %vdisk;
    my $vcgReturn;
    my @driveList;
    my $driveListPtr;
    my $alreadyHaveIt = FALSE;
    my $returnValue;
    my $ccbeVdiskID;
    my $diskGroupID;
    my $serverWorkset;
    my $serverRecord;
    my $master;
    my @ctrl;
    my @groupCCBE;
    my $ICONRDY = BAD;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Create VDisks Routine");

    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        $ICONRDY = BAD;
        TestLibs::Logging::logInfo("Failed to connect to ICON, using CCBE interface");
        }
    }
                
    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@groupCCBE);
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }


    #
    # find the master controller
    #
    $master = FindMaster( \@groupCCBE );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }
    $ccbeConnection = $groupCCBE[$master];

            
    $indexDrive = 0;

    #
    # Create VDisks
    #
    foreach my $vdiskName (@{$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskName'}})
    {
        #
        # Check to see if this is an assoiciation only, the VDisk name will be 'dnc' do not create
        #
        if ($vdiskName eq "dnc") {next;}

        #
        # Get the current VDisk Record
        #
        my $vdiskDiskGroup = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskDiskGroup'}}[$indexDrive];
        my $vdiskSize      = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskSize'}}[$indexDrive];
        my $vdiskRAID      = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskRAID'}}[$indexDrive];
        my $vdiskID        = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskID'}}[$indexDrive];
        my $server         = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskServer'}}[$indexDrive];
        my $vdiskVBlock    = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskVBlock'}}[$indexDrive];
        my $vdiskCache     = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskCache'}}[$indexDrive];

        #
        # Find the corresponding Diskgroup ID
        #
        my $indexDiskGroup = 0;
        foreach my $diskGroupName (@{$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'diskGroupName'}})
        {
            if ($vdiskDiskGroup eq $diskGroupName)
            {
                $diskGroupID = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'diskGroupID'}}[$indexDiskGroup];
                last; #Exit with the current $diskGroupID
            }
            $indexDiskGroup++;

            if ($indexDiskGroup == scalar (@{$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'diskGroupID'}}))
            { 
                logWarning(" Could not find the Disk Group ID for Disk Group:$vdiskDiskGroup");
                return ERROR;
            }
        }

        #
        # Search for the corresponding Server Workset by matching names
        # Default to workset 0 if the server name is 'none' - the VDisk is created but won't be mapped to anything
        #
        $serverWorkset = 0;
        foreach $serverRecord (@{$xtcDataPtr->{SERVERS}->{RECORD}->{$testGroup}})
        {
            if ($server eq ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverName'}}[$$serverRecord[1]])
            {
                $serverWorkset = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverWorkset'}}[$$serverRecord[1]];
                last; #Exit with the current $serverWorkset
            }
        }

        #
        # Create the VDisk
        #
        if ($ICONRDY eq GOOD)
        {
            TestLibs::Logging::logInfo ("Creating VDisk Name:$vdiskName Size:$vdiskSize RAID:$vdiskRAID ID:$vdiskID " . 
                                        "Workset:$serverWorkset VBlock:$vdiskVBlock DiskGroup:$diskGroupID");

            $returnValue = TestLibs::IntegXMCLib::VDCreate($vdiskName,
                     $vdiskSize, $vdiskID, $vdiskRAID,
                     $serverWorkset, $vdiskVBlock, $diskGroupID);

            if ($returnValue != GOOD)
            {
                TestLibs::Logging::logError ("Failed to Create the VDisk RAID:$vdiskRAID Name:$vdiskName Size:$vdiskSize"); 
            }
        }
        else
        {
            #
            # We can't all agree on how to number the raid types, so need to convert here
            #
            my $vdiskRType = TestLibs::Configure::GetCcbeRaidType($vdiskRAID);

            $driveListPtr = "ALL";      # Default option to use redundant disks

            if ($vdiskRType == 1)       # If RAID 0
            {
                #
                # Get the valid drive types for this VDisk, since the CCB does not do it for us
                #
                if ($alreadyHaveIt == FALSE)
                {
                    #
                    # Use unsafe drives if RAID 0
                    #
                    @driveList = TestLibs::IntegCCBELib::GetTheseDisks ($ccbeConnection, CCBEUNSAFETYPE);
                    if (($driveList[0] eq INVALID) || scalar(@driveList < 1))   # No valid drive type found 
                    {
                        logError("Fail to find any drives of type:UNSafe");
                    }
                    $alreadyHaveIt = TRUE;
                }
                $driveListPtr = \@driveList;
            }

            # Play nice with the XSSA
            # Get the VDisk ID within a VBlock, i.e. (VDiskID modulus VDiskCount)
            #
            $ccbeVdiskID = $vdiskID + ($vdiskVBlock * XSSAVDISKCOUNT);
            #print "ccbeVdiskID:$ccbeVdiskID  vdiskID:$vdiskID vdiskVBlock:$vdiskVBlock " . XSSAVDISKCOUNT . "\n";
            TestLibs::Logging::logInfo ("Creating VDisk Name:$vdiskName Size:$vdiskSize RAID:$vdiskRAID ID:$vdiskID " . 
                                        "VBlock:$vdiskVBlock CCBE VID:$ccbeVdiskID");

            #
            # Create the VDisk
            #
            $returnValue = TestLibs::IntegCCBELib::CreateSingleVdisk ($ccbeConnection,
            $vdiskName, $vdiskSize, $vdiskRType,
            0, 0, 0, $driveListPtr, $ccbeVdiskID);
    
            if ($returnValue == INVALID)
            {
                TestLibs::Logging::logError ("Failed to Create the VDisk RAID:$vdiskRAID Name:$vdiskName Size:$vdiskSize VID:$ccbeVdiskID"); 
            }
            delay(5);       # Give the configuration time for propigation
        }

        #
        # Set vdisk write Cache
        #
        # Only use CCBE interface.  SANScript support does not work
        # Leaving as a place holder for future ICON scripting effort
        if ($vdiskCache eq "enable")
        {
        my $rc = WrtCacheControlVdisksSingle( $ccbeConnection, 1, $vdiskID );
 
#                            unless (XMCGOOD == XIOtech::sanscript::vdiskBufferOn($vdiskID[$indexDrive]))
#                            {TestLibs::Logging::logError ("Failed to Enable VDsisk Cache VID:$vdiskID[$indexDrive]")}; 
        }
        else
        {
#                            unless (XMCGOOD == XIOtech::sanscript::vdiskBufferOff($vdiskID[$indexDrive]))
#                            {TestLibs::Logging::logError ("Failed to Disable VDsisk Cache VID:$vdiskID[$indexDrive]")}; 
        }
    $indexDrive++;
    }   # end of for loop to create VDisks


    if ($ICONRDY ne "GOOD")
    {
        #
        # Check the VDisk state
        #
        $vcgReturn = TestLibs::Validate::CheckVdiskState($ccbeConnection);       
        if ($vcgReturn != GOOD)
        {
            TestLibs::Logging::logError ("VDisks failed state check");
        }
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeConnection);  # Disconnect from Master CCBE
    }
    else
    {
        #
        # Disconnect from the VCG.
        #                
        if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
        }  
        
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeConnection);  # Disconnect from Master CCBE
                            
    }                                                              

    return GOOD;
}


#######################################################################
### Function name: CreateCfgVlinks
###
### Purpose: Create VLinks set up in the Config Files
##
## INPUT:    see below 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub CreateCfgVlinks
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $indexLink;
    my $ccbeConnection;
    my $vlinkLun;   
    my $vlinkServer;
    my $serverCluster;
    my $returnValue;
    my $ccbeRemoteVdiskID;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Create VLinks Routine");

    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        logInfo("Vlink Creation is not yet supported via the XMC using the CCBE instead");
    }
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);

    # Create VLinks
    $indexLink = 0;
    foreach my $virLinkName (@{$xtcDataPtr->{VDISKS}->{$testGroup}->{'vlink'}->{'vlinkName'}})
    {
        # Check to see if this is an assoiciation only, the Vlink name will be 'dnc' do not create
        if ($virLinkName eq "dnc") {next;}

        # Get the current VLink Record
        my $vlinkVBlock         = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vlink'}->{'vlinkVBlock'}}[$indexLink];
        my $vlinkVID            = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vlink'}->{'vlinkVID'}}[$indexLink];
        my $vlinkRemoteGroup    = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vlink'}->{'vlinkRemoteGroup'}}[$indexLink];
        my $vlinkRemoteVDisk    = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vlink'}->{'vlinkRemoteVDisk'}}[$indexLink];

        # Find the corresponding Remote VDisk
        my $indexRemote = 0;
        foreach my $vdiskName (@{$xtcDataPtr->{VDISKS}->{$vlinkRemoteGroup}->{'vdisk'}->{'vdiskName'}})
        {
            if ($vlinkRemoteVDisk eq $vdiskName)
            {
                $vlinkLun     = ${$xtcDataPtr->{VDISKS}->{$vlinkRemoteGroup}->{'vdisk'}->{'vdiskLUN'}}[$indexRemote];
                $vlinkServer  = ${$xtcDataPtr->{VDISKS}->{$vlinkRemoteGroup}->{'vdisk'}->{'vdiskServer'}}[$indexRemote];
                last; #Exit with the current $vlinkLun & $vlinkServer
            }
            $indexRemote++;
        }

        # Find the corresponding Server Workset
        foreach my $serverRecord (@{$xtcDataPtr->{SERVERS}->{RECORD}->{$vlinkRemoteGroup}})
        {
            if ($vlinkServer eq ${$xtcDataPtr->{SERVERS}->{$vlinkRemoteGroup}->{$$serverRecord[0]}->{'serverName'}}[$$serverRecord[1]])
            {
                $serverCluster = ${$xtcDataPtr->{SERVERS}->{$vlinkRemoteGroup}->{$$serverRecord[0]}->{'serverWorkset'}}[$$serverRecord[1]];
                # Need modulus (# of targets) on the worksets to get the cluster
                last; #Exit with the current $serverCluster
            }
        }

        logInfo("Creating VLink on Cluster:$serverCluster, LUN:$vlinkLun, VID:$vlinkVID, " . 
                "VBlock:$vlinkVBlock, Controller Server:$vlinkServer, Name:$virLinkName");

        if (${$xtcDataPtr->{USEXMC}} eq "true")
        {
#           # Find the server record to use
#           $indexServer = 0;
#           foreach my $server (@serverName)
#           {
#               if ($server eq $vdiskServer[$indexLink])
#               {
#                           TestLibs::Logging::logInfo ("Creating VDisk Name:$vdiskName[$indexLink] Size:$vdiskSize[$indexLink] ID:$vdiskID[$indexLink] " . 
#                                                       "Workset:$serverWorkset[$indexServer] VBlock:$vdiskVBlock[$indexLink] DiskGroup:$diskGroupID[$indexGroup]");
#           
#                           $returnValue = TestLibs::IntegXMCLib::VDCreate($vdiskName[$indexLink],
#                                    $vdiskSize[$indexLink], $vdiskID[$indexLink], $vdiskRAID[$indexLink],
#                                    $serverWorkset[$indexServer], $vdiskVBlock[$indexLink], $diskGroupID[$indexGroup]);
#
#                           if ($returnValue != GOOD)
#                           {
#                               TestLibs::Logging::logError ("Failed to Create the VDisk RAID:$vdiskRAID[$indexLink] Name:$vdiskName[$indexLink] Size:$vdiskSize[$indexLink]"); 
#                           }
#               }
#               $indexServer++;
#           }
        }
        else
        {

            # Play nice with the XSSA
            # Get the VDisk ID within a VBlock, i.e. (VDiskID modulus VDiskCount)
            $ccbeRemoteVdiskID = $vlinkVID + ($vlinkVBlock * XSSAVDISKCOUNT);
            
            # Create the Vlink
            $returnValue = TestLibs::VlinksLibs::CreateVlink ($ccbeConnection,
                                   $serverCluster,
                                   $vlinkLun,
                                   $ccbeRemoteVdiskID,
                                   $virLinkName,
                                   );
    
            if ($returnValue != GOOD)
            {
                TestLibs::Logging::logError ("ERROR: Failed to Create the VLink");
            }
            delay(10);
        }
    $indexLink++;
    }

    if (${$xtcDataPtr->{USEXMC}} ne "true")
    {
        # Check the VLink state
#                $returnValue = TestLibs::Validate::CheckVlinkState($ccbeConnection);       
#                if ($returnValue != GOOD)
#                {
#                    TestLibs::Logging::logError ("VLinks failed state check");
#                }
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeConnection);  # Disconnect from Master CCBE
    }
    else
    {
        #
        # Disconnect from the VCG.
        #                
        if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{curTestGroup}} with ID ${$xtcDataPtr->{curSerialNumber}}");
        }                           
    }
    
    return GOOD;
}


#######################################################################
### Function name: AssociateCfgVlinks
###
### Purpose: Associate VLinks set up in the Config Files
##
## INPUT:    XTC Data Structure pointer 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub AssociateCfgVlinks
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $indexLink;
    my $noProgress = 0;
    my $pastRemaining = 100;
    my $remaining;
    my $ccbeConnection;
    my $returnValue;
    my @Server_ID;
    my $lun = 0;
    my $serverRsp;
    my @serverLuns;
    my $serverLunStr;
    my $ret;
    my $newport;
    my $workport;
    my %serversHash;
    my $serversArrayPtr;
    my @targetList;
    my @sidTargetPair;
    my $ccbeVdiskID;
    my $shortWWN;
    my $serverWorkset;
    my @worldWideName;
    my $wwnPointer;
    my $ICONRDY = BAD;    
    
    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Associate Vlinks Routine");

    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        
        # Ability to use CCBE if Script Agent is not running.  USEXMC can be set to TRUE.
        $ICONRDY = BAD;
        
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
        TestLibs::Logging::logInfo("Failed to connect to ICON, using CCBE interface");
        }
    }
    else
    {
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
    }
            
    # Associate Vlinks
    $indexLink = 0;
    foreach my $vlinkName (@{$xtcDataPtr->{VDISKS}->{$testGroup}->{'vlink'}->{'vlinkName'}})
    {
        # Get the current Vlink Record
        my $vlinkServer         = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vlink'}->{'vlinkServer'}}[$indexLink];
        my $vlinkLUN            = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vlink'}->{'vlinkLUN'}}[$indexLink];
        my $vlinkVBlock         = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vlink'}->{'vlinkVBlock'}}[$indexLink];
        my $vlinkVID            = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vlink'}->{'vlinkVID'}}[$indexLink];

        # Find the corresponding Server shortWWN & serverWorkset
        foreach my $serverRecord (@{$xtcDataPtr->{SERVERS}->{RECORD}->{$testGroup}})
        {
            if ($vlinkServer eq ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverName'}}[$$serverRecord[1]])
            {
                $shortWWN = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'shortWWN'}}[$$serverRecord[1]];
                $serverWorkset = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverWorkset'}}[$$serverRecord[1]];
                last; #Exit with the current $shortWWN and $serverWorkset
            }
        }
        #
        # $shortWWN is a pointer to a hash
        # create an array to pass to FindSIDs
        #
        push @worldWideName, $shortWWN;
        $wwnPointer = \@worldWideName;

        if ($ICONRDY eq GOOD)
        {
            # Set up the hocus pocus to point to the correct stuff
            $ret = TestLibs::IntegXMCLib::SetWorkBlock($serverWorkset, $vlinkVBlock);
            if ($ret != GOOD)
            {
                logError("Unable to set WorkSet:$serverWorkset or VBlock:$vlinkVBlock");
            }

            #
            # Find or Create the workport
            #
            $workport = TestLibs::IntegXMCLib::FindWorkport($shortWWN);
            if ($workport == INVALID)
            {
                # See if it is in the newport list
                $newport = TestLibs::IntegXMCLib::FindNewport($shortWWN);
                if ($newport != INVALID)
                {
                    # Set NewPort to be a WorkPort
                    $serverRsp = TestLibs::IntegXMCLib::CreateWorkport($newport);
                }

                $workport = TestLibs::IntegXMCLib::FindWorkport($shortWWN);
                if ($workport == INVALID)
                {
            
                    logError(sprintf("Unable to find Workport for WWN: %8.8X%8.8X\n",
                                          $shortWWN->{WWN_LO}, $shortWWN->{WWN_HI} ) );
                }
            }
        }
        else
        {
            # Find possible server IDs for this server
            @Server_ID = TestLibs::IntegCCBELib::FindSIDs($ccbeConnection, 0, $wwnPointer);
            # Check for Badness
            if ($Server_ID[0] == INVALID)
            {
                TestLibs::Logging::logError("Failed to Find SIDs");
            }
            
            # Get servers info from controller
            %serversHash = $ccbeConnection->servers();
            $serversArrayPtr = $serversHash{"SERVERS"};
#$dumper->dumpValues(%serversHash);
            
            #
            # Find the SID the XSSA would use
            #

            # Get the targetlist used by the XSSA for server assignment 
            TargetLookup($serverWorkset,  \@targetList);
            logInfo ("Using TargetList:@targetList");

            # Find the Target associated with each SID
            undef @sidTargetPair;
            foreach my $ServerIDCheck (@Server_ID)
            {
                foreach my $serverCheckPtr (@$serversArrayPtr)
                {
                    # See if this is the server record we need
                    if ($$serverCheckPtr{SID} == $ServerIDCheck)
                    {
                        # Save the corresponding TargetID for this SID
                        push @sidTargetPair, $$serverCheckPtr{TARGETID};
                    }
                }
            }
            
            # Find the SID / Target Pair to use
            my $checkFlag = 0;
SID_Check:  foreach my $targetID (@targetList)
            {
                my $indexTarget = 0;
                foreach my $targetPair (@sidTargetPair)
                {
                    if ($targetID == $targetPair)
                    {
                        $workport = $Server_ID[$indexTarget];
                        logInfo ("Using Server Workset:$serverWorkset SID:$workport with TargetID:$targetID");
                        $checkFlag = 1;
                        last SID_Check;
                    }
                    $indexTarget++;
                }
            }
            
            # Check to make sure we found it
            if (!$checkFlag) 
            {
                logError(sprintf("Could not find a SID / Target Pair for short WWN: %8.8X%8.8X\n",
                                         $shortWWN->{WWN_LO}, $shortWWN->{WWN_HI} ) );
            }
        }

        # Figure out Lun Number
        if ($vlinkLUN eq "next")
        {
            TestLibs::Logging::logInfo ("Looking up next LUN for Server Associate Workport:$workport");
            
            if ($ICONRDY eq GOOD)
            {
                # Get the VDisk / Lun in use
                my %VDiskInfo = XIOtech::IntegXMCLib::LunsInUse($workport);

                # Keys are the VDisks, Values are the Luns
                delete $VDiskInfo{"ERROR_CHECK"};
                @serverLuns = values %VDiskInfo;
            }
            else
            {
                @serverLuns = TestLibs::IntegCCBELib::GetUsedLuns($ccbeConnection, $workport, 0);
            }

            if (scalar(@serverLuns) && $serverLuns[0] != INVALID)
            {
                foreach my $listedLUN (@serverLuns)
                {
                    # Find the Max LUN
                    unless ($lun >= $listedLUN) {$lun = $listedLUN;}
                }
            $lun++;       # Increment one beyond the max
            }
            else
            {
                $lun=0;
            }
        }
        else
        {
            $lun = $vlinkLUN;
        }
    
        TestLibs::Logging::logInfo ("VCG:${$xtcDataPtr->{CURSERIALNUMBER}} Associate Vdisk VID:$vlinkVID Workport:$workport LUN:$lun");

        if ($ICONRDY eq GOOD)
        {
            $ret = TestLibs::IntegXMCLib::AssociateVdisk($workport, $lun, $vlinkVID);
            if ( $ret == ERROR )
            {
                TestLibs::Logging::logError ("Failed mapping Vlink VID:$vlinkVID Worport:$workport LUN:$lun");
            } 
        }
        else
        {
            # Play nice
            # Get the VDisk ID within a VBlock, i.e. (VDiskID modulus VDiskCount)
            $ccbeVdiskID = $vlinkVID + ($vlinkVBlock * XSSAVDISKCOUNT);
            $ret = TestLibs::IntegCCBELib::AssociateSingleVdisk($ccbeConnection, $workport, $lun, $ccbeVdiskID);
            if ( $ret == ERROR )
            {
                TestLibs::Logging::logError ("Failed mapping Vlink VID:$ccbeVdiskID SID:$workport LUN:$lun");
            } 
        }
        $indexLink++;
    }
    
    if ($ICONRDY eq GOOD)
    {
        #
        # Disconnect from the VCG.
        #                
        if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
        }                           
    }
    else
    {
        # Print out the Target Status Table
        my %targetStatus = TestLibs::IntegCCBELib::GetTargetStatus($ccbeConnection);
        TestLibs::IntegCCBELib::LogTargetStatus( %targetStatus);
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeConnection);  # Disconnect from Master CCBE
    }

    return GOOD;
}


=head2 DefineDiskGroup
          
Build the diskgroups with the assigned data from the VDISKS profile.  ICON ScriptAgent required to run.

    # Creates DiskGroup
    # Addes drives to Diskgroup
    # Edit diskgroup and change drive bay type and RAID options

=over 4

=item Usage:

 my $FuctionReturn = DefineDiskGroup(
                                     $xtcDataPtr);   
 
 where: $xtcDataPtr - pointer to the list of objects
    
 
 
 Notes:
 
 None

=item Returns:

 On success - GOOD.
 On error - ERROR.

=back

=cut


#######################################################################
### Function name: DefineDiskGroup
###
### Purpose: Logically Define a group of disks.
##
## INPUT:    None 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub DefineDiskGroup
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $groupRsp;
    my $indexGroup;
    my $returnValue;
    my @groupPIDs;
    my $ICONRDY = BAD;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Define Disk Groups Routine");

    #
    # Reserve ICON
    #
    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        # Ability to use CCBE if Script Agent is not running.  USEXMC can be set to TRUE.
        $ICONRDY = BAD;
        TestLibs::Logging::logInfo("Failed to connect to ICON, using CCBE interface");
        }
    }
    else
    {
        # Diskgroups are only supported via the ICON.  Create CfgVdisks will handle the passing of the drives to 
        # include when creating a Vdisk
        TestLibs::Logging::logWarning ("Diskgroups not yet supported via CCBE");
        return GOOD;
    }
    
    #
    # Create Disk Groups
    #
    if ($ICONRDY eq GOOD)
    {
    $indexGroup = 0;
    foreach my $driveGroupPIDsPtr (@{$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'diskGroupPIDs'}})
    {

        #
        # Get the current DiskGroup Record
        #
        my $diskGroupID     = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'diskGroupID'}}[$indexGroup];
        my $diskGroupName   = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'diskGroupName'}}[$indexGroup];
        my $driveRAID       = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'driveRAID'}}[$indexGroup];
        my $driveStripe     = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'driveStripe'}}[$indexGroup];
        my $driveDepth      = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'driveDepth'}}[$indexGroup];
        my $driveParity     = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'driveParity'}}[$indexGroup];
        my $driveType       = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'driveType'}}[$indexGroup];

        @groupPIDs = split /[,]/, $driveGroupPIDsPtr;
        
        #
        # Add the diskgroup and name it
        #
        if (${$xtcDataPtr->{USEXMC}} eq "true")
        {
            $returnValue = XIOtech::sanscript::diskgroupSet (${$xtcDataPtr->{STORAGE}->{$testGroup}->{'diskgroup'}->{'diskGroupID'}}[$indexGroup]);
            if ($returnValue != XMCGOOD)
            {
                DumpXSSAError();
                TestLibs::Logging::logError ("Failed to Set Disk Group ID:$diskGroupID");
            }
        }

       #
       # Add Vdisks to diskgroups
       #
       $groupRsp = XIOtech::sanscript::diskgroupAdd (@groupPIDs);

       #
       # Edit diskgroup to change drive bay type, and other RAID options depending on RAID type
       #
       if ($groupRsp == XMCGOOD)
        {
            if ($driveRAID == 0)        # RAID-0
            { 
                $returnValue = XIOtech::sanscriptET::diskgroupEdit($diskGroupID,
                                                            DRIVE_TYPE => $driveType,
                                                            NAME => $diskGroupName,
                                                            DESC => $diskGroupName);
                print "DiskGroupID: $diskGroupID   DiskGroupname: $diskGroupName  DriveBay Type:  $driveType \n";

            }
            elsif ($driveRAID == 5)     # RAID-5
            { 
                $returnValue = XIOtech::sanscriptET::diskgroupEdit($diskGroupID, DRIVE_TYPE => $driveType, 
                                                            NAME => $diskGroupName,
                                                            DESC => $diskGroupName,
                                                            R5SS => $driveStripe,       # RAID-5 Only
                                                            R5PARITY => $driveParity);
                print "DiskGroupID: $diskGroupID   DiskGroupname: $diskGroupName  DriveBay Type:  $driveType \n";

            }
            else                        # RAID-10
            { 
                $returnValue = XIOtech::sanscriptET::diskgroupEdit($diskGroupID, DRIVE_TYPE => $driveType,
                                                            NAME => $diskGroupName,
                                                            DESC => $diskGroupName,
                                                            R10SS => $driveStripe);     # RAID-10 only
                print "DiskGroupID: $diskGroupID   DiskGroupname: $diskGroupName  DriveBay Type:  $driveType \n";

            }

            if ($returnValue == XMCGOOD) # This disk group completed GOOD
            {
                TestLibs::Logging::logInfo ("Modified Disk Group $diskGroupName ID:$diskGroupID");
            }
            else # diskgroupEdit error
            {
                DumpXSSAError();
                TestLibs::Logging::logError ("Unable to change parameters on Disk Group $diskGroupName ID:$diskGroupID");
                return ERROR;
            }
        }
        
        $indexGroup++;
    }
    }
    else
    {
    TestLibs::Logging::logInfo("CCBE Interface does not know about WORKSETS.  Section skipped");
    }
    #
    # Un-Reserve ICON
    #
    if ($ICONRDY eq GOOD)
    {
        TestLibs::IntegXMCLib::XSSA_Unreserve (${$xtcDataPtr->{CURSERIALNUMBER}});     # Connect (VCG ID)                
    }

    return GOOD;
}

#######################################################################
### Function name: DeleteWorkports
###
### Purpose: Dlete all workports for the current CNC.
##
## INPUT:    None 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub DeleteWorkports
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $returnValue;
    my $ICONRDY = BAD;

 if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        # Ability to use CCBE if Script Agent is not running.  USEXMC can be set to TRUE.
        $ICONRDY = BAD;
        TestLibs::Logging::logInfo("Failed to connect to ICON, using CCBE interface");
        }
        
        if ($ICONRDY eq GOOD)
        {
            # Delete Workports
            $returnValue = DeleteWPList("ALL");
            if ($returnValue != GOOD)
            {
                TestLibs::Logging::logError ("Failed to Delete All Workports on CNC:${$xtcDataPtr->{CURSERIALNUMBER}}r");
            }

        TestLibs::IntegXMCLib::XSSA_Unreserve (${$xtcDataPtr->{CURSERIALNUMBER}});     # Connect (VCG ID)                
        }
        else
        {
        TestLibs::Logging::logWarning ("Delete all Workports not supported via the CCBE");
        }   
    }
    else
    {
        TestLibs::Logging::logWarning ("Delete all Workports not supported via the CCBE");
        return ERROR;
    }

    return GOOD;
}

#######################################################################
### Function name: UnConfig
###
### Purpose: Unconfigure all structures without doing a wipe-clean.
##
## INPUT:    None 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub UnConfig
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $returnValue;
    my $ICONRDY = BAD;

 if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        # Ability to use CCBE if Script Agent is not running.  USEXMC can be set to TRUE.
        $ICONRDY = BAD;
        TestLibs::Logging::logInfo("Failed to connect to ICON, using CCBE interface");
        }
        
        if ($ICONRDY eq GOOD)
        {
            # Delete Workports
            $returnValue = CleanAll();
            if ($returnValue != GOOD)
            {
                TestLibs::Logging::logError ("Failed to Unconfigure CNC:${$xtcDataPtr->{CURSERIALNUMBER}}");
            }

        TestLibs::IntegXMCLib::XSSA_Unreserve (${$xtcDataPtr->{CURSERIALNUMBER}});     # Connect (VCG ID)                
        }
        else
        {
        TestLibs::Logging::logWarning ("UnConfig not supported via the CCBE");
        } 
    }
    else
    {
        TestLibs::Logging::logWarning ("UnConfig not supported via the CCBE");
        return ERROR;
    }

    return GOOD;
}
#######################################################################
## Function name: CallPowerCycle
##
## Purpose: powercycle all equipment in the current VCG
##
## INPUT:    XTC Data Pointer, Type (ON, OFF, CYCLE) CYCLE is the default
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub CallPowerCycle
{
    trace();                        # This allows function tracability
    
    my ($xtcDataPtr) = @_;
        
    my $retPower = GOOD;
    my $indexPower;
    my $p;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};
    my $type = ${$xtcDataPtr->{CURTESTARGUMENT}};

    if (!defined $type  || $type eq 'none')
    {
        $type = "cycle";
    }

    # Turn Off Power if requested    
    if (lc $type ne "on")
    {
        if (!(@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}}))
        {
            TestLibs::Logging::logWarning ("No power Switch Found, You must manually power off:\n" .
            "Then hit enter...");

            my $pause = <STDIN>;
        }

        # Power Off all Channels in the Current Group
        $indexPower = 0;
        foreach my $powerIP (@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}})
        {
            my $powerChannel = ${$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}}[$indexPower];

            my $retPower = TestLibs::IntegCCBELib::PowerChange($powerIP, $powerChannel, "OFF");
            if ($retPower != GOOD)
            {
                TestLibs::Logging::logError ("Failed OFF Moxa Command IP:$powerIP Channel:$powerChannel, You must manually power off");
            }
        $indexPower++;
        }
    }

    # Turn On Power if requested    
    if (lc $type ne "off")
    {
        TestLibs::utility::delay(6);                #Wait for power supplies to discharge

        if (!(@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}}))
        {
            TestLibs::Logging::logWarning ("No power Switch Found, You must manually power on:\n" .
            "Then hit enter...");

            my $pause = <STDIN>;
        }

        # Power On all Channels in the Current Group
        $indexPower = 0;
        foreach my $powerIP (@{$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerIP'}})
        {
            my $powerChannel = ${$xtcDataPtr->{POWER}->{$testGroup}->{'moxa'}->{'powerChannel'}}[$indexPower];

            my $retPower = TestLibs::IntegCCBELib::PowerChange($powerIP, $powerChannel, "ON");
            if ($retPower != GOOD)
            {
                TestLibs::Logging::logError ("Failed ON Moxa Command IP:$powerIP Channel:$powerChannel, You must manually power on");
            }
        $indexPower++;
        }

        $p = Net::Ping->new("icmp");

        my $indexPing = 0;
        foreach my $pingIP (@{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}})
        {
            my $retPing = TestLibs::utility::pingWait($pingIP, 300);    # Ping for 300 seconds
            if ($retPing != GOOD)
            {
                TestLibs::Logging::logError ("Failed waiting for Controller IP:$pingIP to come ready");
            }
            $indexPing++;
        }
        $p->close();
        TestLibs::utility::delay (20);              # Wait a little longer because we don't belive the CCB is ready
    
    }

    return GOOD;
}

#######################################################################
## Function name: SetUpConfig
##
## Purpose: Create the basic configuration from values in config files
##
## INPUT:    xtcDataPtr
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub SetUpConfig
{
    trace();                        # This allows function tracability
    
    my ($xtcDataPtr) = @_;

    my $callReturn;

    # Configure current group

    # Call the switchCalls Function
    $callReturn = SwitchCalls($xtcDataPtr);
    if ($callReturn != GOOD) {return ERROR;}

    # Call the Build VCG Function 
    $callReturn = BuildVCG($xtcDataPtr);
    if ($callReturn != GOOD) {return ERROR;}

    # Call the Reboot or prepare Server Function
    $callReturn = ServerCalls($xtcDataPtr);
    if ($callReturn != GOOD) {return ERROR;}

    # Call the Label Drives Function
    $callReturn = LabelCfgDrives($xtcDataPtr);
    if ($callReturn != GOOD) {return ERROR;}

    # Call the Disk Group Function
    $callReturn = DefineDiskGroup($xtcDataPtr);
    if ($callReturn != GOOD) {return ERROR;}

    # Call the Create VDisks Function
    $callReturn = CreateCfgVdisks($xtcDataPtr);
    if ($callReturn != GOOD) {return ERROR;}

    # Call the Global Cache Function
    $callReturn = SetGlobalCache($xtcDataPtr);
    if ($callReturn != GOOD) {return ERROR;}

    # Call the Associate VDisks Function
    $callReturn = AssociateCfgVdisks($xtcDataPtr);
    if ($callReturn != GOOD) {return ERROR;}

    # Call the Create VLinks Function
    $callReturn = CreateCfgVlinks($xtcDataPtr);
    if ($callReturn != GOOD) {return ERROR;}

    # Call the Associate VLinks Function
    $callReturn = AssociateCfgVlinks($xtcDataPtr);
    if ($callReturn != GOOD) {return ERROR;}
    
    # This function not longer works.  Undocumented feature (MIMIC) without support.
    # Call the Create Server Function - mainly used for dual path on R6
    # $callReturn = CreateCfgServers($xtcDataPtr);
    # if ($callReturn != GOOD) {return ERROR;}


    return GOOD;
}

#######################################################################
### Function name: BuildVCG
###
### Purpose: applies license and adds controllers to VCG
##
## INPUT:    None 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub BuildVCG
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my @vcgArray;
    my $labelRsp;
    my $ccbeConnection;
    my $ccbeMaster;
    my $state;
    my $returnWait;
    my $vcgReturn;
    my @ccbeList;
    my $ccbeIndex = 0;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Build VCG Routine");

    @vcgArray = @{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgSN'}};

    TestLibs::Logging::logInfo ("VCG Array at Set Up config:@vcgArray");

    $ccbeMaster = ccbe_connect ($xtcDataPtr->{VCGS}->{$testGroup}->{'MASTER'}->{'IP'});         # Get a CCBE connection & Login (IP Address)


    #
    # add ccbeMaster to ccbeList as first entry
    #
    $ccbeList[0] = $ccbeMaster;

    $state = TestLibs::IntegCCBELib::GetPowerUpState ($ccbeMaster);
    if ($state != POWER_UP_COMPLETE )
    {
        # Apply VCG License (CCBE Mgr, VCG ID, SN Array)
        TestLibs::Configure::VcgLicense ($ccbeMaster, $xtcDataPtr->{VCGS}->{$testGroup}->{'MASTER'}->{'ID'}, scalar(@vcgArray));    
    }

    # Check power up state for Complete
    $state = TestLibs::IntegCCBELib::GetPowerUpState ($ccbeMaster);
    if ($state != POWER_UP_COMPLETE )
    {
        TestLibs::Logging::logError ("Power Up State is not complete, power up state:$state");
    }

    # Label Drive here (CCB Obj, PID, RAID Type)   
    $labelRsp = TestLibs::IntegCCBELib::LabelSingleDrive($ccbeMaster, 0, 1);

    if ($labelRsp != GOOD)
    {
        TestLibs::Logging::logInfo ("Failed to label the physical disk PID:0, Trying PID:1");
        $labelRsp = TestLibs::IntegCCBELib::LabelSingleDrive($ccbeMaster, 1, 1);

        if ($labelRsp != GOOD)
        {
            TestLibs::Logging::logError ("Failed to label the physical disk PID:1");
        }
    }
    TestLibs::utility::delay (10);                 # Give the controller time to propogate config change


    foreach my $curIP (@{$xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}})
    {
        # If not the master  controller
        if ($curIP ne $xtcDataPtr->{VCGS}->{$testGroup}->{'MASTER'}->{'IP'})
        {
            ++$ccbeIndex;
            $ccbeConnection = ccbe_connect ($curIP);         # Get a CCBE connection & Login (IP Address)
            $ccbeList[$ccbeIndex] = $ccbeConnection;         # add to ccbeList
            $state = TestLibs::IntegCCBELib::GetPowerUpState ($ccbeConnection);
            TestLibs::Logging::logInfo ("Controller IP:$curIP, Power Up State: $state");

            if ($state == POWER_UP_WAIT_LICENSE)
            {
                TestLibs::Logging::logInfo ("Adding Controller to the VCG, IP:$curIP");

                # Add the controller to the group
                $vcgReturn = TestLibs::IntegCCBELib::AddController(\@ccbeList, $ccbeIndex);
                if ($vcgReturn != GOOD)
                {
                    TestLibs::Logging::logError ("Failed to Add Controller to VCG");
                }

                $returnWait = TestLibs::Validate::Wait4PowerUpState($ccbeConnection, POWER_UP_COMPLETE, 300);
                if ($returnWait != GOOD)
                {
                    TestLibs::Logging::logError ("Added controller did not reach Power Up Complete");
                }

                $state = TestLibs::IntegCCBELib::GetPowerUpState ($ccbeConnection);
                TestLibs::Logging::logInfo ("Controller IP:$curIP, Power Up State: $state");
            }

            if ($state != POWER_UP_COMPLETE )
            {
                TestLibs::Logging::logError ("Controller is not at Power Up Complete");
            }
        }
    }
    # Check the VCG state
    $vcgReturn = TestLibs::Validate::CheckVCGState($ccbeMaster);       
    if ($vcgReturn != GOOD)
    {
        TestLibs::Logging::logError ("Suprise, Suprise, Suprise, the VCG failed the state check");
    }

    #
    # disconnect from all ccbes
    #
    for ($ccbeIndex = 0; $ccbeIndex < scalar(@ccbeList); $ccbeIndex++ )  
    {       
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeList[$ccbeIndex]); # Disconnect from CCBE
    }

    return GOOD;
}


##############################################################################
#
#          Name: ServerCalls
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Prepares or Reboots Servers when called from setupconfig.
#                Note: Preparing a server does the same thing as
#                partitioning and formatting all unpartitioned drives on
#                a server.
#
##############################################################################
sub ServerCalls
{
    trace();                       

    my ($xtcDataPtr) = @_;

    my $server;     # The IP address of a server to reboot or prepare.
    my $indexServer;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Server Setup Routine");

    #
    # Loop through all servers...
    #

    $indexServer = 0;
    foreach $server (@{$xtcDataPtr->{'SERVERS'}->{$testGroup}->{'windows'}->{'serverIP'}})
    {
            #
            # Parse based upon the specified action...
            #
            if ($xtcDataPtr->{'SERVERS'}->{$testGroup}->{'windows'}->{'serverAction'}[$indexServer] eq "reboot")
            {
                #
                # Reboot the server remotely.
                #
                logInfo("Rebooting server $server...");
                my @args = ("common/shutdown", "\\\\$server /R /T:10 /C"); 

                my $systemReturn =  system(@args);
                logInfo ("system return:$systemReturn");

                if ($systemReturn == 0)
                {
                    TestLibs::Logging::logInfo ("Completed System call: @args"); 
                }
                else
                {
                    TestLibs::Logging::logError ("######## Failed to run System call @args ########");
                }
                
                #
                # Wait for the server to shutdown and then wait for it 
                # to come back up by continuously pinging it.
                #
                print "\n";  #Newline in case an error message was returned from the system call
                TestLibs::utility::delay (120);            
                my $retPing = TestLibs::utility::pingWait($server, 300);    # Ping for 300 seconds
                if ($retPing != GOOD)
                {
                    TestLibs::Logging::logError ("Failed waiting for server $server to come ready");
                    return ERROR;
                }
            }

            elsif ($xtcDataPtr->{'SERVERS'}->{$testGroup}->{'windows'}->{'serverAction'}[$indexServer] eq "prepare")
            {
                #
                # Prepare the server.
                #        
                my $ret = PrepareWindowsDisks($server);
                if ($ret != GOOD)
                {
                    # Note: An error message will be displayed by the prepare
                    # windows disks routine.
                    return ERROR;
                }
        }
    $indexServer++;
    }
    return GOOD;
}


##############################################################################
#
#          Name: SwitchCalls
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Does switch configuration when called from setupconfig.
#
##############################################################################
sub SwitchCalls
{
    trace();                       

    my ($xtcDataPtr) = @_;

    my $switchIP;     # An IP address of a switch.
    my $indexSwitch;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Fibre Switch Setup Routine");

    #
    # Loop through all fibre switches..
    #
    $indexSwitch = 0;
    foreach $switchIP (@{$xtcDataPtr->{'SWITCHES'}->{$testGroup}->{'brocade'}->{'serverIP'}})
    {
        #
        # Parse based upon the specified action...
        #
        if ($xtcDataPtr->{'SWITCHES'}->{$testGroup}->{'brocade'}->{'switchAction'}[$indexSwitch] eq "zone")
        {
            #
            # Login to the switch.
            #
            logInfo("Logging into switch $switchIP...");
            my $switchObj = BSWLogInToSwitch($switchIP, 
                                             $xtcDataPtr->{'SWITCHES'}->{$testGroup}->{'brocade'}->{'switchUsername'}[$indexSwitch],
                                             $xtcDataPtr->{'SWITCHES'}->{$testGroup}->{'brocade'}->{'switchPassword'}[$indexSwitch]);

            #
            # Check to see if logging into the switch was successful.
            #
            if ( !defined($switchObj) )
            {
                logError("Failed to login to Brocade switch IP:$switchIP");
                return ERROR;
            }

            #
            # Zone the switch.
            #
            logInfo("Zoning the switch...");
            my $ret = BSWZoneSwitch($switchObj, $xtcDataPtr->{'SWITCHES'}->{$testGroup}->{'brocade'}->{'switchZones'}[$indexSwitch]);
            if ($ret == ERROR)
            {
                logError("Failed to zone Brocade switch IP:$switchIP");
                return ERROR;
            }
            
            print "\n";                    
        }                     
        $indexSwitch++;
    }
    return GOOD;    
}


#######################################################################
### Function name: LabelCfgDrives
###
### Purpose: Labels all single drives or drives pools for the current VCG.
##
## INPUT:    None 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub LabelCfgDrives
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $labelRsp;
    my $indexDrive;
    my $ccbeConnection;
    my $returnValue;
    my $ICONRDY = BAD;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Label Configuration Drives Routine");

  
    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        XSSA_DeviceList();                      # Log current device list for posterity
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        
        # Ability to use CCBE if Script Agent is not running.  USEXMC can be set to TRUE.
        $ICONRDY = BAD;
        
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
        TestLibs::Logging::logInfo("Failed to connect to ICON, using CCBE interface");
        }
    }
    else
    {
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
    }
  

    
    # Label Drives
    $indexDrive = 0;
    foreach my $drivePoolOption (@{$xtcDataPtr->{STORAGE}->{$testGroup}->{'drivepool'}->{'drivePoolOption'}})
    {
        my $poolOption = 0;         # Default option to all drives (0)
        if ($drivePoolOption eq "half") {$poolOption = 1};
        if ($drivePoolOption eq "unlabeled") {$poolOption = 2};

        # Get the current Storage Record
        my $drivePoolNonRedund  = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'drivepool'}->{'drivePoolNonRedund'}}[$indexDrive];
        my $drivePoolHotspare   = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'drivepool'}->{'drivePoolHotspare'}}[$indexDrive];
        my $drivePoolUnlabeled  = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'drivepool'}->{'drivePoolUnlabeled'}}[$indexDrive];
        my $drivePoolRedund     = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'drivepool'}->{'drivePoolRedund'}}[$indexDrive];

        TestLibs::Logging::logInfo ("Label Drives as defined in config files:");
        TestLibs::Logging::logInfo ("NonRedundant:$drivePoolNonRedund");
        TestLibs::Logging::logInfo ("    Hotspare:$drivePoolHotspare");
        TestLibs::Logging::logInfo ("   Unlabeled:$drivePoolUnlabeled");
        TestLibs::Logging::logInfo ("   Redundant:$drivePoolRedund");
        TestLibs::Logging::logInfo ("Repeat...");

        if ($ICONRDY eq GOOD)
        {
            $labelRsp = TestLibs::IntegXMCLib::LabelAllDrives (
                                                $drivePoolRedund,
                                                $drivePoolNonRedund,
                                                $drivePoolHotspare,
                                                $drivePoolUnlabeled,
                                                $poolOption);
        }
        else
        {
            $labelRsp = TestLibs::IntegCCBELib::LabelAllDrives ($ccbeConnection,
                                                 $drivePoolRedund,
                                                 $drivePoolNonRedund,
                                                 $drivePoolHotspare,
                                                 $drivePoolUnlabeled,
                                                 $poolOption);
        }
        
        if ($labelRsp != GOOD)
        {
            TestLibs::Logging::logError ("Failed to label all physical disks");
        }
        $indexDrive++;
    }

    $indexDrive = 0;
    foreach my $driveType (@{$xtcDataPtr->{STORAGE}->{$testGroup}->{'drive'}->{'driveType'}})
    {
        # Get the current Storage Record
        my $drivePID  = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'drive'}->{'drivePID'}}[$indexDrive];
        my $driveName  = ${$xtcDataPtr->{STORAGE}->{$testGroup}->{'drive'}->{'driveName'}}[$indexDrive];

        my $drvLabelOption = XSSADATATYPE;         # Default option to label as redundant
        if ($driveType eq "nonredundant") {$drvLabelOption = XSSAUNSAFETYPE};
        if ($driveType eq "hotspare") {$drvLabelOption = XSSAHOTSPARETYPE};
        if ($driveType eq "unlabeled") {$drvLabelOption = XSSAUNLABLEDTYPE};

        if (${$xtcDataPtr->{USEXMC}} eq "true")
        {
            $labelRsp = TestLibs::IntegXMCLib::LabelSingleDrive($drvLabelOption, $drivePID);
        }
        else
        {
            $labelRsp = TestLibs::IntegCCBELib::LabelSingleDrive($ccbeConnection, $drivePID, $drvLabelOption);
        }

        if ($labelRsp != GOOD)
        {
            TestLibs::Logging::logError ("Failed to label the physical disk PID: $drivePID");
        }
        $indexDrive++;
    }

    if ($ICONRDY ne GOOD)
    {
        TestLibs::IntegCCBELib::DispPdiskInfo ($ccbeConnection);
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeConnection);  # Disconnect from Master CCBE
    }
    else
    {
        if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
        }                           
    }

    return GOOD;
}

#######################################################################
### Function name: SetGlobalCache
###
### Purpose: Sets the global cache for a VCG.
##
## INPUT:    None 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub SetGlobalCache
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $ccbeConnection;
    my $returnValue;
    my $return;
    my $master;
    my $ctrl;
    my @coList;
    my @groupCCBE;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Set Global Cache Routine");

    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}});                            # Connect (VCG ID)
        if($returnValue != GOOD) { return ERROR; }

        # Using CCBE command until ICON CLI is supported (NE 1/6/05)
        #
        # Get a Master CCBE connection & Login (IP Address)
        #
        #ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);

    #
    # Connect to each controller in the VCG and create a list of the connected
    # controllers.
    #
    }
    
    $returnValue = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@groupCCBE);
    if ( $returnValue != GOOD )
    {
        TestLibs::Logging::logInfo("Failed to connect to one or more controllers.");
        return ERROR;
    }


    #
    # find the master controller
    #
    $master = FindMaster( \@groupCCBE );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }
    $coList = $groupCCBE[$master];
    
    
        #
        # now, turn on the global caching bit
        #
        $return = WrtCacheControlGlobal( $coList, WRTCACHE_GLOBAL_SET_ENABLE );

        if ($return != GOOD)
        {
            logInfo(">>>>>>>> Unable to enable global caching. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        logInfo("Global write caching enabled on controller");


        if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
        }                           
    
        logInfo("Global write caching enabled on controller");


      
    #
    # Disconnect from any controllers that have been connected to.
    #
    for (my $i = 0; $i < @groupCCBE; $i++)
    {
        if (ccbe_disconnect($groupCCBE[$i]) == ERROR)
        {
            logWarning("Failed to disconnect from controller");
        }
    }

        
        
        
    

    return GOOD;
}


#######################################################################
### Function name: AssociateCfgVdisks
###
### Purpose: Associate the vdisks to the servers specified in the config file
###          and mirrors Vdisks if assigned in the [station][Vdisks] profile
##
## INPUT:    None 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub AssociateCfgVdisks
{
    trace();                        # This allows function tracability
     use warnings;
    my ($xtcDataPtr) = @_;

    my $serialNumber;
    my $indexDrive;
    my $ccbeConnection;
    my $returnValue;
    my @Server_ID;
    my $lun = 0;
    my $serverRsp;
    my @serverLuns;
    my $serverLunStr;
    my $ret;
    my $newport;
    my $workport;
    my %serversHash;
    my $serversArrayPtr;
    my @targetList;
    my @sidTargetPair;
    my $ccbeVdiskID;
    my $shortWWN;
    my $serverWorkset;
    my $serverVPort;
    my $serverVPass;
    my @worldWideName;
    my $wwnPointer;    
    my $vdiskID;
    my $server;
    my $vdiskVBlock;
    my $vdiskLUN;
    my $vdiskMirror;
    my $ICONRDY = BAD;
    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Associate VDisks Routine");

    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        
        # Ability to use CCBE if Script Agent is not running.  USEXMC can be set to TRUE.
        $ICONRDY = BAD;
        
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
        TestLibs::Logging::logInfo("Failed to connect to ICON, using CCBE interface");
        }
    }
    else
    {
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
    }            
    #
    # Loop for each VDisk in the config file
    #
    
    #
    # Associate VDisks
    #
    $indexDrive = 0;
    foreach my $vdiskName (@{$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskName'}})
    {
        
        #
        # Get the current VDisk Record
        #
        $vdiskID        = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskID'}}[$indexDrive];
        $server         = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskServer'}}[$indexDrive];
        $vdiskVBlock    = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskVBlock'}}[$indexDrive];
        $vdiskLUN       = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskLUN'}}[$indexDrive];
        
        #
        # Find out if this Vdisk is to be used for mirroring.  If so, call mirror function
        #
        $vdiskMirror    = ${$xtcDataPtr->{VDISKS}->{$testGroup}->{'vdisk'}->{'vdiskMirrorDes'}}[$indexDrive];


        #
        # Don't associate VDisks if the server name is "none"
        #
        if ($server ne "none" && $vdiskMirror eq "99")
        {
            #
            # Find the corresponding Server shortWWN & serverWorkset & serverVPort
            #
            foreach my $serverRecord (@{$xtcDataPtr->{SERVERS}->{RECORD}->{$testGroup}})
            {
                if ($server eq ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverName'}}[$$serverRecord[1]])
                {
                    $shortWWN = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'shortWWN'}}[$$serverRecord[1]];
                    $serverWorkset = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverWorkset'}}[$$serverRecord[1]];
                    $serverVPass = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverVPass'}}[$$serverRecord[1]];
                    $serverVPort = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverVPort'}}[$$serverRecord[1]];
                    last; #Exit with the current $shortWWN and $serverWorkset
                }
            }

            #
            # $shortWWN is a pointer to a hash
            # create an array to pass to FindSIDs
            #
            push @worldWideName, $shortWWN;
            $wwnPointer = \@worldWideName;
            
            #
            # Use ICON
            #
            if ($ICONRDY eq GOOD)
            {
                #
                # Set up the hocus pocus to point to the correct stuff
                #
                $ret = TestLibs::IntegXMCLib::SetWorkBlock($serverWorkset, $vdiskVBlock);
                if ($ret != GOOD)
                {
                    TestLibs::Logging::logError("Unable to set WorkSet:$serverWorkset or VBlock:$vdiskVBlock");
                }

                #
                # first, is this disk ready for use. (devstat = 0x10)
                #

                #
                # Find or Create the workport
                #
                
                $workport = TestLibs::IntegXMCLib::FindWorkport($shortWWN);
                if ($workport == INVALID)
                {
                    #
                    # See if it is in the newport list
                    #
                    $newport = TestLibs::IntegXMCLib::FindNewport($shortWWN);
                    if ($newport != INVALID)
                    {
                        if( ( lc($serverVPort) ne "default"))
                        {
                            #
                            # Set NewPort to be a WorkPort & name it
                            #
                            $serverRsp = TestLibs::IntegXMCLib::CreateWorkport($newport, $serverVPort);
                        }
                        else
                        {
                            $serverRsp = TestLibs::IntegXMCLib::CreateWorkport($newport);
                        }
                    }

                    $workport = TestLibs::IntegXMCLib::FindWorkport($shortWWN);
                    if ($workport == INVALID)
                    {
                        logError(sprintf("Unable to find Workport for WWN: %8.8X%8.8X\n",
                                              $shortWWN->{WWN_LO}, $shortWWN->{WWN_HI} ) );
                    }
                    else
                    {
                        $serverRsp = TestLibs::IntegXMCLib::NameWorkport($workport, $server);
                    }
                }
            }

            #
            # Don't use XMC
            #
            else
            {
                #
                # Find possible server IDs for this server
                #
                @Server_ID = TestLibs::IntegCCBELib::FindSIDs($ccbeConnection, 0, $wwnPointer);
                
                #
                # Check for Badness
                #
                if ($Server_ID[0] == INVALID)
                {
                    TestLibs::Logging::logError("Failed to Find SIDs");
                }
                
                #
                # Get servers info from controller
                #
                %serversHash = $ccbeConnection->servers();
                $serversArrayPtr = $serversHash{"SERVERS"};
                
                #
                # Find the SID the XSSA would use
                #

                #
                # Get the targetlist used by the XSSA for server assignment 
                #
                TargetLookup($serverWorkset,  \@targetList);
                logInfo("Using TargetList: @targetList");

                #
                # Find the Target associated with each SID
                #
                undef @sidTargetPair;
                foreach my $ServerIDCheck (@Server_ID)
                {
                    foreach my $serverCheckPtr (@$serversArrayPtr)
                    {
                        #
                        # See if this is the server record we need
                        #
                        if ($$serverCheckPtr{SID} == $ServerIDCheck)
                        {
                            #
                            # Save the corresponding TargetID for this SID
                            #
                            push @sidTargetPair, $$serverCheckPtr{TARGETID};
                        }
                    }
                }
                
                #
                # Find the SID / Target Pair to use
                #
                my $checkFlag = 0;
    SID_Check:  foreach my $targetID (@targetList)
                {
                    my $indexTarget = 0;
                    foreach my $targetPair (@sidTargetPair)
                    {
                        if ($targetID == $targetPair)
                        {
                            $workport = $Server_ID[$indexTarget];
                            logInfo ("Using Server Workset:$serverWorkset SID:$workport with TargetID:$targetID");
                            $checkFlag = 1;
                            last SID_Check;
                        }
                        $indexTarget++;
                    }
                }
                
                #
                # Check to make sure we found it
                #
                if (!$checkFlag) 
                {
                    logError(sprintf("Could not find a SID / Target Pair for short WWN: %8.8X%8.8X\n",
                                             $shortWWN->{WWN_LO}, $shortWWN->{WWN_HI} ) );
                }
            }

            #
            # Figure out Lun Number
            #
            if ($vdiskLUN eq "next")
            {
                TestLibs::Logging::logInfo ("Looking up next LUN for Server Associate Workport:$workport");
                
                if ($ICONRDY eq GOOD)
                {
                    #
                    # Get the VDisk / Lun in use
                    #
                    my %VDiskInfo = XIOtech::IntegXMCLib::LunsInUse($workport);

                    #
                    # Keys are the VDisks, Values are the Luns
                    #
                    delete $VDiskInfo{"ERROR_CHECK"};
                    @serverLuns = values %VDiskInfo;
                }
                else
                {
                    @serverLuns = TestLibs::IntegCCBELib::GetUsedLuns($ccbeConnection, $workport, 0);
                }

                if (scalar(@serverLuns) && $serverLuns[0] != INVALID)
                {
                    foreach my $listedLUN (@serverLuns)
                    {
                        #
                        # Find the Max LUN
                        #
                        unless ($lun >= $listedLUN) {$lun = $listedLUN;}
                    }
                $lun++;       # Increment one beyond the max
                }
                else
                {
                    $lun=0;
                }
            }
            else
            {
                $lun = $vdiskLUN;
            }
        
            TestLibs::Logging::logInfo ("VCG:${$xtcDataPtr->{CURSERIALNUMBER}}" . 
            " Associate Vdisk VID:$vdiskID Workport:$workport LUN:$lun VPORT:$serverVPass");

            if ($ICONRDY eq GOOD)
            {
                $ret = XIOtech::sanscript::vdiskMask($workport, $lun, $vdiskID, $serverVPass);
                if ( $ret != XMCGOOD )
                {
                    TestLibs::Logging::logError ("Failed mapping Vdisk VID:$vdiskID Worport:$workport LUN:$lun VPORT:$serverVPass");
                } 
            }
            else
            {
                #
                # Play nice
                # Get the VDisk ID within a VBlock, i.e. (VDiskID modulus VDiskCount)
                #
                $ccbeVdiskID = $vdiskID + ($vdiskVBlock * XSSAVDISKCOUNT);
                $ret = TestLibs::IntegCCBELib::AssociateSingleVdisk($ccbeConnection, $workport, $lun, $ccbeVdiskID);
                if ( $ret == ERROR )
                {
                    TestLibs::Logging::logError ("Failed mapping Vdisk VID:$ccbeVdiskID SID:$workport LUN:$lun");
                } 
            }
        }   # No server selected - name = 'none'

        #
        # Check if Vdisk is assign as a Mirror Destination and if so, call vdiskMirror function to complete.
        #
        if ($ICONRDY eq GOOD && $vdiskMirror ne "99")
        {
            #
            # Set up the hocus pocus to point to the correct stuff
            #
            $ret = TestLibs::IntegXMCLib::SetWorkBlock($serverWorkset, $vdiskVBlock);
            if ($ret != GOOD)
            {
                TestLibs::Logging::logError("Unable to set WorkSet:$serverWorkset or VBlock:$vdiskVBlock");
            }
            $ret = XIOtech::sanscript::diskgroupSet(0);
            $ret = XIOtech::sanscript::vdiskMirror($vdiskMirror, $vdiskID);
            if ( $ret != XMCGOOD )
            {
                TestLibs::Logging::logError ("Error occured while mirroring VID: $vdiskMirror to VID: $vdiskID");
                print errorString() . "\n";
            } 
            else
            {
               TestLibs::Logging::logInfo("Mirroring VID: $vdiskMirror to VID: $vdiskID");

            }
          
        }
                
        $indexDrive++;
    }   # End each VDisk
    
    if ($ICONRDY eq GOOD)
    {
        #
        # Disconnect from the VCG.
        #                
        if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
        } 
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeConnection);  # Disconnect from Master CCBE                          
    }
    else
    {
        #
        # Print out the Target Status Table
        #
        my %targetStatus = TestLibs::IntegCCBELib::GetTargetStatus($ccbeConnection);
        TestLibs::IntegCCBELib::LogTargetStatus( %targetStatus);
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeConnection);  # Disconnect from Master CCBE
    }

    return GOOD;
}

#######################################################################
### Function name: AssociateCfgServers
###
### Purpose: Used to associate to multiplae links (multipath or MIMIC feature.
##
## INPUT:    None 
## OUTPUT:   Return GOOD or ERROR
#######################################################################

sub CreateCfgServers
{
    trace();                        # This allows function tracability

    my ($xtcDataPtr) = @_;

    my $testGroup;
    my $returnValue;
    my $workport;
    my $indexServer;
    my $shortWWN;
    my $newport;
    my $serverRsp;
    my $serverWorkset;
    my $serverVPass;
    my $newServerName;
    my $serverVPort;
    my @worldWideName;
    my $wwnPointer;    

    #
    # This feature is unsupported and not used.  However, function will remain in case
    # the feature returns.  Option has been removed from Station profiles.
    #
    
    $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    TestLibs::Logging::logInfo ("Create servers routine mainly used for dual path - ICON only ");

    if (${$xtcDataPtr->{USEXMC}} ne "true")
    {
        logInfo("This routine uses ICON scripting only");
        return ERROR;
    }
    
    $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
    if(GOOD != $returnValue) 
    { 
        return ERROR; 
    }            
    
    
    # Associate VDisks
    

    $indexServer = 0;
    
    foreach my $serverToName (@{$xtcDataPtr->{CREATESERVERS}->{$testGroup}->{'server'}->{'serverToName'}})
    {

        $newServerName =  ${$xtcDataPtr->{CREATESERVERS}->{$testGroup}->{'server'}->{'serverName'}}[$indexServer];
        
        $indexServer++;
        
        # Find the corresponding Server shortWWN & serverWorkset
        
        foreach my $serverRecord (@{$xtcDataPtr->{SERVERS}->{RECORD}->{$testGroup}})
        {
            if ($serverToName eq ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverName'}}[$$serverRecord[1]])
            {
                $shortWWN = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'shortWWN'}}[$$serverRecord[1]];
                $serverWorkset = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverWorkset'}}[$$serverRecord[1]];
                $serverVPass = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverVPass'}}[$$serverRecord[1]];
                $serverVPort = ${$xtcDataPtr->{SERVERS}->{$testGroup}->{$$serverRecord[0]}->{'serverVPort'}}[$$serverRecord[1]];
                
                last; #Exit with the current $shortWWN and $serverWorkset
            }
        }

        #
        # $shortWWN is a pointer to a hash
        # create an array to pass to FindSIDs
        #
        push @worldWideName, $shortWWN;
        $wwnPointer = \@worldWideName;

        # Set up the hocus pocus to point to the correct stuff
        
        $returnValue = TestLibs::IntegXMCLib::SetWorkBlock($serverWorkset);
        if (GOOD != GOOD)
        {
            TestLibs::Logging::logError("Unable to set WorkSet:$serverWorkset");
        }


        #
        # Find or Create the workport
        #

        $workport = TestLibs::IntegXMCLib::FindWorkport($shortWWN);
        
        if ( INVALID == $workport )
        {
            # See if it is in the newport list
            $newport = TestLibs::IntegXMCLib::FindNewport($shortWWN);
            if ($newport != INVALID)
            {
                # Set NewPort to be a WorkPort
                $serverRsp = TestLibs::IntegXMCLib::CreateWorkport($newport, $serverVPort);
            }

            $workport = TestLibs::IntegXMCLib::FindWorkport($shortWWN);
            if ( INVALID == $workport )
            {
                logError(sprintf("Unable to find Workport for WWN: %8.8X%8.8X\n",
                                      $shortWWN->{WWN_LO}, $shortWWN->{WWN_HI} ) );
            }
            else
            {
                $serverRsp = TestLibs::IntegXMCLib::NameWorkport($workport, $newServerName);
            }
        }
    }
        
    #
    # Disconnect from the VCG.
    #                
    if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
    {
        logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
    }                           

    return GOOD;
}

#######################################################################
### Function name: CheckVdiskInit
###
### Purpose: Decide how to check VdiskInit, XMC or CCBE
##
## INPUT:    VDisk ID, CCBE Connection if required, XTC Data Pointer 
## OUTPUT:   Return % init remaining
#######################################################################
sub CheckVdiskInit
{
    trace();                       # This allows function tracability
    
    my ($vdiskID, $ccbeConnection, $xtcDataPtr) = @_;
    my $remaining;
    my $ICONRDY = BAD;

    
    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        
        # Ability to use CCBE if Script Agent is not running.  USEXMC can be set to TRUE.
        $ICONRDY = BAD;
        
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
        TestLibs::Logging::logInfo("Failed to connect to ICON, using CCBE interface");
        }
    }
    else
    {
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
    }
    
    
    
    if ($ICONRDY eq GOOD)
    {
        $remaining = TestLibs::IntegXMCLib::CheckInitProgress($vdiskID);
    }
    else
    {
        $remaining = TestLibs::IntegCCBELib::CheckInitProgress($ccbeConnection, $vdiskID);
    }
                    
    return $remaining;
}


#######################################################################
### Function name: WaitVdiskInit
###
### Purpose: Wait for this disk ready for use. (devstat = 0x10)
##
## INPUT:    VDisk ID, CCBE Connection if required, XTC Data Pointer 
## OUTPUT:   Return GOOD or ERROR
#######################################################################
sub WaitVdiskInit
{
    trace();                       # This allows function tracability
    
    my ($vdiskID, $ccbeConnection, $xtcDataPtr) = @_;
    #
    # first, 
    #
    my $noProgress = 0;
    my $pastRemaining = 100;
    my $remaining;

    $remaining = CheckVdiskInit($vdiskID, $ccbeConnection, $xtcDataPtr);

    if ( 0 != $remaining )
    {
        print "Waiting for vdisk $vdiskID to become operational. \n";
        while (0 != ($remaining = CheckVdiskInit($vdiskID, $ccbeConnection, $xtcDataPtr)))
        {
            print "$remaining percent left to initialize \r";
            if ($pastRemaining == $remaining)
            {
                $noProgress++;
            }
            else
            {
                $noProgress = 0;
            }

            if ($noProgress == 300)
            {
                logWarning ("No progress on VDisk:$vdiskID Init, Stopped waiting");
                return ERROR;
            }

            $pastRemaining = $remaining;
            # pause for a second or 2
            sleep 2;
        }
    }

    return GOOD;
}

##############################################################################
#
#          Name: PrepareServersDisks
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Partitions and formats any unpartitioned drives on 
#                the servers in the currently selected VCG.
#
##############################################################################
sub PrepareServersDisks
{
    trace();

    my ($xtcDataPtr) = @_;

    my $serverIP;
    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    #
    # Loop through all servers and prepare the ones in the currently
    # selected VCG.
    #

    # Prepare all the Linux servers
#    foreach $serverIP (@{$xtcDataPtr->{$testGroup}->{'linux'}->{'serverIP'}})
#    {
#        if ( PrepareLinuxDisks($serverIP) != GOOD )
#        {
#            logError("Failed to prepare server disks on linux server $serverIP");
#            return ERROR;
#        }
#    }

    # Prepare all the windoze servers
    foreach $serverIP (@{$xtcDataPtr->{SERVERS}->{$testGroup}->{'windows'}->{'serverIP'}})
    {
        if ( PrepareWindowsDisks($serverIP) != GOOD )
        {
            logError("Failed to prepare server disks on windows server $serverIP");
            return ERROR;
        }
    }

    
    return GOOD;  
}

##############################################################################
#
#          Name: DisAssocAll
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Disassociates all virtual Disks from all servers that are 
#                associated on the current VCG.
#
##############################################################################
sub DisAssocAll
{
    trace ();

    my ($xtcDataPtr) = @_;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    my $returnCode = ERROR; # The return code that is returned (default, ERROR).
    my $ccbeConnection;
    my $ICONRDY = BAD;

    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        
        # Ability to use CCBE if Script Agent is not running.  USEXMC can be set to TRUE.
        $ICONRDY = BAD;
        
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
        TestLibs::Logging::logInfo("Failed to connect to ICON, using CCBE interface");
        }
    }
    else
    {
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
    }

    if ($ICONRDY eq GOOD)
    {
   
        #
        # Run the test.
        #
        $returnCode = TestLibs::IntegXMCLib::DisassocAll();

        #
        # Disconnect from the VCG.
        #                
        if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
        }           
    }
    else
    {
        $returnCode = TestLibs::IntegCCBELib::DisassocAll($ccbeConnection, 0);
        # Disconnect from CCBE
        logInfo("Disconnecting from CCBE Obj:$ccbeConnection");
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeConnection);
    }
    
    return $returnCode;
}

##############################################################################
#
#          Name: DeleteVdAll
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Deletes all vdisks in the current VCG.
#
##############################################################################
sub DeleteVdAll
{
    trace();

    my ($xtcDataPtr) = @_;

    my $returnCode = ERROR; # The return code that is returned (default, ERROR).
    my $ccbeConnection;
    
    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};
    my $ICONRDY = BAD;
    
    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        
        # Ability to use CCBE if Script Agent is not running.  USEXMC can be set to TRUE.
        $ICONRDY = BAD;
        
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
        TestLibs::Logging::logInfo("Failed to connect to ICON, using CCBE interface");
        }
    }
    else
    {
        # Get a Master CCBE connection & Login (IP Address)
        ConnectMasterCCBE(\@{$xtcDataPtr->{'VCGS'}->{$testGroup}->{'bigfoot'}->{'vcgIP'}}, \$ccbeConnection);
    }
        
    if ($ICONRDY eq GOOD)
    {
    
        #
        # Run the test.
        #
        $returnCode = TestLibs::IntegXMCLib::DeleteVDAll();

        #
        # Disconnect from the VCG.
        #                
        if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
        }           
    }
    else
    {
        $returnCode = TestLibs::IntegCCBELib::DeleteAllVdisks2($ccbeConnection, 0);
        # Disconnect from CCBE
        TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeConnection);
    }
    
    return $returnCode;
}

##############################################################################
#
#          Name: DeleteVBAll
#
#        Inputs: xtcDataPtr
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Deletes all VBlocks in the current VCG.
#
##############################################################################
sub DeleteVBAll
{
    trace();

    my ($xtcDataPtr) = @_;

    my $returnCode = ERROR; # The return code that is returned (default, ERROR).
    my $ccbeConnection;
    
    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};


    if (${$xtcDataPtr->{USEXMC}} eq "true")
    {
        $ICONRDY = GOOD;
        $returnValue = TestLibs::IntegXMCLib::XSSA_Reserve (${$xtcDataPtr->{CURSERIALNUMBER}}); # Connect (VCG ID)
        if($returnValue != GOOD) 
        {
        # Ability to use CCBE if Script Agent is not running.  USEXMC can be set to TRUE.
        $ICONRDY = BAD;
        TestLibs::Logging::logInfo("Failed to connect to ICON, CCBE does not use Vblocks");
        }
    }

    #
    # VBlocks are an ICON only concept
    #
    if ($ICONRDY eq GOOD)
    {
  
        #
        # Delete the VBlock.
        #
        $returnCode = TestLibs::IntegXMCLib::DeleteVBList("ALL");

        #
        # Disconnect from the VCG.
        #                
        if (XSSA_Unreserve(${$xtcDataPtr->{CURSERIALNUMBER}}) == ERROR)
        {
            logWarning("Failed to disconnect from VCG group ${$xtcDataPtr->{CURTESTGROUP}} with ID ${$xtcDataPtr->{CURSERIALNUMBER}}");
        }           
    }
    
    return $returnCode;
}

##############################################################################
#
#          Name: showzoningconfig
#
#        Inputs: none
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Shows the zoning configuration for the switches in the
#                currently selected VCG.
#
##############################################################################
sub showzoningconfig
{
    trace();

    my ($xtcDataPtr) = @_;

    my $indexSwitch;

    my $testGroup = ${$xtcDataPtr->{CURTESTGROUP}};

    $indexSwitch = 0;
    foreach my $switchIPAddress (@{$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchIP'}})
    {

        # Get the current Switch Record
        my $switchUsername  = ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchUsername'}}[$indexSwitch];
        my $switchPassword  = ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchPassword'}}[$indexSwitch];

        #
        # Login to the switch.
        #
        logInfo("Logging into switch $switchIPAddress...");
        my $switchObj = BSWLogInToSwitch($switchIPAddress, 
                                         $switchUsername,
                                         $switchPassword);
        if ( !defined($switchObj) )
        {
            logError("Failed to login to Brocade switch $switchIPAddress");
            return ERROR;
        }
       
        #
        # Show the zoning config for the current switch.
        # 
        logInfo("Preparing to show the switch zoning configuration...");         
        if ( BSWShowSwitchZoningConfig($switchObj) == ERROR )
        {
            logError("Failed to showing the zoning configuration for switch $switchIPAddress");
            return ERROR;
        }

        #
        # Logging out of the switch.
        #
        logInfo("Logging out of switch $switchIPAddress...");
        if (BSWLogOutOfSwitch($switchObj) == ERROR)
        {
            logWarning("Failed to logout of Brocade switch $switchIPAddress");
        }

        logInfo("\n");
        $indexSwitch++;
    }

    return GOOD;  
}


##############################################################################
#
#          Name: zoneswitches
#
#        Inputs: group name, zone string.
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Zones all switches in the specified VCG to the zones that
#                are specified in the zone string.
#
##############################################################################
sub zoneSwitchesInGroup
{
    trace();

    my ($testGroup, $zoneString, $xtcDataPtr) = @_;

    my $indexSwitch;
    #
    # Convert the current test argument to a numeric zone array.
    #
    my @zones = convertConfigZonesToZoneArray($zoneString);
    if ($zones[0] == INVALID)
    {
        logError("The zones that were specified are not in the correct format.  Example format: '1,2,3,4|0,4,5'.");
        return ERROR;
    }
    
    #
    # Loop through all switches and show the config for the ones in the given VCG
    #
    $indexSwitch = 0;
    foreach my $switchIPAddress (@{$xtcDataPtr->{SWITCHES}->{$testGroup}->{'brocade'}->{'switchIP'}})
    {
        # Get the current Switch Record
        my $switchUsername  = ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'vdisk'}->{'switchUsername'}}[$indexSwitch];
        my $switchPassword  = ${$xtcDataPtr->{SWITCHES}->{$testGroup}->{'vdisk'}->{'switchPassword'}}[$indexSwitch];

        #
        # Login to the switch.
        #
        logInfo("Logging into switch $switchIPAddress...");
        my $switchObj = BSWLogInToSwitch($switchIPAddress, 
                                         $switchUsername,
                                         $switchPassword);
        if ( !defined($switchObj) )
        {
            logError("Failed to login to Brocade switch $switchIPAddress");
            return ERROR;
        }
       
        #
        # Zone the switch.
        #
        logInfo("Zoning the switch...");
        my $ret = BSWZoneSwitch($switchObj, \@zones);
        if ($ret == ERROR)
        {
            logError("Failed to zone Brocade switch $switchIPAddress");
            return ERROR;
        }

        #
        # Logging out of the switch.
        #
        logInfo("Logging out of switch $switchIPAddress...");
        if (BSWLogOutOfSwitch($switchObj) == ERROR)
        {
            logWarning("Failed to logout of Brocade switch $switchIPAddress");
        }

        logInfo("\n");
        $indexSwitch++;
    }
    
    return GOOD; 
}


##############################################################################
#
#          Name: convertConfigZonesToZoneArray
#
#        Inputs: zone string from config file
#                Example string: "1,2,3|0,1,6|6,7,3", without quotes.
#
#       Outputs: zone array, Note: INVALID is the first element of the array
#                if the zone string was not in the correct format.
#
#   Description: Converts the specified zone string to a zone map array
#                that is recognizable by the Fibre library switch zoning
#                command.
#
##############################################################################
sub convertConfigZonesToZoneArray
{
    my $configZones = $_[0];    # Zone string from a config file.
    my @finishedZones;          # The zone array to return.

    my @commaZones = split /[|]/, $configZones;
    foreach my $commaZone (@commaZones)
    {
        #
        # Set the used ports hash to contain nothing.
        #
        my %usedPorts;
        while (my ($key, $value) = each %usedPorts)
        {
            delete($usedPorts{$key});
        }
        
        my $zone = 0;       # A numeric zone.
        my @ports = split /[,]/, $commaZone;
        foreach my $port (@ports)
        {
            if (!isInteger($port))
            {
                return (INVALID);    
            }


            if (!defined($usedPorts{$port}))
            {
                #
                # The port hasn't been used in this zone yet.
                #
                $zone += 2**$port;
                $usedPorts{$port} = $port;
            }
            else
            {
                logInfo("Port $port was used in zone $commaZone more than once.");
                return (INVALID);
            }
            
            #
            # Check to see if the number of commas corresponds to the number
            # of ports that should be present.
            #  
            if (getSpecifiedCharacterCount($commaZone, ",") != @ports - 1)
            {
                logInfo("The specified zone ($commaZone in $configZones) is not a comma separated list of ports");
                return (INVALID);    
            } 
          
        }
        push @finishedZones, $zone; 
    }
    
    return @finishedZones; 
}
##############################################################################
#
#          Name: ConnectMasterCCBE
#
#        Inputs: Controller Object List Array, Master controller pointer to update
#
#       Outputs: GOOD if successful, otherwise, ERROR.
#
#   Description: Finds the master in the array of IPs.  Connect to the master
#                and return the object for that logged in master
#                Note: a warning message is displayed if the master is not found
#
##############################################################################
sub ConnectMasterCCBE
{
    my ($controllerIPPtr, $masterObjPtr) = @_;

    my $ccbeConnection;
    my @ccbeList;
    my $returnMaster;
    my @controllerIPList;

    @controllerIPList = @$controllerIPPtr;

    # Loop through each IP address.
    foreach my $controllerIP (@controllerIPList)           
    {
        # Connect to the controller
        $ccbeConnection = TestLibs::IntegCCBELib::ccbe_connect ($controllerIP); # Get a CCBE connection & Login (IP Address)
        push @ccbeList, $ccbeConnection;
    }

    # Find the master controller
    $returnMaster = TestLibs::IntegCCBELib::FindMaster(\@ccbeList);
    if ($returnMaster == INVALID)
    {
        TestLibs::Logging::logError ("Master Controller not found in these IPs:@controllerIPList");
        return ERROR;
    }
    
#    TestLibs::Logging::logInfo ("Master Controller found in these IPs:@controllerIPList");

    for (my $index = 0; $index < scalar(@ccbeList); $index++)             
    {
        if ($index != $returnMaster) # Do not disconnect from the master, all others OK
        {
#                TestLibs::Logging::logInfo ("Disconnect from Controller Index:$index, Obj:$ccbeList[$index]");
                TestLibs::IntegCCBELib::ccbe_disconnect ($ccbeList[$index]);  # Disconnect from non-Master CCBEs            
        }
    }

    # Update the referenced master object;
    ${$masterObjPtr} = $ccbeList[$returnMaster];

    return GOOD;
}

###############################################################################

1;

=head1 CHANGELOG

 $Log$
 Revision 1.10  2006/05/31 12:09:10  AnasuriG
 removed duplicate call to ConfigiSCSITargetInfo subroutine

 Revision 1.9  2006/05/25 16:50:06  ElvesterN
 Removed diff markers

 Revision 1.8  2006/05/24 07:51:30  EidenN
 Moved from 750 Branch

 Revision 1.3.2.1  2006/02/24 14:17:25  MiddenM
 Merge from WOOKIEE_EGGS_GA_BR into MODEL750_BR

 Revision 1.7  2006/01/27 08:49:10  AnasuriG
 Added code for configuring CHAPINFO when parameters are passed from a station file in subroutine ictest

 Revision 1.6  2006/01/23 11:57:06  AnasuriG
 Removed commented lines and cosmetic changes

 Revision 1.5  2006/01/23 11:40:10  AnasuriG
 Updated ISCSISETINFO command to set all parameters and added subroutines for ISCSICHAPGETINFO and ISCSISTATS

 Revision 1.4  2006/01/16 14:59:48  EidenN
 Tbolt0000000:   Fixed disk group error when creating Vdisks for the SETUP script (CCBE path)

 Revision 1.35  2005/12/12 17:14:59  EidenN
 Tbolt000000:  Support for CCBE path when using the SETUP script.  Replaces scriptagent

 Revision 1.7  2006/01/27 08:49:10  AnasuriG
 Added code for configuring CHAPINFO when parameters are passed from a station file in subroutine ictest

 Revision 1.6  2006/01/23 11:57:06  AnasuriG
 Removed commented lines and cosmetic changes

 Revision 1.5  2006/01/23 11:40:10  AnasuriG
 Updated ISCSISETINFO command to set all parameters and added subroutines for ISCSICHAPGETINFO and ISCSISTATS

 Revision 1.4  2006/01/16 14:59:48  EidenN
 Tbolt0000000:   Fixed disk group error when creating Vdisks for the SETUP script (CCBE path)

 Revision 1.35  2005/12/12 17:14:59  EidenN
 Tbolt000000:  Support for CCBE path when using the SETUP script.  Replaces scriptagent

 Revision 1.3  2006/01/09 12:09:53  AnasuriG
 Added changes for creation of mirrors using option 55

 Revision 1.2  2005/11/14 11:49:58  AnasuriG
 Changes done as part of iSCSI scripting for Integration testing

 Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
 import CT1_BR to shared/Wookiee

 Revision 1.34  2005/01/11 17:14:59  EidenN
 Tbolt000000:  Section [ICON] added support to call SCRIPTAGENT ,  [Vdisks] Global Cache, Mirroring, Vdisk cache support added  Reviewed by: AllenK

 Revision 1.33  2004/11/10 15:43:30  EidenN
 Tbolt0000:  Fixed undefined calls

 Revision 1.31  2004/09/23 18:01:59  EidenN
 Tbolt0000: Added Vport Assignment to ICON scripting.  Vport is a required parm.  All profiles updated.  Reviewed by: STeve Fleming

 Revision 1.30  2004/05/19 15:52:41  EidenN
 Tbolt00000000:  Added diskgroup support for drive class.  Reviewed by Craig Menning

 Revision 1.29  2004/04/30 19:50:19  KohlmeyerA
 Tbolt00000000 - Modified shortWWN to be a hash of full WWN to allow checking of all bytes of WWN and made changes to handle the possiblity of a different controller becoming master when a controller is added to vcg.  Reviewed by Craig

 Revision 1.28  2004/01/06 22:47:41  VossO
 Tbolt00000000 Edit the file

 Revision 1.27  2003/11/25 18:56:43  VossO
 Tbolt00000000 changes made last time didn't get saved or checked in due to the mess with the name change

 Revision 1.26  2003/09/29 20:42:13  ThiemanE
 Changed names to be compatible with linux

 Revision 1.25  2003/09/26 22:43:02  ThiemanE
 Updated include library names to make them Linux compatible

 Revision 1.24  2003/09/23 16:47:23  TeskeJ
 tbolt00009173 - Release 3 test code changes
 rev by Olga

 Revision 1.23  2003/09/10 13:26:53  MenningC
 tbolt00000000: fix ictest menu, undace configs for n-way, improve 1 way support. reviewed by Olga

 Revision 1.22  2003/09/05 18:53:40  GrigorenkoO
 Tbol00000000 Changed call to version fuction

 Revision 1.21  2003/06/06 20:19:59  WerningJ
 Use TragetLookUp function for finding SIDs
 Reviewed by Craig M

 Revision 1.20  2003/05/29 12:55:19  WerningJ
 Rewrote all XTC data structures, added VLink support
 Reviewed by Craig M

 Revision 1.19  2003/04/15 14:55:00  WerningJ
 Removed the call to unreserve the XSSA in BFDump
 Reviewed by Craig m

 Revision 1.18  2003/04/15 14:36:15  MenningC
 tbolt00000000: move 600 and 3100 to constants; reviewed by JW

 Revision 1.17  2003/03/27 17:36:18  WerningJ
 Removed calls XMC disconnect which are no longer required
 Reviewed by Olga

 Revision 1.16  2003/03/26 21:27:30  WerningJ
 Cleaned Up Constants
 Added new functions for XSSA scripting
 Reviewed by Craig M

 Revision 1.15  2003/01/09 21:25:55  WerningJ
 Added Format Drive & All
 Reviewed by Craig M


=cut
