#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library - Mirror Resync tests
#
#   112/26/2002  XIOtech   Craig Menning
#
#   A set of library functions for integration testing. This set try to do
#   actions a user might do incorrectly.
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2002 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::Resync.pm - Test that stress Mirror Resync feature.

$Id: Resync.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL>
     <LI>Linux</LI>
     <LI>Windows</LI>
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing the robustness
of the design of the controller.



=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

            Resync1DscEntry()
            ResyncNDscEntry()

        The less significant ones

              <none>

=cut


#
# - what I am
#

package TestLibs::Resync;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use XIOTech::cmdMgr;
use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;
use TestLibs::UETestSupport;


#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - local Constants used
#

#use constant ALLCTLRS     => 17;
#use constant SINGLECTLR   => 18;
#use constant MASTERCTLR   => 19;
#use constant SLAVECTLR    => 20;
#use constant ALLSLAVES    => 21;

#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 4298 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &Resync1DscEntry
                        &ResyncNDscEntry


                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.

 $moxaPtr: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.

 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller.

 $retIn: This is a controle variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the
          attached servers. When configuring systems, this list determines
          which WWNs will be associated with vdisks. If an entry in this
          list is not found on the system, it will be ignored. A WWN
          found on the system that is not included in the list will not
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this
        is the pointer to that controller object. It is one of the
        members of the list that $coPtr points to.




=back

=cut


###############################################################################


###############################################################################



###############################################################################


##############################################################################
#
#               Private Functions, but made public for debug
#
##############################################################################

#############################################################################


###############################################################################

=head2 MRTestCase01 function

Orphaned RAID test. Deletes a vdisk during raid init. The test has these
basic steps...

     0) Houseclean system
     1) get a list of vdisks and raids
     2) create a vdisk and expand it several times
     3) start raid init on all the parts
     4) delete the vdisk
     5) look for orphaned raids
     6) repeat 2-5 for other raid types
     7) repeat 2-6 for different raid sizes
     8) clean up, if possible
     9) verify any existing I/O is still OK

=cut

=over 1

=item Usage:

 my $rc = MRTestCase01( $coPtr, $retIn, $snPtr   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 Any failures should come from orphaned raids (what the test is 
 looking for). Failure dure to I/O problems are not expected.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: MRTestCase01
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#
##############################################################################
sub MRTestCase01
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my %vdisks;
    my %raids;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;
    my @currentVdisks;

    my @raids;
    my @sizes;
    my @disks;
    my @vdisks;
    my $raid;
    my $pdskPtr;
    my $sIdx;
    my $rIdx;
    my $size;
    my $expSize;
    my $newVDD;
    my $i;
    my %ret;

    my $sps;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ UE Test Case 1: Delete a vdisk during raid init  ---------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # With a redi-CP running, fail one of the data pdisks.
    ######################################################################

    # setup - need to houseclean

    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
#    $ret = DefragAll($ctlr);
#    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );

    # system is 'packed' ready for the test
    logInfo("-------------- Setup complete for UE test case 1. ---------------------");



    #
    # Get the background data on the current list of raids and vdisks.
    # This info is in a vdisks packet. We will also need the raids
    # packet.
    #

    # - get the vdisks hash

    %vdisks = $ctlr->virtualDisks();
    if ( ! %vdisks  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
        return ERROR;
    }
    if ( $vdisks{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
        PrintError(%vdisks);
        return ERROR;
    }



    # - get the raids hash

    %raids = $ctlr->raids();
    if ( ! %raids  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $raids{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%raids);
        return ERROR;
    }

    logInfo("UE test 01: Initial raids");
    $msg = $ctlr->displayRaids( %raids);
    logInfo("\n".$msg);
            


    #
    # With both raids and vdisks hashes, we can verify that there are no
    # orphaned raids at the start of the test.
    #

    # - look for orphans
    
    logInfo("UE test 01: Initial orphan check");

    $ret = OrphanedRaidCheck( \%vdisks, \%raids );
    if ($ret != GOOD)
    {
        logInfo("Failed initial orphaned raids check.");
        return ERROR;
    }




    #
    # We need to work with different RAID types and sizes. This gives us
    # two nested loops, one for size and the other for RAID type. First,
    # we setup the data arrays to be used by the loops. We also need
    # to generate groups of pdisks to use, one data, one unsafes. 
    #

    # - raids array, the raid types to test
    @raids = ( RAID_5, RAID_10 );   # raids 5 and 10

    # - sizes array, the array of sizes to use
    @sizes = (100, 10000);

    # - get a disk set(s) to use - need DATA for raid 5/10
    @disks = GetDataDisks($ctlr, FC_PREFERRED);    
    if ( $disks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of data disks. <<<<<<<<");
        return ERROR;
    }


    # - get initial vdisks (these we don't init)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }

    #
    # Now do the loops that are the test
    #

    for ( $rIdx = 0; $rIdx < scalar(@raids); $rIdx++ )
    {
        
        #
        # this is the raids loop.
        #

        $raid = $raids[$rIdx];

        if ( $raid == RAID_5 )
        {
            $sps = 64;
        }
        else
        {
            $sps = 512;
        }
        
        #
        # Given the raid type, also pick the disk group to use.
        #


        # - select one disk group(safe/unsafe)
        $pdskPtr = \@disks;          # raid 5/10 only

        for ( $sIdx = 0; $sIdx < scalar(@sizes); $sIdx++ )
        {


            # - get initial vdisks (these we don't init)
            @vdisks = GetVdiskList( $ctlr );
            if ( $vdisks[0] == INVALID )
            {
                logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
                return ERROR;
            }


            logInfo(" ");
            logInfo("--------------------------------------------------------------------------");
            logInfo(" ");
        

            #
            # This is the size loop
            #

            $size = $sizes[$sIdx];
            $expSize =  $size * 2048;

            #
            # Indicate which iteration we are on
            #

            logInfo("UE test 01: Creating and expanding a vdisk using raid $raid, each raid $size mbytes.");
            logInfo(" ");
            logInfo("--------------------------------------------------------------------------");
            logInfo(" ");

            #
            # create the vdisk and initial raid
            #

            logInfo("UE test 01: Create using   ORPHAN, size= $size, raid= $raid, $sps, 2, 3 ");

            $newVDD = CreateSingleVdisk($ctlr, "ORPHAN", $size, $raid, $sps, 2, 3, $pdskPtr, undef);
            if ( $newVDD == INVALID )
            {
                logInfo ("failure creating new vdisk for test.");
                return ERROR;
            }

            #
            # Log the created vdisk number
            #

            logInfo ("Vdisk $newVDD was created.");

            #
            # now do several expansions
            #


            for ( $i = 0; $i < 5; $i++ )
            {
                
                #
                # we expand by the same amount
                #


                logInfo("Expanding vdisk $newVDD.");

                # vdisk expand
                %ret = $ctlr->virtualDiskExpand( $newVDD,     #  vdd to expand
                                                $expSize,     #  $capacity,
                                                $pdskPtr,     #  $pdPointer,
                                                $raid,        #  $rtype,
                                                $sps,         #  $stripe,
                                                2,            #  $depth,
                                                3 );          #  $parity);


                if ( ! %ret  )              # if no return from call
                {
                    logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
                    return ERROR;
                }

                if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
                {
                    logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
                    PrintError(%ret);

                    #
                    # if we run out of space, don't expand any more. Just
                    # ignore the failure and go on.  
                    # PI_ERROR_INS_DEV_CAP => 0x10;  # Insufficient device capacity
                    #
                    if (  $ret{ERROR_CODE} == 0x10 )
                    {
                        # ran out of space
                        last;
                    }
                    else
                    {
                        # other error
                        return ERROR;
                    }
                }



            }

            #
            # Indicate the expansions are done
            #

            logInfo("UE test 01: Expansions complete, starting raid inits.");


            #
            # Init all the (just created) raids
            #


            # - init newer raids - no wait
            $ret = InitNewerVdisks( $ctlr, \@vdisks );
            if ( $ret != GOOD ) 
            { 
                logInfo("Error starting inits on newer raids.");
                return ERROR; 
            }

            #
            # Now delete the vdisk. This should also take out
            # all the associated raids.
            #


                # - delete vdisk
            $ret = DeleteUnusedVdisks($ctlr);
            if ( $ret == ERROR )
            {
                logInfo("Failure deleting vdisks during inits");
            }

            #
            # Now the vdisk is gone and supposedly, all the raids.
            # Check to see if any inits are running and also check to 
            # see if any raids got orphaned. (There should be no
            # inits running and there should be no orphans.)
            #
            
                # - look for running inits, report and fail if found
  
                logInfo("UE test 01: Looking for any running raid inits.");
  
                # - get current  vdisks 
                @currentVdisks = GetVdiskList( $ctlr );

                if ( $currentVdisks[0] == INVALID )
                {
                    logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
                    return ERROR;
                }

                for( my $r = 0; $r < scalar(@currentVdisks); $r++)
                {
                    # if there is one initializing, then we have a failure
                    if ( 0 != CheckInitProgress($ctlr, $currentVdisks[$r] ) )
                    {
                        logInfo("Vdisk  $currentVdisks[$r] is still initializing.");
                        return ERROR;
                    }
                }

                # look for any rebuilds happening.

                logInfo("UE test 01: Looking for running rebuilds.");
                
                $ret = DegradeCheck( $ctlr);
                if ( $ret != GOOD )
                {
                    print "\n";
                    logInfo("One or more drives are degraded - test fails");
                    return ERROR;
                }




            # - look for orphans (need raids and vdisks hashes)
            # - get the vdisks hash

            %vdisks = $ctlr->virtualDisks();
            if ( ! %vdisks  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
                return ERROR;
            }
            if ( $vdisks{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
                PrintError(%vdisks);
                return ERROR;
            }



            # - get the raids hash

            %raids = $ctlr->raids();
            if ( ! %raids  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
                return ERROR;
            }
            if ( $raids{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from raids command <<<<<<<<");
                PrintError(%raids);
                return ERROR;
            }

            logInfo("UE test 01: Current raids");
            $msg = $ctlr->displayRaids( %raids);
            logInfo("\n".$msg);
            
            logInfo("UE test 01: Performing orphan check.");

            $ret = OrphanedRaidCheck( \%vdisks, \%raids );
            if ($ret != GOOD)
            {
                logInfo("Failed orphaned raids check after deletes.");
                return ERROR;
            }

            logInfo("UE test 01: Checks complete for this pass");

            # - Report problems and fail if any found


        }   # end of size loop


    }   # end of raid loop


    #
    # Now do a final I/O check. This should be good.
    #


    # verify IO
    logInfo("UE test 01: Confirm IO after test is done.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );

    if ($ret != GOOD)
    {
        logInfo("Failed I/O check at end of orphan test.");
        return ERROR;
    }


    logInfo("------------------------ End of UE test case 1. ----------------------");


    return GOOD;

}
###############################################################################
sub MRTestCase20
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 20, 0  );

    return $ret;
}

###############################################################################
###############################################################################
sub MRTestCase21
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 21, 1  );

    return $ret;
}

###############################################################################
###############################################################################
sub MRTestCase22
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 22, 2  );

    return $ret;
}

###############################################################################
###############################################################################
sub MRTestCase23
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;

    $ret = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 23, 3  );

    return $ret;
}

###############################################################################
###############################################################################
sub MRTestCase24
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 24, 17  );

    return $ret;
}

###############################################################################
###############################################################################
sub MRTestCase25
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 25, 18  );

    return $ret;
}

###############################################################################
###############################################################################
sub MRTestCase26
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 26, 33  );

    return $ret;
}

###############################################################################
sub MRTestCase27
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 27, 34  );

    return $ret;
}

###############################################################################
sub MRTestCase28
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 28, 49  );

    return $ret;
}
###############################################################################
sub MRTestCase29
{
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;
    my $ret;


    $ret = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, 29, 50  );

    return $ret;
}
###############################################################################
###############################################################################


=head2 MRTestCase2x function

This test case sends Loop Primitive option 0 to all devices on the BE loop.

Loop Primitive option 0 is  LIP Reset loop = LIP(FF,al_ps)

The test has these
basic steps...
    1) initial startup stuff
    2) Identify list of LID to work on.
    3) LIP each one, wait ?? seconds between each LIP
    4) Check I/O
    5) Any other validation
    6) LIP each one, wait ?? seconds between each LIP
    7) Check I/O
    8) do any other validation




=cut

=over 1

=item Usage:

 my $rc = MRTestCase2x( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMean  );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serian numbers - unused
        $loopCount determines how many test loops are done
        $pDFailMean - unused

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.

 Here is the CCBE command we use.

      LOOPPRIMITIVE  processor  option  id  port  lid

        processor      Issue primitive to: FE|BE
        option         options -
                          0 - LIP Reset loop       = LIP(FF,al_ps)
                          1 - LIP Reset lid port   = LIP(al_pd,al_ps)
                          2 - LIP Reset sid or pid = LIP(al_pd,al_ps)
                          3 - Initiate LIP         = LIP(F7,al_ps)
                         17 - Login lid
                         18 - Login pid
                         33 - Logout lid
                         34 - Logout pid
                         49 - Target Reset lid
                         50 - Target Reset pid
                         65 - Loop Port Bypass (LPB) lid
                         66 - Loop Port Bypass (LPB) pid
                         81 - Loop Port Enable (LPE) lid
                         82 - Loop Port Enable (LPE) pid
                         Test modes below valid until next RESCAN LOOP
                         241 - Port bypass test lid
                         242 - Port bypass test pid
        id             pid (BE) or sid (FE)
        port           port
        lid            loop id



=back

=cut

##############################################################################
#
#          Name: MRTestCase2x
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCounts
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub MRTestCase2x
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans, $tcNum, $lprim ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my $loops = 1;
#    my $newVd;


    if ( $loopCount )
    {
        $loops = $loopCount;
    }

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ UE Test Case $tcNum: Loop Primitive option $lprim on all BE devices.  --------";
    $msg0 = "------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

#    1) initial startup stuff









    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);



    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }

    #
    # get the initial active vdisks for the test
    #

    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    #
    # 2) Identify list of LID to work on.
    # Get a list of LIDs on each port for each controller in the group.
    # Each list item is a hash with the controller, lid, and port as 
    # elements. These will be used in a later call.
    #

    my @lids;
    
    $ret = GetBELids($coPtr, \@lids);
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>>>>>>>>>  Failure getting a list of LIDs fo the test. <<<<<<<<");
        return ERROR; 
    }


    ######################################################################
    # loops to LIP the BE devices.
    ######################################################################


    #
    #  3) LIP each one, wait 20 seconds between each LIP
    # First we do this rather slowly and not for many loops. Most of the 
    # fcn parms are set here, then changed as neede for the later call.
    #
    my $delay = 20;
    my $flags = ALLCTLRS;
    my $parm = 0;

    $ret = LoopPrimUsingList($coPtr, $lprim, \@lids, $loops, $delay, $flags, $parm );
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>>>>>>>>>  Error during loop primitives. <<<<<<<<");
        return ERROR; 
    }


    
    #
    #    4) Check I/O
    #
    logInfo("Verify IO after first set of loop primitive option $lprim. ");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>> I/O validation failed after first set of loop primitive option $lprim <<<<");
        return ERROR; 
    }



    #    5) Any other validation


    #
    #    6) LIP each one, wait ?? seconds between each LIP
    # This one is faster (we'll see what can be tolerated by the system)
    #
    $delay = 5;
    $ret = LoopPrimUsingList($coPtr, $lprim, \@lids, $loops, $delay, $flags, $parm );
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>>>>>>>>>  Error during loop primitives. <<<<<<<<");
        return ERROR; 
    }



    #
    #    7) Check I/O
    #
    logInfo("Verify IO after first set of loop primitive option $lprim. ");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) 
    { 
        logInfo(">>>> I/O validation failed after second set of loop primitive option $lprim <<<<");
        return ERROR; 
    }

    #
    #    8) do any other validation
    #

#add code here

    #   10) Verify IO


    logInfo("End of UE stress test case $tcNum.");


    return GOOD;

}
###############################################################################



###############################################################################

=head2 MRTestCase03 function

This test case observes what happens when the master moves while doing a 
defrag. Initially there will be not fail criteria, other than making sure
each command sent to the controllers is successful. Once the FW design
stabilizes in this area, then a failure mechanism may be added.




=cut

=over 1

=item Usage:

 my $rc = MRTestCase03( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMean  );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serian numbers - unused
        $loopCount determines how many test loops are done
        $pDFailMean - unused

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 The test will appear to hang after the mastership changes. The test will
 be waiting to see if defrag restarts or not.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.

 There must be no ICON connection to the controllers.


=back

=cut

##############################################################################
#
#          Name: MRTestCase03
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCounts
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub MRTestCase03
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ret;
    my $ret2;
    my @oldVds;
    my $i;
    my $newVd;
    my $loop;
    my $mIdx;
    my $sIdx;
    my @living;
    my $timeOut;
    my %rsp;
    my @newVds;
    my $elStateM;
    my $newMaster;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg = "------ UE Test Case 3: Change master during a defrag ------";
    $msg0 = "---------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);



    # get measure of the current IO



    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }




    ###################################################################### 
    # delete all inactive vdisks, defrag. This essentially packs the disk.
    # and pack the IO.
    ######################################################################

    #####################
    # clean up the system
    #####################

    # delete them
    $ret = DeleteUnusedVdisks( $ctlr, 0 );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }
    

    # defrag all pdisks
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }


    # verify IO
    logInfo("I/O check after system cleaned up/before actual test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    ########################
    # make holes for defrag
    ########################


    # find the first 5 early vdisks
    @oldVds = FindEarlyVdisk( $ctlr, 5 );     # find  vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # create 5 vdisks for copies
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $newVd =  CreateReplacementVdisk($ctlr, $oldVds[$i] );
        if ( $newVd < 0 ) { return ERROR; }
        $newVds[$i] = $newVd;
        #push ( @newVds, $newVd);
    }

    # do 5 redicp operations
    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {
        $ret = RediCpVdisks($ctlr, $oldVds[$i], $newVds[$i]  );
        if ( $ret != GOOD ) { return ERROR; }
    }

    for ( $i = 0; $i < scalar( @oldVds); $i++ )
    {

        $ret = WaitForCpComplete( $ctlr, $newVds[$i] );
        if ( $ret != GOOD ) { return ERROR; }
    }

    # delete the source vdisks
    for ($i = 1; $i < scalar( @oldVds); $i++ )
    {
        logInfo("Deleting $oldVds[$i]");
        if ( ERROR == DeleteSingleVdisk($ctlr, $newVds[$i]) ) 
        {
            return ERROR;
        }
    }

    ######################################################
    # now start the defrag (all) operation on the master
    ######################################################



    $ret = DefragAllBegin($ctlr);
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to start defragAll. <<<<<<<<");
        return (ERROR);
    }

    

    ############################################################
    # now start the loop that moves the master (defrag running)
    ############################################################


    for ( $loop = 0; $loop < $loopCount; $loop++ )
    {

        #
        # identify the master, get a random slave
        #
        ($mIdx, $sIdx) = FindMasterPickSlave($coPtr);

        if ( ($mIdx == INVALID) || ($sIdx == INVALID) )
        {
            logInfo("Failure getting master and selecting a slave.");
            return ERROR;
        }

        #
        # Get list of current controllers
        #

        $ret = GetOperationalIPs($coPtr, $mIdx, \@living);
        if ( $ret != GOOD )
        {
            logInfo("Unable to get a list of operational contollers - failure");
            return ERROR;
        }

        #
        # ping each controller in group, see if defrag still running
        # ping satisfied by the defrag check
        #
        $timeOut = 30;

# the is a new function to be written
        $ret = IsDefragReallyRunning($coPtr, \@living, $timeOut );
# figure out what to do here


        #
        # wait 45 seconds
        #
        DelaySecs(45);

        #
        # start election on slave
        #
        $ctlr = $$coPtr[$sIdx];

        %rsp = $ctlr->genericCommand("ELECTION", 0 );

        # see how the start of the election went

        if (!%rsp)                        # no response
        {
            logInfo(">>>>>>>> Failed to receive a response from ELECTION start <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} == 1)            # 1 is bad
        {
            logInfo(">>>>>>>> Failed: starting an election returned an error <<<<<<<<");
            PrintError(%rsp);
            logError("Failure in test");
            return ERROR;
        }


        #
        # wait for election to complete
        #
        $elStateM = 0;

        # loop getting state and printing changes until election finishes
        while ( $elStateM != 0 )
        {
            ##
            # get the master's election state
            ##
            %rsp = $ctlr->vcgElectionState();

            # see how getting the master's status went
            if (!%rsp)                        # no response
            {
                logInfo(">>>>>>>> Failed to receive a response from ELECTION status <<<<<<<<");
                return ERROR;
            }

            if ($rsp{STATUS} == 1)            # 1 is bad
            {
                logInfo(">>>>>>>> Failed: getting election status returned an error <<<<<<<<");
                PrintError(%rsp);
                logInfo("Failure in elections test");
                return ERROR;
            }

        }

        #
        # see who the master is now
        #
        $newMaster = FindMaster($coPtr);
        
        $msg = "UEtest03 Result: Mastership change from $mIdx to ";
        $msg .= "$newMaster. Election run from $sIdx.";
        logInfo $msg;
    

        #
        # see what happens over next (up to) 10 minutes
        #
#THis is a new function to look to see if a defrag is running and if so, log and bail if not, timeout and 
# go on.
        $ret = DefragMonitor($coPtr, \@living, 600);


        #
        # check I/O , make sure it is still OK
        #
        logInfo("I/O check after attempted mastership change.");
        $ret2 = VerifyIO( $coPtr,
                         \@activeServers, 
                         \@tMap, 
                         \@initialVdisks,
                         $snPtr
                       );

        if ( $ret2 != GOOD ) { return ERROR; }


        #
        # See if we still need to defrag
        #
        $ret2 = CheckSosTables( $coPtr,  ISFRAGMENTED );     # look for ??? state
 #       if ( $ret != GOOD ) { do the right thing }

        #
        # if defrag needed, re-start defrag
        #

        if ( ($ret2 == GOOD) && ($ret != GOOD)  )
        {
            
            # note: this will log what happened, but at this level we don't know
            # what did happen
            $ret = DefragAllBegin( $$coPtr[$newMaster]);
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> Failed to start defragAll. <<<<<<<<");
                return (ERROR);
            }
       }

            #
            # record response to defrag start
            #
# was it started, or already running, etc.
    }



    #
    # See if we still need to defrag
    #
    $ret = CheckSosTables( $coPtr, (ISFRAGMENTED) );     # look for ??? state
#    if ( $ret != GOOD ) { do the right thing }

    #
    # if defrag needed, re-start defrag
    #
    if ($ret == GOOD )
    {
        $ret = IsDefragReallyRunning($coPtr, \@living, 15 );

        #
        # If running, log message and exit
        #
        if ( $ret != DEFRAGGING )
        {
            $ret = DefragAllBegin($$coPtr[$newMaster]);
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> Failed to start defragAll. <<<<<<<<");
                return (ERROR);
            }
            sleep(15);
        }
    }
    
    
    
        #
        # record response to defrag start (already done)
        #

   #
   # wait for defrag to end
   #
    # wait for something to start

    # now wait for the defrags to end

    $ret = DefragWait( $$coPtr[$newMaster] );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed waiting for defrags to end. <<<<<<<<");
        return (ERROR);
    }






    # verify IO
    logInfo("I/O check at end of test.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers, 
                     \@tMap, 
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $ret != GOOD ) { return ERROR; }

    # check SOS tables

    $ret = DispSOSTables( $$coPtr[$newMaster] );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );     # look for ??? state
    if ( $ret != GOOD ) { return ERROR; }



    logInfo("End of UE test case 03.");

    
    return GOOD;

}

###############################################################################

=head2 MRTestCase04 function

This test case creates, expands, initializes vdisks. Different raid types
and drive types are used.

It has these basic steps...
    1) initial startup
    2) create a vdisk
    3) expand it a couple of times
    4) init it
    5) delete it

    repeat 2-5 using different raid and pdisk types






=cut

=over 1

=item Usage:

 my $rc = MRTestCase04( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done
        $pDFailMeans in unused

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: MRTestCase04
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
##############################################################################
sub MRTestCase04
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
#    my $newVd;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ UE Test Case 4: various create, expand an inits.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);



    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }

    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # loops to LIP the BE cards.
    ######################################################################


#add code here

    #   10) Verify IO

    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 7.");


    return GOOD;

}
###############################################################################
###############################################################################

=head2 MRTestCase51 function

This test case just prints mirror information for field use





=cut

=over 1

=item Usage:

 my $rc = MRTestCase51( $coPtr );

 where: $coPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: MRTestCase51
#
#        Inputs: $coPtr
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: List mirror info
#
#                LIPs the BE loops
#
#
#
#
#
#
##############################################################################
sub MRTestCase51
{
    trace();
    my ( $coPtr ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $master;
    my @coList;
    my $ctlr;
    my $i;
    my %rsp;
    my $ret;
    my $msg0;

    $msg = "------ Test Case 51: List Mirror Information  --------";
    $msg0 = "------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    @coList = @$coPtr;

    $ctlr = $coList[$master];


    %rsp = $ctlr->virtualDisks();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }


    $msg = "";
    
    $msg .= sprintf( "Virtual Disk Mirror Information\n");
    $msg .= sprintf(  "\n");




    $msg .= "                                                                    SOURCE   SEC COPY\n";
    $msg .= " VID    SCDHEAD       SCDTAIL   MIRROR State     MIRROR ATTRIBUTES     VID    % COMP    OWNER    NAME\n";
    $msg .= " ---    -------     ----------  ------------  --------------------  -------  --------   -----  --------\n";

    my $mText;
    my $aText;
    
    for ( $i = 0; $i < $rsp{COUNT}; $i++)
    {
        
        #
        #        .set    vdnomirror,0            # 00 # no mirror active
        #        .set    vdcopyto,1              # 01 # Sec. copy destination
        #        .set    vdcopymirror,2          # 02 # Sec. copy mirror
        #        .set    vdcopyuserpause,3       # 03 # copy user paused
        #        .set    vdcopyautopause,4       # 04 # copy auto paused
        #
        $mText = "unknown: $rsp{VDISKS}[$i]{MIRROR} ";
        if ( $rsp{VDISKS}[$i]{MIRROR} == 0 ) { $mText = "          "; }
        if ( $rsp{VDISKS}[$i]{MIRROR} == 1 ) { $mText = "Copying   "; }
        if ( $rsp{VDISKS}[$i]{MIRROR} == 2 ) { $mText = "Mirrored  "; }
        if ( $rsp{VDISKS}[$i]{MIRROR} == 3 ) { $mText = "User Pause"; }
        if ( $rsp{VDISKS}[$i]{MIRROR} == 4 ) { $mText = "Auto Pause"; }

        
        # --- this mask assumes that the CCB will not modifiy the following 
        #     attribute bits.
        #                       0x0008  suspend
        #                       0x0010  device is destination of copy
        #                       0x0020  device is source of copy
        #                       0x0040  vlink lock flag
        #                       0x0080  vlink flag
        $aText = "";
        if ( $rsp{VDISKS}[$i]{ATTR} ==  0 ) { $aText = "No Mirror"; }
        if ( $rsp{VDISKS}[$i]{ATTR} &   8 ) { $aText .= "Susp "; }
        if ( $rsp{VDISKS}[$i]{ATTR} &  16 ) { $aText .= "Dest "; }
        if ( $rsp{VDISKS}[$i]{ATTR} &  32 ) { $aText .= "Src "; }
        if ( $rsp{VDISKS}[$i]{ATTR} &  64 ) { $aText .= "Lock "; }
        if ( $rsp{VDISKS}[$i]{ATTR} &  128) { $aText .= "Vlink "; }
        
        
        $msg .= sprintf( " %3hu    0x%8.8x  0x%8.8x    %10s  %20s  %7d   %7d    0x%2.2x  %s\n", 
                $rsp{VDISKS}[$i]{VID},
                $rsp{VDISKS}[$i]{SCHEAD},
                $rsp{VDISKS}[$i]{SCTAIL},
                $mText,
                $aText,
                $rsp{VDISKS}[$i]{SCORVID},
                $rsp{VDISKS}[$i]{SCPCOMP},
                $rsp{VDISKS}[$i]{OWNER},
                $rsp{VDISKS}[$i]{NAME});
    }

    $msg .= sprintf( "\n");


    logInfo($msg);








    logInfo("End of UE stress test case 51.");


    return GOOD;

}
###############################################################################



###############################################################################
#
#    Additional test cases 
#
#    Mostly Write Cache related ---
#
#    1) Turn on and off cache repeatedly while running I/O. Do this 
#       slowly at first, then much faster. (Attempt to overlap on/off
#       requests.)
#    2) Failover with cache enabled. Do we want a cache on and cache off
#       set of test cases, or a wrapper on failover that can also make 
#       sure we restore cache to the original setting.
#    3) Rolling code updates with cache on. Write a ccbe script that 
#       emulates RCU on the ICON. (Or calls the ICON scripting.)
#    4) Cache on, do redi copies, swaps, mirrror, etc
#    5) with cache on make/break vlinks (needs a vlink test library)
#    6) enable cache on the destination of a vlink (needs a vlink test
#       library)
#    7) Update failover to handle case were caching is on and the
#       failover would trash both copies of the cache. (Do not fail
#       adjacent controllers simultaneously when cache is on.) Use the
#       mirror partner list when determining what to fail.(Is this the 
#       same as vcgmplist? If so, make it a flag passed to WhatToFail() )
#    8) Ctlr fails, battery dies, another controller has posted the data,      
#       ctlr comes online, checks other controller for the data. Not really
#       good to script, but should be done manually.
#
#
#
#    11) Enable cache, fail controller, verify cache is now off, unfail controller
#        verify cache now on. (determine response in n-way environement
#    12) Characterize, observe cache behavior in a Rolling Code Update
#        environment
#    13) Cache integrity thru a power cycle of all controllers. This does a
#        number on the I/O that will be running. Look at errors logged by the 
#        controllers. (also look at events)
#    14) Turn cache off and on multiple times, verify that caching state on
#        each vdisks ate each on or off cycle. Verify that only the correct 
#        vdisks turn on/off cache.
#    15) Look at cache statistics, verify correct change as cache is 
#        enabled/disabled and during and after a failover/ failback cycle.
#    16) Power off a controller, wait a while, power on, Observe the 
#        charging of the battery (env statistics) and when cache turns 
#        back on. Do this for cases where the the controller is unfailed
#        immediately and unfailed after some delay. Need to look at cache
#        state of all controllers in the CNC. (Output is some sort of
#        timeline?)
#    17) Check ability to enable/disable cache on the slaves as well as 
#        he master controller.
#    18) Observe effect of failing the cache partner of a controller. 
#        Does the LUN owner disable cache of the partner fails?
#    19) In an N-way. Fail the lun owner, see who picks up the LUNs and 
#        does the cache partner change?
#    20) Is cache re-enable after failback manual or automatic? (Affects 
#        test cases)
#    21) Look at statsvdisks to determine if cache is on or off and the 
#        apparent performance change. Assuming consistant I/O load this
#        may be a good metric.
#    22) Try to make a vdisk with some SATA raids and some FC raids. How
#        does cache behave?    See #9.
#    23) Make a timeline of events as cache is turned off. (Assuming 
#        it takes more than a second or two to turn off cache.)
#
#
#    Non-write cache related ones ----
#
#    9) Build a vdisk with fc drive, expand using sata drives, is this a
#       performance solution or not.
#    10) Start a defrag, start it again(fails), stop defrag, restart.
#
#    23) A test for messed up target mapping. Map more than 8 luns to a 
#        target, then do a config change (of the right type) and confirm that
#        the target mappings are still valid on all controllers. This needs 
#        to have both a test and a callable function for the validation.
#
#
#    24) (DONE) Loop Primitive, option 0 on all pdisks. Loop thru all devices slow
#               and fast. Check that I/O survives.
#    25) (DONE) Loop Primitive, option 1 on all pdisks. Loop thru all devices slow
#               and fast. Check that I/O survives.
#    26) (DONE) Loop Primitive, option 2 on all pdisks. Loop thru all devices slow
#               and fast. Check that I/O survives.
#               (One of the above should LIP every device.)
#
#    27) Delete a vdisk during
#                   raid init      see Integccbelib::CreateExpandInitDelete
#                   rebuild
#                   redi-copy      see Defrag case 2
#                   defrag         see Dafrag Case 2
#                   parity scan
#                   cache off and cache on cases for all
#
#        Some of these may already be done, but the test should do the 
#        delete on a vdisk unrelated to the activity, and on one related
#        to the activity. If there are two related vdisks, the delete
#        delete should be done to each one separately. SOme deletes
#        will break the operation, some won't. None should trash the
#        controlleer or I/O. (within reason)
#
#    28) Add vdiskmove to the regression tests.
#    29) Test to validate an expanded raid
#              Time to come ready
#              Size inreases as expected
#              Init completes
#        Check each raid type, and on FC and SATA drives.
#
#
#
###############################################################################
###############################################################################


###############################################################################




###############################################################################


###############################################################################


###############################################################################
###############################################################################


###############################################################################

=head2 MRTestCaseX function

This test case repeatedly LIPs the BE qlogic cards.
The test has these
basic steps...






=cut

=over 1

=item Usage:

 my $rc = MRTestCaseX( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: MRTestCaseX
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                LIPs the BE loops
#
#
#
#
#
#
##############################################################################
sub MRTestCaseX
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
#    my $newVd;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 7: Lots of LIPs on the BE Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    @coList = @$coPtr;

    $ctlr = $coList[$master];

    DispVdiskInfo($ctlr);



    # get measure of the current IO


    @vCounts = GetVdiskActivityCounts($coPtr);

    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }

    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }


    ######################################################################
    # loops to LIP the BE cards.
    ######################################################################


#add code here

    #   10) Verify IO

    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("End of BE stress test case 7.");


    return GOOD;

}
###############################################################################




###############################################################################


###############################################################################

=head2 Resync1DscEntry function

The primary entry point for the Bigfoot Mirror resync tests.

A function used for debugging the code as a generic entry. The final
parameter represents the test case to be run. A test case of 99 will
run most tests sequentially. There is no guarantee that the tests can actually
run sequentially and give full coverage.

The test system should be configured as desired and IO from the
servers should be running. Most likely this will mean a two-way system.
IO from the servers needs to be consistent over time or the IO validation
checks may fail. For the most part, RAIDs should be redundant as many tests
will fail pdisks and require rebuilds. The test will hang if a drive
becomes permanently degraded.

Tests can be run individually by specifying the test case number. ( 1...25+)
Not all test case numbers exist ( the list is not contiguous). Specifying
an invalid number just means no test will be run. Test case 99 will run most
test cases sequentially. Test that are designed to cause a fatal condition
will not be part of the 99 sequence.

Some test require a minimum of a 2 way configuration, others will run on
1-way or n-way configurations.

Refer to the individual test cases for more information on the
individual tests.

=cut

=over 1

=item Usage:

 my $rc = Resync1DscEntry($coPtr, $moxaPtr, $mmPtr, $parmsPtr, $spare );

 where: $coPtr is a pointer to a list of controller objects
        $moxaPtr is a pointer to a list of Moxa controller IP addresses
        $mmPtr is a pointer to a list of tha Moxa channel mappings
        $parmsPtr is a pointer to a test parms hash
        $spare is an extra item, not used
=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the test(s)
           ran to completion without error. Test logs must be reviewed to
           ensure the test ran correctly.



=back

=cut


##############################################################################
#
#          Name: Resync1DscEntry
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:
#
##############################################################################
sub Resync1DscEntry
{
    trace();
    my ( $coPtr,  $moxaIP, $mmPtr, $parmsPtr, $dummy ) = @_;

    my $ret;
    my $case;
    
    $case = $parmsPtr->{testcase}; 
    
    #
    # Note: there are some loines referring to loop counts. This may not 
    # be relevant for resync. If not used, they may be removed. For Defrag
    # BEStress they were used.
    #
    
    
    my $autoLoop;
    my $loopCount = 0;

    $autoLoop = 0;
    $ret = GOOD;

    if ( defined($parmsPtr->{loopcount} ) )
    {
        $loopCount =  $parmsPtr->{loopcount};
    }   

    my @coList = @$coPtr;

    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "                starting MRTest Case $case. ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
 #   DelaySecs(300);

    StatsProcAll($coPtr);

    if ( !$loopCount )
    {
        logInfo("LoopCount was not specified, default values will be used.");
        $autoLoop = 1;
    }

    if ( $case == 99 )
    {
        logInfo("All test cases selected, default loop count values will be used.");
        $autoLoop = 1;
    }


    #
    # You will need to add tests case calls here as you add test cases. The 99/all
    # case does not need to apply to all cases. However if it is applied to a test case, 
    # then the test cases need to support one test following another. Mainly this means 
    # that test cases may need to 'clean up' the system before they actually run.
    #
    # You'll also need to determine what parameters each test will take.
    #


    if ( $case == 1  || $case == 99 ) { $ret = MRTestCase01( $coPtr, GOOD, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 3  || $case == 99 ) { $ret = MRTestCase03( $coPtr, GOOD, $parmsPtr, 5, 0 ); }
    if ( $ret != GOOD ) { return $ret; }


    # loop primitive group
    if ( $case == 20 || $case == 99 ) { $ret = MRTestCase20( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 21 || $case == 99 ) { $ret = MRTestCase21( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 22 || $case == 99 ) { $ret = MRTestCase22( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 23 || $case == 99 ) { $ret = MRTestCase23( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 24 || $case == 99 ) { $ret = MRTestCase24( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 25 || $case == 99 ) { $ret = MRTestCase25( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 26 || $case == 99 ) { $ret = MRTestCase26( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 27 || $case == 99 ) { $ret = MRTestCase27( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 28 || $case == 99 ) { $ret = MRTestCase28( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 29 || $case == 99 ) { $ret = MRTestCase29( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    #-----------------




    StatsProcAll($coPtr);
    #PeriodicDataGather($coPtr);

    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
    CtlrLogTextAll( $coPtr, "           MRTest Case $case ends. ");
    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
#    DelaySecs(300);

    return $ret;

}
###############################################################################

=head2 ResyncNDscEntry function

The primary entry point for the Bigfoot UE tests.

A function used for debugging the code as a generic entry. The final
parameter represents the test case to be run. A test case of 99 will
run most tests sequentially. There is no guarantee that the tests can actually
run sequentially and give full coverage.

The test system should be configured as desired and IO from the
servers should be running. Most likely this will mean a two-way system.
IO from the servers needs to be consistent over time or the IO validation
checks may fail. For the most part, RAIDs should be redundant as many tests
will fail pdisks and require rebuilds. The test will hang if a drive
becomes permanently degraded.

Tests can be run individually by specifying the test case number. ( 1...25+)
Not all test case numbers exist ( the list is not contiguous). Specifying
an invalid number just means no test will be run. Test case 99 will run most
test cases sequentially. Test that are designed to cause a fatal condition
will not be part of the 99 sequence.

Some test require a minimum of a 2 way configuration, others will run on
1-way or n-way configurations.

Refer to the individual test cases for more information on the
individual tests.

=cut

=over 1

=item Usage:

 my $rc = ResyncNDscEntry($coPtr, $retIn, $snPtr, $moxaPtr, $mmPtr, $case );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaPtr is a pointer to a list of Moxa controller IP addresses
        $mmPtr is a pointer to a list of tha Moxa channel mappings
        $case is the test case to run

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the test(s)
           ran to completion without error. Test logs must be reviewed to
           ensure the test ran correctly.



=back

=cut


##############################################################################
#
#          Name: ResyncNDscEntry
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:
#
##############################################################################
sub ResyncNDscEntry
{
    trace();
    my ( $coPtr, $moxaIP, $mmPtr, $parmsPtr, $dummy ) = @_;

    my $ret;
    my $case;
    
    $case = $parmsPtr->{testcase}; 
    
    my $loopCount = 0;
    my $autoLoop;

    $autoLoop = 0;
    $ret = GOOD;

    if ( defined($parmsPtr->{loopcount} ) )
    {
        $loopCount =  $parmsPtr->{loopcount};
    }   


    my @coList = @$coPtr;

    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "                starting MRTest Case $case. ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
 #   DelaySecs(300);
 
 
    #
    # I suggest that you print out the data passed into the function here so 
    # can verify the parameters were what you expected to see. (Just for debugging
    # the code)
    #
 
 
    # This is here for additional data collection and may not be needed for resync
    StatsProcAll($coPtr);   

    if ( !$loopCount )
    {
        logInfo("LoopCount was not specified, default values will be used.");
        $autoLoop = 1;
    }

    if ( $case == 99 )
    {
        logInfo("All test cases selected, default loop count values will be used.");
        $autoLoop = 1;
    }


    if ( $case == 1  || $case == 99 ) { $ret = MRTestCase01( $coPtr, GOOD, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 3  || $case == 99 ) { $ret = MRTestCase03( $coPtr, GOOD, $parmsPtr, 5, 0 ); }
    if ( $ret != GOOD ) { return $ret; }


    # loop primitive group
    if ( $case == 20 || $case == 99 ) { $ret = MRTestCase20( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 21 || $case == 99 ) { $ret = MRTestCase21( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 22 || $case == 99 ) { $ret = MRTestCase22( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 23 || $case == 99 ) { $ret = MRTestCase23( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 24 || $case == 99 ) { $ret = MRTestCase24( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 25 || $case == 99 ) { $ret = MRTestCase25( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 26 || $case == 99 ) { $ret = MRTestCase26( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 27 || $case == 99 ) { $ret = MRTestCase27( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 28 || $case == 99 ) { $ret = MRTestCase28( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 29 || $case == 99 ) { $ret = MRTestCase29( $coPtr, GOOD, $parmsPtr, 1, 0 ); }
    if ( $ret != GOOD ) { return $ret; }

    #-----------------




    # This is here for additional data collection and may not be needed for resync
    StatsProcAll($coPtr);
    #PeriodicDataGather($coPtr);

    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
    CtlrLogTextAll( $coPtr, "           MRTest Case $case ends. ");
    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
#    DelaySecs(300);

    return $ret;

}



##############################################################################
#
#          Name: Support Functions
#
#  These are probably not exported.
#
##############################################################################

###############################################################################


###############################################################################


###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################


###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################




###############################################################################



###############################################################################





###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################

###############################################################################


##############################################################################


1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.1  2005/05/04 18:53:52  RysavyR
# Initial revision
#
# Revision 1.1  2004/11/08 14:54:31  MenningC
# tbolot00000000: new files for resync, wrtcache and wookiee specific tests, reviewed by Dave P.
#
# Revision 1.2  2004/09/02 21:20:54  KohlmeyerA
# Tbolt00000000:  Broke UETest up into separate UETest and UETestSupport files.
# Reviewed by Craig.
#
# Revision 1.1  2004/07/12 15:28:55  MenningC
# tbolt00000000: new file for orphan raids test.  reviewed by Al
#
#
#
#
##############################################################################
