#! /usr/bin/perl -w
# $Id: BaseRegression.pm 50074 2008-04-29 11:57:56Z gopinadh_anasuri $
##############################################################################
#  
#   CCBE Integration test library - Base Regression tests
#
#   1/5/2004  XIOtech  Randy Rysavy
#
#   A set of library functions for integration testing. This set is
#   a basic regression test suite.
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2004 - 2008 Xiotech Corporation. All rights reserved.
#
#   For Xiotech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::BaseRegression - Perl Tests to test basic regression

$Id: BaseRegression.pm 50074 2008-04-29 11:57:56Z gopinadh_anasuri $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions to do basic regression testing of the 
controller.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

            BaseRegression1Way() 
            QLResets() 
              
        The less significant ones

              <none>

=cut


#                         
# - what I am
#

package TestLibs::BaseRegression;

#
# - other modules used
#

use warnings;
use strict;
use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;

use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :CCBE :BASE_REGRESSION);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::Validate;
use TestLibs::defrag;
use TestLibs::iscsi;

#
# - local Constants used
#


#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 50074 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker


# PUT CONSTANTS IN CONSTANTS.PM!!!

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        BaseRegressionNWay
                        QLResets
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 50074 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
#
#

###############################################################################

=head2 BaseRegressionNWay

This test case runs a basic regression test across 1-N conrollers
The test has these basic steps...

    1) If -v: passed in, MfgClean all controllers
    2)        label all drives as requested
    3)        create the N-way
    4) Run regression test suite the requested number of times
    5) Delete the vdisks that were created during the testing

=cut

=over 1

=item Usage:

 my $rc = BaseRegressionNWay($coPtr, $crtVCG, $dataDrvs, $unSfDrvs, $hotSpDrvs, $loopCount, $flags);
 
 where:  $coPtr     - ptr to a list of controller objects
         $crtVCG    - If != 0, creates the vcg (else runs with current cfg)
         $dataDrvs  - count of data drives to create
         $unSfDrvs  - count of unsafe drives to create
         $hotSpDrvs - count of hotspare drives to create
         $loopCount - the number of loops to do
         $flags     - miscellaneous flags:
                      0x01 - exit after setup; skip actual regression test.
                      0x02 - skip cleanup before exit 

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 If invoked with the '-v' option, there are no initial conditions that
 are required.  If invoked without the '-v' option, the test expects an
 operational N-way configuration.

=back

=cut

##############################################################################
#
#          Name: BaseRegressionNWay
#
#        Inputs: $coPtr, $crtVCG, $dataDrvs, $unSfDrvs, $hotSpDrvs, $loopCount, $flags
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: This test case runs a basic regression test across 1-N conrollers
#        
##############################################################################
sub BaseRegressionNWay
{
    trace();
    my ($coPtr, $crtVCG, $dataDrvs, $unSfDrvs, $hotSpDrvs, $loopCount, $flags, $iscsiTargetId, $iscsiParamId, $iscsiTargetParam ) = @_;
    my $ret;
    my $i;
    my @coList = @$coPtr;
    my $ctlrM = $coList[0];
    my $slave;
    my $numCtlrs = scalar(@coList);
    my @ipList;
    my @snList;
    my $ctlr;
    my $flag;
    my %rsp;
    my $overallRC = ERROR;
    my $minpdisksflag = TRUE;
    my $diskOption = 2;
    my @targetId;
    my @paramId;
    my @targetParam;
    my $iscsiflag = $iscsiTargetId;
  
    @targetId = @$iscsiTargetId;
    @paramId  = @$iscsiParamId;
    @targetParam = @$iscsiTargetParam;

    if ($flags =~ /^0x/i) 
    {
        $flags = oct $flags;
    }

    my $skipTests  = $flags & BREG_SKIPTESTS_FLAG ? 1 : 0;
    my $cleanUp    = $flags & BREG_NOCLEANUP_FLAG ? 0 : 1;


    my $productID =  getMagProductID( 0, $ctlrM );
            
    if ($productID == 7000)
    {
        $hotSpDrvs = 0;
    }

    logInfo "Regression N-Way";
    
    if ($crtVCG)
    {
        logInfo "Will be creating a:        $numCtlrs-Way";
        logInfo "Number of Data Drives:     $dataDrvs";
        logInfo "Number of Unsafe Drives:   $unSfDrvs";
        logInfo "Number of Hotspare Drives: $hotSpDrvs";
    }
    else
    {
        logInfo "Will NOT be creating a new N-Way -- using existing configuration";
    }
       
    if($skipTests)
    {
        logInfo "Skip regression tests";
    }
    else
    {
        logInfo "Loop Count:        $loopCount";
        
        if($cleanUp)
        {
            logInfo "Clean Up - Delete VDisks at test completion\n";
        }
        else
        {
            logInfo "No Clean Up - VDisks will Remain at test completion\n";
        }
    }

    MAIN:
    {
        #
        # build the ipList and serial numbers as we will need them later
        #
        for ( $i = 0; $i < $numCtlrs; $i++ )
        {
            my $sn = GetSerial($coList[$i]);
            $ipList[$i] = $coList[$i]->{HOST};

            if ($sn != INVALID)
            {
                $snList[$i] = $sn;
            }
            else
            {
                logInfo(">>>>>>>> Failed to get a controller's serial num <<<<<<<<");
                $ret = ERROR;
                last MAIN;
            }
        }

        #
        # Show what is there
        #
        logInfo("Display current configuration for controllers");
        
        for ( $i = 0; $i < $numCtlrs; $i++ )
        {
            $ret = ConfigView ( $coList[$i], 0, 0 );
            if ( $ret != GOOD )
            {
                logInfo(">>>>>>>> Failed to display current configuration <<<<<<<<");
                last MAIN;
            }
        }

        #
        # If crtVCG passed in, set it up
        #
        if ($crtVCG)
        {
            $ret = WipeControllersClean2($coPtr);
            if ( $ret != GOOD )
            {
                logInfo(">>>>>>>> Failed to clean the controllers <<<<<<<<");
                last MAIN;
            }
            
            # Wait for each controller to reach WAIT_LICENSE state (2 min)
            foreach $ctlr (@coList)
            {
                $ret = Wait4MinPowerUpState($ctlr, POWER_UP_WAIT_LICENSE, 120);
                if ( $ret != GOOD )
                {
                    logInfo(">>>>>>>> Controller failed to reach the WAIT_LICENSE ".
                            "state <<<<<<<<");
                    last MAIN;
                }
            }

            # since we blew away the licenses for the controllers, need
            # to put one back
            $ret = GimmieLicense($coPtr, \@ipList, 0);
            if ($ret != GOOD)
            {
                logInfo(">>>>>>>> Failed to set-up license <<<<<<<<");
                last MAIN;
            }

            # rescan before labeling drives
            $ret = RescanBE( $ctlrM );          
            if( $ret != GOOD )
            {
                logInfo(">>>>>>>> Failed to rescan drives. <<<<<<<<");
                last MAIN;
            }

        #
        # Configuration of ISCSI Target IP
        #
                for ( my $k = 0; $k < 4; $k++ )
                {
                    # Validate port and check if any ISCSI targets are available

                    &TestLibs::iscsi::ValidateTargetType ( $ctlrM, $k, \$flag );
     
                    if ($flag == 0) #If a ISCSI target Found then configure paramters as given in station file
                    {
                        $ret = &TestLibs::iscsi::ConfigiSCSITargetParam( $ctlrM, \@targetId, \@paramId, \@targetParam);
    
                        if ( $ret == ERROR )
                        {
                            logError(">>>>>>>> Failed to configure iscsi target params. <<<<<<<<");
                        }
                    }
                }


                # now build the configuration
                $ret = LabelAllDrives($ctlrM, $dataDrvs, $unSfDrvs, $hotSpDrvs, 0, 0 );
                if ( $ret != GOOD )
                {
                    logInfo(">>>>>>>> Failed to label the drives <<<<<<<<");
                    last MAIN;
                }
            
                if ($numCtlrs > 1)
                {
                    $ret = MakeNWay($coPtr);
                    if ( $ret != GOOD )
                    {
                        logInfo(">>>>>>>> Failed to add controller to VCG <<<<<<<<");
                        last MAIN;
                    }
                }
            
            $ret = PingAll($coPtr);
            if ( $ret != GOOD )
            {
                logInfo(">>>>>>>> Failed to Ping all controllers in VCG <<<<<<<<");
                last MAIN;
            }
        
            logInfo "Completed Making Virtual Control Group...";
        }
    }
    
    if ($ret != GOOD)
    {
        # we're done.
    }
    #Run Tests on Group
    elsif ($skipTests)
    {
        #do nothing but set return code good
        $overallRC = GOOD;
    }
    else
    {
        my $totalLoops = $loopCount;
        
        TEST: while ($loopCount)
        {
            logInfo "*******************************************\n";
            logInfo "*  Test loop ".($totalLoops-$loopCount+1)." of $totalLoops";
            logInfo "*******************************************\n";   

            #
            # FW Vers, PU State, VCGInfo
            #
            logInfo "Running ViewLicenseState on all controllers";
            last TEST if GOOD != ViewLicenseState($coPtr);
            last TEST if GOOD != PingAll($coPtr);

            #
            # FW Vers, MemRead, Get/Set Serial Num, MRP TImeout, DevList
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPMiscCommands on $ctlr->{HOST}";
                last TEST if GOOD != GPMiscCommands($ctlr);
                last TEST if GOOD != PingAll($coPtr);
            }

            #
            # Reset QLogic cards
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running QLReset tests on $ctlr->{HOST}";
                last TEST if GOOD != GPResetTest($ctlr);
                last TEST if GOOD != PingAll($coPtr);
            }

            my $productID =  getMagProductID( 0, $ctlrM );
    
            if ($productID == 7000)
            {
                logInfo("Nitrogen Found !! Pausing for 90 Seconds to Allow QLogic cards to reinitialize");
                sleep 90;
                logInfo("Pause Complete");
             }

            #
            # Run Elections
            #
            # Skip elections for EA builds.  Elections crash the controllers
           if ($productID == 5000 )
           {
           }
           else
           {
           my $count = 0;
            foreach $ctlr (@coList)
            {
                logInfo "Running ElectionsTestNWay on $ctlr->{HOST}";
                last TEST if GOOD != ElectionsTestNWay(\@coList, $count++, 2); 
                last TEST if GOOD != PingAll($coPtr);
            }
           }

            #
            # Figure out who the master is
            #
            logInfo "Running FindMasterPickSlave to determine the master";
            ($ret,$slave) = FindMasterPickSlave(\@coList);
            if ($ret == INVALID)
            {
                logInfo "Failed to find master controller";
                last TEST;
            } 
            else
            {
                $ctlrM = $coList[$ret];
                logInfo "Master is $ctlrM->{HOST}";

                if ($numCtlrs > 1)
                {
                    if ($slave != INVALID)
                    {
                        logInfo "Slave is $coList[$slave]->{HOST}";
                    }
                    else
                    {
                        logInfo "INVALID slave returned from FindMasterPickSlave";
                    }
                }
            }
            
            #
            # PDisk
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPPhysicalDiskCommands on $ctlr->{HOST}";
                last TEST if GOOD != GPPhysicalDiskCommands($ctlr, 1); 
                last TEST if GOOD != PingAll($coPtr);
            }

            #
            # Disk Bays
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPDiskBayCommands on $ctlr->{HOST}";
                last TEST if GOOD != GPDiskBayCommands($ctlr); 
                last TEST if GOOD != PingAll($coPtr);
            }

            #
            # Vdisk creation (issued only on master)
            #
            logInfo "Running GPVirtualDiskCommands on $ctlrM->{HOST}";
            last TEST if GOOD != GPVirtualDiskCommands($ctlrM, 1); 
            last TEST if GOOD != PingAll($coPtr);

            my %pdisks = $ctlrM->physicalDisks();
    
            # set $minpdisksflag to FALSE, if there are more than 8 physical disks
            # this is intended for a 750 controller with minimum number of physical
            # disks.
        
            # This check can go once each 750 is supplied with enough pdisks
        
            if ( $pdisks{COUNT} > 8 )
            {
                $minpdisksflag = FALSE;
            }
            elsif( $pdisks{COUNT} == 8 )
            {
                $diskOption = 44;
            }
            else
            {
                $diskOption = 43;
            }

            #
            # Vdisk creation (issued only on master)
            #
            logInfo "Running MakeVdisks, strategy $diskOption on $ctlrM->{HOST}";
            last TEST if GOOD != MakeVdisks($ctlrM, $diskOption, 0); 
            last TEST if GOOD != PingAll($coPtr);

            #
            # Vdisk create/expand/delete (issued only on master)
            #
            logInfo "Running GPCreateExpand on $ctlrM->{HOST}";
            last TEST if GOOD != GPCreateExpand($ctlrM); 
            last TEST if GOOD != PingAll($coPtr);
            logInfo "Running GPCreateExpandDelete on $ctlrM->{HOST}";
            last TEST if GOOD != GPCreateExpandDelete($ctlrM); 
            last TEST if GOOD != PingAll($coPtr);
            logInfo "Running GPCreateExpandDelete2 on $ctlrM->{HOST}";
            last TEST if GOOD != GPCreateExpandDelete2($ctlrM); 
            last TEST if GOOD != PingAll($coPtr);

            #
            # Vdisk list, Vdisk Info, Vdisk set cache, Global cache Info/Set 
            # (issued only on master)
            #
            logInfo "Running GPCaching on $ctlrM->{HOST}";
            last TEST if GOOD != GPCaching($ctlrM); 
            last TEST if GOOD != PingAll($coPtr);
            
            #
            # Vdisk misc
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPVdiskMisc on $ctlr->{HOST}";
                last TEST if GOOD != GPVdiskMisc($ctlr); 
                last TEST if GOOD != PingAll($coPtr);
            }

            #
            # Raid Commands
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPRaidCommands on $ctlr->{HOST}";
                last TEST if GOOD != GPRaidCommands($ctlr); 
                last TEST if GOOD != PingAll($coPtr);
            }

            #
            # Device Status Commands
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPDeviceStatus on $ctlr->{HOST}";
                last TEST if GOOD != GPDeviceStatus($ctlr); 
                last TEST if GOOD != PingAll($coPtr);
            }
            
            #
            # Server Commands
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPServerCommands on $ctlr->{HOST}";
                last TEST if GOOD != GPServerCommands($ctlr); 
                last TEST if GOOD != PingAll($coPtr);
            }

            #
            # Target Commands
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPTargetCommands on $ctlr->{HOST}";
                last TEST if GOOD != GPTargetCommands($ctlr); 
                last TEST if GOOD != PingAll($coPtr);
            }

            #
            # Stats Commands
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPStatsCommands on $ctlr->{HOST}";
                last TEST if GOOD != GPStatsCommands($ctlr); 
                last TEST if GOOD != PingAll($coPtr);
            }

            #
            # Clean Up!
            #
            if ($loopCount > 1 or $cleanUp)
            {
                #
                # Vdisk delete (all)
                # (issued only on master)
                #
                logInfo "Running DeleteAllVdisks on $ctlrM->{HOST}";
                last TEST if GOOD != DeleteAllVdisks($ctlrM); 
                last TEST if GOOD != PingAll($coPtr);
            }

            #
            # Logging Commands
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPLoggingTest on $ctlr->{HOST}";
                last TEST if GOOD != GPLoggingTest($ctlr); 
                last TEST if GOOD != PingAll($coPtr);
            }

            #
            # Mem Leaks Commands
            #
            foreach $ctlr (@coList)
            {
                logInfo "Running GPMemoryLeakTest on $ctlr->{HOST}";
                last TEST if GOOD != GPMemoryLeakTest($ctlr); 
                last TEST if GOOD != PingAll($coPtr);
            }

        }
        # NOTE: 'last' does not execute the 'continue' block. 
        # Everything else does.
        continue
        {
            --$loopCount;
            if ($loopCount == 0)
            {
                $overallRC = GOOD;
                last;
            }
        }
    }

    foreach $ctlr (@coList)
    {
        logInfo "Logging out of $ctlr->{HOST}";
        $ctlr->logout(); 
    }
    
    if ($overallRC == GOOD)
    {
        logInfo "TEST COMPLETED SUCCESSFULLY\n";
    }
    else
    {
        logInfo "TEST FAILED\n";
    }

    return $overallRC;    
}


###############################################################################

=head2 QLResets

This test case runs a QLogic reset test across 1-N conrollers

=cut

=over 1

=item Usage:

 my $rc = QLResets($coPtr, $loopCount);
 
 where:  $coPtr     - ptr to a list of controller objects
         $loopCount - the number of loops to do

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 None

=back

=cut

##############################################################################
#
#          Name: QLResets
#
#        Inputs: $coPtr, $loopCount
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: This test case runs a QLogic reset test across 1-N conrollers
#        
##############################################################################
sub QLResets
{
    trace();
    my ($coPtr, $loopCount) = @_;
    my $ret;
    my $i;
    my @coList = @$coPtr;
    my $numCtlrs = scalar(@coList);
    my $ctlrM = $coList[0];
    my $slave;
    my @ipList;
    my @snList;
    my $ctlr;
    my %rsp;
    my $overallRC = ERROR;
    my $totalLoops = $loopCount;
        
    TEST: while ($loopCount)
    {
        logInfo "*******************************************";
        logInfo "*  Test loop ".($totalLoops-$loopCount+1)." of $totalLoops";
        logInfo "*******************************************";   

        #
        # FW Vers, PU State, VCGInfo
        #
        logInfo "Running ViewLicenseState on all controllers";
        last TEST if GOOD != ViewLicenseState($coPtr);
        last TEST if GOOD != PingAll($coPtr);

        #
        # FW Vers, MemRead, Get/Set Serial Num, MRP TImeout, DevList
        #
        foreach $ctlr (@coList)
        {
            logInfo "Running GPMiscCommands on $ctlr->{HOST}";
            last TEST if GOOD != GPMiscCommands($ctlr);
            last TEST if GOOD != PingAll($coPtr);
        }

        #
        # Reset QLogic cards
        #
        logInfo(" ------- QL resets on just the FE ------ ");
        foreach $ctlr (@coList)
        {
            logInfo "Running QLReset tests on $ctlr->{HOST}";
            
            foreach $i (0..3)
            {
                if (GOOD != QLReset($ctlr, "FE", $i, 
                            RESET_QLOGIC_RESET_INITIALIZE, 1))
                {
                    logInfo "QLReset FE/$i Failed";
                    last TEST;
                }
            }

            
            last TEST if GOOD != PingAll($coPtr);
        }
        
        logInfo "Pausing 30 seconds to allow QLogic cards to reinitialize...";
        DelaySecs(30);
        logInfo(" ------- QL resets on just the BE ------ ");
        
        foreach $ctlr (@coList)
        {
            logInfo "Running QLReset tests on $ctlr->{HOST}";
            
            foreach $i (0..3)
            {
                if (GOOD != QLReset($ctlr, "BE", $i, 
                            RESET_QLOGIC_RESET_INITIALIZE, 1))
                {
                    logInfo "QLReset BE/$i Failed";
                    last TEST;
                }
            }
            
            last TEST if GOOD != PingAll($coPtr);
        }
        
        logInfo "Pausing 30 seconds to allow QLogic cards to reinitialize...";
        DelaySecs(30);
        logInfo(" ------- QL resets on both BE and FE ------ ");
        
        
        foreach $ctlr (@coList)
        {
            logInfo "Running QLReset tests on $ctlr->{HOST}";
            
            foreach $i (0..3)
            {
                if (GOOD != QLReset($ctlr, "FE", $i, 
                            RESET_QLOGIC_RESET_INITIALIZE, 1))
                {
                    logInfo "QLReset FE/$i Failed";
                    last TEST;
                }
            }

            foreach $i (0..3)
            {
                if (GOOD != QLReset($ctlr, "BE", $i, 
                            RESET_QLOGIC_RESET_INITIALIZE, 1))
                {
                    logInfo "QLReset BE/$i Failed";
                    last TEST;
                }
            }
            
            last TEST if GOOD != PingAll($coPtr);
        }
        
        
        
        logInfo "Pausing 30 seconds to allow QLogic cards to reinitialize...";
        DelaySecs(30);

        #
        # Run Elections
        #
        my $count = 0;
        foreach $ctlr (@coList)
        {
            logInfo "Running ElectionsTestNWay on $ctlr->{HOST}";
            last TEST if GOOD != ElectionsTestNWay(\@coList, $count++, 2); 
            last TEST if GOOD != PingAll($coPtr);
        }

        #
        # Figure out who the master is
        #
        logInfo "Running FindMasterPickSlave to determine the master";
        ($ret,$slave) = FindMasterPickSlave(\@coList);
        if ($ret == INVALID)
        {
            logInfo "Failed to find master controller";
            last TEST;
        } 
        else
        {
            $ctlrM = $coList[$ret];
            logInfo "Master is $ctlrM->{HOST}";

            if ($numCtlrs > 1)
            {
                if ($slave != INVALID)
                {
                    logInfo "Slave is $coList[$slave]->{HOST}";
                }
                else
                {
                    logInfo "INVALID slave returned from FindMasterPickSlave";
                }
            }
        }
    }
    # NOTE: 'last' does not execute the 'continue' block. 
    # Everything else does.
    continue
    {
        --$loopCount;
        if ($loopCount == 0)
        {
            $overallRC = GOOD;
            last;
        }
    }

    foreach $ctlr (@coList)
    {
        logInfo "Logging out of $ctlr->{HOST}";
        $ctlr->logout(); 
    }
    
    if ($overallRC == GOOD)
    {
        logInfo "TEST COMPLETED SUCCESSFULLY\n";
    }
    else
    {
        logInfo "TEST FAILED\n";
    }

    return $overallRC;    
}

1;

