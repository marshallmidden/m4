#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library - Write Cache tests
#
#   11/08/2004  XIOtech   Craig Menning
#
#   A set of library functions for integration testing. 
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2002 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::WrtCache.pm - Tests that stress the Write Cache feature.

$Id: WrtCache.pm 4416 2005-06-01 22:19:09Z PalmiD $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL>
     <LI>Linux</LI>
     <LI>Windows</LI>
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing the robustness
of write cache on the controller.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

            WrtCacheTestEntry()
            WrtCacheTestCase01()
            WrtCacheTestCase02()
            WrtCacheTestCase03()

        The less significant ones

              <none>

=cut

#
# - what I am
#
package TestLibs::WrtCache;

#
# - other modules used
#
use warnings;
use lib "../CCBE";
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOtech::sanscript (port => 10000);
#use XIOtech::sanscriptET;

use TestLibs::IntegCCBELib;
use TestLibs::IntegXMCLib;
use TestLibs::BEUtils;
use TestLibs::utility;
use TestLibs::Logging;
use TestLibs::Validate;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::WrtCacheSupport;
use TestLibs::Validate;
use TestLibs::FailOver;
use TestLibs::FailOverSupport;
use TestLibs::XSSARobustness;

#
# - perl compiler/interpreter flags 'n' things
#
use strict;


#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN
{
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    #
    # set the version for version checking
    #
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(&WrtCacheTestEntry);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4416 $);
}

our @EXPORT_OK;


###############################################################################
#
#    Additional test cases 
#
#    Mostly Write Cache related ---
#
#    1) Turn on and off cache repeatedly while running I/O. Do this 
#       slowly at first, then much faster. (Attempt to overlap on/off
#       requests.) <D1> Global and Vdisk
#    2) Failover with cache enabled. Do we want a cache on and cache off
#       set of test cases, or a wrapper on failover that can also make 
#       sure we restore cache to the original setting. <D2>
#    3) Rolling code updates with cache on. Write a ccbe script that 
#       emulates RCU on the ICON. (Or calls the ICON scripting.) <D2>
#    4) Cache on, do redi copies, swaps, mirrror, etc <D1>
#    5) with cache on make/break vlinks (needs a vlink test library) <D3?>
#    6) enable cache on the destination of a vlink (needs a vlink test
#       library) <D2> (will fail for release 1)
#    7) Update failover to handle case were caching is on and the
#       failover would trash both copies of the cache. (Do not fail
#       adjacent controllers simultaneously when cache is on.) Use the
#       mirror partner list when determining what to fail.(Is this the 
#       same as vcgmplist? If so, make it a flag passed to WhatToFail() ) <D4+>
#    8) Ctlr fails, battery dies, another controller has posted the data,      
#       ctlr comes online, checks other controller for the data. Not really
#       good to script, but should be done manually. 
#         Power off and battery dies
#         When comes back up, log msg notes it has lost data <D3>
#
#    11) Enable cache, fail controller, verify cache is now off, unfail controller
#        verify cache now on. (determine response in n-way environement)
#          Cache always on, but mirror to proper place <D3>
#    12) Characterize, observe cache behavior in a Rolling Code Update
#        environment <D2>
#    13) Cache integrity thru a power cycle of all controllers. This does a
#        number on the I/O that will be running. Look at errors logged by the 
#        controllers. (also look at events) <D3>
#    14) Turn cache off and on multiple times, verify that caching state on
#        each vdisks ate each on or off cycle. Verify that only the correct 
#        vdisks turn on/off cache. <D1>
#    15) Look at cache statistics, verify correct change as cache is 
#        enabled/disabled <D1> and during and after a failover/ failback cycle <D2>.
#    16) Power off a controller, wait a while, power on, Observe the 
#        charging of the battery (env statistics) and when cache turns 
#        back on. Do this for cases where the the controller is unfailed
#        immediately and unfailed after some delay. Need to look at cache
#        state of all controllers in the CNC. (Output is some sort of
#        timeline?) <D1>
#    17) Check ability to enable/disable cache on the slaves as well as 
#        he master controller. <D2>
#    18) Observe effect of failing the cache partner of a controller. <D2>
#        Does the LUN owner disable cache of the partner fails?  (No)
#    19) In an N-way. Fail the lun owner, see who picks up the LUNs and 
#        does the cache partner change? <D4+>
#    20) Is cache re-enable after failback manual or automatic? (Affects 
#        test cases) Automatic <D2>
#    21) Look at statsvdisks to determine if cache is on or off and the 
#        apparent performance change. Assuming consistant I/O load this
#        may be a good metric. <D1> Need Validation Routine   
#    22) Try to make a vdisk with some SATA raids and some FC raids. How
#        does cache behave?    See #9.  <D1>
#    23) Make a timeline of events as cache is turned off. (Assuming 
#        it takes more than a second or two to turn off cache.)  Good
#
#
#    Non-write cache related ones ----
#
#    9) Build a vdisk with fc drive, expand using sata drives, is this a
#       performance solution or not.                                  <Not Write Cache>
#    10) Start a defrag, start it again(fails), stop defrag, restart. <Not Write Cache>
#
#    23) A test for messed up target mapping. Map more than 8 luns to a 
#        target, then do a config change (of the right type) and confirm that
#        the target mappings are still valid on all controllers. This needs 
#        to have both a test and a callable function for the validation. <Not Write Cache>
#
#
#    24) (DONE) Loop Primitive, option 0 on all pdisks. Loop thru all devices slow
#               and fast. Check that I/O survives.          <Not Write Cache>
#    25) (DONE) Loop Primitive, option 1 on all pdisks. Loop thru all devices slow
#               and fast. Check that I/O survives.          <Not Write Cache>
#    26) (DONE) Loop Primitive, option 2 on all pdisks. Loop thru all devices slow
#               and fast. Check that I/O survives.
#               (One of the above should LIP every device.) <Not Write Cache>
#
#    27) Delete a vdisk during
#                   raid init      see Integccbelib::CreateExpandInitDelete
#                   rebuild
#                   redi-copy      see Defrag case 2
#                   defrag         see Dafrag Case 2
#                   parity scan
#                   cache off and cache on cases for all ???
#
#        Some of these may already be done, but the test should do the 
#        delete on a vdisk unrelated to the activity, and on one related
#        to the activity. If there are two related vdisks, the delete
#        delete should be done to each one separately. SOme deletes
#        will break the operation, some won't. None should trash the
#        controlleer or I/O. (within reason)
#
#    28) Add vdiskmove to the regression tests.  <Not Write Cache>
#    29) Test to validate an expanded raid       <Not Write Cache>
#              Time to come ready
#              Size inreases as expected
#              Init completes
#        Check each raid type, and on FC and SATA drives.
#
#    31) Battery On/Off (BatteryHealth CL)
#
#    32) Double bit ECC error on cache card
#    
#    33) Shutdown controller, Ensure cache is flushed, Power off for x time, 
#        Turn on and ensure battery is charged  <D1>
#
#    34) - Write cache enabled w/ cache in use
#        - Stop I/O to the servers (by hand)
#        - Ensure that all dirty write cache tags are moved to resident tags.
#
######################
#  1 => TC05
#  2 => TC12 - TC17
#  3 => TC18 - Global Cache must be disabled for RCU's
#  4 => BEStress All
#  5 => 
#  6 => 
#  7 =>
#  8 => 
#  9 => Not Write Cache
# 10 => Not Write Cache
# 11 => 
# 12 => TC18 -
# 13 => 
# 14 => TC06
# 15 => TC05 (D1) and TCxx (D2)
# 16 => TC09
# 17 => TC11
# 18 => 
# 19 => 
# 20 => TC12 - TC17
# 21 => 
# 22 => Controller will not allow mixing of sata and fc.
# 23 => Not Write Cache
# 24 => Not Write Cache
# 25 => Not Write Cache
# 26 => Not Write Cache
# 27 => 
# 28 => Not Write Cache
# 29 => Not Write Cache
# 31 => TC07
# 32 => Have to do low level write to cache card (See Lynn)
# 33 => TC08
# 34 => TC10
###############################################################################

##############################################################################
#
# GENERAL FUNCTION PARAMETER COMMENTS
#
##############################################################################
=head2 General function parameter comments

For most functions the same set of parameters are required. These parameters
are described in more detail here.

=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.

 $moxaPtr: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.

 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller.

 $retIn: This is a controle variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the
          attached servers. When configuring systems, this list determines
          which WWNs will be associated with vdisks. If an entry in this
          list is not found on the system, it will be ignored. A WWN
          found on the system that is not included in the list will not
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this
        is the pointer to that controller object. It is one of the
        members of the list that $coPtr points to.

=back

=cut
##############################################################################
#
# GENERAL FUNCTION PARAMETER COMMENTS
#
##############################################################################


##############################################################################
#
#               Public Functions
#
##############################################################################

##############################################################################
=head2 WrtCacheTestCase01 function

This test case blindly turns on global write cache as well as vdisk write cache
  for all vdisks seen by the controller. There is no checking to see if write
  cache is already enabled on any of the vdisks or the controller.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase01( $coPtr, $retIn );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    
=back

=cut

##############################################################################
sub WrtCacheTestCase01
{
    trace();
    my ( $coPtr, $retIn ) = @_;

    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;

    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 1              -----------------------");
    logInfo("------ Turn on all Global and Vdisk cache ----------------------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    @coList = @$coPtr;         # recreate the controller array

    $ctlr = $coList[$master];  # Get master object

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Enable global and all vdisk write cache
    #
    $retVal = WrtCacheControl($ctlr,  WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify global cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify all vdisk cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
         return (ERROR);
    }

    logInfo("");
    logInfo("------ End WrtCache Test Case 1              -------------------");
    logInfo("");

    return GOOD;
}


##############################################################################
=head2 WrtCacheTestCase02 function

This test case blindly turns off global write cache as well as vdisk write cache
  for all vdisks seen by the controller. There is no checking to see if write
  cache is already disabled on any of the vdisks or the controller.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase02( $coPtr, $retIn );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    
=back

=cut

##############################################################################
sub WrtCacheTestCase02
{
    trace();
    my ( $coPtr, $retIn ) = @_;

    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;

    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 2               ----------------------");
    logInfo("------ Turn off all Global and Vdisk cache ---------------------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    @coList = @$coPtr;         # recreate the controller array

    $ctlr = $coList[$master];  # Get master object

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # disable all global and vdisk write cache
    #
    $retVal = WrtCacheControl($ctlr,  WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    sleep(5);   # allow cache to flush
    
    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify global cache is disabled 
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify all vdisk cache is disabled
    #
    $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    logInfo("");
    logInfo("------ End WrtCache Test Case 2              -------------------");
    logInfo("");

    return GOOD;
}


##############################################################################
=head2 WrtCacheTestCase03 function

This test case blindly turns on global write cache as well as vdisk write cache
  for a list of vdisks input by the user. There is no checking to see if 
  write cache is already enabled on any of the vdisks or the controller.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase03( $coPtr, $retIn, $parmsPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $parmsPtr is a pointer to the list of test parms 

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    
=back

=cut

##############################################################################
sub WrtCacheTestCase03
{
    trace();
    my ( $coPtr, $retIn, $parmsPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;
    my $vdiskListSelect;
    my $vdiskListOnPtr;
    my $vdiskListOffPtr;
    my @vdisks;
    my $vdisksPtr;
    my $i;
    my $numVDDs;
    my $needed;
    my $globalSetRequest       = WRTCACHE_GLOBAL_SET_ENABLE;
    my $vdiskSetRequest        = WRTCACHE_VDISKS_SET_ENABLE;
    my $vdiskClearRequest      = WRTCACHE_VDISKS_SET_DISABLE;
    
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    #
    # Check if All/Alt/Random parameter is set and default to ALL if not
    #
    if (defined $parmsPtr->{vdisklistselect} )
    {
        #
        # Extract key from parmsPtr (how many vdisks to turn on)
        #
        $vdiskListSelect = $parmsPtr->{vdisklistselect};
    }
    else
    {
        logInfo("    ====> vdisklistselect parameter missing. Using Default of 'ALL' <====");
        $vdiskListSelect = 'all';
    }

    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 3                  -------------------");
    logInfo("------ Turn on Global and select Vdisk cache -------------------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    @coList = @$coPtr;         # recreate the controller array

    $ctlr = $coList[$master];  # Get master object

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Get the list of existing vdisks
    #
    @vdisks = GetVdiskList( $ctlr );
    $vdisksPtr = \@vdisks;
    
    if ( $vdisks[0] == INVALID )
    {
        logInfo("    ====> Unable to retrieve list of virtual disk identifiers. <====");
        logInfo("    ====> $coList[$master]{HOST}                               <====");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # Call to All-Alt-Random routine to select vdisks
    $vdiskListOnPtr = WrtCacheVdisksSelectAllAltRandom($coPtr, $vdisksPtr, $vdiskListSelect);

    #
    # Get pointer to the list of vdisks that are off
    #
    $vdiskListOffPtr = GetComplimentOfList($vdisksPtr, $vdiskListOnPtr);

    #
    # enable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, $globalSetRequest);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    # Display globalCacheInfo
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateCacheGlobal($ctlr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # enable select vdisk write cache
    #
    $retVal = WrtCacheControlVdisksMultiple($ctlr, $vdiskSetRequest, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # disable select vdisk write cache
    #
    $retVal = WrtCacheControlVdisksMultiple($ctlr, $vdiskClearRequest, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    # Display Vdisk Info
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify vdisk write cache is enabled (list of vdisks passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisks passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    logInfo("------ End WrtCache Test Case 3              -------------------");

    return GOOD;
    
}


##############################################################################
=head2 WrtCacheTestCase04 function

This test case blindly turns off global write cache as well as vdisk write cache
  for a list of vdisks input by the user. There is no checking to see if 
  write cache is already disabled on any of the vdisks or the controller.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase04( $coPtr, $retIn, $parmsPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $parmsPtr is a pointer to the list of test parms 

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    
=back

=cut

##############################################################################
sub WrtCacheTestCase04
{
    trace();
    my ( $coPtr, $retIn, $parmsPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;
    my $vdiskListSelect;
    my $vdiskListOnPtr;
    my $vdiskListOffPtr;
    my @vdisks;
    my $vdisksPtr;
    my $i;
    my $numVDDs;
    my $needed;
    my $globalSetRequest       = WRTCACHE_GLOBAL_SET_DISABLE;
    my $vdiskSetRequest        = WRTCACHE_VDISKS_SET_ENABLE;
    my $vdiskClearRequest      = WRTCACHE_VDISKS_SET_DISABLE;

    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    #
    # Check if All/Alt/Random parameter is set and default to ALL if not
    #
    if (defined $parmsPtr->{vdisklistselect} )
    {
        #
        # Extract key from parmsPtr (how many vdisks to turn on)
        #
        $vdiskListSelect = $parmsPtr->{vdisklistselect};
    }
    else
    {
        logInfo("    ====> vdisklistselect parameter missing. Using Default of 'ALL' <====");
        $vdiskListSelect = 'all';
    }

    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 4                   ------------------");
    logInfo("------ Turn off Global and select Vdisk cache ------------------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    @coList = @$coPtr;         # recreate the controller array

    $ctlr = $coList[$master];  # Get master object

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Get the list of existing vdisks
    #
    @vdisks = GetVdiskList( $ctlr );
    $vdisksPtr = \@vdisks;
    
    if ( $vdisks[0] == INVALID )
    {
        logInfo("    ====> Unable to retrieve list of virtual disk identifiers. <====");
        logInfo("    ====> $coList[$master]{HOST}                               <====");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available


    #
    # Call to All-Alt-Random routine to select vdisks
    #
    $vdiskListOffPtr = WrtCacheVdisksSelectAllAltRandom($coPtr, $vdisksPtr, $vdiskListSelect);

    #
    # Get pointer to the list of vdisks that are off
    #
    $vdiskListOnPtr = GetComplimentOfList($vdisksPtr, $vdiskListOffPtr);
    
    #
    # Disable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, $globalSetRequest);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    sleep(5);   # allow cache to flush

    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Verify global write cache is disabled
    #
    $retVal = WrtCacheValidateCacheGlobal($ctlr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Disable select vdisk write cache
    #
    $retVal = WrtCacheControlVdisksMultiple($ctlr, $vdiskClearRequest, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Enable select vdisk write cache
    #
    $retVal = WrtCacheControlVdisksMultiple($ctlr, $vdiskSetRequest, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify vdisk write cache is disabled (list of vdisks passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
        
    #
    # verify vdisk write cache is enabled (list of vdisks passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
        
    logInfo("------ End WrtCache Test Case 4              -------------------");

    return GOOD;
    
}
##############################################################################
=head2 WrtCacheTestCase05 function

This test case cycles global write cache on and off repeatedly while running 
I/O. Cycling begins slowly (30 sec between) and decreases delay to 0 in an
attempt to overlap on/off requests. Global cache is verified to be in the 
correct condition after each request.
  
Also cycles vdisk write cache on and off repeatedly while running I/O. 
Cycling begins slowly (30 sec between) and decreases delay to 0 in an
attempt to overlap on/off requests. Vdisk cache is verified to be in the 
correct condition after each request. 

I/O is tested at the beginning and after each loop (cycle global and cycle 
vdisk).
  
The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase05( $coPtr, $retIn, $snPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server) Also assumes you have I/O running.
    
=back

=cut

##############################################################################
#    1) Turn on and off cache repeatedly while running I/O. Do this 
#       slowly at first, then much faster. (Attempt to overlap on/off
#       requests.) <D1> Global and Vdisk
##############################################################################
sub WrtCacheTestCase05
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;
    my $timer;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my $retFlag;
    
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 5                          -----------");
    logInfo("------ Cycle Global and vdisk write cache repeatedly -----------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    @coList = @$coPtr;         # recreate the controller array

    $ctlr = $coList[$master];  # Get master object

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # get measure of the current IO
    #
    $retVal = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                            \@initialVdisks, \@tMap, 20, 10);

    #
    # Enable Global and all Vdisk write cache
    #
    $retVal = WrtCacheControl($ctlr,  WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    logInfo("    ====> Cycling global write cache on and off repeatedly <====");
    
    #
    # cycle global write cache
    #
    for($timer = 30; $timer > -1; $timer--)
    {
        #
        # disable global write cache
        #
        $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        DelaySecs($timer);
        
        #
        # Display globalCacheInfo
        #
        $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    
        #
        # verify global cache is disabled (if $timer > 5)
        #  if $timer < 5 validate will fail as cache has not had time to flush.
        #
        if($timer > 5)
        {
            $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_DISABLED);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
        }

        #
        # enable global write cache
        #
        $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
        
        DelaySecs($timer);
        
        #
        # Display globalCacheInfo
        #
        $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    
        #
        # verify global cache is enabled
        #
        $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    }

    #
    # Verify status of controller(s) good
    #
    logInfo("Checking the status on the controllers....");
    $retVal = CheckVCGState($coList[$master]);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify IO is still good
    #
    $retVal = VerifyIO( $coPtr,
                        \@activeServers, 
                        \@tMap, 
                        \@initialVdisks,
                        $snPtr
                      );

    if ( $retVal != GOOD ) { return ERROR; }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    logInfo("    ====> Cycling vdisk write cache on and off repeatedly <====");

    #
    # cycle vdisk write cache
    #
    for($timer = 30; $timer > -1; $timer--)
    {
        #
        # disable all vdisk write cache
        #
        $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        DelaySecs($timer);
        
        #
        # Display Vdisk Info
        #
        $retVal = DispVdiskInfo($ctlr);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    
        #
        # verify all vdisk cache is disabled
        #
        $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_DISABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # enable all vdisk write cache
        #
        $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_ENABLE);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
        
        DelaySecs($timer);
        
        #
        # Display Vdisk Info
        #
        $retVal = DispVdiskInfo($ctlr);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    
        #
        # verify all vdisk cache is enabled
        #
        $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_ENABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    }
    
    #
    # Verify status of controller(s) good
    #
    logInfo("Checking the status on the controllers....");
    $retVal = CheckVCGState($coList[$master]);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify IO is still good
    #
    $retVal = VerifyIO( $coPtr,
                        \@activeServers, 
                        \@tMap, 
                        \@initialVdisks,
                        $snPtr
                      );

    if ( $retVal != GOOD ) { return ERROR; }

    logInfo("------ End WrtCache Test Case 5              -------------------");
        
    return GOOD;
    
}

##############################################################################
=head2 WrtCacheTestCase06 function

This test case disables global and all vdisk write cache. Verify global and 
all vdisk cache is off. Pass a list of vdisks to enable write cache on 
(diskListOn). Verify write cache is on for the list of vdisks. Verify write 
cache is off for the other vdisks in the DSC. Global write cache is enabled 
and the write cache states of the vdisks are verified to be unchanged.  Global 
write cache is then disabled and the states of write cache states of the 
vdisks are verified to be unchanged.
  
Enable global and all vdisk write cache. Verify global and all vdisk cache 
is on. Pass a list of vdisks to disable write cache on (diskListOff). Verify 
write cache is off for the list of vdisks. Verify write cache is on for the 
other vdisks in the DSC. Global write cache is disabled and the write cache 
states of the vdisks are verified to be unchanged.  Global write cache is 
then enabled and the states of write cache states of the vdisks are verified 
to be unchanged.
  
The list of vdisks on/off can be selected by a parameter called vdisklistselect
in the config file.  The options are 'all', 'alt' and 'random'.  'all' selects 
all the vdisks, 'alt' selects every other vdisk, and 'random' selects half of 
the vdisks randomly. If the user forgets to add the parameter, the test case
defaults to 'all'.

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase06( $coPtr, $retIn, $parmsPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $parmsPtr is a pointer to the list of test parms 

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
#    14) Turn cache off and on multiple times, verify that caching state on
#        each vdisks at each on or off cycle. Verify that only the correct 
#        vdisks turn on/off cache. <D1>
##############################################################################
sub WrtCacheTestCase06
{
    trace();
    my ( $coPtr, $retIn, $parmsPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;
    my $vdiskListSelect;
    my $vdiskListOnPtr;
    my $vdiskListOffPtr;
    my @vdisks;
    my $vdisksPtr;
    my $i;
    my $numVDDs;
    my $needed;
    my $tempPtr;
    
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    #
    # Check if All/Alt/Random parameter is set and default to ALL if not
    #
    if (defined $parmsPtr->{vdisklistselect} )
    {
        #
        # Extract key from parmsPtr (how many vdisks to turn on)
        #
        $vdiskListSelect = $parmsPtr->{vdisklistselect};
    }
    else
    {
        logInfo("    ====> vdisklistselect parameter missing. Using Default of 'ALL' <====");
        $vdiskListSelect = 'all';
    }

    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 6                                -----");
    logInfo("------ Cycle Global cache; verify Vdisk cache is unchanged -----");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    @coList = @$coPtr;         # recreate the controller array

    $ctlr = $coList[$master];  # Get master object

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    ### Start with all cache off initially ###

    #
    # Disable global and all vdisk write cache
    #
    $retVal = WrtCacheControl($ctlr,  WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    sleep(5);   # allow cache to flush
    
    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Get a list of existing vdisks
    #
    @vdisks = GetVdiskList( $ctlr );
    $vdisksPtr = \@vdisks;
    
    if ( $vdisks[0] == INVALID )
    {
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    #
    # Call to All-Alt-Random routine to select vdisks
    #
    $vdiskListOnPtr = WrtCacheVdisksSelectAllAltRandom($coPtr, $vdisksPtr, $vdiskListSelect);

    #
    # Get pointer to the list of vdisks that are off
    #
    $vdiskListOffPtr = GetComplimentOfList($vdisksPtr, $vdiskListOnPtr);

    #
    # enable select vdisk write cache
    #
    $retVal = WrtCacheControlVdisksMultiple($ctlr, 
                                            WRTCACHE_VDISKS_SET_ENABLE, 
                                            $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify vdisk write cache is enabled (list of vdisksOn passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisksOff passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # enable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
        
    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateCacheGlobal($ctlr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify vdisk write cache is enabled (list of vdisksOn passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisksOff passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # disable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    sleep(5);
    
    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify global write cache is disabled
    #
    $retVal = WrtCacheValidateCacheGlobal($ctlr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify vdisk write cache is enabled (list of vdisksOn passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisksOff passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    ### Now repeat with all cache on initially ###
    
    #
    # Reverse pointers for 2nd part
    #
    $tempPtr = $vdiskListOnPtr;
    $vdiskListOnPtr = $vdiskListOffPtr;
    $vdiskListOffPtr = $tempPtr;
    
    #
    # enable all global and vdisk write cache
    #
    $retVal = WrtCacheControl($ctlr,  WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # disable select vdisk write cache
    #
    $retVal = WrtCacheControlVdisksMultiple($ctlr, WRTCACHE_VDISKS_SET_DISABLE, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify vdisk write cache is enabled (list of vdisksOn passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisksOff passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # disable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
        
    sleep(5);

    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify global write cache is disabled
    #
    $retVal = WrtCacheValidateCacheGlobal($ctlr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify vdisk write cache is enabled (list of vdisksOn passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisksOff passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # enable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
        
    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateCacheGlobal($ctlr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify vdisk write cache is enabled (list of vdisksOn passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisksOff passed in)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    logInfo("------ End WrtCache Test Case 6              -------------------");
        
    return GOOD;
    
}


##############################################################################
=head2 WrtCacheTestCase07 function

This test case changes the battery health state of a single controller
and verifies write caching is affected appropriately.  This test case
requires global caching to be enabled and at least one virtual disk
running IO with write cache enabled.

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase07( $coPtr, $retIn );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    
=back

=cut
##############################################################################
sub WrtCacheTestCase07
{
    trace();
    my ( $coPtr, $retIn ) = @_;

    my $master;
    my @coList;
    my $controller;
    my $srcMP = 0;
    my $srcController = 0;
    my $retVal = GOOD;
    my %rsp;
    my %rspVCGMPList;
    my $msg;
    my $iController;
    my %mirrorData;

    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 07               ---------------------");
    logInfo("------ Change battery health with write caching eabled ---------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # Validate the global cache settings for the controllers.
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Validate the battery state for the controllers
    #
    $retVal = WrtCacheValidateDSCBatteries($coPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Validate the mirroring state for the controllers
    #
    $retVal = WrtCacheValidateDSCMirrors($coPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # find the master controller
    #
    $master = FindMaster($coPtr);
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    #
    # Recreate the controller array and get the master controller object
    # 
    @coList = @$coPtr;
    $controller = $coList[$master];

    #
    # Get the current mirror partner settings
    #
    %rspVCGMPList = $controller->vcgMPList();

    if (!%rspVCGMPList)
    {
        logInfo("    ====> Failed to get response from vcgMPList command <====");
        logInfo("    ====> $coList[$master]{HOST}                        <====");
        return ERROR;
    }

    if ($rspVCGMPList{STATUS} != PI_GOOD)
    {
        logInfo("    ====> Error from vcgMPList command <====");
        logInfo("    ====> $coList[$master]{HOST}       <====");
        PrintError(%rspVCGMPList);
        return ERROR;
    }

    #
    # Validate the current mirror partner settings
    #
    $retVal = MirrorPartnerCheck($controller);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed while validating mirror partners <====");
        logInfo("    ====> $coList[$master]{HOST}                  <====");
        return (ERROR);
    }

    #
    # Select random controller
    #
    $iController = rand(scalar(@coList));

    #
    # Get the controller object
    #
    $controller = $coList[$iController];

    #
    # Find the source mirror partner for this controller (this is the
    # controller mirroring to this controller).
    #
    for ($iController = 0; $iController < $rspVCGMPList{COUNT}; $iController++)
    {
        if ($rspVCGMPList{MPLIST}[$iController]{DEST} == $controller->{SERIAL_NUM})
        {
            $srcMP = $rspVCGMPList{MPLIST}[$iController]{SOURCE};
            last;
        }
    }

    #
    # Make sure we found the source mirror partner controller
    #
    if ($srcMP == 0)
    {
        logInfo("    ====> Failed to find the source mirror parnter controller <====");
        logInfo("    ====> $coList[$master]{HOST}                              <====");
        return ERROR;
    }

    #
    # Get the controller object for the source mirror partner
    #
    for ($iController = 0; $iController < scalar(@coList); $iController++)
    {
        $srcController = $coList[$iController];

        #
        # Is this the source mirror partner controller object
        #
        if ($srcMP == $srcController->{SERIAL_NUM})
        {
            #
            # Yes, exit from the loop
            #
            last;
        }
    }

    #
    # Make sure we found the source mirror partner controller object
    #
    if ($srcController == 0)
    {
        logInfo("    ====> Failed to find the source mirror parnter controller object <====");
        logInfo("    ====> $coList[$master]{HOST}                                     <====");
        return ERROR;
    }

    #
    # Display the current global cache information
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($controller);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed while displaying global cache information <====");
        logInfo("    ====> $coList[$master]{HOST}                           <====");
        return (ERROR);
    }

    #
    # Change battery state to bad
    #
    $retVal = WrtCacheBatteryHealth($controller, WRTCACHE_BAT_BAD);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed to change battery health         <====");
        logInfo("    ====> $coList[$master]{HOST}                  <====");
        return (ERROR);
    }

    print "Delay to allow battery health change to take effect.\n";
    DelaySecs(10);

    #
    # Display the current global cache information
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($controller);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed while displaying global cache information <====");
        logInfo("    ====> $coList[$master]{HOST}                           <====");
        return (ERROR);
    }

    #
    # Validate that the FE battery state of the controller we changed
    # the battery state on is currently bad.
    #
    $retVal = WrtCacheValidateBattery($controller,
                                        WRTCACHE_BAT_FE,
                                        WRTCACHE_BAT_BAD);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> FE Battery state not as expected        <====");
        logInfo("    ====> $coList[$master]{HOST}                  <====");
        return (ERROR);
    }

    #
    # Validate that the BE battery state of source mirror partner
    # controller is currently bad.
    #
    $retVal = WrtCacheValidateBattery($srcController,
                                        WRTCACHE_BAT_BE,
                                        WRTCACHE_BAT_BAD);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> BE Battery state not as expected        <====");
        logInfo("    ====> $coList[$master]{HOST}                  <====");
        return (ERROR);
    }

    #
    # Validate that the controller with bad FE battery is in the
    # enable pending cache state.
    #
    $retVal = WrtCacheValidateCacheGlobal($controller, WRTCACHE_ENABLE_PENDING);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Global cache not enable pending as expected <====");
        logInfo("    ====> $coList[$master]{HOST}                      <====");
        return (ERROR);
    }

    #
    # Validate that the source mirror partner controller is in the
    # enable pending cache state.
    #
    $retVal = WrtCacheValidateCacheGlobal($srcController, WRTCACHE_ENABLE_PENDING);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Global cache not enable pending as expected <====");
        logInfo("    ====> $coList[$master]{HOST}                      <====");
        return (ERROR);
    }

    #
    # Display the current global cache information
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($controller);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed while displaying global cache information <====");
        logInfo("    ====> $coList[$master]{HOST}                           <====");
        return (ERROR);
    }

    #
    # Change battery state to good
    #
    $retVal = WrtCacheBatteryHealth($controller, WRTCACHE_BAT_GOOD);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed to change battery health         <====");
        logInfo("    ====> $coList[$master]{HOST}                  <====");
        return (ERROR);
    }

    print "Delay to allow battery health change to take effect.\n";
    DelaySecs(10);

    #
    # Display the current global cache information
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($controller);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed while displaying global cache information <====");
        logInfo("    ====> $coList[$master]{HOST}                           <====");
        return (ERROR);
    }

    #
    # Validate the global cache settings for the controllers.
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed while validating global write cache enabled <====");
        logInfo("    ====> $coList[$master]{HOST}                             <====");
        return (ERROR);
    }

    #
    # Validate the battery state for the controllers
    #
    $retVal = WrtCacheValidateDSCBatteries($coPtr);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed while validating battery states  <====");
        logInfo("    ====> $coList[$master]{HOST}                  <====");
        return (ERROR);
    }

    #
    # Validate the mirroring state for the controllers
    #
    $retVal = WrtCacheValidateDSCMirrors($coPtr);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Failed while validating mirror states   <====");
        logInfo("    ====> $coList[$master]{HOST}                  <====");
        return (ERROR);
    }

    logInfo("------ End WrtCache Test Case 07             -------------------");

    return GOOD;
}


##############################################################################
=head2 WrtCacheTestCase08 function

This test case inactivates a controller, monitors cache tags using a timeline
and powers off the controller when the outstanding cache tags reach zero. After 
a short time, the controller is powered up and the battery charge is verified.

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase08( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $moxaIPListPtr: The pointer to a list of moxa IP addresses that matches
                        the moxa map and object lists.
          
        $moxaChannelListPtr: A pointer to a list of Moxa channels. This list
                             indicates which channel on the Moxa controls the 
                             power to a controller.
                             


=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
#    33) Shutdown controller, Ensure cache is flushed, Power off for x time, 
#        Turn on and ensure battery is charged  <D1>
##############################################################################
sub WrtCacheTestCase08
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;
    my $cacheInUse = FALSE;
    my %rsp;
    my @snList;
    my $sn;
    my $victim;
    my $numControllers;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my %mirrorData;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my $startTime;
    my $stopTime;
    my $oldStopTime;
    my $maxTimeLineDuration = 3600;   # 1 hr timeout
    my $gcTagsDirty;
    my $someTagsDirty;
    my $timePrinted;
    my $gcStatus;
    my $gcBattery;
    my $gcStopCount;
    my $gcTagsResident;
    my $cNode;
    my %gcInfo;
    my $timeLine;
    my $duration = 1;
    my $displayBatteryStats = 0;
    
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 8                                -----");
    logInfo("------ Shutdown, Flush WC, power cycle and check batteries -----");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # Ensure we have enough controllers
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("    ====> This test case requires multiple controllers. Test case is skipped. <====");
        return ($retIn);
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    @coList = @$coPtr;         # recreate the controller array

    $ctlr = $coList[$master];  # Get original master object
    
    $victim = $master;
    
    #
    # Get number of controllers
    #
    $numControllers = ( scalar(@coList));

    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }

    # get measure of the current IO

    $retVal = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                               \@initialVdisks, \@tMap, 20, 10);

    #
    # Enable Global and all Vdisk write cache
    #
    $retVal = WrtCacheControl($ctlr,  WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # If single controller
    #
    #if ( $numControllers == 1 )
    #{
    #    logInfo("Test case 8 run with a single controller.");
    #    logInfo("This test case requires user intervention");
    #    logInfo("to stop I/O on all servers.");
    #    logInfo("");
    #    logInfo("Hit return FIRST and THEN turn off IO to all servers.");
    #    logInfo("");
    #
    #    # Prompt user to stop test while user reads message above
    #    $retVal = PromptUser( 8 );
    #
    #    #
    #    # Test and Reconnect (in case timeout occurs from slow user response)
    #    #
    #    TestNReconnectAll($coPtr);          # refresh any connections
    #
    #}


    #
    # Inactivate controller
    #
    $retVal = FailOverController($coPtr, $victim, "IC" );    
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Error during FailOverController            <====");
        logInfo("    ====> on controller $ctlr->{HOST}                <====");
        logInfo("    ====> $coList[$master]{HOST}                     <====");
        return ERROR;
    }

    
    #
    # Watch cache tags go to zero
    #
    $retVal = WrtCacheTimeLine( $coPtr, $snPtr, $victim, $maxTimeLineDuration, 
                                 $displayBatteryStats );
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Error during WrtCacheTagsTimeLine          <====");
        logInfo("    ====> on controller $ctlr->{HOST}                <====");
        logInfo("    ====> $coList[$master]{HOST}                     <====");
        return ERROR;
    }

    #
    # Power off
    #
    $retVal = PowerChange($$moxaIPListPtr[$master], $$moxaChannelListPtr[$master], 0);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Error turning off power to $coList[$master]{HOST} <====");
        return ERROR;
    }
    
    #
    # Delay for x time (needs to be less than 30 min to prevent losing communication with master)
    #
    DelaySecs(1500);           # Let it fail (25 MIN PRODUCTION)
    #DelaySecs(120);           # Let it fail (2 MIN TEST)

    #
    # Power on
    #
    $retVal = PowerChange($$moxaIPListPtr[$master], $$moxaChannelListPtr[$master], 1);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Error turning on power to $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # unfail immediately (multiple controllers only)
    #
    if($numControllers > 1)
    {
        #
        # unfail the controller
        #
        logInfo("          Unfail the controller");
        $retVal = UnfailAll($coPtr, $snPtr, $moxaIPListPtr, $moxaChannelListPtr );
        if ( $retVal != GOOD ) 
        { 
            logInfo("    ====> Controller failed to return <===="); 
            logInfo("    ====> $coList[$master]{HOST} retVal = $retVal <====");
            return ERROR; 
        }
    }
    
    #
    # Delay for x time
    #
    DelaySecs(120); 

    #
    # Ensure battery is charged
    #
    $retVal = WrtCacheValidateDSCBatteries($coPtr);
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Error during WrtCacheValidateDSCBatteries <====");
        logInfo("    ====> $coList[$master]{HOST}                    <====");
        return ERROR;
    }
        
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

# restore the caching to previous state here
    #
    # Display globalCacheInfo (prior to change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$victim]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (to witness change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info (to witness change)
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # If single controller
    #
    #if ( $numControllers == 1 )
    #{
    #    #
    #    # Prompt user to restart I/O
    #    #
    #    logInfo("Restart IO and then hit return to continue");
    #
    #    #
    #    # Stop test while user reads message above
    #    #
    #    $retVal = PromptUser( 8 );
    #
    #    DelaySecs(60);  # to allow IO to resume
    #}

    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );

    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing got broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }
    

    logInfo("------ End WrtCache Test Case 8              -------------------");
        
    return GOOD;
    
}


##############################################################################
=head2 WrtCacheTestCase09 function

This test case requires the user manually stop IO and then powers down the 
controller for $timeOut to allow the cache card batteries to discharge below 
the global cache enable threshold. After the timeout, the controller is powered
up and battery statistics as well as applicable global cache info is logged 
for each controller until global cache is enabled. This test case runs twice;
once for unfail immediately and once for unfail after some delay (currently 60 sec).

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase09( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $moxaIPListPtr: The pointer to a list of moxa IP addresses that matches
                        the moxa map and object lists.
          
        $moxaChannelListPtr: A pointer to a list of Moxa channels. This list
                             indicates which channel on the Moxa controls the 
                             power to a controller.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
#    16) Power off a controller, wait a while, power on, Observe the 
#        charging of the battery (env statistics) and when cache turns 
#        back on. Do this for cases where the the controller is unfailed
#        immediately and unfailed after some delay. Need to look at cache
#        state of all controllers in the CNC. (Output is some sort of
#        timeline?) <D1>
##############################################################################
sub WrtCacheTestCase09
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;
    my %batteryStats;
    my $batteryStatsPtr;
    my $numControllers;
    my $msg;
    my $globalOn;
    my $startTime;
    my $stopTime;
    my $oldStopTime;
    my $maxTimeLineDuration = 14400;   # 4 hrs (5 hrs => bad battery)
    my %gcInfo;
    my $timePrinted;
    my $i;
    my $gcStatus;
    my $gcBattery;
    my $gcStopCount;
    my $cNode;
    my $timeLine;
    my $loops;
    my $timeOut = 43200;    # Delay for 12 hrs to allow battery discharge
    my $duration = 1;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my %mirrorData;
    my $initialGlobalCacheState;
    my $initialVdiskCacheState;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @activeCtlrs;
    my $victim;
    my $displayBatteryStats = 1;
    my $CBWminutes = 120;   # 2 hour timeout
        
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 9                     ----------------");
    logInfo("------ Observe battery charging and cache state ----------------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    @coList = @$coPtr;         # recreate the controller array

    #
    # Get number of controllers
    #
    $numControllers = ( scalar(@coList));

    #
    # No controllers present (fail test)
    #
    if ( $numControllers == 0 )
    {
        logInfo("    ====> No controllers present. Test case is skipped <====");
        return ERROR;
    } 
    
    logInfo("This test case requires user intervention. I/O must be shut down");
    logInfo("on all servers when requested. The master controller is powered");
    logInfo("off for $timeOut seconds. This allows the batteries on the cache");
    logInfo("card to fall below the threshold to disable global cache. As the");
    logInfo("battery is charging, the test monitors globalCache and exits when");
    logInfo("enable-pending changes to enabled. I/O will need to be restarted");
    logInfo(" when the test is complete.");
    logInfo("");
    
    #
    # Stop test while user reads message above
    #
    $retVal = PromptUser( 8 );

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }
    
    #
    # Set victim to current master
    #
    $victim = $master;

    $ctlr = $coList[$master];  # Get master object
    
    $cNode = $ctlr & 0x0f;     # Initialize cNode to this controller

    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }

    #
    # get measure of the current IO
    #
    $retVal = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, 
                               \@initialVdisks, \@tMap, 20, 10);
    
    #
    # Enable Global and all Vdisk write cache
    #
    $retVal = WrtCacheControl($ctlr,  WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Prompt user to stop I/O (shuting down controller)
    #
    logInfo("Turn off IO to all servers; THEN Hit return to continue.");
    logInfo("");
    
    # Prompt user to stop test while user reads message above
    $retVal = PromptUser( 8 );
    

    #
    # Fail immediately ($loops = 0) and also after some delay ($loops = 1)
    #
    for ($loops = 0; $loops < 2; $loops++)
    {    
        #
        # Power off Controller
        #
        $retVal = PowerChange($$moxaIPListPtr[$victim], $$moxaChannelListPtr[$victim], 0);
        if ( $retVal != GOOD )
        {
            #
            # Log error with IPaddress of controller
            #
            logInfo("    ====> Error turning off power to $coList[$victim]{HOST} <====");
            return ERROR;
        }
    
        #
        # Delay for batteries to drain (Try 12 hours)
        #
        DelaySecs($timeOut);

        if($numControllers == 1)
        {
            #
            # Turn Controller back on to prevent failing UnfailAll (1-way)
            #
            $retVal = PowerChange($$moxaIPListPtr[$victim], $$moxaChannelListPtr[$victim], 1);
            if ( $retVal != GOOD )
            {
                logInfo("    ====> Error turning on power to $coList[$victim]{HOST} <====");
                return ERROR;
            }

            #
            # Reconnect
            #
            $retVal = Reconnect( $ctlr, 60 );
            if ( $retVal == ERROR )
            {
                logInfo("    ====> Failed to reconnect to the controller   <====");
                logInfo("    ====> $coList[$victim]{HOST} retVal = $retVal <====");
                return ERROR;
            }

            #
            # wait for the controller to sufficiently boot
            #
            logInfo("      Reconnect complete. Checking power up state. ");
            Wait4MinPowerUpState($ctlr, POWER_UP_FAILED, 480);          

            logInfo("      Power up state verified. ");

        }
        else
        {
            #
            # Reconnect all active controllers
            #
            for ( $i = 0; $i < $numControllers; $i++)
            {
                #
                # If victim (skip)
                #
                if ($i != $victim)
                {
                    push ( @activeCtlrs, $coList[$i] );
                }
                
            }
        
            #
            # Test and Reconnect
            #
            #TestNReconnectAll($coPtr);          # refresh any connections
            TestNReconnectAll(\@activeCtlrs);          # refresh any slave connections
            
        }

        #
        # unfail immediately (first loop, multiple controllers only)
        #
        if($loops == 0 && $numControllers > 1)
        {
            #
            # unfail the controller
            #
            logInfo("          Unfail the controller");
            $retVal = UnfailAll($coPtr, $snPtr, $moxaIPListPtr, $moxaChannelListPtr );
            if ( $retVal != GOOD ) 
            { 
                logInfo("    ====> Controller failed to return <===="); 
                logInfo("    ====> $coList[$victim]{HOST} retVal = $retVal <====");
                return ERROR; 
            }
        }

        #
        # unfail after some delay (##### Should numControllers > 1 be removed to allow 1-way to pick up delay)
        #
        if ($loops == 1)
        {
            #
            # Delay for 1 min before unfail
            #
            DelaySecs(60);
            
            #
            # Unfail not needed for single controllers
            #
            if ( $numControllers > 1 )
            {
                logInfo("          Unfail the controller (after delay)");
                $retVal = UnfailAll($coPtr, $snPtr, $moxaIPListPtr, $moxaChannelListPtr );
                if ( $retVal != GOOD ) 
                { 
                    logInfo("    ====> Controller failed to return             <===="); 
                    logInfo("    ====> $coList[$victim]{HOST} retVal = $retVal <====");
                    return ERROR; 
                }
            }
        }
        
        #
        # This WrtCacheTagsTimeLine snippet should replace the code between the "Watch cache tags go to zero" tags
        #
        $retVal = WrtCacheTimeLine( $coPtr, $snPtr, $victim, $maxTimeLineDuration, 
                                     $displayBatteryStats );
        if ( $retVal != GOOD )
        {
            logInfo("    ====> Error during WrtCacheTagsTimeLine          <====");
            logInfo("    ====> on controller $ctlr->{HOST}                <====");
            logInfo("    ====> $coList[$master]{HOST}                     <====");
            return ERROR;
        }


        logInfo("");
        
        #
        # Wait for batteries to be charged
        #
        $retVal = WrtCacheWaitForBatteries($coPtr, $CBWminutes);
    
        #
        # Batteries are still bad (return error)
        #
        if ($retVal != GOOD)
        {
            logInfo("    ====> Error: Batteries did not charge in time after unfailing controller(s).");
            logInfo("    ====> Error during WrtCacheWaitForBatteries on $coList[$i]{HOST} <====");
            return ERROR;
        }
        
#        #
#        #Ensure battery is charged
#        #
#        $retVal = WrtCacheValidateDSCBatteries($coPtr);
#    
#        if ( $retVal != GOOD )
#        {
#            logInfo("    ====> Error during WrtCacheValidateDSCBatteries on $coList[$i]{HOST} <====");
#            return ERROR;
#        }
    
    }    

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

# restore the caching to previous state here
    #
    # Display globalCacheInfo (prior to change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (to witness change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info (to witness change)
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Prompt user to restart I/O
    #
    logInfo("Restart IO and then hit return to continue");

    #
    # Stop test while user reads message above
    #
    $retVal = PromptUser( 8 );

    DelaySecs(60);  # to allow IO to resume
    
    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing got broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 9              -------------------");
        
    return GOOD;
    
}

##############################################################################
=head2 WrtCacheTestCase10 function

This test case requires the user manually stop IO and then verifies dirty  cache
tags are moved to resident tags.

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase10( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $moxaIPListPtr: The pointer to a list of moxa IP addresses that matches
                        the moxa map and object lists.
          
        $moxaChannelListPtr: A pointer to a list of Moxa channels. This list
                             indicates which channel on the Moxa controls the 
                             power to a controller.

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
#    34) - Write cache enabled w/ cache in use
#        - Stop I/O to the servers (by hand)
#        - Ensure that all dirty write cache tags are moved to resident tags.
##############################################################################
sub WrtCacheTestCase10
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;
    my $numControllers;
    my $startTime;
    my $stopTime;
    my $oldStopTime;
    my $maxTimeLineDuration = 3600;   # 1 hr timeout
    my %gcInfo;
    my $timePrinted;
    my $i;
    my $gcStatus;
    my $gcBattery;
    my $gcStopCount;
    my $gcTagsDirty;
    my $someTagsDirty;
    my $gcTagsResident;
    my $cNode;
    my $timeLine;
    my $duration = 1;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my %mirrorData;
    my $numVdisks;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my $victim;
    my $displayBatteryStats = 0;
        
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 10                 -------------------");
    logInfo("------ Ensure dirty wcache tags are moved to -------------------");
    logInfo("------ resident tags when I/O is stopped     -------------------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    @coList = @$coPtr;         # recreate the controller array

    #
    # Get number of controllers
    #
    $numControllers = ( scalar(@coList));

    #
    # No controllers present (fail test)
    #
    if ( $numControllers == 0 )
    {
        logInfo("    ====> No controllers present. Test case is skipped <====");
        return ERROR;
    } 
    
    logInfo("This test case requires user intervention. I/O must be shut down");
    logInfo("on all servers when the test requests. Monitors dirty cache tags");
    logInfo("until they are zero, printing the statistics during each loop.");
    logInfo("");
    
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    $victim = $master;
    
    $cNode = $ctlr & 0x0f;     # Initialize cNode to this controller

    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }
    
    #
    # Enable Global and all Vdisk write cache
    #
    $retVal = WrtCacheControl($ctlr,  WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    logInfo("Hit return FIRST and THEN turn off IO to all servers.");
    logInfo("");
    
    #
    # Prompt to stop test while user reads message above
    #
    $retVal = PromptUser( 8 );


    #
    # Test and Reconnect
    #
    TestNReconnectAll($coPtr);          # refresh any connections

    #
    # This WrtCacheTagsTimeLine snippet should replace the code between the "Watch cache tags go to zero" tags
    #
    $retVal = WrtCacheTimeLine( $coPtr, $snPtr, $victim, $maxTimeLineDuration, 
                                 $displayBatteryStats );
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Error during WrtCacheTagsTimeLine          <====");
        logInfo("    ====> on controller $ctlr->{HOST}                <====");
        logInfo("    ====> $coList[$master]{HOST}                     <====");
        return ERROR;
    }


    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

# restore the caching to previous state here
    #
    # Display globalCacheInfo (before the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (after the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Prompt user to restart I/O
    #
    logInfo("Restart IO and then hit return to continue");

    #
    # Stop test while user reads message above
    #
    $retVal = PromptUser( 8 );

    DelaySecs(60);  # to allow IO to resume
    
    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing was broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 10              -------------------");


    return GOOD;
    
}

##############################################################################
=head2 WrtCacheTestCase11 function

This test case verifies control of Global and Vdisk Write Cache in 4 stages.

  STAGE 1: ATTEMPTs to control Global and Vdisk Write Cache with a Slave 
  controller. NOTE: This should not be possible and is EXPECTED to report 
  command errors. Should a Slave successfully enable/disable either Global  
  cache or Vdisk cache, the reversed logic will return an error and fail
  the test.

  STAGE 2: Enables and disables each controllers vdisks with Global Cache 
  ON and OFF. Verification is performed from each controller.

  STAGE 3: Various combinations of multiple enabling and disabling of 
  Global Write Cache to verify proper operation.

  STAGE 4: Various combinations of multiple enabling and disabling of Vdisk 
  Write Cache to verify proper operation. Each loop of stage 4 is done on a 
  single controller's vdisks. Each successive loop is done on the next 
  controller's vdisks until the controller list is exhausted.

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase11( $coPtr, $retIn, $snPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be error messages in the logs when attempting to control the 
    write cache with a slave controller.  This is normal.
     
    The script should end WITH errors showing on the screen sililar to:
    "You are not the master error".

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
#    17) Check ability to enable/disable cache on the slaves as well as 
#        he master controller. <D2>
##############################################################################
sub WrtCacheTestCase11
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;
    my $retVal1;
    my $retVal2;
    my $numControllers;
    my $i;
    my $owner;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my %mirrorData;
    my $numVdisks;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my $vdiskOwner;
    my $vdiskID;
    my %controllerHash;
    my $controller;
    my $verifyController;
    my $globalSetRequest;
    my $globalSetRequestText;
    my $globalResetRequest;
    my $globalValidateRequest;
    my $vdiskSetRequest;
    my $vdiskSetRequestText;
    my $vdiskSetRequest1;
    my $vdiskSetRequest1Text;
    my $vdiskSetRequest2;
    my $vdiskSetRequest2Text;
    my $vdiskValidateRequest;
    my $first;
    my @controllerHashKeys;
    my $sizeOfHash;
    my $thisKey;
    my $thisKeyVdisksPtr;
    my $loop;
    my $slave;
    my $vdisksPtr;
    my $errorFlag = 0;
       
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 11:                              ------");
    logInfo("------ Verify successful control of global and vdisk      ------");
    logInfo("------ cache from master controller using various         ------");
    logInfo("------ combinations. Verification is performed from       ------");
    logInfo("------ each controller's perspecttive. Also verifies      ------");
    logInfo("------ Unsuccessful control of global and vdisk cache     ------");
    logInfo("------ from a slave controller.                           ------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("    ====> This test case requires multiple controllers. Test case is skipped. <====");
        return ($retIn);
    }

    @coList = @$coPtr;         # recreate the controller array

    #
    # Get number of controllers
    #
    $numControllers = ( scalar(@coList));
    
    #
    # No controllers present (fail test)
    #
    if ( $numControllers == 0 )
    {
        logInfo("    ====> No controllers present. Test case is skipped <====");
        return ERROR;
    } 
    
    logInfo("This test case verifies control of Global and Vdisk Write Cache");
    logInfo("in 4 stages.");
    logInfo("");
    logInfo("STAGE 1: ATTEMPTs to control Global and Vdisk Write Cache with a");
    logInfo("Slave controller. NOTE: This should not be possible and is EXPECTED");
    logInfo("to report command errors. Should a Slave successfully enable/disable either Global");
    logInfo("cache or Vdisk cache, the reversed logic will return an error and");
    logInfo("fail the test.");
    logInfo("");
    logInfo("STAGE 2: Enables and disables each controllers vdisks with Global");
    logInfo("Cache ON and OFF. Verification is performed from each controller.");
    logInfo("");
    logInfo("STAGE 3: Various combinations of multiple enabling and disabling ");
    logInfo("of Global Write Cache to verify proper operation.");
    logInfo("");
    logInfo("STAGE 4: Various combinations of multiple enabling and disabling");
    logInfo("of Vdisk Write Cache to verify proper operation. Each loop of stage");
    logInfo("4 is done on a single controller's vdisks. Each successive loop is");
    logInfo("done on the next controller's vdisks until the controller list is");
    logInfo("exhausted.");
    logInfo("");
    
    DelaySecs(10);  # To allow user to read text above
        
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }
    

    #
    # Build dynamic lists of vdisks for each controller
    # Use hash so we can reference the controller (ie 00, 01, etc) and it's vdisks
    # Also a 2-dimentioal array gets weird when we are missing a controller
    #
    $numVdisks = $mirrorData{VDISKS}{COUNT};

    #
    # Create hash of arrays (lists of vdisks by controller)
    #
    for($i = 0; $i < $numVdisks; $i++)
    {
        # Capture VID and OWNER
        $vdiskID    = $mirrorData{VDISKS}{VDISKS}[$i]{VID};
        $vdiskOwner = $mirrorData{VDISKS}{VDISKS}[$i]{OWNER};

        # Push the vid to the owner array pointed at by the hash key
        push ( @{$controllerHash{$vdiskOwner}}, $vdiskID );
    }
    
    #
    # Initialize Flag to indicate first loop
    #
    $first = 1;
    
    #
    # Generate list of hash keys and shove into an array
    #
    @controllerHashKeys = sort keys %controllerHash;
    $sizeOfHash = scalar(@controllerHashKeys);
    
    ####################################################################
    #
    # Try to control write cache with a slave controller
    #
    ####################################################################
    logInfo("");
    logInfo("WrtCacheTestCase11 Stage 1 begin ...");
    
    
    foreach $slave (@coList)
    {
        #
        # If slave is not same as master (Not a 1-Way)
        #
        if ($slave != $coList[$master])
        {
            #
            # Try to Enable global write cache with slave controller
            #
            logInfo("");
            logInfo("Attempting to enable global write cache with slave");
            logInfo("NOTE: Error messages will be generated!");
            $retVal = WrtCacheControlGlobal($slave, WRTCACHE_GLOBAL_SET_ENABLE);
            if ( $retVal == GOOD )
            {
                logInfo("    ====> Slave was allowed to enable Global Write Cache - test failed. ====>");
                return (ERROR);
            }

            #
            # Try to Disable global write cache with slave controller
            #
            logInfo("");
            logInfo("Attempting to disable global write cache with slave");
            logInfo("NOTE: Error messages will be generated!");
            $retVal = WrtCacheControlGlobal($slave, WRTCACHE_GLOBAL_SET_DISABLE);
            if ( $retVal == GOOD )
            {
                logInfo("    ====> Slave was allowed to disable Global Write Cache - test failed. ====>");
                return (ERROR);
            }

            #
            # Try to Enable write cache on all vdisks with slave controller
            #
            logInfo("");
            logInfo("Attempting to enable vdisk write cache with slave");
            logInfo("NOTE: Error messages will be generated!");
            $retVal = WrtCacheControlVdisksAll($slave, WRTCACHE_VDISKS_SET_ENABLE);
            if ( $retVal == GOOD )
            {
                logInfo("    ====> Slave was allowed to enable Vdisk Write Cache - test failed. ====>");
                return (ERROR);
            }
        
            #
            # Try to Disable write cache on all vdisks with slave controller
            #
            logInfo("");
            logInfo("Attempting to disable vdisk write cache with slave");
            logInfo("NOTE: Error messages will be generated!");
            $retVal = WrtCacheControlVdisksAll($slave, WRTCACHE_VDISKS_SET_DISABLE);
            if ( $retVal == GOOD )
            {
                logInfo("    ====> Slave was allowed to disable Vdisk Write Cache - test failed. ====>");
                return (ERROR);
            }
        
        } # End if
        
    } # end foreach controller

    ####################################################################
    #
    # Control write cache with master and validate with all controllers
    #
    ####################################################################
    logInfo("");
    logInfo("WrtCacheTestCase11 Stage 2 begin ...");

    #
    # for all controllers
    #
    for ($owner = 0; $owner < $sizeOfHash; $owner++)
    {
        #
        # Select controller from hash
        #
        $thisKey = $controllerHashKeys[$owner];
        
        #
        # set pointer to this controller's vdisks
        #
        $thisKeyVdisksPtr = \@{$controllerHash{$thisKey}};
        
        #
        # $master controls $thisKey vdisks
        # Enable/Disable vdisks (with global on and global off)
        #
        for ($loop = 0; $loop < 4; $loop++)
        {
            #
            # Enable this controllers vdisks (global cache enabled)
            #
            if ($loop == 0)
            {
                #
                # set request variables 
                #
                $globalSetRequest = WRTCACHE_GLOBAL_SET_ENABLE;
                $globalSetRequestText = "WRTCACHE_GLOBAL_SET_ENABLE";
                $globalResetRequest = WRTCACHE_GLOBAL_SET_DISABLE;
                $globalValidateRequest = WRTCACHE_ENABLED;
                $vdiskSetRequest = WRTCACHE_VDISKS_SET_ENABLE;
                $vdiskValidateRequest = WRTCACHE_ENABLED;
            }
            
            #
            # Disable this controllers vdisks (global cache enabled)
            #
            elsif ($loop == 1)
            {
                #
                # set request variables 
                #
                $globalSetRequest = WRTCACHE_GLOBAL_SET_ENABLE;
                $globalSetRequestText = "WRTCACHE_GLOBAL_SET_ENABLE";
                $globalResetRequest = WRTCACHE_GLOBAL_SET_DISABLE;
                $globalValidateRequest = WRTCACHE_ENABLED;
                $vdiskSetRequest = WRTCACHE_VDISKS_SET_DISABLE;
                $vdiskValidateRequest = WRTCACHE_DISABLED;
            }
            
            #
            # Enable this controllers vdisks (global cache disabled)
            #
            elsif ($loop == 2)
            {
                #
                # set request variables 
                #
                $globalSetRequest = WRTCACHE_GLOBAL_SET_DISABLE;
                $globalSetRequestText = "WRTCACHE_GLOBAL_SET_DISABLE";
                $globalResetRequest = WRTCACHE_GLOBAL_SET_ENABLE;
                $globalValidateRequest = WRTCACHE_DISABLED;
                $vdiskSetRequest = WRTCACHE_VDISKS_SET_ENABLE;
                $vdiskValidateRequest = WRTCACHE_ENABLED;
            }
            
            #
            # Disable this controllers vdisks (global cache disabled)
            #
            else
            {
                #
                # set request variables 
                #
                $globalSetRequest = WRTCACHE_GLOBAL_SET_DISABLE;
                $globalSetRequestText = "WRTCACHE_GLOBAL_SET_DISABLE";
                $globalResetRequest = WRTCACHE_GLOBAL_SET_ENABLE;
                $globalValidateRequest = WRTCACHE_DISABLED;
                $vdiskSetRequest = WRTCACHE_VDISKS_SET_DISABLE;
                $vdiskValidateRequest = WRTCACHE_DISABLED;
            }
        
            
            #
            # Control global write cache
            #
            logInfo("Controlling global write cache");
            logInfo("globalSetRequest is: $globalSetRequestText");
            $retVal = WrtCacheControlGlobal($ctlr, $globalSetRequest);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }

            #
            # Display globalCacheInfo (From this controller)
            #
            $retVal = WrtCacheDisplayGlobalCacheInfo($coList[$thisKey]);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
        
            #
            # $master controls this controller's vdisks
            #
            logInfo("Controlling vdisk write cache");
            logInfo("vdiskSetRequest is: $vdiskSetRequestText");
            logInfo("vdisks involved: @$thisKeyVdisksPtr");
            $retVal = WrtCacheControlVdisksMultiple($coList[$master], 
                                                    $vdiskSetRequest, 
                                                    $thisKeyVdisksPtr);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }

    
            DelaySecs(5);  # Allow cache to flush (disable only)
            
            #
            # Display Vdisk Info (From this controller)
            #
            $retVal = DispVdiskInfo($coList[$thisKey]);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }

            $errorFlag = 0;
            #
            # For each controller
            #
            foreach $controller (@coList)
            {
                #
                # Verify global cache is in correct state
                #
                $retVal1 = WrtCacheValidateCacheGlobal($controller, 
                                                      $globalValidateRequest);

                #
                # Verify all vdisk cache is in correct state
                #
                $retVal2 = WrtCacheValidateCacheVDiskList($controller, 
                                                         $vdiskValidateRequest,
                                                         $thisKeyVdisksPtr);
                
                if ( $retVal1 != GOOD || $retVal2 != GOOD)
                {
                    #
                    # Display globalCacheInfo (From this controller)
                    #
                    $retVal = WrtCacheDisplayGlobalCacheInfo($coList[$thisKey]);
                    if ( $retVal != GOOD )
                    {
                        return (ERROR);
                    }
        
                    #
                    # Display Vdisk Info (From this controller)
                    #
                    $retVal = DispVdiskInfo($coList[$thisKey]);
                    if ( $retVal != GOOD )
                    {
                        return (ERROR);
                    }
                    
                    $errorFlag = 1;
                }

            } # end foreach controller
            
            #
            # If any controller fails to see correct Global or Vdisk Write 
            # Cache state (fail)
            #
            if ( $errorFlag == 1 )
            {
                return (ERROR);
            }

        } # end for loop (4 conditions)
        
    } # end for loop (each controller)
            
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

    ####################################################################
    #
    # Combinations of Enable/Disable Global Cache
    #
    ####################################################################
    logInfo("WrtCacheTestCase11 Stage 3 begin ...");

    #
    # Case 1: Master enables global cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Master disables global cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    DelaySecs(5);  # Allow cache to flush (disable only)

    #
    # Verify global cache is disabled (For each controller)
    #
    foreach $controller (@coList)
    {
        $retVal = WrtCacheValidateCacheGlobal($controller, 
                                              WRTCACHE_DISABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

    }
    
    #
    # Case 2
    #
    # Master disables global cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Master enables global cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #DelaySecs(5);  # Allow cache to flush (disable only)

    #
    # Verify global cache is enabled (For each controller)
    #
    foreach $controller (@coList)
    {
        $retVal = WrtCacheValidateCacheGlobal($controller, 
                                              WRTCACHE_ENABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

    }
    
    #
    # Case 3
    #
    # Master enables global cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Master disables global cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Master enables global cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Verify global cache is enabled (For each controller)
    #
    foreach $controller (@coList)
    {
        $retVal = WrtCacheValidateCacheGlobal($controller, 
                                              WRTCACHE_ENABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

    }
    
    #
    # Case 4
    #
    # Master disables global cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Master enables global cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Master disables global cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    DelaySecs(5);  # Allow cache to flush (disable only)

    #
    # Verify global cache is enabled (For each controller)
    #
    foreach $controller (@coList)
    {
        $retVal = WrtCacheValidateCacheGlobal($controller, 
                                              WRTCACHE_DISABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

    }

    ####################################################################
    #
    # Combinations of Enable/Disable Vdisk Cache
    #
    ####################################################################
    logInfo("WrtCacheTestCase11 Stage 4 begin ...");
        
    foreach $controller (@coList)
    {
        #
        # set pointer to this controller's vdisks
        #
        $vdisksPtr = \@{$controllerHash{$controller}};

        #
        # Enable/Disable Vdisks (with global cache on and off)
        #
        for ($i = 0; $i < 4; $i++)
        {
            #
            # Enable/Disable Vdisk Write Cache (global cache enabled)
            #
            if ($i == 0)
            {
                #
                # Set request variables 
                #
                $globalSetRequest = WRTCACHE_GLOBAL_SET_ENABLE;
                $globalSetRequestText = "WRTCACHE_GLOBAL_SET_ENABLE";
                $globalValidateRequest = WRTCACHE_ENABLED;
                $vdiskSetRequest1 = WRTCACHE_VDISKS_SET_ENABLE;
                $vdiskSetRequest1Text = "WRTCACHE_VDISKS_SET_ENABLE";
                $vdiskSetRequest2 = WRTCACHE_VDISKS_SET_DISABLE;
                $vdiskSetRequest2Text = "WRTCACHE_VDISKS_SET_DISABLE";
                $vdiskValidateRequest = WRTCACHE_DISABLED;
            }
            #
            # Disable/Enable Vdisk Write Cache (global cache enabled)
            #
            elsif ($i == 1)
            {
                #
                # Set request variables
                #
                $globalSetRequest = WRTCACHE_GLOBAL_SET_ENABLE;
                $globalSetRequestText = "WRTCACHE_GLOBAL_SET_ENABLE";
                $globalValidateRequest = WRTCACHE_ENABLED;
                $vdiskSetRequest1 = WRTCACHE_VDISKS_SET_DISABLE;
                $vdiskSetRequest1Text = "WRTCACHE_VDISKS_SET_DISABLE";
                $vdiskSetRequest2 = WRTCACHE_VDISKS_SET_ENABLE;
                $vdiskSetRequest2Text = "WRTCACHE_VDISKS_SET_ENABLE";
                $vdiskValidateRequest = WRTCACHE_ENABLED;
            }
            #
            # Enable/Disable Vdisk Write Cache (global cache disabled)
            #
            elsif ($i == 2)
            {
                #
                # Set request variables 
                #
                $globalSetRequest = WRTCACHE_GLOBAL_SET_DISABLE;
                $globalSetRequestText = "WRTCACHE_GLOBAL_SET_DISABLE";
                $globalValidateRequest = WRTCACHE_DISABLED;
                $vdiskSetRequest1 = WRTCACHE_VDISKS_SET_ENABLE;
                $vdiskSetRequest1Text = "WRTCACHE_VDISKS_SET_ENABLE";
                $vdiskSetRequest2 = WRTCACHE_VDISKS_SET_DISABLE;
                $vdiskSetRequest1Text = "WRTCACHE_VDISKS_SET_DISABLE";
                $vdiskValidateRequest = WRTCACHE_DISABLED;
            }
            #
            # Disable/Enable Vdisk Write Cache (global cache disabled)
            #
            else
            {
                #
                # Set request variables
                #
                $globalSetRequest = WRTCACHE_GLOBAL_SET_DISABLE;
                $globalSetRequestText = "WRTCACHE_GLOBAL_SET_DISABLE";
                $globalValidateRequest = WRTCACHE_DISABLED;
                $vdiskSetRequest1 = WRTCACHE_VDISKS_SET_DISABLE;
                $vdiskSetRequest1Text = "WRTCACHE_VDISKS_SET_DISABLE";
                $vdiskSetRequest2 = WRTCACHE_VDISKS_SET_ENABLE;
                $vdiskSetRequest2Text = "WRTCACHE_VDISKS_SET_ENABLE";
                $vdiskValidateRequest = WRTCACHE_ENABLED;
            }
            
            #
            # Control global write cache
            #
            logInfo("Controlling global write cache");
            logInfo("globalSetRequest is: $globalSetRequestText");
            $retVal = WrtCacheControlGlobal($ctlr, $globalSetRequest);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
    
            #
            # Display globalCacheInfo (From this controller)
            #
            $retVal = WrtCacheDisplayGlobalCacheInfo($controller);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
            
            #
            # Control write cache on this controller's vdisks
            #
            logInfo("Controlling vdisk write cache");
            logInfo("vdiskSetRequest1 is: $vdiskSetRequest1Text");
            logInfo("vdisks involved: @$vdisksPtr");
            $retVal = WrtCacheControlVdisksMultiple($ctlr, 
                                            $vdiskSetRequest1, 
                                            $vdisksPtr);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
    
            #
            # Control write cache on this controller's vdisks
            #
            logInfo("Controlling vdisk write cache");
            logInfo("vdiskSetRequest2 is: $vdiskSetRequest2Text");
            logInfo("vdisks involved: @$vdisksPtr");
            $retVal = WrtCacheControlVdisksMultiple($ctlr, 
                                            $vdiskSetRequest2, 
                                            $vdisksPtr);

            DelaySecs(5);  # Allow cache to flush (disable only)

            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
    
            #
            # Display Vdisk Info (From this controller)
            #
            $retVal = DispVdiskInfo($controller);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }

            $errorFlag = 0;

            #
            # Have each controller, verify this controller's write cache
            #
            foreach $verifyController (@coList)
            {
                #
                # Verify global cache is in correct state
                #
                $retVal1 = WrtCacheValidateCacheGlobal($verifyController, $globalValidateRequest);
                if ( $retVal != GOOD )
                {
                    return (ERROR);
                }

                #
                # Verify controller vdisk cache is in correct state
                #
                $retVal2 = WrtCacheValidateCacheVDiskList($verifyController, 
                                                         $vdiskValidateRequest,
                                                         $vdisksPtr);

                if ( $retVal1 != GOOD || $retVal2 != GOOD)
                {
                    #
                    # Display globalCacheInfo (From this controller)
                    #
                    $retVal = WrtCacheDisplayGlobalCacheInfo($coList[$thisKey]);
                    if ( $retVal != GOOD )
                    {
                        return (ERROR);
                    }
        
                    #
                    # Display Vdisk Info (From this controller)
                    #
                    $retVal = DispVdiskInfo($coList[$thisKey]);
                    if ( $retVal != GOOD )
                    {
                        return (ERROR);
                    }
                    
                    $errorFlag = 1;
                }
    
            } # end foreach verifyController
            
            if ( $errorFlag != GOOD )
            {
                return (ERROR);
            }

        } # end for loop (4 conditions)

    } # end foreach controller


    ###############################################################################
    
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

    ####################################################################
    #
    # Restore the write cache to initial state
    #
    ####################################################################

    #
    # Display globalCacheInfo (before the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (after the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing was broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 11              -------------------");

    return GOOD;
    
}

##############################################################################
=head2 WrtCacheTestCase12 function

This test case verifies stability of global and vdisk write cache using 
various combinations during failover.  2 loops of each of the following
failtypes:
  
    "CCBET"
    "FEET"
    "BEET"
    "PC"
    "IC"
    "FC"
    
  For a total of 12 loops (each time failover runs).
  
  The test case consists of 4 phases:

    1. Enable GC, Disable VC (all), FailoverNWay (12 loops), Is GC on, Is VC off

    2. Enable VC (random), FailoverNWay (12 Loops), Is GC on, Are select VC on/off

    3. Disable GC, FailoverNWay (12 Loops), Is GC off, Are select VC on/off

    4. Disable VC (all), FailoverNWay (12 Loops), Is GC off, Is VC off

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase12( $coPtr, 
                              $retIn, 
                              $snPtr, 
                              $moxaIPListPtr, 
                              $moxaChannelListPtr, 
                              $parmsPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $moxaIPListPtr: The pointer to a list of moxa IP addresses that matches
                        the moxa map and object lists.
          
        $moxaChannelListPtr: A pointer to a list of Moxa channels. This list
                             indicates which channel on the Moxa controls the 
                             power to a controller.

        $parmsPtr is a pointer to the list of test parms 

=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
sub WrtCacheTestCase12
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal = GOOD;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @theMeans = ("CCBET", "FEET", "BEET", "PC", "IC", "FC");
    my $i;
    my $vdiskListSelect;
    my $vdiskListOnPtr;
    my $vdiskListOffPtr;
    my @vdisks;
    my $vdisksPtr;
    my $numVDDs;
    my %parms;
    my @resources;
       
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 12:                             ------");
    logInfo("------ Verify stability of global and vdisk write cache   ------");
    logInfo("------ using various combinations during failover.        ------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # Ensure we have enough controllers
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("    ====> This test case requires multiple controllers. Test case is skipped. <====");
        return ($retIn);
    }

    @coList = @$coPtr;         # recreate the controller array

    #
    # Check if All/Alt/Random parameter is set and default to ALL if not
    #
    if (defined $parmsPtr->{vdisklistselect} )
    {
        #
        # Extract key from parmsPtr (how many vdisks to turn on)
        #
        $vdiskListSelect = $parmsPtr->{vdisklistselect};
    }
    else
    {
        logInfo("    ====> vdisklistselect parameter missing. Using Default of 'ALL' <====");
        $vdiskListSelect = 'all';
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }
    
    #
    # Get the list of existing vdisks
    #
    @vdisks = GetVdiskList( $ctlr );
    $vdisksPtr = \@vdisks;
    
    if ( $vdisks[0] == INVALID )
    {
        logInfo("    ====> Unable to retrieve list of virtual disk identifiers. <====");
        logInfo("    ====> $coList[$master]{HOST}                               <====");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    #
    # Call to All-Alt-Random routine to select vdisks
    #
    $vdiskListOnPtr = WrtCacheVdisksSelectAllAltRandom($coPtr, $vdisksPtr, $vdiskListSelect);

    #
    # Get pointer to the list of vdisks that are off
    #
    $vdiskListOffPtr = GetComplimentOfList($vdisksPtr, $vdiskListOnPtr);

    ####################################################################
    #
    # Enable GC, Disable VC (all), FailoverNWay (20 loops), Is GC on, Is VC off
    #
    ####################################################################

    #
    # Enable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Disable all vdisk write cache
    #
    $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    $parms{MIRRORRESYNCWAIT} = 3600;
    $parms{LOOPCOUNT} = 2;
    
    DelaySecs(5);   # allow cache to flush

    for($i = 0; $i < scalar(@theMeans); $i++)
    {
        $parms{FAILTYPE} = $theMeans[$i];

        @resources = ();
        
        $retVal = FailOverNWayLoop( \@coList, 
                                    $moxaIPListPtr, 
                                    $moxaChannelListPtr, 
                                    \@resources,            # pointer to resource array, can be empty array
                                    \%parms,                # misc parameter hash
                                    undef 
                                  );

            if ($retVal != GOOD)
            {
                # we be toast
                logInfo("    ====> ERROR during FailOverNWayLoop 1 <====");
                logInfo("    ====> $ctlr->{HOST}                   <====");
                logInfo("    ====> Fail Type = $theMeans[$i]       <====");
                return ERROR;
            }

    }
                
    
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify all vdisk cache is disabled
    #
    $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    ####################################################################
    #
    # Enable VC, FailoverNWay (20 Loops), Is GC on, Is VC on
    #
    ####################################################################

    #
    # enable select vdisk write cache
    #
    logInfo("Controlling vdisk write cache");
    logInfo("vdiskSetRequest is: WRTCACHE_VDISKS_SET_ENABLE");
    logInfo("vdisks involved: @$vdiskListOnPtr");
    $retVal = WrtCacheControlVdisksMultiple($ctlr, WRTCACHE_VDISKS_SET_ENABLE, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #DelaySecs(5);   # allow cache to flush

    for($i = 0; $i < scalar(@theMeans); $i++)
    {
        $parms{FAILTYPE} = $theMeans[$i];
        @resources = ();

        $retVal = FailOverNWayLoop( \@coList, 
                                    $moxaIPListPtr, 
                                    $moxaChannelListPtr, 
                                    \@resources,            # pointer to resource array, can be empty array
                                    \%parms,                # misc parameter hash
                                    undef 
                                  );

            if ($retVal != GOOD)
            {
                # we be toast
                logInfo("    ====> ERROR during FailOverNWayLoop 2 <====");
                logInfo("    ====> $ctlr->{HOST}                   <====");
                logInfo("    ====> Fail Type = $theMeans[$i]       <====");
                return ERROR;
            }

    }
                
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is enabled (list of vdisks with cache on)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisks with cache off)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    ####################################################################
    #
    # Disable GC, FailoverNWay (20 Loops), Is GC off, Is VC on
    #
    ####################################################################

    #
    # Disable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    DelaySecs(5);   # allow cache to flush

    for($i = 0; $i < scalar(@theMeans); $i++)
    {
        $parms{FAILTYPE} = $theMeans[$i];
        @resources = ();

        $retVal = FailOverNWayLoop( \@coList, 
                                    $moxaIPListPtr, 
                                    $moxaChannelListPtr, 
                                    \@resources,            # pointer to resource array, can be empty array
                                    \%parms,                # misc parameter hash
                                    undef 
                                  );

            if ($retVal != GOOD)
            {
                #
                # we be toast
                #
                logInfo("    ====> ERROR during FailOverNWayLoop 3 <====");
                logInfo("    ====> $ctlr->{HOST}                   <====");
                logInfo("    ====> Fail Type = $theMeans[$i]       <====");
                return ERROR;
            }

    }
                
    #
    # verify global write cache is disabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is enabled (list of vdisks with cache on)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisks with cache off)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    ####################################################################
    #
    # Disable VC, FailoverNWay (20 Loops), Is GC off, Is VC off
    #
    ####################################################################

    #
    # Disable all vdisk write cache
    #
    $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    
    DelaySecs(5);   # allow cache to flush

    for($i = 0; $i < scalar(@theMeans); $i++)
    {
        $parms{FAILTYPE} = $theMeans[$i];
        @resources = ();

        $retVal = FailOverNWayLoop( \@coList, 
                                    $moxaIPListPtr, 
                                    $moxaChannelListPtr, 
                                    \@resources,            # pointer to resource array, can be empty array
                                    \%parms,                # misc parameter hash
                                    undef 
                                  );

            if ($retVal != GOOD)
            {
                #
                # we be toast
                #
                logInfo("    ====> ERROR during FailOverNWayLoop 4 <====");
                logInfo("    ====> $ctlr->{HOST}                   <====");
                logInfo("    ====> Fail Type = $theMeans[$i]       <====");
                return ERROR;
            }

    }
                
    #
    # verify global write cache is disabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify all vdisk cache is disabled
    #
    $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    ############################################################################
    
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

    ####################################################################
    #
    # Restore the write cache to initial state
    #
    ####################################################################

    #
    # Display globalCacheInfo (before the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (after the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing was broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 12              -------------------");


    return GOOD;
    
}

##############################################################################
=head2 WrtCacheTestCase13 function

This test case verifies control of global and vdisk write cache using various 
combinations of enable/disable during failover.

1) Enable VC, Disable VC, Failover, verify GC is on and VC is off (GC ON)
 
2) Disable VC, Enable VC, Failover, verify GC is on and VC is on (GC ON)
  
3) Disable VC, Enable VC, FailoverNWay, verify GC is on and VC is on (GC ON)
  
4) Enable VC, Disable VC, FailoverNWay, verify GC is on and VC is off (GC ON)
  
  
Note: Repeat 1 - 4 above with GC OFF.
  
The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.


=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase13( $coPtr, 
                              $retIn, 
                              $snPtr, 
                              $moxaIPListPtr, 
                              $moxaChannelListPtr, 
                              $parmsPtr )

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $moxaIPListPtr: The pointer to a list of moxa IP addresses that matches
                        the moxa map and object lists.
          
        $moxaChannelListPtr: A pointer to a list of Moxa channels. This list
                             indicates which channel on the Moxa controls the 
                             power to a controller.

        $parmsPtr is a pointer to the list of test parms 

         
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
sub WrtCacheTestCase13
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal;
    my $numControllers;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @vdisks;
    my $vdisksPtr;
    my $vdiskListSelect;
    my $vdiskListOnPtr;
    my $vdiskListOffPtr;
    my $loop;
    my @theMeans = ("CCBET", "FEET", "BEET", "PC", "IC", "FC");
    my $globalRequest;
    my $vdisksRequest;
    my $i;
    my %fibreControl;   # hash for Neal's fibre connect/disconnect test
    my @resources;
    my %parms;
       
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 13:                             ------");
    logInfo("------ Verify control of global and vdisk write cache     ------");
    logInfo("------ using various combinations of enable/disable       ------");
    logInfo("------ during failover                                    ------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # Ensure we have enough controllers
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("    ====> This test case requires multiple controllers. Test case is skipped. <====");
        return ($retIn);
    }

    @coList = @$coPtr;         # recreate the controller array

    #
    # Get number of controllers
    #
    $numControllers = ( scalar(@coList));
    
    #
    # No controllers present (fail test)
    #
    if ( $numControllers == 0 )
    {
        logInfo("    ====> No controllers present. Test case is skipped <====");
        return ERROR;
    } 
    
    #
    # Check if All/Alt/Random parameter is set and default to ALL if not
    #
    if (defined $parmsPtr->{vdisklistselect} )
    {
        #
        # Extract key from parmsPtr (how many vdisks to turn on)
        #
        $vdiskListSelect = $parmsPtr->{vdisklistselect};
    }
    else
    {
        logInfo("    ====> vdisklistselect parameter missing. Using Default of 'ALL' <====");
        $vdiskListSelect = 'all';
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }
    
    #
    # Get the list of existing vdisks
    #
    @vdisks = GetVdiskList( $ctlr );
    $vdisksPtr = \@vdisks;
    
    #
    # Call to All-Alt-Random routine to select vdisks
    #
    $vdiskListOnPtr = WrtCacheVdisksSelectAllAltRandom($coPtr, $vdisksPtr, $vdiskListSelect);

    #
    # Get pointer to the list of vdisks that are off
    #
    $vdiskListOffPtr = GetComplimentOfList($vdisksPtr, $vdiskListOnPtr);
    
    $parms{MIRRORRESYNCWAIT } = 3600;
    $parms{LOOPCOUNT } = 2;

    #
    # For GlobalCache On and Off  
    #
    for ($loop = 0; $loop < 2; $loop++)
    {
        if($loop == 0)
        {
            #
            # Enable global write cache
            #
            $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);

            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
            
            $globalRequest = WRTCACHE_ENABLED;  # 0x1
        
        }
        else
        {
            #
            # Disable global write cache
            #
            $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);

            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
            
            $globalRequest = WRTCACHE_DISABLED; # 0x0

        }


        ####################################################################
        #
        # Enable vdisk WC, Disable vdisk WC, Failover, verify WC is off (GC ON and OFF)
        #
        ####################################################################

        #
        # Enable all vdisk write cache
        #
        $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_ENABLE);

        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    
        #
        # Disable all vdisk write cache
        #
        $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);
        
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    
        DelaySecs(5);   # allow cache to flush

        $retVal = FailOverLoop( \@coList,      # ptr to list of ctlr objects
                      $moxaIPListPtr,          # ptr to list of moxa addr
                      $moxaChannelListPtr,     # ptr to list of moxa channels
                      "MULTIC",                # failover method
                      2,                       # loop count (can be 0 or undef)
                      undef,                   # time line duration (can be undef)
                      undef,                   # reconnect delay (can be undef)
                      undef,                   # wait for state tiem (can be undef)
                      0,                       # flags (can be undef or 0)
                      undef,                   # ptr to fibre ctrl hash (can be undef)
                      undef,                   # ptr to xtcdata hash (can be undef)
                      3600
                      );

        if ($retVal != GOOD)
        {
            #
            # we be toast
            #
            logInfo("    ====> ERROR during FailOverLoop 1 <====");
            logInfo("    ====> $ctlr->{HOST}               <====");
            logInfo("    ====> Fail Type = $theMeans[$i]   <====");
            return ERROR;
        }

        DelaySecs(60);

        #
        # verify global write cache is enabled/disabled
        #
        $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, $globalRequest);

        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # verify all vdisk cache is disabled
        #
        $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_DISABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # find the master controller
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) 
        { 
            return(ERROR);
        }

        $ctlr = $coList[$master];  # Get master object
    
        ####################################################################
        #
        # Disable WC, Enable WC, Failover, verify WC is on (GC ON and OFF)
        #
        ####################################################################
    
        #
        # Disable all vdisk write cache
        #
        $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);
        
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # Enable all vdisk write cache
        #
        $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_ENABLE);

        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    
        DelaySecs(5);   # allow cache to flush

        $retVal = FailOverLoop( \@coList,      # ptr to list of ctlr objects
                      $moxaIPListPtr,          # ptr to list of moxa addr
                      $moxaChannelListPtr,     # ptr to list of moxa channels
                      "MULTIC",                # failover method
                      2,                       # loop count (can be 0 or undef)
                      undef,                   # time line duration (can be undef)
                      undef,                   # reconnect delay (can be undef)
                      undef,                   # wait for state tiem (can be undef)
                      0,                       # flags (can be undef or 0)
                      undef,                   # ptr to fibre ctrl hash (can be undef)
                      undef,                   # ptr to xtcdata hash (can be undef)
                      3600
                      );

        if ($retVal != GOOD)
        {
            #
            # we be toast
            #
            logInfo("    ====> ERROR during FailOverLoop 2 <====");
            logInfo("    ====> $ctlr->{HOST}               <====");
            logInfo("    ====> Fail Type = $theMeans[$i]   <====");
            return ERROR;
        }

        
        #
        # verify global write cache is enabled/disabled
        #
        $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, $globalRequest);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # verify all vdisk cache is enabled
        #
        $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_ENABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # find the master controller
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) 
        { 
            return(ERROR);
        }

        $ctlr = $coList[$master];  # Get master object

        ####################################################################
        #
        # Enable WC, Disable WC, FailoverNWay, verify WC is off (GC ON and OFF)
        #
        ####################################################################

        #
        # Enable all vdisk write cache
        #
        $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_ENABLE);

        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    
        #
        # Disable all vdisk write cache
        #
        $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);
        
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    
        DelaySecs(5);   # allow cache to flush

        for($i = 0; $i < scalar(@theMeans); $i++)
        {
            $parms{FAILTYPE} = $theMeans[$i];
            @resources = ();

            $retVal = FailOverNWayLoop( \@coList, 
                              $moxaIPListPtr, 
                              $moxaChannelListPtr, 
                              \@resources,            # pointer to resource array, can be empty array
                              \%parms,                # misc parameter hash
                              undef 
                            );

            if ($retVal != GOOD)
            {
                #
                # we be toast
                #
                logInfo("    ====> ERROR during FailOverNWayLoop 1 <====");
                logInfo("    ====> $ctlr->{HOST}                   <====");
                logInfo("    ====> Fail Type = $theMeans[$i]       <====");
                return ERROR;
            }

        }
        
        #
        # verify global write cache is enabled/disabled
        #
        $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, $globalRequest);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # verify all vdisk cache is disabled
        #
        $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_DISABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # find the master controller
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) 
        { 
            return(ERROR);
        }

        $ctlr = $coList[$master];  # Get master object

        ####################################################################
        #
        # Disable WC, Enable WC, FailoverNWay, verify WC is on (GC ON and OFF)
        #
        ####################################################################

        #
        # Disable all vdisk write cache
        #
        $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);
        
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # Enable all vdisk write cache
        #
        $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_ENABLE);

        if ( $retVal != GOOD )
        {
            return (ERROR);
        }
    
        DelaySecs(5);   # allow cache to flush

        for($i = 0; $i < scalar(@theMeans); $i++)
        {
            $parms{FAILTYPE} = $theMeans[$i];
            @resources = ();

            $retVal = FailOverNWayLoop( \@coList, 
                              $moxaIPListPtr, 
                              $moxaChannelListPtr, 
                              \@resources,            # pointer to resource array, can be empty array
                              \%parms,                # misc parameter hash
                              undef 
                            );

            if ($retVal != GOOD)
            {
                #
                # we be toast
                #
                logInfo("    ====> ERROR during FailOverNWayLoop 2 <====");
                logInfo("    ====> $ctlr->{HOST}                   <====");
                logInfo("    ====> Fail Type = $theMeans[$i]       <====");
                return ERROR;
            }

        }
        
        #
        # verify global write cache is enabled/disabled
        #
        $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, $globalRequest);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # verify all vdisk cache is enabled
        #
        $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_ENABLED);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # find the master controller
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) 
        { 
            return(ERROR);
        }

        $ctlr = $coList[$master];  # Get master object

    }

    ###############################################################################
    

    ####################################################################
    #
    # Restore the write cache to initial state
    #
    ####################################################################

    #
    # Display globalCacheInfo (before the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (after the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing was broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 13              -------------------");


    return GOOD;
    
}

##############################################################################
=head2 WrtCacheTestCase14 function

This test case turns write cache on to half the vdisks (randomly) and runs
FailOver for 100 loops.

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase14( $coPtr, 
                              $retIn, 
                              $snPtr, 
                              $moxaIPListPtr, 
                              $moxaChannelListPtr, 
                              $parmsPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $moxaIPListPtr: The pointer to a list of moxa IP addresses that matches
                        the moxa map and object lists.
          
        $moxaChannelListPtr: A pointer to a list of Moxa channels. This list
                             indicates which channel on the Moxa controls the 
                             power to a controller.

        $parmsPtr is a pointer to the list of test parms 

         
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
sub WrtCacheTestCase14
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal;
    my $numControllers;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @vdisks;
    my $vdisksPtr;
    my $vdiskListSelect;
    my $vdiskListOnPtr;
    my $vdiskListOffPtr;
    my $loop;
    my @theMeans = ("CCBET", "FEET", "BEET", "PC", "IC", "FC");
    my $globalRequest;
    my $vdisksRequest;
    my $i;
    my %fibreControl;   # hash for Neal's fibre connect/disconnect test
    my @resources;
       
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 14:                             ------");
    logInfo("------ With global cache enabled, turn write cache on to  ------");
    logInfo("------ select vdisks (all/alt/random) and run failover    ------");
    logInfo("------ for 100 loops.                                     ------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # Ensure we have enough controllers
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("    ====> This test case requires multiple controllers. Test case is skipped. <====");
        return ($retIn);
    }

    @coList = @$coPtr;         # recreate the controller array

    #
    # Get number of controllers
    #
    $numControllers = ( scalar(@coList));
    
    #
    # No controllers present (fail test)
    #
    if ( $numControllers == 0 )
    {
        logInfo("    ====> No controllers present. Test case is skipped <====");
        return ERROR;
    } 
    
    #
    # Check if All/Alt/Random parameter is set and default to ALL if not
    #
    if (defined $parmsPtr->{vdisklistselect} )
    {
        #
        # Extract key from parmsPtr (how many vdisks to turn on)
        #
        $vdiskListSelect = $parmsPtr->{vdisklistselect};
    }
    else
    {
        logInfo("    ====> vdisklistselect parameter missing. Using Default of 'ALL' <====");
        $vdiskListSelect = 'all';
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }
    
    #
    # Get the list of existing vdisks
    #
    @vdisks = GetVdiskList( $ctlr );
    $vdisksPtr = \@vdisks;

    #
    # Call to All-Alt-Random routine to select vdisks
    #
    $vdiskListOnPtr = WrtCacheVdisksSelectAllAltRandom($coPtr, $vdisksPtr, $vdiskListSelect);

    #
    # Get pointer to the list of vdisks that are off
    #
    $vdiskListOffPtr = GetComplimentOfList($vdisksPtr, $vdiskListOnPtr);
    
    ###############################################################################

    ####################################################################
    #
    # Enable GC, Disable vdisk WC, Enable WC to half vdisks (randomly), 
    # Failover (100 loops), verify WC does not change.
    #
    ####################################################################

    #
    # Enable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Disable all vdisk write cache
    #
    $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # enable select vdisk write cache
    #
    logInfo("Controlling vdisk write cache");
    logInfo("vdiskSetRequest is: WRTCACHE_VDISKS_SET_ENABLE");
    logInfo("vdisks involved: @$vdiskListOnPtr");

    $retVal = WrtCacheControlVdisksMultiple($ctlr, WRTCACHE_VDISKS_SET_ENABLE, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    DelaySecs(5);   # allow cache to flush

    $retVal = FailOverLoop( \@coList,      # ptr to list of ctlr objects
                  $moxaIPListPtr,          # ptr to list of moxa addr
                  $moxaChannelListPtr,     # ptr to list of moxa channels
                  "MULTIC",                # failover method
                  2,                       # loop count (can be 0 or undef)
                  undef,                   # time line duration (can be undef)
                  undef,                   # reconnect delay (can be undef)
                  undef,                   # wait for state tiem (can be undef)
                  0,                       # flags (can be undef or 0)
                  undef,                   # ptr to fibre ctrl hash (can be undef)
                  undef,                   # ptr to xtcdata hash (can be undef)
                  3600
                  );

    if ($retVal != GOOD)
    {
        #
        # we be toast
        #
        logInfo("    ====> ERROR during FailOverLoop 1 <====");
        logInfo("    ====> $ctlr->{HOST}               <====");
        logInfo("    ====> Fail Type = $theMeans[$i]   <====");
        return ERROR;
    }

        
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is enabled (list of vdisks with cache on)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisks with cache off)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }


    ###############################################################################
    
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

    ####################################################################
    #
    # Restore the write cache to initial state
    #
    ####################################################################

    #
    # Display globalCacheInfo (before the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (after the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing was broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 14              -------------------");

    return GOOD;
    
}


##############################################################################
=head2 WrtCacheTestCase15 function

This test case turns write cache on to half the vdisks (randomly) and runs
FailOverNWay for 100 loops.

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase15( $coPtr, 
                              $retIn, 
                              $snPtr, 
                              $moxaIPListPtr, 
                              $moxaChannelListPtr, 
                              $parmsPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $moxaIPListPtr: The pointer to a list of moxa IP addresses that matches
                        the moxa map and object lists.
          
        $moxaChannelListPtr: A pointer to a list of Moxa channels. This list
                             indicates which channel on the Moxa controls the 
                             power to a controller.

        $parmsPtr is a pointer to the list of test parms 

         
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
sub WrtCacheTestCase15
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal;
    my $numControllers;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @vdisks;
    my $vdisksPtr;
    my $vdiskListSelect;
    my $vdiskListOnPtr;
    my $vdiskListOffPtr;
    my $loop;
    my @theMeans = ("CCBET", "FEET", "BEET", "PC", "IC", "FC");
    my $globalRequest;
    my $vdisksRequest;
    my $i;
    my %fibreControl;   # hash for Neal's fibre connect/disconnect test
    my @resources;
    my %parms;
       
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 15:                             ------");
    logInfo("------ With global cache enabled, turn write cache on to  ------");
    logInfo("------ select vdisks (all/alt/random) and run failOver    ------");
    logInfo("------ NWay for 100 loops.                                ------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # Ensure we have enough controllers
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("    ====> This test case requires multiple controllers. Test case is skipped. <====");
        return ($retIn);
    }

    @coList = @$coPtr;         # recreate the controller array

    #
    # Get number of controllers
    #
    $numControllers = ( scalar(@coList));
    
    #
    # No controllers present (fail test)
    #
    if ( $numControllers == 0 )
    {
        logInfo("    ====> No controllers present. Test case is skipped <====");
        return ERROR;
    } 
    
    #
    # Check if All/Alt/Random parameter is set and default to ALL if not
    #
    if (defined $parmsPtr->{vdisklistselect} )
    {
        #
        # Extract key from parmsPtr (how many vdisks to turn on)
        #
        $vdiskListSelect = $parmsPtr->{vdisklistselect};
    }
    else
    {
        logInfo("    ====> vdisklistselect parameter missing. Using Default of 'ALL' <====");
        $vdiskListSelect = 'all';
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }
    
    #
    # Get the list of existing vdisks
    #
    @vdisks = GetVdiskList( $ctlr );
    $vdisksPtr = \@vdisks;

    #
    # Call to All-Alt-Random routine to select vdisks
    #
    $vdiskListOnPtr = WrtCacheVdisksSelectAllAltRandom($coPtr, $vdisksPtr, $vdiskListSelect);

    #
    # Get pointer to the list of vdisks that are off
    #
    $vdiskListOffPtr = GetComplimentOfList($vdisksPtr, $vdiskListOnPtr);
    
    ###############################################################################

    ####################################################################
    #
    # Enable GC, Disable vdisk WC, Enable WC to half vdisks (randomly), 
    # Failover (100 loops), verify WC does not change.
    #
    ####################################################################

    #
    # Enable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Disable all vdisk write cache
    #
    $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # enable select vdisk write cache
    #
    logInfo("Controlling vdisk write cache");
    logInfo("vdiskSetRequest is: WRTCACHE_VDISKS_SET_ENABLE");
    logInfo("vdisks involved: @$vdiskListOnPtr");
    $retVal = WrtCacheControlVdisksMultiple($ctlr, WRTCACHE_VDISKS_SET_ENABLE, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    @resources = ();
    
    DelaySecs(5);   # allow cache to flush

    $parms{FAILTYPE} = "MULTIC";
    $parms{MIRRORRESYNCWAIT} = 3600;
    $parms{LOOPCOUNT} = 100;

    $retVal = FailOverNWayLoop( \@coList, 
                                $moxaIPListPtr, 
                                $moxaChannelListPtr, 
                                \@resources,            # pointer to resource array, can be empty array
                                \%parms,                # misc parameter hash
                                undef 
                              );

        if ($retVal != GOOD)
        {
            #
            # we be toast
            #
            logInfo("    ====> ERROR during FailOverNWayLoop 1 <====");
            logInfo("    ====> $ctlr->{HOST}                   <====");
            logInfo("    ====> Fail Type = $theMeans[$i]       <====");
            return ERROR;
        }

        
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is enabled (list of vdisks with cache on)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisks with cache off)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }


    ###############################################################################
    
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

    ####################################################################
    #
    # Restore the write cache to initial state
    #
    ####################################################################

    #
    # Display globalCacheInfo (before the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (after the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing was broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 15              -------------------");


    return GOOD;
    
}


##############################################################################
=head2 WrtCacheTestCase16 function

This test case enables global cache, turns write cache off to all vdisks and 
runs failOverNWay for 5 loops.  Then turns write cache on to select vdisks 
using a parameter (all/alt/random) and runs failOverNWay for 100 loops.                                     ------");

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase16( $coPtr, 
                              $retIn, 
                              $snPtr, 
                              $moxaIPListPtr, 
                              $moxaChannelListPtr, 
                              $parmsPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $moxaIPListPtr: The pointer to a list of moxa IP addresses that matches
                        the moxa map and object lists.
          
        $moxaChannelListPtr: A pointer to a list of Moxa channels. This list
                             indicates which channel on the Moxa controls the 
                             power to a controller.

        $parmsPtr is a pointer to the list of test parms 

         
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
sub WrtCacheTestCase16
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal;
    my $numControllers;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @vdisks;
    my $vdisksPtr;
    my $vdiskListSelect;
    my $vdiskListOnPtr;
    my $vdiskListOffPtr;
    my @resources;
    my %parms;
       
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 16:                             ------");
    logInfo("------ With global cache enabled, turn write cache off    ------");
    logInfo("------ to all vdisks and run failOverNWay for 5 loops.    ------");
    logInfo("------ Turn write cache on for select vdisks using a      ------");
    logInfo("------ parameter (all/alt/random) and run failOverNWay    ------");
    logInfo("------ for 100 loops.                                     ------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # Ensure we have enough controllers
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("    ====> This test case requires multiple controllers. Test case is skipped. <====");
        return ($retIn);
    }

    @coList = @$coPtr;         # recreate the controller array

    #
    # Get number of controllers
    #
    $numControllers = ( scalar(@coList));
    
    #
    # No controllers present (fail test)
    #
    if ( $numControllers == 0 )
    {
        logInfo("    ====> No controllers present. Test case is skipped <====");
        return ERROR;
    } 
    
    #
    # Check if All/Alt/Random parameter is set and default to ALL if not
    #
    if (defined $parmsPtr->{vdisklistselect} )
    {
        #
        # Extract key from parmsPtr (how many vdisks to turn on)
        #
        $vdiskListSelect = $parmsPtr->{vdisklistselect};
    }
    else
    {
        logInfo("    ====> vdisklistselect parameter missing. Using Default of 'ALL' <====");
        $vdiskListSelect = 'all';
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }
    
    #
    # Get the list of existing vdisks
    #
    @vdisks = GetVdiskList( $ctlr );
    $vdisksPtr = \@vdisks;

    #
    # Call to All-Alt-Random routine to select vdisks
    #
    $vdiskListOnPtr = WrtCacheVdisksSelectAllAltRandom($coPtr, $vdisksPtr, $vdiskListSelect);

    #
    # Get pointer to the list of vdisks that are off
    #
    $vdiskListOffPtr = GetComplimentOfList($vdisksPtr, $vdiskListOnPtr);
    
    ###############################################################################

    ####################################################################
    #
    # Enable GC, Disable vdisk WC, FailOverNWay (5 loops), Enable WC to half  
    # vdisks (alternately), Failover (100 loops), verify WC did not change.
    #
    ####################################################################

    #
    # Enable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Disable all vdisk write cache
    #
    $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    DelaySecs(5);   # allow cache to flush

    @resources = ();

    $parms{FAILTYPE} = "MULTIC";
    $parms{MIRRORRESYNCWAIT} = 3600;
    $parms{LOOPCOUNT} = 5;

    $retVal = FailOverNWayLoop( \@coList, 
                                $moxaIPListPtr, 
                                $moxaChannelListPtr, 
                                \@resources,            # pointer to resource array, can be empty array
                                \%parms,                # misc parameter hash
                                undef 
                              );

        if ($retVal != GOOD)
        {
            #
            # we be toast
            #
            logInfo("    ====> ERROR during FailOverNWayLoop 1 <====");
            logInfo("    ====> $ctlr->{HOST}                   <====");
            logInfo("    ====> Fail Type = $parms{FAILTYPE}    <====");
            return ERROR;
        }

        
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify all vdisk cache is disabled
    #
    $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object


    #
    # enable select vdisk write cache
    #
    logInfo("Controlling vdisk write cache");
    logInfo("vdiskSetRequest is: WRTCACHE_VDISKS_SET_ENABLE");
    logInfo("vdisks involved: @$vdiskListOnPtr");
    $retVal = WrtCacheControlVdisksMultiple($ctlr, WRTCACHE_VDISKS_SET_ENABLE, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #DelaySecs(5);   # allow cache to flush

    @resources = ();
    
    $parms{LOOPCOUNT} = 100;

    $retVal = FailOverNWayLoop( \@coList, 
                                $moxaIPListPtr, 
                                $moxaChannelListPtr, 
                                \@resources,            # pointer to resource array, can be empty array
                                \%parms,                # misc parameter hash
                                undef 
                              );

        if ($retVal != GOOD)
        {
            #
            # we be toast
            #
            logInfo("    ====> ERROR during FailOverNWayLoop 2 <====");
            logInfo("    ====> $ctlr->{HOST}                   <====");
            logInfo("    ====> Fail Type = $parms{FAILTYPE}    <====");
            return ERROR;
        }

        
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is enabled (list of vdisks with cache on)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisks with cache off)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }


    ###############################################################################
    
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

    ####################################################################
    #
    # Restore the write cache to initial state
    #
    ####################################################################

    #
    # Display globalCacheInfo (before the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (after the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing was broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 16              -------------------");


    return GOOD;
    
}


##############################################################################
=head2 WrtCacheTestCase17 function

This test case enables global cache, turns write cache on to select vdisks
using a parameter (all/alt/random) and runs FailOverNWay for 50 loops.
Disables all vdisk write cache and runs FailOverNWay for 5 loops.  Enables 
write cache on select vdisks using a parameter (all/alt/random) and runs 
FailOverNWay for 50 loops.
  
The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.


=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase17( $coPtr, 
                              $retIn, 
                              $snPtr, 
                              $moxaIPListPtr, 
                              $moxaChannelListPtr, 
                              $parmsPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $moxaIPListPtr: The pointer to a list of moxa IP addresses that matches
                        the moxa map and object lists.
          
        $moxaChannelListPtr: A pointer to a list of Moxa channels. This list
                             indicates which channel on the Moxa controls the 
                             power to a controller.

        $parmsPtr is a pointer to the list of test parms 

         
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
sub WrtCacheTestCase17
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ) = @_;
    
    my $master;
    my @coList;
    my $ctlr;
    my $retVal;
    my $numControllers;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    my @vdisks;
    my $vdisksPtr;
    my $vdiskListSelect;
    my $vdiskListOnPtr;
    my $vdiskListOffPtr;
    my @resources;
    my %parms;
       
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 17:                             ------");
    logInfo("------ With global cache enabled, turn write cache on to  ------");
    logInfo("------ select vdisks using a parameter (all/alt/random)   ------");
    logInfo("------ and run FailOverNWay for 50 loops.  Disable all    ------");
    logInfo("------ vdisk write cache and run FailOverNWay for 5       ------");
    logInfo("------ loops.  Enable write cache on select vdisks using  ------");
    logInfo("------ a parameter (all/alt/random) and run FailOverNWay  ------");
    logInfo("------ for 50 loops.                                      ------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    #
    # Ensure we have enough controllers
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("    ====> This test case requires multiple controllers. Test case is skipped. <====");
        return ($retIn);
    }

    @coList = @$coPtr;         # recreate the controller array

    #
    # Get number of controllers
    #
    $numControllers = ( scalar(@coList));
    
    #
    # No controllers present (fail test)
    #
    if ( $numControllers == 0 )
    {
        logInfo("    ====> No controllers present. Test case is skipped <====");
        return ERROR;
    } 
    
    #
    # Check if All/Alt/Random parameter is set and default to ALL if not
    #
    if (defined $parmsPtr->{vdisklistselect} )
    {
        #
        # Extract key from parmsPtr (how many vdisks to turn on)
        #
        $vdiskListSelect = $parmsPtr->{vdisklistselect};
    }
    else
    {
        logInfo("    ====> vdisklistselect parameter missing. Using Default of 'ALL' <====");
        $vdiskListSelect = 'all';
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }
    
    #
    # Get the list of existing vdisks
    #
    @vdisks = GetVdiskList( $ctlr );
    $vdisksPtr = \@vdisks;

    #
    # Call to All-Alt-Random
    #
    $vdiskListOnPtr = WrtCacheVdisksSelectAllAltRandom($coPtr, $vdisksPtr, $vdiskListSelect);

    #
    # Get pointer to the list of vdisks that are off
    #
    $vdiskListOffPtr = GetComplimentOfList($vdisksPtr, $vdiskListOnPtr);
    
    ###############################################################################

    #
    # Disable all vdisk write cache
    #
    $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    ####################################################################
    #
    # Enable GC, Enable WC to half vdisks (randomly), Failover (50 loops),
    # Disable vdisk WC, Failover (5 loops), Enable WC to half vdisks (randomly),
    # Failover (50 loops), verify WC did not change.
    #
    ####################################################################

    #
    # Enable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_ENABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # enable select vdisk write cache
    #
    logInfo("Controlling vdisk write cache");
    logInfo("vdiskSetRequest is: WRTCACHE_VDISKS_SET_ENABLE");
    logInfo("vdisks involved: @$vdiskListOnPtr");
    $retVal = WrtCacheControlVdisksMultiple($ctlr, WRTCACHE_VDISKS_SET_ENABLE, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    @resources = ();
    
    DelaySecs(5);   # allow cache to flush

    $parms{FAILTYPE} = "MULTIC";
    $parms{MIRRORRESYNCWAIT} = 3600;
    $parms{LOOPCOUNT} = 50;

    $retVal = FailOverNWayLoop( \@coList, 
                                $moxaIPListPtr, 
                                $moxaChannelListPtr, 
                                \@resources,            # pointer to resource array, can be empty array
                                \%parms,                # misc parameter hash
                                undef 
                              );

    if ($retVal != GOOD)
    {
        #
        # we be toast
        #
        logInfo("ERROR during FailOverNWayLoop 1");
        logInfo("    ====> $ctlr->{HOST} <====");
        logInfo("Fail Type = $parms{FAILTYPE}");
        return ERROR;
    }

    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is enabled (list of vdisks with cache on)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisks with cache off)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    #
    # Disable all vdisk write cache
    #
    $retVal = WrtCacheControlVdisksAll($ctlr, WRTCACHE_VDISKS_SET_DISABLE);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    DelaySecs(5);   # allow cache to flush

    @resources = ();

    $parms{LOOPCOUNT} = 5;

    $retVal = FailOverNWayLoop( \@coList, 
                                $moxaIPListPtr, 
                                $moxaChannelListPtr, 
                                \@resources,            # pointer to resource array, can be empty array
                                \%parms,                # misc parameter hash
                                undef 
                              );

        if ($retVal != GOOD)
        {
            #
            # we be toast
            #
            logInfo("ERROR during FailOverNWayLoop 2");
            logInfo("    ====> $ctlr->{HOST} <====");
            logInfo("Fail Type = $parms{FAILTYPE}");
            return ERROR;
        }

        
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify all vdisk cache is disabled
    #
    $retVal = WrtCacheValidateDSCCacheVDisks($coPtr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object


    #
    # enable select vdisk write cache
    #
    logInfo("Controlling vdisk write cache");
    logInfo("vdiskSetRequest is: WRTCACHE_VDISKS_SET_ENABLE");
    logInfo("vdisks involved: @$vdiskListOnPtr");
    $retVal = WrtCacheControlVdisksMultiple($coList[$master], WRTCACHE_VDISKS_SET_ENABLE, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    DelaySecs(5);   # allow cache to flush

    @resources = ();
    
    $parms{LOOPCOUNT } = 50;

    $retVal = FailOverNWayLoop( \@coList, 
                                $moxaIPListPtr, 
                                $moxaChannelListPtr, 
                                \@resources,            # pointer to resource array, can be empty array
                                \%parms,                # misc parameter hash
                                undef 
                              );

        if ($retVal != GOOD)
        {
            #
            # we be toast
            #
            logInfo("ERROR during FailOverNWayLoop 3");
            logInfo("    ====> $ctlr->{HOST} <====");
            logInfo("Fail Type = $parms{FAILTYPE}");
            return ERROR;
        }

        
    #
    # verify global write cache is enabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is enabled (list of vdisks with cache on)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_ENABLED, $vdiskListOnPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify vdisk write cache is disabled (list of vdisks with cache off)
    #
    $retVal = WrtCacheValidateCacheVDiskList($ctlr, WRTCACHE_DISABLED, $vdiskListOffPtr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    ###############################################################################
    
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

    ####################################################################
    #
    # Restore the write cache to initial state
    #
    ####################################################################

    #
    # Display globalCacheInfo (before the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (after the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing was broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 17              -------------------");


    return GOOD;
    
}


##############################################################################

=head2 WrtCacheTestCase18 function

This test case loops thru versions of firmware as listed in the testcase file. 
The number of loops run is defined by the LoopCount variable in the testcase 
file. Each loop ($loop) calls RollingCodeApply for all fwk's listed in the 
testcase file. 

The system write cache state is captured in the beginning of the test via 
TestPrep4MirrorCheck and is restored after successful completion of the test 
via WrtCacheRestoreCacheState.


=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase18( $coPtr, 
                              $retIn, 
                              $snPtr, 
                              $parmsPtr );

 
 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $parmsPtr is a pointer to the test parms in the testcase file.

         
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
sub WrtCacheTestCase18
{
    trace();
    my ( $coPtr,
         $retIn, 
         $snPtr,
         $parmsPtr) = @_;

    my $master;
    my @coList;
    my $ctlr;
    my $retVal;
    my $retVal1;
    my $retVal2;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my @activeServers;
    my @initialVdisks;
    my @tMap;
    
    my %testParms;          # Dummy of $xtcDataPtr for $CURTESTARGUMENT and $CURSERIALNUMBER
    my $valFlag   = 1;      # Validation Flag (1 => skip validation in RollingCodeApply)
    my $loopCount = 5;      # Number of loops to run (5, 10, 50, etc)
    my $loop;               # Current loop
    my @FwFiles;            # Array of FW kits
    my $fwKitCount;         # Number of fwk's used (FWK1, FWK2, etc)
    my $fwKit;              # Current FW kit
    my $testRef = "";       # redefined in RollingCodeApply
    my $textMessage = "";   # temp variable for log messages
    my $victim;
    my $vdiskListSelect;
    my $vdiskListOnPtr;
    my $vdiskListOffPtr;
    my @vdisks;
    my $vdisksPtr;
    my $numVDDs;
    my $globalSetRequest;
    my $globalSetRequestText;
    my $globalResetRequest;
    my $globalValidateRequest;
    my $vdiskSetRequest;
    my $vdiskClearRequest;
    my $vdiskValidateRequest;
    my $path;

    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    #
    # Check if All/Alt/Random parameter is set and default to ALL if not
    #
    if (defined $parmsPtr->{vdisklistselect} )
    {
        #
        # Extract key from parmsPtr (how many vdisks to turn on)
        #
        $vdiskListSelect = $parmsPtr->{vdisklistselect};
    }
    else
    {
        logInfo("    ====> vdisklistselect parameter missing. Using Default of 'RANDOM' <====");
        $vdiskListSelect = 'random';
    }

    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 18:                                   ");
    logInfo("------ Rolling Code Updates                                     ");
    logInfo("------ This test case loops through the versions of firmware    ");
    logInfo("------ listed in the testcase file. The number of loops run     ");
    logInfo("------ is defined by the LoopCount variable in the testcase     ");
    logInfo("------ file. Each loop calls RollingCodeApply for all fwk's     ");
    logInfo("------ listed in the testcase file.                             ");
    logInfo("----------------------------------------------------------------");
    logInfo("");
  
 
    #
    # Ensure we have enough controllers
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("    ====> This test case requires multiple controllers. Test case is skipped. <====");
        return ($retIn);
    }

    @coList = @$coPtr;         # recreate the controller array

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    #
    # Get the list of existing vdisks
    #
    @vdisks = GetVdiskList( $ctlr );
    $vdisksPtr = \@vdisks;
    
    if ( $vdisks[0] == INVALID )
    {
        logInfo("    ====> Unable to retrieve list of virtual disk identifiers. <====");
        logInfo("    ====> $coList[$master]{HOST}                               <====");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available




    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }
    



    ###############################################################################

    #
    # Set number of Test Loops if defined in Station Profile (overwrites Default setting)
    #
    if ( defined ($parmsPtr->{"loopcount"}) )
    {
       $loopCount = $parmsPtr->{"loopcount"};
       if ($loopCount < 0)
       {
           logInfo("     ====> Negative loopCount ($loopCount) - Failing Test <====");
           return ERROR;
       }
    }
 
    #
    # Checks for existance of FirmWare Files in the Station Profile & passes the data to a list
    #
    if ( defined ($parmsPtr->{"fwk1"}) )
    {
       push (@FwFiles, $parmsPtr->{"fwk1"});
    }
    
    if ( defined ($parmsPtr->{"fwk2"}) )
    {
       push (@FwFiles, $parmsPtr->{"fwk2"}) ;
    }

    if ( defined ($parmsPtr->{"fwk3"}) )
    {
       push (@FwFiles, $parmsPtr->{"fwk3"}) ;
    }

    if ( defined ($parmsPtr->{"fwk4"}) )
    {
       push (@FwFiles, $parmsPtr->{"fwk4"}) ;
    }

    #
    # Get number of FW Files passed in
    #
    $fwKitCount = scalar(@FwFiles);

    #
    # Set Current Test Arguement to 0 (Rolling Code Update)
    #
    $testParms{CURTESTARGUMENT} = 0;
    
    #
    # Get serial number of DSC (remove last hex bit from master serial number)
    #
    #$testParms{CURSERIALNUMBER} = int($$snPtr[$master]/16);    # WORKS
    $testParms{CURSERIALNUMBER} = int($snPtr->[$master]/16);    # But does this

    #
    # Reserve Controller
    #
    if(XSSA_Reserve($testParms{CURSERIALNUMBER}) != GOOD)
    {
        logInfo("     ====> Unable to reserve CNC $testParms{CURSERIALNUMBER} <====");
        return ERROR;
    }

    ###############################################################################


    #
    # Start of test loop
    #
    for ($loop = 0; $loop < $loopCount; $loop++ )
    {

        #
        # Split loops into 2 separate paths (0, or 1)
        #
        $path = $loop % 2;
        
        #
        # Set GC and VC variables based on the path
        #      
        
        if ( $path == 0 )
        {
            #
            # set request variables (GC off, VC off)
            #
            $globalSetRequest = WRTCACHE_GLOBAL_SET_DISABLE;
            $globalSetRequestText = "WRTCACHE_GLOBAL_SET_DISABLE";
            $globalResetRequest = WRTCACHE_GLOBAL_SET_ENABLE;
            $globalValidateRequest = WRTCACHE_DISABLED;
            $vdiskSetRequest = WRTCACHE_VDISKS_SET_DISABLE;
            $vdiskClearRequest = WRTCACHE_VDISKS_SET_ENABLE;
            $vdiskValidateRequest = WRTCACHE_DISABLED;
        }

### GC must be disabled        
        #elsif ( $path == 3 )
        #{
        #    #
        #    # set request variables (GC on, VC off)
        #    #
        #    $globalSetRequest = WRTCACHE_GLOBAL_SET_ENABLE;
        #    $globalSetRequestText = "WRTCACHE_GLOBAL_SET_ENABLE";
        #    $globalResetRequest = WRTCACHE_GLOBAL_SET_DISABLE;
        #    $globalValidateRequest = WRTCACHE_ENABLED;
        #    $vdiskSetRequest = WRTCACHE_VDISKS_SET_DISABLE;
        #    $vdiskClearRequest = WRTCACHE_VDISKS_SET_ENABLE;
        #    $vdiskValidateRequest = WRTCACHE_DISABLED;
        #    
        #}
        
        elsif ( $path == 1 )
        {
            #
            # set request variables (GC off, VC on (random))
            #
            $globalSetRequest = WRTCACHE_GLOBAL_SET_DISABLE;
            $globalSetRequestText = "WRTCACHE_GLOBAL_SET_DISABLE";
            $globalResetRequest = WRTCACHE_GLOBAL_SET_ENABLE;
            $globalValidateRequest = WRTCACHE_DISABLED;
            $vdiskSetRequest = WRTCACHE_VDISKS_SET_ENABLE;
            $vdiskClearRequest = WRTCACHE_VDISKS_SET_DISABLE;
            $vdiskValidateRequest = WRTCACHE_ENABLED;
            
        }
        
### GC must be disabled        
        #elsif ( $path == 1 )
        #{
        #    #
        #    # GC on, VC on (random)
        #    #
        #    $globalSetRequest = WRTCACHE_GLOBAL_SET_ENABLE;
        #    $globalSetRequestText = "WRTCACHE_GLOBAL_SET_ENABLE";
        #    $globalResetRequest = WRTCACHE_GLOBAL_SET_DISABLE;
        #    $globalValidateRequest = WRTCACHE_ENABLED;
        #    $vdiskSetRequest = WRTCACHE_VDISKS_SET_ENABLE;
        #    $vdiskClearRequest = WRTCACHE_VDISKS_SET_DISABLE;
        #    $vdiskValidateRequest = WRTCACHE_ENABLED;
        #}
        
        else
        {
            logInfo("     ====> ERROR: Invalid path  <====");
            return ERROR;
        }
        
        #
        # find the master controller
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) 
        { 
            return(ERROR);
        }

        $ctlr = $coList[$master];  # Get master object
    
        #
        # Control global write cache
        #
        logInfo("Controlling global write cache");
        logInfo("globalSetRequest is: $globalSetRequestText");
        $retVal = WrtCacheControlGlobal($ctlr, $globalSetRequest);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # Display globalCacheInfo (From this controller)
        #
        $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }


        #
        # Call to All-Alt-Random routine to select vdisks
        #
        $vdiskListOnPtr = WrtCacheVdisksSelectAllAltRandom($coPtr, $vdisksPtr, $vdiskListSelect);

        #
        # Get pointer to the list of vdisks that are off
        #
        $vdiskListOffPtr = GetComplimentOfList($vdisksPtr, $vdiskListOnPtr);
        
        #
        # enable select vdisk write cache
        #
        $retVal = WrtCacheControlVdisksMultiple($ctlr, $vdiskSetRequest, $vdiskListOnPtr);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # disable select vdisk write cache
        #
        $retVal = WrtCacheControlVdisksMultiple($ctlr, $vdiskClearRequest, $vdiskListOffPtr);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }

        #
        # Display Vdisk Info
        #
        $retVal = DispVdiskInfo($ctlr);
        if ( $retVal != GOOD )
        {
            return (ERROR);
        }


        #
        # Verify global cache is in correct state
        #
        $retVal1 = WrtCacheValidateCacheGlobal($ctlr, 
                                              $globalValidateRequest);

        #
        # Verify all vdisk cache is in correct state
        #
        $retVal2 = WrtCacheValidateCacheVDiskList($ctlr, 
                                                 $vdiskValidateRequest,
                                                 $vdiskListOnPtr);
        
        if ( $retVal1 != GOOD || $retVal2 != GOOD)
        {
            #
            # Display globalCacheInfo
            #
            $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }

            #
            # Display Vdisk Info (From this controller)
            #
            $retVal = DispVdiskInfo($ctlr);
            if ( $retVal != GOOD )
            {
                return (ERROR);
            }
            
        }
        
        #
        # Send message to the controllers
        #                                  
        $textMessage = "***** Starting WrtCacheTestCase18 Rolling Code Updates";

        CtlrLogTextAll($coPtr, $textMessage);
        

        for ( $fwKit = 0; $fwKit < $fwKitCount; $fwKit++)             
        {
            #
            # print message on the screen
            #
            logInfo("Updating device serial $testParms{CURSERIALNUMBER} to release $FwFiles[$fwKit]");


            logInfo("------------------ fwKit $fwKit of $fwKitCount started. Loop = $loop -------------------");

            #
            # Call RollingCodeApply Function
            #
            $retVal =  RollingCodeApply( $FwFiles[$fwKit],
                                         $coPtr,
                                         $valFlag,
                                         $loopCount,
                                         $fwKitCount,
                                         $testRef,
                                         $loop,
                                         \%testParms);
                        
            if ( $retVal != GOOD ) 
            { 
                logInfo("    ====> ERROR: Failed while updating CNC $testParms{CURSERIALNUMBER} to FW $FwFiles[$fwKit] <====");
                return ERROR; 
            }

            #
            # find the master controller
            #
            $master = FindMaster( $coPtr );
            if ( $master == INVALID ) 
            { 
                return(ERROR);
            }

            $ctlr = $coList[$master];  # Get master object
    

            #
            # Verify global cache is in correct state
            #
            $retVal1 = WrtCacheValidateCacheGlobal($ctlr, 
                                                  $globalValidateRequest);

            #
            # Verify all vdisk cache is in correct state
            #
            $retVal2 = WrtCacheValidateCacheVDiskList($ctlr, 
                                                     $vdiskValidateRequest,
                                                     $vdiskListOnPtr);
        
            if ( $retVal1 != GOOD || $retVal2 != GOOD)
            {
                #
                # Display globalCacheInfo
                #
                $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
                if ( $retVal != GOOD )
                {
                    return (ERROR);
                }

                #
                # Display Vdisk Info (From this controller)
                #
                $retVal = DispVdiskInfo($ctlr);
                if ( $retVal != GOOD )
                {
                    return (ERROR);
                }
            
            }
        
            #
            # Rel 3.1 adds resync, need to wait for it to complete
            #
            $retVal = MirrorResyncWait($coPtr, $MRWTimeout);
            if ($retVal != GOOD)
            {
                logInfo("Failed Mirror Resync wait.");
                $retVal = MirrorCheck( $coPtr, \%mirrorData, NOCACHECHECK);
                return ERROR;
            }
        
            $retVal = MirrorCheck( $coPtr, \%mirrorData, NOCACHECHECK);
            if ($retVal != GOOD)
            {
                logInfo("Failed Mirror State Check.");
                return ERROR;
            }

            logInfo("--------------------- Loop $fwKit of $fwKitCount completed. Loop = $loop -------------------");

        }
            
        $textMessage = "    ====> Rolling Code Update $loop of $loopCount COMPLETED <====";

        CtlrLogTextAll($coPtr, $textMessage);

        logInfo("--------------------- Loop $loop of $loopCount completed, . -------------------");
    
    }

    $retVal = unreserve( $$parmsPtr{CURSERIALNUMBER} );

    if($retVal != XMCGOOD)
    {
        logInfo("    ====> ERROR: Unable to unreserve CNC $testParms{CURSERIALNUMBER}");
        return ERROR;
    }
        
    logInfo("End of RollingCodeUpdate test.  $loop of $loopCount loops completed");



    ###############################################################################
    
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

    ####################################################################
    #
    # Restore the write cache to initial state
    #
    ####################################################################

    #
    # Display globalCacheInfo (before the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (after the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing was broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 18              -------------------");


    return GOOD;
    
}


##############################################################################
=head2 WrtCacheTestCase19 function

This test case:
    1) Enables write cache
    2) Waits 60 sec for IO cache tags to build
    3) Bypasses a pdisk
    4) Disables write cache
    5) Watches cache tags decrement to zero
    6) Waits for rebuild to finish
    7) Verifies IO
    8) Unfails pdisk


=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestCase19( $coPtr, 
                              $retIn, 
                              $snPtr, 
                              $parmsPtr );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $retIn: This is a control variable. If set to GOOD ( = 0 ), the test
                will be executed. If set to another value, the test will just
                return. The return value from the test will be what was passed
                in $retIn.

        $snPtr: A pointer to a list of controller serial numbers. As the caller
                connects/logs into each controller, the serial number of the
                controller is fetched and put into this list.
         
        $parmsPtr is a pointer to the list of test parms 

         
=item Returns:

       $rc will be GOOD, ERROR or INVALID. The user should verify correct 
         operation by reviewing the logs.

=item Things to look for:

    There should be no unexpected messages in the logs.
    The script should end without errors showing on the screen.

=item Initial Conditions:

    This test case assumes you have a properly configured system.
    (ie vdisks connected to a server)
    I/O is running.
    
=back

=cut

##############################################################################
sub WrtCacheTestCase19
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $parmsPtr ) = @_;
    
    my @activeServers;
    my $cNode;
    my @coList;
    my $ctlr;
    my $duration = 1;
    my $gcBattery;
    my %gcInfo;
    my $gcStatus;
    my $gcStopCount;
    my $gcTagsResident;
    my $gcTagsDirty;
    my @initialVdisks;
    my $lc;
    my $lid;
    my $master;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    my $oldStopTime;
    my @pdds;
    my $port;
    my $retVal;
    my $ses;
    my $slot;
    my $someTagsDirty;
    my $startTime;
    my $stopTime;
    my $maxTimeLineDuration = 3600;   # 1 hr timeout
    my @tMap;
    my $timeLine;
    my $timePrinted;
    my $victim;
    my $displayBatteryStats = 0;
       
    #
    # $retIn coming in is a flag to do the test or not
    #
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    logInfo("");
    logInfo("----------------------------------------------------------------");
    logInfo("------ WrtCache Test Case 19:                             ------");
    logInfo("------ Bypass a pdisk and disable Global Write Cache.     ------");
    logInfo("------ Verify Global Write Cache is disabled. When the    ------");
    logInfo("------ rebuild has finished, IO is verified and the pdisk ------");
    logInfo("------ is unbypassed.                                     ------");
    logInfo("----------------------------------------------------------------");
    logInfo("");

    @coList = @$coPtr;         # recreate the controller array

    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object
    
    $victim = $master;
    
    #
    # Execute cleanup and data collection at start
    #
    $retVal = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $retVal != GOOD ) 
    { 
        return ERROR; 
    }
    
    ###############################################################################
################################
#   1)  Start IO
#   2)  Start Test
#   3)  Enable WC
#   4)  Wait 60 sec (for wc tags to build)
#   5)  Bypass pdisk (FailPdisk)
#   6)  Disable Global Write Cache
#   7)  Watch tags go to zero
#   8)  Verify write cache is disabled
#   9)  Wait for rebuild to finish
#  10)  Verify I/O (no miscompares/nop lost drives)
#  11)  Unfail pdisk (PdiskUnfail)

    #
    # Enable Global and all Vdisk write cache
    #
    $retVal = WrtCacheControl($ctlr,  WRTCACHE_ENABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    logInfo(" Global write cache and write cache on all vdisks should be enabled!");

    #
    # Display globalCacheInfo
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Display Vdisk Info
    #
    $retVal = DispVdiskInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    DelaySecs( 60 ); # Allow cache tags to build
    
    #
    # Get an array of all available physical drives
    #
    @pdds = GetDataDisks( $ctlr, PD_DT_FC_DISK );
    
    if ( $pdds[0] == INVALID) { return ERROR; }

    #
    # fail a  drive (FailPdisk waits for rebuild to start)
    #
    CtlrLogTextAll($coPtr, "WrtCacheTestCase19: Now failing pdd $pdds[1]" );

    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $retVal = FailPdisk( $ctlr, $pdds[1], PDISKBYPASS);
    if ( $retVal != GOOD ) { return ERROR; }

    #
    # Get some pdisk statistics
    #
    ShortPdiskInfo($ctlr);
        
    #
    # disable global write cache
    #
    $retVal = WrtCacheControlGlobal($ctlr, WRTCACHE_GLOBAL_SET_DISABLE);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
        
        
    #
    # Watch cache tags go to zero
    #
    $retVal = WrtCacheTimeLine( $coPtr, $snPtr, $victim, $maxTimeLineDuration, 
                                 $displayBatteryStats );
    if ( $retVal != GOOD )
    {
        logInfo("    ====> Error during WrtCacheTagsTimeLine          <====");
        logInfo("    ====> on controller $ctlr->{HOST}                <====");
        logInfo("    ====> $coList[$master]{HOST}                     <====");
        return ERROR;
    }


    # 
    # Verify Global Write Cache is disabled
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # verify global cache is now disabled
    #
    $retVal = WrtCacheValidateDSCCacheGlobal($coPtr, WRTCACHE_DISABLED);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # verify IO is still good
    #
    logInfo("Verify IO with the failed PDD");
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) { return ERROR; }

    #
    # Wait for rebuild (complete when no drives are 'degraded')
    # 
    $retVal = WaitRebuild( $ctlr );
    if ( $retVal == ERROR )
    {
        return ERROR;
    }

    #
    # verify IO is still good
    #
    logInfo("Verify IO with after rebuilds/defrags end.");
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) { return ERROR; }


    CtlrLogTextAll($coPtr, "Write Cache Test Case 19: now unbypassing data drive $pdds[1]" );

    #
    # unfail the drive
    #
    $retVal = UnfailPdisk($ctlr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $retVal != GOOD ) { return ERROR; }

    #
    # note: there may be a hotspare and rebuild done here if the failed drive
    # had been hotspared. So we should wait for that rebuild to finish before
    # fixing the pdisk labels.
    #

    #
    # Get some pdisk statistics
    #
    ShortPdiskInfo($ctlr);
    DelaySecs(10);

    logInfo("checking for a rebuild and polling until it finishes");
    $retVal = INVALID;

    $lc = 0;
    while ( $retVal != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $retVal = DegradeCheck( $ctlr );
        if ( $retVal == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    #
    # Clean up pdisks
    #
    $retVal = FixPdiskLabels ($ctlr, 0);
    if ( $retVal != GOOD ) { return ERROR; }

    #
    # verify IO
    #
    logInfo("Confirm IO after test is done and disk restored.");
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) { return ERROR; }

    #
    # Check if defrags are running
    #
    $retVal = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $retVal != GOOD ) { return ERROR; }


    ###############################################################################
    
    #
    # find the master controller
    #
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) 
    { 
        return(ERROR);
    }

    $ctlr = $coList[$master];  # Get master object

    ####################################################################
    #
    # Restore the write cache to initial state
    #
    ####################################################################

    #
    # Display globalCacheInfo (before the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);

    if ( $retVal != GOOD )
    {
        return (ERROR);
    }
    
    #
    # Restore original cache state
    #
    $retVal = WrtCacheRestoreCacheState( $coPtr, \%mirrorData );

    if ( $retVal != GOOD )
    {
        logInfo("    ====>Error during WrtCacheRestoreCacheState on $coList[$master]{HOST} <====");
        return ERROR;
    }

    #
    # Display globalCacheInfo (after the change)
    #
    $retVal = WrtCacheDisplayGlobalCacheInfo($ctlr);
    if ( $retVal != GOOD )
    {
        return (ERROR);
    }

    #
    # Verify IO here
    #
    $retVal = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    #
    # Ensure nothing was broken
    #
    $retVal = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $retVal != GOOD ) 
    { 
        return ERROR;
    }

    logInfo("------ End WrtCache Test Case 19              -------------------");


    return GOOD;
    
}



##############################################################################
=head2 WrtCacheTestEntry function

Enter the description here...

=cut

=over 1

=item Usage:

 my $rc = WrtCacheTestEntry($coPtr, $moxaPtr, $mmPtr, $parmsPtr, $spare );

 where: 
        $coPtr: A pointer to a list of CCBE objects that have connections
                already established. Each member of the list is a pointer to
                the object hash.

        $moxaPtr: Pointer to a list of Moxa controller IP addresses
        
        $mmPtr: Pointer to a list of tha Moxa channel mappings
        
        $parmsPtr: Pointer to a test parms hash
        
        $spare: Extra item, not used

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the test
           ran to completion without error. Test logs must be reviewed to
           ensure the test ran correctly.

=back

=cut

##############################################################################
sub WrtCacheTestEntry
{
    trace();
    my ( $coPtr, $snPtr,  $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr, $dummy ) = @_;

    my $ret;
    my $case;
    $case = $parmsPtr->{testcase}; 

    #
    # Note: there are some lines referring to loop counts. This may not 
    # be relevant for resync. If not used, they may be removed. For Defrag
    # BEStress they were used.
    #

    my $autoLoop;
    my $loopCount = 0;

    $autoLoop = 0;
    $ret = GOOD;

    if ( defined($parmsPtr->{loopcount} ) )
    {
        $loopCount =  $parmsPtr->{loopcount};
    }   

    my @coList = @$coPtr;

    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "          starting Write Cache Test Case $case. ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");

    if ( !$loopCount )
    {
        logInfo("LoopCount was not specified, default values will be used.");
        $autoLoop = 1;
    }

    if ( $case == 99 )
    {
        logInfo("All test cases selected, default loop count values will be used.");
        $autoLoop = 1;
    }

    #
    # You will need to add tests case calls here as you add test cases.
    # The 99/all case does not need to apply to all cases.  However if
    # it is applied to a test case, then the test cases need to support
    # one test following another. Mainly this means that test cases may
    # need to 'clean up' the system before they actually run.
    #
    # You'll also need to determine what parameters each test will take.
    #

    if ( $case == 1 )                  { $ret = WrtCacheTestCase01( $coPtr, GOOD ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 2 )                  { $ret = WrtCacheTestCase02( $coPtr, GOOD ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 3 )                  { $ret = WrtCacheTestCase03( $coPtr, GOOD, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 4 )                  { $ret = WrtCacheTestCase04( $coPtr, GOOD, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 5  || $case == 99 )  { $ret = WrtCacheTestCase05( $coPtr, GOOD, $snPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 6  || $case == 99 )  { $ret = WrtCacheTestCase06( $coPtr, GOOD, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 7)                   { $ret = WrtCacheTestCase07( $coPtr, GOOD ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 8 )                  { $ret = WrtCacheTestCase08( $coPtr, GOOD, $snPtr, $moxaIPListPtr, $moxaChannelListPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 9 )                  { $ret = WrtCacheTestCase09( $coPtr, GOOD, $snPtr, $moxaIPListPtr, $moxaChannelListPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 10 )                 { $ret = WrtCacheTestCase10( $coPtr, GOOD, $snPtr, $moxaIPListPtr, $moxaChannelListPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 11  || $case == 99 ) { $ret = WrtCacheTestCase11( $coPtr, GOOD, $snPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 12  || $case == 99 ) { $ret = WrtCacheTestCase12( $coPtr, GOOD, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 13  || $case == 99 ) { $ret = WrtCacheTestCase13( $coPtr, GOOD, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 14  || $case == 99 ) { $ret = WrtCacheTestCase14( $coPtr, GOOD, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 15  || $case == 99 ) { $ret = WrtCacheTestCase15( $coPtr, GOOD, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 16  || $case == 99 ) { $ret = WrtCacheTestCase16( $coPtr, GOOD, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 17  || $case == 99 ) { $ret = WrtCacheTestCase17( $coPtr, GOOD, $snPtr, $moxaIPListPtr, $moxaChannelListPtr, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 18 )                 { $ret = WrtCacheTestCase18( $coPtr, GOOD, $snPtr, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 19 || $case == 99 ) { $ret = WrtCacheTestCase19( $coPtr, GOOD, $snPtr, $parmsPtr ); }
    if ( $ret != GOOD ) { return $ret; }

    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
    CtlrLogTextAll( $coPtr, "           Write Cache Test Case $case ends.       ");
    CtlrLogTextAll( $coPtr, "---------------------------------------------------");

    return $ret;
}


###############################################################################
1;   # we need this for a PM


##############################################################################
# $Log$
# Revision 1.5  2005/06/01 22:19:09  PalmiD
# TBolt00000000: General cleanup.
# Reviewed by Craig Menning (virtually).
#
# Revision 1.4  2005/05/26 21:28:58  KohlmeyerA
# Tbolt00000000:  Added 2 hr flexible timeout to wait for batteries to charge after 12 hr
# power off (WCTC09).  General cleanup.
# Reviewed by Craig Menning.
#
# Revision 1.3  2005/05/25 16:39:51  PalmiD
# TBolt00000000: Elliminated paths for "GlobalCache Enabled" in WrtCacheTestCase18
# (RollingCodeUpdates) due to the change in policy of disabling Global Cache prior to
# RollingCodeUpdates.   Reviewed by Craig Menning.
#
# Revision 1.2  2005/05/18 19:24:24  PalmiD
# TBolt00000000: Changed power off delay to 25 min from 30 min to prevent losing
# communication with the controller.
# Reviewed by Craig Menning.
#
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
# Revision 1.21  2005/05/04 12:34:29  PalmiD
# TBolt00000000: Consolodation of similar code to a common function (WrtCacheTimeLine)
# and WrtCacheDisplayTimeLine.
# Reviewed by Craig Menning.
#
# Revision 1.20  2005/03/30 22:19:53  PalmiD
# Tbolt00000000: Added WrtCacheTestCase19. General cleanup.
# Reviewed by Craig Menning.
#
# Revision 1.19  2005/03/13 23:57:22  PalmiD
# TBolt00000000: Added WrtCacheTestCase18 for RollingCodeUpdates. Changed
# WrtCacheTestCase08 to require multiple controllers (can't inactivate a 1-way). Added
# reconnects in case timeouts occur during user responses, or during extended power
# cycling (ie battery testing during TC09). General cleanup.
# Reviewed by Craig Menning and Allen Kohlmeyer.
#
# Revision 1.18  2005/02/04 23:21:43  PalmiD
# TBolt00000000: Added TC17 (Failover). General cleanup.
# Reviewed by Craig Menning.
#
# Revision 1.17  2005/01/28 19:36:38  PalmiD
# TBolt00000000: Finished TC8. Added TC12 - TC16 (Failover). Added calls to new
# WrtCacheVdisksSelectAllAltRandom to replace duplicate code. General cleanup.
# Reviewed by Craig Menning.
#
# Revision 1.16  2005/01/12 23:28:01  PalmiD
# TBolt00000000:General cleanup of error message syntax.
# Reviewed by Craig Menning.
#
# Revision 1.15  2005/01/03 16:44:41  PalmiD
# TBolt00000000: Added TC11. General cleanup.
# Reviewed by Craig Menning.
#
# Revision 1.14  2004/12/14 20:47:18  PalmiD
# TBolt00000000: Added TC09 and TC10. Added controller IP addresses to the error
# messages. General cleanup. Reviewed by Craig Menning.
#
# Revision 1.13  2004/12/03 20:37:18  PalmiD
# Tbolt00000000: Added entries to display vdisk info and global cache info,
# General cleanup.  Reviewed by Craig Menning (virtually)
#
# Revision 1.12  2004/12/01 21:56:24  PalmiD
# TBolt00000000: Added TC08, General cleanup.  Reviewed by Craig Menning (virtually).
#
# Revision 1.11  2004/11/30 20:04:35  NigburC
# TBolt00011442 - Added test case 7 (battery health) to the available write
# cache tests.  Added code to the mirror check to include the global cache
# information for testing (status and battery only).  Added support functions
# for write cache (battery health, display global cache).
# Reviewed by Craig Menning.
#
# Revision 1.10  2004/11/23 22:58:33  PalmiD
# TBolt00000000: Added TC06 to turn on select vdisk write cache and cycle
# global cache to ensure the states of vdisk write cache do not change.
# General cleanup.  Reviewed by Craig Menning (virtually).
#
# Revision 1.9  2004/11/23 20:38:19  PalmiD
# TBolt00000000: Comment wrap cleanup.
#
# Revision 1.8  2004/11/23 20:34:18  PalmiD
# TBolt00000000: Added TC05 to cycle global and vdisk write cache repeatedly, 
# verifying the condition after each request. General cleanup.  
# Reviewed by Craig Menning (virtually).
#
# Revision 1.7  2004/11/22 21:11:29  PalmiD
# TBolt00000000: Added TC03 and TC04 to control vdisks by passing a parameter. 
# Updated calls to new validate routines. Added delay after turning global 
# cache off to allow for cache to flush. General cleanup.
# Reviewed by Craig Menning.
#
# Revision 1.6  2004/11/15 21:02:02  PalmiD
# TBolt00000000: Restructured Test Cases 1 and 2 to call a routine that calls
# the global and vdisk control routines, added POD's, removed old style funtion
# headers, general cleanup, etc.  Reviewed by Chris Nigbur
#
# Revision 1.5  2004/11/11 22:51:02  PalmiD
# TBolt00000000: Added test cases for enabling and disabling all write cache .
# Reviewed by Craig Menning
#
# Revision 1.4  2004/11/09 21:43:41  PalmiD
# Tbolt00000000: updated comments for wrtcache testing
#
# Revision 1.3  2004/11/09 21:26:20  NigburC
# TBolt00011442 - First pass at the WrtCacheSupport.pm file and updates to
# the WrtCache.pm file, basically clean up to contain only what is currently
# required and nothing more.
# Reviewed by Craig Menning (virtually).
#
# Revision 1.2  2004/11/08 17:33:34  MenningC
# Tbolt00000000: updates for wrtcache testing
#
# Revision 1.1  2004/11/08 14:54:31  MenningC
# tbolot00000000: new files for resync, wrtcache and wookiee specific tests. 
# Reviewed by Dave P.
##############################################################################
