#! /usr/bin/perl s
# $Header$
####s##########################################################################
#  
#   CCBE Integration test library - Server control functions
#
#   12/10/2002  XIOtech   Craig Menning
#
#   A set of library functions for integration testing. This set supports
#   manipulation of attached servers.
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002 XIOtech
#
#   For XIOtech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::server  - library for controlling servers

$Id: server.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This file covers functions for controlling servers. The routines here facilitate
actively involving the servers in testing the Bigfoot controller.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones
              ServerAction: reboot, prepare disks
              
        The less significant ones
               servercalls: wrapper function

=cut


#                         
# - what I am
#

package TestLibs::server;

#
# - other modules used
#

use warnings;
#use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

#use XIOTech::cmdMgr;
#use XIOTech::cmUtils;
#use XIOTech::constants;
#use XIOTech::errorCodes;
#use XIOTech::xiotechPackets;
#use XIOTech::PI_CommandCodes;
#use XIOTech::logMgr;

use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::utility;
use TestLibs::Configure;
#use TestLibs::FailOver;
#use TestLibs::Validate;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - Constants used
#



#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 4298 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point for ...
    # primary entry point for ...

    @ISA         = qw(Exporter);
    @EXPORT      = qw(







                      &ServerAction
                      &servercalls




                        

                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $serverIP: The IP address of the server. A text string in ###.###.###.###
         notation. 

 $serverName: The name of the server on the network. No leading slashes.

         
 $moxaIP: The IP address of the moxa power commander that the servers
          are attached to.
          
 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller. 

 $moxaChan: A specific channel parameter for the moxa. This is usually
            a single letter. For more simultaneous control, multiple letters
            may be passed. Sending 'A' will change only a single channel. 
            Sending 'AEF' will change the three indicated channels. The 
            parameter is passed directly to the XIOpower.exe program and 
            no interpretation is done.      



=back

=cut


###############################################################################

=head2 ServerAction function

This is an entry for multiple functions on the server. The supported functions 
are reboot, shutdown and preparing unpartitioned disks.


=cut

=over 1

=item Usage:

 my $rc = ServerAction($serverName, $action);
 
 where: $serverName is the server to be acted upon
        $action is action to be performed on the server
       
        
        $serverName is the name of the server without leading slashes
        
        $action is one of the following:
            reboot: the server is rebooted, script waits until 
                    server responds to a ping
            prepare: rescan and format all unpartitioned drives on
                     the server
            shutdown: does a server shut down


=item Returns:

       $rc will be GOOD or ERROR. The logs should be checked on error.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The Server needs to be logged into the XIOcorp domain. 




=back

=cut




##############################################################################
#
#          Name: ServerAction
#
#        Inputs: server ID, action to be done
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Prepares or Reboots Servers when called from setupconfig.
#                Note: Preparing a server does the same thing as
#                partitioning and formatting all unpartitioned drives on
#                a server.
#
##############################################################################
sub ServerAction
{
    trace();                       
    my ($serverName, $action) = @_;
    
    my $retPing;


    if ( !$action )
    {
        logInfo("You must specify an action to perform");
        return ERROR;
    }

    $action = lc $action;         # make it all lower case

    if ($action eq "reboot")
    {
        #
        # Reboot the server remotely.
        #
        logInfo("Rebooting server $serverName...");
        my @args = ("common/shutdown", "\\\\$serverName /R /T:10 /C"); 

        my $systemReturn =  system(@args);
print "system return:$systemReturn\n";
        if ($systemReturn == 0)
        {
            TestLibs::Logging::logInfo ("Completed System call: @args"); 
        }
        else
        {
            TestLibs::Logging::logError ("######## Failed to run System call @args ########");
        }
#       if (system(@args) != 0)
#       {
#           logError ("Failed to reboot server $server");
#       }
        
        #
        # Wait for the server to shutdown and then wait for it 
        # to come back up by continuously pinging it.
        #
        print "\n";  #Newline in case an error message was returned from the system call
        TestLibs::utility::delay (120);            
        $retPing = TestLibs::utility::pingWait($serverName, 300);    # Ping for 300 seconds
        if ($retPing != GOOD)
        {
            TestLibs::Logging::logError ("Failed waiting for server $serverName to come ready");
            return ERROR;
        }
    }

    elsif ($action eq "shutdown")
    {
        #
        # Shutdown the server remotely.
        #
        logInfo("Shutdown on server $serverName...");
        my @args = ("common/shutdown", "\\\\$serverName /T:10 /C"); 

        my $systemReturn =  system(@args);
print "system return:$systemReturn\n";
        if ($systemReturn == 0)
        {
            TestLibs::Logging::logInfo ("Completed System call: @args"); 
        }
        else
        {
            TestLibs::Logging::logError ("######## Failed to run System call @args ########");
        }
#       if (system(@args) != 0)
#       {
#           logError ("Failed to shutdown server $server");
#       }
        
        #
        # Wait for the server to shutdown and then wait for it 
        # to come back up by continuously pinging it.
        #
        print "\n";  #Newline in case an error message was returned from the system call

        
        #  no delay, return quickly    
        # TestLibs::utility::delay (120);            
    }

    elsif ($action eq "prepare")
    {
        #
        # Prepare the server.
        #        
        my $ret = prepareWindowsDisks($serverName);
        if ($ret != GOOD)
        {
            # Note: An error message will be displayed by the prepare
            # windows disks routine.
            return ERROR;
        }
    }
    
    elsif ($action eq "testping")
    {
        #
        # returns GOOD if we get a response to a ping
        # retruns ERROR if no response
        #        
        $retPing = TestLibs::utility::pingWait($serverName, 10);    # Ping for 300 seconds
        if ($retPing != GOOD)
        {
            TestLibs::Logging::logInfo ("No ping from server $serverName ");
            return ERROR;
        }
    }
        
    else
    {
        logInfo("$action is an unsupported action for a server");
        return ERROR;
    }

    return GOOD;
}

###############################################################################

=head2 servercalls function

This loops through the config information and does the requested action
on the servers. Global data is used.


=cut

=over 1

=item Usage:

 my $rc = servercalls();
 


=item Returns:

       $rc will be GOOD or ERROR. The logs should be checked on error.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The Server needs to be logged into the XIOcorp domain. 




=back

=cut


##############################################################################
#
#          Name: servercalls
#
#        Inputs: none (global data used)
#
#       Outputs: GOOD if successfull, ERROR otherwise.
#
#   Description: Prepares or Reboots Servers when called from setupconfig.
#                Note: Preparing a server does the same thing as
#                partitioning and formatting all unpartitioned drives on
#                a server.
#
##############################################################################
sub servercalls
{
    trace();                       
    my $server;     # The IP address of a server to reboot or prepare.

    my $ret;
    
our @serverIP;
our $curTestGroup;
our @serverAction;    
our @serverGroup;
    
    #
    # Loop through all servers...
    #
    for (my $indexServer = 0; $indexServer < @serverIP; $indexServer++)
    {
        #
        # Check to see if the current server is in the same group as the
        # current test group.
        #
        if ($serverGroup[$indexServer] eq $curTestGroup)
        {

            $server = $serverIP[$indexServer];

            $ret = ServerAction($server, $serverAction[$indexServer]);
            if ( $ret != GOOD )
            {
                return ERROR;
            }

        }
    }
    return GOOD;
}


###############################################################################

















##############################################################################
#
#               Private Functions, but made public for debug
#
##############################################################################



##############################################################################
#
#          Name: Support Functions
#
#  These are probably not exported.
#
##############################################################################

###############################################################################

##############################################################################


1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.1  2005/05/04 18:53:52  RysavyR
# Initial revision
#
# Revision 1.3  2004/02/05 19:54:08  MenningC
# tbolt00000000: new power control script and related changes; reviewed by Al.
#
# Revision 1.2  2003/03/26 21:24:53  WerningJ
# Removed calls to unused modules
# Reviewed by Craig M
#
# Revision 1.1  2002/12/11 15:24:05  MenningC
# TBOLT00000000: new files for large SAN testing. reveiwed by J. Werning
#
#
#
##############################################################################
