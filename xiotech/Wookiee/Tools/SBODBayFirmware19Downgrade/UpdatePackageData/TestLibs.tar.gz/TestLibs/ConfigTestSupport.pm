#! /usr/bin/perl 
# $Header$
##############################################################################
#  
#   CCBE Integration test library - NWay Config Test Suport Functions
#
#   02/16/2004  XIOtech   Mark Schibilla
#
#   A set of library functions for integration testing. This set support
#   testing the creation of an N way system.
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2004 XIOtech
#
#   For XIOtech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::ConfigTestSupport - Perl Tests to test N Way Configuration

$Id: ConfigTestSupport.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing the configuration
of an N way system.  This will involve building up and tearing down
a DSC.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

            NWayConfigLoopEntry() 
              
        The less significant ones

              <none>

=cut


#                         
# - what I am
#

package TestLibs::ConfigTestSupport;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;

use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - local Constants used
#



#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 4298 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #


    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        &AssociateServersToVDisks
                        &CheckVDiskInit
                        &CleanAndLicense
                        &ConnectAllControllers
                        &GetServerCount
                        &MakeSomeVDisks
                        &PowerCycleAllControllers
                        &UpgradeLicense
                        
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.
         
 $moxaPtr: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.
          
 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller. 

 $retIn: This is a controle variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be 
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the 
          attached servers. When configuring systems, this list determines 
          which WWNs will be associated with vdisks. If an entry in this 
          list is not found on the system, it will be ignored. A WWN 
          found on the system that is not included in the list will not 
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.
       



=back

=cut


###############################################################################


##############################################################################
#
# Name:     PowerCycleAllControllers
#
# Inputs:   $coPtr          Pointer to controller object array
#           $snPtr          Pointer to array of controller serial numbers
#           $moxaPtr        Pointer to array of Moxa IP addresses
#           $moxaChPtr      Pointer to array of Moxa channels
#           $ipPtr          Pointer to array of controller IP addresses
#           $promptUser     Flag (Optional)
#                           - TRUE:  (default) Prompt user to press enter to  
#                                    continue power cycle 
#                           - FALSE: Do not prompt user before power cycle
#
#
# Outputs:  GOOD or ERROR
#
# Comments: Power cycle all controllers in the NWay using the Moxa info
#           in the config file.  Reconnect when done.
#
#
#
##############################################################################
sub PowerCycleAllControllers
{
    trace();

    my ($coPtr, $snPtr, $moxaPtr, $moxaChPtr, $ipPtr, $promptUser) = @_;
    
    my @coList = @$coPtr;           # Controller object list
    my @moxaIPList = @$moxaPtr;     # Array of Moxa IP addresses
    my @moxaChList = @$moxaChPtr;   # Array of Moxa channels
    my @snList;
    my $ret = GOOD;
    my $i;

    # if promptUser was not passed, set it to default of TRUE
    if ( !defined($promptUser) )
    {
        $promptUser = TRUE;
    }

    POWER:
    {
        #
        # Power cycle all controllers.  If any were failed this 
        # will get them back to a good starting point.
        #
        print "\n*** Power cycling all controllers! ***\n";

        # Prompt user before power cycling if indicated    
        if ($promptUser != FALSE) 
        {
            print "ACTION: Press return to continue the script. ";
            my $dummy = <STDIN>;
        } 
        
        # Power OFF all controllers
        for ($i = 0; $i < scalar(@moxaChList); $i++)
        {
            $ret = PowerChange($moxaIPList[$i], $moxaChList[$i], "OFF");
            if ( $ret != GOOD )
            {
                logInfo(">>>>>>>> Failed to power off all controllers <<<<<<<<");
                last POWER;
            }
        }
    
        DelaySecs(10);
    
        # Power ON all controllers
        for ($i = 0; $i < scalar(@moxaChList); $i++)
        {
            $ret = PowerChange($moxaIPList[$i], $moxaChList[$i], "ON");
            if ( $ret != GOOD )
            {
                logInfo(">>>>>>>> Failed to power off all controllers <<<<<<<<");
                last POWER;
            }
        }
       
        # Connect to all controllers
        $ret = CcbeConnectAllWithRetries($ipPtr, $coPtr, CCB_PORT, 120);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>>>> Failed to connect to all controllers <<<<<<<<");
            last POWER;
        }
        
        # Create a controller object list from the pointer
        my @coList = @$coPtr;           
        
        # Generate the list of controller serial numbers
        for ($i = 0; $i < scalar(@coList) ; $i++)
        {
            my $sn = GetSerial($coList[$i]);
            
            # If the SN is valid copy it into the array.
            if ($sn != INVALID)
            {
                $$snPtr[$i] = $sn;
            }
            else
            {
                logInfo(">>>>>>>> Failed to get a controller's serial num <<<<<<<<");
                $ret = ERROR;
                last POWER;
            }
        }
    }

    return ($ret);
}


##############################################################################
#
# Name:     ConnectAllControllers
#
# Inputs:   $coPtr          Pointer to controller object array
#           $snPtr          Pointer to array of controller serial numbers
#           $ipPtr          Pointer to array of controller IP addresses
#
# Outputs:  GOOD or ERROR
#
# Comments: Connect to controllers.
#
#
##############################################################################
sub ConnectAllControllers
{
    trace();

    my ($coPtr, $snPtr, $ipPtr) = @_;
    
    my @coList = @$coPtr;           # Controller object list
    my @snList;
    my $ret = GOOD;
    my $i;

    CONNECT:
    {
        # Connect to all controllers
        $ret = CcbeConnectAllWithRetries($ipPtr, $coPtr, CCB_PORT, 120);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>>>> Failed to connect to all controllers <<<<<<<<");
            last CONNECT;
        }
        
        # Create a controller object list from the pointer
        my @coList = @$coPtr;           
        
        # Generate the list of controller serial numbers
        for ($i = 0; $i < scalar(@coList) ; $i++)
        {
            my $sn = GetSerial($coList[$i]);
            
            # If the SN is valid copy it into the array.
            if ($sn != INVALID)
            {
                $$snPtr[$i] = $sn;
            }
            else
            {
                logInfo(">>>>>>>> Failed to get a controller's serial num <<<<<<<<");
                $ret = ERROR;
                last POWER;
            }
        }
    }

    return ($ret);
}


##############################################################################
#
# Name:     CleanAndLicense
#
# Inputs:   $coPtr          Pointer to controller object array
#           $ipPtr          Pointer to array of controller IP addresses
#           $maxCtrls       Max number of controllers to license
#
# Outputs:  GOOD or ERROR
#
# Comments: 
#           - Wipe clean all controllers
#           - Apply license for maxCtrls
#           - Label 1 drive as data
#
##############################################################################
sub CleanAndLicense
{
    trace();
    
    my ($coPtr, $ipPtr, $maxCtrls) = @_;

    my @coList = @$coPtr;           # Controller object list
    my @ipList = @$ipPtr;           # Controller IP list
    my $ctlrM = $coList[0];         # Master controller
    my $ret = GOOD;
    my $ctlr;

    MAIN:
    {
        #
        # Wipe clean the controllers.  This will reconnect to controllers.
        #
        $ret = WipeControllersClean2($coPtr);
        if ( $ret != GOOD )
        {
            logInfo(">>>>>>>> Failed to clean the controllers <<<<<<<<");
            last MAIN;
        }
        
        # Wait for each controller to reach WAIT_LICENSE state (2 min)
        foreach $ctlr (@coList)
        {
            $ret = Wait4MinPowerUpState($ctlr, POWER_UP_WAIT_LICENSE, 120);
            if ( $ret != GOOD )
            {
                logInfo(">>>>>>>> Controller failed to reach the WAIT_LICENSE ".
                        "state <<<<<<<<");
                last MAIN;
            }
        }

        # Since we blew away the licenses for the controllers, need
        # to re-license them.
        $ret = GimmieLicense($coPtr, $ipPtr, $maxCtrls);
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Failed to set-up license <<<<<<<<");
            last MAIN;
        }

        # Rescan before labeling drives
        $ret = RescanBE( $ctlrM );          
        if( $ret != GOOD )
        {
            logInfo(">>>>>>>> Failed to rescan drives. <<<<<<<<");
            last MAIN;
        }

        # Label one drive 
        $ret = LabelSingleDrive($ctlrM, 0, CCBEDATATYPE);
        
        if ( $ret != GOOD )
        {
            logInfo(">>>>>>>> Failed to label the drives <<<<<<<<");
            last MAIN;
        }
    }

    logInfo "Completed Clean and License.";

    return ($ret);
}


##############################################################################
#
# Name:     UpgradeLicense
#
# Inputs:   $master         Master controller object 
#           $newMaxCtrls    Max number of controllers to license
#
# Outputs:  GOOD or ERROR
#
# Comments: 
#           Upgrade an existing license to allow for more controllers
#
#
##############################################################################
sub UpgradeLicense
{
    trace();
    
    my ($master, $newMaxCtrls) = @_;

    my $ret = GOOD;
    my %rsp;
    my $currentMaxCtrls;
    my $vcgID;

    UPGRADE:
    {
        # 
        # Get the VCG info to determine the VCG ID and current max controllers.
        # 
        %rsp = $master->vcgInfo(0);
    
        # Check the response object
        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from vcginfo <<<<<<<<");
            $ret = ERROR;
            last UPGRADE;
        }
        elsif ($rsp{STATUS} != PI_GOOD)
        {
            logInfo("Unable to get vcginfo - ");
            PrintError(%rsp);
            $ret = ERROR;
        }
        else
        {
            # Get the current max controllers and VCG ID from 
            # the response hash.
            $currentMaxCtrls = $rsp{VCG_MAX_NUM_CONTROLLERS};
            $vcgID = $rsp{VCG_ID};
        }

    
        # License for the new max number of controllers, provided it is >
        # current number of controllers.
        if ($newMaxCtrls > $currentMaxCtrls)
        {
            %rsp = $master->vcgApplyLicense($vcgID, $newMaxCtrls);
            
            # Check the response object
            if ( ! %rsp  )
            {
                logInfo(">>>>>>>> Failed to get response from vcgApplyLicense <<<<<<<<");
                $ret = ERROR;
            }
            elsif ($rsp{STATUS} != PI_GOOD)
            {
                logInfo("Unable to apply license - ");
                PrintError(%rsp);
                $ret = ERROR;
            }
            else
            {
                logInfo("Applied license to $vcgID for $newMaxCtrls controllers.");        
            }
        }
        else
        {
            logInfo("New max conrollers is not > current max controllers");
            $ret = ERROR;
        }
    }

    return ($ret);
}


##############################################################################
#
# Name:     GetServerCount
#
# Inputs:   $master         Master controller object 
#
# Outputs:  $pNumServers    Pointer to number of servers.  Used to return
#                           number of servers to the caller
#
# Return:   GOOD or ERROR
#                          
# Comments: 
#           
#
##############################################################################
sub GetServerCount
{
    trace();
    
    my ($master, $pNumServers) = @_;

    my $ret = GOOD;
    my %rsp;

    # Make the request
    %rsp = $master->serverCount();
    
    # If there is no return from the call, log an error.
    if ( ! %rsp  )              
    {
        logInfo(">>>>>>>> Failed to get response from serverCount <<<<<<<<");
        $ret = ERROR;
    }
    # The call returned but the status was not good
    elsif ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("Unable to get serverCount - ");
        PrintError(%rsp);
        $ret = ERROR;
    }
    # Success!
    else
    {
        $$pNumServers = $rsp{COUNT};
        print "$$pNumServers servers found (i.e. server/target pairs)\n";    
    }

    return ($ret);
}

##############################################################################
#
# Name:     MakeSomeVDisks
#
# Inputs:   $master         Master controller object 
#           $numSevers      Need to create at least 1 VDisk for each server
#           $vdiskStrat     How many and what types of VDisks are created
#
# Outputs:  $pNumVdisks     Used to return number of VDisks.  Will be modified 
#                           from value on entry if more VDisks are created.
#                                            
#                           
# Return:   GOOD or ERROR
#                          
# Comments: 
#           
#
##############################################################################
sub MakeSomeVDisks
{
    trace();
    
    my ($master, $numServers, $pNumVdisks, $vdiskStrat) = @_;

    my $ret = GOOD;
    my %rsp;


    #
    # Create VDisks using the input strategy.  Loop until we have at least
    # as many VDisks as servers - hey it's the simple way to do it!
    #
    VDISK: while ($numServers > $$pNumVdisks)
    {
        # Create some VDisks
        logInfo "Running MakeVdisks, strategy $vdiskStrat on $master->{HOST}";
        last VDISK if GOOD != MakeVdisks($master, $vdiskStrat, 0); 

        
        # See how many VDisks there are now to see if we need to make more.
        %rsp = $master->getObjectCount(PI_VDISK_COUNT_CMD);
        
        # If there is no return from the call, log an error.
        if ( ! %rsp  )              
        {
            logInfo(">>>>>>>> Failed to get response from vdiskCount <<<<<<<<");
            $ret = ERROR;
            last VDISK;
        }
        # The call returned but the status was not good
        elsif ($rsp{STATUS} != PI_GOOD)
        {
            logInfo("Unable to get vdiskCount - ");
            PrintError(%rsp);
            $ret = ERROR;
            last VDISK;
        }
        else
        {
            $$pNumVdisks = $rsp{COUNT};
            print "VDisk count=$$pNumVdisks\n";    
        }
    }

    return ($ret);
}


##############################################################################
#
# Name:     AssociateServersToVDisks
#
# Inputs:   $master         Master controller object 
#           $numSevers      Need to create at least 1 VDisk for each server
#           $assocStrat     How to associate servers and VDisks
#
# Return:   GOOD or ERROR
#                           
#                           
# Comments: 
#
##############################################################################
sub AssociateServersToVDisks
{
    trace();
    
    my ($master, $numServers, $assocStrat) = @_;

    my $ret = GOOD;
    my $numLuns;
    my $remaining;
    my %rsp;


    # 
    # Server to VDisk Association (map, mask, whatever...)
    #
    # Strategy  Description
    # --------  -----------
    #   1       Use only the first server-target pair for each 
    #           physical server.  This is the way ICON Release 2.5
    #           and earlier does it.
    #
    #   2       Use all available server - target pairs.  Map VDisk x
    #           to Server x through LUN x.  This simulates how ICON will
    #           work when VPort assignment is implemented.       
    #
    #
    # Handle error condition if LUN > 63?  Let AssociateSingleVdisk
    # handle it for now.
    #
    if ($assocStrat == 1)
    {
        # See if Craig has a func to determine the first SID for
        # each physical server.
        print "Associate Stragety 1: First Server ID for each physical server\n";
    }
    elsif ($assocStrat == 2)
    {
        print "Associate Stragety 2: Server x to VDisk x using LUN x\n";
        
        for (my $i = 0; $i < $numServers; $i++)
        {
            # 
            # Get the server info to see if a VDisk is already associated
            # to this server.
            # 
            %rsp = $master->serverInfo($i);
            
            if ( ! %rsp  )              
            {
                logInfo(">>>>>>>> Failed to get serverInfo for sid $i <<<<<<<<");
                $ret = ERROR;
                last;
            }
            # The call returned but the status was not good
            elsif ($rsp{STATUS} != PI_GOOD)
            {
                logInfo("Unable to get serverInfo for sid $i - ");
                PrintError(%rsp);
                $ret = ERROR;
                last;
            }
            # Success!
            else
            {
                # If the number of LUNs is 0 then there is not currently
                # a VDisk associated to this server.
                $numLuns = $rsp{NLUNS};
                
                if ($numLuns == 0)
                {
                    # First is this disk ready for use. (devstat = 0x10)
                    if (0 != CheckInitProgress($master, $i))
                    {
                        logInfo("Waiting for vdisk $i to become operational");
    
                        while (0 != ($remaining = CheckInitProgress($master, $i)))
                        {
                            print " $remaining percent left to initialize \r";
                            # pause for a second or 2
                            sleep 2;
                        }
                    }
    
                    # Bail out of the loop on the first error
                    if (GOOD != AssociateSingleVdisk($master, $i, $i, $i))
                    {
                        $ret = ERROR;
                        last;
                    }                                 
                }
            }
        }    
    }

    return ($ret);
}


##############################################################################
#
# Name:     CheckVDiskInit
#
# Inputs:   $master         Master controller object 
#           $numVDisks      How many VDisks there are currently
#
# Outputs:  none
#           
# Return:   none
#                           
# Comments: Assumes there are no gaps in the VDisk ID list.
#           
#
##############################################################################
sub CheckVDiskInit
{
    trace();
    
    my ($master, $numVdisks) = @_;

    my $ret = GOOD;
    my $remaining;
    my %rsp;
    my $i;

    # Check status of all VDisks
    for ($i = 0; $i < $numVdisks; $i++)
    {
        print "Checking VDisk $i...\n";
        
        # Is this disk ready for use? (devstat = 0x10)
        if (0 != CheckInitProgress($master, $i))
        {
            logInfo("Waiting for VDisk $i to become operational");
    
            while (0 != ($remaining = CheckInitProgress($master, $i)))
            {
                print " $remaining percent left to initialize \r";
                # pause for a second or 2
                sleep 2;
            }
        }
    }
}


###############################################################################



1;   # we need this for a PM

##############################################################################
#
# $Log$
# Revision 1.1  2005/05/04 18:53:52  RysavyR
# Initial revision
#
# Revision 1.2  2004/04/09 19:11:01  KohlmeyerA
# Tbolt00000000 - Added parameter to PowerCycleAllControllers to prevent prompt before power cycling.  Reviewed by Craig
#
# Revision 1.1  2004/02/19 23:52:25  SchibillaM
# TBolt00000000: Separate NWay algorithms and support functions into separate
# files.  Move max controllers constant into Constants.pm.  Minor changes to
# PromptUser().
#
# Revision 1.8  2004/02/16 19:34:22  SchibillaM
# TBolt00000000: Add comments, general clean up.
#
# Revision 1.7  2004/02/13 18:18:49  SchibillaM
# TBolt00000000: Changes to Case00 and Case01 based on suggestions
# from Chris.
#
# Revision 1.6  2004/02/11 20:53:04  SchibillaM
# TBolt00000000: Additional error checking on CCBE calls. Check that RAIDs
# have completed initialization (pre-condition for FailOverNWay).  Add option
# to expand RAIDs without initializing them in Case01.
#
# Revision 1.5  2004/02/10 21:08:02  SchibillaM
# TBolt00000000: NWayConfigCase00 and Case01 complete.
#
# Revision 1.4  2004/02/06 20:37:52  SchibillaM
# TBolt00000000: NWayConfigCase00 is close - changed to smart connection
# function after power cycle.  Fixed server associate by checking for VDisk init
# complete before associate.
#
# Revision 1.3  2004/02/05 21:45:09  SchibillaM
# TBolt00000000: NWayConfigCase00 works except for server associate.
#
# Revision 1.2  2004/02/03 21:26:10  SchibillaM
# TBolt00000000: NWay configuration tests 0 and 1 complete.
#
# Revision 1.1  2004/02/02 22:26:52  SchibillaM
# TBolt00000000: Starting point for NWay configuration scripts.
#
#
#
##############################################################################
