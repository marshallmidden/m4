# $Header$

##############################################################################
#
#   Fibre Channel Switch and Hub Control Library
#
#   7/17/2002  XIOtech   Eric Thiemann
#
#   Description: This library is meant to provide a place for functions that
#                deal with controlling fibre channel switches and hubs.
#
#   Copyright 2002 XIOtech, A Seagate Company
#
#   For XIOtech internal use only.
#
#   Notes: This module uses prefixing to help organize its contents.
#          See below for prefix meanings.
#
#   Prefix meanings:
# 
#       BSW - Brocade Switch Items
#       FL  - Fibre Library Items 
#
##############################################################################


#
# The name of this perl module.  
#
package TestLibs::Fibre;

#
# Includes...
#
#use IO::Handle;
use PerlLibs::Net::Telnet;
use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::utility;

#
# Setup...
#
use strict;
STDOUT->autoflush(1);
STDERR->autoflush(1);

#
# Brocade Constants used...
#
use constant BSW_DEFAULT_USERNAME => "admin";    # Default Brocade username.
use constant BSW_DEFAULT_PASSWORD => "password"; # Default Brocade password.
use constant BSW_ZONE_NAME_PREFIX => "zn";        # The prefix to the name of each zone
                                                 # that is created.
# The name of the switch configuration that is created and enabled in the
# BSWZoneSwitch function.
use constant BSW_CFG_NAME => "cfg_" . BSW_ZONE_NAME_PREFIX;   


#
# Vixel Constants used...
#
use constant VIX_DEFAULT_PASSWORD => "password"; # Default Vixel password.

# COMMANDS
use constant VIX_LOGIN => "li";                  # log in command
use constant VIX_LOGOUT => "lo";                 # log out command
use constant VIX_CONFIG => "co";                 # configure command
use constant VIX_SHOW_HARDWARE => "hh";          # Show hub ports command
use constant VIX_SHOW_PORTS => "hp";             # Show hub ports command
use constant VIX_PORT => "po";                   # Show hub port command
use constant VIX_PORT_CONTROL => "1";            # Control hub port command
use constant VIX_PORT_BYPASS => "3";             # Set hub port to bypassed
use constant VIX_PORT_AUTO => "2";               # Set hub port to auto

# STATUS
use constant VIX_STATUS_BYPASSED => "bypassed";  # Set hub port to bypassed
use constant VIX_STATUS_INSERTED => "inserted";  # Set hub port to auto


#
# Set up the module export settings.
#
    BEGIN {
        use Exporter ();
        our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

        $VERSION     = 1.00;
        @ISA         = qw(Exporter);
        @EXPORT      = qw(
                            &BrocadeDump
                            
                            &BSWAddZoneToSwitchConfig
                            &BSWRemoveZoneFromSwitchConfig
                            &BSWAreBitmapZonesAcceptable
                            &BSWCreateSwitchZone
                            &BSWDeleteSwitchZone    
                            &BSWDeleteSwitchZoningConfig
                            &BSWDisableSwitchPort
                            &BSWEnableSwitchPort
                            &BSWEnablePorts
                            &BSWEnableSwitchZoningConfig
                            &BSWGetNumberOfSwitchPorts
                            &BSWIsSwitchReadyForCommands
                            &BSWLogInToSwitch
                            &BSWLogOutOfSwitch
                            &BSWSaveSwitchZoningConfig
                            &BSWShowSwitchZoningConfig
                            &BSWZoneSwitch
                            
                            &FCSetup1
                            
                            &RemoveZone0
                            &RestoreeZone0

                            &VixHubIsReadyForCommands
                            &VIXShowPorts
                            &VIXGetPortStatus
                            &VIXDisableHubPort
                            &VIXEnableHubPort
                            &VIXGetNumberOfHubPorts
                            &VIXLogInToHub
                            &VIXLogOutOfHub


                            BSW_DEFAULT_PASSWORD
                            BSW_DEFAULT_USERNAME 
                            BSW_ZONE_NAME_PREFIX
                            BSW_CFG_NAME
                            VIX_DEFAULT_PASSWORD
                            VIX_STATUS_BYPASSED
                            VIX_STATUS_INSERTED                                                       
                         );
    }
    our @EXPORT_OK;


################################################################################
############################# Implementation Section ###########################
################################################################################

################################################################################
################################# Brocade Switch ###############################
################################################################################

my %_switchName;       # The hash that contains the names of all of the switches
                       # that are currently logged into.

##############################################################################
#
#          Name: BSWLogInToSwitch
#
#        Inputs: switch ip address, optional username (defaults to BSW_BSW_DEFAULT_USERNAME), 
#                optional password (defaults to BSW_BSW_DEFAULT_PASSWORD)
#
#       Outputs: A telnet session object to the switch that was just
#                logged into.  If an error occurs, undef is returned.
#
#  Globals Used: none
#
#   Description: Logs in to the specified Brocade Silkworm 3200 BSW switch 
#                and returns the telenet session to the switch.
#
##############################################################################
sub BSWLogInToSwitch
{
    trace();
    my $ipAddress = $_[0];        # The IP address of the switch.
    my $username = $_[1];         # The username used to login to the switch.
    my $password = $_[2];         # The password used to login to the switch.

    my $t;                        # The telnet session to the switch.  

    #
    # If the user did not specified a username and/or a password, use the
    # default values.
    #    
    if (!defined($username))
    {
        $username = BSW_DEFAULT_USERNAME;       
    } 
    if (!defined($password))
    {
        $password = BSW_DEFAULT_PASSWORD;
    }

    #
    # Telnet to the switch.
    #
    $t = new Net::Telnet;
    eval { $t->open($ipAddress); };
    if ($@)  # If Error, try again ater a wait. another script may be using the switch
    {
        sleep (30);
        eval { $t->open($ipAddress); };
        if ($@)
        {
            logWarning(">>>>>>>> Unable to open a telnet session with the switch <<<<<<<<");                  return undef;     
        }
    }
    #
    # Login to the switch.
    #
    eval { $t->login($username, $password); };
    if ($@)  # If Error, try again ater a wait. another script may be using the switch
    {
        sleep (30);
        if ($@) 
        {
            eval { $t->login($username, $password); };
            logWarning(">>>>>>>> Login to the switch failed <<<<<<<<");
            return undef;
        } 
    }
    
    #
    # Check to see if the switch is ready to accept commands and then
    # save the switch name...
    #
    my $readyCheck = TRUE;
    my $match; 
    my $prematch;
    eval
    {
        #
        # Simulate an "enter" press and see if the ready prompt appears.
        #
        $t->print("");
        ($prematch, $match) = $t->waitfor('/.*:.*>.*$/i');
    };
    if ($@)  #If error, try again
    {
        eval
        {
            #
            # Simulate an "enter" press and see if the ready prompt appears.
            #
            $t->print("");
            ($prematch, $match) = $t->waitfor('/.*:.*>.*$/i');
        };
        if ($@)
        {
            $readyCheck = FALSE;
        }    
    }
        
    if ( $readyCheck == FALSE )
    {
        logWarning(">>>>>>>> The switch did not became ready to receive commands ".
              "after logging in <<<<<<<<\n");
    
        #
        # If a telnet session was established, however, it is not responding
        # correctly, thus, just try to close it so a login can be tried again
        # by the user.
        #        
        eval 
        { 
            $t->logout();
            $t->close(); 
        };

        return undef;
    }
    else
    {
        #
        # Login was successful.  Now, extract the switch name.
        #
        $match = trim($match);
        my $index = index($match, ":");
        $_switchName{"$t"} = substr($match, 0, $index);
    }

    return $t;
}

##############################################################################
#
#          Name: BSWLogOutOfSwitch
#
#        Inputs: switch telnet session object
#
#       Outputs: GOOD if no error occurred, ERROR if an error occurred.
#
#  Globals Used: none
#
#   Description: Logs out of the specified Brocade Silkworm 3200 BSW switch.
#
##############################################################################
sub BSWLogOutOfSwitch
{
    trace();
    my ($t) = @_;      # The telnet session to the switch. 
    
    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($t) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }
    
    #                          
    # Log out of the switch.
    #
    eval {
        #
        # Attempt to read a line.  At least one line is expected to be returned
        # after this command.  If the line cannot be read, then an error must
        # have occurred. 
        # 
        $t->print("exit");
        my $line = $t->getline();    
    };
    if ($@) 
    {
        logInfo(">>>>>>>> Logout of the switch failed <<<<<<<<");
        return ERROR;
    }

    #
    # Close the socket associated with the telnet session.
    #
    if ( !$t->close() )
    {
        logInfo("******** Failed to close the switch telnet session socket, but ".
                "switch telnet logout was successfull ********");
    }

    #
    # Change the name of the logged into switch to undef.
    #
    $_switchName{"$t"} = undef;

    return GOOD;
}

##############################################################################
#
#          Name: BSWEnableSwitchPort
#
#        Inputs: switch telnet session object, port to enable
#
#       Outputs: GOOD if no error occurred, ERROR if an error occurred.
#
#  Globals Used: none
#
#   Description: Enables the specified port on the specified switch.
#
##############################################################################
sub BSWEnableSwitchPort
{
    trace();
    my $switch = $_[0];      # The telnet session to the switch.
    my $port = $_[1];        # The port to enable.

    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    #
    # Enable the specified port.
    #
    $switch->print("portEnable $port");                   
    if ( !$switch->waitfor('/' . $_switchName{"switch"} . ':.*>.*$/i') )
    {
        logInfo(">>>>>>>> Unexpected telnet response: switch port may be enabled".
              " or disabled <<<<<<<<\n");
        return ERROR;
    }
    
    return GOOD;
}

##############################################################################
#
#          Name: BSWDisableSwitchPort
#
#        Inputs: switch telnet session object, port to disable
#
#       Outputs: GOOD if no error occurred, ERROR if an error occurred.
#
#  Globals Used: none
#
#   Description: Disables the specified port on the specified switch.
#
##############################################################################
sub BSWDisableSwitchPort
{
    trace();
    my $switch = $_[0];      # The telnet session to the switch.
    my $port = $_[1];        # The port to disable.

    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    #
    # Disable the specified port.
    #
    $switch->print("portDisable $port");                   
    if ( !$switch->waitfor('/' . $_switchName{"$switch"} . ':.*>.*$/i') )
    {
        logInfo(">>>>>>>> Unexpected telnet response: switch port may be enabled".
                 " or disabled <<<<<<<<\n");
        return ERROR;
    }
    
    return GOOD;
}

##############################################################################
#
#          Name: BSWEnablePorts
#
#        Inputs: 
#                pointer to Brocade IPs,
#                pointer Brocade User Names,
#                pointer Brocade Passwords,
#                pointer Brocade ports to enable,
#
#       Outputs: GOOD if no error occurred, ERROR if an error occurred.
#
#  Globals Used: none
#
#   Description: Enables the specified ports on the specified switches.
#
##############################################################################
sub BSWEnablePorts
{
    trace();

    my ($brocadeIPptr, $brocadeUserptr, $brocadePWptr, $brocadePortPtr) = @_;

    #
    # Loop through all Ports and Enable.
    #
    
    my $portIndex = 0;
    my $brocadePort;
    my $BSWobj;
    my $BSWret;
    my $enPortsReturn = GOOD;

    foreach $brocadePort (@$brocadePortPtr)
    {
        $BSWobj = BSWLogInToSwitch($$brocadeIPptr[$portIndex], $$brocadeUserptr[$portIndex], $$brocadePWptr[$portIndex]);
        $BSWret = BSWEnableSwitchPort($BSWobj, $brocadePort);
        if ($BSWret == ERROR)
        {
            $enPortsReturn = ERROR;
        }
        BSWLogOutOfSwitch($BSWobj);
        $portIndex++;
    }
    
    return $enPortsReturn;
}

##############################################################################
#
#          Name: BSWAddZoneToSwitchConfig
#
#        Inputs: switch telnet session object, name of switch config to add
#                a zone to, the name of the zone to add, optional save and
#                enable configuration (TRUE to do so, FALSE to skip, default
#                is TRUE)
#
#       Outputs: GOOD if no error occurred, ERROR if an error occurred.
#
#  Globals Used: none
#
#   Description: Add the specified zone to the specified switch config.
#
##############################################################################
sub BSWAddZoneToSwitchConfig
{
    trace();
    my $switch = $_[0];             # The telnet session to the switch.
    my $cfgName = $_[1];            # The name of the switch config.
    my $zoneName = $_[2];           # The name of the zone to add to the config.
    my $saveAndEnable = $_[3];      # Determines if save and enable are called.

    my $line;                       # A line from the telnet session to the
                                    # switch.

    #
    # Set the default value of saveAndEnable if it was not specified.
    #
    if (!defined($saveAndEnable))
    {
        $saveAndEnable = TRUE;
    }

    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    #
    # Attempt to add the zone and then wait for the command to get sent.
    #
    my $addZoneCommand = "cfgAdd \"$cfgName\", \"$zoneName\"";
    eval 
    {
        $switch->print($addZoneCommand);

        do { $line = $switch->getline(); } 
        while ( !($line =~ /$addZoneCommand.*$/) ); 
    };
    if ($@)
    {
        logInfo(">>>>>>>> Error: cfgAdd command was not sent to switch correctly <<<<<<<<");
        return ERROR;    
    }
 
    #
    # Get the data in the buffer and see if an error occurred.
    #
    $line = $switch->get();
    if ($line =~ /error/)
    {
        if ($line =~ /already contains/)
        {
            #
            # The zone is already in the specified configuration.
            #
            logWarning(">>>>>>>> Zone '$zoneName' is already part of configuration '$cfgName' <<<<<<<<");
            return ERROR;
        }
        else
        {        
            logWarning(">>>>>>>> Adding zone '$zoneName' to configuration '$cfgName' failed <<<<<<<<");
            return ERROR;
        }
    }

    #
    # If specified, save and enable the configuration.
    #
    if ($saveAndEnable == TRUE)
    {
        if (BSWSaveSwitchZoningConfig($switch) == ERROR)
        {
            logInfo(">>>>>>>> Error: saving the switch zoning configuration failed <<<<<<<<");
            return ERROR; 
        }

        if (BSWEnableSwitchZoningConfig($switch, $cfgName) == ERROR)
        {
            logInfo(">>>>>>>> Error: enabling the switch zoning configuration failed <<<<<<<<");
            return ERROR;   
        }
    }

    return GOOD;
}

##############################################################################
#
#          Name: BSWRemoveZoneFromSwitchConfig
#
#        Inputs: switch telnet session object, name of switch config to remove
#                a zone from, the name of the zone to remove, optional save and
#                enable configuration (TRUE to do so, FALSE to skip).
#
#       Outputs: GOOD if no error occurred, ERROR if an error occurred.
#
#  Globals Used: none
#
#   Description: Removes the specified zone from the specified switch config.
#
##############################################################################
sub BSWRemoveZoneFromSwitchConfig
{
    trace();
    my $switch = $_[0];             # The telnet session to the switch.
    my $cfgName = $_[1];            # The name of the switch config.
    my $zoneName = $_[2];           # The name of the zone to remove from the config.
    my $saveAndEnable = $_[3];      # Determines if save and enable are called.

    my $line;                       # A line from the telnet session to the
                                    # switch.

    #
    # Set the default value of saveAndEnable if it was not specified.
    #
    if (!defined($saveAndEnable))
    {
        $saveAndEnable = TRUE;
    }

    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    #
    # Attempt to remove the zone and then wait for the command to get sent.
    #
    my $removeZoneCommand = "cfgRemove \"$cfgName\", \"$zoneName\"";
    eval 
    {
        $switch->print($removeZoneCommand);

        do { $line = $switch->getline(); } 
        while ( !($line =~ /$removeZoneCommand.*$/) ); 
    };
    if ($@)
    {
        logInfo(">>>>>>>> Error: cfgRemove command was not sent to switch correctly <<<<<<<<");
        return ERROR;    
    }
 
    #
    # Get the data in the buffer and see if an error occurred.
    #
    $line = $switch->get();
    if ($line =~ /error/)
    {
        if ($line =~ /is not in/)
        {
            #
            # The zone is not in the specified configuration.
            #
            logWarning(">>>>>>>> Zone '$zoneName' is not part of configuration '$cfgName' <<<<<<<<");
            return ERROR;
        }
        else
        {        
            logWarning(">>>>>>>> Removing zone '$zoneName' to configuration '$cfgName' failed <<<<<<<<");
            return ERROR;
        }
    }

    #
    # If specified, save and enable the configuration.
    #
    if ($saveAndEnable == TRUE)
    {
        if (BSWSaveSwitchZoningConfig($switch) == ERROR)
        {
            logInfo(">>>>>>>> Error: saving the switch zoning configuration failed <<<<<<<<");
            return ERROR; 
        }

        if (BSWEnableSwitchZoningConfig($switch, $cfgName) == ERROR)
        {
            logInfo(">>>>>>>> Error: enabling the switch zoning configuration failed <<<<<<<<");
            return ERROR;   
        }
    }

    return GOOD;
}

##############################################################################
#
#          Name: BSWIsSwitchReadyForCommands
#
#        Inputs: switch telnet session object
#
#       Outputs: TRUE if the switch is ready, otherwise, FALSE.
#
#  Globals Used: none
#
#   Description: Finds out whether or not the specified switch is ready to
#                take telnet commands.               
#
##############################################################################

sub BSWIsSwitchReadyForCommands
{
    trace();
    my $switch = $_[0];      # The telnet session to the switch.

    #
    # Simulate an "enter" press and see if the ready prompt appears.
    #
    eval
    {
        $switch->print(""); 
        $switch->waitfor('/' . $_switchName{"$switch"} . ':.*>.*$/i'); 
    };
    if ($@)
    {
        logInfo ("Error Output from Switch: $@");
        # If an error was returned, try again
        eval
        {
            my $pname =  $_switchName{"$switch"};
            print ("$pname\n");
            $switch->print(""); 
            $switch->waitfor('/' . $_switchName{"$switch"} . ':.*>.*$/i'); 
        };
        if ($@)
        {
            logInfo ("Error Output from Switch, second attempt: $@");
            return FALSE;
        }
    }

    return TRUE;
}

##############################################################################
#
#          Name: BSWAreBitmapZonesAcceptable
#
#        Inputs: reference to a zone bitmap array, number of ports on the 
#                switch that will be using the bitmapped array
#
#       Outputs: TRUE if the array is acceptable, FALSE if it is not.
#
#  Globals Used: none
#
#   Description: Checks to see if the specified zone bitmap is acceptable for
#                a switch with the specified number of ports.  See
#                BSWZoneSwitch for more information on the zone bitmap array.
#
##############################################################################  
sub BSWAreBitmapZonesAcceptable
{
    trace();
    my $refBitmapZones = $_[0];     # Reference to the bitmapped zone array.      
    my $numberOfPorts = $_[1];      # The number of ports on a switch.
    my $i;                          # Array index.
    my $maxZoneValue;               # The maximum value that any zone can have.

    #
    # Calculate the maxZoneValue.  The value is basically a value that represents
    # the integer value that would represent a zone if all ports on the switch
    # were included in that zone.
    #
    $maxZoneValue = 2**($numberOfPorts) - 1;
                      
    #
    # Check to see if each zone has an acceptable of zone entrie. 
    #
    for ($i = 0; $i < scalar(@{$refBitmapZones}); $i++)
    {
        if ($refBitmapZones->[$i] > $maxZoneValue)
        {
            logInfo(">>>>>>>> There are more ports in zone index $i than ".
                     "the total number of ports on the switch <<<<<<<<\n");
            return FALSE;   
        }
        
        if ($refBitmapZones->[$i] <= 0)
        {
            logInfo(">>>>>>>> Zone index $i has an invalid zone entry <<<<<<<<");
            return FALSE;
        }                
    }

    return TRUE;    
}

##############################################################################
#
#          Name: BSWDeleteSwitchZone
#
#        Inputs: telnet session object to the switch where a zone will be
#                deleted, name of the zone to delete
#
#       Outputs: GOOD if the zone was deleted successfully, ERROR if it was not.
#                Note: ERROR is returned if the zone was not found.
#
#  Globals Used: none
#
#   Description: Deletes the specified switch zone.
#
##############################################################################
sub BSWDeleteSwitchZone
{
    trace();
    my $switch = $_[0];             # The telnet session to the switch.
    my $zoneName = $_[1];           # The name of the zone to delete. 

    my $line;                       # A line from the telnet session to the
                                    # switch.

    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    #
    # Attempt to delete the zone and then wait for the command to get
    # sent.
    #
    my $deleteZoneCommand = "zoneDelete \"$zoneName\"";
    eval 
    {
        $switch->print($deleteZoneCommand);

        do { $line = $switch->getline(); } 
        while ( !($line =~ /$deleteZoneCommand.*$/) ); 
    };
    if ($@)
    {
        logInfo(">>>>>>>> Error: zoneDelete command was not sent to switch correctly <<<<<<<<");
        return ERROR;    
    }
 
    #
    # Get the data in the buffer and see if an error occurred.
    #
    $line = $switch->get();
    if ($line =~ /error/)
    {
        logWarning(">>>>>>>> The switch zone deletion failed <<<<<<<<");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: BSWDeleteSwitchZoningConfig
#
#        Inputs: telnet session object to the switch where a config will be
#                deleted, name of the switch config to delete
#
#       Outputs: GOOD if the config was deleted successfully, ERROR if it was not.
#                Note: ERROR is returned if the config was not found.
#
#  Globals Used: none
#
#   Description: Deletes the specified switch zone.
#
##############################################################################
sub BSWDeleteSwitchZoningConfig
{
    trace();
    my $switch = $_[0];             # The telnet session to the switch.
    my $configName = $_[1];         # The name of the config to delete. 

    my $line;                       # A line from the telnet session to the
                                    # switch.

    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    #
    # Attempt to delete the config and then wait for the command to get
    # sent.
    #
    my $deleteConfigCommand = "cfgDelete \"$configName\"";
    eval 
    {
        $switch->print($deleteConfigCommand);

        do { $line = $switch->getline(); } 
        while ( !($line =~ /$deleteConfigCommand.*$/) ); 
    };
    if ($@)
    {
        logInfo(">>>>>>>> Error: cfgDelete command was not sent to switch correctly <<<<<<<<");
        return ERROR;    
    }
 
    #
    # Get the data in the buffer and see if an error occurred.
    #
    $line = $switch->get();
    if ($line =~ /error/)
    {
        logWarning(">>>>>>>> The switch config deletion failed <<<<<<<<");
        return ERROR;
    }

    return GOOD;
}


##############################################################################
#
#          Name: BSWCreateSwitchZone
#
#        Inputs: telnet session object to the switch to zone, name of the
#                new zone, a single zone from a zone bitmap array (in decimal)
#
#       Outputs: GOOD if the zone was created successfully, ERROR if it was not.
#
#  Globals Used: none
#
#   Description: Creates the specified zone on the specified switch.  If a zone
#                with the specified name already exists, then the old zone is
#                DELETED.  Note: See BSWZoneSwitch for more information on the
#                zone bitmap array.  IMPORTANT: This new zone information is not
#                saved into switch flash memory until BSWSaveSwitchZoningConfig is
#                called.
#
##############################################################################
sub BSWCreateSwitchZone
{
    trace();
    my $switch = $_[0];             # The telnet session to the switch.
    my $zoneName = $_[1];           # The name of the new zone.
    my $zone = $_[2];               # A zone from a zone bitmap array.

    my $DEFAULT_SWITCH_DOMAIN = 1;  # The domain number of the switch.

    my $telnetZoneString = "";      # The string that is appended to the
                                    # zoneCreate telnet command.

    my $portDelimiter = "; ";       # The string that separates port entries in
                                    # the telnet zone string.

    my $numberOfSwitchPorts;        # The number of ports on the switch.

    my $portMask;                   # Mask used to find out if a port is
                                    # suppossed to be part of a zone.

    my $line;                       # A line from the telnet session to the
                                    # switch.

    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    #
    # Get the number of ports on the specified switch.
    #
    $numberOfSwitchPorts = BSWGetNumberOfSwitchPorts($switch);
    if ($numberOfSwitchPorts == INVALID)
    {
        logInfo(">>>>>>>> Error: Could not get the number of switch ports <<<<<<<<");
        return ERROR;    
    }

    #
    # Create the new zone string.
    #  
    $telnetZoneString = "\"";
    for (my $i = 0; $i < $numberOfSwitchPorts; $i++)
    {
        $portMask = 2**($i);    # Get the value that represents the current port.

        #
        # If the specified port is in the current zone, add it to the telnet
        # string.
        #
        if ($zone & $portMask)
        {
            $telnetZoneString .= "$DEFAULT_SWITCH_DOMAIN,$i" . $portDelimiter;
        }    
    }

    #
    # Remove the last "next zone" delimiter and end the string with a double
    # quote character.
    #
    my $indexOfLastDelimiter = rindex($telnetZoneString, $portDelimiter);
    $telnetZoneString = substr($telnetZoneString, 0, $indexOfLastDelimiter);
    $telnetZoneString .= "\"";              

    #
    # Try to create the new zone.  If it fails due to a duplicate zone name,
    # then the duplicate zone will be deleted on an attempt will occur again.
    # If it fails again, then the zone creation fails.
    #
    my $try = 1;
    my $duplicateZoneFound = FALSE;
    while ( ($try == 1) || (($try == 2) && ($duplicateZoneFound == TRUE)) )
    {
        #
        # Check to see if the switch is ready to accept commands.
        #
        if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
        {
            logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
            return ERROR;
        }

        #
        # Attempt to create the new zone and then wait for the command to get
        # sent.
        #
        my $createZoneCommand = "zoneCreate \"$zoneName\", $telnetZoneString";
        eval 
        {
            $switch->print($createZoneCommand);

            do { $line = $switch->getline(); } 
            while ( !($line =~ /$createZoneCommand.*$/) ); 
        };
        if ($@)
        {
            logInfo(">>>>>>>> Error: zoneCreate command was not sent to switch correctly <<<<<<<<");
            return ERROR;    
        }
     
        #
        # Get the data in the buffer and see if an error occurred.
        #
        $line = $switch->get();
        if ($line =~ /error/)
        {
            # 
            # If it is the first time, check to see if a duplicate was found.
            # If there is one, try to delete it.
            #
            if ( ($try == 1) && ($line =~ /" duplicate name/) )
            {
                BSWDeleteSwitchZone($switch, $zoneName);
                $duplicateZoneFound = TRUE;    
            }
            else
            {
                $duplicateZoneFound = FALSE;
                
                logWarning(">>>>>>>> The switch zone creation failed <<<<<<<<");
                return ERROR;
            } 
        }

        $try++;
    }
  
    return GOOD;
}

##############################################################################
#
#          Name: BSWZoneSwitch
#
#        Inputs: telnet session to a switch, reference to a bitmap zone array
#
#       Outputs: GOOD if the switch was zoned successfully, otherwise, ERROR
#                is outputted.  Note: ERROR is returned even if some zones
#                create successfully, but not all of them.
#
#  Globals Used: none
#
#   Description: Port zones a switch according to the zones specified in the
#                given bitmap zone array, saves the configuration, and enables
#                it.  A configuration name will be picked and if it is already
#                present, the previous configuration name will be DELETED. 
#
#                Notes: A bitmap zone array is an array
#                of integers, with each entry representing a switch zone.
#                Each bit that is set in an array entry represents a port 
#                that is part of a zone.  Ex:  Using the following array,
#                (14, 8, 3), 3 zones will be created.  The first zone will
#                contain ports 3, 2, and 1 (because 14 = 2^3 + 2^2 + 2^1),
#                the second zone will contain port 3 (because 8 = 2^3), and
#                the third zone will contain ports 1 and 0 (because 3 =
#                2^1 + 2^0).   
#
##############################################################################
sub BSWZoneSwitch
{
    trace();
    my $switch = $_[0];                  # The telnet session to the switch.
    my $refBitmapZones = $_[1];          # A reference to the bitmap zone array.

    my $configCreationString;              # The string that is sent to create
                                           # a switch configuration.

    my $zoneDelimiter = "; ";       # The string that separates zone entries in
                                    # the telnet create config string.

    my $line;                       # A line from the telnet session to the
                                    # switch.

    #
    # Think of these as "private" constants.
    #
    my $BSW_ZONE_NAME_PREFIX = "zn"; # The prefix to the name of each zone
                                 # that is created.

    my $BSW_CFG_NAME = "cfg_$BSW_ZONE_NAME_PREFIX";   # The name of switch configuration
                                              # that is created and enabled.
                                           
    #
    # Check to see if the bitmap zone array is acceptable for the specified
    # switch.
    #
    if ( BSWAreBitmapZonesAcceptable($refBitmapZones, 
         BSWGetNumberOfSwitchPorts($switch)) == FALSE ) 
    {
        logInfo(">>>>>>>> The specified bitmap zone array is not valid for the".
              " specified switch <<<<<<<<\n");
        return ERROR;
    }

    #
    # Create each zone in the bitmap zone array.  At the same time, the switch
    # configuration string will be created.
    #
    $configCreationString = "cfgCreate \"$BSW_CFG_NAME\", \""; 
    my $i = 0;                   # Loop index.
    my $errorOccurred = FALSE;   # This is set to TRUE if an error occurs.
    my $tempZoneName;            # Use as a temporary zone name.
    while (($i < scalar(@$refBitmapZones)) && ($errorOccurred == FALSE))
    {
        #
        # Create the zone and see if an error occurred.
        #
        $tempZoneName = "$BSW_ZONE_NAME_PREFIX$i";
        if ( BSWCreateSwitchZone($switch, $tempZoneName, $$refBitmapZones[$i]) == ERROR )
        {
            $errorOccurred = TRUE;
        }
        else
        {
            #
            # No error occurred, so update the loop index and append the zone
            # name and separater to the create config string. 
            #
            $i++;
            $configCreationString .= $tempZoneName . $zoneDelimiter;
        }   
    }

    #
    # Respond to an error that might have occurred.
    #
    if ($errorOccurred == TRUE)
    {
        logInfo(">>>>>>>> switch zone $i of the bitmap zone array was not ".
              "created successfully.  All zones after this zone were not ".
              "created <<<<<<<<\n");
        return ERROR;
    }

    #
    # Finish the creation of the zone create string by taking off the trailing
    # zone separater and adding an end quote.
    #
    my $indexOfLastDelimiter = rindex($configCreationString, $zoneDelimiter);
    $configCreationString = substr($configCreationString, 0, $indexOfLastDelimiter);
    $configCreationString .= "\"";   
    
    #
    # Try to create the new configuration.  If it fails due to a duplicate 
    # config name, then the duplicate config will be deleted and an attempt 
    # will occur again.  If it fails again, then the config creation fails.
    #
    my $try = 1;
    my $duplicateConfigFound = FALSE;
    while ( ($try == 1) || (($try == 2) && ($duplicateConfigFound == TRUE)) )
    {
        #
        # Send the create switch configuration string and wait until the command
        # was sent.
        #
        eval 
        {
            $switch->print($configCreationString);

            do { $line = $switch->getline(); } 
            while ( !($line =~ /$configCreationString.*$/) ); 
        };
        if ($@)
        {
            logInfo(">>>>>>>> Error: cfgCreate command was not sent to switch correctly <<<<<<<<");
            return ERROR;    
        }
     
        #
        # Get the data in the buffer and see if an error occurred.
        #
        $line = $switch->get();
        if ($line =~ /error/)
        {
            # 
            # If it is the first time, check to see if a duplicate was found.
            # If there is one, try to delete it.
            #
            if ( ($try == 1) && ($line =~ /" duplicate name/) )
            {
                BSWDeleteSwitchZoningConfig($switch, $BSW_CFG_NAME);
                $duplicateConfigFound = TRUE;    
            }
            else
            {
                $duplicateConfigFound = FALSE;
                
                logWarning(">>>>>>>> The switch configuration creation failed <<<<<<<<");
                return ERROR;
            }
        }

        $try++;
    }

    #
    # Enable the new switch configuration
    #
    if ( BSWEnableSwitchZoningConfig($switch, $BSW_CFG_NAME) == ERROR )
    {
        logInfo(">>>>>>>> Enabling the switch zoning configuration failed <<<<<<<<");
        return ERROR;
    }

    #
    # Save the zoning configuration to switch flash.
    #
    if ( BSWSaveSwitchZoningConfig($switch) == ERROR )
    {
        logInfo(">>>>>>>> Saving the switch zoning configuration failed <<<<<<<<");
        return ERROR;
    }

    return GOOD; 
}

##############################################################################
#
#          Name: BSWGetNumberOfSwitchPorts
#
#        Inputs: telnet session to a switch
#
#       Outputs: the number of ports on the switch if successfull, otherwise,
#                INVALID is outputted
#
#  Globals Used: none
#
#   Description: Returns the number of ports on the specified switch.
#
##############################################################################
sub BSWGetNumberOfSwitchPorts
{
    trace();
    my $switch = $_[0];     # The telnet session to the switch.

    my $line;               # A line of output from the switch.
    my $numberOfPorts;      # The number of ports on the switch.
    my @tempPortArray;      # An array with indices representing each port.
    
    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return INVALID;
    }

    eval 
    { 
        #
        # Send a command to get all of the port performance information
        # and wait for the command to be sent.
        # 
        $switch->print("portPerfShow");
        do { $line = $switch->getline(); } 
        while ( !($line =~ /portPerfShow.*$/) );                
                 
        #
        # Now, get the listing of all the ports.
        #
        chomp ( $line = $switch->getline() );

        #
        # Stop showing the port performance information and get the prompt to appear.
        # Note: This loop is neccessary because a single print statement didn't 
        # always work.
        #
        do { $switch->print(""); } 
        while ( !($switch->getline() =~ /$_switchName{"switch"}:.*>.*$/i) ); 
    };
    if ($@) 
    {
        logInfo(">>>>>>>> An error occurred after sending the command to get the ".
                "number of switch ports <<<<<<<<\n");
        return INVALID;
    }
                
    #
    # Get the number of ports. (It is known that the line just received has
    # the port names for each port.)
    #
    @tempPortArray = split /\s+/, $line;

    #
    # Note: -1 is used because the line that is split has an initial tab that
    # causes an entry into the array with an empty string.  -1 discounts that
    # entry.
    #
    $numberOfPorts = scalar(@tempPortArray) - 1;
    
    return $numberOfPorts; 
}

##############################################################################
#
#          Name: BSWSaveSwitchZoningConfig
#
#        Inputs: telnet session to a switch
#
#       Outputs: GOOD if successfull, otherwise, ERROR is outputted
#
#  Globals Used: none
#
#   Description: Saves the specified switch's zoning configuration to the
#                switch's flash memory.
#
##############################################################################
sub BSWSaveSwitchZoningConfig
{
    trace();
    my $switch = $_[0];     # The telnet session to the switch.

    my $line;               # A line from the switch telnet session.

    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    #
    # Send the save configuration command.
    #
    eval { $switch->print("cfgSave"); };
    if ($@)
    {
        logInfo(">>>>>>>> An error occurred while sending the save configuration".
              " command to the switch <<<<<<<<\n");
        return ERROR;
    }

    # 
    # Watch for the switch to begin the save.
    #
    eval { $switch->waitfor('/Updating flash.*$/i'); };
    if ($@)
    {
        logWarning(">>>>>>>> Switch did not begin to save the zoning configuration <<<<<<<<");
        return ERROR;
    }  

    #
    # Get a ready prompt from the switch to ensure that the update has finished.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logInfo(">>>>>>>> The switch was not ready to accept commands after saving".
              " the zoning configuration information <<<<<<<<\n");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: BSWEnableSwitchZoningConfig
#
#        Inputs: telnet session object to the switch where a config will be
#                enabled, name of the config to enable
#
#       Outputs: GOOD if the config was enabled successfully, ERROR if it was not.
#                Note: ERROR is returned if the config was not found.
#
#  Globals Used: none
#
#   Description: Enables the specified switch config.  Note: A
#                BSWSaveSwitchZoningConfig call should be made to ensure that
#                the change takes effect across switch boots.
#
##############################################################################
sub BSWEnableSwitchZoningConfig
{
    trace();
    my $switch = $_[0];     # The telnet session to the switch.
    my $configName = $_[1]; # The name of the config to delete.

    my $line;               # A line from the switch telnet session.

    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    #
    # Send the enable configuration command.
    #
    eval { $switch->print("cfgEnable \"$configName\""); };
    if ($@)
    {
        logInfo(">>>>>>>> An error occurred while sending the save configuration".
                " command to the switch <<<<<<<<\n");
        return ERROR;
    }

    # 
    # Watch for the switch to enable the configuration.
    #
    eval { $switch->waitfor('/" is in effect/i'); };
    if ($@)
    {
        logWarning(">>>>>>>> Switch did not enable the zoning configuration <<<<<<<<");
        return ERROR;
    }  

    #
    # Get a ready prompt from the switch to ensure that the switch is ready to
    # take another command.
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logInfo(">>>>>>>> The switch was not ready to accept commands after enabling".
                " the zoning configuration information <<<<<<<<\n");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: BSWShowSwitchZoningConfig
#
#        Inputs: telnet session object to the switch
#
#       Outputs: GOOD if the config was shown successfully, ERROR if it was not.
#
#  Globals Used: none
#
#   Description: Shows the current zoning configuration for the switch.
#                Note: A "1" in the zone include/exclude list means that
#                a port is included in a zone.  A "0" means that a port is
#                not included in a zone.
#
##############################################################################
sub BSWShowSwitchZoningConfig
{    
    trace();
    my $switch = $_[0];             # The telnet session to the switch.

    my $line;                       # A line from the telnet session to the
                                    # switch.

    my $rawConfigData;              # The configuration data sent from the 
                                    # switch.

    my $temp;                       # Temporary variable used for different
                                    # purposes.

    #
    #
    # Check to see if the switch is ready to accept commands.
    #
    if ( BSWIsSwitchReadyForCommands($switch) == FALSE )
    {
        logWarning(">>>>>>>> The switch was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    #
    # Attempt to show the config and then wait for the command to get
    # sent.
    #
    my $showConfigCommand = "cfgShow";
    eval 
    {
        $switch->print($showConfigCommand);

        do { $line = $switch->getline(); } 
        while ( !($line =~ /$showConfigCommand.*$/) ); 
    };
    if ($@)
    {
        logInfo(">>>>>>>> Error: cfgShow command was not sent to switch correctly <<<<<<<<");
        return ERROR;    
    }

    #
    # Wait for the prompt to show and capture all the information that
    # was shown before it.
    #
    eval
    {
        ($rawConfigData) = $switch->waitfor('/' . $_switchName{"$switch"} . ':.*>.*$/i'); 
    };
    if ($@)
    {
        logInfo(">>>>>>>> Error: switch configuration data was not retreived <<<<<<<<");
        return ERROR;
    }

    #
    # Get the number of ports on the switch.
    #
    my $numberOfPorts;
    if (($numberOfPorts = BSWGetNumberOfSwitchPorts($switch)) == INVALID)
    {
        logInfo(">>>>>>>> Error: unable to get the number of switch ports <<<<<<<<");
        return ERROR;
    }

    #
    # Make a string representing the number of ports.
    #
    my $portsString = "";
    for (my $i = 0; $i < $numberOfPorts; $i++)
    {
        #
        # Check to see if it is the last port.
        #
        if ($i == $numberOfPorts - 1)
        {
            $portsString .= $i;
        }
        else 
        {
            $portsString .= $i;
            if ($i < 10) { $portsString .= "  "; }
            else { $portsString .= " "; }   
        }   
    }

    #
    # Make the string to show.
    #
    my $str;

    #
    # Append column headers used to show the configuration information.
    #
    $str = "--------------------\n";
    $str .= "Zoning Configuration\n";
    $str .= "--------------------\n";
    $str .= "\n";
    $str .= "Zone\tBitmap Value (decimal)\tPorts\n";
    $str .= "    \t                  \t$portsString\n";
    $str .= "----\t----------------------\t" . "-" x length($portsString) . "\n";
    
    #
    # Get the effective configuration data.
    #
    $temp = index($rawConfigData, "Effective configuration:");
    my $configData = substr($rawConfigData, $temp);
     
    #
    # Find a zone and the next following zone.                        
    #
    my $zoneFirst = index($configData, "zone:");
    if ($zoneFirst != -1)
    {
        my $zoneNumber = 0;         # The current zone number.
        my $zoneSecond;             # The location of the zone after zoneFirst.
        my $continueLoop = TRUE;    # This is used to control the loop.
        while ($continueLoop == TRUE)
        {            
            #
            # If no more zones were found, do this one more time, and then
            # stop.  Note: $zoneSecond will be set to the length of the string
            # because it is the last zone found.
            #
            $zoneSecond = index($configData, "zone:", $zoneFirst + 1);
            if ($zoneSecond == -1)
            {
                $continueLoop = FALSE;
                $zoneSecond = length($configData);
            }

            #
            # Find ports in that zone.  The idea here is to search the config data
            # and find ports in it until the next zone is found.
            #
            my $portStringIndex;     # The location before a port value.
            my $portStringEnd;       # The location of the end of a port value.
            my $port;                # The port that was found.
            my $allDone = FALSE;     # This is set to true to stop the loop.
            my $bitmapZoneValue = 0; # The bitmap zone value for a zone.
            $portStringIndex = index($configData, ",", $zoneFirst);
            while ( ($portStringIndex < $zoneSecond) && ($allDone == FALSE) ) 
            {
                #
                # Get a port in the current zone.
                #
                $portStringEnd = index($configData, "\r", $portStringIndex);
                $port = substr($configData, $portStringIndex + 1,
                                  $portStringEnd - $portStringIndex - 2);
                $portStringIndex = index($configData, ",", $portStringEnd);

                #
                # Update the bitmap zone value.
                #
                $bitmapZoneValue |= 2**$port;

                #
                # Check to see if all the ports in all zones have been covered.
                # 
                if ($portStringIndex == -1)
                {
                    $allDone = TRUE;
                }
            }

            # 
            # Append the current zone information. 
            #
            $str .= "$zoneNumber\t$bitmapZoneValue\t\t\t";

            #
            # Construct the port in/out zone string.
            #
            my $portZoneInOrOutString = "";
            for (my $i = 0; $i < $numberOfPorts; $i++)
            {
                if (2**$i & $bitmapZoneValue)
                {
                    $portZoneInOrOutString .= "1  "; 
                }
                else
                {
                    $portZoneInOrOutString .= "0  ";
                }
            }

            #
            # Append the rest of the zone information.
            #
            $str .= "$portZoneInOrOutString\n";

            #  
            # Prepare to seach in the next zone.
            #
            $zoneFirst = index($configData, "zone:", $zoneSecond);
            $zoneNumber++;    
        }
    }

    #
    # Show the zone information.
    #
    logInfo($str);
                      
    return GOOD;
}


##############################################################################
#
#          Name: FCSetup1
#
#        Inputs: IP address for brocade switch
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This assumes a Brocade 16 port switch.
#
#                The following port usage is assumed
#                    ports 0-3: One of the controllers
#                    ports 4-7: the other controller
#                    ports 12-15: any servers
#
#                Zone 1: both controllers
#                Zone 2: the other controller and the servers
#                Zone 3: one controller and the servers
#
#                This function sets up the port mapping for the fail-over
#                test case that requires the controllers to lose 
#                visibility to each other.
#
##############################################################################

sub FCSetup1
{
    my ($ipAddress) = @_;
    

    my @portBitmapArray;
    my $switch;
    my $returnCode = ERROR;     # The value to return.


    # this is the bitmap that describes the desired zoning.

    @portBitmapArray = (0x00FF, 0xF00F, 0xF0F0 );
    
    #
    # log in to switch
    #

    logInfo("Setting up switch for failover test (logging in to switch)");

    $switch = BSWLogInToSwitch($ipAddress);
    
    
    #
    # Check to make sure that the login was successful.
    #
    if ( defined($switch) )
    {
        #
        # Port zone the switch
        #

        logInfo("Applying zones");
        
        if ( BSWZoneSwitch($switch, \@portBitmapArray) == GOOD )
        {
            #
            # Show the results of the zoning.
            #
            logInfo("");
            if ( BSWShowSwitchZoningConfig($switch) == GOOD )
            {
                logInfo("");
                logInfo("The switch was successfully zoned.");
                $returnCode = GOOD;
                
                #
                # Log out of the switch.
                #
                if ( BSWLogOutOfSwitch($switch) == ERROR )
                {
                    logInfo(">>>>>>>> An error occurred while logging out of the switch. <<<<<<<<");    
                }
            }
            else
            {
                logInfo(">>>>>>>> An error occurred while trying to show the zoning configuration. <<<<<<<<");
            }
        }
        else
        {
            logWarning(">>>>>>>> An error occurred while attempting to zone the switch. <<<<<<<<");    
        }
    }
    return $returnCode;
}

##############################################################################
#
#          Name: RemoveZone0
#
#        Inputs: IP address for brocade switch
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This assumes a Brocade 16 port switch. It also assumes the 
#                zoning was setup by the above function. The configuration
#                is called "cfg_zn" and the zone to be removed is "zn0".
#
#
##############################################################################
sub RemoveZone0
{

    my ($ipAddress) = @_;
    

    my @portBitmapArray;
    my $switch;
    my $returnCode = ERROR;     # The value to return.


    
    #
    # log in to switch
    #

    logInfo("Remove ctlr comm zone from switch (logging in to switch)");

    $switch = BSWLogInToSwitch($ipAddress);
    
    
    #
    # Check to make sure that the login was successful.
    #
    if ( defined($switch) )
    {
        #
        # Port zone the switch
        #

        logInfo("Removing zone");
                  
        if ( BSWRemoveZoneFromSwitchConfig($switch, "Lab22DiscControllers", "Lab22All", TRUE ) == GOOD )
        {
            #
            # Show the results of the zoning.
            #
            logInfo("");
            if ( BSWShowSwitchZoningConfig($switch) == GOOD )
            {
                logInfo("");
                logInfo("The switch was successfully updated.");
                $returnCode = GOOD;
                
                #
                # Log out of the switch.
                #
                if ( BSWLogOutOfSwitch($switch) == ERROR )
                {
                    logInfo(">>>>>>>> An error occurred while logging out of the switch. <<<<<<<<");    
                }
            }
            else
            {
                logInfo(">>>>>>>> An error occurred while trying to show the zoning configuration. <<<<<<<<");
            }
        }
        else
        {
            logWarning(">>>>>>>> An error occurred while attempting to re-zone the switch. <<<<<<<<");    
        }
    }
    return $returnCode;


    return GOOD;
}



##############################################################################
#
#          Name: RestoreZone0
#
#        Inputs: IP address for brocade switch
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This assumes a Brocade 16 port switch. It also assumes the 
#                zoning was setup by the above function. The configuration
#                is called "cfg_zn" and the zone to be restored is "zn0".
#
#
##############################################################################
sub RestoreZone0
{

    my ($ipAddress) = @_;
    

    my @portBitmapArray;
    my $switch;
    my $returnCode = ERROR;     # The value to return.


    
    #
    # log in to switch
    #

    logInfo("Restoring zone for failover test (logging in to switch)");

    $switch = BSWLogInToSwitch($ipAddress);
    
    
    #
    # Check to make sure that the login was successful.
    #
    if ( defined($switch) )
    {
        #
        # Port zone the switch
        #

        logInfo("Restoring zone");

        if ( BSWAddZoneToSwitchConfig($switch, "Lab22DiscControllers", "Lab22All", TRUE ) == GOOD )
        {
            #
            # Show the results of the zoning.
            #
            logInfo("");
            if ( BSWShowSwitchZoningConfig($switch) == GOOD )
            {
                logInfo("");
                logInfo("The switch was successfully updated.");
                $returnCode = GOOD;
                
                #
                # Log out of the switch.
                #
                if ( BSWLogOutOfSwitch($switch) == ERROR )
                {
                    logInfo(">>>>>>>> An error occurred while logging out of the switch. <<<<<<<<");    
                }
            }
            else
            {
                logInfo(">>>>>>>> An error occurred while trying to show the zoning configuration. <<<<<<<<");
            }
        }
        else
        {
            logWarning(">>>>>>>> An error occurred while attempting to re-zone the switch. <<<<<<<<");    
        }
    }
    return $returnCode;

}

  

################################################################################
################################### Vixel Hub ##################################
################################################################################

##############################################################################
#
#          Name: VIXLogInToHub
#
#        Inputs: hub ip address, 
#                optional password (defaults to VIX_DEFAULT_PASSWORD)
#
#       Outputs: A telnet session object to the hub that was just
#                logged into.  If an error occurs, undef is returned.
#
#  Globals Used: none
#
#   Description: Logs in to the specified Vixel Hub (VIX) switch 
#                and returns the telenet session to the hub.
#
##############################################################################
sub VIXLogInToHub
{
    trace();
    my ($ipAddress, $password) = @_;

    my $t;                        # The telnet session to the hub.
    my $prematch;
    my $match;

    # If the user did not specified a a password, use the
    # default values.   
    if (!defined($password))
    {
        $password = VIX_DEFAULT_PASSWORD;
    }

    # Telnet to the hub.
    $t = new Net::Telnet;
    eval { $t->open($ipAddress); };
    if ($@)
    {
        logInfo(">>>>>>>> Unable to open a telnet session with the hub <<<<<<<<");
        return undef;     
    }
 

 
       
    # log into the vixel hub  
    $t->print("");  
    $t->waitfor('/>.*$/');
    $t->print(VIX_LOGIN);  
    $t->waitfor('/password:.*$/');
    $t->print("$password");

    ($prematch, $match) = $t->waitfor('/>.*$/');
    $prematch = trim($prematch);
    if($prematch eq "invalid entry")
    {
        logInfo(">>>>>>>> Login to the hub failed due to an invalid password <<<<<<<<");
        return undef;
    }

    
    if ($@) 
    {
        logInfo(">>>>>>>> Login to the hub failed <<<<<<<<");
        return undef;
    } 
    
    # Check to see if the hub is ready to accept commands.
    if ( VixHubIsReadyForCommands($t) == FALSE )
    {
        logInfo(">>>>>>>> The hub did not became ready to receive commands ".
              "after logging in <<<<<<<<\n");
    
        #
        # If a telnet session was established, however, it is not responding
        # correctly, thus, just try to close it so a login can be tried again
        # by the user.
        #        
        eval 
        { 
            $t->logout();
            $t->close(); 
        };

        return undef;
    }

    return $t;
}

##############################################################################
#
#          Name: VIXLogOutOfHub
#
#        Inputs: hub telnet session object
#
#       Outputs: GOOD if no error occurred, ERROR if an error occurred.
#
#  Globals Used: none
#
#   Description: Logs out of the specified Vixel hub.
#
##############################################################################
sub VIXLogOutOfHub
{
    trace();
    my ($hub) = @_;

    # Check to see if the hub is ready to accept commands.
    if ( VixHubIsReadyForCommands($hub) == FALSE )
    {
        logInfo(">>>>>>>> The hub was not ready to accept commands <<<<<<<<");
        return ERROR;
    }
                           
    # Log out of the switch.
    eval {

        # Attempt to read a line.  At least one line is expected to be returned
        # after this command.  If the line cannot be read, then an error must
        # have occurred. 
        $hub->print(VIX_LOGOUT);
        my $line = $hub->getline();    
    };
    if ($@) 
    {
        logInfo(">>>>>>>> Logout of the hub failed <<<<<<<<");
        return ERROR;
    }

    # Close the socket associated with the telnet session.
    if ( !$hub->close() )
    {
        logInfo(">>>>>>>> Failed to close the hub telnet session socket, but ".
                "hub telnet logout was successfull <<<<<<<<<");
    }

    return GOOD;
}

##############################################################################
#
#          Name: VIXEnableHubPort
#
#        Inputs: hub telnet session object, port to enable
#
#       Outputs: GOOD if no error occurred, ERROR if an error occurred.
#
#  Globals Used: none
#
#   Description: Enables the specified port on the specified hub.
#
##############################################################################
sub VIXEnableHubPort
{
    trace();   
    my ($hub, $port) = @_;

    # Check to see if the switch is ready to accept commands.
    if ( VixHubIsReadyForCommands($hub) == FALSE )
    {
        logWarning(">>>>>>>> The hub was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    # issue Hub Ports command
    $hub->print(VIX_SHOW_PORTS);           # hub ports
    if ( !$hub->waitfor('/>.*$/') )
    {
        logInfo(">>>>>>>> Unexpected telnet response: VIXEnableHubPort - VIX_SHOW_PORTS".
                 " or disabled <<<<<<<<\n");
        return ERROR;
    }
    
    # select the port to modify                            
    $hub->print("$port");            # port number    
    if ( !$hub->waitfor('/>.*$/') )
    {
        logInfo(">>>>>>>> Unexpected telnet response: VIXEnableHubPort - port = $port".
                 " <<<<<<<<\n");
        return ERROR;
    }

    # select the control option
    $hub->print(VIX_PORT_CONTROL);            # control
    if ( !$hub->waitfor('/>.*$/') )
    {
        logInfo(">>>>>>>> Unexpected telnet response: VIXEnableHubPort - VIX_PORT_CONTROL".
                 " <<<<<<<<\n");
        return ERROR;
    }
        
    # select bypass mode
    $hub->print(VIX_PORT_AUTO);
    if ( !$hub->waitfor('/>.*$/') )
    {
        logInfo(">>>>>>>> Unexpected telnet response: VIXEnableHubPort - VIX_PORT_AUTO".
                 " <<<<<<<<\n");
        return ERROR;
    }                   
 
    return GOOD;
}

##############################################################################
#
#          Name: VIXDisableHubPort
#
#        Inputs: hub telnet session object, port to disable
#
#       Outputs: GOOD if no error occurred, ERROR if an error occurred.
#
#  Globals Used: none
#
#   Description: Disables the specified port on the specified hub.
#
##############################################################################
sub VIXDisableHubPort
{
    trace();
    my ($hub, $port) = @_;
 

    # Check to see if the switch is ready to accept commands.
    if ( VixHubIsReadyForCommands($hub) == FALSE )
    {
        logWarning(">>>>>>>> The hub was not ready to accept commands <<<<<<<<");
        return ERROR;
    }


    # issue hub ports command
    $hub->print(VIX_SHOW_PORTS);           # hub ports
    if ( !$hub->waitfor('/>.*$/') )
    {
        logInfo(">>>>>>>> Unexpected telnet response: VIXDisableHubPort - VIX_SHOW_PORTS".
                 " <<<<<<<<\n");
        return ERROR;
    }
    
    # Select the desired port on the switch                
    $hub->print("$port");            # port number 
    if ( !$hub->waitfor('/>.*$/') )
    {
        logInfo(">>>>>>>> Unexpected telnet VIXDisableHubPort - port = $port".
                 " or disabled <<<<<<<<\n");
        return ERROR;
    }

    # select the control option
    $hub->print(VIX_PORT_CONTROL);            # control
    if ( !$hub->waitfor('/>.*$/') )
    {
        logInfo(">>>>>>>> Unexpected telnet response: VIXDisableHubPort - VIX_PORT_CONTROL".
                 " <<<<<<<<\n");
        return ERROR;
    }

    # put the switch in auto mode ( should be enabled)
    $hub->print(VIX_PORT_BYPASS);
    if ( !$hub->waitfor('/>.*$/') )
    {
        logInfo(">>>>>>>> Unexpected telnet response: VIXDisableHubPort - VIX_PORT_BYPASS".
                 " <<<<<<<<\n");
        return ERROR;
    }
           
    return GOOD;
}

##############################################################################
#
#          Name: VIXGetNumberOfHubPorts
#
#        Inputs: hub telnet session object
#
#       Outputs: the number of ports on the hub if successful, otherwise,
#                INVALID is outputted
#
#  Globals Used: none
#
#   Description: Returns the number of ports on the specified hub.
#
##############################################################################
sub VIXGetNumberOfHubPorts
{
    trace();
    my ($hub) = @_;

    my $prematch;
    my $match;

    my $ports;

    my @tokens;

    # Check to see if the hub is ready to accept commands.
    if ( VixHubIsReadyForCommands($hub) == FALSE )
    {
        logInfo(">>>>>>>> The hub was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    $hub->print(VIX_SHOW_HARDWARE);  
    ($prematch, $match) = $hub->waitfor('/>.*$/');
    
    @tokens = split(/:/, $prematch);
    @tokens = split(/ /, $tokens[1]);
        
    $ports = trim($tokens[1]);
    
    return $ports;
}

##############################################################################
#
#          Name: VIXShowPorts
#
#        Inputs: hub telnet session object
#
#       Outputs: a table of the port's status
#
#  Globals Used: none
#
#   Description: Returns a string table of the ports on the hub.
#
##############################################################################
sub VIXShowPorts
{
    trace();
    my ($hub) = @_;

    my $prematch;
    my $match;
    my @tokens;

    # Check to see if the hub is ready to accept commands.
    if ( VixHubIsReadyForCommands($hub) == FALSE )
    {
        logInfo(">>>>>>>> The hub was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    $hub->print(VIX_SHOW_PORTS);  
    ($prematch, $match) = $hub->waitfor('/>.*$/');

    @tokens = split(/hp\n/, $prematch);

    return $tokens[1];
}


##############################################################################
#
#          Name: VIXGetPortStatus
#
#        Inputs: hub telnet session object, port to get status
#
#       Outputs: the port's status
#
#  Globals Used: none
#
#   Description: Returns the status of the port, either VIX_STATUS_BYPASSED,
#                or VIX_STATUS_INSERTED
#
##############################################################################
sub VIXGetPortStatus
{
    trace();
    my ($hub, $port) = @_;

    my $prematch;
    my $match;
    my $state;

    my @tokens;

    # Check to see if the hub is ready to accept commands.
    if ( VixHubIsReadyForCommands($hub) == FALSE )
    {
        logInfo(">>>>>>>> The hub was not ready to accept commands <<<<<<<<");
        return ERROR;
    }

    $hub->print(VIX_PORT . " " . "$port");  
    ($prematch, $match) = $hub->waitfor('/>.*$/');
    
    @tokens = split(/:/, $prematch);
    @tokens = split(/ /, $tokens[2]);
    
    $state = trim($tokens[1]);
        
    return $state;
}


##############################################################################
#
#          Name: VixHubIsReadyForCommands
#
#        Inputs: hub telnet session object
#
#       Outputs: TRUE if the switch is ready, otherwise, FALSE.
#
#  Globals Used: none
#
#   Description: Finds out whether or not the specified hub is ready to
#                take telnet commands.
##############################################################################

sub VixHubIsReadyForCommands
{
    trace();
    my ($hub) = @_;      # The telnet session to the hub.

    # Simulate an "enter" press and see if the ready prompt appears.
    eval
    {
        $hub->print(""); 
        $hub->waitfor('/>.*$/'); 
    };
    if ($@)
    {
        return FALSE;
    }

    return TRUE;
}


##############################################################################
#
#          Name: BrocadeDump
#
#        Inputs: ip addr, ptr to list of ports to do
#
#       Outputs: GOOD or ERROR. Data is in log file.
#
#  Globals Used: none
#
#   Description: Dumps debug data from the brocade switch for the selected ports.
##############################################################################

sub BrocadeDump
{
    trace();
    my ($ip, $portPtr) = @_;      

    my $port;
    my $i;
    my $tObj;
    my $ret;
    my $match;
    my $prematch;
    my $msg;


    ##################
    # validate input
    ##################


    $msg = "#####################################################";
    logInfo($msg.$msg);
    logInfo("#     Brocade data collection begin");
    logInfo($msg.$msg);


    ##################
    # log in to switch
    ##################

    logInfo("Logging into switch");

    $tObj = BSWLogInToSwitch( $ip, "root", "password" );

    if  ( !defined($tObj) )
    {
        logInfo("Login failed: Trying alternate method");
        $tObj = BSWLogInToSwitch( $ip, "root", "fibranne" );
    }

    if  ( !defined($tObj) )
    {
        logInfo("Unable to log into brocade switch");
        return ERROR;
    }

    $tObj->timeout(90);         # bigger timeout for large packet.


# jsw add dump for version; switchshow; portcfgshow 
#Before running the test:
#started Finisar to capture the traces of the port(s) under test.
#0/ version; switchshow; portcfgshow
#1/ portlogclear
#2/ portstatsclear <port # of all ports under test>
#3/ portshow <port # under test>
#4/ portregshow <port # under test>
#5/ portrouteshow <port # under test>
#6/ portstructshow <port # under test>
#

    ####################
    # loop for each port
    ####################

    for ( $i = 0; $i < scalar (@$portPtr) ; $i++ )
    {
        $port = $$portPtr[$i];
        $msg = "#####################################################";
        logInfo($msg.$msg);
        logInfo("#     data collection for port $port");
        logInfo($msg.$msg);
        

        ################################
        # portlogdisable
        ################################

    #    logInfo("######################### port log disable ###################");
    #
    #    $tObj->print("portlogdisable");
    #
    #    ($prematch, $match) = $tObj->waitfor('/' . $_switchName{"$tObj"} . ':.*>.*$/i'); 
    #
    #    logInfo("\n\nportlogdisable preMatch:\n".$prematch);
    #    logInfo("\n\nportlogdisable Match:\n".$match);

        ################################ 1
        # switchshow 
        ################################
        
        logInfo("######################### switch show ###################");

        $tObj->print("switchshow");

        ($prematch, $match) = $tObj->waitfor('/' . $_switchName{"$tObj"} . ':.*>.*$/i'); 

        logInfo("\n\nswitchshow preMatch:\n".$prematch);
        logInfo("\n\nswitchshow Match:\n".$match);


        ################################ 2
        # portlogdumpport <failing port> 
        ################################
        
        logInfo("######################### port log dump port ###################");

        $tObj->print("portlogdumpport $port");

        ($prematch, $match) = $tObj->waitfor('/' . $_switchName{"$tObj"} . ':.*>.*$/i'); 

        logInfo("\n\nportlogdumpport $port preMatch:\n".$prematch);
        logInfo("\n\nportlogdumpport $port Match:\n".$match);


        ################################ 3&4
        # portRegShow <failing port> 
        ################################
        
        logInfo("######################### port reg show ###################");

        $tObj->print("portRegShow $port");

        ($prematch, $match) = $tObj->waitfor('/' . $_switchName{"$tObj"} . ':.*>.*$/i'); 

        logInfo("\n\nportRegShow $port preMatch:\n".$prematch);
        logInfo("\n\nportRegShow $port Match:\n".$match);


        ################################ 5
        # portrouteshow <failing port> 
        ################################
        
        logInfo("######################### port route show ###################");

        $tObj->print("portrouteshow $port");

        ($prematch, $match) = $tObj->waitfor('/' . $_switchName{"$tObj"} . ':.*>.*$/i'); 

        logInfo("\n\nportrouteshow $port preMatch:\n".$prematch);
        logInfo("\n\nportrouteshow $port Match:\n".$match);


        ################################ 6
        # portstructshow <failing port> 
        ################################
        
        logInfo("######################### port struct show ###################");

        $tObj->print("portstructshow $port");

        ($prematch, $match) = $tObj->waitfor('/' . $_switchName{"$tObj"} . ':.*>.*$/i'); 

        logInfo("\n\nportstructshow $port preMatch:\n".$prematch);
        logInfo("\n\nportstructshow $port Match:\n".$match);


        ################################ 7
        # supportshow
        ################################
        
        logInfo("######################### support show ###################");

        $tObj->print("supportshow");
 
        ($prematch, $match) = $tObj->waitfor('/' . $_switchName{"$tObj"} . ':.*>.*$/i'); 
 
        logInfo("\n\nsupportshow preMatch:\n".$prematch);
        logInfo("\n\nsupportshow Match:\n".$match);


        ################################
        # portFlagsShow <failing port> 
        ################################
        
        logInfo("######################### port flags show ###################");

        $tObj->print("portFlagsShow $port");

        ($prematch, $match) = $tObj->waitfor('/' . $_switchName{"$tObj"} . ':.*>.*$/i'); 

        logInfo("\n\nportFlagsShow $port preMatch:\n".$prematch);
        logInfo("\n\nportFlagsShow $port Match:\n".$match);

        ################################
        # portlogenable
        ################################
        
  #      logInfo("######################### port log enable ###################");
  #      
  #      $tObj->print("portlogenable");
  #
  #      ($prematch, $match) = $tObj->waitfor('/' . $_switchName{"$tObj"} . ':.*>.*$/i'); 
  #
  #      logInfo("\n\nportlogenable preMatch:\n".$prematch);
  #      logInfo("\n\nportlogenable Match:\n".$match);

    }

    $msg = "#####################################################";
    logInfo($msg.$msg);
    logInfo("#     Brocade data collection complete");
    logInfo($msg.$msg);




    ##################
    # log out
    ##################

    $ret = BSWLogOutOfSwitch ( $tObj );
    if ( $ret != GOOD )
    {
        logInfo("Error logging out of the Brocade switch");
    }

    return $ret;

}



#
# This is needed for a perl module.
#
1;

__END__

=head1 CHANGELOG

 $Log$
 Revision 1.1  2005/05/04 18:53:52  RysavyR
 Initial revision

 Revision 1.21  2003/05/29 12:56:44  WerningJ
 Rewrote all XTC data structures
 Reviewed by Craig M

 Revision 1.20  2003/04/08 19:03:37  MenningC
 TBOLT00000000 fix typo

 Revision 1.19  2003/04/08 18:39:20  MenningC
 TBOLT00000000 added brocade data collection function for MH and SH; reviewed by JW

 Revision 1.18  2003/03/26 21:24:52  WerningJ
 Removed calls to unused modules
 Reviewed by Craig M

 Revision 1.17  2003/03/14 16:25:11  WerningJ
 Changed for New Zoning and Lab22
 Reviewed by Craig M

 Revision 1.16  2002/11/20 16:49:53  WerningJ
 Added BSWEnablePorts function
 Changed logErrors to logWarnings
 Added retries to Brocade calls
 Reviewed by Craig M

 Revision 1.15  2002/09/25 14:55:38  WerningJ
 Changed some prints to logInfos and added some debug for Switch not ready
 Reviewed by Craig M

 Revision 1.14  2002/08/28 20:02:52  WerningJ
 Retry when switch prompt not available.

 Revision 1.13  2002/08/21 17:41:14  ThiemannE
 Updated library so that it can handle switches that have been named other than the default.
 Reviewed by Craigm.

 Revision 1.12  2002/08/15 16:24:54  MenningC
 Tbolt00000000 support for fe communications test; reviewed by Eric

 Revision 1.11  2002/08/13 19:13:35  ReiterR
 Added pasword invalid check.

 Revision 1.10  2002/08/09 16:31:47  ThiemannE
 The brocade switch show port configuration fucntion now does a log to show the config.
 Reviewed by Randy Reiter.

 Revision 1.9  2002/08/09 13:46:29  ThiemannE
 Merging logging changes files.  Logging changes branches merged, but these did not and had new changes.  This will add the new changes to the regular CVS tip.

 Revision 1.5  2002/08/05 16:23:50  ReiterR
 Removed duplicated constant

 Revision 1.4  2002/08/05 15:59:07  ReiterR
 Added the Vixel support to the library.

 Revision 1.3  2002/08/02 01:44:55  HouseK
 Added or corrected some POD (perldoc)

 Revision 1.2  2002/07/31 19:44:18  HouseK
 Result of merge from tag LOGGING_CHANGES

 Revision 1.1.2.3  2002/07/31 14:01:29  ThiemannE
 Tbolt00000000: Changed a log of logError()'s to logInfo()'s

 Revision 1.1.2.2  2002/07/30 19:01:39  ThiemannE
 Tbolt00000000: Added functionality for adding and removing zone from an existing configuration.

 Revision 1.1.2.1  2002/07/26 14:18:07  ThiemannE
 Tbolt00000000: Added logging changes

 Revision 1.1  2002/07/17 21:58:23  ThiemannE
 Tbolt00000000: Initial release.
 Reviewed by Craigm.

=cut
