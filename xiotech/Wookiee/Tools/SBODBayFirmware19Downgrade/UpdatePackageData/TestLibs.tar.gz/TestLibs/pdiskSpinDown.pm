#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library
#
#   10/07/2005  XIOtech   Prashant Ghungurde
#
#   A set of library functions for integration testing. 
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2005-2006 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::pdiskSpinDown - Perl Tests to test pdiskSpinDown feature

$Id: pdiskSpinDown.pm 6390 2005-12-28 14:13:15Z EidenN $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html
=cut 
=head1 SYNOPSIS

This document covers the functions available for testing pdiskSpinDown and auto rebuild feature.  
Much of this is testing in a two-way
environment.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

               getHotspares
               pdiskSpinDownEntry
               pdiskSpinDownCase1
        The less significant ones
               None   

=cut

#
# - what I am
#

package TestLibs::pdiskSpinDown;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use XIOTech::cmVDisk;
use XIOTech::cmRaid;
use XIOTech::cmPDisk;

use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;
#use TestLibs::CtlrGrabber;

use strict;
my @hotspares;
#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 6390 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker


    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &pdiskSpinDownEntry
                        &pdiskSpinDownCase1
                        &getHotspares
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 6390 $);
}
    our @EXPORT_OK;

##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=over 1

=item Common Parameters:

 $objPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.


 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.

=back

=cut


###############################################################################

###############################################################################

=head2 pdiskSpinDownEntry function

A function used for debugging the code as a generic entry. The final 
parameter represents the test case to be run. A test case of 99 will
run most tests. There is no guarantee that the tests can actually 
run sequentially and give full coverage.

=over 1

=item Usage:

 my $rc = pdiskSpinDownEntry($coPtr, $snPtr, $moxaIP, $wwnPtr, $case );
 
 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is the IP address of the Moxa controller
        $wwnPtr is a pointer to a list WWNs
        $case is the test case to run

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the 
           expected state is found.


=back

=cut


##############################################################################
#
#          Name: pdiskSpinDownEntry
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
##############################################################################

sub pdiskSpinDownEntry
{
    trace();
    my ( $coPtr,  $snPtr, $moxaIP, $mmPtr, $wwnPtr, $ipPtr, $case ) = @_;

    my $loopCount;
    my $ret;
    $ret = GOOD;

    my @coList = @$coPtr;

 TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");
 TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "                starting pdiskSpinDown Case $case. ");
 TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");


    if ( $case==1   || $case == 99 ) { $ret = pdiskSpinDownCase1( $coPtr, $snPtr, GOOD ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==2   || $case == 99 ) { $ret = pdiskSpinDownCase2( $coPtr, GOOD, $snPtr ); }
    if ( $ret != GOOD ) { return $ret; }

   TestLibs::Validate::PeriodicDataGather($coPtr);

  TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");
  TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "                 pdiskSpinDown Case $case ends. ");
  TestLibs::IntegCCBELib::CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    
    return $ret;

}

###############################################################################

=head2 pdiskSpinDownCase1 function

This test case validatesd the functionality of spindown feature and auto rebuild feature

Test Steps ...

     1) collect system information
     2) Find a random Vdiks
     3) Get the raid Ids on the vdisk
     4) Get the pdisks belonging to first raid
     5) Fail a pdisk and rebuild it to a hotspare  
     6) Spindown each pdisk
     7) Replace the drive and auto rebuild
     8) Repeat steps 5-7 for all pdisks
     
     
=cut

=over 1

=item Usage:

 my $rc = pdiskSpinDownCase1( $objPtr );
 
 where: $objPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured for N=2.
 The system needs to be configured with a number of vdisks and IO running.

=back

=cut
##########################################################################################
#
#          Name: pdiskSpinDownCase1
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine validates the spindown and autorebuild feature.
#
#########################################################################################
sub pdiskSpinDownCase1
{
    trace();

    my ( $objPtr, $snPtr, $retIn ) = @_;

    my $i = 0;
    my $j = 0;
    my $k = 0;
    my $r = 0;
    my $ret;
    my $cnt;
    my $master;
    my $ctlr;
    my $loopcount = 0;
    my $numCtlrs = 0;
    my @coList;
    my @pids;
    my @initialVdisks;
    my @pdisksBefore;
    my @pdisksDuring;
    my @pdisksAfter;
    my @activeServers;
    my @VDiskList;
    my $totalRaids;
    my @raidIds;
    my $msg;
    my @tMap;
    my $msg0;
    my %raidinfo;
    my %rsp;
    my %vdiskinfo;
    my %info;
    my %info1;
    my %infoh;
    my %return1;

    
    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }
    
    $msg = "------------ Test Case : pdisk spindown functionality validation test---------------";
    $msg0 = "-------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);
    
    
    @coList = @$objPtr;
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    $ctlr = $coList[$master];
   
    #PromptUser( 8 );        
    
    # Show the current BE configuration
    TestLibs::IntegCCBELib::DispVdiskInfo($ctlr);
    
    #
    # We collect data that will be used later for test validation. 
    # The data collected is BE status arrays and FE I/O performance data.  
    #
    
    # Get measure of the current IO
    
    $ret = TestLibs::Validate::VerifyIOGather($objPtr, $snPtr, $master, \@activeServers, \@initialVdisks, \@tMap, 20, 10);
    
    
   ###################
    # STATSVDISK
    ###################

    %rsp = $ctlr->statsVDisk();     # get the initial reading
    
    if ( ! %rsp  )
    {
        logInfo("No response from statsVDisk");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo("Error returned from statsVdisk ");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo  "Virtual Disk Statistics ($rsp{COUNT} disks):";
    logInfo  "";
    logInfo  " VID       RPS        AVGSC         RREQ           WREQ         SPRC        SPSC   ";
    logInfo  "-----  ----------  ----------  -------------  -------------  ----------  ----------";


    for (my $i = 0; $i < $rsp{COUNT}; $i++)
    {
        $msg = "";
        $msg .= sprintf "%5hu  ",  $rsp{VDISKS}[$i]{VID};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{RPS};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{AVGSC};
        $msg .= sprintf "%13s  ",  $rsp{VDISKS}[$i]{RREQ};
        $msg .= sprintf "%13s  ",  $rsp{VDISKS}[$i]{WREQ};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{SPRC};
        $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{SPSC};
        logInfo($msg);
    }

    logInfo("");
 
  ######################################################################################################## 
   # Fail a pdisk and spindown a drive 
    
   # Select a random vdisk 
    logInfo("Choose a random Vdisk.....");
    
    my $request = 1;                #Number of vdisks
    my @rc = TestLibs::BEUtils::GetRandomVdisks($ctlr, $request );
    if ( $rc[0] == INVALID )
    {
        logWarning(">>>>>>>>>>>>>>Could not get a Vdisk<<<<<<<<<<<<<<");
        return ERROR;
    }
    
    my $vid = $rc[0];
    # Get all the raids for this vdisk
    %vdiskinfo = $ctlr->virtualDiskInfo( $vid ); 
    
    if ( ! %vdiskinfo )              
    {
       logInfo(">>>>>>>> Failed to get response from virtualDiskinfo command <<<<<<<<");
       return ERROR;
    }
    if ( $vdiskinfo{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from virtualDiskinfo command <<<<<<<<");
       TestLibs::IntegCCBELib::PrintError(%vdiskinfo);
       return ERROR;
    }
    
    # Display information of this vdisk
    $ret = $ctlr->displayVirtualDiskInfo( %vdiskinfo ); 
    
    #Get Raid IDs of the vdisk
    $totalRaids = $vdiskinfo{RAIDCNT} + $vdiskinfo{DRAIDCNT};
    for ($i = 0; $i < $totalRaids; $i++)
    {
       push( @raidIds, $vdiskinfo{RIDS}[$i] );
    }
    
    # Get pdisks of the first raidId
    %raidinfo = $ctlr->virtualDiskRaidInfo($raidIds[0]); 
    if ( ! %raidinfo )              
    {
       logInfo(">>>>>>>> Failed to get response from raidinfo command <<<<<<<<");
       return ERROR;
    }
    if ( $raidinfo{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from raidinfo command <<<<<<<<");
       TestLibs::IntegCCBELib::PrintError(%raidinfo);
       return ERROR;
    }

    for ($j = 0; $j < $raidinfo{PSDCNT}; $j++)
    {
        push( @pids, $raidinfo{PIDS}[$j]{PID} );
    }
    
    $ret = $ctlr->displayVirtualDiskRaidInfo( %raidinfo ); 
    
    # Get the list of available hotspares.
    my @currenthotspares = getHotspares( $objPtr );   # Consider the first hotspare for rebuild ie. $currenthotspares[0] 
    
    #
    # Spindown each pdisk   Main Loop 
    #
    for ( $k = 0; $k < scalar(@pids); $k++ ) 
    {   
        
        # We make sure that the I/O has not been interrupted.
        #
        $ret = TestLibs::BEUtils::VerifyIO( $objPtr,
                                            \@activeServers,
                                            \@tMap,
                                            \@initialVdisks,
                                            $snPtr
                                           );
        if ( $ret != GOOD ) { return ERROR; }
        #
        # VALIDATION CHECK :: pdisks belonging to the raid before failing a pdisk
        #
         %raidinfo = $ctlr->virtualDiskRaidInfo($raidIds[0]); 

         if ( ! %raidinfo )              
         {
             logInfo(">>>>>>>> Failed to get response from raidinfo command <<<<<<<<");
             return ERROR;
         }
         for ($j = 0; $j < $raidinfo{PSDCNT}; $j++)
         {
             push( @pdisksBefore, $raidinfo{PIDS}[$j]{PID});
         }
         logInfo ("Pdisks belonging to Raid  $raidIds[0] before failing a pdisk :  @pdisksBefore");
         
         
         # Get and Display the info of the drive to be spun down
         %info1 = $ctlr->physicalDiskInfo( $pids[$k] );
         
        if (%info1)
        {
            if ($info1{STATUS} == PI_GOOD)
            {
                my $msg = $ctlr->displayPhysicalDiskInfo(%info1);
                logInfo (" $msg ");
            }
            else
            {
                my $msg = "Unable to retrieve physical disk information.";
                PrintError($msg, %info1);
            }
        }
        else
        {
            logInfo ( "ERROR: Did not receive a response packet.\n" );
        }

         # Get and Display the info of the hotspare
        %infoh = $ctlr->physicalDiskInfo($currenthotspares[0]);
         
        if (%infoh)
        {
            if ($infoh{STATUS} == PI_GOOD)
            {
                my $msg = $ctlr->displayPhysicalDiskInfo(%infoh);
                logInfo (" $msg " );
            }
            else
            {
                my $msg = "Unable to retrieve physical disk information.";
                PrintError($msg, %infoh);
            }
        }
        else
        {
            logInfo ( "ERROR: Did not receive a response packet.\n" );
        }

         #
         # Set Auto failback, Fail a pdisk and spindown
         #
         my $option = 1; 
                       
         %return1 = $ctlr->physicalDiskAutoFailBack ( $option );
         if( $return1{STATUS} == PI_GOOD )
         {
             logInfo ("Autofailback mode is set.\n");
         }
         else
         {
             logInfo ("Could not set autofailback mode.\n"); 
             TestLibs::IntegCCBELib::PrintError( %return1 );
             return ERROR;
         }
                       
         %return1 = $ctlr->physicalDiskFail ( $pids[$k], $currenthotspares[0], 0x02 );
         if ( $return1{STATUS} == PI_GOOD )
         {
              %return1 = $ctlr->physicalDiskSpindown ( $pids[$k] );
             
              if( $return1{STATUS} == 0x00 )      # PI_GOOD
              {
                  logInfo ("Pdisk $pids[$k] is spun down successfully...\n "); 
                  sleep( 60 );
              }
              else
              {
                  logInfo("\n Unable to spindown the drive.");
                  TestLibs::IntegCCBELib::PrintError( %return1 );
                  return ERROR;
              }
              
          }
          else
          {
               TestLibs::IntegCCBELib::PrintError( %return1 );
               return ERROR;
          }
         #
         #
         # VALIDATION CHECK :: Compare pdisk info for HSDNAME of hotspare and DNAME of failed pdisk.
         #
         %infoh = $ctlr->physicalDiskInfo($currenthotspares[0]);
         if ( ! %infoh )              
         {
             logInfo(">>>>>>>> Failed to get response from pdiskinfo command <<<<<<<<");
             return ERROR;
         }
         if ( $infoh{STATUS} != PI_GOOD )      
         {
             logInfo(">>>>>>>> Error from pdiskinfo command <<<<<<<<");
             TestLibs::IntegCCBELib::PrintError( %infoh );
             return ERROR;
         }
         
         
          logInfo("polling until rebuild finishes");
          $ret = INVALID;

          my $lc = 0;
          while ( $ret != GOOD )
          {
              $lc++;
              logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

              $ret = DegradeCheck( $ctlr );
              if ( $ret == ERROR )
              {
                  return ERROR;
              }
              DelaySecs( 15 );
          }
          
          if ($info1{PD_DNAME} == $infoh{HSDNAME})
          { 
             logInfo("Rebuild is completed ..."); 
          }
          else
          {
             logInfo("Rebuilding is not started...."); 
             return ERROR; 
          }
          # We make sure that the I/O has not been interrupted.
          #
          $ret = TestLibs::BEUtils::VerifyIO( $objPtr,
                                             \@activeServers,
                                             \@tMap,
                                             \@initialVdisks,
                                             $snPtr
                                            );
          if ( $ret != GOOD ) { return ERROR; }
          #
          # VALIDATION CHECK :: pdisks belonging to the raid after failing a pdisk and rebuilding to hotspare
          #
          %raidinfo = $ctlr->virtualDiskRaidInfo($raidIds[0]); 
          if ( ! %raidinfo )              
          {
             logInfo(">>>>>>>> Failed to get response from raidinfo command <<<<<<<<");
             return ERROR;
          }
          for ($j = 0; $j < $raidinfo{PSDCNT}; $j++)
          {
             push( @pdisksDuring, $raidinfo{PIDS}[$j]{PID});
          }
          logInfo ("Pdisks belonging to Raid after rebuilding to hotspare $raidIds[0] : @pdisksDuring ");
          #
          #
          # Prompt the user to replace the drive.
          #
          logInfo("Replace the drive........and wait for reverse rebuild to complete.......");
          PromptUser (8);
          
          logInfo("polling until reverse rebuild finishes");
          $ret = INVALID;

          $lc = 0;
          while ( $ret != GOOD )
          {
              $lc++;
              logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

              $ret = DegradeCheck( $ctlr );
              if ( $ret == ERROR )
              {
                  return ERROR;
              }
              DelaySecs( 15 );
          }
        
         #
         # VALIDATION CHECK :: Check the HSDNAME on the hotspare is zero.
         #
         %infoh = $ctlr->physicalDiskInfo($currenthotspares[0]);
         if ( ! %infoh )              
         {
             logInfo(">>>>>>>> Failed to get response from pdiskinfo command <<<<<<<<");
             return ERROR;
         }
         if ( $infoh{STATUS} != PI_GOOD )      
         {
             logInfo(">>>>>>>> Error from pdiskinfo command <<<<<<<<");
             TestLibs::IntegCCBELib::PrintError( %infoh );
             return ERROR;
         }
         
         if (0x00 == $infoh{HSDNAME})
         { 
            logInfo("Reverse rebuild is complete .... Hotspare is free...."); 
         }
         else
         {
            logInfo("Reverse rebuilding is not completed....Hotspare is in use...."); 
            return ERROR; 
         }
         #
         # VALIDATION CHECK :: pdisks belonging to the raid after recovering a pdisk
         #
         %raidinfo = $ctlr->virtualDiskRaidInfo($raidIds[0]); 
         if ( ! %raidinfo )              
         {
             logInfo(">>>>>>>> Failed to get response from raidinfo command <<<<<<<<");
             return ERROR;
         }
         for ($j = 0; $j < $raidinfo{PSDCNT}; $j++)
         {
             push( @pdisksAfter, $raidinfo{PIDS}[$j]{PID} );
         }
          
         logInfo ("Pdisks belonging to Raid after recovering a pdisk $raidIds[0] : @pdisksAfter ");
            
    
    ###################################################################################################### 
    #
    # We make sure that the I/O has not been interrupted.
    #
        $ret = TestLibs::BEUtils::VerifyIO( $objPtr,
                                            \@activeServers,
                                            \@tMap,
                                            \@initialVdisks,
                                            $snPtr
                                          );
        if ( $ret != GOOD ) { return ERROR; }
    
    
     ###################
     # STATSVDISK
     ###################

        %rsp = $ctlr->statsVDisk();     # get the initial reading
    
        if ( ! %rsp  )
        {
             logInfo("No response from statsVDisk");
             return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {   
             logInfo("Error returned from statsVdisk ");
             PrintError(%rsp);
             return ERROR;
        }

        logInfo  "Virtual Disk Statistics ($rsp{COUNT} disks):";
        logInfo  "";
        logInfo  " VID       RPS        AVGSC         RREQ           WREQ         SPRC        SPSC   ";
        logInfo  "-----  ----------  ----------  -------------  -------------  ----------  ----------";


        for (my $i = 0; $i < $rsp{COUNT}; $i++)
        {   
              $msg = "";
              $msg .= sprintf "%5hu  ",  $rsp{VDISKS}[$i]{VID};
              $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{RPS};
              $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{AVGSC};
              $msg .= sprintf "%13s  ",  $rsp{VDISKS}[$i]{RREQ};
              $msg .= sprintf "%13s  ",  $rsp{VDISKS}[$i]{WREQ};
              $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{SPRC};
              $msg .= sprintf "%10lu  ", $rsp{VDISKS}[$i]{SPSC};
              logInfo($msg);
         }

         $msg0 = "-------------------------------------------------------------------------------";
         logInfo($msg0);
         logInfo($msg);
         logInfo($msg0);
    
    }
     
    return GOOD;
}

###############################################################################

=head2 getHotspares function

This subroutine gets the current list of hotspares 

Test Steps ...

     1) Drives should be lebeled

=cut

=over 1

=item Usage:

 my @rc = getHotspares( $objPtr );
 
 where: $objPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be array of pids of hotspares. In case of failure in getting  
       hotspares first element of @rc will be INVALID.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.

=back

=cut
##############################################################################
#
#          Name: getHotspares
#
#        Inputs: controller  
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine gets the current list of hotspares 
#                and return as an array.
#
##############################################################################
sub getHotspares
{
    trace();

    my ( $objPtr ) = @_;
    
    my @coList;
    my $master;
    my $ctlr;
    my $j;
    my $type;
    my @pdisklist;
    
    @coList = @$objPtr;
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    $ctlr = $coList[$master];
    
    
     @pdisklist = GetPddList ( $ctlr );
       
     my $numberofpdisks = scalar (@pdisklist); 
       
     for ($j = 0; $j < $numberofpdisks; $j++)
     {
          $type = GetDriveLabel ($ctlr, $pdisklist[$j]);
          if ($type == 0x02)
          {
               push(@hotspares, $pdisklist[$j]);
          }
          elsif ($type == INVALID)
          {
              logInfo ("Could not find the dirve type for $pdisklist[$j]");
          }
      }
       
      if(scalar(@hotspares))
      { 
          logInfo ("\n\nAvailable Hotspares are : @hotspares\n\n");
      }
      else
      {
          logWarning ("\n No hotspares are available\n");
          $hotspares[0] = INVALID;
          return ERROR;
      }
      
    return @hotspares;    
    
}
#########################################################################################################

##############################################################################

1;   # we need this for a PM

##############################################################################
=head1 CHANGE       LOG
        
##############################################################################
# Change log:
# $Log$
# Revision 1.2  2005/12/28 14:13:15  EidenN
# Removed Use CtrlGrabber   - Trace() is defined in BEutils.PM already.  This fixes the compile error
# "Subroutine getTrace redefined at TestLibs/CtlrGrabber.pm line 5911."
#
# Revision 1.1  2005/08/16 10:13:52  BalemarthyS
# New file for pdiskspindown test cases created by prashant
#
# Revision 1.1  2005/08/16 10:05:31  BalemarthyS
# New file for pdiskspindown test created by prashant
#
#
##############################################################################
