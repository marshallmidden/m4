#! /usr/bin/perl
# $Header$
##############################################################################
#
#   FE simulator test library
#
#   Desc : A set of library functions for fesim configuration`. 
#
#   Original Author:  Gopinadh Anasuri
#
#   Last modified by  $Author: hari_sirigibathini $
#   
#   Modified date     $Date: 2006-07-10 02:55:25 -0500 (Mon, 10 Jul 2006) $
#   
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2006 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::FeSimConfig - fesim configuration feature

$Id: FeSimConfig.pm 11541 2006-07-10 07:55:25Z hari_sirigibathini $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for fesim configuration.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones
               
               FeSimulatorConfig
               FeSimCreateServers
               FeSimCreateWWNArray
               FeSimServerAssociate

        The less significant ones
               
               None   

=cut

#
# - what I am
#

package TestLibs::FeSimConfig;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use XIOTech::cmVDisk;

use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::Validate;
use TestLibs::BEUtils;

# Constants used


#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 11541 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker


    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &FeSimulatorConfig
                        &FeSimCreateServers
                        &FeSimCreateWWNArray
                        &FeSimServerAssociate
                        
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 11541 $);
}
    our @EXPORT_OK;

##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $objPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.


 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.


=back

=cut
###############################################################################

=head2 FeSimulatorConfig

This subroutine hold calls for the subroutines which will create the configuration
required for FE simulator.

=cut

=over 1

=item Usage:

 my $rc = FeSimulatorConfig( $objPtr );
 
 where: $objPtr is a pointer to a list of controller objects

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controller should be configured with N=2 and pdisks labelled.
 
=back

=cut
##############################################################################
#
#          Name: FeSimulatorConfig
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine hold calls to the subroutines which 
#                will create FE simulator configuration.
#
##############################################################################
sub FeSimulatorConfig
{
    trace();
    my ( $objPtr ) = @_;

    my $i;
    my $j;
    my $ret;
    my $master;
    my $ctlr;
    my $numCtlrs;
    my $WWNstr;
    my %rsp;
    my @coList;
    my @serialNums;
    my @newVdisksList;
    my @originalVdisks;
    my @newVdisks;
    my @WWNListPtr;

    @coList = @$objPtr;
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    $ctlr = $coList[$master];

    # get a list of serial numbers to make the output a little 
    # more user friendly
    #
    
    $numCtlrs = scalar( @coList );
    
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNums[$i] = $coList[$i]{SERIAL_NUM};                                   
    }
    
    #
    # Get the VIDs of all the current vdisks
    #
    
    %rsp = $ctlr->virtualDisks();
    
    if ( ! %rsp  )              
    {
       logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
       return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      
    {
       logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
       TestLibs::IntegCCBELib::PrintError(%rsp);
       return ERROR;
    }
        
    # Get the list of pre-existing vdisks

    if( $rsp{COUNT} != 0)
    {
        for ($i = 0; $i < $rsp{COUNT}; $i++)
        {
            $originalVdisks[$i] = $rsp{VDISKS}[$i]{VID};
        }

    }
    
    # Creating of vdisks required for the test
    
    $ret = MakeVdisks($ctlr, 42, 0 );
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to create new vdisks <<<<<<<<");
        return (ERROR);
    }

    #
    # Get the VIDs of all the current vdisks again
    #

    %rsp = $ctlr->virtualDisks();
    if ( ! %rsp  )              
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      
    {
        logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }
        
    for ($i = 0; $i < $rsp{COUNT}; $i++)
    {
        $newVdisks[$i] = $rsp{VDISKS}[$i]{VID};
    }

    #
    # Get VIDs of the new vdisks that were created
    #

    if( scalar(@originalVdisks) != 0)
    {
        for ( $i = 0; $i < scalar(@newVdisks); $i++ )
        {
            if ( 0 == IsInList( $newVdisks[$i], \@originalVdisks ) )
            {
                push (@newVdisksList, $newVdisks[$i]);
            }
        }
    }
    else
    {
        for ( $i = 0; $i < scalar(@newVdisks); $i++ )
        {
            push (@newVdisksList, $newVdisks[$i]);
        }
    }

    logInfo("Vdisks created for the test : \n@newVdisksList");


    print "\nEnter the Port WWN of FeSim server : ";
    $WWNstr = <STDIN>;
    chomp ($WWNstr);
    print "\n";

    # Creation of WWNs of the servers

    $ret = FeSimCreateWWNArray ($WWNstr, \@WWNListPtr); 
 
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to create WWN List <<<<<<<<");
        return (ERROR);
    }

    #logInfo("Port WWNs created for Simulated servers : \n@WWNListPtr\t\n");

    # Creation of servers 

    $ret = FeSimCreateServers ($ctlr, \@WWNListPtr, \@serialNums );

    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to create servers <<<<<<<<");
        return (ERROR);
    }

    # Association of vdisks to the servers

    $ret = FeSimServerAssociate ($ctlr, \@WWNListPtr, \@newVdisksList ); 
    
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to Associate vdisks to servers <<<<<<<<");
        return (ERROR);
    }
   
    return GOOD;
}

###############################################################################

=head2 FeSimCreateServers function

This subroutine creates servers as required for FE simulator test configuration.
=cut

=over 1

=item Usage:

 my $rc = FeSimCreateServers( $ctlr, $wwn, $snum );
 
 where: $ctlr is a controller.
        $wwn is a pointer to a list WWNs.
        @snum is a pointer to list of serial numbers.

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

Depending on the requirement and WWN range required user needs to change values in the 
wwnarray.

The array of WWNs created here would be from XX00XXXXXXXXXXXX to XX2fXXXXXXXXXXXX.

=back

=cut

##############################################################################
#
#          Name: FeSimCreateServers
#
#        Inputs: controller, wwn, snum
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine creates servers as required for FE simulator 
#                test configuration. 
#
##############################################################################
sub FeSimCreateServers
{
    trace();

    my ( $ctlr, $wwn, $snum ) = @_;

    my $i;
    my $j;
    my $msg;
    my @serialNums;
    my @WWNList;
    my @tid = (0, 1, 4, 5);
    my %rsp;

    @WWNList = @$wwn;
    @serialNums = @$snum;

    my @owner = ($serialNums[0], $serialNums[0], $serialNums[1], $serialNums[1]);
    
    for ($i = 0; $i < scalar(@WWNList); $i++)
    {
       for ( $j = 0; $j < 4; $j++ )
       {
            %rsp = $ctlr->serverCreate($tid[$j], $owner[$j], $WWNList[$i], " ");

            if (%rsp)
            {
                if ($rsp{STATUS} == PI_GOOD)
                {
                    logInfo ("Server $WWNList[$i] created with target Id $tid[$j] and owner $owner[$j]");
                }
                else
                {
                    $msg = "Unable to create server.";
                    displayError($msg, %rsp);
                }
            }
            else
            {
                print "ERROR: Did not receive a response packet.\n";
                logout();
            }
       }
    }
    return GOOD;
}

###############################################################################

=head2 FeSimCreateWWNArray function

This subroutine creates WWN names as required for the FE simulator configuration.

=cut

=over 1

=item Usage:

 my $rc = FeSimCreateWWNArray( $WWNstr, $WWNPtr );
 
 where: $WWNstr is a string which holds WWN
        $WWNPtr is a array of reference which will hold the WWNs created

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

Depending on the requirement and WWN range required user needs to change values in the 
wwnarray.

The array of WWNs created here would be from XX00XXXXXXXXXXXX to XX2fXXXXXXXXXXXX.

=back

=cut

##############################################################################
#
#          Name: FeSimCreateWWNArray
#
#        Inputs: WWN string
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Creates servers range from XX00XXXXXXXXXXXX to XX2fXXXXXXXXXXXX.
#
##############################################################################
sub FeSimCreateWWNArray
{
    trace();
    
    my ( $WWNstr, $WWNPtr ) = @_;
    
    my $i;
    my @wwnarray =  ( "00", "11", "12", "13", "14", "15", 
                      "16", "17", "18", "19", "1a", "1b", 
                      "1c", "1d", "1e", "1f", "20", "21", 
                      "22", "23", "24", "25", "26", "27", 
                      "28", "29", "2a", "2b", "2c", "2d",
                      "2e", "2f" );
    
    #
    # Create an array of WWNs
    #

    # Always keeping the actual server as the first entry in the array.

    $$WWNPtr[0] = $WWNstr;

    # Now creating virtual servers as required for the configuration

    for ($i = 1; $i < scalar(@wwnarray); $i++)
    {
        # replace the second byte of the string with elements in the array
        # and copy into a array.

        substr ($WWNstr, 2  , 2) = $wwnarray[$i];
        $$WWNPtr[$i] = $WWNstr;
    }

return GOOD;
}

###############################################################################
              
###############################################################################

=head2 FeSimServerAssociate function

This subroutine associates the vdisks created for the test to the available servers.

The strategy used in association is that, all the 32 vdisks will be associated to 
first virtual server (VP0) using all target ports of the controller using LUN no's 
in the range 0-7. Now associate the rest 31 vdisks from the available 32 vdisks 
((i.e) first vdisk will not be associated again) to the virtual servers using same
LUN and target which is used while associating those vdisk to the real server.  


=cut

=over 1

=item Usage:

 my $rc = FeSimServerAssociate( $ctlr, $wwn, $vdisks );
 
 where: $ctlr is a controller
        $wwn is a pointer to a list WWNs
        $vdisks list of vdisks created for the FE sim configuration. 

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:
 
 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 Controller should be configured.
 
=back

=cut
##############################################################################
#
#          Name: FeSimServerAssociate
#
#        Inputs: controller, wwn, vdisks
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine associates vdisks to servers created for FE 
#                simulator configuration.
#
##############################################################################
sub FeSimServerAssociate
{
    trace();

    my ( $ctlr, $wwn, $vdisks ) = @_;

    my $r;
    my $v;
    my $sid = 0;
    my $lun = 0;
    my $vid = 1;
    my $sidcnt = 0;
    my $luncnt = 8;
    my $sid1 = 0;
    my $remaining;
    my $ret;
    my %rsp;
    my %info;
    my @Select_Server_ID;
    my @Select_Server_ID1;
    my @wwn1;
    my @wwn2;
    my @wwnList;
    my @vdiskList;

    @vdiskList = @$vdisks;

    my $vdiskcount = scalar(@vdiskList);

    if ( $vdiskcount != 32 )
    {
        logWarning(" There are only $vdiskcount vdisks, need 32 vdisks ");
    }

    # First associate all the vdisks to the actual server

    @wwnList = @$wwn;

    $wwn1[0] = $wwnList[0];
    
    logInfo ("Association of the vdisks to the first server");
    
    @Select_Server_ID = FindSIDs( $ctlr, 0, \@wwn1);
 
    $sidcnt = scalar(@Select_Server_ID);

    for( $r = 0; $r < scalar(@vdiskList); $r++)
    {
        # first, is this disk ready for use. (devstat = 0x10)
        if ( 0 !=TestLibs::IntegCCBELib::CheckInitProgress($ctlr, $vdiskList[$r] ) )
        {
            logInfo("Waiting for vdisk $vdiskList[$r] to become operational");

            while ( 0 != ( $remaining =TestLibs::IntegCCBELib::CheckInitProgress($ctlr, $vdiskList[$r] ) ) )
            {
                print " $remaining percent left to initialize \r";
                # pause for a second or 2
                sleep 2;
            }
        }
        
        $ret =TestLibs::IntegCCBELib::AssociateSingleVdisk($ctlr, $Select_Server_ID[$sid], $lun, $vdiskList[$r]);

        if ( $ret == ERROR )
        {
            logWarning(">>>>> Failed Associating Vdisk <<<<<");
            return (ERROR);
        }

        $lun++;
        
        if ( $lun == $luncnt)
        { 
           $sid++;
           $lun = 0;
        }
    }

    # Associate remaining vdisks to the vitual servers such that the vdisks 
    # are associated through same target and with same LUN no.

    logInfo ("Association of the vdisks to virtual servers");

    $lun = 1; 

    for ( my $n = 1; $n < scalar (@wwnList); $n++ ) 
    {
        $wwn2[0] = $wwnList[$n];

        @Select_Server_ID1 = FindSIDs( $ctlr, 0, \@wwn2);

        #logInfo("Server IDs for $wwn2[0]: @Select_Server_ID1");
       
            # first, is this disk ready for use. (devstat = 0x10)
            if ( 0 !=TestLibs::IntegCCBELib::CheckInitProgress($ctlr, $vdiskList[$vid] ) )
            {
                logInfo("Waiting for vdisk $vdiskList[$vid] to become operational");

                while ( 0 != ( $remaining =TestLibs::IntegCCBELib::CheckInitProgress($ctlr, $vdiskList[$vid] ) ) )
                {
                    print " $remaining percent left to initialize \r";
                    # pause for a second or 2
                    sleep 2;
                }
            }
         
            $ret =TestLibs::IntegCCBELib::AssociateSingleVdisk($ctlr, $Select_Server_ID1[$sid1], $lun, $vdiskList[$vid]);
            
            if ( $ret == ERROR )
            {
                logWarning(">>>>> Failed Associating Vdisk <<<<<");
                return (ERROR);
            }
        
            $lun++;
            $vid++;
            
            if ( $lun == $luncnt)
            {    
                $lun = 0;
                $sid1++;
            }

            if ( $vid == $vdiskcount)
            {
                logInfo ("All available vdisks are associated ");
                return GOOD;
            }
    }

return GOOD;

}
##############################################################################

1;   # we need this for a PM

##############################################################################
=head1 CHANGE       LOG
        
##############################################################################
# Change log:
# $Log$
# Revision 1.3  2006/07/10 07:55:25  hari_sirigibathini
# Tbolt00014650
# Modified fesimConfig.pm and IntegCCBELib.pm for getting maximum capabilites of front end simulator
#
# Revision 1.2  2006/05/24 07:51:30  EidenN
# Moved from 750 Branch
#
# Revision 1.1.4.1  2006/02/24 14:17:25  MiddenM
#
# Merge from WOOKIEE_EGGS_GA_BR into MODEL750_BR
#
# Revision 1.1  2006/02/24 08:58:11  AnasuriG
# New File for FE Simulator configuration
#
#
##############################################################################
