#! /usr/bin/perl s
# $Header$
##############################################################################
# File name:  TestLibs::NoFailOver
#
# Desc: A set of library functions for integration testing. These focus on
#       cases where there is no controller fail-over.
#
# Date: 08/05/2002
#
# Original Author:  Craig Menning
#
# Last modified by  $Author: RustadM $
# Modified date     $Date: 2006-09-07 11:37:18 -0500 (Thu, 07 Sep 2006) $
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002-2006 Xiotech Corporation. All rights reserved.
#
#   For Xiotech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::NoFailOver - Perl Tests to Fail Over XIOtech Storage Devices

$Id: NoFailOver.pm 13469 2006-09-07 16:37:18Z RustadM $

=head1 SUPPORTED PLATFORMS

=begin html

<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=end html

=head1 SYNOPSIS

This document describes usuage of the Perl Scripts to Test Controller non-Fail-over

=head1 DESCRIPTION

Test Scripts Available
    

=cut

#                         
# - what I am
#

package TestLibs::NoFailOver;

#
# - other modules used
#

use warnings;
use lib "../CCBE";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::IntegCCBELib;
#use TestLibs::IntegXMCLib;
#use XIOtech::sanscript;
use TestLibs::utility;
use TestLibs::Fibre;
use TestLibs::Validate;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

# constants
use constant QLOGIC_RESET_SEQ_TEST => "SEQUENTIAL";  # Reset Qlogic cards sequentially
use constant QLOGIC_RESET_RND_TEST => "RANDOM";      # Reset Qlogic cards randomly
use constant QLOGIC_FE => "FE";                  # Qlogic Front End Cards
use constant QLOGIC_BE => "BE";              # Qlogic Back End Cards

###### DownFELoopTemporarly specific constants #######

use constant    FAIL => 0;
use constant    UNFAIL => 1;
use constant    CONSTA0 => 1;
use constant    CONSTA1 => 2;
use constant    CONSTA2 => 4;
use constant    CONSTA3 => 8;
use constant    CONSTB0 => 16;
use constant    CONSTB1 => 32;
use constant    CONSTB2 => 64;
use constant    CONSTB3 => 128;
use constant    CONSTA => 256;
use constant    CONSTB => 512;
use constant    ALLCTRLS => 1024;
use constant    ENDCTRLS => 2048;
use constant    ENDSTEPS => 4096;
######################################

#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                      &DownFELoopTemporarly

                      &FECommunicationTest
                      &TestQLogicResets
                      &TestBypassBEVixelHubPorts
                      &TestIPCEthernetFiberCom
                      &TestPowerDownDriveBays
                      &TestFailingDrives
                      &TestExample

                      QLOGIC_RESET_SEQ_TEST
                      QLOGIC_RESET_RND_TEST
                      QLOGIC_FE
                      QLOGIC_BE

                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 13469 $);
}
    our @EXPORT_OK;



######################## Private Functions For DownFELoopTemporarly ############
 
sub _MyIndex
{
    my ($iface) = @_ ;
    my @ifaceindex = (CONSTA0, CONSTA1, CONSTA2, CONSTA3, CONSTB0, CONSTB1, CONSTB2, CONSTB3, CONSTA, CONSTB);
    my $i;
    for ( $i = 0; $i < scalar(@ifaceindex); $i++ )
    {
        if ($ifaceindex[$i] == $iface)
        {
            
            return $i ;
        }
    }
    # just return off the end of the list.  The other side must check for this.
    return $i+1;
}

sub _MyPrintInterface
{
    my ($iface) = @_ ;
    my @ifaceNames =  ("A0", "A1", "A2", "A3", "B0", "B1", "B2", "B3", "A", "B");
    my $msg;
    my $flag ;

    my $i = _MyIndex($iface) ;

    if ($i < scalar(@ifaceNames))
    {
        $msg = $ifaceNames[$i] ;
        $flag = GOOD ;
    }
    else
    {
        $msg = "Unknown interface\n" ;
        $flag = ERROR ;
    }
    logInfo($msg);
    return $flag ;
}

sub _MyPrintStep
{
    my ($Operation) = @_ ;
    my $msg ;

    if ($Operation == FAIL)
    {
        $msg = "FAIL " ;
    }
    elsif ($Operation == UNFAIL)
    {
        $msg = "UNFAIL " ;
    }
    logInfo($msg) ;
    return GOOD ;
}


##############################################################################
# UnFail an interface
#    Inputs:
#           obj1 = master controller object
#           csn  = sn of controller to unfail interface
#           interface = interface to unfail
##############################################################################
sub _unFailInterface
{
    my $msg ;
    logInfo ("\n");

    my ($obj1, $ctrlSN, $interface) = @_;
    my %rsp;

    if (!defined($ctrlSN))
    {
        logInfo ("Missing controller serial number.\n");
        return;
    }
        
    if (!defined($interface))
    {
        logInfo("Missing interface ID.\n");
        return;
    }
    
    %rsp = $obj1->_unFailInterface($ctrlSN, $interface);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo ("Unfail interface requested.\n");
        }
        else
        {
            my $msg = "ERROR: Unable to unfail interface.";
            TestLibs::scrub::displayError($msg, %rsp);
        }
    }
    else
    {
        logInfo ("ERROR: Did not receive a response packet.\n");
        logout();
    }

    logInfo("\n");
}

################################################################################


##############################################################################
#
#          Name: DownFELoopTemporarly
#
#        Inputs: array of connected controller objects, array of brocade
#                switch IP's, map of ports to use for each switch, the number
#                of controllers in the controller array, the number of loops to
#                do. 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Downs the FE Loop for less than 10 seconds.  A failure is
#                not supposed to occur.
#
##############################################################################
sub DownFELoopTemporarly
{
    my ($coPtr, $brocadeIP, $brocadePtr, $numCtrls, $loopCount ) = @_;
    my @Result ;
    my $Operation ;
    my $ret ;
    my $i;
    my $j;
    my $k;
    my $l;
    my $t;
    my $currentIP;
    my @serialNums ;
    my @ifacesn;
    my @relativeiface ;
    my $index;
    my @map ;

    @Result = [CONSTA0,CONSTA1,CONSTA2,CONSTA3,CONSTB0,CONSTB1,CONSTB2,CONSTB3] ;

    # some initial setup.

    # okay get our controller SNs.
    for ($i = 0; $i < $numCtrls ; $i++)
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coPtr->[$i]);
        # setup ifacesn and relativeiface
        for ($j = 0; $j < 4; $j++)
        {
            $k = $i*4 + $j ;            # $ith controller
            $ifacesn[$k] = $serialNums[$i] ;    # we are on the $ith controller
            $relativeiface[$k] = $j ;   # $jth iface of the $ith controller
        }
    }

    logInfo( "Executing FE Failover Test\n") ;
    logInfo( "Loop down less than 10 seconds NOT to failure.\n") ;

    logInfo( "Checking Initial State\n") ;
#    my %initialstate = GetTargetStatus($coPtr->[0]);
#    LogTargetStatus( %initialstate);
#
#    @map = CreateTargetMap( \@serialNums, %initialstate);

    $ret = GroupTargetMap($coPtr, \@serialNums, \@map, 0, LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    # okay, we have 
    $ret = CompareTargetMap(\@map, @Result);    # item 30 in the result list is a default map
    if ($ret == GOOD)
    {
        logInfo( "Ok\n") ;
    }
    elsif ($ret == ERROR)
    {
        logInfo( "Incorrect Result!\n"); 
        logInfo( "Expected - \n");
        PrintTargetMap(@Result);
        logInfo( "Found - \n");
        PrintTargetMap(\@map);
        return ERROR ;
    }
    else
    {
        logInfo( "Unknown Error!\n"); 
        return ERROR ;
    }
    

    # big loop.
    # full test runs loopcount times.
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        logInfo( "Loop $i\n") ;

        $currentIP = "notrun" ;     ## reset

        for ($k=0; $k < 8 ; $k++)
        {
            # roll the dice
            $j = rand(10) ;
            # if $j == 1 we toggle the interface.
            # if $j == 0 we do not.
            if ($j > 5)
            {
                #okay, we need a connection to our brocade.
                #is it already open?
                if ($currentIP ne $brocadeIP->[$k])
                {
                    # it isn't open.
                    # do we have an open connection?
                    if ($currentIP ne "notrun")
                    {
                        BSWLogOutOfSwitch($t) ;
                    }
                    # save the ip of the connection we are going to be working with
                    $currentIP = $brocadeIP->[$k] ;
                    $t = BSWLogInToSwitch ($currentIP);
                    if ($t == ERROR)
                    {
                        logInfo( "Could not login to switch\n") ;
                        return ERROR;
                    }
                }

                logInfo( "    Disabling port $brocadePtr->[$k] : $brocadeIP->[$k]\n") ;
                BSWDisableSwitchPort($t, $brocadePtr->[$k]);
                DelaySecs (4);
                logInfo( "    Enabling port $brocadePtr->[$k] : $brocadeIP->[$k]\n") ;
                BSWEnableSwitchPort($t, $brocadePtr->[$k]);
            }
        }
        # we likely have a port left open.  So close our connection.
        if ($currentIP ne "notrun")
        {
            BSWLogOutOfSwitch($t) ;
        }

        #wait xxx seconds 
        DelaySecs (90) ;

# check output here

#        my %stuff = GetTargetStatus($coPtr->[0]);
#        LogTargetStatus( %stuff);
#
#        @map = CreateTargetMap( \@serialNums, %stuff);

        $ret = GroupTargetMap($coPtr, \@serialNums, \@map, 0, LOGTARGETSTATUS );
        if ( $ret != GOOD )  {return ERROR; }


        # okay, we have 
        $ret = CompareTargetMap(\@map, @Result);
        if ($ret == GOOD)
        {
            logInfo( "Success!\n") ;
        }
        elsif ($ret == ERROR)
        {
            logInfo( "Incorrect Result!\n"); 
            logInfo( "Expected - \n");
            PrintTargetMap(@Result);
            logInfo( "Found - \n");
            PrintTargetMap(\@map);
            return ERROR ;
        }
        else
        {
            logInfo( "Unknown Error!\n"); 
            return ERROR ;
        }
        DelaySecs(270) ;
        logInfo( "\n") ;
    }
    return GOOD ;
}


##############################################################################
#
#          Name: FECommunicationTest
#
#        Inputs: ptr to controller object list
#                ip address xxx.xxx.xxx.xxx for the brocade
#                either "SU" or the loop count
#
#       Outputs: GOOD if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This assumes a Brocade 16 port switch.
#
#                The following port usage is assumed
#                    ports 0-3: One of the controllers
#                    ports 4-7: the other controller
#                    ports 12-15: any servers
#
#                Zone 1: both controllers
#                Zone 2: the other controller and the servers
#                Zone 3: one controller and the servers
#
#                This test removes the connection between controllers by
#                removing the zone that connects them. The connection is
#                lost for 2 minutes, then restored for 2 minutes. if the loop
#                count is 0, the the switch will be set to the initial 
#                configuration.
#
##############################################################################
sub FECommunicationTest
{
    trace();

    my ($coPtr, $fcIP, $theMeans) = @_;
    
    my @coList;
    my $z;
    my $w;
    my $y;
    my $ret;

    @coList = @$coPtr;
    
    
    # $theMeans is either "SU" for setup, or a loop count
     
    if ( "SU" eq uc($theMeans) )
    {
        # setup the switch initially, before the system is configured
        $ret = TestLibs::Fibre::FCSetup1($fcIP);

        if ( $ret != GOOD )
        {
            logInfo(">>>>>>>> Failed to do the initial Brocade switch setup  <<<<<<<<");
            return ERROR;
        }
    }
    else
    {


        $y = $theMeans; 

        for ( $z = 0; $z < $y; $z++ )
        {
            
            CtlrLogTextAll(\@coList , "remove controller fibre link, loop count = $z");
            $ret = TestLibs::Fibre::RemoveZone0($fcIP);
         
            if ( $ret != GOOD )
            {
                logInfo(">>>>>>>> Failed to remove the connection bewteen contollers  <<<<<<<<");
                return ERROR;
            }
    
            DelaySecs(120);

            CtlrLogTextAll(\@coList , "restore controller fibre link, loop count = $z");
            $ret = TestLibs::Fibre::RestoreZone0($fcIP);
            if ( $ret != GOOD )
            {
                logInfo(">>>>>>>> Failed to restore the connection bewteen contollers  <<<<<<<<");
                return ERROR;
            }

            DelaySecs(120);

            $w = $z + 1;
            
            logInfo("------------------------- $w loop(s) completed -------------------------");
             
        }
    }

    return GOOD;
    
}


##############################################################################
#
#          Name: TestQLogicResets
#
#        Inputs: controller list pointer, Number of resets to perform, 
#                type=SEQUENTIAL or RANDOM, Number of Seconds to delay
#                between Resets, Number of seconds to hold the Resets,
#                Number of times to loop between controllers
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Loop that tests Seqential or Random Resets
#
##############################################################################
sub TestQLogicResets
{
    trace();                        # This allows function tracability

    my ($coPtr, $testType, $resets, $qlogicType, $delay, $hold, $loopCount, $newSeed) = @_;

    my $seed;
    my $loop1;
    my $i;
    my $initMaster;
    my $initMasterSN;
    my $newMaster;
    my $slaveSN;
    my $masterSN;
    my $numCtlrs;
    my $j;
    my $chn;
    my $ret;
    my $testLoopCount;
    my @serialNums;
    my $how2fail;
    
    my @startingTmap;
    my @initialVdisks;
    my %info1;
    my $vdiskListPtr;

    my @moxaMap;


    my @coList;
    @coList = @$coPtr;

    $numCtlrs = scalar( @coList );

    ##########################################################################

    #
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    #


    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #
    
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
    }


    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $newMaster == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
        return ERROR;
    }
    
    #
    # display some starting info
    #
    
    $ret = TestLibs::IntegCCBELib::DispPdiskInfo($coList[$newMaster]);

    if ( $ret == ERROR )
    {
        logError("Failed to get pdisk info at start");
        return ERROR;
    }

    $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$newMaster] );
    if ( $ret == ERROR )
    {
        logError("Failed to get target list at start");
        return ERROR;
    }

    $testLoopCount = 0;

    # Default to 2000 loops unless specified
    if (!$loopCount)
    {
        $loop1 = 2000;
    }
    else
    {
        $loop1 = $loopCount;
    }


    # Default to 1234 random genrator seed
    if (!$newSeed)
    {
        $seed = 1234;
    }
    else
    {
        $seed = $newSeed;
    }

    #
    # find the currently active servers
    #

    my @activeServers = TestLibs::Validate::ActiveServerList($coPtr);


    #
    # get the initial/starting target map
    #

    logInfo("Getting the target status, then building the target map");
    
#    %info1 = GetTargetStatus($coList[$newMaster]);
#
#    if ( ! %info1  )              # if no data from call
#    {
#        logInfo(">>>>>>>> Failed to get a response from GetTargetStatus <<<<<<<<");
#        return ERROR;
#    }
#
#    if ( $info1{STATUS} != PI_GOOD )      # if call returned an error
#    {
#        logInfo(">>>>>>>> Error from GetTargetStatus <<<<<<<<");
#        PrintError(%info1);
#        return ERROR;
#    }
#
#    @startingTmap = CreateTargetMap(\@serialNums, %info1);
#
#    PrintTargetMap (\@startingTmap);


    $ret = GroupTargetMap($coPtr, \@serialNums, \@startingTmap, $newMaster,  LOGTARGETMAP);
    if ( $ret != GOOD )  {return ERROR; }

    #
    # get the initial active vdisks for the test
    #


    @initialVdisks =  ActiveVdiskList($coPtr);

    $vdiskListPtr  = \@initialVdisks;

    if ( scalar(@initialVdisks) != 0 )
    {
        # we have some active vdisks
        if ( $initialVdisks[0] == INVALID )
        {
            # error case 
            logInfo(">>>>>>>> Warning - can't get an initial active vdisklist  <<<<<<<<");
            $vdiskListPtr  = 0;   # clear the point so we skip the following tests
        }
    }

    ############################################################################

    #
    # The loop that is really the test
    #

    for ( $i = 0; $i < $loop1; $i++ )
    {
        # find the master,
        logInfo("Searching for the master controller in the group");
        $initMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
        if ( $newMaster == INVALID )
        {
            logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
            return ERROR;
        }

        #
        # First we loop thru all the slaves and fail each one of them
        #

        for ( $j = 0; $j < $numCtlrs; $j++ )
        {
            if ( $j != $initMaster )     # for each slave ( actually, each non-master )
            {
                # get slave SN
                $slaveSN = TestLibs::IntegCCBELib::GetSerial( $coList[$j] );

             
                logInfo("Starting test for slave $slaveSN......");
                
                ###################################################################
                #
                # Perform Resets Test 
                #
                ###################################################################
                if ($testType eq QLOGIC_RESET_SEQ_TEST)
                {
                    $ret = TestLibs::IntegCCBELib::QLResetTestSeq($coList[$j], $resets, $qlogicType, $delay, $hold);
                }
                elsif ($testType eq QLOGIC_RESET_RND_TEST)
                {
                    $ret = TestLibs::IntegCCBELib::QLResetTestRnd($coList[$j], $resets, $qlogicType, $delay, $hold, $seed);
                }
                else
                {
                    $ret = ERROR;
                    logError(">>>>>>>> UNDEFINED TEST TYPE = $testType <<<<<<<<\n");
                }
                if ( $ret == ERROR )
                {
                    logError(">>>>>>>> Failed in $testType reset qlogic test <<<<<<<<\n");
                    return (ERROR);
                }

            }

            ####################################################################
            #
            # Test the state of the system ( NO controllers should be failed )
            #
            ####################################################################
            $ret = TestLibs::Validate::TestSystemState(\@coList, \@activeServers, \@startingTmap, $vdiskListPtr, \@serialNums);
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> Controller state bad after slave test loop  <<<<<<<<");
                return ERROR;
            }
        }
            
        TestLibs::IntegCCBELib::DispVcgInfo($coList[$initMaster]); 
              
        # get master SN
        $masterSN = TestLibs::IntegCCBELib::GetSerial( $coList[$initMaster] );
        
        logInfo("Starting test for master $masterSN......");
        
        ###################################################################
        #
        # Perform Resets Test 
        #
        ###################################################################
        if ($testType eq QLOGIC_RESET_SEQ_TEST)
        {
            $ret = TestLibs::IntegCCBELib::QLResetTestSeq($coList[$initMaster], $resets, $qlogicType, $delay, $hold);
        }
        elsif ($testType eq QLOGIC_RESET_RND_TEST)
        {
            $ret = TestLibs::IntegCCBELib::QLResetTestRnd($coList[$initMaster], $resets, $qlogicType, $delay, $hold, $seed);
        }
        else
        {
            $ret = ERROR;
            logError(">>>>>>>> UNDEFINED TEST TYPE = $testType <<<<<<<<\n");
        }
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in $testType reset qlogic test <<<<<<<<\n");
            return (ERROR);
        }

        ####################################################################
        #
        # Test the state of the system ( NO controllers should be failed )
        #
        ####################################################################
        $ret = TestLibs::Validate::TestSystemState(\@coList, \@activeServers, \@startingTmap, $vdiskListPtr, \@serialNums);
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> Controller state bad with (old) master unfailed <<<<<<<<");
            return ERROR;
        }
       
        $testLoopCount++;

        logInfo("--------------------- Loop $i completed, $testLoopCount failovers completed. -------------------");
    }
    # end loop

    logInfo("End of No Fail Over Loop test completed.");
    return GOOD;

}


##############################################################################
#
#          Name: TestBypassBEVixelHubPorts
#
#        Inputs: controller list pointer, ip of the hub, number of bypasses to
#                perform, number of seconds between bypasses, number of seconds
#                to keep the port bypassed, port of drive bay (IMPORTANT),
#                Number of times to loop between controllers, seed of the random
#                number generator, password of the hub.
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Loop that tests Randomly Disabling Controller BE ports
#
#          NOTE: THIS TEST REQUIRES SPECIAL CONFIGURATION WHICH IS A VIXEL HUB
#                BETWEEN THE CONTROLLER AND THE DRIVEBAY.  USE ONLY ONE PHYSICAL
#                CONNECTION FROM THE HUB TO THE DRIVEBAY.  PASS THE PORT NUMBER
#                OF THE HUB CONNECTED TO THE DRIVEBAY FOR THIS TEST.  THE 
#                DRIVBAY PORT WILL BE TESTED FOR VALID CONNECTIVITY AND THEN 
#                IGNORED FOR THE REMAINDER OF THE TEST.
#
##############################################################################
sub TestBypassBEVixelHubPorts
{
    trace();                        # This allows function tracability

    my ($coPtr, $ipAddress, $resets, $delay, $hold, $driveBayPort, $loopCount, $newSeed, $password) = @_;

    my $seed;           
    my $loop1;
    my $i;
    my $initMaster;
    my $initMasterSN;
    my $newMaster;
    my $serial;
    my $masterSN;
    my $numCtlrs;
    my $j;
    my $chn;
    my $ret;
    my $testLoopCount;
    my @serialNums;
    my $how2fail;
    
    my @startingTmap;
    my @initialVdisks;
    my %info1;
    my $vdiskListPtr;

    my @moxaMap;


    my @coList;
    @coList = @$coPtr;

    $numCtlrs = scalar( @coList );

    ##########################################################################

    #
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    #


    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #
    
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
    }


    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $newMaster == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
        return ERROR;
    }
    
    #
    # display some starting info
    #
    
    $ret = TestLibs::IntegCCBELib::DispPdiskInfo($coList[$newMaster]);

    if ( $ret == ERROR )
    {
        logError("Failed to get pdisk info at start");
        return ERROR;
    }

    $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$newMaster] );
    if ( $ret == ERROR )
    {
        logError("Failed to get target list at start");
        return ERROR;
    }

    $testLoopCount = 0;

    # Default to 2000 loops unless specified
    if (!$loopCount)
    {
        $loop1 = 2000;
    }
    else
    {
        $loop1 = $loopCount;
    }


    # Default to 1234 random genrator seed
    if (!$newSeed)
    {
        $seed = 1234;
    }
    else
    {
        $seed = $newSeed;
    }

    #
    # find the currently active servers
    #

    my @activeServers = TestLibs::Validate::ActiveServerList($coPtr);


    #
    # get the initial/starting target map
    #

    logInfo("Getting the target status, then building the target map");
    
#    %info1 = GetTargetStatus($coList[$newMaster]);
#
#    if ( ! %info1  )              # if no data from call
#    {
#        logInfo(">>>>>>>> Failed to get a response from GetTargetStatus <<<<<<<<");
#        return ERROR;
#    }
#
#    if ( $info1{STATUS} != PI_GOOD )      # if call returned an error
#    {
#        logInfo(">>>>>>>> Error from GetTargetStatus <<<<<<<<");
#        PrintError(%info1);
#        return ERROR;
#    }
#    
#    @startingTmap = CreateTargetMap(\@serialNums, %info1);
#    
#    PrintTargetMap (\@startingTmap);

    $ret = GroupTargetMap($coPtr, \@serialNums, \@startingTmap, $newMaster,  LOGTARGETMAP);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    @initialVdisks =  ActiveVdiskList($coPtr);

    $vdiskListPtr  = \@initialVdisks;

    if ( scalar(@initialVdisks) != 0 )
    {
        # we have some active vdisks
        if ( $initialVdisks[0] == INVALID )
        {
            # error case 
            logInfo(">>>>>>>> Warning - can't get an initial active vdisklist  <<<<<<<<");
            $vdiskListPtr  = 0;   # clear the point so we skip the following tests
        }
    }

    ############################################################################

    #
    # The loop that is really the test
    #

    for ( $i = 0; $i < $loop1; $i++ )
    {
        # find the master,
        logInfo("Searching for the master controller in the group");
        $initMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
        if ( $newMaster == INVALID )
        {
            logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
            return ERROR;
        }

        #
        # First we loop thru all the slaves and fail each one of them
        #

        for ( $j = 0; $j < $numCtlrs; $j++ )
        {
            # get slave SN
            $serial = TestLibs::IntegCCBELib::GetSerial( $coList[$j] );

         
            logInfo("Starting test for serial $serial......");
            
            ###################################################################
            #
            # Perform Bypass BE ports Test 
            #
            ###################################################################
            $ret = TestLibs::IntegCCBELib::BypassBEHubPorts($ipAddress, $resets, $delay, $hold, $driveBayPort, $seed, $password);
            if ( $ret == ERROR )
            {
                logError(">>>>>>>> Failed in bypass BE ports test <<<<<<<<\n");
                return (ERROR);
            }               
                
            ###################################################################
            #
            # Test the state of the system ( NO controllers should be failed )
            #
            ###################################################################
            $ret = TestLibs::Validate::TestSystemState(\@coList, \@activeServers, \@startingTmap, $vdiskListPtr, \@serialNums);
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> Controller state bad after slave tests  <<<<<<<<");
                return ERROR;
            }

            $testLoopCount++;

        }
            
        TestLibs::IntegCCBELib::DispVcgInfo($coList[$initMaster]); 
              

        logInfo("--------------------- Loop $i completed, $testLoopCount failovers completed. -------------------");
    }
    # end loop

    logInfo("End of No Fail Over Loop test completed.");
    return GOOD;

}


##############################################################################
#
#          Name: TestIPCEthernetFiberCom
#
#        Inputs: controller list pointer, Number of times to loop between 
#                controllers
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Randomly Disables/Enables the IPC connection
#
#          NOTE: THIS TEST REQUIRES SPECIAL CONFIGURATION WHICH IS A ETHERNET 
#                HUB BETWEEN THE TWO CONTROLLERS.  A LAN IS CONNECTED TO THE 
#                UPLINK PORT AND BOTH CONTROLLERS ARE CONNECTED RESPECTIVELY
#                THE HUB'S POWER IS CONNECTED TO A MOXA POWER SWITCH AND IS 
#                POWERCYCLED THROUGH THIS SCRIPT.
#
##############################################################################
sub TestIPCEthernetFiberCom
{
    trace();                        # This allows function tracability

    my ($coPtr, $resets, $ip, $chan, $delay, $hold, $loopCount, $newSeed) = @_;

    my $seed;           
    my $loop1;
    my $i;
    my $initMaster;
    my $initMasterSN;
    my $newMaster;
    my $serial;
    my $masterSN;
    my $numCtlrs;
    my $j;
    my $chn;
    my $ret;
    my $testLoopCount;
    my @serialNums;
    my $how2fail;
    
    my @startingTmap;
    my @initialVdisks;
    my %info1;
    my $vdiskListPtr;

    my @moxaMap;


    my @coList;
    @coList = @$coPtr;

    $numCtlrs = scalar( @coList );

    ##########################################################################

    #
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    #


    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #
    
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
    }


    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $newMaster == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
        return ERROR;
    }
    
    #
    # display some starting info
    #
    
    $ret = TestLibs::IntegCCBELib::DispPdiskInfo($coList[$newMaster]);

    if ( $ret == ERROR )
    {
        logError("Failed to get pdisk info at start");
        return ERROR;
    }

    $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$newMaster] );
    if ( $ret == ERROR )
    {
        logError("Failed to get target list at start");
        return ERROR;
    }

    $testLoopCount = 0;

    # Default to 2000 loops unless specified
    if (!$loopCount)
    {
        $loop1 = 2000;
    }
    else
    {
        $loop1 = $loopCount;
    }


    # Default to 1234 random genrator seed
    if (!$newSeed)
    {
        $seed = 1234;
    }
    else
    {
        $seed = $newSeed;
    }

    #
    # find the currently active servers
    #

    my @activeServers = TestLibs::Validate::ActiveServerList($coPtr);


    #
    # get the initial/starting target map
    #

    logInfo("Getting the target status, then building the target map");
    
#    %info1 = GetTargetStatus($coList[$newMaster]);
#
#    if ( ! %info1  )              # if no data from call
#    {
#        logInfo(">>>>>>>> Failed to get a response from GetTargetStatus <<<<<<<<");
#        return ERROR;
#    }
#
#    if ( $info1{STATUS} != PI_GOOD )      # if call returned an error
#    {
#        logInfo(">>>>>>>> Error from GetTargetStatus <<<<<<<<");
#        PrintError(%info1);
#        return ERROR;
#    }
#    
#    @startingTmap = CreateTargetMap(\@serialNums, %info1);
#    
#    PrintTargetMap (\@startingTmap);

    $ret = GroupTargetMap($coPtr, \@serialNums, \@startingTmap, $newMaster,  LOGTARGETMAP);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    @initialVdisks =  ActiveVdiskList($coPtr);

    $vdiskListPtr  = \@initialVdisks;

    if ( scalar(@initialVdisks) != 0 )
    {
        # we have some active vdisks
        if ( $initialVdisks[0] == INVALID )
        {
            # error case 
            logInfo(">>>>>>>> Warning - can't get an initial active vdisklist  <<<<<<<<");
            $vdiskListPtr  = 0;   # clear the point so we skip the following tests
        }
    }

    ############################################################################

    #
    # The loop that is really the test
    #

    for ( $i = 0; $i < $loop1; $i++ )
    {
        # find the master,
        logInfo("Searching for the master controller in the group");
        $initMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
        if ( $newMaster == INVALID )
        {
            logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
            return ERROR;
        }

        #
        # First we loop thru all the slaves and fail each one of them
        #

        for ( $j = 0; $j < $numCtlrs; $j++ )
        {
            # get slave SN
            $serial = TestLibs::IntegCCBELib::GetSerial( $coList[$j] );

         
            logInfo("Starting test for serial $serial......");
            
            ###################################################################
            #
            # Perform Bypass BE ports Test 
            #
            ###################################################################
            for(my $index = 0; $index < $resets; ++$index)
            {
                $ret = TestLibs::IntegCCBELib::HoldResetPower($ip, $chan, $delay, $hold);
                if ( $ret == ERROR )
                {
                    logError(">>>>>>>> Power Ethernet Hub test <<<<<<<<\n");
                    return (ERROR);
                }
            }


            ###################################################################
            #
            # Test the state of the system ( NO controllers should be failed )
            #
            ###################################################################
            $ret = TestLibs::Validate::TestSystemState(\@coList, \@activeServers, \@startingTmap, $vdiskListPtr, \@serialNums);
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> Controller state bad after slave tests  <<<<<<<<");
                return ERROR;
            }

            $testLoopCount++;

        }
            
        TestLibs::IntegCCBELib::DispVcgInfo($coList[$initMaster]); 
              

        logInfo("--------------------- Loop $i completed, $testLoopCount failovers completed. -------------------");
    }
    # end loop

    logInfo("End of No Fail Over Loop test completed.");
    return GOOD;

}


##############################################################################
#
#          Name: TestPowerDownDriveBays
#
#        Inputs: controller list pointer, number of on/off sequences, ip address
#                of the Moxa switch, channels of the drive bays, delay between an
#                on/off sequence, number of seconds to remove power, number of 
#                loop iterations, seed to randomly select a moxa channel.
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Randomly Disables/Enables the Drive Bays 
#
#          NOTE: THIS TEST REQUIRES SPECIAL CONFIGURATION WHICH IS THE DRIVE
#                BAYS CONNECTED TO A MOXA POWER SWITCH
#
##############################################################################
sub TestPowerDownDriveBays
{
    trace();                        # This allows function tracability

    my ($coPtr, $resets, $moxaIP, $moxaPtr, $delay, $hold, $loopCount, $newSeed) = @_;


    my $seed;           
    my $loop1;
    my $i;
    my $initMaster;
    my $initMasterSN;
    my $newMaster;
    my $serial;
    my $masterSN;
    my $numCtlrs;
    my $j;
    my $k;
    my $chn;
    my $ret;
    my $testLoopCount;
    my @serialNums;
    my $how2fail;
    my $lc;

    my $tempSerial;
    
    my @startingTmap;
    my @initialVdisks;
    my %info1;
    my $vdiskListPtr;

    my @moxaMap;


    my @coList;
    @coList = @$coPtr;

    $numCtlrs = scalar( @coList );

    ##########################################################################

    #
    # get startup info for the test. much of the data collected here is
    # used within the test loop
    #


    #
    # get a list of serial numbers to make the output a little 
    # more user friendly
    #
    
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        $serialNums[$i] = TestLibs::IntegCCBELib::GetSerial($coList[$i]);
    }


    $newMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
    if ( $newMaster == INVALID )
    {
        logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
        return ERROR;
    }
    
    #
    # display some starting info
    
    
    $ret = TestLibs::IntegCCBELib::DispPdiskInfo($coList[$newMaster]);

    if ( $ret == ERROR )
    {
        logError("Failed to get pdisk info at start");
        return ERROR;
    }

    $ret =  TestLibs::IntegCCBELib::TargetList( $coList[$newMaster] );
    if ( $ret == ERROR )
    {
        logError("Failed to get target list at start");
        return ERROR;
    }

    #$testLoopCount = 0;

    # Default to 2000 loops unless specified
    if (!$loopCount)
    {
        $loop1 = 2000;
    }
    else
    {
        $loop1 = $loopCount;
    }


    # Default to 1234 random genrator seed
    if (!$newSeed)
    {
        $seed = 1234;
    }
    else
    {
        $seed = $newSeed;
    }

    #
    # find the currently active servers
    #

    my @activeServers = TestLibs::Validate::ActiveServerList($coPtr);


    #
    # get the initial/starting target map
    

    logInfo("Getting the target status, then building the target map");
    
#    %info1 = GetTargetStatus($coList[$newMaster]);
#
#    if ( ! %info1  )              # if no data from call
#    {
#        logInfo(">>>>>>>> Failed to get a response from GetTargetStatus <<<<<<<<");
#        return ERROR;
#    }
#
#    if ( $info1{STATUS} != PI_GOOD )      # if call returned an error
#    {
#        logInfo(">>>>>>>> Error from GetTargetStatus <<<<<<<<");
#        PrintError(%info1);
#        return ERROR;
#    }
#    
#    @startingTmap = CreateTargetMap(\@serialNums, %info1);
#    
#    PrintTargetMap (\@startingTmap);

    $ret = GroupTargetMap($coPtr, \@serialNums, \@startingTmap, $newMaster,  LOGTARGETMAP);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    @initialVdisks =  ActiveVdiskList($coPtr);
    
    $vdiskListPtr  = \@initialVdisks;

    if ( scalar(@initialVdisks) != 0 )
    {
        # we have some active vdisks
        if ( $initialVdisks[0] == INVALID )
        {
            # error case 
            logInfo(">>>>>>>> Warning - can't get an initial active vdisklist  <<<<<<<<");
            $vdiskListPtr  = 0;   # clear the point so we skip the following tests
        }
    }

    ############################################################################

    #
    # The loop that is really the test
    #

    for ( $i = 0; $i < $loop1; $i++ )
    {
        # find the master,
        logInfo("Searching for the master controller in the group");
        $initMaster = TestLibs::IntegCCBELib::FindMaster( $coPtr );
        if ( $newMaster == INVALID )
        {
            logError(">>>>>>>> Failed to find the master controller <<<<<<<<");
            return ERROR;
        }

        #
        # First we loop thru all the slaves and fail each one of them
        #

        for ( $j = 0; $j < $numCtlrs; $j++ )
        {
            # get slave SN
            $serial = TestLibs::IntegCCBELib::GetSerial( $coList[$j] );

         
            logInfo("Starting test for serial $serial......");
            

            # check to see if none of the drives are degraded, if so, we can't
            # go on

            for ( $k = 0; $k < $numCtlrs; $k++ )
            {
                $tempSerial = TestLibs::IntegCCBELib::GetSerial( $coList[$k] );
                logInfo("Checking to make sure all drives are ready on controller $tempSerial");
                $ret = DegradeCheck( $coList[$k] );
                if ( ($ret == INVALID) || ($ret == ERROR) )
                {
                    logError(">>>>>>>> Not all drives were ready. Sorry, test exiting. <<<<<<<<");
                    return ERROR;
                }
            }

            ###################################################################
            #
            # Perform Bypass BE ports Test 
            #
            ###################################################################
            for(my $index = 0; $index < $resets; ++$index)
            {
                # Get channel randomly
                my $chan = @$moxaPtr[( (rand(scalar(@$moxaPtr))*1000) % scalar(@$moxaPtr) )] ;
                print "power cycle:  ip=$moxaIP, chan=$chan, delay=$delay, hold=$hold\n";
                $ret = TestLibs::IntegCCBELib::HoldResetPower($moxaIP, $chan, $delay, $hold);
                if ( $ret == ERROR )
                {
                    logError(">>>>>>>> Power Drive Bays test <<<<<<<<\n");
                    return (ERROR);
                }

                #############################
                # wait for rebuild to finish
                #############################
                # rebuild is done if no drives are 'degraded'
                
                for ( $k = 0; $k < $numCtlrs; $k++ )
                {
                   $tempSerial = TestLibs::IntegCCBELib::GetSerial( $coList[$k] );
                    logInfo("polling until rebuild finishes for controller $tempSerial");
                    $ret = INVALID;

                    $lc = 0; 
                    while ( $ret != GOOD )
                    {
                        $lc++;
                        logInfo(sprintf("Controller $tempSerial rebuild check loop iteration: %5d = ", $lc));

                        $ret = DegradeCheck( $coList[$k] );
                        if ( $ret == ERROR )
                        {
                            return ERROR;
                        }
                        DelaySecs( 15 );
                   }
                }
            }


            ###################################################################
            #
            # Test the state of the system ( NO controllers should be failed )
            #
            ###################################################################
            $ret = TestLibs::Validate::TestSystemState(\@coList, \@activeServers, \@startingTmap, $vdiskListPtr, \@serialNums);
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> Controller state bad after slave tests  <<<<<<<<");
                return ERROR;
            }

            $testLoopCount++;

        }
            
        TestLibs::IntegCCBELib::DispVcgInfo($coList[$initMaster]); 
              

        logInfo("--------------------- Loop $i completed, $testLoopCount failovers completed. -------------------");
    }
    # end loop

    logInfo("End of No Fail Over Loop test completed.");
    return GOOD;

    #my $ret = GOOD;

    #my ($coPtr, $resets, $ip, $chan, $delay, $hold, $loopCount, $newSeed) = @_;
    #print "TestPowerDownDriveBays\n";

    #print "Power Cycle Drive Bay";
    #$ret = HoldResetPower($moxaIP, "A", $delay, $hold);
    #$ret = HoldResetPower($moxaIP, "B", $delay, $hold);

    #return GOOD;
}

##############################################################################
#
#          Name: TestFailingDrives
#
#        Inputs: controller list object, loops, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Loop on the following,
#                   Fail a drive,
#                   Let rebuild finish
#                   Unfail the drive
#                   Make drive a hotspare
#                   Repeate for next used drive
#
##############################################################################
sub TestFailingDrives
{
    trace();                        # This allows function tracability

    my ($coPtr, $loops, $option, $newSeed) = @_;

    print "TestFailingDrives\n";
    return GOOD;
}


1;   # we need this for a PM

__END__

#################################################################

=head1 CHANGELOG

 $Log$
 Revision 1.3  2006/09/07 16:37:18  RustadM
 TBolt00000000 - Merge OPENISCSI649_BR branch to HEAD.

 Revision 1.2  2006/08/29 15:05:29  ElvesterN
 TBolt00015574 - Changed call to displayError to reference the full path.

 Revision 1.1.1.1.46.1  2006/09/05 18:16:20  RustadM
 TBolt00000000 - Update to F104 build.

 Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
 import CT1_BR to shared/Wookiee

 Revision 1.10  2003/03/26 21:24:53  WerningJ
 Removed calls to unused modules
 Reviewed by Craig M

 Revision 1.9  2003/01/29 16:29:26  WerningJ
 Changed array index sytax that is depreacted
 Reviewed by Craig M

 Revision 1.8  2003/01/07 22:27:50  MenningC
 Tbolt00000000: Many changes to handle the new content of targetstatus, reveiwed by Jeff Werning

 Revision 1.7  2002/09/16 12:49:59  ReiterR
 Checked in power cycle drive bya code

 Revision 1.6  2002/08/21 14:13:34  ReiterR
 Added New Functions

 Revision 1.5  2002/08/20 16:13:44  ThiemannE
 Integrated Tom Swansons test functions into the library.
 Reviewed by Craigm.

 Revision 1.4  2002/08/09 15:53:14  ReiterR
 Added TestIPCEthernetFiberCom function

 Revision 1.3  2002/08/08 00:06:31  ReiterR
 Removed some FAT

 Revision 1.2  2002/08/07 23:11:47  ReiterR
 Added TestQLogicResets, TestBypassBEVixelHubPorts test cases and supporting functions.

 Revision 1.1  2002/08/05 21:40:05  MenningC
 tbolt00000000 (NEW) FE fibre connection test  reviewed by Jeff Werning


=cut


