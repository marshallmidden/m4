#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library - BE robustness tests
#
#   112/26/2002  XIOtech   Craig Menning
#
#   A set of library functions for integration testing. This set support
#   testing of the controller's defrag function
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2002 XIOtech
#
#   For XIOtech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::BEStress - Perl Tests to test Back End rubustness

$Id: BEStress.pm 22486 2007-04-17 12:15:48Z gopinadh_anasuri $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL>
     <LI>Linux</LI>
     <LI>Windows</LI>
 </UL>

=end html

=head1 SYNOPSIS

This document covers the functions available for testing the robustness
of the BE design of the controller.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

            BEStressEntry()

        The less significant ones

              <none>

=cut


#
# - what I am
#

package TestLibs::BEStress;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

# get rid of this next one once a shell is written.
#use lib "../UMC/src/perl/scripting";
#use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;

use TestLibs::Logging;
use TestLibs::scrub;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::IntegCCBELib;
use TestLibs::FailOver;
use TestLibs::Validate;
use TestLibs::BEUtils;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - local Constants used
#



#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 22486 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &BEStressEntry



                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 22486 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.

 $moxaPtr: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.

 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller.

 $retIn: This is a controle variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the
          attached servers. When configuring systems, this list determines
          which WWNs will be associated with vdisks. If an entry in this
          list is not found on the system, it will be ignored. A WWN
          found on the system that is not included in the list will not
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this
        is the pointer to that controller object. It is one of the
        members of the list that $coPtr points to.




=back

=cut


###############################################################################


###############################################################################



###############################################################################

=head2 BETest2Way function

This is a dummy entry point for a series of BE stress tests.

DO not call/use this function, The primary purpose is for
documentation and development only.

Refer to the "BEStressCase##" functions for a description of the individual
tests. In general, the tests all have the same inputs. Those test that do
failover or failback have additional requirements related to the Moxa
power commander.


=cut

=over 1

=item Usage:

 my $rc = BETest2Way( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is the IP address of the moxa power controller
        $mmPtr is a the mapping of the moxa channels


=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 The InitialDefragConfig functions will create a suitable configuration. It
 is not necessary to 'clean up' between calls to this function.




=back

=cut




##############################################################################
#
#          Name: BETest2Way
#
#        Inputs: controller object, server wwn list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Starting with a system that has some vdisks and IO running,
#                ( IO is required for part of this ) DO a variety of things
#                and then start or force a rebuild.  There are several test cases
#                invoked by this test, Each test case is described below.
#
#
#
#
#
##############################################################################
sub BETest2Way
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my %info1;
    my @serialNums;
    my @startingTmap;
    my @pdiskData;
    my @vdiskData;
    my @raidData;
    my $vdiskListPtr;


    @serialNums = @$snPtr;

    $ret = GOOD;

    ######################################################################
    # Fail a pdisk while doing a redi copy operation.
    #
    # Steps are 1) pick an active vdisk
    #           2) get its size
    #           3) create a new one
    #           3) get baseline IO activity info
    #           4) start the redi CP
    #           5) fail a pdisk ( rebuilds should start )
    #           6) confirm IO still going
    #           7) wait for rebuilds to complete
    #           8) confirm IO still Ok
    #           9) confirm configuration
    #          10) restore the failed pdisk
    #          11) verify IO
    ######################################################################

    $ret = BETestCase1(  $coPtr, $ret, $snPtr  );


    ######################################################################
    # Fail a Pdisk while doing a defrag operation.
    #
    # Steps are 1) pick an active vdisk
    #           2) get its size
    #           3) create a new one
    #           4) get baseline IO activity info
    #           5) start the redi CP
    #           6) wait for redicp to complete
    #           7) confirm IO still going
    #           8) begin defrag
    #           9) confirm IO still Ok
    #          10) fail a pdisk
    #          11) confirm IO again
    #          12) wait for rebuilds to end
    #          13) confirm IO
    #          14) check SOS tables
    #          15) restart/re-run defrag
    #          16) wait for defrag to complete
    #          17) check sos tables
    #          18) confirm IO again
    #          19) restore the failed pdisk
    #          20) verify IO
    ######################################################################

    $ret = BETestCase2(  $coPtr, $ret, $snPtr   );




    ######################################################################
    # Fail a second pdisk on a not-degraded vdisk (if doing so will not cause
    # any vdisk to go offline.
    #
    # Steps are 1) identify two appropriate pdisks
    #           2) fail the first one
    #           3) wait for rebuilds to start
    #           4) verify IO
    #           5) fail the second vdisk
    #           6) wait for failure to be noticed
    #           7) verify IO
    #           8) wait for all rebuilds to end
    #           9) verify IO
    #          10) restore the failed pdisks
    #          11) verify IO
    #
    ######################################################################

    $ret = BETestCase3(  $coPtr, $ret, $snPtr    );



    ######################################################################
    # Move a target, fail a pdisk, move it back.   Observe rebuild.
    #
    # Steps are 1) identify a pdisk
    #           2) move a target from one controller to another
    #           3) fail a pdisk
    #           4) wait until rebuilds start
    #           5) verify IO
    #           6) move the target back
    #           7) wait for rebuilds to finish
    #           8) verify IO
    #           9) restore the failed pdisk
    #          10) verify IO
    ######################################################################

    $ret = BETestCase4(  $coPtr, $ret, $snPtr, $moxaIP, $mmPtr    );


    ######################################################################
    # Fail a pdisk, move a target, move it back.   Observe rebuild.
    #
    # Steps are 1) identify a pdisk
    #           2) fail the pdisk
    #           3) wait until rebuilds start
    #           4) verify IO
    #           5) move a target from one controller to another
    #           6) verify IO
    #           7) move the target back
    #           8) wait for rebuilds to finish
    #           9) verify IO
    #          10) restore the failed pdisk
    #          11) verify IO
    ######################################################################

    $ret = BETestCase5(  $coPtr, $ret, $snPtr, $moxaIP, $mmPtr    );



    ######################################################################
    # Repeatedly reset BE qlogic cards
    #
    # Steps are 1) select the controller
    #           2) for 'n' loops
    #                 sequentially reset each QL card
    #                 wait 10 secs between resets
    #           3) verify IO
    #           4) for 'n' loops
    #                 sequentially reset the QL cards
    #                 no wait between cards
    #                 wait 30 seconds after last card (between loops)
    #           5) verify IO
    #           6) for 'n' loops
    #                 reset all QL cards at once
    #                 wait 30 seconds between loops
    #                 verify IO each loop
    #           7) for 'n' loops
    #                 reset all QL cards 5 time
    #                 wait 30 seconds to recover at end
    #           8) verify IO
    #           9) repeat for the other controller(s)
    #          10) verify IO
    #
    ######################################################################

    $ret = BETestCase6(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # Repeatedly LIP the BE cards.
    #
    # Steps are 1) select the controller
    #           2) for 'n' loops
    #                 sequentially LIP each QL card
    #                 wait 10 secs between resets
    #           3) verify IO
    #           4) for 'n' loops
    #                 sequentially LIP the QL cards
    #                 no wait between cards
    #                 wait 30 seconds after last card (between loops)
    #           5) verify IO
    #           6) for 'n' loops
    #                 LIP all QL cards at once
    #                 wait 30 seconds between loops
    #                 verify IO each loop
    #           7) for 'n' loops
    #                 LIP all QL cards 5 time
    #                 wait 30 seconds to recover at end
    #           8) verify IO
    #           9) repeat for the other controller(s)
    #          10) verify IO
    #
    ######################################################################

    $ret = BETestCase7(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # Do a lot of rescans on the BE
    #
    # Steps are 1) pick a controller
    #           2) do 'n' rescans with 10 sec delay between them
    #           3) do 'n' rescans with no delay
    #           4) verify IO
    #           5) repeat for the other controllers
    #           6) alternate rescans among controllers, 10 sec delay
    #           7) alternate rescans among controllers, no delay
    #           8) verify IO
    ######################################################################

    $ret = BETestCase8(  $coPtr, $ret, $snPtr    );



    ######################################################################
    # repeatedly re-label the pdisks
    #
    # Steps are 1) for 'n' loops
    #                 re-label each drive with its current type
    #                 no delay between commands
    #           2) verify IO
    #           3) for 'n' loops
    #                 re-label the same drive, over and over
    #           4) verify IO
    #           5) fail a pdisk
    #           6) wait for rebuild to start
    #           7) verify IO
    #           8) for 'n' loops
    #                 re-label each drive with its current type
    #           9) for 'n' loops
    #                 relabel one drive over and over
    #                 ( drive is not one being rebuilt )
    #          10) for 'n' loops
    #                 re-label all drives with their current type
    #          11) verify IO
    #          12) wait for rebuild to end
    #          13) verify IO
    #          14) restore the failed pdisk
    #          15) verify IO
    #
    #
    ######################################################################

    $ret = BETestCase9(  $coPtr, $ret, $snPtr   );


    ######################################################################
    # repeatedly re-label the pdisks (part 2)
    #
    # Steps are 1) for 'n' loops
    #                 re-label each drive with its current type
    #                 no delay between commands
    #           2) verify IO
    #           3) create some vdisks
    #           4) start raid inits on them
    #           1) for 'n' loops
    #                 re-label each drive with its current type
    #                 no delay between commands
    #           4) verify IO
    #           3) for 'n' loops
    #                 re-label the same drive, over and over
    #           4) verify IO
    #           5) fail a pdisk
    #           6) wait for rebuild to start
    #           7) verify IO
    #           8) for 'n' loops
    #                 re-label each drive with its current type
    #           9) for 'n' loops
    #                 relabel one drive over and over
    #                 ( drive is not one being rebuilt )
    #          10) for 'n' loops
    #                 re-label all drives with their current type
    #          11) verify IO
    #          12) wait for rebuild to end
    #          12.5) wait for inits to end
    #          13) verify IO
    #          14) restore the failed pdisk
    #          15) verify IO
    #
    #
    ######################################################################

    $ret = BETestCase10(  $coPtr, $ret, $snPtr   );


    ######################################################################
    # repeatedly read different FIDs
    #
    # Steps are 1) read the fid directory
    #           2) read each fid in the directory
    #           3) repeat 2) 'n' times
    #           4) verify IO
    #
    ######################################################################

    $ret = BETestCase11(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # repeatedly do different loop primitives
    #
    # Steps are 1) determine valid loop primitives
    #           2) select a controller
    #           3) issue each of the loop primitives, randomly select the
    #              QL card that is used ( do this 'n' times)
    #           4) verify IO
    #           5) repeat 2-4 for the other controller(s)
    #
    ######################################################################

    $ret = BETestCase12(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # fail a disk during a scrub
    #
    # Steps are 1) verify IO
    #           2) enable/start scrubbing
    #           3) fail a pdisk
    #           4) verify IO
    #           5) check scrubbing state
    #           6) wait for rebuild to end
    #           7) verify IO
    #           8) check scrub state/ re-enable if needed
    #           9) wait for one pass to complete
    #          10) verify IO
    #          11) stop scrubbing
    #          12) restore the failed pdisk
    #          13) verify IO
    ######################################################################

    $ret = BETestCase13(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # Fail a pdisk while doing elections. This uses a data disk and
    # rebuilds are expected.
    #
    #
    # Steps:
    #    1) Wait until all disks are operational
    #    2) Do 10 elections, back to back
    #    3) Start Election, Fail the pdisk  ( a data one )
    #    4) Do more elections, repeat until 200 are done, or
    #       the rebuild has finished
    #    5) If needed wait for the rebuild to finish.
    #    6) Do 10 more elections
    #    7) Verify IO
    #    8) Restore the disk to operation
    #    9) Do 50 more elections
    #   10) Verify IO
    ######################################################################

    $ret = BETestCase14(  $coPtr, $ret, $snPtr   );


    ######################################################################
    # Fail a pdisk while doing elections. Uses a hotspare disk, rebuilds
    # not expected.
    #
    #
    # Steps:
    #    1) Wait until all disks are operational
    #    2) Do 10 elections, back to back
    #    3) Start election, Fail the pdisk  ( a hotspare one )
    #    4) Do more elections, repeat until 200 are done, or
    #       the rebuild has finished
    #    5) If needed wait for the rebuild to finish.
    #    6) Do 10 more elections
    #    7) Restore the disk
    #    8) Do 50 more elections
    #    9) Verify IO.
    ######################################################################

    $ret = BETestCase15(  $coPtr, $ret, $snPtr   );




    ######################################################################
    # Do multiple elections while a rebuild is running
    #
    # Steps:
    #    1) Wait until all disks are operational
    #    2) Fail a data disk so that a rebuild will start
    #    3) D0 200 elections or until rebuild finished
    #    4) If necessary, wait for the rebuild to finish.
    #    5) Restore the data disk
    #    6) Verify IO
    ######################################################################

    $ret = BETestCase16(  $coPtr, $ret, $snPtr   );


    ######################################################################
    # Do multiple elections while init is running
    #
    # Steps:
    #    1) Wait until all disks are operational
    #    2) Create and init a vdisk
    #    3) Do 200 elections or until init finished
    #    4) If necessary, wait for the init to finish.
    #    5) Verify IO
    #
    ######################################################################

    $ret = BETestCase17(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # With no hotspares, fail and unfail a 'parity' disk
    # when done put back the hoptspares
    #
    # Steps are 1) Identify the hotspares
    #           2) unlabel all hotspares
    #           3) verify IO
    #           4) fail a pdisk
    #           5) wait 20 seconds (for failure to be handled)
    #           6) verify IO
    #           7) wait for rebuild to end (should be immediate)
    #           8) restore the failed disk (this should start a rebuild)
    #           9) verify IO
    #          10) wait for rebuild to finish (should take a while)
    #          11) verify IO
    #          12) restore all the hotspares
    #          13) verify IO
    #          14) Make sure there is no rebuild running.
    #
    ######################################################################

    $ret = BETestCase18(  $coPtr, $ret, $snPtr   );




    ######################################################################
    # Fail a pdisk while doing a raid init on a single raid vdisk
    #
    # Steps are 1) Create a vdisk (single Raid)
    #           2) Start the raid init
    #           3) verify IO
    #           4) fail a pdisk (rebuild will start)
    #           5) wait for rebuilds to finish
    #           6) verify IO
    #           7) wait for init to finish
    #           8) verify IO
    #           9) delete the new vdisk
    #          10) verify IO
    #
    ######################################################################

    $ret = BETestCase19(  $coPtr, $ret, $snPtr   );




    ######################################################################
    # Fail a disk while doing raid inits on a multi raid vdisk
    #
    # Steps are 1) Create a vdisk (multiple Raid)
    #           2) Start the raid init
    #           3) verify IO
    #           4) fail a pdisk (rebuild will start)
    #           5) wait for rebuilds to finish
    #           6) verify IO
    #           7) wait for init to finish
    #           8) verify IO
    #           9) delete the new vdisk
    #          10) verify IO
    #
    ######################################################################

    $ret = BETestCase20(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # Power Cycle the slave controller repeatedly
    #
    # Steps are 1) Locate a slave controller
    #           2) verify IO
    #           3) turn off the controller
    #           4) failover timeline from master
    #           5) verify IO
    #           6) for 'n' loops
    #                 turn on slave controller
    #                 wait 2 minute (timeline?)
    #                 verify IO
    #                 turn off controller
    #                 wait 2 minutes (timeline?)
    #                 verify IO
    #           7) turn on controller
    #           8) reconnect and unfail
    #           9) timeline for 2 minutes
    #          10) verify IO
    #
    ######################################################################

    $ret = BETestCase21(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # Power Cycle the slave controller repeatedly while rebuild is running.
    #
    # Steps are 1) Locate a slave controller
    #           2) verify IO
    #           3) select a pdisk
    #           4) fail the pdisk
    #           5) confirm rebuild start
    #           6) turn off the slave controller
    #           7) failover timeline from master
    #           8) verify IO
    #           9) for 'n' loops
    #                 turn on slave controller
    #                 wait 2 minute (timeline?)
    #                 verify IO
    #                 turn off controller
    #                 wait 2 minutes (timeline?)
    #                 verify IO
    #          10) turn on controller
    #          11) reconnect and unfail
    #          12) timeline for 2 minutes
    #          13) verify IO
    #          14) wait for/verify rebuild is complete
    #          15) verify IO
    #
    ######################################################################

    $ret = BETestCase22(  $coPtr, $ret, $snPtr   );



    ######################################################################
    # Redi-copy and defrag while rebuilds are running.
    #
    # Steps are 1) Redi-copy a vdisk, wait for complete
    #           2) fail a pdisk - rebuilds start
    #           3) verify IO
    #           4) do another redi-copy, wait for complete
    #           5) verify IO
    #           6) delete first source vdisk
    #           7) start another redi-copy
    #           8) Begin defrags
    #           9) wait for copy complete
    #          10) verify IO
    #          11) wait for rebuild complete
    #          11.3) check SOS tables
    #          11.5) restart defrags
    #          12) verify IO
    #          13) wait for defrag complete
    #          14) check sos tables
    #          15) verify IO
    #
    #
    ######################################################################

    $ret = BETestCase23(  $coPtr, $ret, $snPtr   );


    ######################################################################
    # While doing a redi-cp, delete a vdisk that is being initialized.
    #
    # Steps are 0.5) delete unused vdisks
    #           1) Create a vdisk
    #           2) start a redi-copy operation
    #           3) start init of the new vdisk
    #           4) verify IO
    #           5) delete the new vdisk
    #           6) verify IO
    #           7) wait for redi-cp to end
    #           8) wait for init/ all disks operational
    #           9) verify IO
    #         9.5) delete unused vdisks
    #          10) check sos tables
    #          11) start defag
    #          12) verify IO
    #          13) wait for defrag complete
    #          13.5) unfail pdisk
    #          14) check sos tables
    #          15) verify IO
    #
    #
    ######################################################################

    $ret = BETestCase24(  $coPtr, $ret, $snPtr   );

    ######################################################################
    # While doing a redi-cp (mirror) delete the destination vdisk.
    #
    # Steps are 1) delete unused vdisks
    #           2) start a redi-copy operation
    #           3) wait a while
    #           4) verify IO
    #           5) delete the destination vdisk
    #           6) verify IO
    #           7) wait for redi-cp to end
    #           8) wait for init/ all disks operational
    #           9) verify IO
    #         9.5) delete unused vdisks
    #          10) check sos tables
    #          11) start defag
    #          12) verify IO
    #          13) wait for defrag complete
    #          14) check sos tables
    #          15) verify IO
    #
    #
    ######################################################################

    $ret = BETestCase25(  $coPtr, $ret, $snPtr   );

    ######################################################################
    # While doing a redi-cp and defrag, delete a vdisk that is being initialized.
    #
    # Steps are 0.5) redi-copy 2 vdisks
    #           0.7) delete unused vdisks
    #           1) Create a vdisk
    #           2) start a redi-copy operation
    #           3) start init of the new vdisk
    #           3.6) start a defrag
    #           4) verify IO
    #           5) delete the new vdisk
    #           6) verify IO
    #           7) wait for redi-cp to end
    #           8) wait for init/ all disks operational
    #           9) verify IO
    #         9.5) delete unused vdisks
    #          10) check sos tables
    #          11) start defag
    #          12) verify IO
    #          13) wait for defrag complete
    #          14) check sos tables
    #          15) verify IO
    #
    #
    ######################################################################

    $ret = BETestCase26(  $coPtr, $ret, $snPtr   );

    ######################################################################
    # Start a redi-cp operation TO a vdisk that is being initialized
    #
    # Steps are 1) houseclean
    #           2) create a rcp destination
    #           3) start inits on the vdisk
    #           4) begin a redicp TO the new vdisk
    #           5) wait for redi-cp to finish
    #          15) verify IO
    #
    #
    ######################################################################

    $ret = BETestCase27(  $coPtr, $ret, $snPtr   );

    ######################################################################
    # Start a redi-cp operation FROM a vdisk that is being initialized
    #
    # Steps are 1) houseclean
    #           2) create a vdisk
    #           3) create a another vdisk
    #           4) begin inits on both
    #           5) start a redi-cp from one to the other
    #           6) verify IO
    #           6.5) display vdisk status
    #           7) delete the source vdisk
    #           8) display vdisk status
    #           9) wait for redi-cp to finish
    #          10) wait for inits to end
    #          11) verify IO
    #          12) delete unused vdisks
    #
    #
    ######################################################################

    $ret = BETestCase28(  $coPtr, $ret, $snPtr   );

    ######################################################################
    # Start a redi-cp operation while drives are rebuilding
    #
    # Steps are 1) houseclean
    #           2) fail a pdisk
    #           3) wait for rebuild to start
    #           4) verify IO
    #           5) begin two redi-copy operations
    #           6) verify IO
    #           7) wait for redi-copy to end
    #           6) verify IO
    #           8) wait for rebuilds to end
    #           9) verify IO
    #
    #
    ######################################################################

    $ret = BETestCase29(  $coPtr, $ret, $snPtr   );

    ######################################################################
    # Start a redi-cp operation while another disk is being initialized
    #
    # Steps are 1) houseclean
    #           2) create a vdisk
    #           3) create a another vdisk
    #           4) begin inits on both
    #           6) verify IO
    #           5) start a redi copy to a third new vdisk
    #           9) wait for redi-cp to finish
    #          11) verify IO
    #          10) wait for inits to end
    #          11) verify IO
    #
    #
    ######################################################################

    $ret = BETestCase30(  $coPtr, $ret, $snPtr   );


    ######################################################################
    # Fail a pdisk repeatedly, waiting for the rebuilds to complete each
    # time.
    #
    # Steps are
    #           1) pick an active vdisk
    #           2) get its size
    #           3) create a new one
    #           4) get baseline IO activity info
    #           5) start the redi CP
    #           6) wait for redicp to complete
    #           7) confirm IO still going
    #           8) begin defrag
    #           9) confirm IO still Ok
    #          10) fail a pdisk
    #          11) confirm IO again
    #          12) wait for rebuilds to end
    #          13) confirm IO
    #          14) check SOS tables
    #          15) restart/re-run defrag
    #          16) wait for defrag to complete
    #          17) check sos tables
    #          18) confirm IO again
    #          19) restore the failed pdisk
    #          20) verify IO
    #
    #
    ######################################################################

    $ret = BETestCase30(  $coPtr, $ret, $snPtr   );




    return $ret;

}

##############################################################################
#
#               Private Functions, but made public for debug
#
##############################################################################

#############################################################################


###############################################################################

=head2 BEStressCase01 function

This test case fails a pdisk while redi copy is running. The test has these
basic steps...

     0) Houseclean system
     1) pick an active vdisk
     2) get its size
     3) create a new one
     4) get baseline IO activity info
     5) start the redi CP
     6) fail a pdisk ( rebuilds should start )
     7) confirm IO still going
     8) Wait for the copy to complete
     9) wait for rebuilds to complete
    10) confirm IO still Ok
    11) restore the failed pdisk
    12) verify IO
    13) check SOS tables

=cut

=over 1

=item Usage:

 my $rc = BEStressCase01( $coPtr, $retIn, $snPtr, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $pDFailMeans determines how the pdisk will be failed

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 1, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 51, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase01
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#
##############################################################################
sub BEStressCase01
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;
    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 1: Fail a pdisk during redi-copy  ---------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller   

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # With a redi-CP running, fail one of the data pdisks.
    ######################################################################

    # setup - need to houseclean

    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 1.");

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # copy it to the end
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    # pause for a minute or two, then fail the pdisk
    logInfo("A short delay to allow us to get well into the copy ");
    DelaySecs(30);

    logInfo("Going to fail a pdisk now");

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 1: now failing pdd $pdds[1]" );

    $failedDisk = $pdds[1];

    GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);


    $ret = FailPdisk( $coPtr, $failedDisk, $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin


    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # let copy complete (if it hasn't already finished)
    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }


    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );


    # verify IO
    logInfo("Confirm IO after copy and rebuilds are done");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # unfail the drive
    $ret = UnfailPdisk($coPtr, $failedDisk, $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # verify IO
    logInfo("Confirm IO after test is done and disk restored.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


#    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
 
    logInfo("End of BE stress test case 1.");


    return GOOD;

}

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

sub BEStressCase01B
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;
    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 1: Fail a pdisk during redi-copy  ---------------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }



    # get measure of the current IO


#    @vCounts = GetVdiskActivityCounts($coPtr);

#    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
#    DelaySecs(20);

#    @tMap = GetTargetMap( $coPtr, $snPtr );
#    if ( $tMap[0] == INVALID ) { return ERROR; }

    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }


    #
    # get the initial active vdisks for the test
    #


    logInfo("Generating Activity Information");

#    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
#    if (scalar(@activeServers) > 0 )
#    {
#        if ( $activeServers[0] == INVALID ) { return ERROR; }
#    }
#
#    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
#    if (scalar(@initialVdisks) > 0 )
#    {
#        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
#    }


    ######################################################################
    # With a redi-CP running, fail one of the data pdisks.
    ######################################################################

    # setup - need to houseclean

    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
#    $ret = DefragAll($ctlr);
#    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
#    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
#    $ret = VerifyIO( $coPtr,
#                     \@activeServers,
#                     \@tMap,
#                     \@initialVdisks,
#                     $snPtr
#                   );
#    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 1.");

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # copy it to the end
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    # pause for a minute or two, then fail the pdisk
    logInfo("A short delay to allow us to get well into the copy ");
    DelaySecs(30);

    logInfo("Going to fail a pdisk now");

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 1: now failing pdd $pdds[1]" );

    $failedDisk = $pdds[1];


    GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);


print "pdisk $failedDisk \n";
print "ses $ses \n";
print "slot $slot \n";
print "lid $lid \n";
print "port $port \n";


DelaySecs(60);


    $ret = FailPdisk( $coPtr, $failedDisk, $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin


    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
#    $ret = VerifyIO( $coPtr,
#                     \@activeServers,
#                     \@tMap,
#                     \@initialVdisks,
#                     $snPtr
#                   );
#    if ( $ret != GOOD ) { return ERROR; }


    # let copy complete (if it hasn't already finished)
    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }


    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );


    # verify IO
    logInfo("Confirm IO after copy and rebuilds are done");
#    $ret = VerifyIO( $coPtr,
#                     \@activeServers,
#                     \@tMap,
#                     \@initialVdisks,
#                     $snPtr
#                   );
#
#    if ( $ret != GOOD ) { return ERROR; }



    # confirm the configuration

    # ???

    # unfail the drive
    $ret = UnfailPdisk($coPtr, $failedDisk, $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    # verify IO
    logInfo("Confirm IO after test is done and disk restored.");
#    $ret = VerifyIO( $coPtr,
#                     \@activeServers,
#                     \@tMap,
#                     \@initialVdisks,
#                     $snPtr
#                   );
#    if ( $ret != GOOD ) { return ERROR; }


#    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
#    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 1.");


    return GOOD;

}

###############################################################################

=head2 BEStressCase02 function

This test case begins a defrag operation and then fails a pdisk. Here are
test steps.

     0) Houseclean the system
     1) pick an active vdisk
     2) get its size
     3) create a new one
     4) get baseline IO activity info
     5) start the redi CP
     6) wait for redicp to complete
     7) confirm IO still going
     8) begin defrag
     9) confirm IO still Ok
    10) fail a pdisk
    11) confirm IO again
    12) wait for rebuilds to end
    13) confirm IO
    14) check SOS tables
    15) restart/re-run defrag
    16) wait for defrag to complete
    17) check sos tables
    18) confirm IO again
    19) restore the failed pdisk
    20) verify IO
    21) check the SOS tables

=cut

=over 1

=item Usage:

 my $rc = BEStressCase02( $coPtr, $retIn, $snPtr, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $pDFailMeans determines how the pdisk will be failed


=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 2, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 52, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase02
#
#        Inputs: $coPtr, $retIn, $snPtr , $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
##############################################################################
sub BEStressCase02
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlr;

    my @oldVds;
    my $newVd;
    my $ret;
    my $lc;
    my @pdds;
    my %rsp;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 2: fail a pdisk while defrag is running  -----------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # With a defrag running, rediCP one of the first vdisks to a new one.
    # then delete the old one and start another defrag.
    ######################################################################

    # setup - need to get a defrag running

    # get rid of any unused vdisks ( any that
    # were existing )
    DeleteUnusedVdisks( $ctlr, 0);

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # copy it to the end
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    logInfo("IO check before beginning defrag");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # delete the source ( the early vdisk )
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) )
    {
        return ERROR;
    }


    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }


    CtlrLogTextAll($coPtr, "Test Case 2: begin defrag and then fail a pdisk" );


    # start the defrag
  #  $ret = DefragBegin($ctlr);
  #  if ( $ret != GOOD ) { return ERROR; }
  #
  #  DelaySecs(120);
  #
  #  # verify IO is still good
  #  logInfo("IO check after beginning defrag");
  #  $ret = VerifyIO( $coPtr,
  #                   \@activeServers,
  #                   \@tMap,
  #                   \@initialVdisks,
  #                   $snPtr
  #                 );
  #  if ( $ret != GOOD ) { return ERROR; }

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 2: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);


    $ret = FailPdisk( $coPtr, $pdds[1], $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin


    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }





    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );


    # any rebuild stops a defrag, so there is no point in waiting for
    # defrags to end (note, some defrags may continue if they don't
    # crash into the rebuild)

    # wait for defrag to complete, check
    #$ret = DefragWait( $ctlr );
    #if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    logInfo("Verify IO with after rebuilds/defrags end.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    logInfo("We are probably fragmented, but that is not guaranteed here.");

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }


    # start the defrag - This will restart any that stopped and help to
    # clean up the system
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    logInfo("Verify IO with after 2nd defrag ends.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    #
    # note: there may be a hotspare and rebuild done here if the failed drive
    # had been hotspared. So we should wait for that rebuild to finish before
    # fixing the pdisk labels.
    #

    logInfo("checking for a rebuild and polling until it finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }




    # verify IO
    logInfo("Confirm IO after test is done and disk restored.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


#    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 2.");


    return GOOD;

}
###############################################################################

###############################################################################

=head2 BEStressCase04 function            (NO LONGER SUPPORTED)

This test is obsolete as it uses the move targt command which is
no longer supported.


This test case moves a target, fails a pdisk, then moves the target back.
The test has these
basic steps...

     1) identify a pdisk
     2) move a target from one controller to another
     3) fail a pdisk
     4) wait until rebuilds start
     5) verify IO
     6) move the target back
     7) wait for rebuilds to finish
     8) verify IO
     9) restore the failed pdisk
    10) verify IO


This test requires multiple controllers


=cut

=over 1

=item Usage:

 my $rc = BEStressCase04( $coPtr, $retIn, $snPtr, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers


=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 4, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 54, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase04
#
#        Inputs: $coPtr, $retIn, $snPtr , $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub BEStressCase04
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @snList;

    my @oldVds;
    my $index;
    my $targ;
    my $index2;
    my @pdds;
    my $lc;
    my %rsp;
    my $ses;
    my $slot;
    my $ret;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 4: Move a target, fail a pdisk, move it back.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    @snList = @$snPtr;

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     

    ######################################################################
    # Move a target, fail a pdisk, move it back.
    ######################################################################

    # setup - need to houseclean
    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);


    # identify the target to be moved
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # find owner of the  disk

    ($index, $targ) = FindVdiskOwner($coPtr, $snPtr, $oldVds[0]);
    if ( $index == INVALID ) { return ERROR; }
    if ( $targ == INVALID ) { return ERROR; }


    # move the target to another controller

    $index2 = 0;
    if ( $index == 0 ) { $index2 = 1; }

    $ret = MoveTarget($ctlr, $snList[$index2], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    DelaySecs(40);


    # now fail the pdisk

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 4: now failing pdd $pdds[1]" );

    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin



    # verify IO is still good
    logInfo("Verify IO with the failed PDD and moved target");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     0,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # move the target back

    $ret = MoveTarget($ctlr, $snList[$index], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    # probably need a delay here.
    DelaySecs(40);

    $ret = RescanBE( $ctlr);
    if ( $ret == ERROR )
    {
        return ERROR;
    }


    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );



    # verify IO is still good
    logInfo("Verify IO with after rebuilds/defrags (target position restored) end.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }


    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }



    # verify IO
    logInfo("Confirm IO after test is done and disk restored.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
#    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 4.");


    return GOOD;

}

###############################################################################
###############################################################################

=head2 BEStressCase05 function

This test case fails a pdisk, moves atarget, then moves the target back.

This test is obsolete as it uses the moveTarget command which
is no longer supported.


The test has these
basic steps...

     0) Houseclean system
     1) identify a pdisk
     2) fail the pdisk
     3) wait until rebuilds start
     4) verify IO
     5) move a target from one controller to another
     6) verify IO
     7) move the target back
     8) wait for rebuilds to finish
     9) verify IO
    10) restore the failed pdisk
    11) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase05( $coPtr, $retIn, $snPtr, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers


=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 5, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 55, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase05
#
#        Inputs: $coPtr, $retIn, $snPtr, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub BEStressCase05
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $ret;
    my @pdds;
    my @oldVds;
    my $index;
    my $targ;
    my $index2;
    my @snList;
    my $lc;
    my %rsp;
    my $failedDisk;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 5: Fail a pdisk, move a target, move it back.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # fail a pdisk, Move a target, move it back.
    ######################################################################

    @snList = @$snPtr;

    # setup - need to houseclean
    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # now fail the pdisk

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 5: now failing pdd $pdds[1]" );

    $failedDisk = $pdds[1];

    GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $failedDisk , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin



    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # identify the target to be moved
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # find owner of the  disk

    ($index, $targ) = FindVdiskOwner($coPtr, $snPtr, $oldVds[0]);
    if ( $index == INVALID ) { return ERROR; }
    if ( $targ == INVALID ) { return ERROR; }


    # move the target to another controller

    $index2 = 0;
    if ( $index == 0 ) { $index2 = 1; }

    $ret = MoveTarget($ctlr, $snList[$index2], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    DelaySecs(40);

    # verify IO is still good
    logInfo("Verify IO with the failed PDD and moved target");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     0,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # move the target back

    $ret = MoveTarget($ctlr, $snList[$index], $targ);
    if ( $ret != GOOD ) { return ERROR; }

    # probably need a delay here.
    DelaySecs(40);

    $ret = RescanBE( $ctlr);
    if ( $ret == ERROR )
    {
        return ERROR;
    }


    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );



    # verify IO is still good
    logInfo("Verify IO with after rebuilds/defrags end.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }


    # unfail the drive
    $ret = UnfailPdisk($coPtr, $failedDisk, $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }




    # verify IO
    logInfo("Confirm IO after test is done and disk restored.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
#    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 5.");


    return GOOD;

}

###############################################################################
###############################################################################

=head2 BEStressCase06 function

This test case repeatedly resets the BE qlogic cards.
The test has these
basic steps...

     0) Houseclean system
     1) select the controller
        2) for 'n' loops
              sequentially reset each QL card
              wait 10 secs between resets
        3) verify IO
        4) for 'n' loops
              sequentially reset the QL cards
              no wait between cards
              wait 30 seconds after last card (between loops)
        5) verify IO
        6) for 'n' loops
              reset all QL cards at once
              wait 30 seconds between loops
              verify IO each loop
        7) for 'n' loops
              reset all QL cards 5 time
              wait 30 seconds to recover at end
        8) verify IO
     9) repeat for the other controller(s)
    10) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase06( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase06
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub BEStressCase06
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;

    my $i;
    my $j;
    my $k;
    my $l;
    my $ret;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 6: Lots of resets on the BE Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     

    ######################################################################
    # several loops to reset cards
    ######################################################################



    # Steps are 1) select the controller
    for ( $i = 0; $i < scalar(@$coPtr); $i++ )
    {

        $ctlr = $coList[$i];

        #           2) for 'n' loops
        for ( $j = 0; $j < $loopCount; $j++ )
        {

            print("                                          reset # $j, with delay, launched. \r");

            #   sequentially reset each QL card
            for ( $k = 0; $k < 4; $k++ )
            {
                $ret = QLReset( $ctlr, "BE", $k, RESET_QLOGIC_RESET_INITIALIZE );
                if ( $ret != GOOD )
                {
                    logInfo ("Occasional Time Limit exceeded messages are acceptable.")
                }
                # wait 10 secs between resets
                DelaySecs(10);
            }

        }

        #  3) verify IO is still good

        logInfo("Verify IO after $loopCount loops sequentially resetting the BE QLogic cards");
        $ret = VerifyIO( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }



        #  4) for 'n' loops
        for ( $j = 0; $j < $loopCount; $j++ )
        {

            print("                                          reset # $j, with delay after last one, launched. \r");
            #   sequentially reset each QL card
            for ( $k = 0; $k < 4; $k++ )
            {
                $ret = QLReset( $ctlr, "BE", $k, RESET_QLOGIC_RESET_INITIALIZE );
                if ( $ret != GOOD )
                {
                    logInfo ("Occasional Time Limit exceeded messages are acceptable.")
                }
                
                # no wait between cards
            }

            # wait 30 seconds after last card (between loops)
            DelaySecs(30);

        }

        #  5) verify IO is still good

        logInfo("Verify IO after $loopCount loops sequentially resetting the BE QLogic cards");
        $ret = VerifyIO( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }


        #  6) for 'n' loops
        for ( $j = 0; $j < $loopCount; $j++ )
        {
            logInfo("Reset loop # $j, with delay after last one. \r");

            #   sequentially reset each QL card
            for ( $k = 0; $k < 4; $k++ )
            {
                $ret = QLReset( $ctlr, "BE", $k, RESET_QLOGIC_RESET_INITIALIZE );
                if ( $ret != GOOD )
                {
                    logInfo ("Occasional Time Limit exceeded messages are acceptable.")
                }
                
                
                # no wait between cards
            }

            # wait 30 seconds after last card (between loops)
            DelaySecs(30);

            # verify IO each loop
            logInfo("Verify IO after $j loops sequentially resetting the BE QLogic cards");
            $ret = VerifyIO( $coPtr,
                             \@activeServers,
                             \@tMap,
                             \@initialVdisks,
                             $snPtr
                           );
            if ( $ret != GOOD ) { return ERROR; }

        }


        #  7) for 'n' loops
        for ( $j = 0; $j < $loopCount; $j++ )
        {
            print("                                          multiple resets loop # $j, with delay after last one, launched. \r");

            #   sequentially reset each QL card
            for ( $k = 0; $k < 4; $k++ )
            {
                for ( $l = 0; $l < 5; $l++ )
                {
                    $ret = QLReset( $ctlr, "BE", $k, RESET_QLOGIC_RESET_INITIALIZE );
                    if ( $ret != GOOD )
                    {
                        logInfo ("Occasional Time Limit exceeded messages are acceptable.")
                    }
                    
                }

                # no wait between cards
            }

            # wait 30 seconds after last card (between loops)
            DelaySecs(30);

        }

        #  8) verify IO is still good

        logInfo("Verify IO after $loopCount loops sequentially resetting the BE QLogic cards");
        $ret = VerifyIO( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }




    }



    # verify IO is still good
    logInfo("Verify IO at end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 6.");


    return GOOD;

}

###############################################################################
###############################################################################

=head2 BEStressCase07 function

This test case repeatedly LIPs the BE qlogic cards.
The test has these
basic steps...

     0) Houseclean system
     1) select the controller
        2) for 'n' loops
              sequentially reset each QL card
              wait 15 secs between resets
        3) verify IO

           steps 4-6 are not done
                    4) for 'n' loops
                          sequentially reset the QL cards
                          no wait between cards
                          wait 30 seconds after last card (between loops)
                    5) verify IO
                    6) for 'n' loops
                          reset all QL cards at once
                          wait 30 seconds between loops
                          verify IO each loop
        7) verify IO
     8) repeat for the other controller(s)
     9) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase07( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase07
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#
##############################################################################
sub BEStressCase07
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;


    my $i;
    my $j;
    my $k;
    my $l;
    my $ret;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 7: Lots of LIPs on the BE Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # loops to LIP the BE cards.
    ######################################################################

    # Steps are 1) select the controller
    for ( $i = 0; $i < scalar(@$coPtr); $i++ )
    {

        $ctlr = $coList[$i];

        #           2) for 'n' loops

        logInfo("(2) Begin loop to LIP each card with 15 second delay");

        for ( $j = 0; $j < $loopCount; $j++ )
        {



            #   sequentially LIP each QL card
            for ( $k = 0; $k < 4; $k++ )
            {

                $ret = ResetBELoop ($ctlr, $k );


                if ( $ret == ERROR )
                {
                    print ("\n");
                    logInfo("Error from ResetBELoop. Card = $k.");
                    return ERROR;
                }

                print("                                          LIP # $j, with delay, launched. \r");



                # wait 10 secs between LIPs
                if ( $ret != INVALID )
                {
                    DelaySecs(15);
                }
            }

        }

        print "\n";

        #  3) verify IO is still good

        logInfo("(3) Verify IO after $loopCount loops sequentially LIPping the BE QLogic cards");
        $ret = VerifyIO( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }
#
#
#
#        #  4) for 'n' loops
#
#        logInfo("(4) Begin loop to LIP each card multiple times with 30 second delay between loops.");
#
#        for ( $j = 0; $j < $loopCount; $j++ )
#        {
#
#            #   sequentially LIP each QL card
#            for ( $k = 0; $k < 4; $k++ )
#            {
#
#                print("                                          Loop # $j, card $k, no delay. \r");
#
#                $ret = ResetBELoop ($ctlr, $k );
#
#                if ( $ret != GOOD ) { return ERROR; }
#                # no wait between cards
#            }
#
#            # wait 30 seconds after last card (between loops)
#            DelaySecs(30);
#
#        }
#
#        print "\n";
#
#        #  5) verify IO is still good
#
#        logInfo("(5) Verify IO after $loopCount loops sequentially LIPping the BE QLogic cards");
#        $ret = VerifyIO( $coPtr,
#                         \@activeServers,
#                         \@tMap,
#                         \@initialVdisks,
#                         $snPtr
#                       );
#        if ( $ret != GOOD ) { return ERROR; }
#
#
#        #  6) for 'n' loops
#        # can't do this one as the QL cards can't keep up with the rate of resets.
#
#        logInfo("(6) Begin loop to LIP each card multiple times with 30 second delay after last card only");
#
#        for ( $j = 0; $j < $loopCount; $j++ )
#        {
#
#            #   sequentially LIP each QL card
#            for ( $k = 0; $k < 4; $k++ )
#            {
#
#                print "card $k \n";
#
#                $ret = ResetBELoop ($ctlr, $k );
#
#                if ( $ret != GOOD ) { return ERROR; }
#                print("                                          LIP # $j, no delay, launched. \r");
#                # no wait between cards
#            }
#
#            print "\n";
#
#
#            # wait 30 seconds after last card (between loops)
#            DelaySecs(30);
#
#            # verify IO each loop
#
#            logInfo("Verify IO after $j loops sequentially LIPping the BE QLogic cards");
#            $ret = VerifyIO( $coPtr,
#                             \@activeServers,
#                             \@tMap,
#                             \@initialVdisks,
#                             $snPtr
#                           );
#            if ( $ret != GOOD ) { return ERROR; }
#        }



#        #  7) for 'n' loops
#        # can't do this one as the QL cards can't keep up with the rate of resets.
#
#        logInfo("(7) Begin loop to LIP each card multiple times. Two second delay between cards, delay after last card.");
#
#        for ( $j = 0; $j < $loopCount; $j++ )
#        {
#
#            #   sequentially LIP each QL card
#            for ( $k = 0; $k < 4; $k++ )
#            {
#
#                print("                                          Loop # $j, card $k, 2 sec. delay, begin. \r");
#
#
#                for ( $l = 0; $l < 5; $l++ )
#                {
#                    sleep 2;
#                            # print "card $k, loop $l\n";
#
#                    $ret = ResetBELoop ($ctlr, $k );
#
#                    if ( $ret != GOOD ) { return ERROR; }
#                }
#
#                # no wait between cards
#            }
#
#            # wait 30 seconds after last card (between loops)
#            DelaySecs(30);
#
#        }
#
#        print "\n";
#

        #  8) verify IO is still good

        logInfo("(8) Verify IO after $loopCount loops sequentially LIPping the BE QLogic cards");
        $ret = VerifyIO( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }




    }



    # verify IO is still good
    logInfo("Verify IO at end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 7.");


    return GOOD;

}
###############################################################################

=head2 BEStressCase08 function

This test case repeatedly rescans the BE qlogic cards.
The test has these
basic steps...


     1) pick a controller
     2) do 'n' rescans with 10 sec delay between them
     3) do 'n' rescans with no delay
     4) verify IO
     5) repeat for the other controllers
     6) alternate rescans among controllers, 10 sec delay
     7) alternate rescans among controllers, no delay
     8) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase08( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase08
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
##############################################################################
sub BEStressCase08
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;


    my $i;
    my $j;
    my $ret;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 8: Lots of rescans on the BE Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # loop to do rescans
    ######################################################################

    # Steps are 1) select the controller
    for ( $i = 0; $i < scalar(@$coPtr); $i++ )
    {

        $ctlr = $coList[$i];

        #           2) do 'n' rescans with 10 sec delay between them

        logInfo("Begin loop to rescan , 10 second delay between rescans.");

        for ( $j = 0; $j < $loopCount; $j++ )
        {


            $ret = RescanBE($ctlr);
            if ( $ret != GOOD ) { return ERROR; }
            print("                                          Rescan # $j,  with delay, launched. \r");
            DelaySecs(10);
        }


        #           3) do 'n' rescans with no delay

        logInfo("Begin loop to rescan , no delay between rescans.");

        for ( $j = 0; $j < $loopCount; $j++ )
        {


            $ret = RescanBE($ctlr);
            if ( $ret != GOOD ) { return ERROR; }
            print("                                          Rescan # $j, no delay, launched. \r");

            #DelaySecs(10);
        }
    }



    #           4) verify IO
    logInfo("Verify IO after several rescans on each controller");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    #           6) alternate rescans among controllers, 10 sec delay

    logInfo("Begin loop to alternate rescans between controllers, 10 second delay between rescans.");

    for ( $j = 0; $j < $loopCount; $j++ )
    {


        # Steps are 1) select the controller
        for ( $i = 0; $i < scalar(@$coPtr); $i++ )
        {

            $ctlr = $coList[$i];

            $ret = RescanBE($ctlr);
            if ( $ret != GOOD ) { return ERROR; }
            print("                                          Rescan # $j, with delay, launched. \r");

            DelaySecs(10);
        }
    }

    #           4) verify IO
    logInfo("Verify IO after several rescans on among controllers with delay");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           7) alternate rescans among controllers, no delay

    logInfo("Begin loop to alternate rescans between controllers, no delay between rescans.");

    for ( $j = 0; $j < $loopCount; $j++ )
    {

        # Steps are 1) select the controller
        for ( $i = 0; $i < scalar(@$coPtr); $i++ )
        {

            $ctlr = $coList[$i];

            $ret = RescanBE($ctlr);
            if ( $ret != GOOD ) { return ERROR; }
            print("                                          Rescan # $j, no delay, launched. \r");

            #DelaySecs(10);
        }
    }

    #           4) verify IO
    logInfo("Verify IO after several rescans on among controllers with delay");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 8.");


    return GOOD;

}

###############################################################################

=head2 BEStressCase09 function

This test case repeatedly relabels pdisks. A pdisk is failed and
rebuilt to stress the system.
The test has these
basic steps...

 Steps are 1) for 'n' loops
                 re-label each drive with its current type
                 no delay between commands
           2) verify IO
           3) for 'n' loops
                 re-label the same drive, over and over
           4) verify IO
           5) fail a pdisk
           6) wait for rebuild to start
           7) verify IO
           8) for 'n' loops
                 re-label each drive with its current type
           9) for 'n' loops
                 relabel one drive over and over
                 ( drive is not one being rebuilt )
          10) for 'n' loops
                 re-label all drives with their current type
          11) verify IO
          12) wait for rebuild to end
          13) verify IO
          14) restore the failed pdisk
          15) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase09( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 9, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 59, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase09
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                LIPs the BE loops
#
# Steps are 1) for 'n' loops
#                 re-label each drive with its current type
#                 no delay between commands
#           2) verify IO
#           3) for 'n' loops
#                 re-label the same drive, over and over
#           4) verify IO
#           5) fail a pdisk
#           6) wait for rebuild to start
#           7) verify IO
#           8) for 'n' loops
#                 re-label each drive with its current type
#           9) for 'n' loops
#                 relabel one drive over and over
#                 ( drive is not one being rebuilt )
#          10) for 'n' loops
#                 re-label all drives with their current type
#          11) verify IO
#          12) wait for rebuild to end
#          13) verify IO
#          14) restore the failed pdisk
#          15) verify IO
#
#
##############################################################################
sub BEStressCase09
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;


    my @pdds;
    my @allPdds;
    my $i;
    my $j;
    my $type;
    my $ret;
    my %rsp;
    my $lc;
    my $total;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 9: Re-label drives repeatedly, fail a drive.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # loops to relabel drives.
    ######################################################################


    # we are going to re-label these
    @allPdds = GetPddList( $ctlr );
    if ( $allPdds[0] == INVALID) { return ERROR; }

    # we will fail the 2nd one of these
    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }



    logInfo("Begin 1st loop to relabel ".scalar(@allPdds)."  drives $loopCount times.");
    CtlrLogTextAll($coPtr, "Test Case 9: Begin 1st loop to relabel ".scalar(@allPdds)."  drives $loopCount times." );

    # loop to relabel all drives without delay
    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");
        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {

            # get the current label
            $type = GetDriveLabel( $ctlr, $allPdds[$i] );
            if ( $type == INVALID )
            {
                return ERROR;
            }

            # re-apply that label to the same drive
            $ret = ReLabelSingleDrive ( $ctlr, $allPdds[$i], $type );
            if ( $ret != GOOD ) { return ERROR; }
        }
    }

    logInfo("End loop to relabel ".scalar(@allPdds)." drives $loopCount times.");

    #           4) verify IO
    logInfo("Verify IO after several rescans on among controllers with delay");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # now fail a pdisk
    CtlrLogTextAll($coPtr, "Test Case 9: now failing pdd $pdds[1]" );

    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);


    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin



    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # loop to relabel all drives without delay

    $total = scalar(@allPdds) - 1;

    logInfo("Begin 2nd loop to relabel $total drives $loopCount times.");

    CtlrLogTextAll($coPtr, "Test Case 9: Begin 2nd loop to relabel $total drives $loopCount times" );

    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");
        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {
            # probably need to make sure we don't use the dead drive

            if ( $allPdds[$i] !=  $pdds[1] )
            {
                # get the current label
                $type = GetDriveLabel( $ctlr, $allPdds[$i] );
                if ( $type == INVALID )
                {
                    return ERROR;
                }

                # re-apply that label to the same drive
                $ret = ReLabelSingleDrive ( $ctlr, $allPdds[$i], $type );
                if ( $ret != GOOD ) { return ERROR; }

            }
        }
    }

    logInfo("END loop to relabel $total drives $loopCount times.");


    $total = $loopCount * scalar(@allPdds) ;

    logInfo("Begin 3rd loop to relabel drive $pdds[2] $total times.");
    CtlrLogTextAll($coPtr, "Test Case 9: Begin 3rd loop to relabel drive $pdds[2] $total times" );

    # loop to relabel the same drive without delay
    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");
        # this loop just increases the number of commands sent
        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {

            # get the current label
            $type = GetDriveLabel( $ctlr, $pdds[2] );
            if ( $type == INVALID )
            {
                return ERROR;
            }

            # re-apply that label to the same drive
            $ret = ReLabelSingleDrive ( $ctlr, $pdds[2], $type );
            if ( $ret != GOOD ) { return ERROR; }
        }
    }

    logInfo("End loop to relabel drive $pdds[2] $total times.");

    # make sure IO is still good
    logInfo("Verify IO after several rescans on among controllers with delay");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );


    # make sure IO is still good

    CtlrLogTextAll($coPtr, "Test Case 9: Verify IO after rebuild has completed");

    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # unfail the drive
    CtlrLogTextAll($coPtr, "Test Case 9: Unfailing pdisk $pdds[1]");
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }




    # verify IO
    CtlrLogTextAll($coPtr, "Confirm IO after test is done and disk restored.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
#    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 9.");


    return GOOD;

}
###############################################################################

=head2 BEStressCase10 function

This test case repeatedly labels drives while running raid inits and
failing a pdisk.

The test has these
basic steps...

 Steps are 1) for 'n' loops
                 re-label each drive with its current type
                 no delay between commands
           2) verify IO
           3) create some vdisks
           4) start raid inits on them
           1) for 'n' loops
                 re-label each drive with its current type
                 no delay between commands
           4) verify IO
           3) for 'n' loops
                 re-label the same drive, over and over
           4) verify IO
           5) fail a pdisk
           6) wait for rebuild to start
           7) verify IO
           8) for 'n' loops
                 re-label each drive with its current type
           9) for 'n' loops
                 relabel one drive over and over
                 ( drive is not one being rebuilt )
          10) for 'n' loops
                 re-label all drives with their current type
          11) verify IO
          12) wait for rebuild to end
          13) verify IO
          14) restore the failed pdisk
          15) verify IO





=cut

=over 1

=item Usage:

 my $rc = BEStressCase10( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 10, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 60, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase10
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                Relabel drives while doing inits
#
# Steps are 1) for 'n' loops
#                 re-label each drive with its current type
#                 no delay between commands
#           2) verify IO
#           3) create some vdisks
#           4) start raid inits on them
#           1) for 'n' loops
#                 re-label each drive with its current type
#                 no delay between commands
#           4) verify IO
#           3) for 'n' loops
#                 re-label the same drive, over and over
#           4) verify IO
#           5) fail a pdisk
#           6) wait for rebuild to start
#           7) verify IO
#           8) for 'n' loops
#                 re-label each drive with its current type
#           9) for 'n' loops
#                 relabel one drive over and over
#                 ( drive is not one being rebuilt )
#          10) for 'n' loops
#                 re-label all drives with their current type
#          11) verify IO
#          12) wait for rebuild to end
#          13) verify IO
#          14) restore the failed pdisk
#          15) verify IO
#
##############################################################################
sub BEStressCase10
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @pdds;
    my @allPdds;
    my $i;
    my $j;
    my $type;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my $lc;
    my %rsp;
    my $total;
    my $ses;
    my $slot;
    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 10: Re-label pdisks while doing init and fail pdisk.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     
 

    ######################################################################
    # loops to label drives
    ######################################################################


    # we are going to re-label these
    @allPdds = GetPddList( $ctlr );
    if ( $allPdds[0] == INVALID) { return ERROR; }

    # we will fail the 2nd one of these
    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # loop to relabel all drives without delay

    $total = $loopCount * scalar(@allPdds);
    logInfo("Begin loop to relabel all drives $total times.");
    CtlrLogTextAll($coPtr,"Test Case 10: Begin loop to relabel all drives $total times.");

    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");

        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {

            # get the current label
            $type = GetDriveLabel( $ctlr, $allPdds[$i] );
            if ( $type == INVALID )
            {
                return ERROR;
            }

            # re-apply that label to the same drive
            $ret = ReLabelSingleDrive ( $ctlr, $allPdds[$i], $type );
            if ( $ret != GOOD ) { return ERROR; }
        }
    }
    logInfo("End loop to relabel all drives $total times.");

    #           4) verify IO
    logInfo("Verify IO after several relabels");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # create some vdisks

    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)
    CtlrLogTextAll($coPtr,"Test Case 10: Creating new vdisks ");

    $ret = MakeVdisks($ctlr, 14, NO_RAID_INIT );  # option 14 is 2 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
        return (ERROR);
    }

    # start inits on new vdisks
    logInfo("      Starting raids inits.");
    CtlrLogTextAll($coPtr,"Test Case 10:       Starting raids inits.");

    $ret = InitNewerVdisks( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }


    # loop to relabel all drives without delay
    $total = $loopCount * scalar(@allPdds);
    logInfo("Begin loop to relabel all drives $total times.");
    CtlrLogTextAll($coPtr,"Test Case 10: Begin loop to label drives during init.");

    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");

        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {

            # get the current label
            $type = GetDriveLabel( $ctlr, $allPdds[$i] );
            if ( $type == INVALID )
            {
                return ERROR;
            }

            # re-apply that label to the same drive
            $ret = ReLabelSingleDrive ( $ctlr, $allPdds[$i], $type );
            if ( $ret != GOOD ) { return ERROR; }
        }
    }
    logInfo("End loop to relabel all drives $total times.");

    #           4) verify IO
    logInfo("Verify IO after relabeling all drives while init runs.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # wait for the inits

    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }


# # has init finished? if not, rebuild will fail
#
#    $ret = INVALID;
#
#    $lc = 0;
#    while ( $ret != GOOD )
#    {
#        $lc++;
#        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));
#                                                                                                      # should this be an inti check?
#        $ret = DegradeCheck( $ctlr );
#        if ( $ret == ERROR )
#        {
#            return ERROR;
#        }
#        DelaySecs( 15 );
#    }


    PSDCheck( $ctlr );



    # now fail a pdisk
    CtlrLogTextAll($coPtr, "Test Case 10: now failing pdd $pdds[1]" );

    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin

    DelaySecs(60);

    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # loop to relabel all drives without delay

    $total = $loopCount * (scalar(@allPdds) - 1);
    logInfo("Begin loop to relabel most drives $total times during rebuild.");
    CtlrLogTextAll($coPtr, "Test Case 10: Begin loop to relabel most drives $total times during rebuild." );

    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j                 \r");

        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {
            # probably need to make sure we don't use the dead drive

            if ( $allPdds[$i] !=  $pdds[1] )
            {
                # get the current label
                $type = GetDriveLabel( $ctlr, $allPdds[$i] );
                if ( $type == INVALID )
                {
                    return ERROR;
                }

                # re-apply that label to the same drive
                $ret = ReLabelSingleDrive ( $ctlr, $allPdds[$i], $type );
                if ( $ret != GOOD ) { return ERROR; }

            }
        }
    }

    logInfo("End loop to relabel most drives $total times.");

    # let the rebuild finish
    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );


    # loop to relabel the same drive without delay
    for ( $j = 0; $j < $loopCount; $j++ )
    {
        print ("Begin loop # $j of $loopCount             \r");

        # this loop just increases the number of commands sent
        for ( $i = 0; $i < scalar(@allPdds); $i++)
        {

            # get the current label
            $type = GetDriveLabel( $ctlr, $pdds[2] );
            if ( $type == INVALID )
            {
                return ERROR;
            }

            # re-apply that label to the same drive
            $ret = ReLabelSingleDrive ( $ctlr, $pdds[2], $type );
            if ( $ret != GOOD ) { return ERROR; }
        }
    }

    # make sure IO is still good
    logInfo("Verify IO after several relabels with rebuild running");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }




    # wait for the inits to end ( they are probably done by now )

    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }


    # make sure IO is still good
    logInfo("Verify IO once rebuilds have completed");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }



    # verify IO
    logInfo("Confirm IO after test is done and disk restored.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
#    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 10.");


    return GOOD;

}

###############################################################################

=head2 BEStressCase11 function

This test case reads the quorum FIDs repeatedly.
The test has these
basic steps...


 Steps are 1) read the fid directory
           2) read each fid in the directory
           3) repeat 2) 'n' times
           4) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase11( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase11
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                LIPs the BE loops
#
# Steps are 1) read the fid directory
#           2) read each fid in the directory
#           3) repeat 2) 'n' times
#           4) verify IO
#
##############################################################################
sub BEStressCase11
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $i;
    my $j;
    my %data;
    my $ret;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 11: FID reads.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    #  FID reads.
    ######################################################################

    # FID directory

    #### 00000000  44 69 72 65 63 74 6F 72  79 20 09 00 00 00 00 00  Directory ......
    #### 00000010  58 49 4F 20 4C 61 62 65  6C 20 02 00 09 00 00 00  XIO Label ......
    #### 00000020  42 45 20 4E 56 52 41 4D  20 20 81 0B 0B 00 00 00  BE NVRAM  ......
    #### 00000030  46 45 20 4E 56 52 41 4D  20 20 81 0B 8C 0B 00 00  FE NVRAM  ......
    #### 00000040  45 4D 43 20 4E 56 52 41  4D 20 81 0B 0D 17 00 00  EMC NVRAM ......
    #### 00000050  53 54 20 53 63 72 61 74  63 68 01 01 8E 22 00 00  ST Scratch..."..
    #### 00000060  4D 41 53 54 45 52 5F 43  4F 4E 09 00 8F 23 00 00  MASTER_CON...#..
    #### 00000070  43 4F 4E 54 52 4C 5F 4D  41 50 19 00 98 23 00 00  CONTRL_MAP...#..
    #### 00000080  43 4F 4D 4D 5F 41 52 45  41 20 01 04 B1 23 00 00  COMM_AREA ...#..
    #### 00000090  4E 4D 5F 50 44 49 53 4B  20 20 01 02 B2 27 00 00  NM_PDISK  ...'..
    #### 000000A0  4E 4D 5F 56 44 49 53 4B  20 20 01 02 B3 29 00 00  NM_VDISK  ...)..
    #### 000000B0  4E 4D 5F 53 45 52 56 45  52 20 01 01 B4 2B 00 00  NM_SERVER ...+..
    #### 000000C0  4E 4D 5F 56 4C 49 4E 4B  5F 43 21 00 B5 2C 00 00  NM_VLINK_C!..,..
    #### 000000D0  4E 4D 5F 43 4F 4E 54 52  4F 4C 09 00 D6 2C 00 00  NM_CONTROL...,..
    #### 000000E0  4E 4D 5F 54 41 52 47 45  54 20 81 00 DF 2C 00 00  NM_TARGET ...,..
    #### 000000F0  4E 4D 5F 45 4E 43 4C 4F  53 55 41 00 60 2D 00 00  NM_ENCLOSUA.`-..
    #### 00000100  4E 4D 5F 4D 49 53 43 44  45 56 21 00 A1 2D 00 00  NM_MISCDEV!..-..
    #### 00000110  4E 4D 5F 56 43 47 20 20  20 20 02 00 C2 2D 00 00  NM_VCG    ...-..
    #### 00000120  4E 4D 5F 56 4C 49 4E 4B  5F 56 21 00 C4 2D 00 00  NM_VLINK_V!..-..
    #### 00000130  52 4D 5F 43 4F 4E 46 49  47 31 41 00 E5 2D 00 00  RM_CONFIG1A..-..
    #### 00000140  52 4D 5F 43 4F 4E 46 49  47 32 41 00 26 2E 00 00  RM_CONFIG2A.&...
    #### 00000150  52 4D 5F 4C 4F 47 5F 31  20 20 81 00 67 2E 00 00  RM_LOG_1  ..g...
    #### 00000160  52 4D 5F 4C 4F 47 5F 32  20 20 81 00 E8 2E 00 00  RM_LOG_2  ......
    #### 00000170  43 4B 50 5F 44 49 52 45  43 54 81 00 69 2F 00 00  CKP_DIRECT..i/..
    #### 00000180  43 4B 50 5F 4D 43 4E 46  30 30 09 00 EA 2F 00 00  CKP_MCNF00.../..

    my @safeFids = (0,1,2,3,4,5,6,7);
    for ( $j = 0; $j < $loopCount; $j++ )
    {

        foreach $i (@safeFids)
        #for ($i = 0; $i < 23; $i++ )
        {
            if ( $i == 8 ) { next; }        # skip FID 8

            print "reading FID $i \n";

            %data = $ctlr->ReadFID($i);
            if ( ! %data  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from ReadFID <<<<<<<<");
                return ERROR;
            }
            if ( $data{STATUS} != PI_GOOD )      # if call returned an error
            {
                # probably need to handle the expected bad CRC on FID 23

                logInfo(">>>>>>>> Error from ReadFID <<<<<<<<");
                PrintError(%data);
                return ERROR;
            }
        }

    }

    #           4) verify IO
    logInfo("Verify IO after reading FIDs");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 11.");


    return GOOD;

}

###############################################################################

=head2 BEStressCase12 function

This test case send loop primitives to the BE qlogic cards.
The test has these
basic steps...
     1) determine valid loop primitives
     2) select a controller
     3) issue each of the loop primitives, randomly select the
        QL card that is used ( do this 'n' times)
     4) verify IO
     5) repeat 2-4 for the other controller(s)


=cut

=over 1

=item Usage:

 my $rc = BEStressCase12( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase12
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCountv
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                loop primitives to the BE loops
#
# Steps are 1) determine valid loop primitives
#           2) select a controller
#           3) issue each of the loop primitives, randomly select the
#              QL card that is used ( do this 'n' times)
#           4) verify IO
#           5) repeat 2-4 for the other controller(s)
#
##############################################################################
sub BEStressCase12
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $i;
    my $j;
    my $k;
    my $ret;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 12: Send loop primitives (just LIP) to the BE Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # loops to LIP the BE cards.
    ######################################################################

    # Steps are 1) select the controller
    for ( $i = 0; $i < scalar(@$coPtr); $i++ )
    {

        $ctlr = $coList[$i];

        #           2) for 'n' loops
        for ( $j = 0; $j < $loopCount; $j++ )
        {

            #   sequentially LIP each QL card
            for ( $k = 0; $k < 4; $k++ )
            {

                $ret = ResetBELoop ($ctlr, $k );
                if ( $ret == ERROR )
                {
                    print ("\n");
                    logInfo("Error from ResetBELoop.");
                    return ERROR;
                }


                # wait 10 secs between LIPs
                if ( $ret != INVALID )
                {
                    DelaySecs(15);
                }
            }

        }

        #  3) verify IO is still good

        logInfo("Verify IO after $loopCount loops sequentially LIPping the BE QLogic cards");
        $ret = VerifyIO( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

    }


#add code here
#           option      - loop primitive option
#                           LP_RESET_LOOP           0x0000
#                           LP_RESET_LID_PORT       0x0001
#                           LP_SID_PID_RESET        0x0002
#                           LP_LOGIN_LID            0x0011
#                           LP_LOGIN_PID            0x0012
#                           LP_LOGOUT_LID           0x0021
#                           LP_LOGOUT_PID           0x0022
#                           LP_TARGET_RESET_LID     0x0031
#                           LP_TARGET_RESET_PID     0x0032
#                           LP_PORT_BYPASS_LID      0x0041
#                           LP_PORT_BYPASS_PID      0x0042
#                           LP_PORT_ENABLE_LID      0x0043
#                           LP_PORT_ENABLE_PID      0x0044
#                           LP_PORT_BYPASS_TEST_LID 0x00F1
#                           LP_PORT_BYPASS_TEST_PID 0x00F2


    logInfo("End of BE stress test case 12.");

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    return GOOD;

}


###############################################################################

=head2 BEStressCase13 function

This test case fails a pdisk during a scrub.
The test has these
basic steps...

     1) verify IO
     2) enable/start scrubbing
     3) fail a pdisk
     4) verify IO
     5) check scrubbing state
     6) wait for rebuild to end
     7) verify IO
     8) check scrub state/ re-enable if needed
     9) wait for one pass to complete
    10) verify IO
    11) stop scrubbing
    12) restore the failed pdisk
    13) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase13( $coPtr, $retIn, $snPtr, $pDFailMeans  );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 13, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 63, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase13
#
#        Inputs: $coPtr, $retIn, $snPtr, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                LIPs the BE loops
#
# Steps are 1) verify IO
#           2) enable/start scrubbing
#           3) fail a pdisk
#           4) verify IO
#           5) check scrubbing state
#           6) wait for rebuild to end
#           7) verify IO
#           8) check scrub state/ re-enable if needed
#           9) wait for one pass to complete
#          10) verify IO
#          11) stop scrubbing
#          12) restore the failed pdisk
#          13) verify IO
#
##############################################################################
sub BEStressCase13
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @pdds;
    my $ret;
    my %rsp;
    my $lc;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 13: Fail a pdisk during a scrub.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # loops to LIP the BE cards.
    ######################################################################

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # Steps are 1) verify IO

    logInfo("Verify IO at start of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           2) enable/start scrubbing

    $ret = ScrubSet("ENABLE", "DISABLE", 0, $coPtr);

    if ( $ret != GOOD ) { return ERROR; }




    #           3) fail a pdisk
    CtlrLogTextAll($coPtr, "Test Case 13: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin


    #           4) verify IO

    logInfo("Verify IO after failing a pdisk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           5) check scrubbing state

    %rsp = $ctlr->scrubInfo();

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo(sprintf("  Classic Scrubbing: %s", $rsp{SCRUBBING}));
        }
        else
        {
            logInfo("Unable to retrieve the scrubbing information.");
            PrintError( %rsp);
            return ERROR;
        }
    }
    else
    {
        logInfo("ERROR: Did not receive a response packet from Scrub Info.");
        return ERROR;
    }





    #           6) wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );

    #           7) verify IO

    logInfo("Verify IO after rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           8) check scrub state/ re-enable if needed

    $ret = ScrubSet("ENABLE", "DISABLE", 0, $coPtr);
    if ( $ret != GOOD ) { return ERROR; }

    #           9) wait for one pass to complete

    logInfo("20 minute delay to allow scrubbing to run for a while");
    DelaySecs(1200);


    #          10) verify IO

    logInfo("Verify IO after scrub running for a while");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #          11) stop scrubbing

    #          12) restore the failed pdisk

    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }



    # disable scrubbing
    $ret = ScrubSet("DISABLE", "DISABLE", 0, $coPtr);
    if ( $ret != GOOD ) { return ERROR; }


    #          13) verify IO

    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 13.");


    return GOOD;

}

###############################################################################

=head2 BEStressCase14 function

This test case fails a pdisk during an election.
The test has these
basic steps...

    1) Wait until all disks are operational
    2) Do 10 elections, back to back
    3) Start Election, Fail the pdisk  ( a data one )
    4) Do more elections, repeat until 200 are done, or
       the rebuild has finished
    5) If needed wait for the rebuild to finish.
    6) Do 10 more elections
    7) Verify IO
    8) Restore the disk to operation
    9) Do 50 more elections
   10) Verify IO





=cut

=over 1

=item Usage:

 my $rc = BEStressCase14( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 14, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 64, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase14
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                LIPs the BE loops
#
# Steps:
#    1) Wait until all disks are operational
#    2) Do 10 elections, back to back
#    3) Start Election, Fail the pdisk  ( a data one )
#    4) Do more elections, repeat until 200 are done, or
#       the rebuild has finished
#    5) If needed wait for the rebuild to finish.
#    6) Do 10 more elections
#    7) Verify IO
#    8) Restore the disk to operation
#    9) Do 50 more elections
#   10) Verify IO
#
##############################################################################
sub BEStressCase14
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlrS;

    my $lc;
    my $ret;
    my @pdds;
    my %rsp;
    my $elStateM;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 14: Fail a pdisk during an election.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }
    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # pick a slave controller
    if ($master == 0)
    {
        $ctlrS = $coList[1];
    }
    else
    {
        $ctlrS = $coList[0];
    }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     

    ######################################################################
    # begin elections test
    ######################################################################

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    #    1) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );


    #    2) Do 10 elections, back to back

    # need to refresh the connection to the slave
    $ret = TestNReconnectAll($coPtr);

    $ret = ElectionsTest($ctlr, $ctlrS, 10);
    if ( $ret != GOOD ) { return ERROR; }

    DelaySecs(5);

    #    3) Start Election, Fail the pdisk  ( a data one )

    CtlrLogTextAll($coPtr, "Test Case 14: begin election before failing drive" );

    %rsp = $ctlr->genericCommand("ELECTION", 0 );

    # see how the start of the election went

    if (!%rsp)                        # no response
    {
        logInfo(">>>>>>>> Failed to receive a response from ELECTION start <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} == 1)            # 1 is bad
    {
        logInfo(">>>>>>>> Failed: starting an election returned an error <<<<<<<<");
        PrintError(%rsp);
        logError("Failure in BEStress test");
        return ERROR;
    }




    CtlrLogTextAll($coPtr, "Test Case 14: now failing pdd $pdds[1] during an election" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin

    # let's wait until this lecetion ends

    $elStateM = 0;

    # loop getting state and printing changes until election finishes
    while ( $elStateM != 0 )
    {
        ##
        # get the master's election state
        ##
        %rsp = $ctlr->vcgElectionState();

        # see how getting the master's status went
        if (!%rsp)                        # no response
        {
            logInfo(">>>>>>>> Failed to receive a response from ELECTION status <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} == 1)            # 1 is bad
        {
            logInfo(">>>>>>>> Failed: getting election status returned an error <<<<<<<<");
            PrintError(%rsp);
            logInfo("Failure in elections test");
            return ERROR;
        }

    }

    #    4) Do more elections, repeat until 200 are done, or
    #       the rebuild has finished

    $ret = ElectionsTest($ctlr, $ctlrS, 100);
    if ( $ret != GOOD ) { return ERROR; }



    #    5) If needed wait for the rebuild to finish.
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );


    # need to refresh the connection to the slave
    $ret = TestNReconnectAll($coPtr);


    #    6) Do 10 more elections

    $ret = ElectionsTest($ctlr, $ctlrS, 10);
    if ( $ret != GOOD ) { return ERROR; }


    #    7) Verify IO
    logInfo("Verify IO after the rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # get the current master as it may have moved

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }
    $ctlr = $coList[$master];

    #    8) Restore the disk to operation
    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    #    9) Do 50 more elections

    # need to refresh the connection to the slave
    $ret = TestNReconnectAll($coPtr);



    $ret = ElectionsTest($ctlr, $ctlrS, 50);
    if ( $ret != GOOD ) { return ERROR; }



    #   10) Verify IO

    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 14.");


    return GOOD;

}
###############################################################################

###############################################################################

=head2 BEStressCase15 function

This test case fails a pdisk during an election.
The test has these
basic steps...

    1) Wait until all disks are operational
    2) Do 10 elections, back to back
    3) Start Election, Fail the pdisk  ( a hotspare one )
    4) Do more elections, repeat until 200 are done, or
       the rebuild has finished
    5) If needed wait for the rebuild to finish.
    6) Do 10 more elections
    7) Verify IO
    8) Restore the disk to operation
    9) Do 50 more elections
   10) Verify IO





=cut

=over 1

=item Usage:

 my $rc = BEStressCase15( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 15, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 65, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase15
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                Fail a hotspare drive during an election
#
# Steps:
#    1) Wait until all disks are operational
#    2) Do 10 elections, back to back
#    3) Start Election, Fail the pdisk  ( a hotspare one )
#    4) Do more elections, repeat until 200 are done, or
#       the rebuild has finished
#    5) If needed wait for the rebuild to finish.
#    6) Do 10 more elections
#    7) Verify IO
#    8) Restore the disk to operation
#    9) Do 50 more elections
#   10) Verify IO
#
##############################################################################
sub BEStressCase15
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlrS;

    my @pdds;
    my %rsp;
    my $ret;
    my $lc;
    my $elStateM;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 15: Fail a pdisk(HOTSPARE) during an election.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    # pick a slave controller
    if ($master == 0)
    {
        $ctlrS = $coList[1];
    }
    else
    {
        $ctlrS = $coList[0];
    }



    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # begin elections test
    ######################################################################

    @pdds = GetTheseDisks( $ctlr, CCBEHOTSPARETYPE );
    if ( $pdds[0] == INVALID) 
    { 
        logInfo("Failed to find any suitable hotspare pdisks.");
        return ERROR; 
    }


    #    1) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );


    #    2) Do 10 elections, back to back

    $ret = ElectionsTest($ctlr, $ctlrS, 10);
    if ( $ret != GOOD ) { return ERROR; }



    #    3) Start Election, Fail the pdisk  ( a data one )


    %rsp = $ctlr->genericCommand("ELECTION", 0);

    # see how the start of the election went

    if (!%rsp)                        # no response
    {
        logInfo(">>>>>>>> Failed to receive a response from ELECTION start <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} == 1)            # 1 is bad
    {
        logInfo(">>>>>>>> Failed: starting an election returned an error <<<<<<<<");
        PrintError(%rsp);
        logError("Failure in BEStress test");
        return ERROR;
    }




    CtlrLogTextAll($coPtr, "Test Case 15: now failing pdd $pdds[1] during an election" );


    GetSesAndSlot ($ctlr, $pdds[0], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[0], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin

    # let's wait until this lecetion ends

    $elStateM = 0;

    # loop getting state and printing changes until election finishes
    while ( $elStateM != 0 )
    {
        ##
        # get the master's election state
        ##
        %rsp = $ctlr->vcgElectionState();

        # see how getting the master's status went
        if (!%rsp)                        # no response
        {
            logInfo(">>>>>>>> Failed to receive a response from ELECTION status <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} == 1)            # 1 is bad
        {
            logInfo(">>>>>>>> Failed: getting election status returned an error <<<<<<<<");
            PrintError(%rsp);
            logInfo("Failure in elections test");
            return ERROR;
        }

    }

    #    4) Do more elections, repeat until 200 are done, or
    #       the rebuild has finished

    $ret = ElectionsTest($ctlr, $ctlrS, 100);
    if ( $ret != GOOD ) { return ERROR; }



    #    5) If needed wait for the rebuild to finish.
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );



    #    6) Do 10 more elections

    $ret = ElectionsTest($ctlr, $ctlrS, 10);
    if ( $ret != GOOD ) { return ERROR; }


    #    7) Verify IO
    logInfo("Verify IO after the rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #    8) Restore the disk to operation
    # unfail the drive
    $master = FindMaster( $coPtr );
    $ctlr = $coList[$master];

    $ret = UnfailPdisk($coPtr, $pdds[0], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }



    #    9) Do 50 more elections


    $ret = ElectionsTest($ctlr, $ctlrS, 50);
    if ( $ret != GOOD ) { return ERROR; }



    #   10) Verify IO

    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 15.");


    return GOOD;

}

###############################################################################

=head2 BEStressCase17 function

This test case does elections while an init is running.
The test has these
basic steps...

     1) Wait until all disks are operational
     2) Create and init a vdisk
     3) Do 200 elections or until init finished
     4) If necessary, wait for the init to finish.
     5) Verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase17( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase17
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                Elections during raid init
#
# Steps:
#    1) Wait until all disks are operational
#    2) Create and init a vdisk
#    3) Do 200 elections or until init finished
#    4) If necessary, wait for the init to finish.
#    5) Verify IO
#
##############################################################################
sub BEStressCase17
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlrS;

    my $ret;
    my $numVDDs;
    my $lc;
    my @vdisks;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;



    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 17: Elections during a single raid init.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # pick a slave controller
    if ($master == 0)
    {
        $ctlrS = $coList[1];
    }
    else
    {
        $ctlrS = $coList[0];
    }

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     
 
    ######################################################################
    # Elections during a single raid init.
    ######################################################################


    #    1) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until drives are operational");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );


    #    2) Create and init a vdisk

    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)
    $ret = MakeVdisks($ctlr, 14, NO_RAID_INIT );  # option 14 is 2 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
        return (ERROR);
    }

    # start inits on new vdisks
    logInfo("      Starting raids inits, this will stop the defrags");
    $ret = InitNewerVdisks( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }


    #    3) Do 200 elections or until init finished
    $ret = ElectionsTest($ctlr, $ctlrS, 10);
    if ( $ret != GOOD ) { return ERROR; }


    #    4) If necessary, wait for the init to finish.
    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }



    #    5) Verify IO

    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 17.");


    return GOOD;

}
###############################################################################


###############################################################################

=head2 BEStressCase19 function

This test case fails a pdisk while doing an init on a single raid drive.
The test has these
basic steps...
     1) Create a vdisk (single Raid)
     2) Start the raid init
     3) verify IO
     4) fail a pdisk (rebuild will start)
     5) wait for rebuilds to finish
     6) verify IO
     7) wait for init to finish
     8) verify IO
     9) delete the new vdisk
    10) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase19( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 19, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 69, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase19
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                Fail a pdisk while initializong a single raid vdisk
#
# Steps are 1) Create a vdisk (single Raid)
#           2) Start the raid init
#           3) verify IO
#           4) fail a pdisk (rebuild will start)
#           5) wait for rebuilds to finish
#           6) verify IO
#           7) wait for init to finish
#           8) verify IO
#           9) delete the new vdisk
#          10) verify IO
#
##############################################################################
sub BEStressCase19
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $lc;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my @pdds;
    my %rsp;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 19: Fail a pdisk during init of a single raid vdisk.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # create vdisk, init, then fail a pdisk
    ######################################################################

    #    0) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until drives are operational");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );

    # Steps are 1) Create a vdisk (single Raid)
    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)
    $ret = MakeVdisks($ctlr, 14, NO_RAID_INIT );  # option 14 is 2 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
        return (ERROR);
    }

    #           2) Start the raid init
    # start inits on new vdisks
    logInfo("      Starting raids inits, this will stop the defrags");
    $ret = InitNewerVdisks( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }


    #           3) verify IO
    logInfo("Verify IO after starting the raid init");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           4) fail a pdisk (rebuild will start)

    # now fail the pdisk

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 19: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin





    #           5) wait for rebuilds to finish
    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );


    #           6) verify IO
    logInfo("Verify IO after rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           7) wait for init to finish
    # wait for the inits to end ( they are probably done by now )

    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }



    #           8) verify IO
    logInfo("Verify IO at end of the init");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           9) delete the new vdisk
    # get rid of any unused vdisks
    $ret = DeleteUnusedVdisks( $ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    # restore the failed pdisk
    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }




    #          10) verify IO
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 19.");


    return GOOD;

}
###############################################################################


###############################################################################

=head2 BEStressCase20 function

This test case fails a pdisk while doing an init on a multiple raid drive.
The test has these
basic steps...
     1) Create a vdisk (single Raid)
     2) Start the raid init
     3) verify IO
     4) fail a pdisk (rebuild will start)
     5) wait for rebuilds to finish
     6) verify IO
     7) wait for init to finish
     8) verify IO
     9) delete the new vdisk
    10) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase20( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 20, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 70, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase20
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                Fail a pdisk while initializong a multiple raid vdisk
#
# Steps are 1) Create a vdisk (multiple Raid)
#           2) Start the raid init
#           3) verify IO
#           4) fail a pdisk (rebuild will start)
#           5) wait for rebuilds to finish
#           6) verify IO
#           7) wait for init to finish
#           8) verify IO
#           9) delete the new vdisk
#          10) verify IO
#
##############################################################################
sub BEStressCase20
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $lc;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my @pdds;
    my %rsp;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 20: Fail a pdisk during init of a multiple raid vdisk.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # create vdisk, init, then fail a pdisk
    ######################################################################

    #    0) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until drives are operational");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );

    # Steps are 1) Create a vdisk (single Raid)
    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)


    $ret = CreateMultiRaidVdisk($ctlr, 2000, RAID_10);
    if ( $ret != GOOD ) { return ERROR; }


    #           2) Start the raid init
    # start inits on new vdisks
    logInfo("      Starting raids inits, this will stop the defrags");
    $ret = InitNewerVdisks( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }


    #           3) verify IO
    logInfo("Verify IO after starting the raid init");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           4) fail a pdisk (rebuild will start)

    # now fail the pdisk

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 20: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin





    #           5) wait for rebuilds to finish
    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );


    #           6) verify IO
    logInfo("Verify IO after rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           7) wait for init to finish
    # wait for the inits to end ( they are probably done by now )

    logInfo("      Wait for the new vdisks to intialize");
    $ret = WaitOnNewerInits( $ctlr, \@vdisks );
    if ( $ret != GOOD ) { return ERROR; }



    #           8) verify IO
    logInfo("Verify IO at end of the init");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           9) delete the new vdisk
    # get rid of any unused vdisks
    $ret = DeleteUnusedVdisks( $ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    # restore the failed pdisk
    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }




    #          10) verify IO
    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 20.");


    return GOOD;

}


###############################################################################

=head2 BEStressCase21 function

This test case repeatedly powercycles a slave controller.
The test has these
basic steps...

     1) Locate a slave controller
     2) verify IO
     3) turn off the controller
     4) failover timeline from master
     5) verify IO
     6) for 'n' loops
           turn on slave controller
           wait 2 minute (timeline?)
           verify IO
           turn off controller
           wait 2 minutes (timeline?)
           verify IO
     7) turn on controller
     8) reconnect and unfail
     9) timeline for 2 minutes
    10) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase21( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase21
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                Many power cycles on a slave controller.
#
# Steps are 1) Locate a slave controller
#           2) verify IO
#           3) turn off the controller
#           4) failover timeline from master
#           5) verify IO
#           6) for 'n' loops
#                 turn on slave controller
#                 wait 2 minute (timeline?)
#                 verify IO
#                 turn off controller
#                 wait 2 minutes (timeline?)
#                 verify IO
#           7) turn on controller
#           8) reconnect and unfail
#           9) timeline for 2 minutes
#          10) verify IO
#
##############################################################################
sub BEStressCase21
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $slave;
    my $ret;
    my $i;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 21: Repeatedly power cycle a slave controller.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 21: start" );

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     

    ######################################################################
    # power cycles on the slave controller.
    ######################################################################

    # Steps are 1) Locate a slave controller
    $slave = 1;
    if ( $master == 1 ) { $slave = 0; }


    #           2) verify IO
    logInfo("Verify IO at the beginning of the test");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           3) turn off the controller

    CtlrLogTextAll($coPtr, "Test Case 21: now turning off $$coPtr[$slave]->{HOST}" );
    $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 0);
    if ( $ret != GOOD ) { return ERROR; }


    #           4) failover timeline from master

    $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
    if ( $ret != GOOD ) { return ERROR; }


    #           5) verify IO
    logInfo("Verify IO after failing the slave controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers,
                     0,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #           6) for 'n' loops
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        #                 turn on slave controller
        CtlrLogText($$coPtr[$master], "Test Case 21: now turning on $$coPtr[$slave]->{HOST}" );
        $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 1);
        if ( $ret != GOOD ) { return ERROR; }

        #                 wait 2 minute (timeline?)
        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        #                 verify IO
        logInfo("Verify IO with slave turned on. Loop $i");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         0,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #                 turn off controller
        CtlrLogText($$coPtr[$master], "Test Case 21: now turning off $$coPtr[$slave]->{HOST}" );
        $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 0);
        if ( $ret != GOOD ) { return ERROR; }



        #                 wait 2 minutes (timeline?)
        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        #                 verify IO
        logInfo("Verify IO with slave turned off. Loop $i");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         0,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }
    }

    #           7) turn on controller
    CtlrLogText($$coPtr[$master], "Test Case 21: now turning on $$coPtr[$slave]->{HOST}" );
    $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 1);
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogText($$coPtr[$master], "Test Case 21: unfailing all failed controllers" );

    #           8) reconnect and unfail
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    #           9) timeline for 2 minutes (delay in above fcn)
    #          10) verify IO

    CtlrLogTextAll($coPtr, "Test Case 21: checking I/O on system" );

    logInfo("Verify IO at end of the test, after restoring the controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );

    CtlrLogTextAll($coPtr, "Test Case 21: after checking I/O on system" );


    if ( $ret != GOOD )
    {
        my $obj1 = XIOTech::cmdMgr->new(\*STDOUT);

        for ( $i = 0; $i < scalar(@coList); $i++ )
        {
            if ( $coList[$i] )
            {
                # 3200 login here
                $ret =  $obj1->login( $coList[$i]->{HOST}, 3200);       # connect to controller
                if ( ! $ret  )
                {
                    logError(">>>>>>>> Failed to connect to $coList[$i]->{HOST}  <<<<<<<<");
                    #return (ERROR);
                }
                else
                {
                    getTrace($obj1, "C:\\temp\\fail".$i.".txt");
                    $obj1->logout();
                }
            }

        }


        return ERROR;
    }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 21.");


    return GOOD;

}
###############################################################################

###############################################################################

=head2 BEStressCase22 function

This test case repeatedly powercycles a slave controller during a rebuild.
The test has these
basic steps...

     1) Locate a slave controller
     2) verify IO
     3) select a pdisk
     4) fail the pdisk
     5) confirm rebuild start
     3) turn off the slave controller
     4) failover timeline from master
     5) verify IO
     6) for 'n' loops
           turn on slave controller
           wait 2 minute (timeline?)
           verify IO
           turn off controller
           wait 2 minutes (timeline?)
           verify IO
     7) turn on controller
     8) reconnect and unfail
     9) timeline for 2 minutes
    10) verify IO
    11) wait for/verify rebuild is complete
    12) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase22( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 22, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 72, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase22
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                Many power cycles on a slave controller.
#
# Steps are 1) Locate a slave controller
#           2) verify IO
#           3) select a pdisk
#           4) fail the pdisk
#           5) confirm rebuild start
#           6) turn off the slave controller
#           7) failover timeline from master
#           8) verify IO
#           9) for 'n' loops
#                 turn on slave controller
#                 wait 2 minute (timeline?)
#                 verify IO
#                 turn off controller
#                 wait 2 minutes (timeline?)
#                 verify IO
#          10) turn on controller
#          11) reconnect and unfail
#          12) timeline for 2 minutes
#          13) verify IO
#          14) wait for/verify rebuild is complete
#          15) verify IO
#
##############################################################################
sub BEStressCase22
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ses;
    my $slot;

    my $slave;
    my $ret;
    my $i;
    my $lc;
    my %rsp;
    my @pdds;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 22: Repeatedly power cycle a controller during rebuild.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     

    ######################################################################
    # power cycles on the slave controller, during a rebuild
    ######################################################################




    # Steps are 1) Locate a slave controller
    $slave = 1;
    if ( $master == 1 ) { $slave = 0; }


    #           2) verify IO
    logInfo("Verify IO at the beginning of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # moving the turn off first so that we can let the R5 resyncs complete before
    # killing a drive. If we kill the drive first, we get a situation where the
    # rebuilds fail due to a double fault. (A raid 5 issue.)
    #


    CtlrLogText($$coPtr[$master], "Test Case 22: now turning off $$coPtr[$slave]->{HOST}" );
    $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 0);
    if ( $ret != GOOD ) { return ERROR; }


    #           7) failover timeline from master

    $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
    if ( $ret != GOOD ) { return ERROR; }


    #           8) verify IO
    logInfo("Verify IO after failing the slave controller");
    $ret = TestSystemState1( $coPtr,
                     \@activeServers,
                     0,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    #
    # now we need to wait for the R5 resyncs to finish. Do this only if there
    # are raid 5 drives in the system.
    #

    if ( 1 == GotRaid5($coList[$master]) )
    {
        logInfo ( "Raid 5 configured in system, mwaiting for resyncs to complete.");

        # wait for resync to finish on all raids
        $ret = TestLibs::Validate::R5ResyncCheck( \@coList, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("R5 resync check reported an error - test failed.");
            return ERROR;
        }

    }

    #           3) select a pdisk
    # we will fail the 2nd one of these
    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }

    #           4) fail the pdisk
    CtlrLogTextAll($coPtr, "Test Case 22: now failing pdd $pdds[1]" );

    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    #           5) confirm rebuild start
    $ret = DegradeCheck( $ctlr );
    logInfo("Degrade check returned $ret.");

    #           6) turn off the controller


    #           9) for 'n' loops
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        #                 turn on slave controller
        CtlrLogText($$coPtr[$master], "Test Case 22: now turning on $$coPtr[$slave]->{HOST}" );
        $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 1);
        if ( $ret != GOOD ) { return ERROR; }

        #                 wait 2 minute (timeline?)
        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        #                 verify IO
        logInfo("Verify IO with slave turned on. Loop $i");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         0,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #                 turn off controller
        CtlrLogText($$coPtr[$master], "Test Case 22: now turning off $$coPtr[$slave]->{HOST}" );
        $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 0);
        if ( $ret != GOOD ) { return ERROR; }



        #                 wait 2 minutes (timeline?)
        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        #                 verify IO
        logInfo("Verify IO with slave turned off. Loop $i");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         0,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }
    }

    #           10) turn on controller
    CtlrLogText($$coPtr[$master], "Test Case 22: now turning on $$coPtr[$slave]->{HOST}" );
    $ret = PowerChange($$moxaIP[$slave], $$mmPtr[$slave], 1);
    if ( $ret != GOOD ) { return ERROR; }

    #           11) reconnect and unfail
    $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
    if ( $ret != GOOD ) { return ERROR; }

    #           12) timeline for 2 minutes (delay in above fcn)
    #          13) verify IO


    logInfo("Verify IO at end of the test, after restoring the controller");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #          14) wait for/verify rebuild is complete

    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }



    #          15) verify IO


    logInfo("Verify IO at end of the test, after restoring the pdisk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 22.");




    return GOOD;

}


###############################################################################

=head2 BEStressCase23 function

This test case rrund redi-copy and attempts a defrag while rebuilds are
running.
The test has these
basic steps...

     1) Redi-copy 2 vdisks, wait for complete
     2) fail a pdisk - rebuilds start
     3) create a 3rd replacement vdisk
     4) delete first source vdisk
     5) start another redi-copy
     6) Begin defrags
     7) wait for copy complete
     8) verify IO
     9) wait for rebuild complete
    10) wait for defrag to complete
    11) check SOS tables
    12) verify IO
    13) unfail pdisk
    14) check sos tables
    15) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase23( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 23, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 73, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase23
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                redi-cp and defrag during a rebuild
#
# Steps are 1) Redi-copy 2 vdisks, wait for complete
#           2) fail a pdisk - rebuilds start
#           3) create a 3rd replacement vdisk
#           4) delete first source vdisk
#           5) start another redi-copy
#           6) Begin defrags
#           7) wait for copy complete
#           8) verify IO
#           9) wait for rebuild complete
#          10) wait for defrag to complete
#          11) check SOS tables
#          12) verify IO
#          13) unfail pdisk
#          14) check sos tables
#          15) verify IO
#
##############################################################################
sub BEStressCase23
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @pdds;
    my $ret;
    my $newVd;
    my $newVd2;
    my $newVd3;
    my $lc;
    my @oldVds;
    my $failedDisk;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 23: Redi-copy and defrag while doing a rebuild.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    #
    # Do initial defrag all to clean up any initial fragmentation 
    #
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    # refresh any connections
    TestNReconnectAll($coPtr);    

    DispVdiskInfo($ctlr);

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     

    ######################################################################
    # redi-cp and defrag during rebuild.
    ######################################################################

    # we will fail the 2nd one of these
    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # Steps are 1) Redi-copy a vdisk, wait for complete
    # this makes sure there is space to defrag

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 5 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }
    if ( scalar(  @oldVds ) < 3 ) 
    { 
        logInfo(" Not enough early vdisks found.");
        return ERROR; 
    }

    # copy it to the end
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    # let copy complete
    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }

    # do another redi-copy, wait for complete

    # copy it to the end
    $newVd2 =  CreateReplacementVdisk($ctlr, $oldVds[1] );
    if ( $newVd2 < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[1], $newVd2);
    if ( $ret != GOOD ) { return ERROR; }

    # let copy complete
    $ret = WaitForCpComplete( $ctlr, $newVd2 );
    if ( $ret != GOOD ) { return ERROR; }

    #           2) fail a pdisk - rebuilds start
    CtlrLogTextAll($coPtr, "Test Case 23: now failing pdd $pdds[1]" );

    $failedDisk =  $pdds[1];

    GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $failedDisk, $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # if a hotspare was used, we need to relabel disks for
    # the next vdiskcreate (just data disks)
    $ret = FixPdiskLabels ($ctlr, DONTMAKEHOTSPARE);
    if ( $ret != GOOD ) { return ERROR; }


    # Create another replacement vdisk
    $newVd3 =  CreateReplacementVdisk($ctlr, $oldVds[2] );
    if ( $newVd3 < 0 ) { return ERROR; }

    #           6) delete first source vdisk
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) )
    {
        return ERROR;
    }

    #          11.3) check SOS tables
    $ret = CheckSosTables( $coPtr, ISFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    #           7) start another redi-copy
    # copy it to the end
    $ret = RediCpVdisks($ctlr, $oldVds[2], $newVd3);
    if ( $ret != GOOD ) { return ERROR; }


  #  #           8) Begin defrags
  #  # Since a rebuild is going on, these really can't start. The
  #  # appropriate messages should get logged
  #  logInfo("Due to rebuilds, the following defrags will probably NOT start.");
    $ret = DefragAllBegin($ctlr);
    if ( $ret != GOOD ) { return ERROR; }
  

    #           9) wait for copy complete
    $ret = WaitForCpComplete( $ctlr, $newVd3 );
    if ( $ret != GOOD ) { return ERROR; }

    #          10) verify IO
    logInfo("Verify IO after 3rd redi-copy");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #          11) wait for rebuild complete
    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );

    # Not wait for defrag to finish
    $ret = DefragWait( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    # refresh any connections
    TestNReconnectAll($coPtr);    

    #          11.3) check SOS tables
    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    #          15) verify IO

    logInfo("Verify IO after defrags finish");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #          11.5) restart defrags
    # Since a rebuild is done, these should start. The
    # appropriate messages should get logged

#    logInfo("Rebuilds are done, the following defrags will probably WILL start.");
#    $ret = DefragAll($ctlr);
#    if ( $ret != GOOD ) { return ERROR; }

    # 13.5) unfail the drive
    $ret = UnfailPdisk($coPtr, $failedDisk, $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }


    #          14) check sos tables
#    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    #          15) verify IO

    logInfo("Verify IO at end of test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 23.");


    return GOOD;

}
###############################################################################
###############################################################################

=head2 BEStressCase24 .. 26 function

These test cases stress the move vdisk function. Case 24 just does a lot of moves.
Case 25 does moves during a redi-copy. Case 26 does moves, then
moves during a redi-copy.

The test has these
basic steps...
     1) Create 2 vdisks (single Raid)
     2) change its vid many times  (vdiskmove)
     3) Create 2 move vdisks for redi-copy destinations
     4) start the redi-copies
     5) change the vid several times
     6) wait for redicp to complete
     7) check io at the end

Steps 3-6 are skipped for 24
Step 2 is skipped for case 25


=cut

=over 1

=item Usage:

 my $rc = BEStressCase24 .. 26( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase24 .. 26
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                Fail a pdisk while initializing a single raid vdisk
#
# Steps are 1) Create a vdisk (single Raid)
#           2) change its vid many times  (vdiskmove)
#
#
##############################################################################
sub BEStressCase24
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $ret;

    $ret = BEStressCase2426($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, 0, $pDFailMeans );

    return $ret;

}

sub BEStressCase25
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $ret;

    $ret = BEStressCase2426($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, 1, $pDFailMeans );

    return $ret;

}

sub BEStressCase26
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $ret;

    $ret = BEStressCase2426($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, 2, $pDFailMeans );

    return $ret;

}


###############################################################################

=head2 BEStressCase2426 function

This test case fails a pdisk while doing an init on a single raid drive.
The test has these
basic steps...
     1) Create a vdisk (single Raid)
     2) change its vid many times  (vdiskmove)
=cut

=over 1

=item Usage:

 my $rc = BEStressCase2426( $coPtr, $retIn, $snPtr, $loopCount, $ option, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done
        $option is 0, 1, 2

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase2426
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                Fail a pdisk while initializong a single raid vdisk
#
# Steps are 1) Create a vdisk (single Raid)
#           2) change its vid many times  (vdiskmove)
#
#
##############################################################################
sub BEStressCase2426
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $option, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my $lc;
    my $i;
    my $j;
    my $ret;
    my @vdisks;
    my $numVDDs;
    my @pdds;
    my @nowVds;
    my @newVds;
    my %rsp;
    my $foundIt;
    my $newVd1;
    my $newVd2;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 24..26: Move vdisk, option = $option.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

  #  # check the number of controllers
  #  if ( scalar(@$coPtr) < 2 )
  #  {
  #      logInfo("This test case requires multiple controllers. Test case is skipped.");
  #      return ($retIn);
  #  }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }



    # get measure of the current IO


#    @vCounts = GetVdiskActivityCounts($coPtr);
#
#    @sCounts = GetServerActivityCounts($coPtr);
#
#    logInfo("Pause to allow activity to accumulate");
#    DelaySecs(20);
#
##    @tMap = GetTargetMap( $coPtr, $snPtr );
##    if ( $tMap[0] == INVALID ) { return ERROR; }
#
#    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
#    if ( $ret != GOOD )  {return ERROR; }
#
#
#    #
#    # get the initial active vdisks for the test
#    #
#
#
#    logInfo("Generating Activity Information");
#
#    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
#    if (scalar(@activeServers) > 0 )
#    {
#        if ( $activeServers[0] == INVALID ) { return ERROR; }
#    }
#
#    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
#    if (scalar(@initialVdisks) > 0 )
#    {
#        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
#    }
#

    ######################################################################
    # create vdisk, init, then fail a pdisk
    ######################################################################

    #    0) Wait until all disks are operational
    # rebuild is done if no drives are 'degraded'

#    logInfo("polling until drives are operational");
#    $ret = INVALID;
#
#    $lc = 0;
#    while ( $ret != GOOD )
#    {
#        $lc++;
#        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));
#
#        $ret = DegradeCheck( $ctlr );
#        if ( $ret == ERROR )
#        {
#            return ERROR;
#        }
#        DelaySecs( 15 );
#    }

    # Steps are 1) Create a vdisk (single Raid)
    # (first get a list of existing vdisks)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available

    # (now create them)
    $ret = MakeVdisks($ctlr, 14, NO_RAID_INIT );  # option 14 is 2 vdisks
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
        return (ERROR);
    }

    #           2) Start the raid init

    # identify the two new ones


    # first get a list of current vdisks
    @nowVds = GetVdiskList( $ctlr );
    if ( $nowVds[0] == INVALID )
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@nowVds);  # of drives currently available

    # now find which are new vdisks

    for ( $i = 0; $i < $numVDDs; $i++ )
    {
        $foundIt = 0;

        for ( $j = 0; $j < scalar(@vdisks); $j++ )
        {
            if ( $vdisks[$j] == $nowVds[$i] )
            {
                $foundIt = 1;
            }
        }

        if ( $foundIt == 0 )
        {
            push (@newVds, $nowVds[$i]);
        }
    }

    my @altVds;

    for ( $i = 0; $i < scalar(@newVds); $i++ )
    {
        $altVds[$i] = $newVds[$i] + 128;
    }

    # now the loops

    logInfo(" Starting vdisks @vdisks");
    logInfo(" Source vdisks @newVds");
    logInfo(" Alternate vdisks @altVds");

    # option 1: skip the next loop

    if ( $option != 1 )
    {
        for ( $i = 0; $i < $loopCount; $i++ )
        {


            # move to alt

            for ( $j = 0; $j < scalar(@newVds); $j++ )
            {

                print "Moving vdisk  $newVds[$j] to $altVds[$j], loop $i.      \n";
                                                          # src         dest
                %rsp = $ctlr->virtualDiskControl(0x00, $newVds[$j], $altVds[$j]);

                if (!%rsp)                        # no response
                {
                    print "\n";
                    logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                    return ERROR;
                }

                if ($rsp{STATUS} == 1)            # 1 is bad
                {
                    logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                    print "\n";
                    PrintError(%rsp);
                    return ERROR;
                }

            }

            # move back
            for ( $j = 0; $j < scalar(@newVds); $j++ )
            {

                print "Moving vdisk  $altVds[$j] to $newVds[$j], loop $i.      \n";
                                                          # src         dest
                %rsp = $ctlr->virtualDiskControl(0x00, $altVds[$j], $newVds[$j]);

                if (!%rsp)                        # no response
                {
                    print "\n";
                    logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                    return ERROR;
                }

                if ($rsp{STATUS} == 1)            # 1 is bad
                {
                    print "\n";
                    logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                    PrintError(%rsp);
                    return ERROR;
                }

            }

            print "\n";

            logInfo ("Move vdisk loop $i complete");

        }
    }


    # option 0 skip the rest

    if ( $option != 0 )
    {

        # now, start a redicp on both of these and repeat the loop


        # copy it to the end
        $newVd1 =  CreateReplacementVdisk($ctlr, $vdisks[0] );
        if ( $newVd1 < 0 ) { return ERROR; }

        $ret = RediCpVdisks($ctlr, $vdisks[0], $newVd1);
        if ( $ret != GOOD ) { return ERROR; }

        # copy it to the end
        $newVd2 =  CreateReplacementVdisk($ctlr, $vdisks[1] );
        if ( $newVd2 < 0 ) { return ERROR; }

        $ret = RediCpVdisks($ctlr, $vdisks[1], $newVd2);
        if ( $ret != GOOD ) { return ERROR; }


        # For R1 and R2, we do not have the ability to move a vdisk that
        # is part of a copy/swap. So, this test must work with different
        # vdisks. Allowing a move during C/S is a future enhancement.
        #
        # We do this by using @vdisks or @newVds for the copies above
        #                    <current>  <future>




        for ( $i = 0; $i < $loopCount; $i++ )
        {


            # move to alt

            for ( $j = 0; $j < scalar(@newVds); $j++ )
            {

                print "Moving vdisk  $newVds[$j] to $altVds[$j], loop $i.      \n";
                                                          # src         dest
                %rsp = $ctlr->virtualDiskControl(0x00, $newVds[$j], $altVds[$j]);

                if (!%rsp)                        # no response
                {
                    print "\n";
                    logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                    return ERROR;
                }

                if ($rsp{STATUS} == 1)            # 1 is bad
                {
                    logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                    print "\n";
                    PrintError(%rsp);
                    return ERROR;
                }

            }

            # move back
            for ( $j = 0; $j < scalar(@newVds); $j++ )
            {

                print "Moving vdisk  $altVds[$j] to $newVds[$j], loop $i.      \n";
                                                          # src         dest
                %rsp = $ctlr->virtualDiskControl(0x00, $altVds[$j], $newVds[$j]);

                if (!%rsp)                        # no response
                {
                    print "\n";
                    logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                    return ERROR;
                }

                if ($rsp{STATUS} == 1)            # 1 is bad
                {
                    print "\n";
                    logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                    PrintError(%rsp);
                    return ERROR;
                }

            }

            print "\n";

            logInfo ("Move vdisk loop $i complete");

        }

        # let copy complete (if it hasn't already finished)
        $ret = WaitForCpComplete( $ctlr, $newVd1 );
        if ( $ret != GOOD ) { return ERROR; }

        # let copy complete (if it hasn't already finished)
        $ret = WaitForCpComplete( $ctlr, $newVd2 );
        if ( $ret != GOOD ) { return ERROR; }

     }


    # verify io at end

#
#
#    #          10) verify IO
#    logInfo("Verify IO at end of the test");
#    $ret = VerifyIO( $coPtr,
#                     \@activeServers,
#                     \@tMap,
#                     \@initialVdisks,
#                     $snPtr
#                   );
#    if ( $ret != GOOD ) { return ERROR; }
#

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 24..26, option = $option.");


    return GOOD;

}
###############################################################################

###############################################################################

=head2 BEStressCase28 function

This test case fails a pdisk during a scrub.
The test has these
basic steps...

     1) verify IO
     2) fail a pdisk
     3) verify IO
     4) wait for rebuild to end
     5) verify IO
     6) restore the failed pdisk
     7) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase28( $coPtr, $retIn, $snPtr , $pDFailMeans );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 28, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 78, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase28
#
#        Inputs: $coPtr, $retIn, $snPtr, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                LIPs the BE loops
#
# Steps are
#             1) verify IO
#             2) fail a pdisk
#             3) verify IO
#             4) wait for rebuild to end
#             5) verify IO
#             6) restore the failed pdisk
#             7) verify IO
#
##############################################################################
sub BEStressCase28
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ses;
    my $slot;

    my @pdds;
    my $ret;
    my %rsp;
    my $lc;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 28: Fail a pdisk during IO.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # loops to LIP the BE cards.
    ######################################################################

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # Steps are 1) verify IO

 #   logInfo("Verify IO at start of the test");
 #   $ret = VerifyIO( $coPtr,
 #                    \@activeServers,
 #                    \@tMap,
 #                    \@initialVdisks,
 #                    $snPtr
 #                  );
 #   if ( $ret != GOOD ) { return ERROR; }





    #           3) fail a pdisk
    CtlrLogTextAll($coPtr, "Test Case 28: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin


    #           4) verify IO

    logInfo("Verify IO after failing a pdisk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }






    #           6) wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );

    #           7) verify IO

    logInfo("Verify IO after rebuilds end");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }




    #          12) restore the failed pdisk

    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }




    #          13) verify IO

    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 28.");


    return GOOD;

}
###############################################################################

=head2 BEStressCase31 function

This test case fails a pdisk, waits for the rebuild to finish
The test has these
basic steps...

     1) verify IO
     2) fail a pdisk
     3) verify IO
     4) wait for rebuild to end
     5) verify IO
     6) restore the failed pdisk
     7) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase31( $coPtr, $retIn, $snPtr, $pDFailMeans );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 31, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 31, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut


###############################################################################
sub BEStressCase31
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlr;

    my @oldVds;
    my $newVd;
    my $ret;
    my $lc;
    my @pdds;
    my %rsp;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 31: fail a pdisk wait for rebuilds  -----------------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # initial defrag  (to assure no initial gaps)
    $ret = DefragAll( $ctlr );
    if ( $ret != GOOD ) { return ERROR; }

    # refresh any connections
    TestNReconnectAll($coPtr);    

    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     

    ######################################################################
    # With a defrag running, rediCP one of the first vdisks to a new one.
    # then delete the old one and start another defrag.
    ######################################################################

    # setup - need to get a defrag running


    # verify IO is still good
    logInfo("IO check after beginning defrag");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 31: now failing pdd $pdds[1]" );


    GetSesAndSlot ($ctlr, $pdds[1], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $pdds[1] , $pDFailMeans);
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin


    # verify IO is still good
    logInfo("Verify IO with the failed PDD");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }





    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );


    # any rebuild stops a defrag, so there is no point in waiting for
    # defrags to end (note, some defrags may continue if they don't
    # crash into the rebuild)



    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[1], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }



    # verify IO
    logInfo("Confirm IO after test is done and disk restored.");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


#    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 31.");


    return GOOD;

}
###############################################################################
###############################################################################

=head2 BEStressCase32 function

This test case is run without IO. This represent JT`s
Rebuild Test Summary case A2 (as of 8/03).
The overall test has these
basic steps...

     1) validate BE state (a good start)
     2) for each pdisk,                    (rebuild test case A2)
            bypass the drive
            unbypass/unfail the drive
     3) do a parity scan
     4) validate the BE state

=cut

=over 1

=item Usage:

 my $rc = BEStressCase32( $coPtr, $retIn, $snPtr, $pDFailMeans );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $pDFailMeans is ignored

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.



=item Initial Conditions:

 The system needs to be configured with a number of vdisks and no IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut


###############################################################################
sub BEStressCase32
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlr;

    my @oldVds;
    my $newVd;
    my $ret;
    my $lc;
    my @pdds;
    my %rsp;
    my $ses;
    my $slot;

    my $lid;
    my $port;

    my @dataDrives;
    my @unsafeDrives;

    my $drive;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg  = "-------------- Test Case 32: bypass/unbypass pdisks without IO  -----------------";
    $msg0 = "---------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }



    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("This test requires all BE states to be good at the beginning");
        return ERROR;

    }

    logInfo("Parity Scan at the beginning of the test.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test cannot run.");
        return ERROR;
    }


    ######################################################################
    # With a no IO, tests that bypass and unbypass drives.
    ######################################################################

    logInfo("Begin loop to bypass/unbypass drives.");

    # first get a list of all data and unsafe drives


    @dataDrives = GetTheseDisks($ctlr, CCBEDATATYPE);


    @unsafeDrives = GetTheseDisks($ctlr, CCBEUNSAFETYPE);


    # CCBEDATATYPE => 1;
    # CCBEHOTSPARETYPE => 2;
    # CCBEUNSAFETYPE => 3;
    # CCBEUNLABLEDTYPE => 0;
    # CCBEVLINKTYPE => 5;

    ##########################################
    # now do bypass/unbypass for data drives
    ##########################################

    for ( $drive = 0; $drive < scalar(@dataDrives); $drive++ )
    {

        # Check for empty/invalid list
        if ( $dataDrives[$drive] == INVALID) { last; }

        # fail a  drive
        CtlrLogTextAll($coPtr, "Test Case 32: now bypassing data drive $dataDrives[$drive]" );

        GetSesAndSlot ($ctlr, $dataDrives[$drive], \$ses, \$slot, \$lid, \$port);

        #$ret = FailPdisk( $coPtr, $dataDrives[$drive] , PDISKBYPASS);
        #if ( $ret != GOOD ) { return ERROR; }
        $ret = FailPdiskNoWait( $ctlr, $dataDrives[$drive] , PDISKBYPASS);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(120);
        

        # the disk is failed, nothing unexpected should happen (no IO = no rebuild)
        ShortPdiskInfo($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now unbypassing data drive $dataDrives[$drive]" );

        # unfail the drive
        $ret = UnfailPdisk($coPtr, $dataDrives[$drive], $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        ShortPdiskInfo($ctlr);
        DelaySecs(10);

    }

    ShortVdisks($ctlr);

    # wait for any rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    logInfo("Verify the BE state after bypass/unbypass loop for data drives.");
    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("Some drives are not good after the bypass/unbypass test.");
        return ERROR;

    }

    PSDCheck( $ctlr );

    ##########################################
    # now do bypass/unbypass for unsafe drives
    ##########################################

    for ( $drive = 0; $drive < scalar(@unsafeDrives); $drive++ )
    {

        # Check for empty/invalid list
        if ( $unsafeDrives[$drive] == INVALID) { last; }

        # fail a  drive
        CtlrLogTextAll($coPtr, "Test Case 32: now bypassing data drive $unsafeDrives[$drive]" );


        GetSesAndSlot ($ctlr, $unsafeDrives[$drive], \$ses, \$slot, \$lid, \$port);

        #$ret = FailPdisk( $coPtr, $unsafeDrives[$drive] , PDISKBYPASS);
        #if ( $ret != GOOD ) { return ERROR; }
        $ret = FailPdiskNoWait( $ctlr, $unsafeDrives[$drive] , PDISKBYPASS);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(120);

        # the disk is failed, nothing unexpected should happen (no IO = no rebuild)

        ShortPdiskInfo($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now unbypassing unsafe drive $unsafeDrives[$drive]" );

        # unfail the drive
        $ret = UnfailPdisk($coPtr, $unsafeDrives[$drive], $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(10);

        ShortPdiskInfo($ctlr);

    }



    # wait for any rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    logInfo("Verify the BE state after bypass/unbypass loop for unsafe drives.");
    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("Some drives are not good after the bypass/unbypass test.");
        return ERROR;

    }

    PSDCheck( $ctlr );


    logInfo("Parity Scan after bypass/unbypass loop.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test fails.");
        return ERROR;
    }


    #########################################################

    logInfo("Begin loop to bypass/rescan/unbypass drives.");

    #########################################################

    # first get a list of all current data and unsafe drives


    @dataDrives = GetTheseDisks($ctlr, CCBEDATATYPE);


    @unsafeDrives = GetTheseDisks($ctlr, CCBEUNSAFETYPE);


    # CCBEDATATYPE => 1;
    # CCBEHOTSPARETYPE => 2;
    # CCBEUNSAFETYPE => 3;
    # CCBEUNLABLEDTYPE => 0;
    # CCBEVLINKTYPE => 5;

    ##########################################
    # now do bypass/rescan/unbypass for data drives
    ##########################################

    for ( $drive = 0; $drive < scalar(@dataDrives); $drive++ )
    {

        # Check for empty/invalid list
        if ( $dataDrives[$drive] == INVALID) { last; }

        # fail a  drive
        CtlrLogTextAll($coPtr, "Test Case 32: now bypassing data drive $dataDrives[$drive]" );


        GetSesAndSlot ($ctlr, $dataDrives[$drive], \$ses, \$slot, \$lid, \$port);

        #$ret = FailPdisk( $ctlr, $dataDrives[$drive] , PDISKBYPASS);
        #if ( $ret != GOOD ) { return ERROR; }
        $ret = FailPdiskNoWait( $ctlr, $dataDrives[$drive] , PDISKBYPASS);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(120);

        # the disk is failed, nothing unexpected should happen (no IO = no rebuild)

        ShortPdiskInfo($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now rescanning BE." );

        RescanBE($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now unbypassing data drive $dataDrives[$drive]" );

        # unfail the drive
        $ret = UnfailPdisk($coPtr, $dataDrives[$drive], $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(10);

        ShortPdiskInfo($ctlr);

    }


    # wait for any rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    logInfo("Verify the BE state after bypass/rescan/unbypass loop for data drives.");
    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("Some drives are not good after the bypass/rescan/unbypass test.");
        return ERROR;

    }

    PSDCheck( $ctlr );

    ##########################################
    # now do bypass/rescan/unbypass for unsafe drives
    ##########################################

    for ( $drive = 0; $drive < scalar(@unsafeDrives); $drive++ )
    {

        # Check for empty/invalid list
        if ( $unsafeDrives[$drive] == INVALID) { last; }

        # fail a  drive
        CtlrLogTextAll($coPtr, "Test Case 32: now bypassing data drive $unsafeDrives[$drive]" );

        GetSesAndSlot ($ctlr, $unsafeDrives[$drive], \$ses, \$slot, \$lid, \$port);

        #$ret = FailPdisk( $ctlr, $unsafeDrives[$drive] , PDISKBYPASS);
        #if ( $ret != GOOD ) { return ERROR; }
        $ret = FailPdiskNoWait( $ctlr, $unsafeDrives[$drive] , PDISKBYPASS);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(120);

        # the disk is failed, nothing unexpected should happen (no IO = no rebuild)

        ShortPdiskInfo($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now rescanning BE." );

        RescanBE($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now unbypassing unsafe drive $unsafeDrives[$drive]" );

        # unfail the drive
        $ret = UnfailPdisk($coPtr, $unsafeDrives[$drive], $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(10);

        ShortPdiskInfo($ctlr);

    }



    # wait for any rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    logInfo("Verify the BE state after bypass/rescan/unbypass loop for unsafe drives.");
    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("Some drives are not good after the bypass/rescan/unbypass test.");
        return ERROR;

    }

    PSDCheck( $ctlr );


    logInfo("Parity Scan after bypass/rescan/unbypass loop.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test fails.");
        return ERROR;
    }


    #
    # This next test requires that there be at least one hotspare drive in
    # each drive bay. If not, all the drives may get bypassed and the
    # bay will disappear. The only recourse would be to power cycle
    # the drive bay.
    #

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 32.");


    return GOOD;

}
###############################################################################
###############################################################################

=head2 BEStressCase33 function

This test case is run without IO. This represent JT`s
Rebuild Test Summary case A6(as of 8/03).
The overall test has these
basic steps...

     1) validate BE state (a good start)
     2) for each pdisk,                    (rebuild test case A6)
            bypass the drive
            rescan BE
            unbypass/unfail the drive
            rescan BE
     3) do a parity scan
     4) validate the BE state

=cut

=over 1

=item Usage:

 my $rc = BEStressCase33( $coPtr, $retIn, $snPtr, $pDFailMeans );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.



=item Initial Conditions:

 The system needs to be configured with a number of vdisks and no IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut


###############################################################################
sub BEStressCase33
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlr;

    my @oldVds;
    my $newVd;
    my $ret;
    my $lc;
    my @pdds;
    my %rsp;
    my $ses;
    my $slot;

    my $lid;
    my $port;


    my @dataDrives;
    my @unsafeDrives;

    my $drive;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg  = "-------------- Test Case 33: bypass/rescan/unbypass without IO  -----------------";
    $msg0 = "---------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }



    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("This test requires all BE states to be good at the beginning");
        return ERROR;

    }

    logInfo("Parity Scan at the beginning of the test.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test cannot run.");
        return ERROR;
    }




    # CCBEDATATYPE => 1;
    # CCBEHOTSPARETYPE => 2;
    # CCBEUNSAFETYPE => 3;
    # CCBEUNLABLEDTYPE => 0;
    # CCBEVLINKTYPE => 5;


    #########################################################

    logInfo("Begin loop to bypass/rescan/unbypass drives.");

    #########################################################

    # first get a list of all current data and unsafe drives


    @dataDrives = GetTheseDisks($ctlr, CCBEDATATYPE);


    @unsafeDrives = GetTheseDisks($ctlr, CCBEUNSAFETYPE);


    # CCBEDATATYPE => 1;
    # CCBEHOTSPARETYPE => 2;
    # CCBEUNSAFETYPE => 3;
    # CCBEUNLABLEDTYPE => 0;
    # CCBEVLINKTYPE => 5;

    ##########################################
    # now do bypass/rescan/unbypass for data drives
    ##########################################

    for ( $drive = 0; $drive < scalar(@dataDrives); $drive++ )
    {

        # Check for empty/invalid list
        if ( $dataDrives[$drive] == INVALID) { last; }

        # fail a  drive
        CtlrLogTextAll($coPtr, "Test Case 33: now bypassing data drive $dataDrives[$drive]" );


        GetSesAndSlot ($ctlr, $dataDrives[$drive], \$ses, \$slot, \$lid, \$port);

        #$ret = FailPdisk( $ctlr, $dataDrives[$drive] , PDISKBYPASS);
        #if ( $ret != GOOD ) { return ERROR; }
        $ret = FailPdiskNoWait( $ctlr, $dataDrives[$drive] , PDISKBYPASS);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(120);

        # the disk is failed, nothing unexpected should happen (no IO = no rebuild)

        ShortPdiskInfo($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 33: now rescanning BE." );

        RescanBE($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 33: now unbypassing data drive $dataDrives[$drive]" );

        # unfail the drive
        $ret = UnfailPdisk($coPtr, $dataDrives[$drive], $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(10);

        ShortPdiskInfo($ctlr);

    }


    # wait for any rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    logInfo("Verify the BE state after bypass/rescan/unbypass loop for data drives.");
    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("Some drives are not good after the bypass/rescan/unbypass test.");
        return ERROR;

    }

    PSDCheck( $ctlr );

    ##########################################
    # now do bypass/rescan/unbypass for unsafe drives
    ##########################################

    for ( $drive = 0; $drive < scalar(@unsafeDrives); $drive++ )
    {

        # Check for empty/invalid list
        if ( $unsafeDrives[$drive] == INVALID) { last; }

        # fail a  drive
        CtlrLogTextAll($coPtr, "Test Case 33: now bypassing data drive $unsafeDrives[$drive]" );

        GetSesAndSlot ($ctlr, $unsafeDrives[$drive], \$ses, \$slot, \$lid, \$port);

        #$ret = FailPdisk( $ctlr, $unsafeDrives[$drive] , PDISKBYPASS);
        #if ( $ret != GOOD ) { return ERROR; }
        $ret = FailPdiskNoWait( $ctlr, $unsafeDrives[$drive] , PDISKBYPASS);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(120);

        # the disk is failed, nothing unexpected should happen (no IO = no rebuild)

        ShortPdiskInfo($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 33: now rescanning BE." );

        RescanBE($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 33: now unbypassing unsafe drive $unsafeDrives[$drive]" );

        # unfail the drive
        $ret = UnfailPdisk($coPtr, $unsafeDrives[$drive], $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(10);

        ShortPdiskInfo($ctlr);

    }



    # wait for any rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    logInfo("Verify the BE state after bypass/rescan/unbypass loop for unsafe drives.");
    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("Some drives are not good after the bypass/rescan/unbypass test.");
        return ERROR;

    }

    PSDCheck( $ctlr );


    logInfo("Parity Scan after bypass/rescan/unbypass loop.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test fails.");
        return ERROR;
    }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 33.");


    return GOOD;

}
###############################################################################
###############################################################################

=head2 BEStressCase34 function

This test case is run without IO. This represents JT`s
Rebuild Test Summary case A7 (as of 8/03).
The overall test has these
basic steps...

     1) validate BE state (a good start)
     2) bypass all data and unsafe drives
     3) for each bypassed pdisk            (rebuild test case A7)
            unbypass the drive
            rescan BE
            check vdisk state (all vdisks)
     4) do a parity scan
     5) validate the BE state

=cut

=over 1

=item Usage:

 my $rc = BEStressCase34( $coPtr, $retIn, $snPtr, $pDFailMeans );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.



=item Initial Conditions:

 The system needs to be configured with a number of vdisks and no IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut


###############################################################################
sub BEStressCase34
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlr;

    my @oldVds;
    my $newVd;
    my $ret;
    my $lc;
    my @pdds;
    my %rsp;
    my $ses;
    my $slot;

    my $lid;
    my $port;

    my @dataDrives;
    my @unsafeDrives;

    my $drive;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg  = "-------------- Test Case 34: Insert drives until VDisk operative ----------------";
    $msg0 = "---------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }



    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("This test requires all BE states to be good at the beginning");
        return ERROR;

    }

    logInfo("Parity Scan at the beginning of the test.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test cannot run.");
        return ERROR;
    }


    ######################################################################
    # With a no IO, remove all drives, then restore one at a time.
    ######################################################################

    logInfo("Begin loop to bypass/unbypass drives.");

    # first get a list of all data and unsafe drives


    @dataDrives = GetTheseDisks($ctlr, CCBEDATATYPE);


    @unsafeDrives = GetTheseDisks($ctlr, CCBEUNSAFETYPE);


    # CCBEDATATYPE => 1;
    # CCBEHOTSPARETYPE => 2;
    # CCBEUNSAFETYPE => 3;
    # CCBEUNLABLEDTYPE => 0;
    # CCBEVLINKTYPE => 5;

    ##########################################
    # now do bypass/unbypass for data drives
    ##########################################

    for ( $drive = 0; $drive < scalar(@dataDrives); $drive++ )
    {

        # Check for empty/invalid list
        if ( $dataDrives[$drive] == INVALID) { last; }

        # fail a  drive
        CtlrLogTextAll($coPtr, "Test Case 32: now bypassing data drive $dataDrives[$drive]" );


        GetSesAndSlot ($ctlr, $dataDrives[$drive], \$ses, \$slot, \$lid, \$port);

        #$ret = FailPdisk( $ctlr, $dataDrives[$drive] , PDISKBYPASS);
        #if ( $ret != GOOD ) { return ERROR; }
        $ret = FailPdiskNoWait( $ctlr, $dataDrives[$drive] , PDISKBYPASS);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(120);

        # the disk is failed, nothing unexpected should happen (no IO = no rebuild)
        ShortPdiskInfo($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now unbypassing data drive $dataDrives[$drive]" );

        # unfail the drive
        $ret = UnfailPdisk($coPtr, $dataDrives[$drive], $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        ShortPdiskInfo($ctlr);
        DelaySecs(10);

    }

    ShortVdisks($ctlr);

    # wait for any rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    logInfo("Verify the BE state after bypass/unbypass loop for data drives.");
    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("Some drives are not good after the bypass/unbypass test.");
        return ERROR;

    }

    PSDCheck( $ctlr );

    ##########################################
    # now do bypass/unbypass for unsafe drives
    ##########################################

    for ( $drive = 0; $drive < scalar(@unsafeDrives); $drive++ )
    {

        # Check for empty/invalid list
        if ( $unsafeDrives[$drive] == INVALID) { last; }

        # fail a  drive
        CtlrLogTextAll($coPtr, "Test Case 32: now bypassing data drive $unsafeDrives[$drive]" );


        GetSesAndSlot ($ctlr, $unsafeDrives[$drive], \$ses, \$slot, \$lid, \$port);

        #$ret = FailPdisk( $ctlr, $unsafeDrives[$drive] , PDISKBYPASS);
        #if ( $ret != GOOD ) { return ERROR; }
        $ret = FailPdiskNoWait( $ctlr, $unsafeDrives[$drive] , PDISKBYPASS);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(120);

        # the disk is failed, nothing unexpected should happen (no IO = no rebuild)

        ShortPdiskInfo($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now unbypassing unsafe drive $unsafeDrives[$drive]" );

        # unfail the drive
        $ret = UnfailPdisk($coPtr, $unsafeDrives[$drive], $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(10);

        ShortPdiskInfo($ctlr);

    }



    # wait for any rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    logInfo("Verify the BE state after bypass/unbypass loop for unsafe drives.");
    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("Some drives are not good after the bypass/unbypass test.");
        return ERROR;

    }

    PSDCheck( $ctlr );


    logInfo("Parity Scan after bypass/unbypass loop.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test fails.");
        return ERROR;
    }


    #########################################################

    logInfo("Begin loop to bypass/rescan/unbypass drives.");

    #########################################################

    # first get a list of all current data and unsafe drives


    @dataDrives = GetTheseDisks($ctlr, CCBEDATATYPE);


    @unsafeDrives = GetTheseDisks($ctlr, CCBEUNSAFETYPE);


    # CCBEDATATYPE => 1;
    # CCBEHOTSPARETYPE => 2;
    # CCBEUNSAFETYPE => 3;
    # CCBEUNLABLEDTYPE => 0;
    # CCBEVLINKTYPE => 5;

    ##########################################
    # now do bypass/rescan/unbypass for data drives
    ##########################################

    for ( $drive = 0; $drive < scalar(@dataDrives); $drive++ )
    {

        # Check for empty/invalid list
        if ( $dataDrives[$drive] == INVALID) { last; }

        # fail a  drive
        CtlrLogTextAll($coPtr, "Test Case 32: now bypassing data drive $dataDrives[$drive]" );


        GetSesAndSlot ($ctlr, $dataDrives[$drive], \$ses, \$slot, \$lid, \$port);

        #$ret = FailPdisk( $ctlr, $dataDrives[$drive] , PDISKBYPASS);
        #if ( $ret != GOOD ) { return ERROR; }
        $ret = FailPdiskNoWait( $ctlr, $dataDrives[$drive] , PDISKBYPASS);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(120);

        # the disk is failed, nothing unexpected should happen (no IO = no rebuild)

        ShortPdiskInfo($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now rescanning BE." );

        RescanBE($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now unbypassing data drive $dataDrives[$drive]" );

        # unfail the drive
        $ret = UnfailPdisk($coPtr, $dataDrives[$drive], $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(10);

        ShortPdiskInfo($ctlr);

    }


    # wait for any rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    logInfo("Verify the BE state after bypass/rescan/unbypass loop for data drives.");
    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("Some drives are not good after the bypass/rescan/unbypass test.");
        return ERROR;

    }

    PSDCheck( $ctlr );

    ##########################################
    # now do bypass/rescan/unbypass for unsafe drives
    ##########################################

    for ( $drive = 0; $drive < scalar(@unsafeDrives); $drive++ )
    {

        # Check for empty/invalid list
        if ( $unsafeDrives[$drive] == INVALID) { last; }

        # fail a  drive
        CtlrLogTextAll($coPtr, "Test Case 32: now bypassing data drive $unsafeDrives[$drive]" );


        GetSesAndSlot ($ctlr, $unsafeDrives[$drive], \$ses, \$slot, \$lid, \$port);

        #$ret = FailPdisk( $ctlr, $unsafeDrives[$drive] , PDISKBYPASS);
        #if ( $ret != GOOD ) { return ERROR; }
        $ret = FailPdiskNoWait( $ctlr, $unsafeDrives[$drive] , PDISKBYPASS);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(120);

        # the disk is failed, nothing unexpected should happen (no IO = no rebuild)

        ShortPdiskInfo($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now rescanning BE." );

        RescanBE($ctlr);

        CtlrLogTextAll($coPtr, "Test Case 32: now unbypassing unsafe drive $unsafeDrives[$drive]" );

        # unfail the drive
        $ret = UnfailPdisk($coPtr, $unsafeDrives[$drive], $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        DelaySecs(10);

        ShortPdiskInfo($ctlr);

    }



    # wait for any rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    logInfo("Verify the BE state after bypass/rescan/unbypass loop for unsafe drives.");
    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("Some drives are not good after the bypass/rescan/unbypass test.");
        return ERROR;

    }

    PSDCheck( $ctlr );


    logInfo("Parity Scan after bypass/rescan/unbypass loop.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test fails.");
        return ERROR;
    }


    #
    # This next test requires that there be at least one hotspare drive in
    # each drive bay. If not, all the drives may get bypassed and the
    # bay will disappear. The only recourse would be to power cycle
    # the drive bay.
    #

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 32.");


    return GOOD;

}

#############################################################################


###############################################################################

=head2 BEStressCase35 function

This test case fails a pdisk while IO is running. It is run with no hotspare
drives. The test has these
basic steps...

     1) get baseline IO activity info
     2) unlabel all hotspare drives
     3) fail a pdisk ( rebuilds should start )
     4) unfail the pdisk
     5) wait for rebuilds to complete
     6) relabel the hotspare drives
     7) confirm IO still going
     8) confirm IO still Ok
     9) check SOS tables

=cut

=over 1

=item Usage:

 my $rc = BEStressCase35( $coPtr, $retIn, $snPtr, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $pDFailMeans determines how the pdisk will be failed

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 35, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 85, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase35
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#
##############################################################################
sub BEStressCase35
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 35: Fail a pdisk then unfail it (no hotspares) ---------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("This test requires all BE states to be good at the beginning");
        return ERROR;

    }


    logInfo("Parity Scan at the beginning of the test.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test cannot run.");
        return ERROR;
    }


    ######################################################################
    # Fail one of the data pdisks, unfail it.
    ######################################################################

    # remove any hotspares from the list

    my @hsDrives = GetTheseDisks( $ctlr, CCBEHOTSPARETYPE );

    logInfo("Unlabel all hotspare drives.");

    if ( $hsDrives[0] != INVALID)
    {
        # there were some hotspares, we need to unlabel them
        for ( my $i=0; $i < scalar( @hsDrives ); $i++ )
        {
            # do we unlabel or bypass (try unlabel)
            $ret = LabelSingleDrive( $ctlr, $hsDrives[$i], 0);

            if ($ret == ERROR)
            {
                logInfo(">>>>> Failed to unlabel hotspare drives  <<<<<");
                return (ERROR);
            }

        }

    }


    # show current pdisk data
    ShortPdiskInfo($ctlr);

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 35.");

    # find an early vdisk

    logInfo("Going to fail a pdisk now");

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 35: now failing pdd $pdds[1]" );

    $failedDisk = $pdds[1];

    GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);



    $ret = FailPdisk( $coPtr, $failedDisk, $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin


    # verify IO is still good
    logInfo("Verify IO after failing the pdd (rebuilds not running)");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # unfail the drive
    $ret = UnfailPdisk($coPtr, $failedDisk, $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }



    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );

    logInfo("Making hotspares drives hotspares again.");

    if ( $hsDrives[0] != INVALID)
    {
        # there were some hotspares, we need to unlabel them
        for ( my $i=0; $i < scalar( @hsDrives ); $i++ )
        {
            # restore the hotspare labels
            $ret = LabelSingleDrive( $ctlr, $hsDrives[$i], CCBEHOTSPARETYPE);

            if ($ret == ERROR)
            {
                logInfo(">>>>> Failed to unlabel hotspare drives  <<<<<");
                return (ERROR);
            }

        }

    }

    # confirm the configuration

    # ???

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    # show current pdisk data
    ShortPdiskInfo($ctlr);

    # verify IO
    logInfo("Confirm IO after test is done and disk restored. (rebuilds done)");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
#    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("Parity Scan at the end of the test.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test cannot run.");
        return ERROR;
    }

    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("This test requires all BE states to be good at the end");
        return ERROR;

    }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 35.");


    return GOOD;

}

###############################################################################

###############################################################################

=head2 BEStressCase36 function

This test case fails a pdisk while IO is running. The test has these
basic steps...

     1) get baseline IO activity info
     2) fail a pdisk ( rebuilds should start )
     3) unfail the pdisk
     4) confirm IO still going
     5) wait for rebuilds to complete
     6) confirm IO still Ok
     7) check SOS tables

=cut

=over 1

=item Usage:

 my $rc = BEStressCase36( $coPtr, $retIn, $snPtr, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $pDFailMeans determines how the pdisk will be failed

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 36, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 86, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase36
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#
##############################################################################
sub BEStressCase36
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 36: Fail a pdisk then unfail it (with hotspares) -------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }



    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     
 

    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("This test requires all BE states to be good at the beginning");
        return ERROR;

    }


    logInfo("Parity Scan at the beginning of the test.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test cannot run.");
        return ERROR;
    }


    ######################################################################
    # Fail one of the data pdisks, unfail it.
    ######################################################################



    # show current pdisk data
    ShortPdiskInfo($ctlr);



    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 36.");

    # find an early vdisk

    logInfo("Going to fail a pdisk now");

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 36: now failing pdd $pdds[1]" );

    $failedDisk = $pdds[1];

    GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);



    $ret = FailPdisk( $coPtr, $failedDisk, $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin


    # verify IO is still good
    logInfo("Verify IO after failing the pdd (rebuilds running on hotspare)");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # unfail the drive
    $ret = UnfailPdisk($coPtr, $failedDisk, $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }



    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );


    # show current pdisk data
    ShortPdiskInfo($ctlr);

    # verify IO
    logInfo("Confirm IO after test is done and disk restored. (rebuilds done)");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
#    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("Parity Scan at the end of the test.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test cannot run.");
        return ERROR;
    }

    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("This test requires all BE states to be good at the end");
        return ERROR;

    }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 36.");


    return GOOD;

}

###############################################################################

###############################################################################

=head2 BEStressCase37 function

This test case fails a pdisk while IO is running. It is run with no hotspare
drives. The test has these
basic steps...

     1) get baseline IO activity info
     2) unlabel all hotspare drives
     3) fail a pdisk
     4) add in one hotspare
     5) unfail the pdisk
     6) wait for rebuilds to complete
     7) relabel the hotspare drives
     8) confirm IO still going
     9) confirm IO still Ok
    10) check SOS tables

=cut

=over 1

=item Usage:

 my $rc = BEStressCase37( $coPtr, $retIn, $snPtr, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $pDFailMeans determines how the pdisk will be failed

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 37, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 87, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase37
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#
##############################################################################
sub BEStressCase37
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @oldVds;
    my $newVd;
    my @pdds;
    my $lc;
    my %rsp;
    my $ret;
    my $failedDisk;
    my $ses;
    my $slot;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 37: Fail a pdisk add hotspare then unfail it ---------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }



    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("This test requires all BE states to be good at the beginning");
        return ERROR;

    }


    logInfo("Parity Scan at the beginning of the test.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test cannot run.");
        return ERROR;
    }


    ######################################################################
    # Fail one of the data pdisks, unfail it.
    ######################################################################

    # remove any hotspares from the list

    my @hsDrives = GetTheseDisks( $ctlr, CCBEHOTSPARETYPE);

    logInfo("Unlabel all hotspare drives.");

    if ( $hsDrives[0] != INVALID)
    {
        # there were some hotspares, we need to unlabel them
        for ( my $i=0; $i < scalar( @hsDrives ); $i++ )
        {
            # do we unlabel or bypass (try unlabel)
            $ret = LabelSingleDrive( $ctlr, $hsDrives[$i], 0);

            if ($ret == ERROR)
            {
                logInfo(">>>>> Failed to unlabel hotspare drives  <<<<<");
                return (ERROR);
            }

        }

    }


    # show current pdisk data
    ShortPdiskInfo($ctlr);



    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 37.");

    # find an early vdisk

    logInfo("Going to fail a pdisk now");

    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }


    # fail a  drive
    CtlrLogTextAll($coPtr, "Test Case 37: now failing pdd $pdds[1]" );

    $failedDisk = $pdds[1];

    GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);



    $ret = FailPdisk( $coPtr, $failedDisk, $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    # the disk is failed, now some rebuilds will soon begin

    # show current pdisk data
    ShortPdiskInfo($ctlr);



    # verify IO is still good
    logInfo("Verify IO after failing the pdd (rebuilds not running?)");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("Adding back one hotspare.");

    $ret = LabelSingleDrive( $ctlr, $hsDrives[0], CCBEHOTSPARETYPE);
    if ($ret == ERROR)
    {
        logInfo(">>>>> Failed to label hotspare drives  <<<<<");
        return (ERROR);
    }

    logInfo("Pause to ensure that the rebuilds do start.");
    DelaySecs(150);


    # show current pdisk data
    ShortPdiskInfo($ctlr);



    # verify IO is still good
    logInfo("Verify IO after adding in a hotspare (rebuilds running)");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # unfail the drive
    $ret = UnfailPdisk($coPtr, $failedDisk, $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }



    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }

    PSDCheck( $ctlr );

    logInfo("Making remaining hotspares drives hotspares again.");

    if ( $hsDrives[0] != INVALID)
    {
        # there were some hotspares, put the labels back
        for ( my $i = 1; $i < scalar( @hsDrives ); $i++ )
        {
            # restore the hotspare labels
            $ret = LabelSingleDrive( $ctlr, $hsDrives[$i], CCBEHOTSPARETYPE);

            if ($ret == ERROR)
            {
                logInfo(">>>>> Failed to label hotspare drives  <<<<<");
                return (ERROR);
            }

        }

    }

    # confirm the configuration

    # ???

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    # show current pdisk data
    ShortPdiskInfo($ctlr);

    # verify IO
    logInfo("Confirm IO after test is done and disk restored. (rebuilds done)");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
#    $ret = CheckSosTables( $coPtr, ( NOTFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }


    logInfo("Parity Scan at the end of the test.");

    $ret = TestLibs::BEUtils::PScanCheck( $coPtr, 0, INVALID );
    if ( $ret != GOOD )
    {
        logInfo("Parity scan reported an error - test cannot run.");
        return ERROR;
    }

    $ret = TestBEState($coPtr);
    if ( $ret != GOOD )
    {
        logInfo("This test requires all BE states to be good at the end");
        return ERROR;

    }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 37.");


    return GOOD;

}

###############################################################################
###############################################################################

=head2 BEStressCase38 function

This test case runs redi-copy and fails a pdisk at the end.
The test has these
basic steps...

     1) Redi-copy a vdisk (on the slave), wait for complete
     2) fail a pdisk - rebuilds start
     3) verify IO
     9) wait for rebuilds to end
    10) unfail pdisk
    11) check sos tables
    12) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase38( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 38, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 88, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase38
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#
#
##############################################################################
sub BEStressCase38
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;

    my @pdds;
    my $ret;
    my $newVd;
    my $newVd2;
    my $lc;
    my @oldVds;
    my $failedDisk;
    my $ses;
    my $slot;
    my $srcVdisk;

    my $lid;
    my $port;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 38: Redi-copy and defrag while doing a rebuild.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 38: Begin BEStress case 38" );

    #
    # check the number of controllers
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

    my $otherCtlr = 1;
    if ( $master == 1) { $otherCtlr = 0; }


    # get measure of the current IO

    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # redi-cp and defrag during rebuild.
    ######################################################################

    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # we will fail the 2nd one of these
    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }

    # Steps are 1) Redi-copy a vdisk, wait for complete
    # this makes sure there is space to defrag

    # find an early vdisk on the slave
    $srcVdisk = FirstVdiskOnCtlr($coPtr, \@initialVdisks, $otherCtlr, $snPtr);

    if ( $srcVdisk == INVALID ) { return ERROR; }

    # copy it to the end
    $newVd =  CreateReplacementVdisk($ctlr, $srcVdisk );
    if ( $newVd < 0 ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 38: Begin copy vdisk $srcVdisk  to vdisk $newVd " );

    $ret = RediCpVdisks($ctlr, $srcVdisk, $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    # let copy complete
    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }


    #           2) fail a pdisk - rebuilds start
    CtlrLogTextAll($coPtr, "Test Case 38: now failing pdd $pdds[1]" );

    $failedDisk =  $pdds[1];

    GetSesAndSlot ($ctlr, $failedDisk, \$ses, \$slot, \$lid, \$port);

    $ret = FailPdisk( $coPtr, $failedDisk, $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }


    CtlrLogTextAll($coPtr, "Test Case 38: I/O check after failing pdisk." );

    #           3) verify IO
    logInfo("Verify IO after failing the pdisk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }


    # if a hotspare was used, we need to relabel disks for
    # the next vdiskcreate (just data disks)



    $ret = FixPdiskLabels ($ctlr, DONTMAKEHOTSPARE);
    if ( $ret != GOOD ) { return ERROR; }

    #          11) wait for rebuild complete
    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    PSDCheck( $ctlr );



    #          11.3) check SOS tables
    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + ISFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 38: Unfailing pdisk." );

    # 13.5) unfail the drive
    $ret = UnfailPdisk($coPtr, $failedDisk, $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 38: Final I/O checks." );

    #          14) check sos tables - pobably fragmented
#    $ret = CheckSosTables( $coPtr, (SKIPVALIDATIONFAILURE + NOTFRAGMENTED) );
    $ret = CheckSosTables( $coPtr, ( SKIPVALIDATIONFAILURE + ISFRAGMENTED) );
    if ( $ret != GOOD ) { return ERROR; }

    #          15) verify IO

    logInfo("Verify IO after defrags finish");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    CtlrLogTextAll($coPtr, "Test Case 38: End of BEStress case 38." );

    logInfo("End of BE stress test case 38.");


    return GOOD;

}
###############################################################################
###############################################################################

=head2 BEStressCase39 function

This test case does many copy/swaps to debug a failure.
The test has these
basic steps...






=cut

=over 1

=item Usage:

 my $rc = BEStressCase39( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase39
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                LIPs the BE loops
#




#
##############################################################################
sub BEStressCase39
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
    my $srcVd;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;

#    my $newVd;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 39: Lots of copy/swaps.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    CtlrLogTextAll($coPtr, "Test Case 39: Lots of copy/swaps." );

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # copy swaps
    ######################################################################


    # setup - need to houseclean

    # first get rid of any unused vdisks
    DeleteUnusedVdisks( $ctlr, 0);

    # defrag all drives
    $ret = DefragAll($ctlr);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = CheckSosTables( $coPtr, NOTFRAGMENTED );
    if ( $ret != GOOD ) { return ERROR; }

    # verify IO is still good
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    # system is 'packed' ready for the test
    logInfo("Setup complete for test case 39.");

    ##############################
    # basic copy/swap
    ##############################

    CtlrLogTextAll($coPtr, "Test Case 39: First copy/swap" );
    

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 1 );     # find one vdisk
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    # copy it to the end
    $newVd =  CreateReplacementVdisk($ctlr, $oldVds[0] );
    if ( $newVd < 0 ) { return ERROR; }

    $ret = RediCpVdisks($ctlr, $oldVds[0], $newVd);
    if ( $ret != GOOD ) { return ERROR; }

    $ret = WaitForCpComplete( $ctlr, $newVd );
    if ( $ret != GOOD ) { return ERROR; }


    # delete the source ( the early vdisk )
    if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) )
    {
        logInfo("Unable to delete the source vdisk");
        return ERROR;
    }


    ##############################
    # loops on copy/swap
    ##############################

    # find an early vdisk
    @oldVds = FindEarlyVdisk( $ctlr, 22 );     # find 22 vdisks
    if ( $oldVds[0] == INVALID ) { return ERROR; }

    CtlrLogTextAll($coPtr, "Test Case 39: Copy/swap each vdisk" );

    foreach $srcVd (@oldVds)
    {
        # copy it to the end
        $newVd =  CreateReplacementVdisk($ctlr, $srcVd );
        if ( $newVd < 0 ) { return ERROR; }

        $ret = RediCpVdisks($ctlr, $srcVd, $newVd);
        if ( $ret != GOOD ) { return ERROR; }

        $ret = WaitForCpComplete( $ctlr, $newVd );
        if ( $ret != GOOD ) { return ERROR; }


        # delete the source ( the early vdisk )
        if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) )
        {
            logInfo("Unable to delete the source vdisk");
            return ERROR;
        }

    }

    my $j;

    for ( $j = 0; $j < 100; $j++ )
    {
        # find an early vdisk
        @oldVds = FindEarlyVdisk( $ctlr, 22 );     # find 22 vdisks
        if ( $oldVds[0] == INVALID ) { return ERROR; }

        CtlrLogTextAll($coPtr, "Test Case 39: Copy/swap Each vdisk, loop $j" );
        
        foreach $srcVd (@oldVds)
        {
            # copy it to the end
            $newVd =  CreateReplacementVdisk($ctlr, $srcVd );
            if ( $newVd < 0 ) { return ERROR; }

            $ret = RediCpVdisks($ctlr, $srcVd, $newVd);
            if ( $ret != GOOD ) { return ERROR; }

            $ret = WaitForCpComplete( $ctlr, $newVd );
            if ( $ret != GOOD ) { return ERROR; }


            # delete the source ( the early vdisk )
            if ( ERROR == DeleteSingleVdisk($ctlr, $newVd) )
            {
                logInfo("Unable to delete the source vdisk");
                return ERROR;
            }

        }

        logInfo("Verify IO after a group of copy/swaps");
        $ret = VerifyIO( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }


    }

    logInfo("Verify IO at end of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 39.");
    
    CtlrLogTextAll($coPtr, "End of BE stress test case 39." );

    return GOOD;

}
###############################################################################
###############################################################################

=head2 BEStressCase40 function

This test case repeatedly LIPs the BE qlogic cards.
The test has these
basic steps...






=cut

=over 1

=item Usage:

 my $rc = BEStressCase40( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase40
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                LIPs the BE loops
#




#
##############################################################################
sub BEStressCase40
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my $k;
    my $j;
    my %rsp;
    my $ret;
    my @pdds;
#    my $newVd;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 40: Alternate LIPs and I/O checks on the BE Qlogic cards.  --------";
    $msg0 = "-------------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # loops to LIP the BE cards.
    ######################################################################


    # Steps are 1) select the controller
    for ( $i = 0; $i < scalar(@$coPtr); $i++ )
    {

        $ctlr = $coList[$i];

        #           2) for 'n' loops
        for ( $j = 0; $j < $loopCount; $j++ )
        {

            #   sequentially LIP each QL card
            for ( $k = 0; $k < 4; $k++ )
            {

                $ret = ResetBELoop ($ctlr, $k );
                if ( $ret == ERROR )
                {
                    print ("\n");
                    logInfo("Error from ResetBELoop.");
                    return ERROR;
                }

                # do I/O between LIPs
                if ( $ret != INVALID )
                {
                    #  3) verify IO is still good

                    sleep(10);  # To allow system to recover before grabbing data
                    
                    logInfo("Verify IO after $loopCount loops sequentially LIPping the BE QLogic cards");
                    $ret = VerifyIO( $coPtr,
                                     \@activeServers,
                                     \@tMap,
                                     \@initialVdisks,
                                     $snPtr
                                   );
                    if ( $ret != GOOD ) { return ERROR; }

                }
            }

        }

    }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 40.");


    return GOOD;

}
###############################################################################

###############################################################################

=head2 BEStressCase41 function

This test case repeatedly powercycles a controller during a rebuild.
The test has these
basic steps...

     1) Locate a slave controller
     2) verify IO
     3) select a pdisk
     4) fail the pdisk
     5) confirm rebuild start
     6) for 'n' loops (while Rebuilds continuing)
           turn off  controller
           failover timeline
           verify IO
           turn on controller
           wait 2 minute (timeline?)
           verify IO
     8) wait for/verify rebuild is complete
     9) verify IO

=cut

=over 1

=item Usage:

 my $rc = BEStressCase41( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 41, the pdisks will be failed by spinning
 them down. This not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 91, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase41
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                Many power cycles on a controller during Rebuilds
#
# Steps are 1) Locate a slave controller
#           2) verify IO
#           3) select a pdisk
#           4) fail the pdisk
#           5) confirm rebuild start
#           6) while still rebuilding
#                 turn off controller
#                 wait 2 minutes (timeline?)
#                 verify IO
#                 turn on controller
#                 unfail the controller
#                 wait 2 minute (timeline?)
#                 verify IO
#           7) unfail the pdisk
#           8) verify IO
#
##############################################################################
sub BEStressCase41
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ses;
    my $slot;

    my $lid;
    my $port;

    my $slave;
    my $ret;
    my $i;
    my $lc;
    my %rsp;
    my @pdds;
    my $rebuildFlag;
    my $listSize;
    my $pddSelected;
    my $failthiscontroller;
    my $checkTimeout;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 41: Repeatedly fail/unfail a controller during rebuild.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # check the number of controllers
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers. Test case is skipped.");
        return ($retIn);
    }



    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # ensure there is a hot spare to run this test!
    @pdds = GetTheseDisks( $ctlr, CCBEHOTSPARETYPE);
    if ( $pdds[0] == INVALID)
    {
        logInfo("This Test Requires a Hotspare to work - none found = Exiting");
        return ERROR;
    }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     
 
    ######################################################################
    # fail/unfail on the slave controller, during a rebuild
    ######################################################################




    # Steps are 1) Locate a slave controller
    $slave = 1;
    if ( $master == 1 ) { $slave = 0; }


    #           2) verify IO
    logInfo("Verify IO at the beginning of the test");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    #
    # now we need to wait for the R5 resyncs to finish. Do this only if there
    # are raid 5 drives in the system.
    #

    if ( 1 == GotRaid5($coList[$master]) )
    {
        logInfo ( "Raid 5 configured in system, waiting for resyncs to complete.");

        # wait for resync to finish on all raids
        $ret = TestLibs::Validate::R5ResyncCheck( \@coList, 0, INVALID );
        if ( $ret != GOOD )
        {
            logInfo("R5 resync check reported an error - test failed.");
            return ERROR;
        }

    }

    #           3) select a pdisk
    # we will fail a random PDisk
    @pdds = GetDataDisks( $ctlr, FC_PREFERRED );
    if ( $pdds[0] == INVALID) { return ERROR; }

    #           4) fail a random pdisk
    $listSize =  scalar(@pdds);
    $pddSelected = randomInt(0, ($listSize - 1));

    CtlrLogTextAll($coPtr, "Test Case 41: now failing pdd $pdds[$pddSelected]" );

    GetSesAndSlot ($ctlr, $pdds[$pddSelected], \$ses, \$slot, \$lid, \$port);

    $ret = FailPdiskNoWait( $ctlr, $pdds[$pddSelected], $pDFailMeans );
    if ( $ret != GOOD ) { return ERROR; }

    #           5) confirm rebuild start
    logInfo("waiting up to 150 seconds for the rebuild to start");

    $checkTimeout = 150;                   # timeout after 2.5 minutes
    $rebuildFlag = DegradeCheckRunning($coList[0]);  # get current rebuild state
    #                 Ensure both controller are checked
    if ($rebuildFlag != INVALID)
    {
        $rebuildFlag = DegradeCheckRunning( $coList[1] );
    }


    while ( ( $checkTimeout > 0 ) &&          # not timed out and
         ( $rebuildFlag != INVALID) )              # not running
    {
        #
        # wait a second, decrement timeout and do
        # another check
        #
        sleep 1;                           # wait a second
        $checkTimeout--;
        $rebuildFlag = DegradeCheckRunning($coList[0]);  # get current rebuild state
        #                 Ensure both controller are checked
        if ($rebuildFlag != INVALID)
        {
            $rebuildFlag = DegradeCheckRunning( $coList[1] );
        }
    }

    if ($checkTimeout == 0)
    {
        logInfo("Rebuilding did not start in 150 seconds, aborting test!");
        return ERROR;
    }

    $i = 0;
    #           6) for 'n' loops (while Rebuilding)
    while ( ($rebuildFlag == INVALID) &&    # Still Rebuilding
            ($i < 10) )                     # Failover/Failback at most 10 times
    {
        #                 determine which controller to fail
        $failthiscontroller = randomInt(0,1);
        if ($failthiscontroller == 0)
        {
            $ctlr = $coList[1];
        }
        else
        {
            $ctlr = $coList[0];
        }

        #                 turn off controller
        CtlrLogTextAll($coPtr, "Test Case 41: now turning off $$coPtr[$failthiscontroller]->{HOST}" );
        $ret = PowerChange($$moxaIP[$failthiscontroller], $$mmPtr[$failthiscontroller], 0);
        if ( $ret != GOOD ) { return ERROR; }



        #                 wait 2 minutes (timeline?)
        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        #                 verify IO
        logInfo("Verify IO with controller turned off. Loop $i");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         0,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #                 turn on controller
        CtlrLogTextAll($coPtr, "Test Case 41: now turning on $$coPtr[$failthiscontroller]->{HOST}" );
        $ret = PowerChange($$moxaIP[$failthiscontroller], $$mmPtr[$failthiscontroller], 1);
        if ( $ret != GOOD ) { return ERROR; }

        # unfail the controller
        $ret = UnfailAll($coPtr, $snPtr, $moxaIP, $mmPtr );
        if ( $ret != GOOD ) { return ERROR; }


        #                 wait 2 minute (timeline?)
        $ret = FailOverTimeLine($ctlr, 120, $snPtr, 0 );
        if ( $ret != GOOD ) { return ERROR; }

        #                 verify IO
        logInfo("Verify IO with controller back on. Loop $i");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         0,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        $rebuildFlag = DegradeCheckRunning( $coList[0] );

        #                 Ensure both controller are checked
        if ($rebuildFlag != INVALID)
        {
            $rebuildFlag = DegradeCheckRunning( $coList[1] );
        }


        $i++;
    }

    #           7) wait for/verify rebuild is complete

    # find the new master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); }

    $ctlr = $coList[$master];

    # wait for rebuild to end
    # rebuild is done if no drives are 'degraded'

    logInfo("polling until rebuild finishes");
    $ret = INVALID;

    $lc = 0;
    while ( $ret != GOOD )
    {
        $lc++;
        logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

        $ret = DegradeCheck( $ctlr );
        if ( $ret == ERROR )
        {
            return ERROR;
        }
        DelaySecs( 15 );
    }


    # unfail the drive
    $ret = UnfailPdisk($coPtr, $pdds[$pddSelected], $ses, $slot, 0, $lid, $port);
    if ( $ret != GOOD ) { return ERROR; }


    $ret = FixPdiskLabels ($ctlr, 0);
    if ( $ret != GOOD ) { return ERROR; }



    #           8) verify IO


    logInfo("Verify IO at end of the test, after restoring the pdisk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 41.");

    return GOOD;

}


###############################################################################


###############################################################################

=head2 BEStressCase42 function

This test case powers off a controller, delays 0-10 secs, and then fails a pdisk.
The test will only execute if there are 2 or more controllers and 1 or more 
pdisks without any Raid-5 segments. 

The test has these basic steps...

     1) Power off a random controller
     2) Delay random 0-10 secs  
     3) Fail a random non Raid-5 pdisk
     4) Failover timeline
     5) Verify IO
     6) Wait for rebuild to complete
     7) Power on controller
     8) Reconnect to and unfail controller
     9) Verify IO
    10) Unfail pdisk
    11) Verify IO
    12) Repeat loopCount times
      
=cut

=over 1

=item Usage:

 my $rc = BEStressCase42( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is a pointer to a list of moxa IP addresses
        $mmPtr is a pointer to the mapping of the moxa channels 
        $loopCount is the number of times to perform the internal test loop
        $pDFailMeans determines how the pdisk will be failed
        
=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 42, the pdisks will be failed by spinning
 them down. This does not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 92, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 There must be 2 or more controllers and 1 or more pdisks without any 
 Raid-5 segments.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase42
#
#        Inputs: $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: This test case powers off a controller, delays 0-10 secs,
#   and then fails a pdisk.
#
# Steps are 1) Power off a random controller
#           2) Delay random 0-10 secs  
#           3) Fail a random non Raid-5 pdisk
#           4) Failover timeline
#           5) Verify IO
#           6) Wait for rebuild to complete
#           7) Power on controller
#           8) Reconnect to and unfail controller
#           9) Verify IO
#          10) Unfail pdisk
#          11) Verify IO
#          12) Repeat loopCount times
#
##############################################################################
sub BEStressCase42
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList = @$coPtr;
    my @snList = @$snPtr;
    my $numCtlrs = scalar(@coList);
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlr1Index;
    my $ctlr2Index;
    my $ctlr1;
    my $ctlr2;
    my $victimIndex;
    my $victim;
    my $ses;
    my $slot;
    my $lid;
    my $port;
    my $delay;

    my $ret;
    my $i;
    my $j;
    my @dataDisks;
    my @deadList;
    my $numDataDisks;
    my @nonRaid5DataDisks;
    my $numNonRaid5DataDisks;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    
    #
    # If $retIn is not GOOD, we're outa here.
    #
    if ( $retIn != GOOD ) 
    {
        return $retIn;
    }

    $msg = "------ Test Case 42: Power off a controller and then fail a pdisk  ----------";
    $msg0 = "-----------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    #
    # Make sure we have enough controllers to do this test.
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers.  Test case is skipped.");
        return ($retIn);
    }

    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

   
    #
    # Get a list of all the data disks
    #
    @dataDisks = GetDataDisks( $ctlr );
    if ( $dataDisks[0] == INVALID) { return ERROR; }

    $numDataDisks = scalar(@dataDisks);
    
    #
    # **** NOTE ****
    # If you fail a controller and a pdisk at the same time and that pdisk 
    # has one or more RAID-5 raids on it, it is possible to get into a state 
    # where the corresponding vdisk will go inoperable.  This will occur if 
    # the failed controller owned the vdisk and if a write was in progress
    # to that vdisk when the failures occur.  
    #
 
    #
    # Check if there are any RAID-5 raids on our system
    # 
    if ( GotRaid5($ctlr) )
    {
        $numNonRaid5DataDisks = 0;
        # 
        # Go thru each data disk and see if there are any that do NOT have
        # any RAID-5 segments
        #
        for ( $i = 0; $i < $numDataDisks; $i++ )
        {
            $ret = PdiskGotRaid($ctlr, $dataDisks[$i], RAID_5);
            if ( $ret == INVALID )
            {
                logInfo(">>>>>>>> PdiskGotRaid failed for pdisk $dataDisks[$i]) <<<<<<<<");
                return ERROR;
            }
            if ( $ret == TRUE )
            {
                next;
            }
            $nonRaid5DataDisks[$numNonRaid5DataDisks] = $dataDisks[$i]; 
            $numNonRaid5DataDisks++;
        }
    }   
    else
    {
        @nonRaid5DataDisks = @dataDisks; 
        $numNonRaid5DataDisks = $numDataDisks;
    }

    logInfo("Available pdisks without any Raid-5 segments:  @nonRaid5DataDisks");

  
    # 
    # If there is not at least one non RAID-5 pdisk, then exit
    #
    if ( $numNonRaid5DataDisks == 0 )
    {
        logInfo("This test case requires at least one pdisk without any Raid 5 segments.");
        logInfo("All pdisks have one or more Raid 5 segments.  Test case is skipped.");
        return ($retIn);
    }
    
    #
    # Log current vdisk info
    #
    $ret = DispVdiskInfo($ctlr);
    if ( $ret != GOOD ) { return ERROR; }
   
    #
    # Get measure of the current IO
    #
    @vCounts = GetVdiskActivityCounts($coPtr);
    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause to allow activity to accumulate");
    DelaySecs(20);

    #
    # Display target map
    #
    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }

    #
    # Get the initial active vdisks for the test
    #
    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }

    #
    # Loop thru the test $loopCount times
    #
    for ( $j = 0; $j < $loopCount; $j++ )
    {
        #
        # Select a controller to power off and a different one to use to fail the  
        # pdisk. 
        #
        $ctlr1Index = int( rand($numCtlrs) );
        
        $ctlr2Index = $ctlr1Index;
        while ( $ctlr2Index == $ctlr1Index )
        {
            $ctlr2Index = int( rand($numCtlrs) );
        } 

        $ctlr1 = $coList[$ctlr1Index];
        $ctlr2 = $coList[$ctlr2Index];

        # 
        # Get info on the data disk we want to fail 
        #
        $victimIndex = int( rand($numNonRaid5DataDisks) ); 
        $victim = $nonRaid5DataDisks[$victimIndex]; 

        GetSesAndSlot ($ctlr, $victim, \$ses, \$slot, \$lid, \$port);

        #
        # Select random delay between power off and pdisk fail
        #
        $delay = int( rand(11) );

        #
        # Power off the controller and then fail the pdisk.
        #
        CtlrLogTextAll($coPtr, "Test Case 42: Turn off $ctlr2->{HOST}, delay $delay secs, then fail pdisk $victim" );
        
        $ret = PowerChange( $$moxaIP[$ctlr2Index], $$mmPtr[$ctlr2Index], 0 );
        if ( $ret != GOOD ) { return ERROR; }

        sleep( $delay );
        
        #
        # If the fail option is bypass, have to call PDiskBypass directly with 
        # SES and Slot as FailPdiskNoWait may fail getting valid SES and Slot 
        # data due to the power off of controller 
        #
        if ( $pDFailMeans == PDISKBYPASS )
        {
            $ret = PdiskBypass($ctlr1, $ses, $slot, 0xC);
            if ( $ret != GOOD ) { return ERROR; }
        }
        else
        {
            $ret = FailPdiskNoWait( $ctlr1, $victim, $pDFailMeans );
            if ( $ret != GOOD ) { return ERROR; }
        }
        
        #
        # Failover timeline
        #
        @deadList = ($ctlr2Index);
        FailOverTimeLineNway( $coPtr, 120, $snPtr, \@deadList);

        #
        # Verify IO
        #
        logInfo("Verify IO after failing the controller");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         0,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Find the new master
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) { return(ERROR); }
        $ctlr = $coList[$master];

        #
        # Wait for rebuilds to finish if they haven't already
        #
        $ret = WaitRebuild( $ctlr );
        if ( $ret != GOOD ) 
        { 
            logInfo(">>>>>>>> WaitRebuild Failed <<<<<<<<");
            return ERROR; 
        }
     
        #
        # Power controller back on 
        #
        CtlrLogText($$coPtr[$master], "Test Case 42: now turning on $ctlr2->{HOST}" );
        $ret = PowerChange($$moxaIP[$ctlr2Index], $$mmPtr[$ctlr2Index], 1);
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Wait 60 seconds and then reconnect to controller
        #
        logInfo("Pause for 60 seconds and reconnect to controller $ctlr2->{HOST} ");
        $ret = Reconnect( $ctlr2, 60 );
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> Failed to reconnect to the controller    <<<<<<<<");
            return ERROR;
        }

        #
        # Wait until controller completes power up
        #
        $ret = Wait4MinPowerUpState($ctlr2, POWER_UP_FAILED, 120);          
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Unfail controller
        #
        $ret = UnFailController( $ctlr, $snList[$ctlr2Index] );
        if ( $ret != GOOD ) { return ERROR; }

        @deadList = (INVALID);
        FailOverTimeLineNway( $coPtr, 120, $snPtr, \@deadList);

        #
        # Verify IO after unfailing controller
        #
        logInfo("Verify IO after restoring the controller");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Find the master controller
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) { return(ERROR); }

        $ctlr = $coList[$master];

        #
        # Unfail the drive
        #
        $ret = UnfailPdisk($coPtr, $victim, $ses, $slot, 0, $lid, $port);
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Clean up the labels
        #
        $ret = FixPdiskLabels ($ctlr, 0);
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Verify IO one last time after unfailing pdisks
        #
        logInfo("Verify IO at end of the test, after restoring the pdisk");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }
    }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 42.");

    return GOOD;

}


###############################################################################

###############################################################################

=head2 BEStressCase43 function

This test case fails a pdisk, delays 0-10 sec, then powers off a controller.
The test will only execute if there are 2 or more controllers and 1 or more 
pdisks without any Raid-5 segments. 

The test has these basic steps...

     1) Fail a random non Raid-5 pdisk
     2) Delay random 0-10 secs  
     1) Power off a random controller
     4) Failover timeline
     5) Verify IO
     6) Wait for rebuild to complete
     7) Power on controller
     8) Reconnect to and unfail controller
     9) Verify IO
    10) Unfail pdisk
    11) Verify IO
    12) Repeat loopCount times
      
=cut

=over 1

=item Usage:

 my $rc = BEStressCase43( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is a pointer to a list of moxa IP addresses
        $mmPtr is a pointer to the mapping of the moxa channels 
        $loopCount is the number of times to perform the internal test loop
        $pDFailMeans determines how the pdisk will be failed
        
=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

 When invoked as test case 43, the pdisks will be failed by spinning
 them down. This does not guarantee a hotspare as the controller will
 probably spin the drive up and rebuild it. When invoked as test case
 93, the pdisk being failed will be bypassed. This will force a hotspare
 if the drive is active.


=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 There must be 2 or more controllers and 1 or more pdisks without any 
 Raid-5 segments.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCase43
#
#        Inputs: $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: This test case fails a pdisk, delays 0-10 secs, then powers
#                off a controller.
#
# Steps are 1) Fail a random non Raid-5 pdisk
#           2) Delay random 0-10 secs  
#           3) Power off a random controller
#           4) Failover timeline
#           5) Verify IO
#           6) Wait for rebuild to complete
#           7) Power on controller
#           8) Reconnect to and unfail controller
#           9) Verify IO
#          10) Unfail pdisk
#          11) Verify IO
#          12) Repeat loopCount times
#
##############################################################################
sub BEStressCase43
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $loopCount, $pDFailMeans ) = @_;

    my $msg;
    my $msg0;
    my $master;
    my @coList = @$coPtr;
    my @snList = @$snPtr;
    my $numCtlrs = scalar(@coList);
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ctlr1Index;
    my $ctlr2Index;
    my $ctlr1;
    my $ctlr2;
    my $victimIndex;
    my $victim;
    my $ses;
    my $slot;
    my $delay;

    my $ret;
    my $i;
    my $j;
    my @dataDisks;
    my @deadList;
    my $numDataDisks;
    my @nonRaid5DataDisks;
    my $numNonRaid5DataDisks;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;
    
    #
    # If $retIn is not GOOD, we're outa here.
    #
    if ( $retIn != GOOD ) 
    {
        return $retIn;
    }

    $msg = "------ Test Case 43: Fail a pdisk and then power off a controller  ----------";
    $msg0 = "-----------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    #
    # Make sure we have enough controllers to do this test.
    #
    if ( scalar(@$coPtr) < 2 )
    {
        logInfo("This test case requires multiple controllers.  Test case is skipped.");
        return ($retIn);
    }
    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }

   
    #
    # Get a list of all the data disks
    #
    @dataDisks = GetDataDisks( $ctlr );
    if ( $dataDisks[0] == INVALID) { return ERROR; }

    $numDataDisks = scalar(@dataDisks);
    
    #
    # **** NOTE ****
    # If you fail a controller and a pdisk at the same time and that pdisk 
    # has one or more RAID-5 raids on it, it is possible to get into a state 
    # where the corresponding vdisk will go inoperable.  This will occur if 
    # the failed controller owned the vdisk and if a write was in progress
    # to that vdisk when the failures occur.  
    #
 
    #
    # Check if there are any RAID-5 raids on our system
    # 
    if ( GotRaid5($ctlr) )
    {
        $numNonRaid5DataDisks = 0;
        # 
        # Go thru each data disk and see if there are any that do NOT have
        # any RAID-5 segments
        #
        for ( $i = 0; $i < $numDataDisks; $i++ )
        {
            $ret = PdiskGotRaid($ctlr, $dataDisks[$i], RAID_5);
            if ( $ret == INVALID )
            {
                logInfo(">>>>>>>> PdiskGotRaid failed for pdisk $dataDisks[$i]) <<<<<<<<");
                return ERROR;
            }
            if ( $ret == TRUE )
            {
                next;
            }
            $nonRaid5DataDisks[$numNonRaid5DataDisks] = $dataDisks[$i]; 
            $numNonRaid5DataDisks++;
        }
    }   
    else
    {
        @nonRaid5DataDisks = @dataDisks; 
        $numNonRaid5DataDisks = $numDataDisks;
    }

    logInfo("Available pdisks without any Raid-5 segments:  @nonRaid5DataDisks");

  
    # 
    # If there is not at least one non RAID-5 pdisk, then exit
    #
    if ( $numNonRaid5DataDisks == 0 )
    {
        logInfo("This test case requires at least one pdisk without any Raid 5 segments.");
        logInfo("All pdisks have one or more Raid 5 segments.  Test case is skipped.");
        return ($retIn);
    }
    
    #
    # Log current vdisk info
    #
    $ret = DispVdiskInfo($ctlr);
    if ( $ret != GOOD ) { return ERROR; }
   
    #
    # Get measure of the current IO
    #
    @vCounts = GetVdiskActivityCounts($coPtr);
    @sCounts = GetServerActivityCounts($coPtr);

    logInfo("Pause 20 secs to allow activity to accumulate");
    DelaySecs(20);

    #
    # Display target map
    #
    $ret = GroupTargetMap($coPtr, $snPtr, \@tMap, $master, LOGTARGETMAP + LOGTARGETSTATUS);
    if ( $ret != GOOD )  {return ERROR; }

    #
    # Get the initial active vdisks for the test
    #
    logInfo("Generating Activity Information");

    @activeServers = MakeActiveServerMap( $coPtr,  \@sCounts, 10 );
    if (scalar(@activeServers) > 0 )
    {
        if ( $activeServers[0] == INVALID ) { return ERROR; }
    }

    @initialVdisks = MakeActiveVdiskMap( $coPtr,  \@vCounts, 10 );
    if (scalar(@initialVdisks) > 0 )
    {
        if ( $initialVdisks[0] == INVALID ) { return ERROR; }
    }

    #
    # Loop thru the test $loopCount times
    #
    for ( $j = 0; $j < $loopCount; $j++ )
    {
        #
        # Select a controller to power off and one to use to fail the  
        # pdisk (can be same or different). 
        #
        $ctlr1Index = int( rand($numCtlrs) );
        $ctlr2Index = int( rand($numCtlrs) );
        $ctlr1 = $coList[$ctlr1Index];
        $ctlr2 = $coList[$ctlr2Index];

        # 
        # Get info on the data disk we want to fail 
        #
        $victimIndex = int( rand($numNonRaid5DataDisks) ); 
        $victim = $nonRaid5DataDisks[$victimIndex]; 
        GetSesAndSlot ($ctlr, $victim, \$ses, \$slot);

        #
        # Select random delay between power off and pdisk fail
        #
        $delay = int( rand(11) );

        #
        # Log info to controllers
        #
        CtlrLogTextAll($coPtr, "Test Case 43:  Fail pdisk $victim, delay $delay secs, then turn off $ctlr2->{HOST}" );

        #
        # Fail the pdisk and delay.
        #
        $ret = FailPdiskNoWait( $ctlr, $victim, $pDFailMeans );
        if ( $ret != GOOD ) { return ERROR; }

        sleep( $delay );

        #
        # Power off the controller 
        #
        $ret = PowerChange( $$moxaIP[$ctlr2Index], $$mmPtr[$ctlr2Index], 0 );
        if ( $ret != GOOD ) { return ERROR; }
        
        #
        # Failover timeline
        #
        @deadList = ($ctlr2Index);
        FailOverTimeLineNway( $coPtr, 120, $snPtr, \@deadList);

        #
        # Verify IO
        #
        logInfo("Verify IO after failing the controller");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         0,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Find the new master
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) { return(ERROR); }
        $ctlr = $coList[$master];

        #
        # Wait for rebuilds to finish if they haven't already
        #
        $ret = WaitRebuild( $ctlr );
        if ( $ret != GOOD ) 
        { 
            logInfo(">>>>>>>> WaitRebuild Failed <<<<<<<<");
            return ERROR; 
        }
     
        #
        # Power controller back on 
        #
        CtlrLogText($$coPtr[$master], "Test Case 43: now turning on $ctlr2->{HOST}" );
        $ret = PowerChange($$moxaIP[$ctlr2Index], $$mmPtr[$ctlr2Index], 1);
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Wait 60 seconds and then reconnect to controller
        #
        logInfo("Pause for 60 seconds and reconnect to controller $ctlr2->{HOST} ");
        $ret = Reconnect( $ctlr2, 60 );
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> Failed to reconnect to the controller    <<<<<<<<");
            return ERROR;
        }

        #
        # Wait until controller completes power up
        #
        $ret = Wait4MinPowerUpState($ctlr2, POWER_UP_FAILED, 120);          
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Unfail controller
        #
        $ret = UnFailController( $ctlr, $snList[$ctlr2Index] );
        if ( $ret != GOOD ) { return ERROR; }

        @deadList = (INVALID);
        FailOverTimeLineNway( $coPtr, 120, $snPtr, \@deadList);

        #
        # Verify IO after unfailing controller
        #
        logInfo("Verify IO after restoring the controller");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Find the master controller
        #
        $master = FindMaster( $coPtr );
        if ( $master == INVALID ) { return(ERROR); }

        $ctlr = $coList[$master];

        #
        # Unfail the drive
        #
        $ret = UnfailPdisk($coPtr, $victim, $ses, $slot);
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Clean up the labels
        #
        $ret = FixPdiskLabels ($ctlr, 0);
        if ( $ret != GOOD ) { return ERROR; }

        #
        # Verify IO one last time after unfailing pdisks
        #
        logInfo("Verify IO at end of the test, after restoring the pdisk");
        $ret = TestSystemState1( $coPtr,
                         \@activeServers,
                         \@tMap,
                         \@initialVdisks,
                         $snPtr
                       );
        if ( $ret != GOOD ) { return ERROR; }
    }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 43.");

    return GOOD;

}


###############################################################################





###############################################################################
###############################################################################


###############################################################################




###############################################################################


###############################################################################


###############################################################################
###############################################################################


###############################################################################

=head2 BEStressCaseX function

This test case repeatedly LIPs the BE qlogic cards.
The test has these
basic steps...






=cut

=over 1

=item Usage:

 my $rc = BEStressCaseX( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans   );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $loopCount determines how many test loops are done

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:

 There should be no unexpected messages in the logs.
 The script should end without errors showing on the screen.

=item Initial Conditions:

 The system needs to be configured with a number of vdisks and IO running.
 It is not necessary to 'clean up' between calls to this function.

 There should be no defrag, copy, or init operation running when the test
 is started.




=back

=cut

##############################################################################
#
#          Name: BEStressCaseX
#
#        Inputs: $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Assumes this is called with no inits or defrags running.
#                I/O may be running, but not a requirement.
#
#                LIPs the BE loops
#




#
##############################################################################
sub BEStressCaseX
{
    trace();
    my ( $coPtr, $retIn, $snPtr, $loopCount, $pDFailMeans ) = @_;

    my $lc;
    my @hotSpares;
    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts;
    my @sCounts;
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my @oldVds;
    my $newVd;
    my @newVds;
    my $i;
    my %rsp;
    my $ret;
    my @pdds;
#    my $newVd;
    my %mirrorData;
    my $MRWTimeout = DEFAULT_MRW_TIMEOUT;


    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }

    $msg = "------ Test Case 7: Lots of LIPs on the BE Qlogic cards.  --------";
    $msg0 = "------------------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);


    # find the master controller

    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    @coList = @$coPtr;
    $ctlr = $coList[$master];
    
    #
    # Execute cleanup and data collection at start
    #
    $ret = TestPrep4MirrorCheck($coPtr, $master, $MRWTimeout, \%mirrorData);
    if ( $ret != GOOD ) { return ERROR; }


    # get measure of the current IO


    $ret = VerifyIOGather($coPtr, $snPtr, $master, \@activeServers, \@initialVdisks, 
                                  \@tMap, 20, 10);
     


    ######################################################################
    # loops to LIP the BE cards.
    ######################################################################


#add code here

    #   10) Verify IO

    logInfo("Verify IO at end of the test, after restoring the disk");
    $ret = VerifyIO( $coPtr,
                     \@activeServers,
                     \@tMap,
                     \@initialVdisks,
                     $snPtr
                   );
    if ( $ret != GOOD ) { return ERROR; }

    $ret = TestEndMirrorCheck($coPtr, $MRWTimeout, \%mirrorData );   
    if ( $ret != GOOD ) { return ERROR; }
    
    logInfo("End of BE stress test case 7.");


    return GOOD;

}
###############################################################################



###############################################################################

=head2 BEStressEntry function

The primary entry point for the Bigfoot BE stress tests.

A function used for debugging the code as a generic entry. The final
parameter represents the test case to be run. A test case of 99 will
run most tests sequentially. There is no guarantee that the tests can actually
run sequentially and give full coverage.

The test system should be configured as desired and IO from the
servers should be running. Most likely this will mean a two-way system.
IO from the servers needs to be consistent over time or the IO validation
checks may fail. For the most part, RAIDs should be redundant as many tests
will fail pdisks and require rebuilds. The test will hang if a drive
becomes permanently degraded.

Tests can be run individually by specifying the test case number. ( 1...25+)
Not all test case numbers exist ( the list is not contiguous). Specifying
an invalid number just means no test will be run. Test case 99 will run most
test cases sequentially. Test that are designed to cause a fatal condition
will not be part of the 99 sequence.

Some test require a minimum of a 2 way configuration, others will run on
1-way or n-way configurations.

Refer to the individual test cases for more information on the
individual tests.

=cut

=over 1

=item Usage:

 my $rc = BEStressEntry($coPtr, $retIn, $snPtr, $moxaPtr, $mmPtr, $case );

 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaPtr is a pointer to a list of Moxa controller IP addresses
        $mmPtr is a pointer to a list of tha Moxa channel mappings
        $case is the test case to run

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the test(s)
           ran to completion without error. Test logs must be reviewed to
           ensure the test ran correctly.



=back

=cut


##############################################################################
#
#          Name: BEStressEntry
#
#        Inputs:
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:
#
##############################################################################
sub BEStressEntry
{
    trace();
    my ( $coPtr,  $snPtr, $moxaIP, $mmPtr, $wwnPtr, $ipPtr, $case, $loopCount ) = @_;

    my $ret;
    my $autoLoop;

    $autoLoop = 0;
    $ret = GOOD;



    my @coList = @$coPtr;

    my $productID =  getMagProductID( 0, $coList[0]);

    if ( !$loopCount )
    {
        logInfo("LoopCount was not specified, default values will be used.");
        $autoLoop = 1;
    }

    if ( $case == 99 )
    {
        logInfo("All test cases selected, default loop count values will be used.");
        $autoLoop = 1;
    }


    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "                starting BEStress Case $case. ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
 #   DelaySecs(300);

    StatsProcAll($coPtr);

    if ( $productID == 2750 )
    {

        if ( $case==1   || $case == 99 ) { $ret = BEStressCase01(  $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==2   || $case == 99 ) { $ret = BEStressCase02(  $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==8   || $case == 99 ) { $ret = BEStressCase08(  $coPtr, GOOD, $snPtr, $loopCount, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==9   || $case == 99 ) { $ret = BEStressCase09(  $coPtr, GOOD, $snPtr, $loopCount, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==10  || $case == 99 ) { $ret = BEStressCase10( $coPtr, GOOD, $snPtr, $loopCount, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 5; }
        if ( $case==11  || $case == 99 ) { $ret = BEStressCase11( $coPtr, GOOD, $snPtr, $loopCount, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==13  || $case == 99 ) { $ret = BEStressCase13( $coPtr, GOOD, $snPtr , PDISKFAIL ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==15  || $case == 99 ) { $ret = BEStressCase15( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==17  || $case == 99 ) { $ret = BEStressCase17( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==19  || $case == 99 ) { $ret = BEStressCase19( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==20  || $case == 99 ) { $ret = BEStressCase20( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 3; }
        if ( $case==21  || $case == 99 ) { $ret = BEStressCase21( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $autoLoop == 1 ) { $loopCount = 3; }
        if ( $case==22  || $case == 99 ) { $ret = BEStressCase22( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKFAIL   ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==23  || $case == 99 ) { $ret = BEStressCase23( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==28  || $case == 99 ) { $ret = BEStressCase28( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==31  || $case == 99 ) { $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }
        
        if ( $case==34  || $case == 99 ) { $ret = BEStressCase34( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==35  || $case == 99 ) { $ret = BEStressCase35( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==36  || $case == 99 ) { $ret = BEStressCase36( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

        if ( $case==37  || $case == 99 ) { $ret = BEStressCase37( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }
        
        if ( $case==39  || $case == 99 ) { $ret = BEStressCase39( $coPtr, GOOD, $snPtr, PDISKFAIL  ); }
        if ( $ret != GOOD ) { return $ret; }

    }
    else
    {


    #############################################
    #
    # These test cases fail a pisk via SPIN DOWN
    #
    #############################################

    if ( $case==28  || $case == 99 ) { $ret = BEStressCase28( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }


    if ( $case==1   || $case == 99 ) { $ret = BEStressCase01(  $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==2   || $case == 99 ) { $ret = BEStressCase02(  $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==6   || $case == 99 ) { $ret = BEStressCase06(  $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==7   || $case == 99 ) { $ret = BEStressCase07(  $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==8   || $case == 99 ) { $ret = BEStressCase08(  $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==9   || $case == 99 ) { $ret = BEStressCase09(  $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
    if ( $ret != GOOD )
    {

        TestLibs::IntegCCBELib::ErrorTrapController($coList[0], "BE");

        return $ret;
    }


    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==10  || $case == 99 ) { $ret = BEStressCase10( $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==11  || $case == 99 ) { $ret = BEStressCase11( $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==12  || $case == 99 ) { $ret = BEStressCase12( $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==13  || $case == 99 ) { $ret = BEStressCase13( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    # 14 (spindown version only) fails due to limitation in BE robustness (Defect #11303).  No plans to correct at this time.
    if ( $case==14 ) { $ret = BEStressCase14( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==15  || $case == 99 ) { $ret = BEStressCase15( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

#    if ( $case==16  || $case == 99 ) { $ret = BEStressCase16( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
#    if ( $ret != GOOD ) { return $ret; }

    if ( $case==17  || $case == 99 ) { $ret = BEStressCase17( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

#    if ( $case==18  || $case == 99 ) { $ret = BEStressCase18( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
#    if ( $ret != GOOD ) { return $ret; }

    if ( $case==19  || $case == 99 ) { $ret = BEStressCase19( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==20  || $case == 99 ) { $ret = BEStressCase20( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 3; }
    if ( $case==21  || $case == 99 ) { $ret = BEStressCase21( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 3; }
    if ( $case==22  || $case == 99 ) { $ret = BEStressCase22( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==23  || $case == 99 ) { $ret = BEStressCase23( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }


    if ( $autoLoop == 1 ) { $loopCount = 1000; }
    if ( $case==24   ) { $ret = BEStressCase24( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 50; }
    if ( $case==25   ) { $ret = BEStressCase25( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 50; }
    if ( $case==26   ) { $ret = BEStressCase26( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
    if ( $ret != GOOD ) { return $ret; }


    if ( $case==31  || $case == 99 )
    {
        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
#        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKSPINDOWN  );
    }
    if ( $ret != GOOD ) { return $ret; }

    # test cases 32, 33, 34 are done without IO

    if ( $case == 32 ) { $ret = BEStressCase32(  $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 33 ) { $ret = BEStressCase33(  $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 34 ) { $ret = BEStressCase34(  $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 35 || $case == 99 ) { $ret = BEStressCase35(  $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 36 || $case == 99 ) { $ret = BEStressCase36(  $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 37 || $case == 99 ) { $ret = BEStressCase37(  $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 38 || $case == 99 ) { $ret = BEStressCase38(  $coPtr, GOOD, $snPtr, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 39  ) { $ret = BEStressCase39(  $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 40  ) { $ret = BEStressCase40(  $coPtr, GOOD, $snPtr, $loopCount, PDISKSPINDOWN   ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 3; }
    if ( $case==41  ) { $ret = BEStressCase41( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
    if ( $ret != GOOD ) { return $ret; }

    # 42 (spindown version only) fails due to limitation in BE robustness (Defect #11303).  No plans to correct at this time.
    if ( $autoLoop == 1 ) { $loopCount = 10; }
    if ( $case==42 ) { $ret = BEStressCase42( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 10; }
    if ( $case==43 || $case == 99 ) { $ret = BEStressCase43( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKSPINDOWN   ); }
    if ( $ret != GOOD ) { return $ret; }

    #############################################
    #
    # These test cases fail a pisk via BYPASS
    #
    #############################################

    if ( $case==78  || $case == 99 ) { $ret = BEStressCase28( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==51   || $case == 99 ) { $ret = BEStressCase01(  $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==52   || $case == 99 ) { $ret = BEStressCase02(  $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==56   || $case == 99 ) { $ret = BEStressCase06(  $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==57   || $case == 99 ) { $ret = BEStressCase07(  $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==58   || $case == 99 ) { $ret = BEStressCase08(  $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==59   || $case == 99 ) { $ret = BEStressCase09(  $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==60  || $case == 99 ) { $ret = BEStressCase10( $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==61  || $case == 99 ) { $ret = BEStressCase11( $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 5; }
    if ( $case==62  || $case == 99 ) { $ret = BEStressCase12( $coPtr, GOOD, $snPtr, $loopCount, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==63  || $case == 99 ) { $ret = BEStressCase13( $coPtr, GOOD, $snPtr , PDISKBYPASS ); }
    if ( $ret != GOOD ) { return $ret; }

    # 14 fails due to bug 7803. to be fixed for release 2. Till then, not in all.
    if ( $case==64  || $case == 99 ) { $ret = BEStressCase14( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==65  || $case == 99 ) { $ret = BEStressCase15( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

#    if ( $case==66  || $case == 99 ) { $ret = BEStressCase16( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
#    if ( $ret != GOOD ) { return $ret; }

    if ( $case==67  || $case == 99 ) { $ret = BEStressCase17( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

#    if ( $case==68  || $case == 99 ) { $ret = BEStressCase18( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
#    if ( $ret != GOOD ) { return $ret; }

    if ( $case==69  || $case == 99 ) { $ret = BEStressCase19( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==70  || $case == 99 ) { $ret = BEStressCase20( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 3; }
    if ( $case==71  || $case == 99 ) { $ret = BEStressCase21( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 3; }
    if ( $case==72  || $case == 99 ) { $ret = BEStressCase22( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==73  || $case == 99 ) { $ret = BEStressCase23( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }


    if ( $autoLoop == 1 ) { $loopCount = 1000; }
    if ( $case==74   ) { $ret = BEStressCase24( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 50; }
    if ( $case==75   ) { $ret = BEStressCase25( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 50; }
    if ( $case==76   ) { $ret = BEStressCase26( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
    if ( $ret != GOOD ) { return $ret; }


    if ( $case==81  || $case == 99 )
    {
        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  );
        $ret = BEStressCase31( $coPtr, GOOD, $snPtr, PDISKBYPASS  );
    }
    if ( $ret != GOOD ) { return $ret; }


    if ( $case==85  || $case == 99 ) { $ret = BEStressCase35( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==86  || $case == 99 ) { $ret = BEStressCase36( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case==87  || $case == 99 ) { $ret = BEStressCase37( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }


    if ( $case==88  || $case == 99 ) { $ret = BEStressCase38( $coPtr, GOOD, $snPtr, PDISKBYPASS  ); }
    if ( $ret != GOOD ) { return $ret; }


    if ( $autoLoop == 1 ) { $loopCount = 3; }
    if ( $case==91   ) { $ret = BEStressCase41( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 10; }
    if ( $case==92 || $case == 99 ) { $ret = BEStressCase42( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
    if ( $ret != GOOD ) { return $ret; }

    if ( $autoLoop == 1 ) { $loopCount = 10; }
    if ( $case==93 || $case == 99 ) { $ret = BEStressCase43( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, $loopCount, PDISKBYPASS   ); }
    if ( $ret != GOOD ) { return $ret; }



    # special cases, not part of 'all'



    if ( $case == 115 )
    {
        while(1)
        {
            $ret = BEStressCase15( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, PDISKSPINDOWN     );
        }
    }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 119 )
    {
        while(1)
        {
            $ret = BEStressCase19( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, PDISKSPINDOWN     );
        }
    }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 116 )
    {
        while(1)
        {
            $ret = BEStressCase15( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, PDISKSPINDOWN     );
            $ret = BEStressCase19( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr, PDISKSPINDOWN     );

        }
    }
    if ( $ret != GOOD ) { return $ret; }

    if ( $case == 222 )
    {
        while(1)
        {
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );
            $ret = BEStressCase02( $coPtr, GOOD, $snPtr, PDISKSPINDOWN     );

        }
    }
    if ( $ret != GOOD ) { return $ret; }
    } # end of else

    StatsProcAll($coPtr);
    PeriodicDataGather($coPtr);

    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
    CtlrLogTextAll( $coPtr, "           BEStress Case $case ends. ");
    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
#    DelaySecs(300);

    return $ret;

}


##############################################################################
#
#          Name: Support Functions
#
#  These are probably not exported.
#
##############################################################################

###############################################################################


###############################################################################


###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################


###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################



###############################################################################




###############################################################################



###############################################################################





###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################


###############################################################################

###############################################################################


##############################################################################


1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.2  2006/08/01 11:12:41  AnasuriG
# TBolt00015075
# Added changes for PDISKFAIL
#
# Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
# import CT1_BR to shared/Wookiee
#
# Revision 1.62  2005/03/14 00:02:55  PalmiD
# TBolt00000000: Fixed typos which occurred during a block copy (FailPdisk to
# FailPdiskNoWait).
# Reviewed by Allen Kohlmeyer.
#
# Revision 1.61  2005/03/09 19:30:54  PalmiD
# TBolt00000000: Replaced FailPdisk with FailPdiskNoWait to speed up BEStress32,
# BEStress33 and BEStress34.
# Reviewed by Craig Menning.
#
# Revision 1.60  2005/02/08 15:14:02  PalmiD
# TBolt00000000: Added delay to allow system to recover before grabbing data.
# Reviewed by Craig Menning.
#
# Revision 1.59  2004/12/15 22:16:23  KohlmeyerA
# Tbolt00000000:  Removed tests 14 and 42 from 99.
# Reviewed by Craig.
#
# Revision 1.58  2004/11/22 20:27:27  MenningC
# TBOLT00000000:AUpdates to validation for mirrors, fix wait for inits to end. Reviewed by Dave
#
# Revision 1.57  2004/11/16 16:09:15  MenningC
# TBOLT00000000:Logtext and defrag cleanup. Reviewed by Al
#
# Revision 1.56  2004/09/24 19:53:00  MenningC
# tbolt00000000: Message allowing errors in BE6 (ql reset errors) and disable cache test for wookiee. reviewed by TIm.
#
# Revision 1.55  2004/09/22 16:17:50  KohlmeyerA
# Tbolt00000000: Added check to 38 for number of controllers.  Updated test 23
# to create all replacement vdisks before deleting any old vdisks.  Also uncommented
# the defrag part of the test.
# Reviewed by Craig.
#
# Revision 1.54  2004/08/30 19:12:38  KohlmeyerA
# Tbolt00000000:  Removed the SKIPVALIDATIONFAILURE flag from a number of
# the CheckSosTables calls.
#
# Revision 1.53  2004/08/23 15:15:18  KohlmeyerA
# Tbolt00000000:  Added missing checks of return codes after VerifyIO calls.
# Reviewed by Craig.
#
# Revision 1.52  2004/08/04 15:29:44  MenningC
# tbolt00000000: updates to allow unbypass in fabric, reviewed by Al
#
# Revision 1.51  2004/07/30 20:49:21  KohlmeyerA
# Tbolt00000000:  Added test case 43.  Reviewed by Craig.
#
# Revision 1.50  2004/07/28 15:04:34  MenningC
# tbolt00000000: updates to support SATA and adrdress 4 way issues, reviewed by Al
#
# Revision 1.49  2004/07/23 21:22:20  KohlmeyerA
# Tbolt00000000:  Added BEStress42.  Reviewed by Craig.
#
# Revision 1.48  2004/05/21 15:35:11  SneadJ
# TBolt0001348 - R1, R5, R10, PDisk Error and Failover = Data Miscompare
# Made changes to remove the temporary delay in BEStress 41/91 and
# add finding the master after the unfail (may have changed during the
# elections).
#
# Revision 1.47  2004/04/30 18:22:34  MenningC
# tbolt00000000: fix BE38; reviewed by Al
#
# Revision 1.46  2004/04/23 16:32:56  SneadJ
# TBolt00010259 - RAID 5 Robustness
# Changed Testcase 41 and 91 to only do Failover/Failback 10 times
# in the loop while Rebuilds are in progress.  This prevents a never
# ending cycle.
#
# Reviewed with Craig Menning
#
# Revision 1.45  2004/04/23 14:11:51  SneadJ
# TBolt00010259 - RAID 5 Robustness
# Waiting 30 seconds for Local Images to be processed before allowing
# a failover after rebuilds start in Testcase 41 and 91.
#
# This is a temporary workaround for two bugs dealing with local image
# processing.
#
# Revision 1.44  2004/04/15 18:48:42  KohlmeyerA
# Tbolt00000000 - Removed unused call to GetDataDisks.  Reviewed by Craig
#
# Revision 1.43  2004/04/13 16:57:58  SneadJ
# TBolt00010259 - RAID 5 Robustness
# TBolt00010182 - Hold off Rebuilds while R5 Resync in Progress
# Updates for Testcase 41 and 91.
#
# Written by Jim Snead and Tim Swatosh.
#
# Revision 1.42  2004/03/22 21:34:05  MenningC
# tbolt00000000: Fixes to BE41. Reviewed by Jim
#
# Revision 1.41  2004/03/18 21:39:24  MenningC
# tbolt00000000: new test for Jim S. reviewed by Al
#
# Revision 1.40  2004/02/18 20:28:54  MenningC
# tbolt00000000:Fix defrag 5, timing on be14, etc., reviewed by Al
#
# Revision 1.39  2004/01/27 19:52:41  MenningC
# TBOLT00000000:changes for readability and additional data collection.
# Reviewed by Al
#
# Revision 1.38  2004/01/21 21:39:24  MenningC
# TBOLT00000000: fix for moved master in BEstress14. Reviewed by Jim
#
# Revision 1.37  2003/11/25 19:45:54  MenningC
# TBOLT00000000: Add new BEStress test #38 for debugging a bug. Reviewed by Jeff Williams.
#
# Revision 1.36  2003/11/12 19:17:02  MenningC
# tbolt00000000: Scrub fixes and some additional debug code. Reviewed by Olga
#
# Revision 1.35  2003/11/05 21:16:39  MenningC
# tbolt00000000: Added 5 minute delays before and after testing. Defrag case 1 got additional delays.  Reviewed by Olga
#
# Revision 1.34  2003/10/29 15:03:18  MenningC
# tbolt00000000: updates for TAS=LAS=0 bug, move rebuild check in unfailpdisk. Reviewed by Olga
#
# Revision 1.33  2003/10/22 13:57:04  MenningC
# tbolt00000000: fupdates to support Raid 5 testing and removing the checks on the SOS tables for slaves; reviewed by Olga
#
# Revision 1.32  2003/10/08 14:21:37  WerningJ
# Tbolt00000000: changes to support defrag all, reveiwed by Eric
#
# Revision 1.31  2003/09/30 20:51:04  MenningC
# tbolt00000000: Fix for empty vdisk list and initial fixes for one defrag at a time. Reviewed by Eric.
#
# Revision 1.30  2003/09/16 15:12:03  MenningC
# tbolt00000000: additional parity scan work, update for pdisks that automatically unhotspare themselves. Reviewed by Eric
#
# Revision 1.29  2003/09/10 13:26:53  MenningC
# tbolt00000000: fix ictest menu, undace configs for n-way, improve 1 way support. reviewed by Olga
#
# Revision 1.28  2003/08/20 15:17:53  MenningC
# tbolt00000000: check in current state of parity scan tests, adds parity scan to most BE stress tests, reviewed by Olgs
#
# Revision 1.27  2003/08/12 13:53:51  MenningC
# TBOLT00000000: check in test cases for TIm's testing; reviewed by  Eric
#
# Revision 1.26  2003/08/11 14:51:34  MenningC
# TBOLT00000000: check in test cases for TIm's testing; reviewed by Tim
#
# Revision 1.25  2003/07/25 18:39:35  MenningC
# tbolt00000000: support for the parity scan tests; reviewed by Eric
#
# Revision 1.24  2003/07/01 14:32:12  MenningC
# TBOLT00000000: Additional fixes for pdisklabels and removed a server assoc test from the regression suite. reviewed by Olga
#
# Revision 1.23  2003/06/26 18:04:28  MenningC
# TBOLT00000000: Changes to support unchanging drive labels during hotspare in R2 and R3; reviewed by Olga
#
# Revision 1.22  2003/06/06 21:05:07  MenningC
# TBOLT00000000: fixes for ses and slot for pdisk bypassing.
#
# Revision 1.21  2003/05/28 14:54:20  MenningC
# TBOLT00000000: Changes to support bypassing of drives, patch for servermates, fix a defrag case timing.; reviewed by JW
#
# Revision 1.20  2003/05/07 18:58:38  MenningC
# TBOLT00000000: New test case 31; reviewed by Olga
#
# Revision 1.19  2003/04/21 15:13:41  MenningC
# tbolt00000000: fix timeout in rmstate, fix bestress case22, fix defrag case 23; reviewed by JW
#
# Revision 1.18  2003/04/16 13:55:40  MenningC
# tbolt00000000: minor fixes reviewed by JW
#
# Revision 1.17  2003/04/14 14:31:48  MenningC
# tbolt00000000: adde PSDCheck; reviewed by JW
#
# Revision 1.16  2003/04/08 18:44:56  MenningC
# tbolt00000000: changed an error message; reviewed by JW
#
# Revision 1.15  2003/03/27 21:29:39  MenningC
# Fix BEPULL in failover, remove case14 in bestress; reviewed by JW
#
# Revision 1.14  2003/03/26 21:24:52  WerningJ
# Removed calls to unused modules
# Reviewed by Craig M
#
# Revision 1.13  2003/03/06 19:55:58  MenningC
# tbolt00000000 enhancement for JW and MS, reviewed by the other JW
#
# Revision 1.12  2003/03/03 23:03:29  MenningC
# tbolt00000000 fix for BEStress and new failover test case for Neal, reviewed by JW
#
# Revision 1.11  2003/02/25 22:01:24  MenningC
# tbolt00000000 updates for BEStress tests, reviewed by JW
#
# Revision 1.10  2003/02/25 21:56:00  MenningC
# tbolt00000000 updates for BEStress tests, reviewed by JW
#
# Revision 1.9  2003/01/29 17:16:13  MenningC
# Tbolt00000000:more debug of BEStress reviewed by Jeff Werning.
#
# Revision 1.8  2003/01/22 20:48:31  MenningC
# Tbolt00000000: fix for target maps. Reviewed by Jeff Werning.
#
# Revision 1.7  2003/01/22 17:03:53  MenningC
# Tbolt00000000: more debug of the BEstress tests, reviewed by J Werning
#
# Revision 1.6  2003/01/21 19:49:14  MenningC
# Tbolt00000000: more debug of the BEstress tests, reviewed by J Werning
#
# Revision 1.5  2003/01/17 16:36:26  MenningC
# Tbolt00000000: Additional updates to BEStress. Reviewed by Jeff Werning.
#
# Revision 1.4  2003/01/16 15:28:01  MenningC
# Tbolt00000000: more new code, not reviewed.
#
# Revision 1.3  2003/01/15 21:17:50  MenningC
# Tbolt00000000: amore new code, not reviewed.
#
# Revision 1.2  2003/01/15 15:58:07  MenningC
# Tbolt00000000: additional new code, reviewed by Olga
#
# Revision 1.1  2003/01/14 16:03:46  MenningC
# Tbolt00000000: new file. Reviewed by J Werning.
#
#
#
##############################################################################
