#! /usr/bin/perl 
# $Header$
##############################################################################
#  
#   CCBE Integration test library - X1 test functions
#
#   03/06/2003  XIOtech   Mark Schibilla
#
#   A set of library functions for integration testing. This set support
#   testing of the controller's defrag function
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2003 XIOtech
#
#   For XIOtech internal use only.       
#
##############################################################################
=head1 NAME

TestLibs::X1robust - Perl Tests to test X1 commands

$Id: X1robust.pm 4298 2005-05-04 18:53:47Z RysavyR $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This is a starting point for testing the X1 packet interface.  Only
configuration commands have return status.

The key externally available functions will have extra descriptions on
how they are called and what to look for in the results.

=head1 DESCRIPTION

Test Functions Available (exported)

        The more significant ones

              X1Entry            entry point for all X1 tests
              
              

=cut


#                         
# - what I am
#

package TestLibs::X1robust;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::IntegCCBELib;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - Constants used
#



#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 4298 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

                        #



    # primary entry point for basic 1 way test is DefragTest()
    # primary entry point for the 2 way version is Defrag2Way()

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        &X1Entry

                        

                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 4298 $);
}
    our @EXPORT_OK;


##############################################################################
#
#               Public Functions
#
##############################################################################
###############################################################################

=head2 General function parameter comments


For most functions the same set of parameters are required. These parameters 
are described in more detail here.


=cut

=over 1

=item Common Parameters:

 $coPtr: A pointer to a list of CCBE objects that have connections
         already established. Each member of the list is a pointer to
         the object hash.

 $snPtr: A pointer to a list of controller serial numbers. As the caller
         connects/logs into each controller, the serial number of the
         controller is fetched and put into this list.
         
 $moxaIP: The pointer to a list of moxa IP addresses that matches the
          moxa map and object lists.
          
 $mmPtr: A pointer to a list of Moxa channels. This list indicates which
         channel on the Moxa controls the power to a controller. 

 $retIn: This is a controle variable. If set to GOOD ( = 0 ), the test
         will be executed. If set to another value, the test will just
         return. The return value from the test will be what was passed
         in $retIn.

 Note; For each of the above lists, the order of the elements is critical.
       The elements are ordered so that the entry in each list will indicate
       the corresponding data for the same controller. Results will be 
       unexpected if this ordering is not correct.

 $wwnPtr: This is a pointer to a list of WWNs for the QLogic cards in the 
          attached servers. When configuring systems, this list determines 
          which WWNs will be associated with vdisks. If an entry in this 
          list is not found on the system, it will be ignored. A WWN 
          found on the system that is not included in the list will not 
          have any drives associated. Ordering of this list is not critical,
          although if there are more (found) entries in the list than
          vdisks, the latter members of the list may not get any vdisks
          associated.

 $ctlr: For functions that work with a single specific controller, this 
        is the pointer to that controller object. It is one of the 
        members of the list that $coPtr points to.
       



=back

=cut


###############################################################################


###############################################################################


###############################################################################

=head2 X1Entry function

A function used for debugging the code as a generic entry. The final 
parameter represents the test case to be run. A test case of 99 will
run most tests. There is no guarantee that the tests can actually 
run sequentially and give full coverage.



=cut

=over 1

=item Usage:

 my $rc = X1Entry($coPtr, $retIn, $snPtr, $moxaIP, $mmPtr, $case );
 
 where: $coPtr is a pointer to a list of controller objects
        $retIn is a control flag and should be GOOD
        $snPtr is a pointer to a list of controller serial numbers
        $moxaIP is the IP address of the Moxa controller
        $mmPtr is a pointer to a list of tha Moxa channel mappings
        $case is the test case to run

=item Returns:

       $rc will be GOOD or ERROR. The function returns GOOD if the 
           expected state is found.



=back

=cut


##############################################################################
#
#          Name: X1Entry
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub X1Entry
{
    trace();
    my ( $coPtr,  $snPtr, $moxaIP, $mmPtr, $wwnPtr, $ipPtr, $case ) = @_;

    my $ret;
    $ret = GOOD;

    my @coList = @$coPtr;

print " in X1Entry\n";

    if ( $case==1   || $case == 99 ) { $ret = X1Case1(  $coPtr, GOOD, $snPtr  ); }
    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==2   || $case == 99 ) { $ret = DefragCase2(  $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==5   || $case == 99 ) { $ret = DefragCase5(  $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==6   || $case == 99 ) { $ret = DefragCase6(  $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==7   || $case == 99 ) { $ret = DefragCase7(  $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==8   || $case == 99 ) { $ret = DefragCase8(  $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==9   || $case == 99 ) { $ret = DefragCase9(  $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==10  || $case == 99 ) { $ret = DefragCase10( $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==11  || $case == 99 ) { $ret = DefragCase11( $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==12  || $case == 99 ) { $ret = DefragCase12( $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==13  || $case == 99 ) { $ret = DefragCase13( $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==17                 ) { $ret = DefragCase17( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==16                 ) { $ret = DefragCase16( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==15                 ) { $ret = DefragCase15( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==18                 ) { $ret = DefragCase18( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==19                 ) { $ret = DefragCase19( $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr     ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==20     ) { $ret = DefragCase20(  $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==21  || $case == 99 )  { $ret = DefragCase21(  $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==3   || $case == 99 ) { $ret = DefragCase3(  $coPtr, GOOD, $snPtr  ); }
#    if ( $ret != GOOD ) { return $ret; }
#
#    if ( $case==4   || $case == 99 ) { $ret = DefragCase4(  $coPtr, GOOD, $snPtr, $moxaIP, $mmPtr   ); }
#    if ( $ret != GOOD ) { return $ret; }
#

    return $ret;

}


##############################################################################
#
#          Name: Support Functions
#
#  These are probably not exported.
#
##############################################################################

##############################################################################
#
#          Name: X1Case1
#
#        Inputs:  
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description:  
#
##############################################################################
sub X1Case1
{
    trace();
    my ( $coPtr, $retIn, $snPtr ) = @_;


    my $msg;
    my $msg0;
    my $master;
    my @coList;
    my $ctlr;
    my @vCounts; 
    my @sCounts; 
    my @tMap;
    my @activeServers;
    my @initialVdisks;
    my $ret;

    # $retIn coming in is a flag to do the test or not
    if ($retIn != GOOD)
    {
        return $retIn;
    }


    $msg  = "------ X1 Test Case 1: Test description goes here--------------";
    $msg0 = "---------------------------------------------------------------";
    logInfo($msg0);
    logInfo($msg);
    logInfo($msg0);

    # find the master controller
    $master = FindMaster( $coPtr );
    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$coPtr;

    $ctlr = $coList[$master];


    $ret = X1GetEnvironmentalInfo($ctlr);


    logInfo("End of X1 Test Case 1.");

    
    return GOOD;

}


#
# Wrapper functions.  These functions provide common returns from standard
# CCBE - XIOTECH library functions.
#



##############################################################################
#
#          Name: X1GetEnvironmentalInfo
#
#        Inputs: controller, server, lun, vdisk
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Associates the specified vdisk to the specified server and 
#                lun.   
#
#
##############################################################################
sub X1GetEnvironmentalInfo
{
    trace();

    my ($controller) = @_; 

    my $msg = "";
     
    debug("X1GetEnvironmentalInfo");
    
    my %info = $controller->X1GetEnvironmentalInfo();
    
    if (!%info)                        # no response
    {
        logInfo(">>>>> Failed to receive a response from X1GetEnvironmentalInfo <<<<<");
        return ERROR;
    }
    else
    {
        $controller->FmtX1EnvironmentalInfo(\$msg, %info);
        logInfo($msg);
        return GOOD;
    }

    # X1 packets have no STATUS return.  Comment this out for now.
    # Later we will create a packet call to get the status.

#    if ($info{STATUS} == 1)            # 1 is bad
#    {
#        logInfo(">>>>> Failed: serverAssociate returned an error <<<<<");
#        PrintError(%info);
#        logInfo("Failure with VDISK $vd, LUN $lun, SERVER $server");
#        return ERROR;
#    }
#
#    if($info{STATUS} == 0)             # 0 is good
#    {
#        logInfo("VDISK $vd is mapped using LUN $lun to SERVER $server");
#    }

    

    return GOOD;
}




1;   # we need this for a PM

##############################################################################
# $Log$
# Revision 1.1  2005/05/04 18:53:52  RysavyR
# Initial revision
#
# Revision 1.2  2003/03/26 21:24:53  WerningJ
# Removed calls to unused modules
# Reviewed by Craig M
#
# Revision 1.1  2003/03/14 15:55:42  SchibillaM
# TBolt00000000: Check in a starting point for X1 packet testing using XTC.
# Reviewed by Craig.
#
#
#
##############################################################################
