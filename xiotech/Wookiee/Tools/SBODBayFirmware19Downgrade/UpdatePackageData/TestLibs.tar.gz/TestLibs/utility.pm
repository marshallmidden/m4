#$Id: utility.pm 48313 2008-04-13 05:31:49Z neal_eiden $
##############################################################################
# File name:  TestLibs::utility
#
# Desc: A utility library for Bigfoot testing
#
# Date: 07/26/2002
#
# Original Author:  Craig Menning
#
# Last modified by  $Author: neal_eiden $
# Modified date     $Date: 2008-04-13 00:31:49 -0500 (Sun, 13 Apr 2008) $
#
# Copyright Xiotech 2001, 2002, 2003, 2004, 2008
#
##############################################################################

package TestLibs::utility;

=head1 NAME

Bigfoot Test Utility Library

TestLibs::utility - a library of misc functions that are not specific to 
       Bigfoot.

$Id: utility.pm 48313 2008-04-13 05:31:49Z neal_eiden $

=head1 SUPPORTED PLATFORMS

IF IT DOES NOT SUPPORT LINUX (MOXA FOR EXAMPLE), PLEASE STATE SO

=begin html
<UL>
    <LI>Linux</LI>
    <LI>Windows</LI>
</UL>

=head1 SYNOPSIS

 THIS SECTION OPTIONAL

 use TestLibs::utility;

 debug("Here is some debug info")

 logInfo("Important info");

 logControl(trace => "true", debug => "true", error => "stop")

=head1 DESCRIPTION

TEST ALGORITHMS GO HERE IF THERE IS ONE

trace() provides a method of capturing code execution

debug() provides a method of capturing specific information a developer
deems useful in debugging their Perl script.

trace() and debug() display to STDERR by default, but can be sent to a file by using
debug_to().

The logControl() function controls the level of detail being
logged.  For example, to turn on trace and debug:

    logControl(trace => "true", debug => "true");

trace and debug are off by default

Other control options are:

 warning : continue - do not pause on warnings (default)
 warning : pause    - pause on warnings
 error   : continue - do not pause or stop of errors (default)
 error   : pause    - pause on warnings
 error   : stop     - stop on errors

=over 4

=item function($parameter)

Description here

=item logInfo($msg)

logs informational messags.  $msg is optional.

=back

=head1 AUTHOR

Your name and email address here

=head1 CHANGELOG

 $Log$
 Revision 1.6  2006/06/08 12:18:45  AnasuriG
 Added 2750 for 750 in getMagProductID subroutine

 Revision 1.5  2006/06/01 11:14:01  AnasuriG
 Added subroutine getMagProductId

 Revision 1.4  2006/05/24 07:51:31  EidenN
 Moved from 750 Branch

 Revision 1.2.4.1  2006/03/10 13:58:26  HoltyB
 TBolt00000000:Merged with HEAD

 Revision 1.3  2006/02/24 08:57:24  AnasuriG
 Added code for FE simulator configuration

 Revision 1.2  2005/11/14 11:49:58  AnasuriG
 Changes done as part of iSCSI scripting for Integration testing

 Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
 import CT1_BR to shared/Wookiee

 Revision 1.28  2005/01/28 16:31:42  PalmiD
 TBolt00000000: Fixed typo.
 Reviewed by Craig Menning.

 Revision 1.27  2004/12/08 16:35:35  KohlmeyerA
 Tbolt00000000:  Updated for RediCopyTest to handle full WWNs and work without using the
 move vdisks command that is no supported.
 Reviewed by Craig.

 Revision 1.26  2004/12/01 20:34:43  PalmiD
 TBolt00000000: Added IO shutdown option in promptUser.  Reviewed by
 Craig Menning (virtually).

 Revision 1.25  2004/11/23 23:13:06  MenningC
 tbolt00000000: fixed copyright, reviewed by Al

 Revision 1.24  2004/11/22 17:58:15  PalmiD
 TBolt00000000: Added function to take in a full list and a partial list and
 return the compliment of the partial list. (GetComplimentOfList).
 Reviewed by Craig Menning.

 Revision 1.23  2004/04/30 19:50:19  KohlmeyerA
 Tbolt00000000 - Modified shortWWN to be a hash of full WWN to allow checking of all bytes of WWN and made changes to handle the possiblity of a different controller becoming master when a controller is added to vcg.  Reviewed by Craig

 Revision 1.22  2004/02/19 23:52:25  SchibillaM
 TBolt00000000: Separate NWay algorithms and support functions into separate
 files.  Move max controllers constant into Constants.pm.  Minor changes to
 PromptUser().

 Revision 1.21  2004/02/13 18:14:25  SchibillaM
 TBolt00000000: Add 2 new PromptUser() options.

 Revision 1.20  2003/10/07 15:40:23  ThiemanE
 Added a function to create a C string
 Reviewed by Craigm

 Revision 1.19  2003/08/08 13:43:20  MenningC
 tbolt00000000: changes to spread disk groups across drive bays. Reviewed by Eric

 Revision 1.18  2003/05/29 12:56:44  WerningJ
 Rewrote all XTC data structures
 Reviewed by Craig M

 Revision 1.17  2003/04/16 18:09:25  MenningC
 TBOLT00000000; added File::CompareFiles reveiwed by Olga.

 Revision 1.16  2003/04/16 15:05:55  MenningC
 TBOLT00000000; exported CompareFiles reveiwed by Olga.

 Revision 1.15  2003/04/16 13:55:40  MenningC
 tbolt00000000: minor fixes reviewed by JW

 Revision 1.14  2003/03/27 17:37:04  WerningJ
 Moved ExtractWWN from XMClib to here
 Reviewed by Olga

 Revision 1.13  2003/03/26 21:24:53  WerningJ
 Removed calls to unused modules
 Reviewed by Craig M

 Revision 1.12  2003/01/14 15:26:39  MenningC
 Tbolt00000000: Changes to support BEUtils lib, removed UMC. Reveiewed by J Werning.

 Revision 1.11  2002/12/11 19:50:25  MenningC
 TBOLT00000000: error handling update. reveiwed by J. Werning

 Revision 1.10  2002/12/11 15:23:43  MenningC
 TBOLT00000000: fixed a timing hole; reveiwed by J. Werning

 Revision 1.9  2002/10/08 20:34:09  MenningC
 tbolt00000000 changes for defrag test and prequal scripts. Reviewed by JT

 Revision 1.8  2002/10/03 15:01:27  MenningC
 TBOLT00000000 fixed type, Max watched me

 Revision 1.7  2002/08/20 21:03:31  MenningC
 Tbolt00000000 updates to testSystemState, reveiwed by Tim

 Revision 1.6  2002/08/19 17:57:14  ThiemannE
 Bad IP addresses, like "10.64.55.34.." are now caught in IPValidate.
 A function that counts that number of times a particular character is seen in a string was added.
 Reviewed by Craigm.

 Revision 1.5  2002/08/15 19:27:15  ThiemannE
 Added an isFloat function
 Reviewed by WerningJ.

 Revision 1.4  2002/08/09 13:36:34  ThiemannE
 Merging logging changes files.  Logging changes branches merged, but these did not and had new changes.  This will add the new changes to the regular CVS tip.

 Revision 1.1.2.7  2002/08/08 14:26:40  ThiemannE
 Added new GoodPath testcases and added a new [Switch] tag to allow for configuring switches.
 Reviewed by JWerning.

 Revision 1.1.2.6  2002/08/06 18:24:42  ThiemannE
 Added trim and IPValidate functions.
 Reviewed by Randy Reiter.

 Revision 1.1.2.5  2002/07/29 15:45:27  WerningJ
 Added pingWait function
 Reviewed by Craig M

 Revision 1.1.2.4  2002/07/28 19:07:48  MenningC
 Tbolt00000000 continued changes for logging

 Revision 1.1.2.3  2002/07/27 05:08:26  WerningJ
 Added delay and randomDelay functions to this library

 Revision 1.1.2.2  2002/07/26 16:22:22  HouseK
 Removed tabs

 Revision 1.1.2.1  2002/07/26 14:44:11  WerningJ
 Initial Release of Utility Library


=cut

#
# - other modules used
#

#use warnings;
use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :XIOCISER);
use Net::Ping;
use Time::localtime;

#
# - perl compiler/interpreter flags 'n' things
#
use File::Copy;
use File::Compare;

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

#use strict;


#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 48313 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

    @ISA         = qw(Exporter);
    @EXPORT      = qw(
                        &AsciiHexToBin
                        
                        &CalcTime
                        &CheckWWN
                        &CopyFiles
                        &CompareFiles
                        &CompareWWN
                                                
                        &DecToAsciiHexData
                        &delay
                        &DelaySecs
                        &DeleteFile

                        &ExtractWWN

                        &getSpecifiedCharacterCount

                        &IPValidate
                        &isFloat
                        &IsInList
                        &isInteger
                        &isValidDelimitedList

                        &min
                        
                        &pingWait
                        &PromptUser

                        &randomDelay
                        &randomInt

                        &SortAndRemoveDups

                        &trim
                        &AssembleCString
                        &getMagProductID
                        &GetComplimentOfList
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 48313 $);
}
    our @EXPORT_OK;



##############################################################################
#
#          Name: CompareWWN
#
#        Inputs: Two pointers to two WWN hashes to compare
#
#       Outputs: TRUE  - The WWNs match
#                FALSE - The WWNs do not match
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################

sub CompareWWN
{ 
    my ( $wwn1Ptr, $wwn2Ptr ) = @_;
    
    #
    # If the WWNs are the same, return GOOD, 
    # Otherwise, return ERROR
    #
    my $wwn = $wwn1Ptr->{WWN};

    # WWN is handled as a string of length 256 and filled with "\0"s at the end 
    # of string. 

    # Here the string is been split till "\0" so that the string comparision goes smoothly.

    my @wwn1 = split /[\0]/, $wwn;

    #printf "WWN1:  %s \n", $wwn1[0];
    #printf "WWN2   %s \n", $wwn2Ptr;

    if ( $wwn1[0] eq $wwn2Ptr )
    {
          
        return TRUE;
    }  

    return FALSE;

}
##############################################################################
#
#          Name: CheckWWN
#
#        Inputs: Pointers to a WWN hash to search for and the list to search
#
#       Outputs: GOOD  - The WWN was found in the list
#                ERROR - The WWN was not found in the list
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################

sub CheckWWN
{ 
    my ( $wwnPtr, $wwnListPtr) = @_;
    
    my $numWWNs;
    my $wwnIndex;
    
    #
    # loop thru each WWN in the wwnlist and compare to thisWWN
    # exit with GOOD return if we find it.  
    #
    
    $numWWNs = scalar(@$wwnListPtr);
    
    for $wwnIndex ( 0..($numWWNs-1) ) 
    {
        if ( CompareWWN ( $wwnPtr, $wwnListPtr->[$wwnIndex] ) == TRUE )
        {
            return GOOD;
        }
    }

    # 
    # If we went thru the list and didn't get a match,
    # Then return ERROR because we didn't find it.
    #
    return ERROR;

}


##############################################################################
#
#          Name: ExtractWWN
#
#        Inputs: WWN string in ##-##-##-##-##-##-##-## format
#
#       Outputs: pointer to hash of WWN as 2 integers
#                WWN_LO - integer value of first 4 bytes 
#                WWN_HI - integer value of last 4 bytes    
#
#  Globals Used: none
#
#   Description: strange string manipulation  
#
#
##############################################################################
sub ExtractWWN
{
    trace();
    
    my ( $WWNstr ) = @_;
    my %WWNnum;
    my $sub1;
    my $sub2;
    my $sub3;
    my $sub4;
    my $sub5;
    my $sub6;
    my $sub7;
    my $sub8;

    #
    # Extract each of the hex digits from the WWN string 
    #
    $sub1 = substr $WWNstr, 0  , 2;
    $sub2 = substr $WWNstr, 3  , 2;
    $sub3 = substr $WWNstr, 6  , 2;
    $sub4 = substr $WWNstr, 9  , 2;
    $sub5 = substr $WWNstr, 12  , 2;
    $sub6 = substr $WWNstr, 15  , 2;
    $sub7 = substr $WWNstr, 18  , 2;
    $sub8 = substr $WWNstr, 21  , 2;

    #
    # Build the lo and hi numbers
    #
    $WWNnum{WWN_LO} = 0x1000000 * hex($sub1) + 0x10000 * hex($sub2) + 0x100 * hex($sub3) + hex($sub4);
    $WWNnum{WWN_HI} = 0x1000000 * hex($sub5) + 0x10000 * hex($sub6) + 0x100 * hex($sub7) + hex($sub8);

    #
    # return the pointer to the hash with the new values
    #
    return \%WWNnum;
}

##############################################################################
# Name:     AsciiHexToBin
#
# Desc:     Converts an ASCII hex string to packed binary data
#
# Input:    data - hex string representing the MRP input data
#           format - byte|short|word  (default: word)
##############################################################################
sub AsciiHexToBin
{
    trace();
    my ($data, $format) = @_;

    $data =~ s/0x//i;

    if (!defined $data) {
        logError("AsciiHexToBin: No input data");
        return undef;
    }

    if (!defined $format) {
        $format = "word";
    }
    
    if ($format !~ /^byte$|^short$|^word$/i) {
        logError("AsciiHexToBin: format incorrect ($format)");
        return undef;
    }

    # setup to parse the input data string
    my $cCnt;
    my $cTpl;

    if ($format =~ /^byte$/i) {
        $cCnt = 2;
        $cTpl = "C";
    }
    elsif ($format =~ /^short$/i) {
        $cCnt = 4;
        $cTpl = "S";
    }
    else { # word
        $cCnt = 8;
        $cTpl = "L";
    }
    
    my @wData;
    my $i;
    my $template = "";
    my $length = length $data;

    if ($length % $cCnt) {
        logError("AsciiHexToBin: Input data string length not correct for the " .
                 "format selected data = $data, format = $format");
        return undef;
    }
    
    # parse the input data string
    for($i=0; $i<$length; $i+=$cCnt) {
        push @wData, oct("0x" . substr $data, 0, $cCnt);
        $data = substr $data, $cCnt;
        $template .= $cTpl;
    }

    $data = pack $template, @wData;
   
    return $data;
}

##############################################################################
#
#          Name: DecToAsciiHexData
#
#        Inputs: uinteger, format as a string (either "word", "short", or "byte"
#
#       Outputs: the specified integer is converted into an ASCII Hex, word
#                short, or byte string.
#                
#  Globals Used: none
#
#   Description: Converts the specified integer into an ASCII Hex word, short, or
#                byte string.  Example - Input: 255, "word" - Output: 
#                "000000ff", without the quotation marks.  Example - Input 255,
#                "short" - Output: "00ff".
#
##############################################################################
sub DecToAsciiHexData
{
    trace();
    use constant BITS_IN_NIBBLE => 4; # the number of bits in a nibble
    use constant WORD_SIZE => 8;      # the number of hex nibbles 
                                      # (4-bit chunks) in a word
    use constant SHORT_SIZE => 4;     # the number of hex nibbles in a short
    use constant BYTE_SIZE => 2;      # the number
 
                     
    my ($inputValue, $formatString) = @_;  # the input to this function
    my $ret;                               # return value
    my $condensedHexString;   # the hex string without padding
    my $fillNumber;           # the number of zeros to pad the data with    
    my $maxInput;             # the maximum number that can be entered
    my $minInput;             # the minimum number that can be entered
    my $dataSize;             # the size of the data to format

    if ($formatString)
    {
        #
        # Parse the data format string
        #
        if ($formatString eq "word")
        {
            $dataSize = WORD_SIZE;
        }
        elsif ($formatString eq "short")
        {
            $dataSize = SHORT_SIZE;
        }
        elsif ($formatString eq "byte")
        {
            $dataSize = BYTE_SIZE;
        }
        else
        {
            debug("Invalid data format specifier");
            die "Invalid data format specifier.";
        }
    }
    else {
        debug("No data format specifier was provided");
        die "No data format specifier was provided.";
    }
    
    #
    # Find out the max and mins that are allowed to be entered.
    #
    $maxInput = 2**((BITS_IN_NIBBLE * $dataSize)) - 1;
    $minInput = 0;

    # Ensure that the input is within the allowed range.
    if (! (($inputValue <= $maxInput) && ($inputValue >= $minInput)) ) {
        debug("The input $inputValue in not within the range of values for the " .
              "specified data format");
        die "The input $inputValue in not within the range of values for the " .
            "specified data format.";
    }

    #
    # Convert the input to hex 
    #
    $condensedHexString = sprintf("%x", $inputValue);

    #
    # Get the number of zeros to pad the string with 
    #
    $fillNumber = $dataSize - length($condensedHexString);

    #
    # Pad the string with zeros to make it the correct size
    #
    $ret = ("0" x $fillNumber) . "$condensedHexString";
    
    return $ret;
}


##############################################################################
#
#          Name:IPValidate
#
#        Inputs: string
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Find out if a scaler is a proper IP address.
#
##############################################################################
sub IPValidate
{
    my $testString = $_[0];         # Get the string to test.
    my $returnValue = ERROR;        # The value to return.

    if ( defined($testString) )
    {
        #
        # Check to see if the IP address starts with a dot or ends with a dot.
        # Note: This would not be noticed by the split function, so without this
        # check, 10.34.45.23.. would be valid.
        #
        if (!($testString =~ /^[.]/) and !($testString =~ /[.]$/))
        {
            my @IPAddressParts = split /\./, $testString;
            
            #
            # Validate the IP Address.
            #
            if (@IPAddressParts == 4)
            {
                my $i = 0;
                my $errorFound = FALSE;
                while ( ($errorFound == FALSE) && ($i < @IPAddressParts) )
                {
                    #
                    # Check to ensure that the parts are integers.
                    # 
                    if ( isInteger($IPAddressParts[$i]) == TRUE)
                    {
                        #
                        # Check to see if the parts are within the expected boundaries.
                        #
                        if ( ($IPAddressParts[$i] < 0) || ($IPAddressParts[$i] > 255) )
                        {
                            $errorFound = TRUE;
                        }
                    }
                    else
                    {
                        $errorFound = TRUE;
                    }
                    $i++;
                } 
        
                if ($errorFound == FALSE)
                {
                    $returnValue = GOOD;
                }   
            }
        }
    }

    return $returnValue;
}


##############################################################################
#
#          Name: isFloat
#
#        Inputs: string
#
#       Outputs: TRUE if the input is a floating point number, FALSE if not.
#                Note: a valid floating point number will have a decimal
#                point in it.
#
#  Globals Used: none
#
#   Description: Finds out if the specified string is a floating point number.
#
##############################################################################
sub isFloat
{
    my $testString = $_[0];      # Get the string to test.
    my $returnValue = FALSE;     # The value to return.

    if ( defined($testString) )
    {
        if ( ($testString =~ /^[0-9]*[.][0-9]+$/) ) 
        {
            $returnValue = TRUE;
        }
    }
    
    return $returnValue;
}


##############################################################################
#
#          Name: isInteger
#
#        Inputs: string
#
#       Outputs: TRUE if the input is an integer, FALSE if not.
#
#  Globals Used: none
#
#   Description: Finds out if the specified string is an integer.
#
##############################################################################
sub isInteger
{
    my $testString = $_[0];      # Get the string to test.
    my $returnValue = FALSE;     # The value to return.

    if ( defined($testString) )
    {
        if ( ($testString =~ /^[\-]*[0-9]+$/) ) 
        {
            $returnValue = TRUE;
        }
    }
    
    return $returnValue;
}


##############################################################################
#
#          Name: trim
#
#        Inputs: string
#
#       Outputs: The specified string with all leading and trailing whitespace
#                removed.
#
#  Globals Used: none
#
#   Description: Removes the leading and trailing whitespace from the
#                specified string.
#
##############################################################################
sub trim
{
    my $trimmedString = $_[0]; 

    $trimmedString =~ s/^\s+//;   # Replace leading whitespace with nothing.
    $trimmedString =~ s/\s+$//;   # Replace trailing whitespace with nothing.

    return $trimmedString;
}





##############################################################################
#
#          Name: min
#
#        Inputs: oneValue, anotherValue
#
#       Outputs: the less positive of the two values
#
#  Globals Used: none
#
#   Description: basic min function because I know I will need it.  
#
#
##############################################################################
# basic min(x,y) function
sub min
{
    my ($a, $b ) = @_;
    if ( $a > $b ) {return $b};     # b is smaller, send it back
    return $a;                      # a=b or is smaller, send it back
}


##############################################################################
#
#          Name: getSpecifiedCharacterCount
#
#        Inputs: string, character to count
#
#       Outputs: The number of times the specified character occured in the
#                specified string.
#
#   Description: Returns the number of times that the specified character
#                was found in the specified string. 
#
##############################################################################
sub getSpecifiedCharacterCount
{
    my $str = $_[0];             # The string to get the specified character count.
    my $specifiedChar = $_[1];   # The character to count.

    my $numChars = 0;            # The number of characters that were found.
    my $char;                    # A single character.

    #
    # Check to see if the specified character was really a character.
    #
    if (length($specifiedChar) != 1)
    {
        logWarning("The specified character in getSpecifiedCharacterCount() is not a single character.");
        return 0;
    }

    #
    # Check to see if the specified string is a real string.
    # If not, then return 0 because no specified characters were found.
    #
    if (!defined($str))
    {
        return 0;
    }
    
    #
    # Count up the number of specified characters.
    #
    my $strLength = length($str);
    for (my $index = 0; $index < $strLength; $index++)
    {
        $char = substr($str, $index, 1);
        if ($char eq $specifiedChar)
        {
            #
            # The specified character was found.
            #
            $numChars++;
        }
    }

    return $numChars;
}


##############################################################################
#
#          Name: PromptUser
#
#        Inputs: choice     - which prompt
#
#       Outputs: nothing, any input is tossed
#
#  Globals Used: none
#
#   Description:    
#
#
##############################################################################
sub PromptUser
{
    my ($choice) = @_;           # which one to do
    my $dummy;

    print " \n";                  # make this stand out a little bit

    if ( $choice == 1 )
    {
        print "ACTION: Now rescan for drives on your server(s). \n";
        print "ACTION: Then press return to continue the script. ";
        $dummy = <STDIN>;
        print " Thanks. \n\n";
        return;
    }
    elsif ( $choice == 2 )
    {
        print "ACTION: Please wait for all the initializations to complete. \n";
        print "ACTION: They will be done when the drive LEDs stop flashing. \n";
        print "ACTION: Then press return to continue the script. ";
        $dummy = <STDIN>;
        print " Thanks. \n\n";
        return;
    }
    elsif ( $choice == 3 )
    {
        print "ACTION: Now rescan for drives on your server(s). You do NOT \n";
        print "ACTION: need to wait for all the initializations to complete. \n";
        print "ACTION: (The script will wait as needed for inits to complete.) \n";
        print "ACTION: However, after you do the rescans, you DO need to wait \n";
        print "ACTION: until the controllers recognize all the servers.  This \n";
        print "ACTION: will take about 1 minute after the rescans complete.\n";
        print "ACTION: Then press return to continue the script. ";
        $dummy = <STDIN>;
        print " Thanks. \n\n";
        return;
    }
    elsif ( $choice == 4 )
    {
        print "ACTION: Press return to finish the scripts, Then \n";
        print "ACTION: cycle power on the controller(s) and \n";
        print "ACTION: wait for them to finish booting. \n\n";
        $dummy = <STDIN>;
        print " Thanks. \n\n";
        return;
    }
    elsif ( $choice == 5 )
    {
        print "ACTION: Don't forget to clear the new bit in the server \n";
        print "ACTION: properties. (Currently no CLI facility for that. \n";
        print "ACTION: Now press return to continue the script. ";
        $dummy = <STDIN>;
        print " Thanks. \n\n";
        return;
    }
    elsif ( $choice == 6 )
    {
        print "ACTION: You can now start IO on the server(s). \n";
        print "ACTION: Two VDISKS should be available for IO. \n";
        print "\n";
        DelaySecs(15);
        return;
    }
    elsif ( $choice == 7 )
    {
        print "ACTION: You can now start IO on the server(s). \n";
        print "ACTION: Several VDISKS should be available for IO. \n";
        print "\n";
        DelaySecs(15);
        return;
    }
    elsif ( $choice == 8 )
    {
        print "ACTION: Now press return to continue the script. ";
        $dummy = <STDIN>;
        print " Thanks. \n\n";
        return;
    }
    elsif ( $choice == 9 )
    {
        print "ACTION: You can now start IO on the server(s). \n";
        print "ACTION: Several VDISKS should be available for IO. \n";
        print "ACTION: Now press return to continue the script. ";
        $dummy = <STDIN>;
        print " Thanks. \n\n";
        return;
    }
    elsif ( $choice == 10 )
    {
        print "ACTION: Stop IO and restart - new server(s) have been added. \n";
        print "ACTION: Several VDISKS should be available for IO. \n";
        print "ACTION: Now press return to continue the script. ";
        $dummy = <STDIN>;
        print " Thanks. \n\n";
        return;
    }
    elsif ( $choice == 11 )
    {
        print "ACTION: Stop IO - shutting down controller. \n";
        print "ACTION: Now press return to continue the script. ";
        $dummy = <STDIN>;
        print " Thanks. \n\n";
        return;
    }
    else 
    {
        print "ACTION: We are not supposed to be here! Something is wrong! \n";
        print "ACTION: Then press return to continue the script. ";
        $dummy = <STDIN>;
        print " Thanks. \n\n";
        return;
    }
}


##############################################################################
# Name:     CalcTime
#
# Desc:     Calculates time for single command execution 
#           
# In:       $sec_b  - Sec at the Beginning  
#           $min_b  - Min at the Beginning                 
#           $hour_b - Hour at the Beginning 
#           $sec_e  - Sec at the End
#           $min_e  - Min at the End
#           $hour_e - Hour at the End        
#
# Returns:  $TimeExecute - Time took to execute the command   
#
##############################################################################

sub CalcTime
{
    trace();
    my ($command, $sec_b, $min_b, $hour_b, $sec_e, $min_e, $hour_e) = @_;
    my $TimeStampB = (($hour_b * 3600) + ($min_b * 60) + $sec_b);
    my $TimeStampE = (($hour_e * 3600) + ($min_e * 60) + $sec_e);
    my $TimeExecute = $TimeStampE - $TimeStampB;
#    print "\n", "TimeStampB  ", "  >>>>>>>>>>>> ", "$TimeStampB time of the day in sec \n";
#    print       "TimeStampE  ", "  >>>>>>>>>>>> ", "$TimeStampE time of the day in sec \n";
#    print       "TimeExecute ", "  >>>>>>>>>>>> ", "$TimeExecute sec \n";

#    print OUT "\n", "TimeStampB  ", "  >>>>>>>>>>>> ", "$TimeStampB time of the day in sec \n";
#    print OUT       "TimeStampE  ", "  >>>>>>>>>>>> ", "$TimeStampE time of the day in sec \n";
#    print OUT       "TimeExecute ", "  >>>>>>>>>>>> ", "$TimeExecute sec \n";

#    if($TimeExecute > 5)
#    {
#       print "\n", "WARNING: TOOK $TimeExecute sec to EXECUTE $command  \n";
#    }
#    else
#    {
       logInfo(sprintf("TIME: %3d sec \n", $TimeExecute));
#    }

    return $TimeExecute;   
}

##############################################################################
#
#          Name: randomInt
#
#        Inputs: min value, max value
#
#       Outputs: some int inclusive to the range
#
#  Globals Used: random number seed indirectly
#
#   Description:
# 
#
#
##############################################################################
sub randomInt
{
    my ($min, $max) = @_;

    my$ i;

    if ( $max <= $min )
    {
        return $min;
    }

    $i = $max - $min + 1;

    $i = int(rand $i) + $min;
    
    return $i;
}

##############################################################################
# RDelay
#    Inputs:
#           $minTk = min time to delay in seconds
#           $maxTk = max time to delay in seconds
##############################################################################
sub randomDelay
{
    trace();                        # This allows function tracability
    my($maxTk, $minTk) = @_;
    my $delayTime;

    $delayTime = $minTk + int( rand($maxTk-$minTk) );
    TestLibs::Logging::debug ("Random delay $delayTime secs");
    delay($delayTime);

}

##############################################################################
# Delay
#    Inputs:
#           $tk = time to delay in seconds
##############################################################################
sub delay
{
    trace();                        # This allows function tracability
    my($tk) = @_;
    my $waittime = $tk;


    while ($tk>0)
    {
      print "Sleeping...$tk/$waittime    \r";
      sleep(1);
      $tk--;
    }
    print "\n";
}

########################################################################
### Function name: pingWait
###
### Purpose: ping a device and wait for ready
##
## INPUT:    IP Address or name of device, seconds to wait
## OUTPUT:   Return value from the called library function
#######################################################################

sub pingWait
{
    trace();                        # This allows function tracability
    my ($address, $timeSecs) = @_;
    my $p = Net::Ping->new("icmp");

    TestLibs::Logging::logInfo ("Checking device $address for ready, wait $timeSecs Seconds"); 
    my $stop_time = time() + $timeSecs;    #Wait for Device to come up
    while (($stop_time > time()) && !($p->ping($address)))
    {
        print "$address not yet reachable ", ctime(), "\r";
    }
    print "                                                                            \r";
    if ($stop_time <= time())
    {
        TestLibs::Logging::logInfo ("Timeout waiting for device $address to come ready");
        return ERROR;
    }

    $p->close();
    
    return GOOD;
}

##############################################################################
#
#          Name:  DelaySecs
#
#        Inputs:  seconds
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: Delay specified number of seconds with countdown   
#
#
##############################################################################
sub DelaySecs
{
    trace();                        # This allows function tracability

    my ($amount ) = @_;
    
    while ( $amount > 0 )
    {
        print "Pause for $amount seconds          \r";
        sleep 1;
        $amount--;
    }
    print "                               \r";

    return
}

##############################################################################
#
#          Name: DeleteFile
#
#        Inputs: one file name
#
#       Outputs: GOOD, if the delete is successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Deletes a file
#
##############################################################################


sub DeleteFile
{
    my ($file1) = @_;
    my $ret;
    trace();
    
    logInfo("Deleting file $file1 ");

    $ret = system("del", $file1);

    if( $ret == 0 )
    {
        logInfo("  Delete successful");
        return GOOD;
    }
    else
    {
        logInfo("  The delete failed, or there was another error. (RC = $ret)");
        return ERROR;
    }
}

##############################################################################
#
#          Name: CopyFiles
#
#        Inputs: two file names
#
#       Outputs: GOOD, if the copy is successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Copies a file. The print in here does not advance the 
#                curser to the next line, after calling you may want to 
#                print a newline.
#
##############################################################################


sub CopyFiles
{
    my ($file1, $file2) = @_;
    my $ret;
    trace();
    my $str;

    $str = "Copying file $file1 to $file2                        ";
 
    print "\r".$str;
                 
    $ret = copy( $file1, $file2);
 
    #$ret = system("copy", $file1, $file2);

    if( $ret == 1 )           # 1 is good from perl copy
    {
        #logInfo("  Copy successful");
        return GOOD;
    }
    else
    {
        logInfo("\n".$str."\n  The copy failed, or there was another error. (RC = $ret)");
        return ERROR;
    }
}
##############################################################################
#
#          Name: CompareFiles
#
#        Inputs: two file names
#
#       Outputs: GOOD, if the files match, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Compares two files, log the result.The print in here 
#                does not advance the 
#                curser to the next line, after calling you may want to 
#                print a newline.
#
##############################################################################


sub CompareFiles
{
    my ($file1, $file2) = @_;
    my $ret;
    trace();
    my $msg;

    $msg = "Comparing file $file1 to $file2...";


    $ret = compare($file1, $file2);

    #print "\n";

    if( $ret == 0 )
    {
        print "\r".$msg." The files matched                  ";
        return GOOD;
    }
    else
    {
        logInfo("\n".$msg." The files did not match, or there was an error.");
        return ERROR;
    }
}

##############################################################################
#
#          Name: isValidDelimitedList
#
#        Inputs: string to check, delimiter character
#
#       Outputs: TRUE if the specified string is a list delimited by the
#                specified character (or character class).
#
#   Description: Finds out if the specified string is a valid list delimited
#                by the specified character.
#
##############################################################################
sub isValidDelimitedList
{                           
    my $str = $_[0];        # The string to check.
    my $delimiter = $_[1];  # The delimiter to use.
    
    my $error = FALSE;     # This is set to true when an error occurs.
    
    #
    # Check to see if the serverlist was in the correct format.
    # The correct format is server1,server2,server3....etc.
    # (This catches more than one comma within the string.)
    #
    my @list = split /[$delimiter]/, $str;

    #
    # Go through each item in the list to ensure it is not an empty string.
    #
    foreach my $item (@list)
    {
        if (trim($item) eq "")
        {
            $error = TRUE;
        }
        
    }

    if ($error == FALSE)
    {
        #
        # Check make sure that the number commas in the list correspond to
        # the number of items in the list - 1.
        # (This catches more than one comma in the beginning or ending of
        # a string._
        #
        if ((getSpecifiedCharacterCount($str, $delimiter) != @list - 1))
        {
            $error = TRUE;    
        }
    }

    return ($error == TRUE ? FALSE : TRUE);
}


##############################################################################
#
#          Name: SortAndRemoveDups
#
#        Inputs: one list  
#
#       Outputs: the sorted list
#
#  Globals Used: none
#
#   Description: This function just sorts a list (list is assumed to have 
#                something in it).
#
#
##############################################################################
sub SortAndRemoveDups
{
    my (@list) = @_;
    
    if (scalar(@list) < 2 )
    {
        # no need to sort a 0 length or single item list 
        return @list;
    }
    
    my @list2 = sort(@list);      # sort the list (the easy part)
    
    # now to remove any duplicates
    
    my @list3;    
    my $i;

    push (@list3, $list2[0]);  # let's start with the easy one
    
    # now do the rest of the list
    for ( $i = 1; $i < scalar(@list2); $i++ )
    {
        if ( $list2[$i] != $list2[ ($i - 1) ] )
        {
            # add the different one to the new list
            push (@list3, $list2[$i]);   
        }
    }

    return @list3;
}


##############################################################################
#
#          Name: GetComplimentOfList
#
#        Inputs: full list, partial list  
#
#       Outputs: compliment of partial list
#
#  Globals Used: none
#
#   Description: This function gets the inverse of the partial list based on
#                  the full list. Or the complete fullList is no matches occur.
#
##############################################################################
sub GetComplimentOfList
{
    my ($fullListPtr, $partialListPtr) = @_;
    
    my @complimentList;    
    my $numPartialLocations;
    my $numFullLocations;
    my $addValue;
    my $removeValue;
    my $match;    
    my $i;
    my $j;
    
    my @fullList = @$fullListPtr;
    my @partialList = @$partialListPtr;

    #
    # Get the size of fullList
    #
    $numFullLocations = scalar(@fullList);

    #
    # Get the size of partialList
    #
    $numPartialLocations = scalar(@partialList);

    #
    # Get value from fullList and check for value in partialList
    #
    for($i = 0; $i < $numFullLocations; $i++)
    {
        $match = 0;
        
        #
        # get value from full list
        #
        $addValue = $fullList[$i];

        #
        # Compare addValue to each value in partialList
        #
        for( $j = 0; $j < $numPartialLocations; $j++)
        {
            $removeValue = $partialList[$j];
            
            #
            # If they match, set flag and exit loop
            #
            if($removeValue == $addValue)
            {
                $match = 1;
                last;
            }
            
        }
        
        #
        # if no match exists, add the value to complimentList
        #
        if($match == 0)
        {
            @complimentList = (@complimentList, $addValue);
        }
        
    }
           
    return \@complimentList;
}

##############################################################################

# returns 1 if $val is in the list reference by $lPtr, 0 otherwise
sub IsInList
{
    my ($val, $lPtr) = @_;

    my $i;
    for ( $i = 0; $i < scalar(@$lPtr); $i++ )
    {
        if ( $val eq $$lPtr[$i] )
        {
            return 1;
        }
    }

    return 0;
}

##############################################################################
#
#          Name: AssembleCString
#
#        Inputs: Scalars:
#                str - the string to convert to a null terminated C string.
#                bufferSize - the size of the buffer that the string will be
#                             put into
#
#       Outputs: reference to the assembled binary C string
#
#   Description: Assembles a binary, null terminated C string of the specified
#                size.            
#
##############################################################################
sub AssembleCString
{
    my ($str, $bufferSize) = @_;
    my $cString;

    #
    # If the string is undefined, set the string equal to an empty string.
    #
    if (!defined($str))
    {
        $str = "";
    }

    #
    # If the string is too long to fit a terminating null character within
    # the size of the buffer given, cut off the end of the string.
    #
    if (length($str) >= TESTCASE_NAME_SIZE)
    {
        $str = substr($str, 0, TESTCASE_NAME_SIZE - 1);
    }

    #
    # Create the string field.
    #
    $cString = pack("a$bufferSize", $str);

    return \$cString;  
}


##############################################################################
#
#          Name: getMagProductID
#
#        Inputs: $masterIP 
#
#       Outputs: returns the product ID
#
#   Description: Connects to the master controller and finds out the Model/Product 
#                and returns 1000 = Mag3D 1000, 2000 = Mag3D 3000 and 2750 = Mag 750 
##############################################################################

sub getMagProductID
{
    trace();

	my ( $masterIP, $objPtr ) = @_;
    
    my $productID;
    my $returnCode;
    my $disflag = FALSE;
    
    #
    # Connect to master controller and get the product ID
    #
   

    if ( $masterIP != 0 )
	{

    	$objPtr = TestLibs::IntegCCBELib::ccbe_connect ($masterIP); # Get a CCBE connection & Login (IP Address)
		$disflag = TRUE;

        if ($objPtr == ERROR)
        {
            return ERROR;
        }

    }
    
    #
    # Read FID 296
    #
    
    logInfo("Reading FID 296 to get the Product ID from the Firmware Header");

    my %data = $objPtr->MPXReadFID(296);
    if ( ! %data  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from ReadFID <<<<<<<<");
        return ERROR;
    }

    #
    # Format the data.  Get just the CCB FW header DATA
    #
    my $input = $objPtr->FormatDataString($data{RD_DATA}, 0, "WORD", undef, 100);
    #format (byte/short/word/binary)


    #
    # Replace the ProductID with the correct version & make sure we log what product type is being tested.
    # Used for script & platform development debugging
    #

    if ($input =~ m/1000/s) 
    {
        $productID = 1000; 
        logInfo ("Product type Magnitude 3D 1000");
    }
    elsif ($input =~ m/2000/s) 
    {
        $productID = 2000; 
        logInfo ("Product type Magnitude 3D 3000"); 
    }
    elsif ($input =~ m/2750/s) 
    {
        $productID = 2750; 
        logInfo ("Product type Magnitude 750");
    }
    elsif ($input =~ m/5000/s) 
    {
        $productID = 5000; 
        logInfo ("Product type NitroGen EA");
    }
    elsif ($input =~ m/7000/s) 
    {
        $productID = 7000; 
        logInfo ("Product type Emprise 7000");
    }
    print "My productID is a:  $productID \n\n\n";

    # Store the productID to the xtcDataPtr for future use

    ${$xtcDataPtr->{PRODUCTID}} = $productID;
    
    if ($disflag == TRUE)
    {

        # Disconnect from all controllers in this VCG
        $returnCode = TestLibs::IntegCCBELib::ccbe_disconnect ($objPtr);
    
        if ( $returnCode != GOOD )
        {
            print "Failed to disconnect from the controllers \n";
            return ERROR;
        }
    }
    return $productID;
}
###############################################################################


1;
__END__

###############################################################################
