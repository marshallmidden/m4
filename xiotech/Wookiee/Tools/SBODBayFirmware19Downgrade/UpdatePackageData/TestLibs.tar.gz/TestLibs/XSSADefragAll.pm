
=head2 XSSADefragAllEntry function

This test case calls either a passed test case number or will run all test cases (default)
     0) 
 
=cut

=over 1

=item Usage:

 my $rc = XSSADefragAllEntry( $coPtr,  $snPtr, $moxaIP, $mmPtr, $group, $sernm, $case, $loopCount ); }


 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $moxaPtr is a pointer to a list of Moxa controller IP addresses
        $mmPtr is a pointer to a list of tha Moxa channel mappings
		$group is a pointer to the selected disk group 
		$sernm is a pointer to the controller serial numbers
        $case is the test case to run
		$loopCount is a pointer to the loop count

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:



=item Initial Conditions:


=back

=cut

# Put in XSSADefrag.pm
##############################################################################
#
#          Name: XSSADefragAllEntry
#
#
#    Description:  Copyright 2004 XIOtech Corporation
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub XSSADefragAllEntry
{
    trace();
    my ( $coPtr,  $snPtr, $moxaIP, $mmPtr, $group, $sernm, $case, $loopCount ) = @_;

    my $ret;
    my $autoLoop;

    $autoLoop = 0;
    $ret = GOOD;



    my @coList = @$coPtr;



    if ( !$loopCount )
    {
        logInfo("LoopCount was not specified, default values will be used.");
        $autoLoop = 1;
    }

    if ( $case == 99 )
    {
        logInfo("All test cases selected, default loop count values will be used.");
        $autoLoop = 1;
    }


    CtlrLogTextAll( $coPtr, "------------------------------------------------------");
    CtlrLogTextAll( $coPtr, "                Starting XSSA Defrag All $case. ");
    CtlrLogTextAll( $coPtr, "------------------------------------------------------");

   # StatsProcAll($coPtr);



    
    #
    # Start of Test Case calls
    #
	if ( $autoLoop == 1 ) { $loopCount = 1; }
	if ( $case==1   || $case == 99 ) { $ret = XSSADefragAllCase01( $coPtr,  $snPtr, $moxaIP, $mmPtr, $group, $sernm, $case, $loopCount ); }
    if ( $ret != GOOD ) { return $ret; }

	if ( $autoLoop == 1 ) { $loopCount = 1; }
	if ( $case==2   || $case == 99 ) { $ret = XSSADefragAllCase02( $coPtr,  $snPtr, $moxaIP, $mmPtr, $group, $sernm, $case, $loopCount ); }
    if ( $ret != GOOD ) { return $ret; }



    # StatsProcAll($coPtr);
    # PeriodicDataGather($coPtr);
	
	#
    # Unreserve ICON - Completes Clean up
    #
	$return = unreserve( $sernm );
    
    if($return != XMCGOOD)
    {
        logInfo("Unable to unreserve CNC $sernm ");
        return ERROR;
    }


    return $ret;

}





=head2 XSSADefragAllCase01 function

This test case creates Vdisks and causes a fragmentaion by which a DefragAll is run.
     0) Log into XSSA
     1) Find free Vblocks
     2) Find free workset
	 3) Using Disk Group 23 by default.  Engineering Test will call out specific configurations (i.e. Economy, Enterprise or Low Cost)
	    in the Virtual Configuration document.  Others may use, however the default will be Enterprise unless previously defined.
     4) Find available PDisks
     5) Creates 4 Vdisks (Raid 5,10,5 & 10)
     6) Deletes the first Vdisk to create a fragmentaion
     7) Starts DefragAll
     8) Checks DefragAll Status until complete
     9) House cleaning (remove the 3 remaining test Vdisks)
 
=cut

=over 1

=item Usage:

 my $rc = XSSADefragAllCase01( $coPtr,  $snPtr, $moxaIP, $mmPtr, $group, $sernm, $case, $loopCount ); }


 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $moxaPtr is a pointer to a list of Moxa controller IP addresses
        $mmPtr is a pointer to a list of tha Moxa channel mappings
		$group is a pointer to the selected disk group 
		$sernm is a pointer to the controller serial numbers
        $case is the test case to run
		$loopCount is a pointer to the loop count

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:



=item Initial Conditions:


=back

=cut
# Put in XSSADefrag.pm
##############################################################################
#
#          Name: XSSADefragAllCase01
#
#
#    Description:  Copyright 2004 XIOtech Corporation
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub XSSADefragAllCase01

{
     trace();
    my ( $coPtr,  $snPtr, $moxaIP, $mmPtr, $group, $sernm, $case, $loopCount ) = @_;

    my $testGroup    = $group;
	
	#
	# Local Variables
	#
	my @VdId =(0, 1, 2, 3); 
    my @Raid = (5, 10, 5, 10);
    my @Capacity = (512, 1024, 2048, 3072); # units are in MB
    my @DiskGroup = (23, 23, 23, 23);
    my @Name = ("DefragAll1", "DefragAll2", "DefragAll3", "DefragAll4");
    my @DataDr;
    my @WorkSet;
    my @Vblock;
    my @FreeWorkSet; 
    my @FreeVblock;
    my $TestLoop;


    my $return;
    my @ccbeObjArray;

    my $mes = "***** Starting ICON Defrag All test - Case 01 ";

  
    $return = CtlrLogTextAll(\@ccbeObjArray, $mes);
    
    if($return != GOOD)    
    {
        logInfo("Unable to send message to controller logs");
        return ERROR;   
    }

    logInfo(" ");
    logInfo("----------- Starting ICON defrag All test - Case 01 -----------");
    logInfo(" ");


    TestLibs::Logging::logInfo("Reserving device $sernm");

    #
    # Reserve the ICON
    #

    if(XSSA_Reserve($sernm) != GOOD)
    {
        logInfo("Unable to reserve CNC $sernm");
        return ERROR;
    }
    #
    # Start Defrag All System Clean Up, check status until completion
    #
    logInfo("Defrag All System Clean Up - Started");

    $return = XIOtech::sanscript::defragAll("start");
    
    if($return == XMCGOOD )
    {
        logInfo("Unable to start defrag all");
        DumpXSSAError();
        return ERROR;           
    }

	#
    # Checking Defrag All System Clean Up Status
	#
    $i = 1;
    my $loopall = 0;
	while (1 == $i)	
	{
	    $loopall++;
	    #
		# Sleep for 60 seconds giving ICON time to update
		#
		DelaySecs(60);
        $return = XIOtech::sanscript::defragAll("Status");
        
       	#
        # status returns 1 if defrag all is started 
        # status returns 0 if defrag all is stopped 
		#
        if($return == 1 )
        {
            print "                                             * Defrag All (System Clean Up) is Running, Loop: $loopall\r";           
        }
		else
        {
            print "                                             * Defrag All (System Clean Up) has completed, Loop: $loopall\n";
            $i = 0; 

        }
	}

    logInfo("Defrag All System Clean Up - Completed");

	#
	# Start of Setup loop
	#

    for($TestLoop = 0; $TestLoop < $loopCount; $TestLoop++)
	{
	    #
	    # Check for free Vblocks
	    # Use first free Vblock found
		#
		logInfo("Looking for free Vblocks and free Worksets");

	    $return = FindFreeWB(\@FreeVblock, \@FreeWorkSet);
	    
	    if($return != GOOD)
	    {
	        logInfo("Error occured while getting free Vblocks and Worksets");
	        return ERROR;
	    }
	    
	    if(scalar(@FreeVblock) == 0)
	    {
	        logInfo("There are no free Vblocks available");
	        return ERROR;
	    }
	    
	    logInfo("Following Vblocks are free @FreeVblock ");

	    #
	    # Check for free workset
	    # Use first free Workset found
		#
		if(scalar(@FreeWorkSet) == 0)
	    {
	        logInfo("There are no free Worksets available");
	        return ERROR;
	    }
	    logInfo("Following Worksets are free @FreeWorkSet");

	    #
	    # Build Vblock and Workset array
	    #
	    for(my $loop = 0; $loop < scalar(@Name); $loop++)
	    {
	        push(@WorkSet, $FreeWorkSet[0]);
	        push(@Vblock, $FreeVblock[0]);
	    }
	    
	    logInfo("Getting list of all data drives....");
	    
	    $return = PdList(\@DataDr, XSSADATATYPE);
	    
	    if($return != GOOD) # in case of error, first element is Invalid
	    {
	        logInfo("Unable get list of Pd Id labeled as ". XSSADATATYPE);
	        return ERROR;   
	    }
	    
	    if(scalar(@DataDr) == 0)
	    {
	        logInfo("There are no drives labeled as data");
	        return ERROR;           
	    }
		$workset = $FreeWorkSet[0];

		#
	    # Setting up DiskGroups
	    #
		logInfo("Setting Disk Group to $DiskGroup[0]");
	    
	    $return = diskgroupSet( $DiskGroup[0] );
	    
	    if($return != XMCGOOD)
	    {
	        logInfo("Unable to set disk group $DiskGroup[0]");
	        DumpXSSAError();
	        return ERROR;       
	    }

	    $vblock = $FreeVblock[0];
	    #
	    # Adding Drives to DiskGroup
	    #
		logInfo("Adding all data drives to disk group $DiskGroup[0]");
	    
	    $return = diskgroupAdd(@DataDr);
	    
	    if($return != XMCGOOD)
	    {
	        logWarning("Unable to add Pdisk IDs: @DataDr to disk group $DiskGroup[0]");
	        DumpXSSAError();
	        return ERROR;
	    }   
	 
	    #
	    # Create 4 Vdisks
	    #
	    for( $loop = 0; $loop < scalar(@VdId); $loop++)
	    {
	        logInfo(" ");
	        logInfo("Creating VDisk $VdId[$loop] RAID $Raid[$loop] capacity $Capacity[$loop]");

	        $return = VDCreate( $Name[$loop], 
	                            $Capacity[$loop], 
	                            $VdId[$loop], 
	                            $Raid[$loop], 
	                            $workset, 
	                            $vblock, 
	                            $PdGroup[$loop]);
	        
	        if($return != GOOD)
	        {
	            logWarning("Unable to create VDisk $VdId[$loop]");
	            return ERROR;               
	        }
	    }

	    #
	    # Delete a VDisk to create a hole in the RAID allocation
	    #    
	    logInfo("Deleting VDisk $VdId[0]");
		print "Deleting VDisk $VdId[$loop]\n";
	    $return = vdiskDelete($VdId[0]);
	    
	    if($return != XMCGOOD )
	    {
	        logWarning("Unable to delete VDisk $VdId[$loop]");
	        DumpXSSAError();
	        return ERROR;           
	    }



		#
        # Start Defrag all, check status until completion
        #
        logInfo("Defrag All Test Started - Case 1");

        $return = XIOtech::sanscript::defragAll("start");
        
        if($return == XMCGOOD )
        {
            logInfo("Unable to start defrag all");
            DumpXSSAError();
            return ERROR;           
        }

		#
        # Checking Defrag All Status
		#
        
        my $loopall = 0;
	    while (1 == $i)	
	    {
	    $loopall++;
		    #
			# Sleep for 60 seconds giving ICON time to update
			#
			DelaySecs(60);
	        $return = XIOtech::sanscript::defragAll("Status");
	        
	       	#
            # status returns 1 if defrag all is started 
            # status returns 0 if defrag all is stopped 
			#
	            if($return == 1 )
            {
                print "                                             * Defrag All is Running, Loop: $loopall\r";           
            }
		        else
            {
                print "                                             * Defrag All has completed, Loop: $loopall\n";
                $i = 0; 
			}
		}

        logInfo("Defrag All Test Completed - Case 1");
	    
	    #
	    # Clean Up Part 1 of 2 - remove Vdisks created and prepare for next loop
	    #
	    for($loop = 1; $loop < scalar(@VdId); $loop++)
	    {
	        $return = vdiskDelete($VdId[$loop]);
	        if($return != XMCGOOD )
	        {
	            logInfo("Unable to delete VDisk $VdId[$loop]");
	            DumpXSSAError();
	            return ERROR;           
	        }
	    }

	    #
        # Remove Vblock
        #
		$return = XIOtech::sanscript::vblockRemove($vblock);
        if($return == XMCGOOD )
        {
              print "vblock $vblock has been removed from workset $workset\n";
        }

	    #
        # Start Defrag All System Clean Up Part 2, check status until completion
        #
        logInfo("Defrag All System Clean Up Part 2 - Started");

        $return = XIOtech::sanscript::defragAll("start");
        
        if($return == XMCGOOD )
        {
            logInfo("Unable to start defrag all");
            DumpXSSAError();
            return ERROR;           
        }

		#
        # Checking Defrag All System Clean Up Status
		#
        $i = 1;
        while (1 == $i)
        {
		    #
			# Sleep for 60 seconds giving ICON time to update
			#
			DelaySecs(60);
	        $return = XIOtech::sanscript::defragAll("Status");
	        
	       	#
            # status returns 1 if defrag all is started 
            # status returns 0 if defrag all is stopped 
			#
	        if($return == 1 )
	        {
	            print "Defrag All System Clean Up Part 2 is Running\r";           
	        }
			else
	        {
	            print "Defrag All System Clean Up Part 2 has completed\n";
	            $i = 0; 
	        }
			DelaySecs(10);
		}

        logInfo("Defrag All System Clean Up Part 2 - Completed");
 


		#
		# Re connect to controllers - Timeout may have occured
		#
		$return = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 

	    if($return != GOOD)    
	    {
	        logInfo("Unable to log in to one or more Controllers");
	        return ERROR;   
	    }


	    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
	    CtlrLogTextAll( $coPtr, "           XSSA Defrag All $case ends. ");
	    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
    }
return GOOD;
}

=head2 XSSADefragAllCase02 function

This test case creates Vdisks and causes a fragmentaion by which a DefragAll is run.
     0) Log into XSSA
     1) Find free Vblocks
     2) Find free workset
	 3) Using Disk Group 23 by default.  Engineering Test will call out specific configurations (i.e. Economy, Enterprise or Low Cost)
	    in the Virtual Configuration document.  Others may use, however the default will be Enterprise unless previously defined.
     4) Find available PDisks
     5) Creates 4 Vdisks (Raid 5,10,5 & 10)
     6) Deletes the first Vdisk to create a fragmentaion
     7) Starts DefragAll
     8) Checks DefragAll Status until complete
     9) House cleaning (remove the 3 remaining test Vdisks)
 
=cut

=over 1

=item Usage:

 my $rc = XSSADefragAllCase02( $coPtr,  $snPtr, $moxaIP, $mmPtr, $group, $sernm, $case, $loopCount ); }


 where: $coPtr is a pointer to a list of controller objects
        $snPtr is a pointer to a list of controller serial numbers
        $moxaPtr is a pointer to a list of Moxa controller IP addresses
        $mmPtr is a pointer to a list of tha Moxa channel mappings
		$group is a pointer to the selected disk group 
		$sernm is a pointer to the controller serial numbers
        $case is the test case to run
		$loopCount is a pointer to the loop count

=item Returns:

       $rc will be GOOD or ERROR. The user should verify correct operation
           by reviewing the logs.

=item Things to look for:



=item Initial Conditions:


=back

=cut
# Put in XSSADefrag.pm
##############################################################################
#
#          Name: XSSADefragAllCase02
#
#
#    Description:  Copyright 2004 XIOtech Corporation
#                 
#                  For XIOtech internal use only.
#
#############################################################################################
sub XSSADefragAllCase02

{
     trace();
    my ( $coPtr,  $snPtr, $moxaIP, $mmPtr, $group, $sernm, $case, $loopCount ) = @_;

    my $testGroup    = $group;
	
	#
	# Local Variables
	#
	my @VdId =(0, 1, 2, 3); 
    my @Raid = (5, 10, 5, 10);
    my @Capacity = (512, 1024, 2048, 3072); # units are in MB
    my @DiskGroup = (23, 23, 23, 23);
    my @Name = ("DefragAll1", "DefragAll2", "DefragAll3", "DefragAll4");
    my @DataDr;
    my @WorkSet;
    my @Vblock;
    my @FreeWorkSet; 
    my @FreeVblock;
    my $TestLoop;


    my $return;
    my @ccbeObjArray;

    my $mes = "***** Starting ICON Defrag All test - Case 02 ";

  
    $return = CtlrLogTextAll(\@ccbeObjArray, $mes);
    
    if($return != GOOD)    
    {
        logInfo("Unable to send message to controller logs");
        return ERROR;   
    }

    logInfo(" ");
    logInfo("----------- Starting ICON defrag All test - Case 02 -----------");
    logInfo(" ");


    TestLibs::Logging::logInfo("Reserving device $sernm");

    #
    # Reserve the ICON
    #

    if(XSSA_Reserve($sernm) != GOOD)
    {
        logInfo("Unable to reserve CNC $sernm");
        return ERROR;
    }
    #
    # Start Defrag All System Clean Up, check status until completion
    #
    logInfo("Defrag All System Clean Up - Started");

    $return = XIOtech::sanscript::defragAll("start");
    
    if($return == XMCGOOD )
    {
        logInfo("Unable to start defrag all");
        DumpXSSAError();
        return ERROR;           
    }

	#
    # Checking Defrag All System Clean Up Status
	#
    $i = 1;
    my $loopall = 0;
	while (1 == $i)	
	{
	    $loopall++;
	    #
		# Sleep for 60 seconds giving ICON time to update
		#
		DelaySecs(60);
        $return = XIOtech::sanscript::defragAll("Status");
        
       	#
        # status returns 1 if defrag all is started 
        # status returns 0 if defrag all is stopped 
		#
        if($return == 1 )
        {
            print "                                             * Defrag All (System Clean Up) is Running, Loop: $loopall\r";           
        }
		else
        {
            print "                                             * Defrag All (System Clean Up) has completed, Loop: $loopall\n";
            $i = 0; 

        }
	}

    logInfo("Defrag All System Clean Up - Completed");

	#
	# Start of Setup loop
	#

    for($TestLoop = 0; $TestLoop < $loopCount; $TestLoop++)
	{
	    #
	    # Check for free Vblocks
	    # Use first free Vblock found
		#
		logInfo("Looking for free Vblocks and free Worksets");

	    $return = FindFreeWB(\@FreeVblock, \@FreeWorkSet);
	    
	    if($return != GOOD)
	    {
	        logInfo("Error occured while getting free Vblocks and Worksets");
	        return ERROR;
	    }
	    
	    if(scalar(@FreeVblock) == 0)
	    {
	        logInfo("There are no free Vblocks available");
	        return ERROR;
	    }
	    
	    logInfo("Following Vblocks are free @FreeVblock ");

	    #
	    # Check for free workset
	    # Use first free Workset found
		#
		if(scalar(@FreeWorkSet) == 0)
	    {
	        logInfo("There are no free Worksets available");
	        return ERROR;
	    }
	    logInfo("Following Worksets are free @FreeWorkSet");

	    #
	    # Build Vblock and Workset array
	    #
	    for(my $loop = 0; $loop < scalar(@Name); $loop++)
	    {
	        push(@WorkSet, $FreeWorkSet[0]);
	        push(@Vblock, $FreeVblock[0]);
	    }
	    
	    logInfo("Getting list of all data drives....");
	    
	    $return = PdList(\@DataDr, XSSADATATYPE);
	    
	    if($return != GOOD) # in case of error, first element is Invalid
	    {
	        logInfo("Unable get list of Pd Id labeled as ". XSSADATATYPE);
	        return ERROR;   
	    }
	    
	    if(scalar(@DataDr) == 0)
	    {
	        logInfo("There are no drives labeled as data");
	        return ERROR;           
	    }
		$workset = $FreeWorkSet[0];

		#
	    # Setting up DiskGroups
	    #
		logInfo("Setting Disk Group to $DiskGroup[0]");
	    
	    $return = diskgroupSet( $DiskGroup[0] );
	    
	    if($return != XMCGOOD)
	    {
	        logInfo("Unable to set disk group $DiskGroup[0]");
	        DumpXSSAError();
	        return ERROR;       
	    }

	    $vblock = $FreeVblock[0];
	    #
	    # Adding Drives to DiskGroup
	    #
		logInfo("Adding all data drives to disk group $DiskGroup[0]");
	    
	    $return = diskgroupAdd(@DataDr);
	    
	    if($return != XMCGOOD)
	    {
	        logWarning("Unable to add Pdisk IDs: @DataDr to disk group $DiskGroup[0]");
	        DumpXSSAError();
	        return ERROR;
	    }   
	 
	    #
	    # Create 4 Vdisks
	    #
	    for( $loop = 0; $loop < scalar(@VdId); $loop++)
	    {
	        logInfo(" ");
	        logInfo("Creating VDisk $VdId[$loop] RAID $Raid[$loop] capacity $Capacity[$loop]");

	        $return = VDCreate( $Name[$loop], 
	                            $Capacity[$loop], 
	                            $VdId[$loop], 
	                            $Raid[$loop], 
	                            $workset, 
	                            $vblock, 
	                            $PdGroup[$loop]);
	        
	        if($return != GOOD)
	        {
	            logWarning("Unable to create VDisk $VdId[$loop]");
	            return ERROR;               
	        }
	    }

	    #
	    # Delete a VDisk to create a hole in the RAID allocation
	    #    
	    logInfo("Deleting VDisk $VdId[0]");
		print "Deleting VDisk $VdId[$loop]\n";
	    $return = vdiskDelete($VdId[0]);
	    
	    if($return != XMCGOOD )
	    {
	        logWarning("Unable to delete VDisk $VdId[$loop]");
	        DumpXSSAError();
	        return ERROR;           
	    }


		#
        # Start Defrag all, check status until completion
        #
        logInfo("Defrag All Test Started - Case 2");

        $return = XIOtech::sanscript::defragAll("start");
        
        if($return == XMCGOOD )
        {
            logInfo("Unable to start defrag all");
            DumpXSSAError();
            return ERROR;           
        }

		#
        # Checking Defrag All Status
		#
    
        my $loopall = 0;
	    while (1 == $i)	
	    {
	    $loopall++;
		    #
			# Sleep for 60 seconds giving ICON time to update
			#
			DelaySecs(60);
	        $return = XIOtech::sanscript::defragAll("Status");
	        
	       	#
            # status returns 1 if defrag all is started 
            # status returns 0 if defrag all is stopped 
			#
	            if($return == 1 )
            {
                print "                                             * Defrag All is Running, Loop: $loopall\r";           
            }
		        else
            {
                print "                                             * Defrag All has completed, Loop: $loopall\n";
                $i = 0; 
			}
		}

        logInfo("Defrag All Test Completed - Case 2");
	    
	    #
	    # Clean Up Part 1 of 2 - remove Vdisks created and prepare for next loop
	    #
	    for($loop = 1; $loop < scalar(@VdId); $loop++)
	    {
	        $return = vdiskDelete($VdId[$loop]);
	        if($return != XMCGOOD )
	        {
	            logInfo("Unable to delete VDisk $VdId[$loop]");
	            DumpXSSAError();
	            return ERROR;           
	        }
	    }

	    #
        # Remove Vblock
        #
		$return = XIOtech::sanscript::vblockRemove($vblock);
        if($return == XMCGOOD )
        {
              print "vblock $vblock has been removed from workset $workset\n";
        }

	    #
        # Start Defrag All System Clean Up Part 2, check status until completion
        #
        logInfo("Defrag All System Clean Up Part 2 - Started");

        $return = XIOtech::sanscript::defragAll("start");
        
        if($return == XMCGOOD )
        {
            logInfo("Unable to start defrag all");
            DumpXSSAError();
            return ERROR;           
        }

		#
        # Checking Defrag All System Clean Up Status
		#
        $i = 1;
        while (1 == $i)
        {
		    #
			# Sleep for 60 seconds giving ICON time to update
			#
			DelaySecs(60);
	        $return = XIOtech::sanscript::defragAll("Status");
	        
	       	#
            # status returns 1 if defrag all is started 
            # status returns 0 if defrag all is stopped 
			#
	        if($return == 1 )
	        {
	            print "Defrag All System Clean Up Part 2 is Running\r";           
	        }
			else
	        {
	            print "Defrag All System Clean Up Part 2 has completed\n";
	            $i = 0; 
	        }
			DelaySecs(10);
		}

        logInfo("Defrag All System Clean Up Part 2 - Completed");
 


		#
		# Re connect to controllers - Timeout may have occured
		#
		$return = TestLibs::IntegCCBELib::CcbeConnectAll($xtcDataPtr->{VCGS}->{$testGroup}->{'bigfoot'}->{'vcgIP'}, \@ccbeObjArray); 

	    if($return != GOOD)    
	    {
	        logInfo("Unable to log in to one or more Controllers");
	        return ERROR;   
	    }


	    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
	    CtlrLogTextAll( $coPtr, "           XSSA Defrag All $case ends. ");
	    CtlrLogTextAll( $coPtr, "---------------------------------------------------");
    }
return GOOD;
}


1;   # we need this for a PM
