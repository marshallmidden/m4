#! /usr/bin/perl
# $Header$
##############################################################################
#
#   CCBE Integration test library
#
#   4/08/2002  Xiotech   Craig Menning
#
#   A set of library functions for integration testing. The first group
#   will be for basic configuration activity.
#
#   It is expected that the user will write a perl script that calls
#   these.
#
#   Copyright 2002-2006 Xiotech Corporation. All rights reserved.
#
#   For Xiotech internal use only.
#
##############################################################################

#
# - what I am
#

package TestLibs::IntegCCBELib;

#
# - other modules used
#

use warnings;
use lib "../CCBE";

use Time::localtime;

use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use TestLibs::Logging;
use TestLibs::Constants qw(:DEFAULT :CCBE);
use TestLibs::utility;
use TestLibs::Fibre;
use TestLibs::xiocontrol;

#use TestLibs::BEUtils;
use TestLibs::VlinksLibs;
#use TestLibs::VdiskPriority;
#use TestLibs::Validate;
use strict;

#
# - Constants used
#

             # these are bit significant
#use constant NO_RAID_INIT => 1;    # for makeVdisks, defrag test
#use constant DEFRAG_WAIT => 2;     # for defrag test

# raid types
#use constant RAID_NONE => 0;  #define RAID_NONE 0
#use constant RAID_0 => 1;     #define RAID_0 1
#use constant RAID_1 => 2;     #define RAID_1 2
#use constant RAID_5 => 3;     #define RAID_5 3
#use constant RAID_10 => 4;    #define RAID_10 4

#
# - some global variables/constant
#

my $currentConnection = -1;
my $currentIP = "";
my $currentPort = CCB_PORT;
my $currentMgr;
my $numNextConnection = 0;
my %connections;


#
# - A note on parameters.
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional dta, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS.
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.05;
    # if using RCS/CVS, this may be preferred
    #$VERSION = do { my @r = (q$Revision: 50662 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker


                    #    &AsciiHexToBin
                     #   &CalcTime
                     #   &CheckWWN
                     #   &DecToAsciiHexData
                    #    &DelaySecs
                    #    &min
                    #    &PromptUser
                    #     &ActiveServerList
    #                    &GetServerIO
           #             &TestSystemState
        #                &TestForServerIO



                        # These are no longer exposed here because they are
                        # also exposed, as exact duplicates, in GoodPath.pm
                        # Include GoodPath.pm to use these functions.
                        #
                        #&GoodPathIOTest
                        #&GoodPathSubset1
                        #&GoodPathSuperset
                        #&GoodPathTest

                        #&DefragBegin      in defrag.pm
                        #&DefragPart1
                        #&DefragPart2
                        #&DefragPart3
                        #&DefragPart4
                        #&DefragTest
                        #&FindFirstNew

    @ISA         = qw(Exporter);
    @EXPORT      = qw(

                        &AddController
                        &AssociateServers
                        &AssociateSingleVdisk

                        &BasicConfig
                        &BEETLoop
                        &BreakAllMirrorVdisks
                        &BypassBEHubPorts

                        &CacheCycleTest

                        &ccbe_connect
                        &CcbeConnectAll
                        &CcbeConnectAllWithRetries
                        &ccbe_disconnect
                        &CheckInitProgress
                        &ConfigSelect
                        &ConfigView
                        &CorruptBENvram
                        &CreateExpandInitDelete
                        &CreateSingleVdisk
                        &CreateSingleVlink
                        &CtlrLogText
                        &CtlrLogTextAll
                        &CtlrLogTextList



                        &DegradeCheck
                        &DegradeCheckRunning
                        &DeleteAllVdisks
                        &DeleteAllVdisks2
                        &DeleteSingleVdisk
                        &DisableCache
                        &disableHealthMonitor
                        &DisassocAll
                        &DisassocOne
                        &DispPdiskInfo
                        &DispVcgInfo
                        &DispVdiskInfo
                        &DispVdisksRaids

                        &ElectionsTest
                        &ElectionsTestNWay
                        &EnableCache
                        &ExpandVdisks


                        &ErrorTrapController

                        &FailController
                        &FailDrivesTest
                        &FindMaster
                        &FindServerMates
                        &FindSIDs

                        &GenericMRP

                        &GetAllVdiskDataDisks
                        &GetActiveDataDisks
                        &GetDataDisks
                        &GetDriveLabel
                        &GetGroupSerial
                        &GetMyLicense
                        &GetPddList
                        &GetPowerUpState
                        &GetRaidIDs
                        &GetRMState
                        &GetSerial
                        &GetSerialFromMaster
                        &GetSIDs
                        &GetStatePO
                        &GetStatePOQ
                        &GetTargetStatus
                        &GetTheseDisks
                        &GetUsedLuns
                        &GetVdiskList
                        &GetVdisksOnPdisk
                        &GetAdminTime
                        &GimmieLicense
                        &GotRaid5


                        &GPCaching
                        &GPCase1
                        &GPCase1IO
                        &GPCase1TwoWay
                        &GPCreateExpand
                        &GPCreateExpandDelete
                        &GPCreateExpandDelete2
                        &GPCreateExpandDeleteTest
                        &GPDeviceStatus
                        &GPDiskBayCommands
                        &GPFidRead
                        &GPLoggingTest
                        &GPMemoryLeakTest
                        &GPMiscCommands
                        &GPModes
                        &GPPhysicalDiskCommands
                        &GPRaidCommands
                        &GPReal1Way
                        &GPReal2Way
                        &GPResetTest
                        &GPServerCommands
                        &GPStatsCommands
                        &GPTargetCommands
                        &GPVdiskMisc
                        &GPVirtualDiskCommands
                        &GPVirtualDiskCommands2
                        &GPVirtualDiskCommandsTest

                        &HoldResetPower

                        &IcTestMenu
                        &InitializeAllVdisks
                        &InitializeSomeVdisks
                        &InitVdiskRids
                        &IsControllerAlive

                        &LabelAllDrives
                        &LabelSingleDrive
                        &LabelSomeDrives
                        &ListSIDs
                        &LogTargetStatus

                        &MakeMirror
                        &MakeNWay
                        &MakeVCG
                        &MakeVdisks

                        &NoSuicide
                        &NoFailureManager

                        &FindMasterPickSlave
                        &PdiskGotRaid
                        &PingAll
                        &PowerChange
                        &PowerCheck
                        &PowerCycle
                        &PrintError

                        &QLTest1
                        &QLReset
                        &QLResetTestRnd
                        &QLResetTestSeq

                        &RebootControllers
                        &Reconnect
                        &ReLabelPD
                        &ReLabelSingleDrive
                        &RescanBE
                        &resetAll

                        &SanLinksAssoc
                        &SelectMapOption
                        &SelectServers
                        &SelectVdiskOption
                        &SendCode2Drive
                        &SetServerProp
                        &ShowRids
                        &ShowServerInfo
                        &ShowVdisks
                        &SingleItemMenu
                        &StatsProcAll
                        &SuicideOK

                        &TargetList
                        &TestMain
                        &TestMenu
                        &TestNReconnect
                        &TestNReconnectAll

                        &ViewLicenseState

                        &Unconfigure
                        &UnFailController
                        &UpdateDriveCode

                        &ValidateVdiskParams
                        &VdiskMenu
                        &ViewLicenseState

                        &WaitRMSTateRUNNING
                        &Wipe2Clean
                        &WipeControllersClean
                        &WipeControllersClean2

                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    # your exported package globals go here,
    # as well as any optionally exported functions
    #@EXPORT_OK   = qw($Var1 %Hashit &func3);

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 50662 $);
}
    our @EXPORT_OK;


##############################################################################
#
#          Name: GetActiveDataDisks
#
#        Inputs: controller object
#                ptr to list of active vdisks (ie. from MakeActiveVdiskMap)
#                interface type  
#                   - PD_DT_ALL       ALL disk types
#                   - PD_DT_FC_DISK   FC disks only
#                   - PD_DT_SATA      SATA disks only
#                   - PD_DT_STP       STP disks only
#                   - FC_PREFERRED    
#                   - SATA_PREFERRED 
#                   - PD_DT_ISE_HIGH_PERF
#                   - PD_DT_ISE_PERF
#                   - PD_DT_ISE_BALANCE
#                   - PD_DT_ISE_CAPACITY
#
#                minimum number of user segments required on each pdisk  
#                minimum number of active user segments required on each pdisk
#                ptr to results array
#
#       Outputs: GOOD    - successful, active data disks meeting requirements 
#                          were found.  PIDs and segment info for those pdisks 
#                          are stored in the results array  
#                INVALID - successful, but no pdisks meeting requirements 
#                          specified were found.     
#                ERROR   - function failed   
#
#                If the return code is GOOD, the results array is loaded with 
#                the following array of hashes.  The array is sorted in order of 
#                highest percentage of segments active to lowest.  
#
#                @results => ARRAY
#                   0  HASH
#                      'PID' => 1
#                      'SEGMENTS' => 14
#                      'ACTIVESEGMENTS'=> 14
#                      'PERCENTACTIVE'=> 100
#                   1  HASH
#                      'PID' => 5
#                      'SEGMENTS' => 10
#                      'ACTIVESEGMENTS'=> 7
#                      'PERCENTACTIVE'=> 70
#
#  Globals Used: none
#
#   Description: Function searches thru all pdisks on controller for any  
#                pdisks that meet the specified requirements.    
#                - If it finds some, it returns GOOD and the PIDs and segment 
#                  info are stored in the results array 
#                - If the function completes successfully, but no pdisks of
#                  the specified type are found, it returns INVALID
#                - If the function fails for some reason, it returns ERROR 
#
#
##############################################################################
sub GetActiveDataDisks
{
    trace();
    my ($ctlr, $activeVdisksPtr, $hdType, $minSegs, $minActiveSegs, $resultsPtr) = @_;

    my @activeVdisks = @$activeVdisksPtr;
             
    my %info;
    my $i;
    my $j;
    my @activeRaids;
    my @dataDisks;
    my $numDataDisks;
    my @pdiskActivity;
    my @sortedPdiskActivity;
    my $segCount;
    my $numActivePdisks;
    my $entry;
    
    #
    # Determine raids that are active based on the active vdisk list
    # Loop thru all the raids and save the ones that correlate to an active vdisk
    #
    %info = $ctlr->raids();
    if ( ! %info  )             
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )    
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }
  
    for ( $i = 0; $i < $info{COUNT}; $i++ )
    {
        for ( $j = 0; $j < scalar(@activeVdisks); $j++ )
        {   
            if ( $activeVdisks[$j] == $info{RAIDS}[$i]{VID} )
            {
                push( @activeRaids, $info{RAIDS}[$i]{RID} );
                last;
            }
        }                  
    }       

    #
    # Get a list of all the data disks
    #
    @dataDisks = GetDataDisks( $ctlr, $hdType );
    if ( $dataDisks[0] == INVALID)
    {
        logInfo(">>>>>>>> Error from GetDataDisks <<<<<<<<");
        return ERROR;
    }
    $numDataDisks = scalar(@dataDisks);
  
    # 
    # Go thru each data disk and find out how many segments are on each and 
    # how many of the segments have activity from the servers.
    #
    $numActivePdisks = 0; 
    for ( $i = 0; $i < $numDataDisks; $i++ )
    {
    
        #
        # Get the SOS info
        #
        %info = $ctlr->getSos( $dataDisks[$i] );
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from getSos($dataDisks[$i]) <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error from getSos($dataDisks[$i]) <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
        
        #
        # Skip any pdisks that don't have the minimum number of user segments
        # requested.
        #
        if ( $info{COUNT} < ( $minSegs + 1 )  ) 
        {
            next;
        } 
       
        #
        # Find the number of segments that have activity
        #
        $segCount = 0;
        for ( $j = 0; $j < $info{COUNT}; $j++ )
        {
            if ( IsInList( $info{LIST}[$j]{RID}, \@activeRaids ) )
            {
                $segCount++;
            }
        }

        #
        # Skip any pdisks that don't have the minimum number of active user segments
        # requested.
        #
        if ( $segCount < $minActiveSegs ) 
        {
            next;
        } 

        #
        # If we got here, then we want to include this pdisk.
        # Store the pid for each data disk
        #
        $pdiskActivity[$numActivePdisks]{PID} = $dataDisks[$i];
       
        #
        # Store the number of data segments on this pdisk         
        #
        $pdiskActivity[$numActivePdisks]{SEGMENTS} = $info{COUNT} - 1;
        
        #
        # Store the number of active data segments on this pdisk         
        #
        $pdiskActivity[$numActivePdisks]{ACTIVESEGMENTS} = $segCount;
        
        #
        # Calculate percentage active and store         
        #
        if ( $pdiskActivity[$numActivePdisks]{SEGMENTS} == 0 )
        {
            $pdiskActivity[$numActivePdisks]{PERCENTACTIVE} = 0;
        }
        else
        { 
            $pdiskActivity[$numActivePdisks]{PERCENTACTIVE} = 
                int( ($pdiskActivity[$numActivePdisks]{ACTIVESEGMENTS} * 100)
                    / $pdiskActivity[$numActivePdisks]{SEGMENTS} ); 
        }
        
        #
        # Increment counter
        #
        $numActivePdisks++;        
    }
   
    #
    # Check number of active pdisk.  If we don't have any, return INVALID
    #
    if ( $numActivePdisks == 0 )
    {
        logInfo("No active pdisks are available that meet specified criteria.");
        return INVALID;
    } 
   
    #
    # Sort the array ordered from most active to least
    #
    sub activity 
    {
        $b->{PERCENTACTIVE}     <=> $a->{PERCENTACTIVE}
        or $b->{ACTIVESEGMENTS} <=> $a->{ACTIVESEGMENTS} 
        or $b->{SEGMENTS}       <=> $a->{SEGMENTS} 
        or $a->{PID}            <=> $b->{PID} 
    }
    @sortedPdiskActivity = sort activity @pdiskActivity;

    #
    # put results in results array and return GOOD.
    #   
    @$resultsPtr = @sortedPdiskActivity;
  
    return GOOD; 
   

}

##############################################################################
#
#          Name: GetVdisksOnPdisk
#
#        Inputs: controller object
#                PID of pdisk
#                ptr to results array
#
#       Outputs: GOOD    - successful, vdisks were found.  VIDs are stored in  
#                          results array  
#                INVALID - successful, but no vdisks were found 
#                ERROR   - function failed   
#
#                If the return code is GOOD, the results array is loaded with 
#                the VIDs of vdisks that correspond to the raids found on the 
#                specified pdisk.  The vdisks in the array are in the same order
#                as the raids were on the pdisk.
#
#  Globals Used: none
#
#   Description: Function searches thru all user segments on a pdisk and 
#                determines the vdisks that correlate to the raid for each 
#                segment.   
#                - If it finds some, it returns GOOD and the VIDs for the vdisks
#                  are stored in the results array in the same order as the 
#                  segments were found on the pdisk. 
#                - If the function completes successfully, but there were no
#                  user segments on the pdisk, it returns INVALID 
#                - If the function fails for some reason, it returns ERROR 
#
#
##############################################################################
sub GetVdisksOnPdisk
{
    trace();
    my ($ctlr, $pdisk, $resultsPtr) = @_;

    my %sosInfo;
    my %raidInfo;
    my @vdisks;
    my $i;
    my $j;

    #
    # Get the SOS info
    #
    %sosInfo = $ctlr->getSos( $pdisk );
    if ( ! %sosInfo  )
    {
        logInfo(">>>>>>>> Failed to get response from getSos($pdisk) <<<<<<<<");
        return ERROR;
    }
    if ($sosInfo{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Error from getSos($pdisk) <<<<<<<<");
        PrintError(%sosInfo);
        return ERROR;
    }

    #
    # Get the Raids info
    #
    %raidInfo = $ctlr->raids();
    if ( ! %raidInfo  )             
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $raidInfo{STATUS} != PI_GOOD )    
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%raidInfo);
        return ERROR;
    }
    
    # 
    # Check if any user segments on pdisk
    #
    if ( $raidInfo{COUNT} < 2 )
    {
        logInfo("No user segments on PID $pdisk");
        return INVALID;
    }

    #
    # Find matching vdisk for each raid and put in vdisks array
    #    
    for ( $i = 0; $i < $sosInfo{COUNT}; $i++ )
    {
        for ( $j = 0; $j < $raidInfo{COUNT}; $j++ )
        {   
            if ( $raidInfo{RAIDS}[$j]{RID} == $sosInfo{LIST}[$i]{RID} )
            {
                push( @vdisks, $raidInfo{RAIDS}[$j]{VID} );
                last;
            }
        }                  
    }       

    # 
    # Check if any found
    #
    if ( scalar(@vdisks) < 1 )
    {
        logInfo("No vdisks on PID $pdisk");
        return INVALID;
    }

    #
    # If we got here, we have at least one valid VID
    #
    @$resultsPtr = @vdisks;
    
    return GOOD;

}

##############################################################################
#
#          Name: GetRaidIDs
#
#        Inputs: controller object, raid type, results array ptr
#                where:  raid type = RAID_0, RAID_1, RAID_5, or RAID_10
#
#       Outputs: GOOD    - successful, raid(s) of specified type were found.
#                          RIDs of those raids are stored in results array  
#                INVALID - successful, but no raids of specified type were 
#                          found 
#                ERROR   - function failed   
#
#  Globals Used: none
#
#   Description: Function searches thru all raids on controller for any  
#                raids of specified type.  
#                - If it finds some, it returns GOOD and the RIDs of those
#                  raids are stored in the results array 
#                - If the function completes successfully, but no raids of
#                  the specified type are found, it returns INVALID
#                - If the function fails for some reason, it returns ERROR 
#
#
##############################################################################
sub GetRaidIDs
{
    trace();
    my ($ctlr, $raidType, $resultsPtr) = @_;
    my %info;
    my $numRaids;
    my $raidIDsIndex;
    my @raidIDs;
    my $i;
    my $ret;

    $resultsPtr->[0] = INVALID;
    #
    # do "raids" to the controller to get a list of all raids and their RIDs
    #
#    %info = $ctlr->raids();
#    if ( ! %info  )             
#    {
#        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
#        return ERROR;
#    }
#    if ( $info{STATUS} != PI_GOOD )      
#    {
#        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
#        PrintError(%info);
#        return ERROR;
#    }
     
     
     
     
    $ret = GetRaidsWithRetry($ctlr, \%info);
    if ( $ret != GOOD )
    {
        logInfo("Error getting Raids Data");
        return ERROR;
    } 
     
     
     
    # logRaids(%info);

    $numRaids = $info{COUNT};

    #
    # walk list of raids and look for ones of specified type
    # if one is found, add it to a result array
    #
    $raidIDsIndex = 0;
    for ( $i = 0; $i < $numRaids; $i++ )
    {
        if ( $info{RAIDS}[$i]{TYPE} ==  $raidType )
        {
            $raidIDs[$raidIDsIndex] =  $info{RAIDS}[$i]{RID};
            $raidIDsIndex++;
        }
    }
    
    #
    # If we found at least one raid, point to new array and return GOOD.
    # If we didn't find any, return INVALID
    #
    if ($raidIDsIndex > 0)
    {
        @$resultsPtr = @raidIDs;
        return GOOD;
    }
    else 
    {
        return INVALID;
    }
    
}
##############################################################################
#
#          Name: GetRaidsWithRetry
#
#        Inputs: controller object, pointer to RAIDS hash
#
#       Outputs: GOOD    - We evetually got the RAIDS data 
#                ERROR   - Eventually timed out.
#
#  Globals Used: none
#
#   Description: Attempts raids command until it works or  we've done it 
#                enough so that we time it out. 
#
#
##############################################################################
sub GetRaidsWithRetry
{
    my ($ctlr, $rPtr) = @_;
    
    my $again = 1;     
    my $loop = 1; 
    my %info; 
     

    while ( $again != 0 )
    {
        $again = 0;

        sleep(1);
        $loop++;

        # get raids data
        
        %info = $ctlr->raids();

        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from raids command (attempt $loop) <<<<<<<<");
            $again = 1;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from raids command, (attempt $loop)  <<<<<<<<");
            PrintError(%info);
            $again = 1;
        }

        # delay if we have to go again
        if ($again != 0 ) { sleep 2; }
        
        
    }
     
     
    %$rPtr = %info;
     
    return GOOD; 
}     
     
     
     


##############################################################################


##############################################################################
#
#          Name: PdiskGotRaid
#
#        Inputs: controller object, pdisk PID, raid type
#                where:  raid type = RAID_0, RAID_1, RAID_5, or RAID_10
#
#       Outputs: TRUE    - The specified pdisk has at least one segment of the 
#                          specified raid type on it.
#                FALSE   - The specified pdisk does not have any segments 
#                          of the specified raid type on it.
#                INVALID - The function had an error.  
#
#  Globals Used: none
#
#   Description: Determines if there are any segments of the specified raid 
#                type on the specified pdisk.
#                - If there is at least one segment of the specified raid 
#                  type on the pdisk, function returns TRUE
#                - If there are no segments of the specified raid found, 
#                  function returns FALSE
#                - If the function fails for some reason, it returns INVALID 
#
#
##############################################################################
sub PdiskGotRaid
{
    trace();
    my ($ctlr, $pid, $raidType) = @_;
    my $ret;
    my @raidIDs;
    my $raidIDsPtr = \@raidIDs;
    my %info;
    my $numSOSEntries;
    my $i;
    
    # 
    # get all the ids of the raids of the specified type
    #
    $ret = GetRaidIDs($ctlr, $raidType, $raidIDsPtr);
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> GetRaidIDs Failed <<<<<<<<");
        return INVALID;
    }
    
    #
    # If GetRaidIDs returns INVALID, then no raids of the specified type
    # exist on the system.  Therefore, the pdisk wouldn't have any segments
    # of that raid type.  We are done.  Return FALSE.
    #
    if ( $ret == INVALID )
    {
        return FALSE;
    }
    
    #
    # Raids of the specified type exist.  Go thru the SOS table for the 
    # pdisk and see if there are any segments belonging to any of the 
    # raids
    #
    
    #
    # get the SOS table
    #
    %info = $ctlr->getSos($pid);
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from getSos <<<<<<<<");
        return INVALID;
    }
    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Could not retrieve SOS table ($pid) <<<<<<<<");
        PrintError(%info);
        return INVALID;
    }

    $numSOSEntries = $info{COUNT};
    
    #
    # loop thru each segment checking to see if the RID of that segment
    # is in the list of raid ids that we are looking for.
    # If at least one segment has a RID that is in the RaidIDs list, 
    # then return TRUE
    #  
    for ( $i = 0; $i < $numSOSEntries; $i++ )
    {
        if ( IsInList( $info{LIST}[$i]{RID}, $raidIDsPtr ) )
        {
            # found one, we're done, return with TRUE
            return TRUE;
        }
    }
   
    #
    # none of the segment RIDs was in the list of Raid IDs we were checking
    # for.  Return FALSE.
    #
    return FALSE;

}



##############################################################################
#
#          Name: BasicConfig
#
#        Inputs: controller, strategy, ip addr, server wwn list, numVdisks (optional) 
#                mirrortype (optional), destgeoid (optional)
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: One stop shopping for a configuration. Will do the basic
#                configurations that we normally do with one call.
#
#
##############################################################################
sub BasicConfig
{
    trace();

    my ( $objPtr,  $strategy, $ipPtr, $wwn, $numVdisks , $mirrortype, $destgeoid) = @_;

    my $grpID;                                 # ID of VCG group
    my $server1;
    my $server2;
    my $option;
    my $ret;

    # these lines help manage the transition from passing 2 controllers
    # to passing an array of controllers for n-way setup

    my @ipList;
    my @objList;

    my $master;
    my $slave;
    my $masterIP;
    my $slaveIP;
    my $masterIndex;


    @objList = @$objPtr;
    @ipList = @$ipPtr;

    $master = $objList[0];     # controller objects
    $masterIP = $ipList[0];    # controller ip addresses

    if ( scalar(@objList) > 1 )   # if there is a slave...
    {
        $slave  = $objList[1];
        $slaveIP  = $ipList[1];
    }
    else
    {
        $slave = 0;
        $slaveIP = " ";
    }

    # NEED to address the million hardcoded numbers here
    # Some strategies are incomplete.

#    # These vars are not currently needed. leftover from debug
#    $server1 = 5;
#    $server2 = 8;

    logInfo("BasicConfig: configuration option $strategy selected");

    debug("master = $master slave = $slave strategy = $strategy masterIP = $masterIP slaveIP = $slaveIP");


    if ( $strategy == 0 )
    {

        logError(">>>>>>>> You shouldn't be using this one <<<<<<<<");
        # this case handles non-numeric input for the strategy
        return (ERROR);

    }
    elsif ( $strategy == 1 )
    {

        #########################################
        # Strategy 1 is equivalent to
        #            Label_14
        #            VCG_part_2
        #            System_A
        #            Server_Map
        #########################################


        $ret = LabelAllDrives($master, 11, 2, 1, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        #$ret = DeleteAllVdisks($master);
        #if ( $ret == ERROR )
        #{
        #    print ">>>>>>>> Failed to delete the existing vdisks <<<<<<<<\n";
        #    return (ERROR);
        #}

        $ret = MakeVdisks($master, 2, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, $strategy, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 2 )
    {


        #########################################
        # Strategy 2 is equivalent to
        #            Label_22
        #            VCG_part_2
        #            System_b
        #            Server_Map
        #########################################

        $ret = LabelAllDrives($master, 11, 2, 0, 0, 0 );     # for 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 2, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 1, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 3 )
    {

        #########################################
        # Strategy 3 is equivalent to
        #            Mike's san lnks stuff
        #
        #########################################

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 1 );     # assume 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }


        $ret = MakeVdisks($master, 8, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks for master <<<<<");
            return (ERROR);
        }

        $ret = LabelAllDrives($slave, 11, 2, 1, 0, 2 );     # assume 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeVdisks($slave, 9, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks slave <<<<<");
            return (ERROR);
        }

        $ret = PromptUser( 3 );

        $ret = SanLinksAssoc( $master, $slave, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to set up san links associations <<<<<");
            return (ERROR);
        }



    }
    elsif ( $strategy == 4 )
    {

        #########################################
        # Strategy 4 is equivalent to
        #            Mike's vlinks stuff
        #########################################

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 0 );     # assume 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeVdisks($master, $strategy, $option );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 5 )
    {

        #########################################
        # Strategy 5 is equivalent to
        #            Label_xx
        #            VCG_part_2
        #            System_c
        #            Server_map
        #########################################

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 0 );     # assume 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 2, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
    }
    elsif ( $strategy == 6 )
    {

        #########################################
        # Strategy 6 is equivalent to
        #            Label and create a bunch
        #            of vdisks
        #########################################

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 0 );     # assume 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeVdisks($master, 3, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }
    }
    elsif ( $strategy == 7 )
    {

        #########################################
        # Strategy 7 is equivalent to
        #            Label and create a handful
        #            of vdisks
        #########################################

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 0 );     # assume 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeVdisks($master, 7, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 8 )
    {

        ###########################################
        # Strategy 8 is equivalent to
        #            Wipe_clean on 2 controllers
        #
        # Note: after the power is cycled, You
        # need to re-login to the two controllers.
        ###########################################

    #    $ret = Wipe2Clean($master, $slave, 0);
    #    if ( GOOD != $ret )
    #    {
    #        logError(">>>>> Unable to unconfigure the system <<<<<");
    #        return (ERROR);
    #    }
    #
    #    PromptUser( 4 );        # have user power cycle, wait for boot

    }
    elsif ( $strategy == 9 )
    {

        ###########################################
        # Strategy 9 is equivalent to
        #            Wipe_clean on 1 controllers
        #
        # Note: after the power is cycled, You
        # need to re-login to the two controllers.
        ###########################################

      #  $ret = Wipe2Clean($master, 0, 0);
      #  if ( GOOD != $ret )
      #  {
      #      logError(">>>>> Unable to unconfigure the system <<<<<");
      #      return (ERROR);
      #  }
      #
      #  PromptUser( 4 );        # have user power cycle, wait for boot


    }
    elsif ( $strategy == 10 )
    {


        #########################################
        # Strategy 10 is equivalent to
        #            Label_22
        #            VCG_part_2
        #            System_b
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 0 );     # for 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 2, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 11 )
    {

        #########################################
        # Strategy 11 is equivalent to
        #            Mike's san lnks stuff
        #            Uses RAID 5 disks
        #########################################

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 1 );     # assume 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }


        $ret = MakeVdisks($master, 18, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks for master <<<<<");
            return (ERROR);
        }

        $ret = LabelAllDrives($slave, 11, 2, 1, 0, 2 );     # assume 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeVdisks($slave, 19, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks slave <<<<<");
            return (ERROR);
        }

        $ret = PromptUser( 3 );

        $ret = SanLinksAssoc( $master, $slave, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to set up san links associations <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 12 )
    {


        #########################################
        # Strategy 12 is equivalent to
        #            Label_14
        #            System_A
        #            Server_Map
        #########################################

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = LabelAllDrives($master, 100, 2, 1, 0, 0 );    # for one drive bay
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeVdisks($master, 2, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        PromptUser( 3 );        # have user rescan servers, wait for inits

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 13 )
    {


        #########################################
        # Strategy 13 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 0 );     # for 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 1, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 14 )
    {


        #########################################
        # Strategy 14 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 0 );     # for 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 4, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }

    elsif ( $strategy == 15 )
    {


        #########################################
        # Strategy 15 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 11, 0, 3, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 20, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        $ret = MakeVdisks($master, 20, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 16 )
    {


        #########################################
        # Strategy 16 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 0
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 3, 9, 3, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 21, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        $ret = MakeVdisks($master, 21, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 17 )
    {


        #########################################
        # Strategy 17 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 0
        #            Server_Map   BUT selects servers using WWN
        #########################################



        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 22, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

        #
        # figure out the vdisk numbers for what is there (probably starts with
        # 64, but get the list anyway and then pick the ones to delete)
        #

my @vdisks;
my $numVDDs;
my $i;
my %rsp;
my $lun;
my $sid;


        # find the first vdisk (vdisklist)
        @vdisks = GetVdiskList( $master );
        if ( $vdisks[0] == INVALID )
        {
            logError(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
            return ERROR;
        }
        $numVDDs = scalar (@vdisks);  # of drives available


        # we just made 16 vdisks, let's disassoc every 4th one

        for ($i = 2; $i < $numVDDs; $i += 4 )
        {


            # get the owner
            %rsp = $master->virtualDiskOwner($vdisks[$i]);
            if ( ! %rsp  )
            {
                logInfo(">>>>>>>> Failed to get response from virtualDiskOwner <<<<<<<<");
                return ERROR;
            }
            if ($rsp{STATUS} != PI_GOOD)
            {
                logInfo(">>>>>>>> Unable to retrieve virtualDiskOwner. <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }

            # if there is an owner, disassoc it.
            if ( $rsp{NDEVS} > 0 )
            {
                $lun = $rsp{OWNERS}[0]{LUN};
                $sid = $rsp{OWNERS}[0]{SID};

                #
                # got the info, now disassoc it
                #
                $ret = DisassocOne( $master, $sid, $lun, $vdisks[$i]);
                if ( $ret == ERROR )
                {
                    return ERROR;
                }
            }

        }
        # now we have 16 vdisks, most have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 18 )
    {


        #########################################
        # Strategy 18 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 23, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 19 )
    {

        print ("BasicConfig strategy 19: no raid 1\n");

        #########################################
        # Strategy 18 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 24, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 20 )
    {

        print ("BasicConfig strategy 20: raid 1 on exactly 2 pdisks \n");

        #########################################
        # Strategy 18 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 25, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 21 )
    {

        ###########################################
        # Strategy 21 enables caching for vdisks and the controller
        #
        ###########################################

        $ret = EnableCache($master,  0);
        if ( GOOD != $ret )
        {
            logError(">>>>> Failed while enabling write cache <<<<<");
            return (ERROR);
        }



    }
    elsif ( $strategy == 22 )
    {

        ###########################################
        # Strategy 22 disables global caching
        #
        ###########################################

        $ret = DisableCache($master,  0);
        if ( GOOD != $ret )
        {
            logError(">>>>> Failed while disabling global write cache <<<<<");
            return (ERROR);
        }



    }
    elsif ( $strategy == 23 )
    {

        print ("BasicConfig strategy 23: no raid 1\n");

        #########################################
        # Strategy 23 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 26, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 24 )
    {

        print ("BasicConfig strategy 24: no raid 1\n");

        #########################################
        # Strategy 24 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 28, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 25 )
    {

        print ("BasicConfig strategy 25: no raid 1\n");

        #########################################
        # Strategy 25 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 27, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 26 )
    {

        print ("BasicConfig strategy 26: all raid 1\n");

        #########################################
        # Strategy 26 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 29, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 27 )
    {

        print ("BasicConfig strategy 26: all raid 1\n");

        #########################################
        # Strategy 26 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But has raid 10,5
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 30, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }

    elsif ( $strategy == 28 )
    {

        ###########################################
        # Strategy 28 is equivalent to
        #            Wipe_clean on ALL controllers
        #
        # Note: after the power is cycled, You
        # need to re-login to the  controllers.
        ###########################################

      #  $ret = WipeControllersClean($objPtr, 0);
      #  if ( GOOD != $ret )
      #  {
      #      logError(">>>>> Unable to unconfigure the system <<<<<");
      #      return (ERROR);
      #  }
      #
      #  PromptUser( 4 );        # have user power cycle, wait for boot

    }
    elsif ( $strategy == 29 )
    {

        print ("BasicConfig strategy 29: no raid 1\n");

        #########################################
        # Strategy 29 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 26, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        ExpandVdisks( $master, 200);   # add 200 mb to each vdisk



        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }

    elsif ( $strategy == 30 )
    {

        ###########################################
        # Strategy 30 view configuration stuff
        #
        ###########################################

        $ret = ConfigView($master, $slave, 0);
        if ( GOOD != $ret )
        {
            logError(">>>>> Failed while displaying controller config <<<<<");
            return (ERROR);
        }



    }
    elsif ( $strategy == 31 )
    {

        print ("BasicConfig strategy 31: all raid 5\n");

        #########################################
        # Strategy 23 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 31, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 32 )
    {

        print ("BasicConfig strategy 31: all raid 5\n");

        #########################################
        # Strategy 23 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 32, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 40 )
    {

        print ("BasicConfig strategy 40: \n");

        #########################################
        # Strategy 40 
        #            Label_14
        #            26 small raids 0, 1, 10, multiple groups
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 40, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 41 )
    {

        print ("BasicConfig strategy 41: \n");

        #########################################
        # Strategy 41 
        #            Label_14
        #            26 small raids 0, 1, 5, 10, multiple groups
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 41, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }
    elsif ( $strategy == 50 )
    {

        ###########################################
        # Strategy 50 Another menu
        #
        ###########################################

        $ret = NoSuicide($objPtr);

        $ret = TestMenu($master, $slave, 0, $wwn);
        if ( GOOD != $ret )
        {
            logError(">>>>> Failure from the test menu <<<<<");
            return (ERROR);
        }



    }
    elsif ( $strategy == 51 )
    {

        ###########################################
        # Strategy 51 Single command menu
        #
        ###########################################

        $ret = SingleItemMenu($objPtr, $ipPtr, $wwn, 0);
        if ( GOOD != $ret )
        {
            logError(">>>>> Failure from the single command menu <<<<<");
            return (ERROR);
        }



    }
    elsif ( $strategy == 52 )
    {

        ###########################################
        # Strategy 52 is for custom configuration
        #
        # Note: after the power is cycled, You
        # need to re-login to the two controllers.
        ###########################################

        $ret = ConfigSelect($objPtr, $ipPtr, $wwn);
        if ( GOOD != $ret )
        {
            logError(">>>>> Unable to unconfigure the system <<<<<");
            return (ERROR);
        }
    }
    elsif ( $strategy == 55 )
    {
        my $i;
        my $j;
        my %rsp;
        my @originalVdisks;
        my @baseVdisks;
        my @newVdisks;
        my @newMirrorVdisks;
        my $numBaseVdisksUsed;
        my $baseVdisk;
        my $srcVdisk;
        my $baseVdiskIndex;
        my @baseVdisksUsed;
        my @tempVdisks;
       

        print ("Option 55 - Adding Mirrors: \n");

        #########################################
        # Strategy 55 
        #            Add up to 30 mirrors to existing configuration. 
        #            All RAID_5 & RAID_10, multiple groups
        #            If no RAID_5 vdisks detected, will make all mirrors
        #            RAID_10 only.
        #########################################

        #
        # Find the master 
        #
        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        #
        # Get the VIDs of all the current vdisks
        #
        %rsp = $master->virtualDisks();
        if ( ! %rsp  )              
        {
            logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      
        {
            logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
        
        for ($i = 0; $i < $rsp{COUNT}; $i++)
        {
            $originalVdisks[$i] = $rsp{VDISKS}[$i]{VID};
        }

        logInfo("Current vdisks: \n@originalVdisks");
        
        #
        # Remove any vlinks that may exist
        #
        $ret = TestLibs::BEUtils::RemoveVlinks($master, \@originalVdisks, \@tempVdisks);  
        if ( $ret  != GOOD )      
        {
            logInfo(">>>>>>>> Error from RemoveVlinks <<<<<<<<");
            return ERROR;
        }
        
        #
        # Remove any currently existing mirrors
        #
        $ret = TestLibs::BEUtils::RemoveMirrors($master, \@tempVdisks, \@baseVdisks);  
        if ( $ret  != GOOD )      
        {
            logInfo(">>>>>>>> Error from RemoveMirrors <<<<<<<<");
            return ERROR;
        }

        logInfo("Base vdisks (not vlinks or mirrors): \n@baseVdisks");

        #
        # Create new vdisks for new mirrors
        #
        
        if ($mirrortype == 1)
        {
        
            $ret = MakeVdisks($master, 55, 0, $numVdisks );
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to create new vdisks <<<<<");
                return (ERROR);
            }
        }
        elsif ($mirrortype == 2)
        {
            $ret = TestLibs::GeoRaid::MakeGeoVdisks($objPtr, 3, 0, $numVdisks, 0, 0);
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to create new vdisks <<<<<");
                return (ERROR);
            }
        }
        elsif ($mirrortype == 3)
        {
            $ret = TestLibs::GeoRaid::MakeGeoVdisks($objPtr, 3, 0, $numVdisks, 0, $destgeoid);
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to create new vdisks <<<<<");
                return (ERROR);
            }
        }

        #
        # Get the VIDs of all the current vdisks again
        #
        %rsp = $master->virtualDisks();
        if ( ! %rsp  )              
        {
            logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      
        {
            logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
        
        for ($i = 0; $i < $rsp{COUNT}; $i++)
        {
            $newVdisks[$i] = $rsp{VDISKS}[$i]{VID};
        }

        #
        # Get VIDs of the new mirror vdisks that were created
        #
        for ( $i = 0; $i < scalar(@newVdisks); $i++ )
        {
            if ( 0 == IsInList( $newVdisks[$i], \@originalVdisks ) )
            {
                push (@newMirrorVdisks, $newVdisks[$i]);
            }
        }

        logInfo("New vdisks created to be mirrors: \n@newMirrorVdisks");

        #
        # Wait until all raids have completed initialization.
        #
        $ret = TestLibs::BEUtils::WaitOnNewerInits( $master, \@originalVdisks );
        if ( $ret != GOOD ) 
        {
            logInfo(">>>>>>>> Error from WaitOnNewerInits command <<<<<<<<");
            return ERROR;
        }

        #
        # Assign the new vdisks as mirrors to random baseVdisks
        #
        logInfo("Setting up mirrors....");  
        $numBaseVdisksUsed = scalar(@baseVdisks);
        for ( $i = 0; $i < scalar(@newMirrorVdisks); $i++ )
        {
            if ( ($i % 12) == 7 )
            {
                #
                # Special case:
                # On the 7th & 17th base vdisk, set up 2 mirrors to the same 
                # base vdisk.
                #
                
                # don't need to do anything
            
            }
            elsif ( ($i % 12) == 9 ) 
            {
                #
                # Special case:
                # On the 9th & 19th base vdisk, set up a mirror of the mirror 
                # of the base vdisk 
                #
                $srcVdisk = $newMirrorVdisks[$i-1];                 
            }
            else 
            {
            
                #
                # If all the base vdisks have been used, start over
                #
                if ( $numBaseVdisksUsed >= scalar(@baseVdisks) )
                {
                    for ( $j = 0; $j < scalar(@baseVdisks); $j++ )
                    {
                        $baseVdisksUsed[$j] = 0;
                    }    
                    $numBaseVdisksUsed = 0;
                    $baseVdiskIndex = -1;
                } 
            
                #
                # Choose the base vdisk to add a mirror to. 
                # If the number of mirrors we are creating is more than 
                # 90% of the number of base vdisks, just increment thru the 
                # base vdisks
                # Otherwise, choose random base vdisks
                #
                if ( scalar(@newMirrorVdisks) > ( 9 * scalar(@baseVdisks) / 10 ) ) 
                {
                    $baseVdiskIndex++;
                }
                else
                {
                  
                    do 
                    {
                        $baseVdiskIndex = int( rand( scalar(@baseVdisks) ) );
                    }
                    while ($baseVdisksUsed[$baseVdiskIndex] == 1);       
                }
                  
                $baseVdisksUsed[$baseVdiskIndex] = 1;
                $numBaseVdisksUsed++;
                $srcVdisk = $baseVdisks[$baseVdiskIndex]; 
            }

            #
            # Now actually set up the mirror
            #
                                                     # src             dest
            %rsp = $master->virtualDiskControl(0x03, $srcVdisk, $newMirrorVdisks[$i]);
            if (!%rsp)                        # no response
            {
                logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
                return ERROR;
            }

            if ($rsp{STATUS} != PI_GOOD)            # 1 is bad
            {
                logInfo(">>>>> Failed: virtualDiskControl returned an error <<<<<");
                PrintError(%rsp);
                return ERROR;
            }
            else
            {
                logInfo("Vdisk $newMirrorVdisks[$i] is now a mirror of vdisk $srcVdisk");  
            }
        }
    }
    elsif ( $strategy == 61 )
    {

        print ("BasicConfig strategy 61: raid 5/10\n");

        #########################################
        # Strategy 61 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 30, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }

    elsif ( $strategy == 62 )
    {

        print ("BasicConfig strategy 62: raid 10\n");

        #########################################
        # Strategy 61 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 33, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }


    elsif ( $strategy == 70 )
    {


        #########################################
        # Strategy 70 is equivalent to
        #            Label_22
        #            VCG_part_2
        #            System_b     with more vdisks
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 0 );     # for 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 10, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }
        elsif ( $strategy == 71 )
    {


        #########################################
        # Strategy 70 is equivalent to
        #            Label_22
        #            VCG_part_2
        #            System_b     with a few small
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 11, 2, 1, 0, 0 );     # for 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 11, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }

        elsif ( $strategy == 72 )
    {


        #########################################
        # Strategy 72 is equivalent to
        #            Label_22
        #            System_b     with a few small drives
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = LabelAllDrives($master, 11, 2, 2, 0, 1 );     # for 22 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeVdisks($master, 11, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }

    }
    elsif ( $strategy == 73 )
    {


        print ("BasicConfig strategy 73: no raid 1\n");

        #########################################
        # Strategy 23 is similar to
        #            Label_14
        #            VCG_part_2
        #            System_b     But all raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 10, 2, 2, 0, 0 );     # for 14 drive bays
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 26, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have 16 vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );


    }

    elsif ( $strategy == 81 )
    {
      #########################################
      # Strategy 81
      # Georaid configuration with source vdisks 
      # and mirror vdisks on different geolocations
      #########################################
      
      $ret = TestLibs::GeoRaid::GeoConfig( $objPtr, 1, $wwn );
       
      if ( $ret == ERROR )
       {
           logError(">>>>> Failed to configure georaid configuration 1 <<<<<");
           return (ERROR);
       }
    
    }
    elsif ( $strategy == 82 )
    {
        #########################################
        # Strategy 82
        # Georaid configuration with source vdisks 
        # and mirror vdisks on multiple geolocations
        #########################################
        
        $ret = TestLibs::GeoRaid::GeoConfig( $objPtr, 2, $wwn );
        
        if ( $ret == ERROR )
         {
            logError(">>>>> Failed to configure georaid configuration 2 <<<<<");
            return (ERROR);
         }
    }
    elsif ( $strategy == 85 )
    {
        #########################################
        # Strategy 85
        # FESimulator configuration 
        #########################################
        
        $ret = TestLibs::FeSimConfig::FeSimulatorConfig( $objPtr );

        if ( $ret == ERROR )
         {
            logError(">>>>> Failed to create FE Simulator Configuration <<<<<");
            return (ERROR);
         }
    }
    elsif ( $strategy == 86 )
    {

        print ("BasicConfig strategy 86: \n");

        #########################################
        # Strategy 86
        #            Used for 750 with only 5 pdisks
        #            Label_5
        #            15 vdisks of raid 10
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 4, 0, 1, 0, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 43, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );
    }
    elsif ( $strategy == 87 )
    {

        print ("BasicConfig strategy 87: \n");

        #########################################
        # Strategy 87
        #            Used for 750 with only 8 pdisks
        #            Label_5
        #            26 small raids 0, 1, 5, 10, multiple groups
        #            Server_Map   BUT selects servers using WWN
        #########################################

        $ret = LabelAllDrives($master, 100, 2, 1, 0, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label the drives <<<<<");
            return (ERROR);
        }

        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create the VCG <<<<<");
            return (ERROR);
        }

        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex];  

        $ret = MakeVdisks($master, 44, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to create new vdisks <<<<<");
            return (ERROR);
        }


        GetSIDs( $master, 0 );   # show sids to user

        $ret = PromptUser( 3 );

        $ret = AssociateServers($master, 2, $wwn );
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to associate drives to servers <<<<<");
            return (ERROR);
        }
        # now we have vdisks, all have owners, all are initialized. Tell
        # user thay can start IO.

        $ret = PromptUser( 7 );
    }
    elsif ( $strategy == 90 )
    {

        ###########################################
        # Strategy 90 is no suicide on error trap
        ###########################################

        $ret = NoSuicide($objPtr);

        if ( GOOD != $ret )
        {
            logError(">>>>> Unable to set no suicide bit(s) <<<<<");
            return (ERROR);
        }



    }



    elsif ( $strategy == 98 )
    {

        ###########################################
        # Strategy 98 is equivalent to
        #            debug
        #
        # Note: after the power is cycled, You
        # need to re-login to the two controllers.
        ###########################################
        #$ret = CreateExpandInitDelete($master,  3, 3, 0 );
        #$ret = CreateExpandInitDelete($master,  3, 3, 1 );
        #$ret = CreateExpandInitDelete($master,  3, 3, 2 );
        #$ret = CreateExpandInitDelete($master,  3, 3, 3 );

        my $rc;
        my @PDDs;
        my $j;
        my $pdd;
        my %rsp;
        my $msg;
        my %info;
        my $dummy; 
        my @drives;


#        $rc = TestLibs::UETestSupport::OrphanedRaidCheck2( $master );

        $rc = AssociateServers($master, 4, $wwn );
       
#        $rc = TestLibs::UETestSupport::OrphanedRaidCheck2($master); 
 
#        $rc = TestLibs::UETestSupport::OrphanedRaidCheck2($slave); 
       
       
#        $rc = TestLibs::BEUtils::DefragWait( $master, );
        
        logInfo("rc = $rc");       
        
        
        
    }

    elsif ( $strategy == 99 )
    {
        #########################################
        # Strategy 99 is for my debugging
        #            don't expect consistency
        #            of action
        #########################################

        #QLTest1($master, $loops, $proc, $option, $delay1, $delay2) ;
        # option not used

        for ( my $mOption = 1; $mOption < 35 ; $mOption++)
        {
            MakeVdisks($master, $mOption, 0);
            DelaySecs(20);
            DeleteAllVdisks($master, 0);
        }


#        $ret = DeleteAllVdisks2($master, 1 );
#        $ret = DeleteAllVdisks2($master, 2 );
#        $ret = DeleteAllVdisks2($master, 0 );
#        if ( $ret == ERROR )
#        {
#            print ">>>>>>>> Failed to create new vdisks <<<<<<<<\n";
#            return (ERROR);
#        }
#
#        # FindSIDs( $master, 0, $wwn );
#        print "Debugging successful! \n";
#
    }
    else
    {
        logError(">>>>> Improper configuration strategy specified. <<<<<" .
         "You tried strategy $strategy but I do not know what that is.");
        return (ERROR);
    }


    return GOOD;
}



##############################################################################
#
#          Name: UpdateDriveCode
#
#        Inputs: controller object, code index
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: update code on all pdds
#
#
##############################################################################
sub UpdateDriveCode
{
    trace();
    my ( $ctlr, $index ,$drivePtr, $FWptr) = @_;

    my %info;
    my $ret;
    my %rtn;
    my %rsp;
    my $i;
    my $id;
    my $j;
    my $drv;
    my $rev;
    my @driveList;
    my @FWList;
    my $wwnLo;
    my $wwnHi;
    my $lun;

    @driveList = @$drivePtr;
    @FWList = @$FWptr;


    #############
    #  PDISKLIST
    #############


    %rsp = $ctlr->physicalDiskList();
    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from physicalDiskList <<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Unable to physicalDiskList <<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    my $str = "\nPhysical Disk List:\n";

#    for $i (0..$#{$rsp{LIST}})
    for $i (0..1)
    {
        $str.= "Examining drive  " . $rsp{LIST}[$i] . "\n";
        $id =  $rsp{LIST}[$i];

        ##############
        #  PDISKINFO
        ##############
        $str .= "Retrieving physical disk information for each disk.\n";
        %info = $ctlr->physicalDiskInfo($id);
        if ( ! %info  )
        {
            logInfo(">>>>> Failed to get response from physicalDiskInfo <<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>> Unable to physicalDiskInfo <<<<<");
            PrintError(%info);
            return ERROR;
        }

        $drv = $info{PS_PRODID};
        $rev = $info{PD_REV};
        #logPhysicalDiskInfo(%info);
        $wwnLo = $info{WWN_LO};
        $wwnHi = $info{WWN_HI};
        $lun = $info{PD_LUN};

        #if ( $info{PS_PRODID} ==

        $str .= "PD_PRODID:             $info{PS_PRODID}\n";
        $str .= sprintf("WWN:                   %8.8x%8.8x\n", $info{WWN_LO}, $info{WWN_HI});
        $str .= sprintf("PD_LUN:                %hu\n", $info{PD_LUN});
        logInfo($str);

        for ( $j = 0; $j < scalar(@FWList); $j++ )
        {
            debug("testing <$drv> against <$driveList[$j]> \n");
            my $drvmatch = ($drv =~ /$driveList[$j]/i);
            debug("drv match: $drvmatch\n");
            if ( $drvmatch == 1 )
            {
                logInfo("Drive ID matched, index = $j, old rev is $rev, needs to be $FWList[$j]");;

                #
                # now we need to update the code
                #

                my $codeMatch = ( $rev =~ /$FWList[$j]/i );

                if ( $codeMatch != 1 )
                {
                    $ret = SendCode2Drive( $ctlr, $id, $FWList[$j],
                                $wwnLo, $wwnHi, $lun) ;
                    if ( $ret != GOOD )
                    {
                        logError(">>>>> Failure updating code on drive $j <<<<<");
                        return ERROR;
                    }
                }
            }
        }

    }
    return GOOD;
}

##############################################################################
#
#          Name: SendCode2Drive
#
#        Inputs: controller object, PDD number, partial file name
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: sends code file to disk drive
#
#
##############################################################################
sub SendCode2Drive
{
    trace();

    my ( $ctlr, $pdd, $file, $wwnLo, $wwnHi, $lun ) = @_;

    my @arr;
    my $filename;

    #
    # build the file name
    #

    # we are in the bigfoot\<rel>\test\ directory
    # so we need to go up 1 dir

    # want it to be  "..\$file.ima"

    $filename = "..\\" . $file . ".ima";

    #
    # verify file existence
    #
      if (! -r $filename)
    {
        logError(">>>>> Missing or unreadable file ($filename) <<<<<");
        return ERROR;
    }

    #
    # build a data array
    #

    $arr[0]{WWN_LO} = $wwnLo;
    $arr[0]{WWN_HI} = $wwnHi;
    $arr[0]{PD_LUN} = $lun;

    #
    # send the file
    #

    logInfo(sprintf("Writing %s to %8.8x%8.8x \n", $filename, $wwnLo, $wwnHi));

    my %rsp = $ctlr->writeBuffer(1, $filename, @arr);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from writeBuffer <<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Error sending code to drive <<<<<");
        PrintError(%rsp);
        return ERROR;
    }


    # insert code here

    return GOOD;
}


##############################################################################
#
#          Name: MakeMirror
#
#        Inputs: TBD
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Set up mirror partners
#
#
##############################################################################
sub MakeMirror
{
    trace();
#    setXIOdevice($controller);              # select the controller

    # insert code here

    return GOOD;
}

##############################################################################
#
#          Name: BreakAllMirrorVdisks
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Breaks all the mirror vdisks available on a VCG
#
#
##############################################################################
sub BreakAllMirrorVdisks
{
    trace();

    my ($objPtr) = @_;

    my %info;
    my %rsp2;
    my $i;
    my $master;
    my $masterCtlr;
    my @coList;

    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 
    
    @coList = @$objPtr;

    $masterCtlr = $coList[$master];

    %info = $masterCtlr->resyncData(1);
    
    if (%info)
    {
        if ($info{STATUS} == PI_GOOD)
        { 
            for ($i = 0; $i < $info{COUNT}; $i++)
            {
                    %rsp2 = $masterCtlr->virtualDiskControl(0x05, $info{DTLCPY}[$i]{RCSDV}, $info{DTLCPY}[$i]{RCDDV});

                    if (!%rsp2)                        # no response
                    {
                        logInfo(">>>>> Failed to receive a response from Break Mirror <<<<<");
                        return ERROR;
                    }
                    elsif ($rsp2{STATUS}  != PI_GOOD)            # 1 is bad
                    {
                        logInfo("Failed to Break Mirror Vdisk $info{DTLCPY}[$i]{RCDDV}.");
                        PrintError(%rsp2);
                        return ERROR;
                    }
                    else
                    {
                        logInfo(" Vdisk Mirror $info{DTLCPY}[$i]{RCDDV} broken.");
                    }
            }   
        } 
        else
        {
            logInfo("Unable to retrieve the resync data.");
            PrintError(%info);
        }
    }  
    else
    {
        logInfo( "ERROR: Did not receive a response packet from function resyncData.\n" );
        return ERROR;
    } 

    return GOOD;
}

##############################################################################
#
#          Name: SanLinksConfig
#
#        Inputs: controllerID1, controllerID2, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Prepare for San links, make controllers single, label
#                half the drives for one controller, half for the other.
#
#
##############################################################################
sub SanLinksConfig
{
    trace();

    # cannot use the label 0xffff option.

    # vcgmakesingle
    # initprocnvram
    # repeat for other controller
    # unlabel all drives
    # count the drives,
    # label half for one controller
    # lable rest for other controller
    return GOOD;

}





##############################################################################
#
#          Name:  LabelAllDrives
#
#        Inputs: controllerID, numData, numUnsafe, numSpare, numUnlabelled
#
#       Returns: GOOD, if successful, otherwise ERROR
#
#  Globals Used: none
#
#   Description: Labels drives attached to the controller. Inputs are
#                the number of drives of each type to label. Drives will
#                labelled in the following manner: First label numUnsafe as
#                UNSAFE, then label numSpare as HOTSPARE, then label
#                numUnlabeled as unlabeled, then label
#                numData as DATA. Repeat this until all drives are used
#                up.
#
#                The controller is specified by controllerID.
#
#                Internally, an array will be built to set up the above
#                mapping, then ALL drives will be marked as data and then
#                the non-DATA ones will be labelled one at a time.
#
#                This means the label on EVERY drive is written by this
#                function. If you do not want every drive touched, then
#                make several calls to LabelSingleDrive as needed.
#
#                No error will be generated if there are not enough drives
#                complete one  set of the requested labels. Only the failure
#                to label any drive will return error. The failure to execute
#                a related command could also generate an error.
#
#                By calling with an extremely large number of data drives,
#                the user will get the specified number of the 'other'
#                drive types and all the rest will be data. By using a
#                reasonable number of data drives, the user gets drives
#                that reasonable match the desired 'mix'.
#
#                option = 0 : use all drives
#                option = 1 : use half the drives found
#                option = 2 : use only drives with serial# == 0 (the other half)
#                option = 3 : Skip Unlabel ALL Drives step
#
##############################################################################
sub LabelAllDrives
{
    trace();
    my ( $contID, $data, $unsafe, $numspare, $unlabel, $option ) = @_;

    my $driveCount;      # number of physical drives
    my @driveList;       # array of valid drive numbers
    my $drivesToDo;      # counter
    my $ret;
    my %info;
    my %drives;
    my $drive;
    my $dsn;
    my $numData;
    my $numUnsafe;
    my $numHotSpare;
    my $numUnlabel;

    my @dataList;
    my @unsafeList;
    my @hotspareList;
    my @unlabelList;

    # bail out with error if any problems arise, or there are NO drives

    if( ! $option )
    {
        # default to all drives if no option
        $option = 0;
    }

    if ( $contID == 0 )
    {
        logInfo(">>>>> Failed, need a valid controller object. <<<<<");
        return (ERROR);
    }


    # gotta force a rescan here since the labels may have changed since
    # the last scan...

#    $ret = RescanBE( $contID );
#    if( $ret == ERROR )
#    {
#        logInfo(">>>>> Failed to rescan drives. <<<<<");
#        return (ERROR);
#    }


    debug("label all");

    # do a devstat to get the list of drives and status of each
    #   have to do this with pdisklist and pdiskinfo as devstat seems to
    #   be missing

    %drives = $contID->physicalDisks();  # get list of drives present

    if( ! %drives )
    {
        logInfo(">>>>> Failed to get physical disk list. <<<<<");
        return (ERROR);
    }

    # check each drive in the list

    $driveCount = 0;

    # build an array of all the good ones. To be good a drive must have
    # 'operational' status and not have a serial number, meaning it isn't
    # already owned by somebody

    for (my $i = 0; $i < $drives{COUNT}; $i++)     # for each drive
    {
        if (
            ($drives{PDISKS}[$i]{PD_DEVSTAT} == 0x10) ||           # if drive is good, or
               (($drives{PDISKS}[$i]{PD_DEVSTAT} == 0x01) &&       # if drive is inop AND
                ($drives{PDISKS}[$i]{PD_POSTSTAT} == 0x27))        # no rsvd area
           )
        {


            # now check the class (looking for unlabeled)
            $dsn = $drives{PDISKS}[$i]{PD_CLASS};

            if ( $dsn == CCBEUNLABLEDTYPE )
            {
                # drive is free, I can use it
                #$driveList[$driveCount] = $i;          # add it to the list
                $driveList[$driveCount] = $drives{PDISKS}[$i]{PD_PID};          # add it to the list
                $driveCount++;                         # increase count
            }
        }

    }

    if ( $option == 1 )
    {
        # only half for option 1
        $driveCount = int( $driveCount / 2 );
    }

    if ($driveCount < 1)
    {
        logInfo(">>>>> Failed to find any good drives <<<<<");
        return (ERROR);
    }

    debug("good drives = $driveCount");
    debug("list is @driveList \n");;

    # tag the array elements with the type to label (data, unsafe, etc.)
    #     (actually deal with this in the loop below)

    # for options 0 and 1, unlabel all drives first
    if ( $option < 2 )
    {
        $ret = LabelSingleDrive( $contID, 0xffff, 0);
        if ($ret == ERROR)
        {
            logInfo(">>>>> Failed to unlabel all drives  <<<<<");
            return (ERROR);
        }
    }

#    # option 0 allows us to use all drives, therefore we can speed things
#    # up by labeling all drives as data at once, then go back and
#    # relabel the non-data ones
#    if ( $option == 0 )
#    {
#        # make all drives data
#        $ret = LabelSingleDrive( $contID, 0xffff, CCBEDATATYPE);
#
#        if ($ret == ERROR)
#        {
#            print ">>>>>>>> Failed to label all drives as DATA <<<<<<<<\n";
#            return (ERROR);
#        }
#    }

    # walk the array and build arrays of 'data' 'unsafe' and 'hotspare' drive
    # then label them in groups at the end.

    # note - data drives handled based upon the option

    $drive = 0;                # index to $driveList
    $numData = 0;
    $numUnsafe = 0;
    $numHotSpare = 0;
    $numUnlabel = 0;

    while ( $driveCount > 0)
    {
        # first some unsafes
        $drivesToDo = $unsafe;                 # number to do this pass
        while ( ( $driveCount > 0 ) &&  ( $drivesToDo > 0 ) )
        {
            push ( @unsafeList, $driveList[$drive] );
            $numUnsafe++;

            $drive++;                          # incr drive index
            $drivesToDo--;                     # decr num unsafes to do
            $driveCount--;                     # decr num drives left to do
        }

        # now the hot spares
        $drivesToDo = $numspare;
        while ( ( $driveCount > 0 ) &&  ( $drivesToDo > 0 ) )
        {
            push ( @hotspareList, $driveList[$drive] );
            $numHotSpare++;

            $drive++;                          # incr drive index
            $drivesToDo--;
            $driveCount--;
        }

        # now the unlabeled
        $drivesToDo = $unlabel;
        while ( ( $driveCount > 0 ) &&  ( $drivesToDo > 0 ) )
        {
            push ( @unlabelList, $driveList[$drive] );
            $numUnlabel++;

            $drive++;                          # incr drive index
            $drivesToDo--;
            $driveCount--;
        }

        # now the data - these may already be done - based upon option
        $drivesToDo = $data;          # number of data drives this pass
        while ( ( $driveCount > 0 ) &&  ( $drivesToDo > 0 ) )
        {
            push ( @dataList, $driveList[$drive] );
            $numData++;
            # counts updated either way
            $drive++;                          # incr drive index
            $drivesToDo--;            # but we still adjust the counts
            $driveCount--;
        }

    }  # if there are any drives left, go back and do another set.


    # Now the arrays are built, label each of the groups

    # label the data drives
    if (  $numData > 0 )
    {
        $ret = LabelSomeDrives( $contID, \@dataList, CCBEDATATYPE);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to unlabel drive(s) @dataList  <<<<<");
            return (ERROR);
        }
    }



    # Label the unsafe drives
    if (  $numUnsafe > 0 )
    {
        $ret = LabelSomeDrives( $contID, \@unsafeList, CCBEUNSAFETYPE);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label drives (@unsafeList) as unsafe <<<<<");
            return (ERROR);                # bail on an error
        }
    }

    # label the Hot spares
    if (  $numHotSpare > 0 )
    {
        $ret = LabelSomeDrives( $contID, \@hotspareList, CCBEHOTSPARETYPE);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to label drives (@hotspareList) as hot spare <<<<<");
            return (ERROR);
        }
    }

    # label the unlabeled
    if (  $numUnlabel > 0 )
    {
        $ret = LabelSomeDrives( $contID, \@unlabelList, CCBEUNLABLEDTYPE);
        if ( $ret == ERROR )
        {
            logError(">>>>> Failed to unlabel drives (@unlabelList)  <<<<<");
            return (ERROR);
        }
    }

     # if we got here, we must be
    # done
    return (GOOD);
}

##############################################################################
#
#          Name: RescanBE
#
#        Inputs: controllerID
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Rescans the back end to see if the status of the drives has
#                changed, This makes sure we are dealing with current
#                information.
#
#
##############################################################################
sub RescanBE
{
    trace();
    my ($ctlr) = @_;
    my %rsp;

    debug("Scanning the drives");

    %rsp = $ctlr->rescanDevice("LOOP");

    if ( ! %rsp  )
    {
        logInfo(">>>>> No response rescanning the BE <<<<<");
        return (ERROR);
    }

    if ( $rsp{STATUS} != PI_GOOD )
    {
        logInfo(">>>>> Failed to rescan the drives <<<<<");

        PrintError(%rsp);

        return (ERROR);
    }

    return (TestLibs::BEUtils::Wait4Ses($ctlr, 90));
}

##############################################################################
#
#          Name: LabelSomeDrives
#
#        Inputs: controllerID, driveID, type
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Labels the specified drive on the specified controller
#                Will generally succeed but will fail if the drive does
#                not exist, the type is wrong, ot the controller signals
#                an error.
#
#
##############################################################################
sub LabelSomeDrives
{
    trace();
    my ( $controller, $pddList, $type ) = @_;
    my $i;
    my %rsp;
    my @pddList2;

    my $zero = 0;

    # labels a drive, if pdd is 0xffff, than all drives at once

    logInfo("Setting MRP timeout to 400 seconds");
    %rsp = $controller->timeoutMRP("MRP", 400);

    %rsp = $controller->physicalDiskLabel($pddList, $type, $zero, $zero );

    if ( %rsp )
    {

        debug(" label status  $rsp{STATUS}");

        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo("Physical disks (@$pddList) labeled ($type)");
        }
        else
        {
            logInfo(">>>>> Failed to label pdds as $type <<<<<");

            PrintError(%rsp);

            return (ERROR);
        }
    }
    else
    {
        logInfo(">>>>> Did not receive a response packet.\n <<<<<");
        return (ERROR);
    }

    return GOOD;
}

##############################################################################
#
#          Name: LabelSingleDrive
#
#        Inputs: controllerID, driveID, type
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Labels the specified drive on the specified controller
#                Will generally succeed but will fail if the drive does
#                not exist, the type is wrong, ot the controller signals
#                an error.
#
#
##############################################################################
sub LabelSingleDrive
{
    trace();
    my ( $controller, $pdd, $type ) = @_;
    my $i;
    my %rsp;
    my @pddList;

    my $zero = 0;

    # labels a drive, if pdd is 0xffff, than all drives at once

    debug("labeling $controller, $pdd, $type");
    if ( 0xffff == $pdd )
    {
        # all drive case, build the list

        my %rsplist = $controller->physicalDiskList();

        if (%rsplist)
        {
            if ($rsplist{STATUS} == PI_GOOD)
            {
                for $i (0..$#{$rsplist{LIST}})
                {
                    $pddList[$i] = $rsplist{LIST}[$i];
                }
            }
            else
            {
                logInfo(">>>>> Error getting a pdd list <<<<<");
                PrintError(%rsplist);
                return ERROR;
            }
        }
        else
        {
            logInfo(">>>>> Failed to get a pdd list <<<<<");
            return ERROR;
        }

    }
    else
    {
        # single drive case, just populate the array
        $pddList[0] = $pdd;
    }


    %rsp = $controller->physicalDiskLabel(\@pddList, $type, $zero, $zero );

    if ( %rsp )
    {

        debug("label status  $rsp{STATUS}");

        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo("Physical disk ($pdd) labeled ($type)");
        }
        else
        {
            logInfo(">>>>> Failed to label pdd # $pdd as $type <<<<<");

            PrintError(%rsp);

            return (ERROR);
        }
    }
    else
    {
        logInfo(">>>>> Did not receive a response packet.\n <<<<<");
        return (ERROR);
    }

    return GOOD;
}




##############################################################################
#
#          Name: MakeVCG
#
#        Inputs: masterID, slaveID, masterIP, slaveIP
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: configure two controllers as a VCG
#
##############################################################################
sub MakeVCG
{
    trace();
    my ($master, $slave, $masterIP, $slaveIP ) = @_;

    my $sn1;                                     # group serial number
    my $sn2;                                     # group serial number
    my %vcginfo;
    my $k;
    my $v;
    my %rsp;
    my $response;
    my $vcg;
    my $ret;
    my @ctlrList;
    my $slaveIndex;

    if ( $slave == 0 )
    {
        logError(">>>>> Failed, need two valid controller objects. <<<<<");
        return (ERROR);
    }


    # need to get the serialnumbrs for the two controllers, get them
    # directly from the controllers

    $sn1 = GetSerial( $master );
    if ( INVALID == $sn1  )
    {
        logError(">>>>> Failed to get master's serial number <<<<<");
        return (ERROR);
    }
    logInfo("Master's serial number is $sn1");

    $sn2 = GetSerial( $slave );
    if ( INVALID == $sn2  )
    {
        logError(">>>>> Failed to get slave's serial number <<<<<");
        return (ERROR);
    }
    logInfo("Slave's serial number is $sn2");


    $vcg = (($sn1 % 100 ) * 100) + ($sn2 % 100);



#print " creating vcg $vcg \n";


    # tell the master it is in a VCG - vcgcreate
##    %rsp = $master->vcgCreate($vcg);
#
#    if ( ! %rsp  )
#    {
#        print ">>>>>>>> No response to create a vcg on $master <<<<<<<<\n";
#        return (ERROR);
#    }
#    else
#    {
##print " vcgcreate status = $rsp{STATUS} \n";
#        if ( $rsp{STATUS} == PI_GOOD )
#        {
#            print "Created vcg $vcg \n";
#        }
#        else
#        {
#            print ">>>>>>>> Failed to create a vcg on $masterIP <<<<<<<<\n";
#
#            PrintError(%rsp);
#
#            return (ERROR);
#        }
#    }
#

    #
    # Create a controller list array 
    #
    $ctlrList[0] = $master;
    $ctlrList[1] = $slave;

    $response = AddController (\@ctlrList, 1);
    if ($response != GOOD)
    {
        return (ERROR);
    }

#    logInfo("Wait a minute for all the targets to move ( bug 6356 workaround ) ");
#    DelaySecs(60);

    # check to make sure (use VCGINFO)

    # first, info from master
    %rsp = $master->vcgInfo($vcg);
    if ( ! %rsp  )
    {
        logError(">>>>> Failed to get master's vcginfo <<<<<");
        return (ERROR);
    }
    else
    {
        if ( $rsp{STATUS} == PI_GOOD )
        {
            logInfo("VCGINFO for master");
            logVCGInfo(%rsp);

        }
        else
        {
            logError(">>>>> Failed get vcginfo from master <<<<<");
            return (ERROR);
        }
    }

    # next, info from slave
    %rsp = $slave->vcgInfo($vcg);
    if ( ! %rsp  )
    {
        logError(">>>>> Failed to get slave's vcginfo <<<<<");
        return (ERROR);
    }
    else
    {
        if ( $rsp{STATUS} == PI_GOOD )
        {
            logInfo("VCGINFO for slave");
            logVCGInfo(%rsp);

        }
        else
        {
            logError(">>>>> Failed get vcginfo from slave <<<<<");
            return (ERROR);
        }
    }



    return (GOOD);

}
##############################################################################
#
#          Name: AddController
#
#        Inputs: ctlrListPtr, slaveIndex
#                where:  ctlrListPtr - pointer to array of all controllers
#                        slaveIndex  - index in ctlrList of slave controller
#                                      that is to be added to VCG 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: adds a controller to a VCG
#
##############################################################################
sub AddController
{
    trace();
    my ($ctlrListPtr, $slaveIndex) = @_;
    my %rsp;
    my $rms;
    my $retryTime = 60; # keep trying for 60 seconds
    my $ret;
    my $masterIndex;
    my $master;
    my $slave;
    my @ctlrList = @$ctlrListPtr;
    
    #
    # Check to make sure resource manager isn't doing anything
    #
    logInfo("     AddController: checking RMstate.");

    $ret = WaitRMStateRUNNING2($ctlrListPtr, 5, 60);
    if ($ret != GOOD)
    {
        logInfo("Error waiting for Resource Manager to finish.  Cannot add controller.");
        return ERROR;
    }

    #
    # Find the master controller
    #
    $masterIndex = FindMaster($ctlrListPtr);
    if ( $masterIndex == INVALID ) 
    { 
        logInfo("Unable to identify the master controller. Cannot add controller.");
        return(ERROR); 
    }
    $master = $ctlrList[$masterIndex];  
    $slave = $ctlrList[$slaveIndex];

    #
    # We are sure RM has behaved for the last 10 seconds. It is now
    # safe to add the controller.
    #

    logInfo("Adding Controller $slave->{'HOST'} to the VCG...");
    while ($retryTime > 0)
    {
        %rsp = $master->vcgAddController( $slave );
        if ( ! %rsp  )
        {
            logInfo(">>>>> Failed to add $slave->{'HOST'} to VCG (no response) <<<<<");
            return (ERROR);
        }
        else
        {
            if ( $rsp{STATUS} == PI_GOOD )
            {
                logInfo("Controller $slave->{'HOST'} added to VCG");
            }
            elsif ( $rsp{STATUS} == PI_ELECTION_ERROR )
            {
                # sleep 5 seconds and try again
                logInfo("Election in progress, trying again");
                $retryTime -= 5;
                if ($retryTime > 0)
                {
                    sleep 5;
                    next;
                }
            }
            last;
        }
    }

    if ( $rsp{STATUS} != PI_GOOD )
    {
        logInfo(">>>>> Failed to add controller $slave->{'HOST'} to VCG <<<<<");
        PrintError(%rsp);
        return (ERROR);
    }

    # now wait until the resource manager is ready,
    # first, give it a chance to start up

    $rms = GetRMState($master);
    print("Initial RMSTATE is $rms \n");

    $ret = WaitRMStateRUNNING2( $ctlrListPtr, 30, 120);
    if ($ret != GOOD)
    {
        logInfo("Error waiting for Resource manage to finish after adding controller.");
        return ERROR;
    }

    return (GOOD);

}
##############################################################################
#
#          Name: GetSerial
#
#        Inputs: controller
#
#       Outputs: INVALID in unable to get sn, otherwise the controller's sn
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub GetSerial
{
    trace();
    my ($ctlr) = @_;

    my %rsp;

    %rsp = $ctlr->serialNumGet();

    if ( ! %rsp  )
    {
        logWarning("Controller (ip: $ctlr->{HOST}) timed out while getting serial number");
        return INVALID;
    }
    else
    {
        if ( $rsp{STATUS} == PI_GOOD )
        {

            #debug("serialnumber :", %rsp, "\n",$rsp{2}{SERIAL_NUM}," \n" ,$rsp{1}{SERIAL_NUM} ," \n");
            return  $rsp{1}{SERIAL_NUM};

        }
        else
        {
            # we don't want to pause on this one.
            #logInfo("Controller (ip: $ctlr->{HOST}) returned error while reading serial number");
            #PrintError(%rsp);
            return INVALID;
        }
    }
}

#
#
##############################################################################
#
#          Name: WaitRMSTateRUNNING
#
#        Inputs: controller, timeout (seconds)
#
#       Outputs: ERROR if there is/was a problem, GOOD if state met
#
#  Globals Used: none
#
#   Description:  resource manager state is tested.
#
#
##############################################################################
sub WaitRMSTateRUNNING
{
    trace();
    my ($ctlr, $timeout) = @_;

    my $state;


    $state = GetRMState($ctlr);


    # Checks RMState every few seconds until is is RM_RUNNING or
    # times out

    while ( ( RM_RUNNING != GetRMState($ctlr) )  && ( $timeout > 0 ) )
    {
        DelaySecs(5);
        $timeout -= 5;
    }

    if ( $timeout < 0 )
    {
        return ERROR;        # Timed Out
    }
    else
    {
        return GOOD;         # was good
    }

}

#
#
##############################################################################
#
#          Name: WaitRMStateRUNNING2
#
#        Inputs: controller list pointer, duration (seconds), timeout (seconds)
#
#       Outputs: ERROR if there is/was a problem, GOOD if state met
#
#  Globals Used: none
#
#   Description: Finds the master controller.  Then waits for RM to be 
#                in the running state for $duration seconds.  If RM 
#                stays in the RM_DOWN state, then the master has probably
#                changed.  Find new master and continue.  Will  
#                timeout with error if it takes longer than $timeout 
#                seconds to get there.
#
#
##############################################################################
sub WaitRMStateRUNNING2
{
    trace();
    my ($ctlrListPtr, $duration, $timeout) = @_;

    my $state;

    my $goodState = 0;
    my $sample = 0;
    my @ctlrList = @$ctlrListPtr;
    my $master;             # index of master controller
    my $rmDownCount = 0;

    #
    # Find the master controller
    #
    $master = FindMaster($ctlrListPtr);
    if ( $master == INVALID ) 
    { 
        logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
        return(ERROR); 
    } 
    
    #
    # Get current RM state
    #
    $state = GetRMState($ctlrList[$master]);

    # Checks RMState every few seconds until is is RM_RUNNING or
    # times out

    while (  $timeout > $sample )
    {

        print "     WaitRMStateRUNNING2: sample = $sample, state = $state.     \r";

        if ( $state == RM_RUNNING )
        {
            #
            # in running state - incr good count
            # and reset RM_DOWN state count
            #
            $rmDownCount = 0;
            $goodState++;
            if ( $goodState > $duration )
            {
                # we are done
                print "\n\n";
                return GOOD;
            }

        }
        elsif ( $state == RM_DOWN )
        {
            #
            # if the state is RM_DOWN for more than a couple samples, 
            # master has probably moved.  find new master, reset count,
            # and continue 
            #
            $goodState = 0;
            $rmDownCount++;
            if ( $rmDownCount > 5 )
            {
                logInfo("WaitRMStateRUNNING2:  Current state RM_DOWN.".
                        "  sample number - $sample.  Verifying master.");
                $master = FindMaster($ctlrListPtr);
                if ( $master == INVALID ) 
                { 
                    logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
                    return(ERROR); 
                } 
                $rmDownCount = 0;
            }
        }
        else
        {
            #
            # not desired state, reset count
            #
            $goodState = 0;
            $rmDownCount = 0;
        }

        sleep 1;
        $sample++;
        $state = GetRMState($ctlrList[$master]);

    }

    #
    # We timed out, not good
    #

    logInfo(">>>>>>>> WaitRMStateRUNNING2:  ".
            "Timeout waiting for RMstate to be running. <<<<<<<<");
    return ERROR;        # Timed Out

}


##############################################################################
#
#          Name: GetRMState
#
#        Inputs: controller
#
#       Outputs: INVALID in unable to get it, otherwise the controller's rmstate
#
#  Globals Used: none
#
#   Description:  resource manager state is returned.
#
#
##############################################################################
sub GetRMState
{
    trace();
    my ($ctlr) = @_;

    my %rsp;

    %rsp = $ctlr->rmState();
    if ( ! %rsp  )
    {
        logWarning(">>>>> Failed to get rm state from the controller <<<<<");
        return INVALID;
    }
    else
    {
        if ( $rsp{STATUS} == PI_GOOD )
        {

                                    #    if ($info{STATE} == RM_NONE)
                                    #    {
                                    #        print "RM_NONE";
                                    #    }
                                    #    elsif ($info{STATE} == RM_INIT)
                                    #    {
                                    #        print "RM_INIT";
                                    #    }
                                    #    elsif ($info{STATE} == RM_SHUTDOWN)
                                    #    {
                                    #        print "RM_SHUTDOWN";
                                    #    }
                                    #    elsif ($info{STATE} == RM_RUNNING)
                                    #    {
                                    #        print "RM_RUNNING";
                                    #    }
                                    #    elsif ($info{STATE} == RM_BUSY)
                                    #    {
                                    #        print "RM_BUSY";
                                    #    }
                                    #    elsif ($info{STATE} == RM_DOWN)
                                    #    {
                                    #        print "RM_DOWN";
                                    #    }
                                    #    else
                                    #    {
                                    #        print "UNKNOWN";
                                    #    }

#print ("RM State =  $rsp{STATE} \n");                               # DEBUG

            return  $rsp{STATE};

        }
        else
        {
            logWarning(">>>>> Failed get rm state from controller <<<<<");
            return INVALID;
        }
    }
}


##############################################################################
#
#          Name: GetGroupSerial
#
#        Inputs: controller
#
#       Outputs: INVALID in unable to get sn, otherwise the controller's sn
#
#  Globals Used: none
#
#   Description:  serial number of VCG is returned.
#
#
##############################################################################
sub GetGroupSerial
{
    trace();
    my ($ctlr) = @_;

    my %rsp;

    %rsp = $ctlr->serialNumGet();

    if ( ! %rsp  )
    {
        logWarning(">>>>> Failed to get the controller's serial number <<<<<");
        return INVALID;
    }
    else
    {
        if ( $rsp{STATUS} == PI_GOOD )
        {

            debug(" serialnumber :", %rsp, "\n",$rsp{2}{SERIAL_NUM}," \n" ,$rsp{1}{SERIAL_NUM} ," \n");
            return  $rsp{2}{SERIAL_NUM};

        }
        else
        {
            logWarning(">>>>> Failed get serial number from controller <<<<<");
            return INVALID;
        }
    }
}


##############################################################################
#
#          Name: GetSerialFromMaster
#
#        Inputs: ptr to controller object list
#                ptr to serial number list
#                ptr to IP address list
#
#       Outputs: INVALID if unable to get info, otherwise GOOD
#
#  Globals Used: none
#
#   Description: Updates the serial number in snList by identifying the master
#                and extracting the serial numbers and IP information from the
#                vcg info from the master. Requires coList to have at least the
#                object for the existing master controller. $ipList must be
#                filled in.
#
#
##############################################################################
sub GetSerialFromMaster
{
    trace();
    my ($coPtr, $snPtr, $ipPtr) = @_;

    my %info;
    my $master;
    my $match;
    my $matchedIndex;
    my $i;
    my $j;
    my $k;
    my $ip;
    my $sn;
    my $thisIP;
    my $thisSN;

#print ("Getting master.....\n");

    $master = FindMaster($coPtr);     # identify the master

#print (" got master = $master ... \n");

    if ( $master == INVALID)
    {
        logInfo("Unable to determine the master controller - cannot complete");
        return INVALID;
    }

    # get the vcginfo


#print ("Getting master's vcg info.....\n");

    %info = $$coPtr[$master]->vcgInfo(0);

    if ( ! %info  )
    {
        logInfo("Unable to get vcginfo from master - cannot complete");
        return INVALID;
    }

    if (%info)
    {

        if ($info{STATUS} == PI_GOOD)
        {

#print ("scanning vcg info data.....\n");

            # check each controller listed
            for ( $j = 0; $j < $info{VCG_MAX_NUM_CONTROLLERS}; $j++ )
            {

                $ip = $info{CONTROLLERS}[$j]{IP_ADDRESS};
                $sn = $info{CONTROLLERS}[$j]{SERIAL_NUMBER};

#print (" line $j ...\n");

                # We have the IP and the SN, now scan the IP list
                # to find the index for that IP


                $match = 0;
                $matchedIndex = 0;

                for ( $k = 0; $k < scalar(@$ipPtr); $k++ )
                {
                    $thisIP = $$ipPtr[$k];


                    #print("Testing $ip against $thisIP, index = $k \n");

                    if ( $thisIP eq $ip )
                    {
                        $match += 1;
                        $matchedIndex = $k;

                    }
                }

                if ( $match > 0 )
                {
                    #logInfo(" Found $match matching ip addresses, last match at index $matchedIndex.");
                }

                $thisSN = $$snPtr[$matchedIndex];

                #logInfo("Corresponding serial numbers at index $matchedIndex, vcginf: $sn, list: $thisSN ");

                # now we can save the SN back into the callers list.

                $$snPtr[$matchedIndex] = $sn;

            }
            return GOOD;
        }
        else
        {
            # status was not good
            logInfo(">>>>>>>> Error getting vcginfo from controller  <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
    }  # end of if %rsp

    # no response from vcg info
    return ERROR;
}


##############################################################################
#
#          Name: DeleteAllVdisks
#
#        Inputs: controllerID
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Deletes all vdisks on the specified controller
#
#
##############################################################################
sub DeleteAllVdisks
{
    trace();

    my ($controller, $option) = @_;
    my $ret;

# need some error checking here!!!

    my %VIDs = $controller->virtualDiskList();
    my $listsub = $VIDs{LIST};
    my @list = @$listsub;

    debug(" vdisks to delete  @list");

    if(scalar(@list))
    {
        for (my $i = 0; $i < scalar(@list); $i++)
        {

            $ret = DeleteSingleVdisk($controller, $list[$i]);

            if ( $ret == GOOD )
            {
                print " VDisk ID =  $list[$i] was deleted \n";
            }
            else
            {
                return ERROR;
            }

        }   # end of for loop
    }
    else
    {
        logInfo("There are no virtual disks to delete");
    }

    return GOOD;
}

##############################################################################
#
#          Name: SelectVdiskOption
#
#        Inputs: current visik creation option
#
#       Outputs: new option, if successful, INVALID otherwise
#
#  Globals Used: none
#
#   Description: prompt the user and gat an input. The descriptions here
#                should match the MakeVdisks function.
#
#
##############################################################################
sub SelectVdiskOption
{
    trace();
    my ( $current ) = @_;

    print "\n\nOptions for creating vdisks are: \n";
    print "   1) 20 RAID 5, 1 GB to 20 GB size \n";
    print "   2) 16 mixed RAID, various sizes \n";
    print "   3) 20 mixed RAID, various sizes \n";
    print "   4) 20 RAID 10, various sizes \n";
    print "   5) 20 RAID 1,   <untested>   \n";
    print "   6) 20 RAID 1, various sizes \n";
    print "   7) 4 RAID 10, 4 RAID 5, various sizes \n";
    print "   8) 2 RAID 10  \n";
    print "   9) 2 Raid 10 (sizes different from #8) \n";
    print "  10) 26 mixed RAID, various sizes \n";
    print "  18) 2 RAID 5  \n";
    print "  19) 2 Raid 5 (sizes different from #18) \n";
    print "\n$current is presently selected\n";
    print "\n\nEnter your  choice: ";

    my $ans = <STDIN>;
    chomp ($ans);

    if ( $ans > 10 || $ans < 1 )
    {
        # bad choice
        return INVALID;
    }

    # answer is in range, use it
    return $ans;
}



##############################################################################
#
#          Name: MakeVdisks
#
#        Inputs: controllerID, strategy, option, numVdisks (optional)
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Makes a group of vdisks based upon a strategy. There
#                is the ability to pass an option to a strategy. Will
#                use data and unsafe drives as appropriate.
#
#                Do we care how these are grouped across channels?
#
#                Strategies:
#
#                1) Start at one GB, increase by 1/2 GB for 18 drives,
#                   then make 2 40GB drives, all Raid 5.
#
#                2) Duplicate Neal's group of drives.
#
#                3) Same as 1) but a mixture of raid types
#
#                4) Same as 1) but all RAID  10
#
#                5) Same as 1) but all RAID 1
#
#                6) Make drives based upon a list in a file passed via
#                   option. (Option is the filename)
#
#                7) just four medium sized Raid 5 and 4 medium sized raid 10
#
#                8,9) Two halfs of create vdisks for san links
#
#                10)
#
##############################################################################
sub MakeVdisks
{
    trace();

    my ($controller, $strategy, $option, $numVdisks) = @_;

    # variables I use
    my $numberToCreate;
    my $r;
    my $ret;
    my $bay;
    my @newVdisks;
    my %rsp;
    my $maxSize;
    my $foundRaid5;
    my $minpdisksflag = TRUE;

    # dummys for the compile, re-declared later
    my @VDMName;
    my @Capacity;
    my @Type;
    my @Stripe;
    my @Parity;
    my @Disks;
    my @Depth;

    # discover what PDDs are there and how they are labeled (devstat)
        # assume there are some physical drives for the moment


    # group drives, possibly according to strategy - just data manipulation
        # ( can't do, CLI doesn't support specifying the drive to use )

 #   my @All;
 #   my @A_ll;
 #   my @AllLessOne;
 #   my @GroupOfNonRed;
 #   my @GroupOfNon_Red;
 #   my @GRA;
 #   my @GRB;
 #   my @GRC;
 #   my @GRD;
 #   my @odds;
 #   my @evens;
 #   my @first2;
 #   my @middle2;
 #   my @last2;

    my $ourSN;
 #$   my $diskSN;

    my $i;
    my @ourDataEntries;       # indices to pdisks
    my @ourUnsafeEntries;
    my @ourDataEntriesSata;
    my @ourUnsafeEntriesSata;
    my @ourDataEntriesHighPerf;
    my @ourUnsafeEntriesHighPerf;
    my @ourDataEntriesPerf;
    my @ourUnsafeEntriesPerf;
    my @ourDataEntriesBalance;
    my @ourUnsafeEntriesBalance;
    my @ourDataEntriesCap;
    my @ourUnsafeEntriesCap;

    my @bays1;
    my @driveBays;

    my $bayFlag;
    my $drivesInAllData;
    my $drivesInAllUnsafe;
    my $drivesInGr3Data;
    my $drivesInGr5Data;
    my $drivesInGr9Data;
    my $msg;

    my $count;
    my $j;
    my $drvCount;
    my $pdd;
    my $skipped;

    my @bayPtr;
    my $UseArrays;


    #
    # Arrays for fibre drives
    #
    my @evenData = ();
    my @oddData = ();
    my @allData = ();
    my @allUnsafe = ();
    my @Gr3Data = ();
    my @Gr5Data = ();
    my @Gr9Data = ();
    

    #
    # Arrays for ISE volumes
    #
    my @evenDataHighPerf = ();
    my @evenDataPerf = ();
    my @evenDataBalance = ();
    my @evenDataCap = ();    
 
    my @oddDataHighPerf = ();
    my @oddDataPerf = ();
    my @oddDataBalance = ();
    my @oddDataCap = ();
 
    my @allDataHighPerf = ();
    my @allDataPerf = ();
    my @allDataBalance = ();
    my @allDataCap = ();
 
    my @allUnsafeHighPerf = ();
    my @allUnsafePerf = ();
    my @allUnsafeBalance = ();
    my @allUnsafeCap = ();
 
    my @Gr3DataHighPerf = ();
    my @Gr3DataPerf = ();
    my @Gr3DataBalance = ();
    my @Gr3DataCap = ();    
    
    my @Gr5DataHighPerf = ();
    my @Gr5DataPerf = ();
    my @Gr5DataBalance = ();
    my @Gr5DataCap = ();
    
    my @Gr9DataHighPerf = ();
    my @Gr9DataPerf = ();
    my @Gr9DataBalance = ();
    my @Gr9DataCap = ();
    
    #
    # arrays for sata drives
    #
    my @evenDataSata = ();
    my @oddDataSata = ();
    my @allDataSata = ();
    my @allUnsafeSata = ();
    my @Gr3DataSata = ();
    my @Gr5DataSata = ();
    my @Gr9DataSata = ();


    #
    # pointers to the drive arrays
    #
    
    # FC Drives
    my $evenDataPtr;
    my $oddDataPtr;
    my $allDataPtr;
    my $allUnsafePtr;
    my $Gr3DataPtr;
    my $Gr5DataPtr;
    my $Gr9DataPtr;

    # Sata Drives
    my $evenDataSataPtr;
    my $oddDataSataPtr;
    my $allDataSataPtr;
    my $allUnsafeSataPtr;
    my $Gr3DataSataPtr;
    my $Gr5DataSataPtr;
    my $Gr9DataSataPtr;

    # ISE drives
    my $evenDataHighPerfPtr;
    my $oddDataHighPerfPtr;
    my $allDataHighPerfPtr;
    my $allUnsafeHighPerfPtr;
    my $Gr3DataHighPerfPtr;
    my $Gr5DataHighPerfPtr;
    my $Gr9DataHighPerfPtr;

    my $evenDataPerfPtr;
    my $oddDataPerfPtr;
    my $allDataPerfPtr;
    my $allUnsafePerfPtr;
    my $Gr3DataPerfPtr;
    my $Gr5DataPerfPtr;
    my $Gr9DataPerfPtr;
    
    my $evenDataBalancePtr;
    my $oddDataBalancePtr;
    my $allDataBalancePtr;
    my $allUnsafeBalancePtr;
    my $Gr3DataBalancePtr;
    my $Gr5DataBalancePtr;
    my $Gr9DataBalancePtr;

    my $evenDataCapPtr;
    my $oddDataCapPtr;
    my $allDataCapPtr;
    my $allUnsafeCapPtr;
    my $Gr3DataCapPtr;
    my $Gr5DataCapPtr;
    my $Gr9DataCapPtr;    


    my $fcCount = 0;
    my $sataCount = 0;
    my $HighPerfCount = 0;
    my $PerfCount = 0;
    my $BalanceCount = 0;
    my $CapCount = 0;



    my $drivesInOddData;
    my $drivesInEvenData;
    my $bayflag;
    my $driveCnt;
    my $numDrives;


    if ( $controller == 0 )
    {
        logWarning(">>>>> Failed, need a valid controller object. <<<<<");
        return (ERROR);
    }


    logInfo("     MakeVdisks: strategy # $strategy.");

    # get our serial number, used to see if we will own a drive

    $ourSN = GetGroupSerial( $controller );
    if ( INVALID == $ourSN  )
    {
        logWarning(">>>>> Failed to get controller's serial number <<<<<");
        return (ERROR);
    }

    # NEED TO DO THIS PART

    #######################################
    # Name:     DiskGroupSetUp
    ######################################

    my $rc = 0;
    my $n = 0;
    my $A = 0;
    my $B = 0;
    my $C = 0;
    my $D = 0;

    logInfo("============ Disks Group and Drive Information ==========");


    ###########################################
    #          Get pdisk related information
    ###########################################


    my %pdisks = $controller->physicalDisks();

    if ( ! %pdisks )     # no response from controller
    {
        logInfo(">>>>> Failed to get pdisk list (no response) <<<<<");
        return ERROR;
    }
    else                          # got a response
    {
        if ( $pdisks{STATUS} == PI_GOOD )
        {
            # good path - this is expected
            logInfo("disk list is good, now walking it");
        }
        else
        {
            # got an error, report it, bail
            logInfo(">>>>> Failed getting pdisk list <<<<<");
            PrintError(%pdisks);
            return ERROR;
        }
    }

    # set $minpdisksflag to FALSE, if there are more than 5 physical disks
    # this is intended for a 750 controller with minimum number of physical
    # disks.
        
    if ( $pdisks{COUNT} > 5 )
    {
             
        $minpdisksflag = FALSE;

    }

    for(my $i = 0; $i < $pdisks{COUNT}; ++$i)
    {
        # These are the data items we will use

        #    $pdisks{COUNT}
        #    $pdisks{PDISKS}[$i]{PD_PID}
        #                   [$i]{SES},
        #                   [$i]{SLOT},
        #                   [$i]{PD_CLASS},
        #                   [$i]{PD_SSERIAL},
        #                   [$i]{PD_PID},

        # go thru the disk list and count the data and unsafe disks. keep
        # an array of each


        # let's see if we 'own' this disk. To own it, the serial number
        # must be ours.


        # compare to our SN, if match we can use
        if ( $ourSN == $pdisks{PDISKS}[$i]{PD_SSERIAL} )
        {
            # OK to use this drive - put in right group

            if ($pdisks{PDISKS}[$i]{PD_CLASS} == CCBEUNSAFETYPE)
            {
                # add unsafe drive index to array
                push(@ourUnsafeEntries, $i);
            }
            elsif($pdisks{PDISKS}[$i]{PD_CLASS} == CCBEDATATYPE)
            {
                # add data drive index to array
                push(@ourDataEntries, $i);
            }
        }

        # While we are walking the list, lets count drive bays
        # We do this because a one or two drive bay system may
        # cause a problem in some configurations. Collect a bay
        # list here.

        push(@bays1, $pdisks{PDISKS}[$i]{SES});



        #
        # count fibre vs. sata drives vs. ISE drive teirs
        #
        if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$i]{PD_DEVTYPE} )  # fibre
        {
            $fcCount++;
        }
        elsif ( PD_DT_SATA == $pdisks{PDISKS}[$i]{PD_DEVTYPE} ) #sata
        {
            $sataCount++;
        }
        elsif ( PD_DT_ISE_HIGH_PERF == $pdisks{PDISKS}[$i]{PD_DEVTYPE} ) #ISE High Perf
        {
            $HighPerfCount++;
        }
        elsif ( PD_DT_ISE_PERF == $pdisks{PDISKS}[$i]{PD_DEVTYPE} ) #ISE Perf
        {
            $PerfCount++;
        }
        elsif ( PD_DT_ISE_BALANCE == $pdisks{PDISKS}[$i]{PD_DEVTYPE} ) #ISE Balance
        {
            $BalanceCount++;
        }
        elsif ( PD_DT_ISE_CAPACITY == $pdisks{PDISKS}[$i]{PD_DEVTYPE} ) #ISE Cap
        {
            $CapCount++;
        }

    }


    logInfo("Found $fcCount Fibre drives, $sataCount SATA drives, $HighPerfCount ISE High Performance Drives.");
    logInfo("Found $PerfCount ISE Performance drives, $BalanceCount ISE Balance drives and $CapCount ISE Capacity Drives.");
    @driveBays = SortAndRemoveDups(@bays1);

    #
    # Now we have list of pdisk pointers that we own for data and
    # unsafe type. Using the appropriate SES/SLOT info we can break
    # the disks into several groups. We also know how many bays we have.
    #

    # Establish the number of drives for each disk group we will use

    # If there are less than 3 bays, make the number of drives even for
    # all groups. For the "all" groups reduce the count if needed. For the
    # subsets, increase the count if needed.




    $bayFlag = 0;                          # 0 = lots of bays
    if ( scalar( @driveBays ) < 3 ) {$bayFlag = 1; }


    $drivesInAllData   = scalar(@ourDataEntries);
    $drivesInAllUnsafe = scalar(@ourUnsafeEntries);
    $drivesInOddData   = int (scalar(@ourDataEntries) / 2);
    $drivesInEvenData  = int (scalar(@ourDataEntries) / 2);

    if ( $bayflag )
    {
        $drivesInAllData   = $drivesInAllData   - $drivesInAllData   % 2;
        $drivesInAllUnsafe = $drivesInAllUnsafe - $drivesInAllUnsafe % 2;

        # at least the math doesn't assume the data to be simple integers

    }

    # the adjustments are based upon raid 5 requirements (this correction
    # may go away)

    $drivesInGr3Data = 3 + $bayFlag;
    $drivesInGr5Data = 5 + $bayFlag;
    $drivesInGr9Data = 9 + $bayFlag;

    #
    # Now validate the group sizes. If we didn't have enough pdisks to
    # start with, we will have trouble creating some configurations. In
    # thisscase, rather than looking at what drives were are going to
    # create per the requested strategy, we are just looking at our
    # ability to create the disk groupings.
    #

    # We really only need to check a few as that will cover the rest.
    # (This still won't guarantee success because we haven't looked
    # at what labels are on the drive by bay.)

    # If the total pdisk count is more than 5 then only check for data and unsafe drives
    # This check is to allow vdiskcreation when there only minimum pdisks in a controller

    if ( $pdisks{COUNT} > 14 )
    {
        if ( $drivesInGr9Data > scalar(@ourDataEntries) ||
            $drivesInAllUnsafe < 2 )
        {
            $msg =  "There does not appear to be enough pdisks with the right labels\n";
            $msg .= "to build the necessary configuration. You will need to relabel\n";
            $msg .= "your drives, or add more drives or bays.\n\n";
            $msg .= "Group:      Drives needed:     Drives available:\n";
            $msg .= "9 data              $drivesInGr9Data                  $drivesInAllData \n";
            $msg .= "unsafe              2                    $drivesInAllUnsafe  \n";

            logInfo($msg);
            # don't return, rather let a drive create fail
            # return ERROR;
        }
    }

    print "    Putting drives into groups.\n";

    #
    # Now we build the individual disk arrays. We do our best to spread
    # them across the bays. (This may be ugly.)
    #

    # do the easy ones first - most/all data

    for ( $i = 0; $i < $drivesInAllData; $i++ )
    {
        if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # fibre
        {
            push( @allData, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
        }
        elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # sata
        {
            push( @allDataSata, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
        }
        elsif ( PD_DT_ISE_HIGH_PERF == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE High Perf
        {
            push( @allDataHighPerf, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
        }
        elsif ( PD_DT_ISE_PERF == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE Perf
        {
            push( @allDataPerf, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
        }
        elsif ( PD_DT_ISE_BALANCE == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE Balance
        {
            push( @allDataBalance, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
        }
        elsif ( PD_DT_ISE_CAPACITY == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE Capacity
        {
            push( @allDataCap, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
        }
    }

    print "      all data groups done \n";

    # most/all of the unsafes

    for ( $i = 0; $i < $drivesInAllUnsafe; $i++ )
    {

        if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_DEVTYPE} )  # fibre
        {
            push( @allUnsafe, $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_PID} );
        }
        elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_DEVTYPE} )  # sata
        {
            push( @allUnsafeSata, $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_PID} );
        }
        elsif ( PD_DT_ISE_HIGH_PERF == $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_DEVTYPE} )  # ISE High Perf
        {
            push( @allUnsafeHighPerf, $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_PID} );
        }
        elsif ( PD_DT_ISE_PERF == $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_DEVTYPE} )  # ISE Perf
        {
            push( @allUnsafePerf, $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_PID} );
        }
        elsif ( PD_DT_ISE_BALANCE == $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_DEVTYPE} )  # ISE Balance
        {
            push( @allUnsafeBalance, $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_PID} );
        }
        elsif ( PD_DT_ISE_CAPACITY == $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_DEVTYPE} )  # ISE Capacity
        {
            push( @allUnsafeCap, $pdisks{PDISKS}[$ourUnsafeEntries[$i]]{PD_PID} );
        }

    }

    print "      all unsafe groups done \n";


    # now the odd/evens

    for ( $j = 0; $j < scalar( @driveBays ); $j++ )
    {
        $count = 0;

        for ( $i = 0; $i < $drivesInAllData; $i++ )
        {
            if ( $driveBays[$j] ==  $pdisks{PDISKS}[$ourDataEntries[$i]]{SES} )
            {
                # same bay, select odd/even

                if ( ($count % 2) == 0 )
                {

                    if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # fibre
                    {
                        push( @evenData, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }
                    elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} ) # sata
                    {
                        push( @evenDataSata, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }
                    elsif ( PD_DT_ISE_HIGH_PERF == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE High Perf
                    {
                        push( @evenDataHighPerf, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }
                    elsif ( PD_DT_ISE_PERF == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE Perf
                    {
                        push( @evenDataPerf, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }
                    elsif ( PD_DT_ISE_BALANCE == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE Balance
                    {
                        push( @evenDataBalance, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }
                    elsif ( PD_DT_ISE_CAPACITY == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE Capacity
                    {
                        push( @evenDataCap, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }

                }
                else
                {

                    if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # fibre
                    {
                        push( @oddData, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }
                    elsif ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # sata
                    {
                        push( @oddDataSata, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }
                    elsif ( PD_DT_ISE_HIGH_PERF == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE High Perf
                    {
                        push( @oddDataHighPerf, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }
                    elsif ( PD_DT_ISE_PERF == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE Perf
                    {
                        push( @oddDataPerf, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }
                    elsif ( PD_DT_ISE_BALANCE == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE Balance
                    {
                        push( @oddDataBalance, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }
                    elsif ( PD_DT_ISE_CAPACITY == $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_DEVTYPE} )  # ISE Capacity
                    {
                        push( @oddDataCap, $pdisks{PDISKS}[$ourDataEntries[$i]]{PD_PID} );
                    }

                }

                $count++;
            }
        }

    }

    print "      odd and even groups done \n";


my $productID = getMagProductID( 0, $controller ); # Get the product ID

 if ( $productID != 7000 ) 
 {
    if ($fcCount > 0 )
    {

        #
        # now the raid 5 data ones. First do all the FC drives, then repeat
        # for all the SATA drives.
        #

        # make/init some Ptr for each bay. These are the index for the last
        # pdisk used from the bay.

        for ( $i = 0; $i < scalar( @driveBays ); $i++ )
        {
            $bayPtr[$i]=0;
        }


        #
        # first the parity 3 group
        #

        $bay = 0;
        $pdd = 0;

        $driveCnt = 0;

        while ($driveCnt <  $drivesInGr3Data)
        {

            if (
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr3Data ) )  # not in list
               )
            {
                # add drive to list
                push ( @Gr3Data, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P3 FC group done \n";



        #
        # next the parity 5 group ( don't reset $pdd or $bay )
        #



        $driveCnt = 0;

        while ($driveCnt <  $drivesInGr5Data)
        {

            if (                                                        
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr5Data ))   # not in list
               )
            {
                # add drive to list
                push ( @Gr5Data, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P5 FC group done \n";

        #
        # last the parity 9group ( don't reset $pdd or $bay )
        #


        #
        # Check to see if there are enough fc data drives available to create a 
        # parity 9 group.  If not, create a parity 5 group instead.
        # 
        if ( $drivesInGr9Data > scalar(@allData) )
        {
            logInfo("Not enough FC data drives available to create a parity 9 group.");
            logInfo("Will use a parity 5 group instead.");
            $numDrives = $drivesInGr5Data;    
        }
        else 
        {
            $numDrives = $drivesInGr9Data;    
        } 

        $driveCnt = 0;
        while ($driveCnt <  $numDrives)
        {

            if (
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_FC_DISK == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr9Data ) )  # not in list
               )
            {
                # add drive to list
                push ( @Gr9Data, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
          
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P9 FC group done \n";
    }
  }
    #
    # Let's do the same thing for the ISE drive types.  This is repeated for each drive tier
    #    
    
    #  ISE High Performance
    
    if ($HighPerfCount > 0 )
    {

        #
        # now the raid 5 data ones. First do all the ISE High Performance drives
        #

        # make/init some Ptr for each bay. These are the index for the last
        # pdisk used from the bay.

        for ( $i = 0; $i < scalar( @driveBays ); $i++ )
        {
            $bayPtr[$i]=0;
        }


        #
        # first the parity 3 group
        #

        $bay = 0;
        $pdd = 0;

        $driveCnt = 0;

        while ($driveCnt <  $drivesInGr3Data)
        {

            if (
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_HIGH_PERF == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr3DataHighPerf ) )  # not in list
               )
            {
                # add drive to list
                push ( @Gr3DataHighPerf, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P3 FC group done \n";



        #
        # next the parity 5 group ( don't reset $pdd or $bay )
        #



        $driveCnt = 0;

        while ($driveCnt <  $drivesInGr5Data)
        {

            if (                                                        
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_HIGH_PERF == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr5DataHighPerf ))   # not in list
               )
            {
                # add drive to list
                push ( @Gr5DataHighPerf, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P5 FC group done \n";

        #
        # last the parity 9group ( don't reset $pdd or $bay )
        #


        #
        # Check to see if there are enough ISE data drives available to create a 
        # parity 9 group.  If not, create a parity 5 group instead.
        # 
        if ( $drivesInGr9Data > scalar(@allDataHighPerf) )
        {
            logInfo("Not enough ISE High Performance data drives available to create a parity 9 group.");
            logInfo("Will use a parity 5 group instead.");
            $numDrives = $drivesInGr5Data;    
        }
        else 
        {
            $numDrives = $drivesInGr9Data;    
        } 

        $driveCnt = 0;
        while ($driveCnt <  $numDrives)
        {

            if (
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_HIGH_PERF == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr9DataHighPerf ) )  # not in list
               )
            {
                # add drive to list
                push ( @Gr9DataHighPerf, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P9 FC group done \n";
    }

    #
    # ISE Perf Drives
    #
    if ($PerfCount > 0 )
    {

        #
        # now the raid 5 data ones. First do all the ISE Performance drives
        #

        # make/init some Ptr for each bay. These are the index for the last
        # pdisk used from the bay.

        for ( $i = 0; $i < scalar( @driveBays ); $i++ )
        {
            $bayPtr[$i]=0;
        }


        #
        # first the parity 3 group
        #

        $bay = 0;
        $pdd = 0;

        $driveCnt = 0;

        while ($driveCnt <  $drivesInGr3Data)
        {

            if (
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_PERF == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr3DataPerf ) )  # not in list
               )
            {
                # add drive to list
                push ( @Gr3DataPerf, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P3 FC group done \n";



        #
        # next the parity 5 group ( don't reset $pdd or $bay )
        #



        $driveCnt = 0;

        while ($driveCnt <  $drivesInGr5Data)
        {

            if (                                                        
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_PERF == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr5DataPerf ))   # not in list
               )
            {
                # add drive to list
                push ( @Gr5DataPerf, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P5 FC group done \n";

        #
        # last the parity 9group ( don't reset $pdd or $bay )
        #


        #
        # Check to see if there are enough ISE data drives available to create a 
        # parity 9 group.  If not, create a parity 5 group instead.
        # 
        if ( $drivesInGr9Data > scalar(@allDataPerf) )
        {
            logInfo("Not enough ISE Performance data drives available to create a parity 9 group.");
            logInfo("Will use a parity 5 group instead.");
            $numDrives = $drivesInGr5Data;    
        }
        else 
        {
            $numDrives = $drivesInGr9Data;    
        } 

        $driveCnt = 0;
        while ($driveCnt <  $numDrives)
        {

            if (
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_PERF == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr9DataPerf ) )  # not in list
               )
            {
                # add drive to list
                push ( @Gr9DataPerf, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P9 FC group done \n";
    }

    #
    # ISE Balance Drives
    #
    if ($BalanceCount > 0 )
    {

        #
        # now the raid 5 data ones. First do all the ISE Performance drives
        #

        # make/init some Ptr for each bay. These are the index for the last
        # pdisk used from the bay.

        for ( $i = 0; $i < scalar( @driveBays ); $i++ )
        {
            $bayPtr[$i]=0;
        }


        #
        # first the parity 3 group
        #

        $bay = 0;
        $pdd = 0;

        $driveCnt = 0;

        while ($driveCnt <  $drivesInGr3Data)
        {

            if (
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_BALANCE == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr3DataBalance ) )  # not in list
               )
            {
                # add drive to list
                push ( @Gr3DataBalance, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P3 FC group done \n";



        #
        # next the parity 5 group ( don't reset $pdd or $bay )
        #



        $driveCnt = 0;

        while ($driveCnt <  $drivesInGr5Data)
        {

            if (                                                        
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_BALANCE == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr5DataBalance ))   # not in list
               )
            {
                # add drive to list
                push ( @Gr5DataBalance, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P5 FC group done \n";

        #
        # last the parity 9group ( don't reset $pdd or $bay )
        #


        #
        # Check to see if there are enough ISE data drives available to create a 
        # parity 9 group.  If not, create a parity 5 group instead.
        # 
        if ( $drivesInGr9Data > scalar(@allDataBalance) )
        {
            logInfo("Not enough ISE Balance data drives available to create a parity 9 group.");
            logInfo("Will use a parity 5 group instead.");
            $numDrives = $drivesInGr5Data;    
        }
        else 
        {
            $numDrives = $drivesInGr9Data;    
        } 

        $driveCnt = 0;
        while ($driveCnt <  $numDrives)
        {

            if (
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_BALANCE == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr9DataBalance) )  # not in list
               )
            {
                # add drive to list
                push ( @Gr9DataBalance, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P9 FC group done \n";
    }

    #
    # ISE Capacity Drives
    #
    if ($CapCount > 0 )
    {

        #
        # now the raid 5 data ones. First do all the ISE Capacity drives
        #

        # make/init some Ptr for each bay. These are the index for the last
        # pdisk used from the bay.

        for ( $i = 0; $i < scalar( @driveBays ); $i++ )
        {
            $bayPtr[$i]=0;
        }


        #
        # first the parity 3 group
        #

        $bay = 0;
        $pdd = 0;

        $driveCnt = 0;

        while ($driveCnt <  $drivesInGr3Data)
        {

            if (
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_CAPACITY == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr3DataCap) )  # not in list
               )
            {
                # add drive to list
                push ( @Gr3DataCap, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P3 FC group done \n";



        #
        # next the parity 5 group ( don't reset $pdd or $bay )
        #



        $driveCnt = 0;

        while ($driveCnt <  $drivesInGr5Data)
        {

            if (                                                        
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_CAPACITY == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr5DataCap ))   # not in list
               )
            {
                # add drive to list
                push ( @Gr5DataCap, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P5 FC group done \n";

        #
        # last the parity 9group ( don't reset $pdd or $bay )
        #


        #
        # Check to see if there are enough ISE data drives available to create a 
        # parity 9 group.  If not, create a parity 5 group instead.
        # 
        if ( $drivesInGr9Data > scalar(@allDataCap) )
        {
            logInfo("Not enough ISE Balance data drives available to create a parity 9 group.");
            logInfo("Will use a parity 5 group instead.");
            $numDrives = $drivesInGr5Data;    
        }
        else 
        {
            $numDrives = $drivesInGr9Data;    
        } 

        $driveCnt = 0;
        while ($driveCnt <  $numDrives)
        {

            if (
                 ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&         # bay matches and
                 ( PD_DT_ISE_CAPACITY == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&        # drive type matches and
                 ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr9DataCap) )  # not in list
               )
            {
                # add drive to list
                push ( @Gr9DataCap, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                $bay++;                                # switch to next bay
                $bay = $bay  % scalar(@driveBays);     # wrap bay number

                $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                $driveCnt++;                           # show we got another one
                $skipped = 0;                          # reset skipped counter

            }
            else
            {
                # skip drive, bay mismatched, or was in list
                $pdd++;
                $skipped++;
                if($skipped > scalar(@ourDataEntries) )
                {
                    # we've skipped enough drives that we can't find
                    # any more in this bay, go on to the next bay
                    # and search for the next drive
                    $bay++;
                    $skipped = 0;
                }
            }

            # wrap pointers if necessary

            $pdd = $pdd % scalar(@ourDataEntries);
            $bay = $bay % scalar(@driveBays);

        }

        print "      R5P9 FC group done \n";
    }

    
    #
    # Now do the above for the SATA drives. Same code, different variables.
    #
    # first the parity 3 group
    #

    if ( $minpdisksflag == FALSE )
    {
        if ( $sataCount > 0 )
        {

            $bay = 0;
            $pdd = 0;

            $driveCnt = 0;

            while ($driveCnt <  $drivesInGr3Data)
            {
                if (
                    ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&          # bay matches and
                    ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&            # drive type matches and
                    ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr3DataSata ) )   # not in list
                )
                {
                    # add drive to list
                    push ( @Gr3DataSata, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                    $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                    $bay++;                                # switch to next bay
                    $bay = $bay  % scalar(@driveBays);     # wrap bay number

                    $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                    $driveCnt++;                           # show we got another one
                    $skipped = 0;                          # reset skipped counter

                }
                else
                {
                    # skip drive, bay mismatched, or was in list
                    $pdd++;
                    $skipped++;
                    if($skipped > scalar(@ourDataEntries) )
                    {
                        # we've skipped enough drives that we can't find
                        # any more in this bay, go on to the next bay
                        # and search for the next drive
                        $bay++;
                        $skipped = 0;
                    }
                }

                # wrap pointers if necessary

                $pdd = $pdd % scalar(@ourDataEntries);
                $bay = $bay % scalar(@driveBays);

            }
            print "      R5P3 SATA group done \n";

            #
            # next the parity 5 group ( don't reset $pdd or $bay )
            #

            if ( scalar(@allDataSata) >= 6 ) # This check is added as part of 750 changes, this may go later. 
            {

                $driveCnt = 0;
                while ($driveCnt <  $drivesInGr5Data)
                {

                    if (
                        ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&          # bay matches and
                        ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&            # drive type matches and
                        ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr5DataSata ))    # not in list
                    )
                    {
                        # add drive to list
                        push ( @Gr5DataSata, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                        $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                        $bay++;                                # switch to next bay
                        $bay = $bay  % scalar(@driveBays);     # wrap bay number

                        $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                        $driveCnt++;                           # show we got another one
                        $skipped = 0;                          # reset skipped counter
                        logInfo (" 5 data disks @Gr5DataSata");

                    }
                    else
                    {
                        # skip drive, bay mismatched, or was in list
                        $pdd++;
                        $skipped++;
                        if($skipped > scalar(@ourDataEntries) )
                        {
                            # we've skipped enough drives that we can't find
                            # any more in this bay, go on to the next bay
                            # and search for the next drive
                            $bay++;
                            $skipped = 0;
                        }
                    }

                    # wrap pointers if necessary

                    $pdd = $pdd % scalar(@ourDataEntries);
                    $bay = $bay % scalar(@driveBays);

                }
                print "      R5P5 SATA group done \n";


                #
                # last the parity 9 group ( don't reset $pdd or $bay )
                #

                #
                # Check to see if there are enough sata data drives available to create a 
                # parity 9 group.  If not, create a parity 5 group instead.
                # 
                if ( $drivesInGr9Data > scalar(@allDataSata) )
                {
                    logInfo("Not enough SATA data drives available to create a parity 9 group.");
                    logInfo("Will use a parity 5 group instead.");
                    $numDrives = $drivesInGr5Data;    
                }
                else 
                {
                    $numDrives = $drivesInGr9Data;    
                } 

                $driveCnt = 0;
                while ($driveCnt <  $numDrives)
                {

                    if (
                        ( $pdisks{PDISKS}[$ourDataEntries[$pdd]]{SES} == $driveBays[$bay] ) &&          # bay matches and
                        ( PD_DT_SATA == $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_DEVTYPE} ) &&            # drive type matches and
                        ( 0 == IsInList($pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID}, \@Gr9DataSata ) )   # not in list
                    )
                    {
                        # add drive to list
                        push ( @Gr9DataSata, $pdisks{PDISKS}[$ourDataEntries[$pdd]]{PD_PID} );
                        $bayPtr[$bay]= $pdd +1;                # search to resume at next pdd
                        $bay++;                                # switch to next bay
                        $bay = $bay  % scalar(@driveBays);     # wrap bay number

                        $pdd = $bayPtr[$bay];                  # get starting pdd for new bay

                        $driveCnt++;                           # show we got another one
                        $skipped = 0;                          # reset skipped counter

                    }
                    else
                    {
                        # skip drive, bay mismatched, or was in list
                        $pdd++;
                        $skipped++;
                        if($skipped > scalar(@ourDataEntries) )
                        {
                            # we've skipped enough drives that we can't find
                            # any more in this bay, go on to the next bay
                            # and search for the next drive
                            $bay++;
                            $skipped = 0;
                        }
                    }

                    # wrap pointers if necessary

                    $pdd = $pdd % scalar(@ourDataEntries);
                    $bay = $bay % scalar(@driveBays);

                }

                print "      R5P9 SATA group done \n";
            } # End of checking if enough data drives available for creating parity 5 and 9 
            else
            {
                logInfo("Not enough SATA data drives available to create a parity 5 & 9 group.");
                logInfo("Will create only parity 3 disks.");
            }

        }

    } # End of check

    #
    # Drives are sorted into groups, but some groups may be empty based
    # upon the number and type of bays.
    #


    $bay = scalar(@driveBays) ;

    my $str = "\nI think there are $bay bay(s). (@driveBays) \n";

    $str .=  "------------- disk groupings ----- step 1 --------\n";

    # fibre ones
    $str .= sprintf "                Gr9Data[%3d",scalar(@Gr9Data);
    $str .=  "]:  @Gr9Data \n";

    $str .= sprintf "                Gr5Data[%3d",scalar(@Gr5Data);
    $str .=  "]:  @Gr5Data \n";

    $str .= sprintf "                Gr3Data[%3d",scalar(@Gr3Data);
    $str .=  "]:  @Gr3Data \n";

    $str .= sprintf "                allData[%3d",scalar(@allData);
    $str .=  "]:  @allData \n";

    $str .= sprintf "              allUnsafe[%3d",scalar(@allUnsafe);
    $str .=  "]:  @allUnsafe \n";

    $str .= sprintf "               evenData[%3d",scalar(@evenData);
    $str .=  "]:  @evenData \n";

    $str .= sprintf "                oddData[%3d",scalar(@oddData);
    $str .= "]:  @oddData \n";
    
    # ISE High Performance Drive
    $str .= sprintf "                Gr9DataHighPerf[%3d",scalar(@Gr9DataHighPerf);
    $str .=  "]:  @Gr9DataHighPerf \n";

    $str .= sprintf "                Gr5DataHighPerf[%3d",scalar(@Gr5DataHighPerf);
    $str .=  "]:  @Gr5DataHighPerf \n";

    $str .= sprintf "                Gr3DataHighPerf[%3d",scalar(@Gr3DataHighPerf);
    $str .=  "]:  @Gr3DataHighPerf \n";

    $str .= sprintf "                allDataHighPerf[%3d",scalar(@allDataHighPerf);
    $str .=  "]:  @allDataHighPerf \n";

    $str .= sprintf "              allUnsafeHighPerf[%3d",scalar(@allUnsafeHighPerf);
    $str .=  "]:  @allUnsafeHighPerf \n";

    $str .= sprintf "               evenDataHighPerf[%3d",scalar(@evenDataHighPerf);
    $str .=  "]:  @evenDataHighPerf \n";

    $str .= sprintf "                oddDataHighPerf[%3d",scalar(@oddDataHighPerf);
    $str .= "]:  @oddDataHighPerf \n";
    
    # ISE Performance Drive
    $str .= sprintf "                Gr9DataPerf[%3d",scalar(@Gr9DataPerf);
    $str .=  "]:  @Gr9DataPerf \n";

    $str .= sprintf "                Gr5DataPerf[%3d",scalar(@Gr5DataPerf);
    $str .=  "]:  @Gr5DataPerf \n";

    $str .= sprintf "                Gr3DataPerf[%3d",scalar(@Gr3DataPerf);
    $str .=  "]:  @Gr3DataPerf \n";

    $str .= sprintf "                allDataPerf[%3d",scalar(@allDataPerf);
    $str .=  "]:  @allDataPerf \n";

    $str .= sprintf "              allUnsafePerf[%3d",scalar(@allUnsafePerf);
    $str .=  "]:  @allUnsafePerf \n";

    $str .= sprintf "               evenDataPerf[%3d",scalar(@evenDataPerf);
    $str .=  "]:  @evenDataPerf \n";

    $str .= sprintf "                oddDataPerf[%3d",scalar(@oddDataPerf);
    $str .= "]:  @oddDataPerf \n";
    
    # ISE Balance Drive
    $str .= sprintf "                Gr9DataBalance[%3d",scalar(@Gr9DataBalance);
    $str .=  "]:  @Gr9DataBalance \n";

    $str .= sprintf "                Gr5DataBalance[%3d",scalar(@Gr5DataBalance);
    $str .=  "]:  @Gr5DataBalance \n";

    $str .= sprintf "                Gr3DataBalance[%3d",scalar(@Gr3DataBalance);
    $str .=  "]:  @Gr3DataBalance \n";

    $str .= sprintf "                allDataBalance[%3d",scalar(@allDataBalance);
    $str .=  "]:  @allDataBalance \n";

    $str .= sprintf "              allUnsafeBalance[%3d",scalar(@allUnsafeBalance);
    $str .=  "]:  @allUnsafeBalance \n";

    $str .= sprintf "               evenDataBalance[%3d",scalar(@evenDataBalance);
    $str .=  "]:  @evenDataBalance \n";

    $str .= sprintf "                oddDataBalance[%3d",scalar(@oddDataBalance);
    $str .= "]:  @oddDataBalance \n";
    
    # ISE Capacity Drive
    $str .= sprintf "                Gr9DataCap[%3d",scalar(@Gr9DataCap);
    $str .=  "]:  @Gr9DataCap \n";

    $str .= sprintf "                Gr5DataCap[%3d",scalar(@Gr5DataCap);
    $str .=  "]:  @Gr5DataCap \n";

    $str .= sprintf "                Gr3DataCap[%3d",scalar(@Gr3DataCap);
    $str .=  "]:  @Gr3DataCap \n";

    $str .= sprintf "                allDataCap[%3d",scalar(@allDataCap);
    $str .=  "]:  @allDataCap \n";

    $str .= sprintf "              allUnsafeCap[%3d",scalar(@allUnsafeCap);
    $str .=  "]:  @allUnsafeCap \n";

    $str .= sprintf "               evenDataCap[%3d",scalar(@evenDataCap);
    $str .=  "]:  @evenDataCap \n";

    $str .= sprintf "                oddDataCap[%3d",scalar(@oddDataCap);
    $str .= "]:  @oddDataCap \n";

    # sata ones
    $str .= sprintf "            Gr9DataSata[%3d",scalar(@Gr9DataSata);
    $str .=  "]:  @Gr9DataSata \n";

    $str .= sprintf "            Gr5DataSata[%3d",scalar(@Gr5DataSata);
    $str .=  "]:  @Gr5DataSata \n";

    $str .= sprintf "            Gr3DataSata[%3d",scalar(@Gr3DataSata);
    $str .=  "]:  @Gr3DataSata \n";

    $str .= sprintf "            allDataSata[%3d",scalar(@allDataSata);
    $str .=  "]:  @allDataSata \n";

    $str .= sprintf "          allUnsafeSata[%3d",scalar(@allUnsafeSata);
    $str .=  "]:  @allUnsafeSata \n";

    $str .= sprintf "           evenDataSata[%3d",scalar(@evenDataSata);
    $str .=  "]:  @evenDataSata \n";

    $str .= sprintf "            oddDataSata[%3d",scalar(@oddDataSata);
    $str .= "]:  @oddDataSata \n";

    $str .=  " -----------------------------------------\n";
    logInfo($str);


#return ERROR;

    #
    # Groups are filled with the drives we have. Now setup pointers that will be used
    # for the rest of the function. If an array is empty, the pointer will point to
    # the corresponding array for the other drive type. (We can have one type of bay
    # or mixed and this should all work.
    #

    $evenDataPtr = \@evenData;
    $oddDataPtr = \@oddData;
    $allDataPtr = \@allData;
    $allUnsafePtr = \@allUnsafe;
    $Gr3DataPtr = \@Gr3Data;
    $Gr5DataPtr = \@Gr5Data;
    $Gr9DataPtr = \@Gr9Data;
    
    # Create the data pointers for the ISE.  This is for future use and will not be used right now.
    $evenDataHighPerfPtr = \@evenDataHighPerf;
    $oddDataHighPerfPtr = \@oddDataHighPerf;
    $allDataHighPerfPtr = \@allDataHighPerf;
    $allUnsafeHighPerfPtr = \@allUnsafeHighPerf;
    $Gr3DataHighPerfPtr = \@Gr3DataHighPerf;
    $Gr5DataHighPerfPtr = \@Gr5DataHighPerf;
    $Gr9DataHighPerfPtr = \@Gr9DataHighPerf;

    $evenDataPerfPtr = \@evenDataPerf;
    $oddDataPerfPtr = \@oddDataPerf;
    $allDataPerfPtr = \@allDataPerf;
    $allUnsafePerfPtr = \@allUnsafePerf;
    $Gr3DataPerfPtr = \@Gr3DataPerf;
    $Gr5DataPerfPtr = \@Gr5DataPerf;
    $Gr9DataPerfPtr = \@Gr9DataPerf;

    $evenDataBalancePtr = \@evenDataBalance;
    $oddDataBalancePtr = \@oddDataBalance;
    $allDataBalancePtr = \@allDataBalance;
    $allUnsafeBalancePtr = \@allUnsafeBalance;
    $Gr3DataBalancePtr = \@Gr3DataBalance;
    $Gr5DataBalancePtr = \@Gr5DataBalance;
    $Gr9DataBalancePtr = \@Gr9DataBalance;

    $evenDataCapPtr = \@evenDataCap;
    $oddDataCapPtr = \@oddDataCap;
    $allDataCapPtr = \@allDataCap;
    $allUnsafeCapPtr = \@allUnsafeCap;
    $Gr3DataCapPtr = \@Gr3DataCap;
    $Gr5DataCapPtr = \@Gr5DataCap;
    $Gr9DataCapPtr = \@Gr9DataCap;

    $evenDataSataPtr = \@evenDataSata;
    $oddDataSataPtr = \@oddDataSata;
    $allDataSataPtr = \@allDataSata;
    $allUnsafeSataPtr = \@allUnsafeSata;
    $Gr3DataSataPtr = \@Gr3DataSata;
    $Gr5DataSataPtr = \@Gr5DataSata;
    $Gr9DataSataPtr = \@Gr9DataSata;

    #
    # Now deal with pointers that may be references to empty arrays.
    #
    # For the ISE volumes we will try to balance out the usage of the existing volumes.
    # We may want to change this later.  But for now we will reuse the existin method to not break previous products
    #
    
    # first the fibre ones

    if (scalar(@allData) == 0 ) 
    {
        if (scalar(@allDataSata) > 0)
        {
            $allDataPtr = \@allDataSata;
        }
        else
        {
        # Assume there are ISE drives and let that function handle erroring out.
        }
    }

    if (scalar(@evenData) == 0 )
    {
        if (scalar(@evenDataSata) > 0)
        {
            $evenDataPtr = \@evenDataSata;
        }
        else
        {
        # Assume there are ISE drives and let that function handle erroring out.
        }
    }

    if (scalar(@oddData) == 0 )
    {
        if (scalar(@oddDataSata) > 0)
        {
            $oddDataPtr = \@oddDataSata;
        }
        else
        {
        # Assume there are ISE drives and let that function handle erroring out.
        }
    }

    if ( $minpdisksflag == FALSE )
    {

        if (scalar(@allUnsafe) == 0 )
        {
            if (scalar(@allUnsafeSata) > 0)
            {
                $allUnsafePtr = \@allUnsafeSata;
            }
            else
            {
            # Assume there are ISE drives and let that function handle erroring out.
            }
        }


        if (scalar(@Gr3Data) == 0 )
        {
            if (scalar(@Gr3DataSata) > 0)
            {
                $Gr3DataPtr = \@Gr3DataSata;
            }
            else
            {
            # Assume there are ISE drives and let that function handle erroring out.
            }
        }

        if ( scalar(@allDataSata) >= 6 ) # This check is added as part of 750 changes, this may go later. 
        {
        
            if (scalar(@Gr5Data) == 0 )
            {
                if (scalar(@Gr5DataSata) > 0)
                {
                    $Gr5DataPtr = \@Gr5DataSata;
                }
                else
                {
                # Assume there are ISE drives and let that function handle erroring out.
                }
            }

            if (scalar(@Gr9Data) == 0 )
            {
                if (scalar(@Gr9DataSata) > 0)
                {
                    $Gr9DataPtr = \@Gr9DataSata;
                }
                else
                {
                # Assume there are ISE drives and let that function handle erroring out.
                }
            }
       }

    } # end of if $minpdisksflag

    # ISE Drive teir.  Try to mix up the groups if multiple drive types exist.

    if (scalar(@allData) == 0 )
    {
        if (scalar(@allDataHighPerf) > 0)
        {
            $allDataPtr = \@allDataHighPerf;
        }
        elsif (scalar(@allDataCap) > 0)
        {
            $allDataPtr = \@allDataCap;
        }      
        elsif (scalar(@allDataPerf) > 0)
        {
            $allDataPtr = \@allDataPerf;
        }    
        elsif (scalar(@allDataBalance) > 0)
        {
            $allDataPtr = \@allDataBalance;
        }       
        else
        {
            logInfo(" Not enough 'all data' drives ");
            return ERROR;
        }
    }

    if (scalar(@evenData) == 0 )
    {
        if (scalar(@evenDataBalance) > 0)
        {
            $evenDataPtr = \@evenDataBalance;
        }
        elsif (scalar(@evenDataPerf) > 0)
        {
            $evenDataPtr = \@evenDataPerf;
        }
        elsif (scalar(@evenDataHighPerf) > 0)
        {
            $evenDataPtr = \@evenDataHighPerf;
        }
        elsif (scalar(@evenDataCap) > 0)
        {
            $evenDataPtr = \@evenDataCap;
        }
        else
        {
            logInfo(" Not enough 'even data' drives ");
            return ERROR;
        }
    }

    if (scalar(@oddData) == 0 )
    {
        if (scalar(@oddDataBalance) > 0)
        {
            $oddDataPtr = \@oddDataBalance;
        }
        elsif (scalar(@oddDataPerf) > 0)
        {
            $oddDataPtr = \@oddDataPerf;
        }
        elsif (scalar(@oddDataHighPerf) > 0)
        {
            $oddDataPtr = \@oddDataHighPerf;
        }
        elsif (scalar(@oddDataCap) > 0)
        {
            $oddDataPtr = \@oddDataCap;
        }
        else
        {
            logInfo(" Not enough 'odd data' drives ");
            return ERROR;
        }
    }

    if ( $minpdisksflag == FALSE )
    {

        if (scalar(@allUnsafe) == 0 )
        {
            if (scalar(@allUnsafeHighPerf) > 0)
            {
                $allUnsafePtr = \@allUnsafeHighPerf;
            }
            elsif (scalar(@allUnsafeCap) > 0)
            {
                $allUnsafePtr = \@allUnsafeCap;
            }      
            elsif (scalar(@allUnsafePerf) > 0)
            {
                $allUnsafePtr = \@allUnsafePerf;
            }    
            elsif (scalar(@allUnsafeBalance) > 0)
            {
                $allUnsafePtr = \@allUnsafeBalance;
            }  
            else
            {
                logInfo(" Not enough 'all Unsafe' drives ");
                return ERROR;
            }
        }


        if (scalar(@Gr3Data) == 0 )
        {
            if (scalar(@Gr3DataHighPerf) > 0)
            {
                $Gr3DataPtr = \@Gr3DataHighPerf;
            }
            elsif (scalar(@Gr3DataPerf) > 0)
            {
                $Gr3DataPtr = \@Gr3DataPerf;
            }    
            elsif (scalar(@Gr3DataBalance) > 0)
            {
                $Gr3DataPtr = \@Gr3DataBalance;
            }
            elsif (scalar(@Gr3DataCap) > 0)
            {
                $Gr3DataPtr = \@Gr3DataCap;
            }      
            else
            {
                logInfo(" Not enough 'group 3 data' drives ");
                return ERROR;
            }
        }
        if (scalar(@Gr9Data) == 0 )
        {
            if (scalar(@Gr9DataHighPerf) > 0)
            {
                $Gr9DataPtr = \@Gr9DataHighPerf;
            }
            elsif (scalar(@Gr9DataPerf) > 0)
            {
                $Gr9DataPtr = \@Gr9DataPerf;
            }    
            elsif (scalar(@Gr9DataBalance) > 0)
            {
                $Gr9DataPtr = \@Gr9DataBalance;
            }
            elsif (scalar(@Gr9DataCap) > 0)
            {
                $Gr9DataPtr = \@Gr9DataCap;
            }      
            else
            {
                logInfo(" Not enough 'group 9 data' drives ");
                return ERROR;
            }
        }        
       }

    
     # now the sata ones

    if (scalar(@allDataSata) == 0 )
    {
        if (scalar(@allData) > 0)
        {
            $allDataSataPtr = \@allData;
        }
        else
        {
        # Assume there are ISE drives and let that function handle erroring out.
        }
    }

    if (scalar(@evenDataSata) == 0 )
    {
        if (scalar(@evenData) > 0)
        {
            $evenDataSataPtr = \@evenData;
        }
        else
        {
        # Assume there are ISE drives and let that function handle erroring out.
        }
    }



    if (scalar(@oddDataSata) == 0 )
    {
        if (scalar(@oddData) > 0)
        {
            $oddDataSataPtr = \@oddData;
        }
        else
        {
        # Assume there are ISE drives and let that function handle erroring out.
        }
    }

    if ( $minpdisksflag == FALSE )
    {
        if (scalar(@allUnsafeSata) == 0 )
        {
            if (scalar(@allUnsafe) > 0)
            {
                $allUnsafeSataPtr = \@allUnsafe;
            }
            else
            {
            # Assume there are ISE drives and let that function handle erroring out.
            }
        }


        if (scalar(@Gr3DataSata) == 0 )
        {
            if (scalar(@Gr3Data) > 0)
            {
                $Gr3DataSataPtr = \@Gr3Data;
            }
            else
            {
            # Assume there are ISE drives and let that function handle erroring out.
            }
        }

        if ( scalar(@allData) >= 6 ) # This check is added as part of 750 changes, this may go later. 
        {
            if (scalar(@Gr5DataSata) == 0 )
            {
                if (scalar(@Gr5Data) > 0)
                {
                    $Gr5DataSataPtr = \@Gr5Data;
                }
                else
                {
                # Assume there are ISE drives and let that function handle erroring out.
                }
            }

            if (scalar(@Gr9DataSata) == 0 )
            {
                if (scalar(@Gr9Data) > 0)
                {
                    $Gr9DataSataPtr = \@Gr9Data;
                }
                else
                {
                # Assume there are ISE drives and let that function handle erroring out.
                }
            }
        } 
    } # end of if $minpdisksflag 

    #
    # Now all the pointers point to valid arrays and we should be able to make
    # vdisks at will.
    #
    # All the following use the pointers to the arrays so that we don't worry
    # about empty arrays (since the pointers all point to full ones).
    #

    ################ Disk groups are defined #######################################





    # make the vdisks according to strategy (CreateSingleVdisk)

    #
    # This is done by making arrays for the vdisk's name, size and raid type
    # and then walking the arrays to create the individual vdisks. The
    # content of the arrays is based upon the strategy passed in.
    #

    # We can either set up arrays and create vdisks at the end, or create them on the fly
    # This variable controls the use of the arrays after the if statements. We default to
    # false and set it true when we want the arrays to be used.

    $UseArrays = FALSE;

    debug("in makevdisks  $strategy");

    # For Emprise 7000 for to use STRATEGY 24.  Need to change this to handle multiples.  This should be okay for the first release.
     if ( $productID == 7000 )
     {
      $strategy = 24;
          debug("in makevdisks  $strategy - replaced for 7000 product");
              logInfo("     MakeVdisks: strategy # $strategy.  Replaced for 7000 Product");
     }

    if ( $strategy == 1 )
    {
        ###########################################
        # 1 - 20 drives, growing size  All RAID 5
        ###########################################
        $UseArrays = TRUE;

        @VDMName = (    "1R5",  "2R5",  "3R5",  "4R5",
                    "5R5",  "6R5",  "7R5",  "8R5",
                    "9R5",  "10R5", "11R5", "12R5",
                    "13R5", "14R5", "15R5", "16R5",
                    "17R5", "18R5", "19R5", "20R5" );

        @Capacity = ( 1024, 1024, 1500, 1500,
                      2000, 2100, 2200, 2300,
                      3000, 3300, 3500, 3750,
                      4000, 4100, 4500, 4700,
                      5000, 5200, 5500, 5700 );

        @Type = ( RAID_5,  RAID_5,  RAID_5,  RAID_5,
                  RAID_5,  RAID_5,  RAID_5,  RAID_5,
                  RAID_5,  RAID_5,  RAID_5,  RAID_5,
                  RAID_5,  RAID_5,  RAID_5,  RAID_5,
                  RAID_5,  RAID_5,  RAID_5,  RAID_5 );

        @Stripe = ( 512,  0,   0,   8,
                     16, 32,  64, 512,
                     16, 32,  64, 512,
                      8, 16,  32,  64,
                      8, 16,  32,  64  );

        @Depth =  ( 4,    scalar(@$allDataPtr),     scalar(@$Gr9DataPtr),   3,
                    3,    2,    2,     4,
                    3,    2,    2,     4,
                    0,    0,    0,     0,
                    0,    0,    0,     0   );

        @Parity = ( 0, 0, 0, 0,
                    0, 0, 0, 0,
                    0, 0, 0, 0,
                    3, 3, 3, 3,
                    9, 9, 0, 0   );

        @Disks =  ( $allDataPtr,   $allDataPtr,    $Gr9DataPtr,   $oddDataPtr,
                    $allDataPtr,   $Gr9DataPtr,    $allDataPtr,   $allDataPtr,
                    $allDataPtr,   $Gr9DataPtr,    $allDataPtr,   $allDataPtr,
                    $Gr5DataPtr,   $evenDataPtr,   $evenDataPtr,  $Gr9DataPtr,
                    $oddDataPtr,   $allDataPtr,    $allDataPtr,   $allDataPtr          );



    }
    elsif ( $strategy == 2 )
    {
        ####################
        # 2 - Neal's group  for the CLI
        # used by good_path.pl
        ####################
        $UseArrays = TRUE;

        debug("strategy 2 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15"   );

        # my @VDSName = (   "PFS",   "VDS01", "VDS02", "VDS03", "VDS04",
        #                   "VDS05", "VDS06", "VDS07", "VDS09", "VDS10",
        #                   "VDS11", "VDS12", "VDS13", "VDS14", "VDS15" );

        @Capacity = (   100,  105,  110,  115,  120,
                        125,  130,  135,  140,  145,
                        150,  155,  160,  165,  170,
                        180 );

        @Type = (  RAID_10,  RAID_1,  RAID_1,   RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_5,  RAID_5,
                   RAID_5,   RAID_5,  RAID_5,   RAID_5,  RAID_0,
                   RAID_0  );

        @Stripe = ( 512,  0,   0,   8,  16,
                     32, 64, 512,   8,  16,
                     32, 64,   8,  16,  32,
                     64  );

        @Depth =  ( 4,    scalar(@$Gr3DataPtr),     scalar(@$Gr5DataPtr),   3,    3,
                    2,    2,     4,   0,    0,
                    0,    0,     0,   0,    0,
                    0   );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 5, 5, 0,
                    0   );

        @Disks =  ( $allDataPtr,    $Gr3DataPtr,       $Gr5DataPtr,     $Gr9DataPtr,     $allDataPtr,
                    $oddDataPtr,    $allDataPtr,       $allDataPtr,      $Gr3DataPtr,     $Gr3DataPtr,
                    $Gr3DataPtr,    $evenDataPtr,      $Gr9DataPtr,      $allDataPtr,     $allUnsafePtr,
                    $allUnsafePtr   );

    }
    elsif ( $strategy == 3 )
    {
        ###########################################
        # 3 - 20 drives, growing size  Mixed RAID
        ###########################################
        $UseArrays = TRUE;

        @VDMName = ("1R10", "2R10", "3R10", "4R10",
                    "1R5",  "2R5",  "3R5",  "4R5",
                    "1R0",  "2R0",  "3R0",  "4R0",
                    "1R1",  "2R1",  "3R1",  "4R1",
                    "5R5",  "6R5",  "7R5",  "8R5" );

        @Capacity = ( 1000, 1500, 2000, 2500,
                     3000, 3500, 4000, 4500,
                     5000, 5500, 6000, 6500,
                     7000, 7500, 8000, 8500,
                     9000, 9500, 30000, 31500 );

        @Type = ( RAID_10,  RAID_10, RAID_10, RAID_10,
                   RAID_5,  RAID_5,  RAID_5,  RAID_5,
                   RAID_0,  RAID_0,  RAID_0,  RAID_0,
                   RAID_1,  RAID_1,  RAID_1,  RAID_1,
                   RAID_5,  RAID_5,  RAID_5,  RAID_5 );

        @Stripe = (  512,  0,   0,   8,
                      16, 32,  64, 512,
                      16, 32,  64, 512,
                       8, 16,  32,  64,
                       8, 16,  32,  64  );

        @Depth =  ( 4,    scalar(@$allDataPtr),     scalar(@$evenDataPtr),   3,
                    3,    2,    2,     4,
                    3,    2,    2,     4,
                    0,    0,    0,     0,
                    0,    0,    0,     0   );

        @Parity = ( 0, 0, 0, 0,
                    0, 0, 0, 0,
                    0, 0, 0, 0,
                    3, 3, 3, 3,
                    9, 9, 0, 0   );

        @Disks =  ( $allDataPtr,   $allDataPtr,   $evenDataPtr,  $Gr9DataPtr,
                    $allDataPtr,   $evenDataPtr,  $allDataPtr,   $allDataPtr,
                    $allUnsafePtr, $allUnsafePtr, $allUnsafePtr, $allUnsafePtr,
                    $Gr3DataPtr,   $Gr5DataPtr,   $Gr5DataPtr,   $evenDataPtr,
                    $Gr9DataPtr,   $allDataPtr,   $allDataPtr,   $allDataPtr          );
    }
    elsif ( $strategy == 4 )
    {
        ###########################################
        # 4 - 20 drives, growing size All RAID 10
        ###########################################
        $UseArrays = TRUE;

        @VDMName = ("1R10",  "2R10",  "3R10",  "4R10",
                    "5R10",  "6R10",  "7R10",  "8R10",
                    "9R10",  "0R10",  "11R10", "12R10",
                    "13R10", "14R10", "15R10", "16R10",
                    "17R10", "18R10", "19R10", "20R10" );


        @Capacity = ( 1000, 1500, 2000,  2500,
                     3000, 3500, 4000,  4500,
                     5000, 5500, 6000,  6500,
                     7000, 7500, 8000,  8500,
                     9000, 9500, 30000, 31000  );

        @Type = ( RAID_10,  RAID_10,  RAID_10,  RAID_10,
                  RAID_10,  RAID_10,  RAID_10,  RAID_10,
                  RAID_10,  RAID_10,  RAID_10,  RAID_10,
                  RAID_10,  RAID_10,  RAID_10,  RAID_10,
                  RAID_10,  RAID_10,  RAID_10,  RAID_10 );

        @Stripe = ( 512,  0,   0,   8,
                     16, 32,  64, 512,
                     16, 32,  64, 512,
                      8, 16,  32,  64,
                      8, 16,  32,  64  );

        @Depth =  ( 4,    scalar(@$allDataPtr),     scalar(@$oddDataPtr),   3,
                    3,    2,    2,     4,
                    3,    2,    2,     4,
                    0,    0,    0,     0,
                    0,    0,    0,     0   );

        @Parity = ( 0, 0, 0, 0,
                    0, 0, 0, 0,
                    0, 0, 0, 0,
                    3, 3, 3, 3,
                    9, 9, 0, 0   );

        @Disks =  ( $allDataPtr,   $allDataPtr,   $oddDataPtr,  $Gr3DataPtr,
                    $allDataPtr,   $evenDataPtr,  $allDataPtr,  $allDataPtr,
                    $allDataPtr,   $oddDataPtr,   $allDataPtr,  $allDataPtr,
                    $Gr9DataPtr,   $Gr5DataPtr,   $Gr5DataPtr,  $evenDataPtr,
                    $Gr3DataPtr,   $allDataPtr,   $allDataPtr,  $allDataPtr    );
    }
    elsif ( $strategy == 5 )
    {
        ##########################################
        # 5 - 20 drives, growing size All RAID 1
        ##########################################
        $UseArrays = TRUE;

        @VDMName = ("1R1",  "2R1",  "3R1",  "4R1",
                    "5R1",  "6R1",  "7R1",  "8R1",
                    "9R1",  "0R1",  "11R1", "12R1",
                    "13R1", "14R1", "15R1", "16R1",
                    "17R1", "18R1", "19R1", "20R1" );

        @Capacity = ( 1000, 1500, 2000, 2500,
                     3000, 3500, 4000, 4500,
                     5000, 5500, 6000, 6500,
                     7000, 7500, 8000, 8500,
                     9000, 9500, 30000, 31000 );

        @Type = ( 1,  1,  1,  1,
                  1,  1,  1,  1,
                  1,  1,  1,  1,
                  1,  1,  1,  1,
                  1,  1,  1,  1 );

    }
    elsif ( $strategy == 6 )
    {
        ##########################################
        # 6 - RAID 1 drives
        ##########################################
        $UseArrays = TRUE;
            # parms: $controller, $name, $capacity_org, $rtype, $stripe, $depth, $parity, @physicalDisks
            #$ret = CreateSingleVdisk($controller, $VDMName[$r], $Capacity[$r], $Type[$r], 64, 0, 5, @All );

        @VDMName = ("1R1",  "2R1",  "3R1",  "4R1",
                    "5R1",  "6R1",  "7R1",  "8R1",
                    "9R1",  "0R1",  "11R1", "12R1",
                    "13R1", "14R1", "15R1", "16R1",
                    "17R1", "18R1", "19R1", "20R1" );

        @Capacity = ( 1000, 1500, 2000, 2500,
                     3000, 3500, 4000, 4500,
                     5000, 5500, 6000, 6500,
                     7000, 7500, 8000, 8500,
                     9000, 9500, 3000, 3100 );

        @Type = (  RAID_1,   RAID_1,   RAID_1,   RAID_1,
                   RAID_1,   RAID_1,   RAID_1,   RAID_1,
                   RAID_1,   RAID_1,   RAID_1,   RAID_1,
                   RAID_1,   RAID_1,   RAID_1,   RAID_1,
                   RAID_1,   RAID_1,   RAID_1,   RAID_1  );

        @Stripe = ( 512,  0,   0,   8,
                     16,  32,  64,  512,
                      8,  16,  32,  64,
                      8,  16,  32,  64,
                      8,  16,  32,  64  );

        @Depth =  ( 4,    scalar(@$allDataPtr),     scalar(@$oddDataPtr),   3,
                    3,    2,    2,     4,
                    0,    0,    0,     0,
                    0,    0,    0,     0,
                    0,    0,    0,     0   );

        @Parity = ( 0, 0, 0, 0,
                    0, 0, 0, 0,
                    0, 0, 0, 0,
                    3, 3, 3, 3,
                    9, 9, 0, 0   );

        @Disks =  ( $allDataPtr,   $allDataPtr,   $oddDataPtr,     $Gr3DataPtr,
                    $allDataPtr,   $evenDataPtr,  $allDataPtr,     $allDataPtr,
                    $allDataPtr,   $oddDataPtr,   $allDataPtr,     $allDataPtr,
                    $Gr9DataPtr,   $Gr5DataPtr,   $Gr5DataPtr,     $evenDataPtr,
                    $Gr5DataPtr,   $allDataPtr,   $allDataPtr,     $allDataPtr   );
    }
    elsif ( $strategy == 7 )
    {
        ###########################
        # 7 - a handful of vdisks
        ###########################
        $UseArrays = TRUE;

        @VDMName = ("1R10", "2R10", "3R10", "4R10",
                    "1R5",  "2R5",  "3R5",  "4R5" );

        @Capacity = ( 3000, 3500, 4000, 4500,
                      5000, 5500, 6000, 6500  );


        @Type = (  RAID_10,  RAID_10,  RAID_10,   RAID_10,
                   RAID_5,   RAID_5,   RAID_5,    RAID_5   );

        @Stripe = ( 512,  0,   0,   8,
                     32, 64, 64,   8  );

        @Depth =  ( 4,    2,     4,   2,
                    2,    2,     2,   0   );

        @Parity = ( 0, 0, 0, 0,
                    3, 5, 5, 3   );

        @Disks =  ( $allDataPtr,  $allDataPtr,    $evenDataPtr,      $Gr9DataPtr,
                    $oddDataPtr,  $allDataPtr,     $allDataPtr,      $Gr3DataPtr   );
    }
    elsif ( $strategy == 8 )
    {
        ###############################################################
        # 8 - even fewer vdisks for san links, two for one controller
        #
        # Note difference size and disk group from opt 9. Requires a
        # way to make sure the 'groups' are on physically different
        # drives on the 2 controllers.
        ###############################################################
        $UseArrays = TRUE;

        @VDMName = ("1R10", "2R10" );

        @Capacity = ( 1000, 2000 );

        @Type = (  RAID_10,  RAID_10   );

        @Stripe = ( 512,  64 );

        @Depth =  ( 2, 2 );

        @Parity = ( 0, 0 );

        @Disks =  ( $evenDataPtr,  $evenDataPtr  );
    }
    elsif ( $strategy == 9 )
    {
        ###############################################################
        # 8 - even fewer vdisks for san links, two for 2nd controller
        #
        # Note difference size and disk group from opt 8. Requires a
        # way to make sure the 'groups' are on physicall different
        # drives on the 2 controllers.
        ###############################################################

        $UseArrays = TRUE;

        @VDMName = ("1R10", "2R10" );

        @Capacity = ( 3000, 4000 );

        @Type = (  RAID_10,  RAID_10   );

        @Stripe = ( 512,  64 );

        @Depth =  ( 2, 2 );

        @Parity = ( 0, 0 );

        @Disks =  ( $oddDataPtr,  $oddDataPtr  );
    }
    elsif ( $strategy == 10 )
    {
        ####################
        # 10 - More vdisks than 2
        ####################
        $UseArrays = TRUE;

        debug("strategy 10selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );

        # my @VDSName = (   "PFS",   "VDS01", "VDS02", "VDS03", "VDS04",
        #                   "VDS05", "VDS06", "VDS07", "VDS09", "VDS10",
        #                   "VDS11", "VDS12", "VDS13", "VDS14", "VDS15" );

        @Capacity = (   5000,  1000,  2000,  3000,  4000,
                        5000,  6000,  7000,  8000,  9000,
                       10000, 11000, 12000, 13000, 14000,
                        5000,  6000,  7000,  8000,  9000,
                       10000, 11000, 12000, 13000, 14000,
                       15000 );

        @Type = (  RAID_10,  RAID_1,  RAID_1,   RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_5,  RAID_5,
                   RAID_5,   RAID_5,  RAID_5,   RAID_5,  RAID_0,
                   RAID_10,  RAID_10, RAID_10,  RAID_5,  RAID_5,
                   RAID_5,   RAID_5,  RAID_5,   RAID_5,  RAID_0,
                   RAID_0  );

        @Stripe = ( 512,  0,   0,   8,  16,
                     32, 64, 512,   8,  16,
                     32, 64,   8,  16,  32,
                     32, 64, 512,   8,  16,
                     32, 64,   8,  16,  32,
                     64  );

        @Depth =  ( 4,    scalar(@$allDataPtr),     scalar(@$oddDataPtr),   3,    3,
                    2,    2,     4,   0,    0,
                    0,    0,     0,   0,    0,
                    2,    2,     4,   0,    0,
                    0,    0,     0,   0,    0,
                    0   );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0   );

        @Disks =  ( $allDataPtr,    $allDataPtr,     $oddDataPtr,    $Gr9DataPtr,     $allDataPtr,
                    $evenDataPtr,   $allDataPtr,     $allDataPtr,    $Gr3DataPtr,     $Gr5DataPtr,
                    $Gr5DataPtr,    $oddDataPtr,     $Gr9DataPtr,    $allDataPtr,     $allUnsafePtr,
                    $evenDataPtr,   $allDataPtr,     $allDataPtr,    $Gr3DataPtr,     $Gr5DataPtr,
                    $Gr5DataPtr,    $oddDataPtr,     $Gr9DataPtr,    $allDataPtr,     $allUnsafePtr,
                    $allUnsafePtr   );

    }
    elsif ( $strategy == 11 )
    {
        ###########################
        # 11 - a handful of small vdisks
        ###########################
        $UseArrays = TRUE;

        @VDMName = ("1R10", "2R10", "3R10", "4R10",
                    "1R5",  "2R5",  "3R5",  "4R5" );

        @Capacity = ( 500, 500, 500, 500,
                      500, 500, 500, 500 );
                      #, .3, .3  );


        @Type = (  RAID_10,  RAID_10,  RAID_10,   RAID_10,
                   RAID_5,   RAID_5,   RAID_5,    RAID_5   );

        @Stripe = ( 512,  0,   0,   8,
                     32, 64, 512,   8  );

        @Depth =  ( 4,    scalar(@$allDataPtr),     scalar(@$allDataPtr),   3,
                    2,    2,     4,   0   );

        @Parity = ( 0, 0, 0, 0,
                    0, 0, 0, 3   );

        @Disks =  ( $allDataPtr,  $allDataPtr,  $allDataPtr,  $allDataPtr,
                    $allDataPtr,  $allDataPtr,  $allDataPtr,  $allDataPtr   );
    }

    elsif ( $strategy == 12 )
    {
        ###################################
        # 12  3 vdisks for the defrag test
        ###################################
        $UseArrays = TRUE;

        @VDMName = ( "2R5",  "3R5",  "4R5" );

        @Capacity = ( 1000, 1050, 1100);


        @Type = (    RAID_10,   RAID_10,    RAID_10   );

        @Stripe = (  64, 512,   8  );

        @Depth =  (   2,     4,   0   );

        @Parity = (  0, 0, 3   );

        @Disks =  (   $allDataPtr,  $allDataPtr,  $allDataPtr   );
    }
    elsif ( $strategy == 13 )
    {
        ###############################################################
        # 13 - even fewer vdisks for san links, two for one controller
        #
        # Note difference size and disk group from opt 9. Requires a
        # way to make sure the 'groups' are on physically different
        # drives on the 2 controllers.
        ###############################################################
        $UseArrays = TRUE;

        @VDMName = ("1R10", "2R10" );

        @Capacity = ( 1000, 2000 );

        @Type = (  RAID_10,  RAID_10   );

        @Stripe = ( 512,  64 );

        @Depth =  ( 2, 2 );

        @Parity = ( 0, 0 );

        @Disks =  ( $allDataPtr,  $allDataPtr  );
    }
    elsif ( $strategy == 14 )
    {
        ###############################################################
        # 14 - even fewer vdisks for san links, two for one controller
        #
        # Note difference size and disk group from opt 9. Requires a
        # way to make sure the 'groups' are on physically different
        # drives on the 2 controllers.
        ###############################################################
        my @tmpList = GetVdiskList( $controller );

        my $adder;

        if ( $tmpList[0] == INVALID )
        {
            $adder = 0;
        }
        else
        {
            $adder =  scalar(@tmpList);
        }

        $UseArrays = TRUE;

        @VDMName = ("1R10", "2R10" );

        $Capacity[0] = 500 * (1 + $adder);
        $Capacity[1] = 500 * (2 + $adder);

        debug("@Capacity");

        @Type = (  RAID_10,  RAID_10   );

        @Stripe = ( 512,  64 );

        @Depth =  ( 2, 2 );

        @Parity = ( 0, 0 );

        @Disks =  ( $allDataPtr,  $allDataPtr  );
    }
    elsif ( $strategy == 15 )
    {
        ###############################################################
        # 15 - even fewer vdisks for san links, two for one controller
        #
        # Note difference size and disk group from opt 9. Requires a
        # way to make sure the 'groups' are on physically different
        # drives on the 2 controllers.
        ###############################################################
        my @tmpList = GetVdiskList( $controller );

        my $adder;

        if ( $tmpList[0] == INVALID )
        {
            $adder = 0;
        }
        else
        {
            $adder =  scalar(@tmpList);
        }

        $UseArrays = TRUE;

        @VDMName = ("1R10", "2R10" );

        $Capacity[0] = 50 * (1 + $adder);
        $Capacity[1] = 50 * (2 + $adder);

        debug("@Capacity");

        @Type = (  RAID_10,  RAID_10   );

        @Stripe = ( 512,  64 );

        @Depth =  ( 2, 2 );

        @Parity = ( 0, 0 );

        @Disks =  ( $allDataPtr,  $allDataPtr  );
    }

    elsif ( $strategy == 18 )
    {
        ###############################################################
        # 18 - even fewer vdisks for san links, two for one controller
        #
        # Note difference size and disk group from opt 9. Requires a
        # way to make sure the 'groups' are on physicall different
        # drives on the 2 controllers.
        ###############################################################
        $UseArrays = TRUE;

        @VDMName = ("1R5", "2R5" );

        @Capacity = ( 1000, 2000 );

        @Type = (  RAID_5,  RAID_5   );

        @Stripe = ( 512,  64 );

        @Depth =  ( 2, 2 );

        @Parity = ( 0, 0 );

        @Disks =  ( $Gr3DataPtr,  $Gr3DataPtr  );
    }
    elsif ( $strategy == 19 )
    {
        ###############################################################
        # 19 - even fewer vdisks for san links, two for 2nd controller
        #
        # Note difference size and disk group from opt 8. Requires a
        # way to make sure the 'groups' are on physicall different
        # drives on the 2 controllers.
        ###############################################################

        $UseArrays = TRUE;

        @VDMName = ("1R5", "2R5" );

        @Capacity = ( 3000, 4000 );

        @Type = (  RAID_5,  RAID_5   );

        @Stripe = ( 512,  64 );

        @Depth =  ( 2, 2 );

        @Parity = ( 0, 0 );

        @Disks =  ( $Gr3DataPtr,  $Gr3DataPtr  );
    }
    elsif ( $strategy == 20 )
    {
        ###########################
        # 20 - a handful of small vdisks
        ###########################
        $UseArrays = TRUE;

        @VDMName = ("1R10", "2R10", "3R10", "4R10",
                    "5R10", "6R10", "7R10", "8R10",
                    "9R10", "9R10", "10R10", "11R10" );

        @Capacity = ( 1000, 1050, 1100, 1150,
                      1200, 1250, 1025, 1075,
                      1125, 1175, 1225, 1275 );


        @Type = (  RAID_10,  RAID_10,  RAID_10,   RAID_10,
                   RAID_10,  RAID_10,  RAID_10,   RAID_10,
                   RAID_10,  RAID_10,  RAID_10,   RAID_10   );

        @Stripe = ( 512,  0,   0,  8,
                     64, 64,  64, 64,
                     32, 64, 512,  8  );

        @Depth =  ( 2, 2, 2, 2,
                    2, 2, 2, 2,
                    2, 2, 2, 2  );

        @Parity = ( 0, 0, 0, 0,
                    0, 0, 0, 0,
                    0, 0, 0, 0   );

        @Disks =  ( $allDataPtr,  $allDataPtr,  $allDataPtr,  $allDataPtr,
                    $allDataPtr,  $allDataPtr,  $allDataPtr,  $allDataPtr,
                    $allDataPtr,  $allDataPtr,  $allDataPtr,  $allDataPtr   );
    }
    elsif ( $strategy == 21 )
    {
        ###########################
        # 21 - a handful of small vdisks    all RAID 0
        ###########################
        $UseArrays = TRUE;

        @VDMName = ("1R0", "2R0", "3R0", "4R0",
                    "5R0", "6R0", "7R0", "8R0",
                    "9R0", "9R0", "10R0", "11R0" );

        @Capacity = ( 1000, 1050, 1100, 1150,
                      1200, 1250, 1025, 1075,
                      1125, 1175, 1225, 1275 );


        @Type = (  RAID_0,  RAID_0,  RAID_0,   RAID_0,
                   RAID_0,  RAID_0,  RAID_0,   RAID_0,
                   RAID_0,  RAID_0,  RAID_0,   RAID_0   );

        @Stripe = ( 512,  0,   0,  8,
                     64, 64,  64, 64,
                     32, 64, 512,  8  );

        @Depth =  ( 2, 2, 2, 2,
                    2, 2, 2, 2,
                    2, 2, 2, 2  );

        @Parity = ( 0, 0, 0, 0,
                    0, 0, 0, 0,
                    0, 0, 0, 0   );

        @Disks =  ( $allUnsafePtr,  $allUnsafePtr,  $allUnsafePtr,  $allUnsafePtr,
                    $allUnsafePtr,  $allUnsafePtr,  $allUnsafePtr,  $allUnsafePtr,
                    $allUnsafePtr,  $allUnsafePtr,  $allUnsafePtr,  $allUnsafePtr   );
    }
    elsif ( $strategy == 22 )
    {
        ####################
        # 22 - More vdisks than 2
        ####################
        $UseArrays = TRUE;

        debug("strategy 22 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (   1500,   750,  850,  950, 1400,
                        1100,  1200, 1300, 1400, 1500,
                        1600,  1700, 1800, 1900, 2000,
                        2100,  2200, 2300, 2044, 2500,
                        2600,   900,  800,  700,  600,
                        500 );

        @Type = (  RAID_10,  RAID_1,  RAID_1,   RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_0,  RAID_0,
                   RAID_1,   RAID_0,  RAID_1,   RAID_0,  RAID_0,
                   RAID_10,  RAID_10, RAID_10,  RAID_1,  RAID_10,
                   RAID_1,   RAID_0,  RAID_1,   RAID_0,  RAID_10,
                   RAID_0  );

        @Stripe = ( 512,  0,   0,   8,  16,
                     32, 64, 512,   8,  16,
                     32, 64,   8,  16,  32,
                     32, 64, 512,   8,  16,
                     32, 64,   8,  16,  32,
                     64  );

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   0,    0,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    2,
                    0   );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0   );

        @Disks =  ( $allDataPtr,     $allDataPtr,       $oddDataPtr,    $Gr9DataPtr,     $allDataPtr,
                    $evenDataPtr,    $allDataPtr,       $allDataPtr,    $allUnsafePtr,   $allUnsafePtr,
                    $Gr5DataPtr,     $allUnsafePtr,     $Gr9DataPtr,    $allUnsafePtr,   $allUnsafePtr,
                    $evenDataPtr,    $allDataPtr,       $allDataPtr,    $Gr3DataPtr,     $Gr5DataPtr,
                    $Gr5DataPtr,     $allUnsafePtr,     $Gr9DataPtr,    $allUnsafePtr,   $Gr5DataPtr,
                    $allUnsafePtr   );

    }
    elsif ( $strategy == 23 )
    {
        ####################
        # 23 - More vdisks than 2
        ####################
        $UseArrays = TRUE;

        debug("strategy 23 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (   1500,   750,  850,  950, 1400,
                        1100,  1200, 1300, 1400, 1500,
                        1600,  1700, 1800, 1900, 2000,
                        2100,  2200, 2300, 2044, 2500,
                        2600,   900,  800,  700,  600,
                        500 );

        @Type = (  RAID_10,  RAID_1,  RAID_1,   RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_0,  RAID_0,
                   RAID_1,   RAID_0,  RAID_1,   RAID_0,  RAID_0,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10  );

        @Stripe = ( 512,  0,   0,   8,  16,
                     32, 64, 512,   8,  16,
                     32, 64,   8,  16,  32,
                     32, 64, 512,   8,  16,
                     32, 64,   8,  16,  32,
                     64  );

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   0,    0,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    2,
                    0   );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0   );

        @Disks =  ( $allDataPtr,      $allDataPtr,     $evenDataPtr,   $Gr3DataPtr,    $allDataPtr,
                    $evenDataPtr,     $allDataPtr,     $allDataPtr,    $allUnsafePtr,  $allUnsafePtr,
                    $Gr3DataPtr,      $allUnsafePtr,   $Gr5DataPtr,    $allUnsafePtr,  $allUnsafePtr,
                    $oddDataPtr,      $evenDataPtr,    $oddDataPtr,    $evenDataPtr,   $oddDataPtr,
                    $evenDataPtr,     $oddDataPtr,     $evenDataPtr,   $oddDataPtr,    $evenDataPtr,
                    $oddDataPtr   );

    }
    elsif ( $strategy == 24 )
    {
        ####################
        # 24 - More vdisks than 2
        # no raid 1
        ####################
        $UseArrays = TRUE;

        debug("strategy 24 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (    5250,   7500,  8500,  9500,  4000,
                         1000,   2000,  3000,  4000,  5000,
                         6000,   7000,  8000,  9000, 10000,
                        11000,  12000, 13000, 10440, 15000,
                        16000,   9750,  8750,  7750,  6750,
                        5750 );

        @Type = (  RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_0,  RAID_0,
                   RAID_10,  RAID_0,  RAID_10,  RAID_0,  RAID_0,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10  );

        @Stripe = ( 512,  0,   0,   0,  0,
                     128, 128, 128,   0,  0,
                     128, 128, 128,   0,  0,
                     128, 128, 128,   0,  0,
                     128, 128, 128,   0,  0,
                     512  );

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   0,    0,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    0   );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0   );

        @Disks =  ( $allDataPtr,    $allDataPtr,    $allDataPtr,   $allDataPtr,    $allDataPtr,
                    $allDataPtr,    $allDataPtr,    $allDataPtr,   $allUnsafePtr,  $allUnsafePtr,
                    $allDataPtr,    $allUnsafePtr,  $allDataPtr,   $allUnsafePtr,  $allUnsafePtr,
                    $oddDataPtr,    $evenDataPtr,   $oddDataPtr,   $evenDataPtr,   $oddDataPtr,
                    $evenDataPtr,   $oddDataPtr,    $evenDataPtr,  $oddDataPtr,    $evenDataPtr,
                    $oddDataPtr   );

    }
    elsif ( $strategy == 25 )
    {
        ####################
        # 25 - More vdisks than 2
        # this one has the RAID_1 vdisks on exactly 2 data disks
        ####################
        $UseArrays = TRUE;

        debug("strategy 25 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (    525,   750,  850,  950,  400,
                         100,   200,  300,  400,  500,
                         600,   700,  800,  900, 1000,
                        1100,  1200, 1300, 1044, 1500,
                        1600,   975,  875,  775,  675,
                        575 );

        @Type = (  RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_1,  RAID_1,
                   RAID_10,  RAID_1,  RAID_10,  RAID_1,  RAID_1,
                   RAID_0,   RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10  );

        @Stripe = ( 512,  0,   0,   8,  16,
                     32, 64, 512,   8,  16,
                     32, 64,   8,  16,  32,
                     32, 64, 512,   8,  16,
                     32, 64,   8,  16,  32,
                     64  );

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    2   );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0   );

        @Disks =  ( $allDataPtr,     $allDataPtr,    $evenDataPtr,   $Gr9DataPtr,    $allDataPtr,
                    $allDataPtr,     $allDataPtr,    $allDataPtr,    $Gr3DataPtr,    $Gr5DataPtr,
                    $Gr5DataPtr,     $Gr3DataPtr,    $Gr9DataPtr,    $Gr3DataPtr,    $Gr5DataPtr,
                    $allUnsafePtr,   $evenDataPtr,   $oddDataPtr,    $evenDataPtr,   $oddDataPtr,
                    $evenDataPtr,    $oddDataPtr,    $evenDataPtr,   $oddDataPtr,    $evenDataPtr,
                    $oddDataPtr   );

    }
    elsif ( $strategy == 26 )
    {
        ####################
        # 24 - More vdisks than 2
        # no raid 1
        ####################
        $UseArrays = TRUE;

        debug("strategy 26 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (    50,   52,  54,  56,  58,
                         60,   62,  64,  66,  68,
                         70,   72,  74,  76, 78,
                        80,  82, 84, 86, 88,
                        90,   92,  94,  96,  98,
                        100 );

        @Type = (  RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_0,  RAID_0,
                   RAID_10,  RAID_0,  RAID_10,  RAID_0,  RAID_0,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10  );

        @Stripe = ( 512,  0,   0,   512,  128,
                     128, 128, 512,   512,  128,
                     128, 128,   512,  128,  128,
                     128, 128, 512,   512,  128,
                     128, 128,   512,  128,  128,
                     128  );

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   0,    0,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    2,
                    0   );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0   );

        @Disks =  ( $allDataSataPtr,    $allDataPtr,     $oddDataSataPtr,    $Gr9DataPtr,      $allDataPtr,
                    $Gr9DataSataPtr,    $allDataPtr,     $allDataSataPtr,    $allUnsafePtr,    $allUnsafePtr,
                    $Gr5DataSataPtr,    $allUnsafePtr,   $Gr9DataSataPtr,    $allUnsafePtr,    $allUnsafePtr,
                    $oddDataSataPtr,    $evenDataPtr,    $oddDataSataPtr,    $evenDataPtr,     $oddDataPtr,
                    $evenDataSataPtr,   $oddDataPtr,     $evenDataSataPtr,   $oddDataPtr,      $evenDataPtr,
                    $oddDataSataPtr   );

    }

    elsif ( $strategy == 27 )
    {
        ####################
        # 24 - More vdisks than 2
        # no raid 1
        ####################
        $UseArrays = TRUE;

        debug("strategy 27 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (    50,   52,  54,  56,  58,
                         60,   62,  64,  66,  68,
                         70,   72,  74,  76, 78,
                        80,  82, 84, 86, 88,
                        90,   92,  94,  96,  98,
                        100 );

        @Type = (  RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10,  RAID_10,
                   RAID_10,  RAID_0,  RAID_10,  RAID_0,  RAID_0,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10  );

        @Stripe = ( 512,  512,   512,   512,  512,
                     512, 512, 512,   512,  512 );

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    2,
                    0   );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0,
                    3, 3, 9, 9, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0   );

        @Disks =  ( $allDataSataPtr,     $allDataPtr,    $allDataSataPtr,   $allDataPtr,     $allDataPtr,
                    $allDataSataPtr,     $allDataPtr,    $allDataSataPtr,   $allDataPtr,     $allDataPtr,
                    $Gr5DataSataPtr,     $allUnsafePtr,  $Gr9DataSataPtr,   $allUnsafePtr,   $allUnsafePtr,
                    $oddDataSataPtr,     $evenDataPtr,   $oddDataSataPtr,   $evenDataPtr,    $oddDataPtr,
                    $evenDataSataPtr,    $oddDataPtr,    $evenDataSataPtr,  $oddDataPtr,     $evenDataPtr,
                    $oddDataSataPtr   );

    }
    elsif ( $strategy == 28 )
    {
        ####################
        # 24 - More vdisks than 2
        # no raid 1
        ####################
        $UseArrays = TRUE;

        debug("strategy 28 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (    50,   52,  54,  56,  58,
                         60,   62,  64,  66,  68,
                         70,   72,  74,  76, 78,
                        80,  82, 84, 86, 88,
                        90,   92,  94,  96,  98,
                        100 );

        @Type = (  RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10,  RAID_10,
                   RAID_10,  RAID_10,  RAID_10,  RAID_10,  RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10  );

        @Stripe = ( 512,  512,   512,   512,  512,
                     512, 512, 512,   512,  512 ,
                     512, 512, 512,   512,  512 ,
                     512, 512, 512,   512,  512 ,
                     512, 512, 512,   512,  512 ,
                     512);

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    2,
                    0   );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0,
                    3, 3, 9, 9, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0   );

        @Disks =  ( $oddDataSataPtr,        $evenDataPtr,      $oddDataSataPtr,     $evenDataPtr,   $oddDataPtr,
                    $evenDataSataPtr,       $oddDataPtr,       $evenDataSataPtr,    $oddDataPtr,    $evenDataPtr,
                    $oddDataSataPtr,        $evenDataPtr,      $oddDataSataPtr,     $evenDataPtr,   $oddDataPtr,
                    $evenDataSataPtr,       $oddDataPtr,       $evenDataSataPtr,    $oddDataPtr,    $evenDataPtr,
                    $oddDataSataPtr,        $evenDataPtr,      $oddDataSataPtr,     $evenDataPtr,   $oddDataPtr,
                    $evenDataSataPtr   );

    }
    elsif ( $strategy == 29 )
    {
        ####################
        # 24 - More vdisks than 2
        # no raid 1
        ####################
        $UseArrays = TRUE;

        debug("strategy 29 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (    50,   52,  54,  56,  58,
                         60,   62,  64,  66,  68,
                         70,   72,  74,  76, 78,
                        80,  82, 84, 86, 88,
                        90,   92,  94,  96,  98,
                        100 );

        @Type = (  RAID_1,  RAID_1, RAID_1,  RAID_1, RAID_1,
                   RAID_1,  RAID_1, RAID_1,  RAID_1, RAID_1,
                   RAID_1,  RAID_1, RAID_1,  RAID_1, RAID_1,
                   RAID_1,  RAID_1, RAID_1,  RAID_1, RAID_1,
                   RAID_1,  RAID_1, RAID_1,  RAID_1, RAID_1,
                   RAID_1  );

        @Stripe = ( 512,  512,   512,   512,  512,
                     512, 512, 512,   512,  512 ,
                     512, 512, 512,   512,  512 ,
                     512, 512, 512,   512,  512 ,
                     512, 512, 512,   512,  512 ,
                     512);

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    2,
                    0   );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0,
                    3, 3, 9, 9, 0,
                    0, 0, 0, 3, 3,
                    3, 3, 9, 9, 0,
                    0   );


        @Disks =  ( $oddDataPtr,        $evenDataSataPtr,      $oddDataPtr,     $evenDataSataPtr,   $oddDataPtr,
                    $evenDataPtr,       $oddDataSataPtr,       $evenDataPtr,    $oddDataSataPtr,    $evenDataPtr,
                    $oddDataPtr,        $evenDataSataPtr,      $oddDataPtr,     $evenDataSataPtr,   $oddDataPtr,
                    $evenDataPtr,       $oddDataSataPtr,       $evenDataPtr,    $oddDataSataPtr,    $evenDataPtr,
                    $oddDataPtr,        $evenDataSataPtr,      $oddDataPtr,     $evenDataSataPtr,   $oddDataPtr,
                    $evenDataPtr   );

    }
    elsif ( $strategy == 30 )
    {
        ####################
        # 30 - More vdisks than 2
        # no raid 1
        ####################
        $UseArrays = TRUE;

        debug("strategy 30 selected, raid 10 and raid 5 drives");

        @VDMName = (    "VDM00",  "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (    50,   52,  54,  56,  58,
                         60,   62,  64,  66,  68,
                         70,   72,  74,  76, 78,
                        80,  82, 84, 86, 88,
                        90,   92,  94,  96,  98,
                        100 );

        @Type = (  RAID_10,  RAID_5, RAID_5,   RAID_5, RAID_10,
                   RAID_5,   RAID_5, RAID_10,  RAID_5, RAID_10,
                   RAID_10,  RAID_5, RAID_5,   RAID_5, RAID_10,
                   RAID_5,   RAID_5, RAID_10,  RAID_5, RAID_10,
                   RAID_10,  RAID_5, RAID_5,   RAID_5, RAID_10,
                   RAID_1  );

        @Stripe = (  512,  64,   16,   32,  512,
                     32,   64,  512,   32,  512 ,
                     512,  64,   32,   32,  512 ,
                     32,   64,  512,   32,  512 ,
                     512,  64,   64,   32,  512 ,
                     512);

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    2,
                    0   );

        @Parity = ( 0, 3, 5, 5, 0,
                    3, 5, 0, 9, 0,
                    3, 9, 9, 3, 0,
                    5, 3, 0, 5, 3,
                    3, 5, 9, 3, 0,
                    0   );


        @Disks =  ( $oddDataSataPtr,    $evenDataPtr,      $oddDataSataPtr,     $Gr5DataSataPtr,   $oddDataPtr,
                    $Gr9DataPtr,        $oddDataPtr,       $Gr5DataSataPtr,     $oddDataPtr,    $evenDataSataPtr,
                    $oddDataPtr,        $evenDataPtr,      $Gr9DataPtr,         $evenDataPtr,   $oddDataSataPtr,
                    $evenDataPtr,       $Gr5DataPtr,       $evenDataSataPtr,    $Gr9DataPtr,    $evenDataSataPtr,
                    $oddDataPtr,        $evenDataPtr,      $oddDataPtr,         $evenDataPtr,   $oddDataSataPtr,
                    $allDataPtr   );
    #          Gr9Data   Gr5Data  Gr3Data  allData  allUnsafe  evenData   oddData

    }

    elsif ( $strategy == 31 )
    {
        ####################
        # 31 - More vdisks than 2
        # all raid 5
        ####################
        $UseArrays = TRUE;

        debug("strategy 31 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25", "UNSAFE"   );


        @Capacity = (    50,   52,  54,  56,  58,
                         60,   62,  64,  66,  68,
                         70,   72,  74,  76, 78,
                        80,  82, 84, 86, 88,
                        90,   92,  94,  96,  98,
                        100, 50 );

        @Type = (  RAID_5,  RAID_5, RAID_5,  RAID_5, RAID_5,
                   RAID_5,  RAID_5, RAID_5,  RAID_5, RAID_5,
                   RAID_5,  RAID_5, RAID_5,  RAID_5, RAID_5,
                   RAID_5,  RAID_5, RAID_5,  RAID_5, RAID_5,
                   RAID_5,  RAID_5, RAID_5,  RAID_5, RAID_5,
                   RAID_5,  RAID_0  );

        @Stripe = (  8,  0,   32,   64,  64,
                     64, 32,  32,   64,  16,
                     16, 16,  64,   64,  64,
                     64, 64,  64,   64,  64,
                     64, 32,  32,   32,  32,
                     32, 0  );

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   0,    0,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    2,
                    0,    0 );

        @Parity = ( 5, 5, 5, 5, 5,
                    5, 5, 5, 3, 3,
                    3, 3, 9, 9, 5,
                    5, 5, 5, 3, 3,
                    3, 3, 9, 9, 5,
                    5, 0   );

        @Disks =  ( $allDataSataPtr,    $allDataPtr,     $oddDataSataPtr,    $Gr9DataPtr,      $allDataPtr,
                    $Gr9DataSataPtr,    $allDataPtr,     $allDataSataPtr,    $Gr9DataPtr,      $Gr9DataPtr,
                    $Gr5DataSataPtr,    $Gr9DataPtr,     $Gr9DataSataPtr,    $Gr9DataPtr,      $Gr9DataPtr,
                    $oddDataSataPtr,    $evenDataPtr,    $oddDataSataPtr,    $evenDataPtr,     $oddDataPtr,
                    $evenDataSataPtr,   $oddDataPtr,     $evenDataSataPtr,   $oddDataPtr,      $evenDataPtr,
                    $oddDataSataPtr,    $allUnsafePtr   );
    }

    elsif ( $strategy == 32 )
    {
        ####################
        # 32 - More vdisks than 2
        # all raid 5   bigger than 31,
        ####################
        $UseArrays = TRUE;

        debug("strategy 32 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (    5000,   5200,  5400,  5600,  5800,
                         6000,   6200,  6400,  6600,  6800,
                         7000,   7200,  7400,  7600,  7800,
                         8000,   8200,  8400,  8600,  8800,
                         9000,   9200,  9400,  9600,  9800,
                        10000 );

        @Type = (  RAID_5,  RAID_5, RAID_5,  RAID_5, RAID_5,
                   RAID_5,  RAID_5, RAID_5,  RAID_5, RAID_5,
                   RAID_5,  RAID_5, RAID_5,  RAID_5, RAID_5,
                   RAID_5,  RAID_5, RAID_5,  RAID_5, RAID_5,
                   RAID_5,  RAID_5, RAID_5,  RAID_5, RAID_5,
                   RAID_5  );

        @Stripe = (  64, 64,  64,   64,  64,
                     64, 64,  64,   64,  64,
                     64, 64,  64,   64,  64,
                     64, 64,  64,   64,  64,
                     64, 64,  64,   64,  64,
                     64  );

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   0,    0,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    2,
                    0   );

        @Parity = ( 5, 5, 5, 5, 5,
                    5, 5, 5, 5, 5,
                    5, 5, 5, 5, 5,
                    5, 5, 5, 5, 5,
                    5, 5, 5, 5, 5,
                    5   );

        @Disks =  ( $allDataSataPtr,    $allDataPtr,     $allDataSataPtr,    $allDataPtr,      $allDataPtr,
                    $allDataSataPtr,    $allDataPtr,     $allDataSataPtr,    $allDataPtr,      $allDataPtr,
                    $allDataSataPtr,    $allDataPtr,     $allDataSataPtr,    $allDataPtr,      $allDataPtr,
                    $allDataSataPtr,    $allDataPtr,     $allDataSataPtr,    $allDataPtr,      $allDataPtr,
                    $allDataSataPtr,    $allDataPtr,     $allDataSataPtr,    $allDataPtr,      $allDataPtr,
                    $allDataSataPtr   );
    }
    elsif ( $strategy == 33 )
    {
        ####################
        # 33 - More vdisks than 2
        # no raid 0,5
        ####################
        $UseArrays = TRUE;

        debug("strategy 30 selected, raid 10 and raid 5 drives");

        @VDMName = (    "VDM00",  "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"   );


        @Capacity = (    150,   152,  154,  156,  158,
                         160,   162,  164,  166,  168,
                         170,   172,  174,  176,  178,
                         180,   182,  184,  186,  188,
                         190,   192,  194,  196,  198,
                         150 );

        @Type = (  RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_1  );

        @Stripe = (  512,  512,  512,   512,  512,
                     512,  512,  512,   512,  512 ,
                     512,  512,  512,   512,  512 ,
                     512,  512,  512,   512,  512 ,
                     512,  512,  512,   512,  512 ,
                     512);

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    0,
                    2,    2,     2,   2,    2,
                    2,    0,     2,   0,    2,
                    0   );

        @Parity = ( 0, 3, 5, 5, 0,
                    3, 5, 0, 9, 0,
                    3, 9, 9, 3, 0,
                    5, 3, 0, 5, 3,
                    3, 5, 9, 3, 0,
                    0   );


        @Disks =  ( $oddDataSataPtr,    $evenDataPtr,      $oddDataSataPtr,     $Gr5DataSataPtr,   $oddDataPtr,
                    $Gr9DataPtr,        $oddDataPtr,       $Gr5DataSataPtr,     $oddDataPtr,    $evenDataSataPtr,
                    $oddDataPtr,        $evenDataPtr,      $Gr9DataPtr,         $evenDataPtr,   $oddDataSataPtr,
                    $evenDataPtr,       $Gr5DataPtr,       $evenDataSataPtr,    $Gr9DataPtr,    $evenDataSataPtr,
                    $oddDataPtr,        $evenDataPtr,      $oddDataPtr,         $evenDataPtr,   $oddDataSataPtr,
                    $allUnsafePtr   );
    #          Gr9Data   Gr5Data  Gr3Data  allData  allUnsafe  evenData   oddData

    }
    elsif ( $strategy == 34 )
    {
        ###########################################
        # 34 - 10 drives, growing size All RAID 10
        ###########################################
        $UseArrays = TRUE;

        @VDMName = ("1R10",  "2R10",  "3R10",  "4R10",
                    "5R10",  "6R10",  "7R10",  "8R10",
                    "9R10",  "0R10",                    );

        @Capacity = (1000, 1500, 2000,  2500,
                     3000, 3500, 4000,  4500,
                     5000, 5500, 6000,  6500,
                     7000, 7500                 );

        @Type = ( RAID_10,  RAID_10,  RAID_10,  RAID_10,
                  RAID_10,  RAID_10,  RAID_10,  RAID_10,
                  RAID_10,  RAID_10                     );

        @Stripe = ( 512,  0,   0,   8,
                     16, 32,  64, 512,
                     16, 32             );

        @Depth =  ( 4,    scalar(@$allDataPtr),     scalar(@$oddDataPtr),   3,
                    3,    2,    2,     4,
                    3,    2                                             );

        @Parity = ( 0, 0, 0, 0,
                    0, 0, 0, 0,
                    0, 0        );

        @Disks =  ( $allDataSataPtr,   $allDataPtr,   $oddDataSataPtr,  $Gr3DataPtr,
                    $allDataSataPtr,   $evenDataPtr,  $allDataSataPtr,  $allDataPtr,
                    $allDataSataPtr,   $oddDataPtr                          );
    }
    elsif ( $strategy == 40 )
    {
        ####################
        # 26 small vdisks, raids 0, 1, and 10
        # small -  85 to 210 MB
        # multiple groups
        ####################
        $UseArrays = TRUE;

        debug("strategy 40 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"  );

        @Capacity = (    200,   100,  110,  120,  130,
                         140,   150,  160,  170,  180,
                         190,   210,  195,  185,  175,
                         165,   155,  145,  135,  125,
                         115,   105,   95,   85,  205,
                          90  );

        @Type = (  RAID_10, RAID_10,  RAID_0, RAID_10, RAID_10,
                   RAID_10, RAID_10, RAID_10,  RAID_1,  RAID_1,
                   RAID_10,  RAID_1, RAID_10,  RAID_1,  RAID_1,
                    RAID_0, RAID_10, RAID_10,  RAID_1, RAID_10,
                    RAID_1,  RAID_1, RAID_10, RAID_10, RAID_10,
                   RAID_10  );

        @Stripe = ( 512, 128, 128, 256, 128,
                    256, 512, 512,   0,   0,
                    128,   0, 256,   0,   0,
                    512, 128, 512,   0, 256,
                      0,   0, 512, 128, 256,
                    512  );

        @Depth =  ( 2,    2,     0,   2,    3,
                    4,    scalar(@$allDataPtr),     2,   3,    5,
                    2,    scalar(@$allDataPtr),     2,   3,    5,
                    0,    3,     4,   scalar(@$allDataSataPtr),    scalar(@$allDataSataPtr),
                    3,    5,     2,   2,    2,
                    2  );

        @Parity = ( 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0,
                    0  );

        @Disks =  ( $Gr3DataPtr,     $Gr5DataPtr,    $allUnsafeSataPtr,   $evenDataPtr,    $allDataPtr,
                    $allDataPtr,     $allDataPtr,    $Gr3DataSataPtr,    $Gr3DataPtr,   $Gr5DataPtr,
                    $Gr5DataSataPtr,     $allDataPtr,    $evenDataSataPtr,    $Gr3DataSataPtr,  $Gr5DataSataPtr,
                    $allUnsafePtr,   $allDataSataPtr,   $allDataSataPtr,    $allDataSataPtr,   $allDataSataPtr,
                    $Gr3DataPtr,   $Gr5DataPtr,   $oddDataPtr,    $allDataPtr,     $Gr3DataPtr,
                    $Gr5DataPtr  );
    }
    elsif ( $strategy == 41 )
    {
        ####################
        # 26 small vdisks, raids 0, 1, 5, and 10
        # small - 85 to 210 MB
        # multiple groups
        ####################
        $UseArrays = TRUE;

        debug("strategy 41 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"  );

        @Capacity = (    100,   105,  110,  115,  120,
                         125,   130,  135,  140,  145,
                         150,   155,  160,  165,  170,
                         175,   180,  185,  190,  195,
                         200,   205,  210,   95,   90,
                          85  );

        @Type = (   RAID_5,  RAID_1,  RAID_5, RAID_10, RAID_10,
                    RAID_1,  RAID_0, RAID_10,  RAID_5,  RAID_5,
                    RAID_5,  RAID_0,  RAID_5, RAID_10,  RAID_1,
                   RAID_10,  RAID_1, RAID_10,  RAID_5, RAID_10,
                    RAID_5, RAID_10, RAID_10,  RAID_5,  RAID_1,
                    RAID_1  );

        @Stripe = (  64,   0,   8, 256, 512,
                      0, 512, 128,  32,  16,
                     32, 128,   8, 512,   0,
                    128,   0, 256,  64, 256,
                     16, 512, 128,  64,   0,
                      0  );

        @Depth =  ( 0,    3,     0,   2,    2,
                    5,    0,     2,   0,    0,
                    0,    0,     0,   2,    3,
                    2,    5,     2,   0,    4,
                    0,    2,     3,   0,    scalar(@$allDataPtr),
                    scalar(@$allDataSataPtr)  );

        @Parity = ( 3, 0, 5, 0, 0,
                    0, 0, 0, 9, 3,
                    5, 0, 9, 0, 0,
                    0, 0, 0, 3, 0,
                    9, 0, 0, 5, 0,
                    0  );

        @Disks =  ( $Gr3DataPtr,     $Gr3DataPtr,    $allDataPtr,   $Gr3DataPtr,    $Gr5DataPtr,
                    $Gr5DataPtr,     $allUnsafePtr,    $evenDataPtr,    $allDataPtr,    $allDataPtr,
                    $Gr9DataPtr,     $allUnsafeSataPtr,    $allDataPtr,    $Gr3DataSataPtr,    $Gr3DataSataPtr,
                    $Gr5DataSataPtr,   $Gr5DataSataPtr,   $oddDataSataPtr,    $Gr3DataSataPtr,   $allDataPtr,
                    $allDataSataPtr,   $oddDataPtr,   $evenDataPtr,    $allDataSataPtr,   $allDataPtr,
                    $allDataSataPtr  );
    }
    elsif ( $strategy == 42 )
    {
        debug("strategy 42 selected");
        
        ####################
        # User Specified Number of vdisks only RAID 10
        # A Strategy which will be used while using FE Simulator
        ####################
        $UseArrays = TRUE;

        my $ans;
        my $size;

        #
        # check if numVdisks was passed in.  
        # If it was, use it.
        # If not, ask user how many vdisks to create
        #
        
        if (!$numVdisks)
        {
            do
            {
                print "\nEnter the number of vdisks to create (1-32): ";
                $ans = <STDIN>;
                chomp ($ans);
                print "\n";
            } 
            while ( ($ans < 1) || ($ans > 32) );
        }
        else 
        {
            $ans = $numVdisks;
            if ( ($ans < 1) || ($ans > 32) )
            {
                logInfo(">>>>>>>> Illegal value passed for numVdisks.  Must be 1-30.  <<<<<<<<");
                return ERROR;
            } 
        }
        
        print "\nEnter capacity of vdisks to be created in size of MB: ";
        $size = <STDIN>;
        chomp ($size);
        print "\n";

            @VDMName = ("PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25", "VDM26", "VDM27", "VDM28", "VDM29",
			"VDM30", "VDM31" );

            @Capacity = ( $size,   $size,  $size,  $size,  $size,
                          $size,   $size,  $size,  $size,  $size,
                          $size,   $size,  $size,  $size,  $size,
                          $size,   $size,  $size,  $size,  $size,
                          $size,   $size,  $size,  $size,  $size,
                          $size,   $size,  $size,  $size,  $size,
			  $size,   $size );

            @Type = ( RAID_10,  RAID_10,  RAID_10, RAID_10,  RAID_10,
                      RAID_10,  RAID_10,  RAID_10, RAID_10,  RAID_10,
                      RAID_10,  RAID_10,  RAID_10, RAID_10,  RAID_10,
                      RAID_10,  RAID_10,  RAID_10, RAID_10,  RAID_10,
                      RAID_10,  RAID_10,  RAID_10, RAID_10,  RAID_10,
                      RAID_10,  RAID_10,  RAID_10, RAID_10,  RAID_10,
		      RAID_10,  RAID_10 );


            @Stripe = ( 512, 512, 512, 512, 512,
                        512, 512, 512, 512, 512,
                        512, 512, 512, 512, 512,
                        512, 512, 512, 512, 512,
                        512, 512, 512, 512, 512,
                        512, 512, 512, 512, 512,
			512, 512 );

            @Depth =  ( 2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
			2,   2 );

            @Parity = ( 3, 3, 3, 3, 3,
                        3, 3, 3, 3, 3,
                        3, 3, 3, 3, 3,
                        3, 3, 3, 3, 3,
                        3, 3, 3, 3, 3,
                        3, 3, 3, 3, 3,
			3, 3 );

            @Disks =  ( $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
			$allDataPtr,	$allDataPtr );
        #
        # Limit the number of vdisks created to the input value by truncating
        # on of the arrays.   
        #

        $#Capacity = $ans - 1;
    }
    elsif ( $strategy == 43 )
    {
        #################################################
        # A strategy used for creating vdisks for a 750 
        # controller when there are only 5 pdisks present
        # 15 vdisks all Raid 10
        #################################################
        $UseArrays = TRUE;
        
        if ( $minpdisksflag == FALSE )
        {
            logInfo (" This strategy is for a controller with 4 pdisks only, Use a different startegy.... "); 
        }

        debug("strategy 43 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14" );


        @Capacity = (    100,   105,  110,  115,  120,
                         125,   130,  135,  140,  145,
                         150,   155,  160,  165,  170 );


        @Type = (  RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10,  RAID_10,
                   RAID_10,  RAID_10,  RAID_10,  RAID_10,  RAID_10 );

        @Stripe = ( 512,  512,   512,   512,  512,
                     512, 512, 512,   512,  512 ,
                     512, 512, 512,   512,  512 );

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2  );

        @Parity = ( 3, 3, 3, 3, 3,
                    3, 3, 3, 3, 3,
                    3, 3, 3, 3, 3  );

        @Disks =  ( $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr );
    }
    elsif ( $strategy == 44 )
    {
        ####################
        # 26 small vdisks, raids 0, 1, 5, and 10
        # small - 85 to 210 MB
        # multiple groups
        ####################
        $UseArrays = TRUE;

        debug("strategy 44 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09",
                        "VDM10", "VDM11", "VDM12", "VDM13", "VDM14",
                        "VDM15", "VDM16", "VDM17", "VDM18", "VDM19",
                        "VDM20", "VDM21", "VDM22", "VDM23", "VDM24",
                        "VDM25"  );

        @Capacity = (    100,   105,  110,  115,  120,
                         125,   130,  135,  140,  145,
                         150,   155,  160,  165,  170,
                         175,   180,  185,  190,  195,
                         200,   205,  210,   95,   90,
                          85  );

        @Type = (   RAID_5,  RAID_10,  RAID_5, RAID_10, RAID_10,
                    RAID_10,  RAID_10, RAID_10,  RAID_5,  RAID_5,
                    RAID_5,  RAID_10,  RAID_5, RAID_10,  RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_5, RAID_10,
                    RAID_5, RAID_10, RAID_10,  RAID_5,  RAID_10,
                    RAID_10  );

        @Stripe = (  64,   0,   8, 256, 512,
                      0, 512, 128,  32,  16,
                     32, 128,   8, 512,   0,
                    128,   0, 256,  64, 256,
                     16, 512, 128,  64,   0,
                      0  );

        @Depth =  ( 0,    3,     0,   2,    2,
                    5,    0,     2,   0,    0,
                    0,    0,     0,   2,    3,
                    2,    5,     2,   0,    4,
                    0,    2,     3,   0,    scalar(@$allDataPtr),
                    scalar(@$allDataSataPtr)  );

        @Parity = ( 3, 0, 3, 0, 0,
                    0, 0, 0, 3, 3,
                    3, 0, 3, 0, 0,
                    0, 0, 0, 3, 0,
                    3, 0, 0, 3, 0,
                    0  );

        @Disks =  ( $Gr3DataPtr,     $Gr3DataPtr,    $allDataPtr,   $Gr3DataPtr,    $Gr3DataPtr,
                    $allDataPtr,     $allUnsafePtr,    $evenDataPtr,    $allDataPtr,    $allDataPtr,
                    $Gr3DataPtr,     $allUnsafeSataPtr,    $allDataPtr,    $Gr3DataSataPtr,    $Gr3DataSataPtr,
                    $Gr3DataSataPtr,   $allDataSataPtr,   $allDataSataPtr,    $Gr3DataSataPtr,   $allDataPtr,
                    $allDataSataPtr,   $allDataPtr,   $evenDataPtr,    $allDataSataPtr,   $allDataPtr,
                    $allDataSataPtr  );
    }
    elsif ( $strategy == 45 )
    {
        ####################
        # 10 small vdisks, raids 0, 1, 5, and 10
        # small - 8 to 10 MB
        # multiple groups
        ####################
        $UseArrays = TRUE;

        debug("strategy 45 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09" );

        @Capacity = (    25,    25,  25,  25,  25,
                         20,   20,  25,  20,  20 );

        @Type = (   RAID_5,  RAID_1,  RAID_5, RAID_10, RAID_10,
                    RAID_1,  RAID_0, RAID_10,  RAID_5,  RAID_5 );

        @Stripe = (  64,   0,   8, 256, 512,
                      0, 512, 128,  32,  16 );

        @Depth =  ( 0,    3,     0,   2,    2,
                    5,    0,     2,   0,    0 );

        @Parity = ( 3, 0, 3, 0, 0,
                    0, 0, 0, 3, 3 );

        @Disks =  ( $Gr3DataPtr,     $Gr3DataPtr,    $allDataPtr,   $Gr3DataPtr,    $Gr3DataPtr,
                    $allDataPtr,     $allUnsafePtr,    $evenDataPtr,    $allDataPtr,    $allDataPtr );
    }
    elsif ( $strategy == 46 )
    {
        #################################################
        # A strategy used for creating vdisks for a 750 
        # controller when there are only 5 pdisks present
        # 10 vdisks all Raid 10 and size 8 - 10
        #################################################
        $UseArrays = TRUE;

        if ( $minpdisksflag == FALSE )
        {
            logInfo (" This strategy is for a controller with 4 pdisks only, Use a different startegy.... "); 
        }

        debug("strategy 46 selected");

        @VDMName = (    "PFM",   "VDM01", "VDM02", "VDM03", "VDM04",
                        "VDM05", "VDM06", "VDM07", "VDM08", "VDM09" );


        @Capacity = (    10,    20,    25,   20,  20,
                         18,     10,  10,   20,   26 );


        @Type = (  RAID_10,  RAID_10, RAID_10,  RAID_10, RAID_10,
                   RAID_10,  RAID_10, RAID_10,  RAID_10,  RAID_10 );

        @Stripe = ( 512,  512,   512,   512,  512,
                     512, 512, 512,   512,  512 );

        @Depth =  ( 2,    2,     2,   2,    2,
                    2,    2,     2,   2,    2 );
        
        @Parity = ( 3, 3, 3, 3, 3,
                    3, 3, 3, 3, 3 );

        @Disks =  ( $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr );
    }

    elsif ( $strategy == 55 )
    {
        my $foundRaid5;
        my @originalVdisks;
        my @baseVdisks;
        my @tempVdisks;
        my $ans;
        
        ####################
        # Up to 30 vdisks, RAID_10 and RAID_5 
        # If no RAID_5 vdisks currently exist, will make all mirrors RAID_10
        # All slightly larger than the largest current existing vdisk
        # multiple groups
        ####################
        $UseArrays = TRUE;

        debug("strategy 55 selected");

        #
        # check if numVdisks was passed in.  
        # If it was, use it.
        # If not, ask user how many vdisks to create
        #
        if (!$numVdisks)
        {
            do
            {
                print "\n\n=====>  Enter the number of vdisks to create as mirrors (1-30): ";
                $ans = <STDIN>;
                chomp ($ans);
            } 
            while ( ($ans < 1) || ($ans > 30) );
        }
        else 
        {
            $ans = $numVdisks;
            if ( ($ans < 1) || ($ans > 30) )
            {
                logInfo(">>>>>>>> Illegal value passed for numVdisks.  Must be 1-30.  <<<<<<<<");
                return ERROR;
            } 
        }

        # 
        # Get the vdisks that currently exist
        #
        %rsp = $controller->virtualDisks();
        if ( ! %rsp  )             
        {
            logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      
        {
            logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
        if ($rsp{COUNT} < 1)
        {
            logInfo(">>>>>>>> No vdisks currently exist <<<<<<<<");
            return ERROR;
        }

        for ($i = 0; $i < $rsp{COUNT}; $i++)
        {
            $originalVdisks[$i] = $rsp{VDISKS}[$i]{VID};
        }

        #
        # Remove any vlinks that may exist
        #
        $ret = TestLibs::BEUtils::RemoveVlinks($controller, \@originalVdisks, \@tempVdisks);  
        if ( $ret  != GOOD )      
        {
            logInfo(">>>>>>>> Error from RemoveVlinks <<<<<<<<");
            return ERROR;
        }
        
        #
        # Remove any currently existing mirrors
        #
        $ret = TestLibs::BEUtils::RemoveMirrors($controller, \@tempVdisks, \@baseVdisks);  
        if ( $ret  != GOOD )      
        {
            logInfo(">>>>>>>> Error from RemoveMirrors <<<<<<<<");
            return ERROR;
        }

        #
        # Find the size of the largest vdisk that is not a mirror or a vlink   
        #
        $maxSize = 0;
        for ($i = 0; $i < $rsp{COUNT}; $i++)
        {
            if ( IsInList( $rsp{VDISKS}[$i]{VID}, \@baseVdisks ) )
            {
                if ( $rsp{VDISKS}[$i]{CAPACITY} > $maxSize )
                {
                    $maxSize = $rsp{VDISKS}[$i]{CAPACITY};
                }
            }
        }

        logInfo("Largest base vdisk found is $maxSize blocks.");

        $maxSize = 1 + int( $maxSize / 2048 );
        
        logInfo("All mirror vdisks created will be $maxSize MB.");

        #
        # Check to see if there are any RAID_5 on system.
        # If not, do not create any RAID_5 mirrors either
        #
        $foundRaid5 = GotRaid5($controller);
        if ( $foundRaid5 == INVALID )
        {
            logInfo(">>>>>>>> GotRaid5 Failed <<<<<<<<");
            return ERROR;
        } 
        
        #
        # Set up max of 30 vdisks
        #
        @VDMName = (    "MIR00", "MIR01", "MIR02", "MIR03", "MIR04",
                        "MIR05", "MIR06", "MIR07", "MIR08", "MIR09",
                        "MIR10", "MIR11", "MIR12", "MIR13", "MIR14",
                        "MIR15", "MIR16", "MIR17", "MIR18", "MIR19",
                        "MIR20", "MIR21", "MIR22", "MIR23", "MIR24",
                        "MIR25", "MIR26", "MIR27", "MIR28", "MIR29"  );

        @Capacity = (    $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize,
                         $maxSize,   $maxSize,  $maxSize,  $maxSize,  $maxSize  );

        if ( $foundRaid5 )
        {
            logInfo("System currently has RAID 5 vdisks.");  
            logInfo("Mirrors created will be mixture of RAID 5 and 10.");  
            
            if (scalar(@Gr5DataSata) == 0 )
            {

                logInfo("System currently is set for creating only RAID 5 parity 3 vdisks.");  

                @Type = (   RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                            RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5,
                            RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                            RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5,
                            RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                            RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5  );

                @Stripe = ( 512,  64, 512,  64, 256,
                             32, 256,  32, 128,  16,
                            128,  16, 512,   8, 512,
                              8, 256,  64, 256,  64,
                            128,  32, 128,  32, 512,
                            16, 512,  16, 256,   8  );

                @Depth =  ( 2,   0,   2,   0,   2,
                            0,   2,   0,   2,   0,
                            2,   0,   2,   0,   2,
                            0,   2,   0,   2,   0,
                            2,   0,   2,   0,   2,
                            0,   2,   0,   2,   0  );

                @Parity = ( 0, 3, 0, 3, 0,
                            3 , 0, 3, 0, 3,
                            0, 3, 0, 3, 0,
                            3, 0, 3, 0, 3,
                            0, 3, 0, 3, 0,
                            3, 0, 3, 0, 3  );

                @Disks =  ( $Gr3DataPtr,     $Gr3DataPtr,      $Gr3DataSataPtr,  $Gr3DataSataPtr,  $Gr3DataPtr,
                            $Gr3DataPtr,     $Gr3DataSataPtr,  $Gr3DataSataPtr,  $allDataPtr,      $allDataPtr,
                            $allDataSataPtr, $allDataSataPtr,  $allDataPtr,     $Gr3DataPtr,       $allDataSataPtr,
                            $Gr3DataSataPtr, $allDataPtr,      $Gr3DataPtr,      $allDataSataPtr,  $Gr3DataSataPtr,
                            $Gr3DataPtr,     $allDataPtr,      $Gr3DataSataPtr,  $allDataSataPtr,  $Gr3DataPtr,
                            $Gr3DataPtr,     $Gr3DataSataPtr,  $Gr3DataSataPtr,  $allDataPtr,     $Gr3DataPtr  );
            }
            else
            {

                @Type = (   RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                            RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5,
                            RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                            RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5,
                            RAID_10,  RAID_5, RAID_10,  RAID_5, RAID_10,
                            RAID_5, RAID_10,  RAID_5, RAID_10,  RAID_5  );

                @Stripe = ( 512,  64, 512,  64, 256,
                             32, 256,  32, 128,  16,
                            128,  16, 512,   8, 512,
                              8, 256,  64, 256,  64,
                            128,  32, 128,  32, 512,
                            16, 512,  16, 256,   8  );

                @Depth =  ( 2,   0,   2,   0,   2,
                            0,   2,   0,   2,   0,
                            2,   0,   2,   0,   2,
                            0,   2,   0,   2,   0,
                            2,   0,   2,   0,   2,
                            0,   2,   0,   2,   0  );

                @Parity = ( 0, 3, 0, 3, 0,
                            5 , 0, 5, 0, 9,
                            0, 9, 0, 3, 0,
                            3, 0, 5, 0, 5,
                            0, 9, 0, 9, 0,
                            3, 0, 3, 0, 5  );

                @Disks =  ( $Gr3DataPtr,     $Gr5DataPtr,      $Gr3DataSataPtr,  $Gr5DataSataPtr,  $Gr5DataPtr,
                            $Gr9DataPtr,     $Gr5DataSataPtr,  $Gr9DataSataPtr,  $oddDataPtr,      $allDataPtr,
                            $oddDataSataPtr, $allDataSataPtr,  $evenDataPtr,     $Gr5DataPtr,      $evenDataSataPtr,
                            $Gr5DataSataPtr, $allDataPtr,      $Gr9DataPtr,      $allDataSataPtr,  $Gr9DataSataPtr,
                            $Gr3DataPtr,     $allDataPtr,      $Gr3DataSataPtr,  $allDataSataPtr,  $Gr5DataPtr,
                            $Gr5DataPtr,     $Gr5DataSataPtr,  $Gr5DataSataPtr,  $evenDataPtr,     $Gr9DataPtr  );
            }                                 
        }
        elsif ( $minpdisksflag == FALSE ) 
        {
            logInfo("System currently does not have any RAID 5 vdisks.");  
            logInfo("All mirrors created will be RAID 10.");  

            @Type = (  RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                       RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                       RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                       RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                       RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                       RAID_10, RAID_10, RAID_10, RAID_10, RAID_10  );

            @Stripe = ( 128, 128, 256, 256, 512,
                        512, 128, 128, 256, 256,
                        512, 512, 128, 128, 256,
                        256, 512, 512, 128, 128,
                        256, 256, 512, 512, 128,
                        128, 256, 256, 512, 512  );

            @Depth =  ( 2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2  );

            @Parity = ( 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0  );

            @Disks =  ( $Gr3DataPtr,     $Gr3DataSataPtr, $Gr5DataPtr,      $Gr5DataSataPtr, $Gr9DataPtr,
                        $Gr9DataSataPtr, $evenDataPtr,    $evenDataSataPtr, $oddDataPtr,     $oddDataSataPtr,
                        $allDataPtr,     $allDataSataPtr, $Gr3DataPtr,      $Gr3DataSataPtr, $Gr5DataPtr,
                        $Gr5DataSataPtr, $Gr9DataPtr,     $Gr9DataSataPtr,  $evenDataPtr,    $evenDataSataPtr,
                        $oddDataPtr,     $oddDataSataPtr, $allDataPtr,      $allDataSataPtr, $Gr3DataPtr,
                        $Gr3DataSataPtr, $Gr5DataPtr,     $Gr5DataSataPtr,  $Gr9DataPtr,     $Gr9DataSataPtr  );
        }                        
        else
        {
            logInfo("System currently has less than 5 pdisks.");  
            logInfo("All mirrors created will be RAID 10.");  

            @Type = (  RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                       RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                       RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                       RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                       RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                       RAID_10, RAID_10, RAID_10, RAID_10, RAID_10  );

            @Stripe = ( 128, 128, 256, 256, 512,
                        512, 128, 128, 256, 256,
                        512, 512, 128, 128, 256,
                        256, 512, 512, 128, 128,
                        256, 256, 512, 512, 128,
                        128, 256, 256, 512, 512  );

            @Depth =  ( 2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2,
                        2,   2,   2,   2,   2  );

            @Parity = ( 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0  );

            @Disks =  ( $allDataPtr,     $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,     $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,     $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,     $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,     $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr,
                        $allDataPtr,     $allDataPtr,    $allDataPtr,    $allDataPtr,    $allDataPtr  );
        }
        #
        # Limit the number of vdisks created to the input value by truncating
        # on of the arrays.   
        #
        $#Capacity = $ans - 1;
    }
    else
    {
        #########################
        # you have chosen badly
        #########################
        logWarning(">>>>> Unavailable strategy specified ($strategy). Sorry, no vdisks created. <<<<<");
        return ERROR;
    }


    # figure out how many to make, based upon smallest array size. This helps
    # when we miscount the number of elements in an array.
    $numberToCreate = min( scalar(@VDMName), min(scalar(@Capacity), scalar(@Type) ) );
    $numberToCreate = min( $numberToCreate,  min(scalar(@Stripe),   scalar(@Depth) ) );
    $numberToCreate = min( $numberToCreate,  min(scalar(@Parity),   scalar(@Disks) ) );

    logInfo("to create $numberToCreate \n @VDMName \n @Capacity \n @Type");

    my $numberNew = 0;

    if ( $UseArrays == TRUE )
    {
        # now actually make the vdisks
        for(my $r = 0; $r < $numberToCreate; $r++)
        {

            # enforce a minimum stripe size per changes in A290 code
            if (  ($Stripe[$r] < 128) && ($Type[$r] == 4) )
            {
                $Stripe[$r] = 128;
            }

            debug("creating vdisk using  $VDMName[$r], $Capacity[$r] MB, $Type[$r]");
            # parms: $controller, $name, $capacity_org, $rtype, $stripe, $depth, $parity, $numPDDs, \@physicalDisks

            # Capacity is in MBs, call is in GBs
            $ret = CreateSingleVdisk($controller, $VDMName[$r], $Capacity[$r], $Type[$r],
                                           $Stripe[$r], $Depth[$r], $Parity[$r],  $Disks[$r] );

            if ( $ret == INVALID )
            {                                                                            #
                logWarning(">>>>> Failed creating $r th Vdisk <<<<<");
                return (ERROR);
            }

            push (  @newVdisks, $ret );  # save new vdisk number
            $numberNew++;
        }
    }

    # make sure we have created some vdisks for the rest to be done

    if ( $numberNew == 0 )
    {
        # no vdisks were created, so nothing more to do
        return GOOD;
    }

    if (  ($option & NO_RAID_INIT)  == 0 )
    {
        if ( ERROR == InitializeSomeVdisks( $controller, \@newVdisks ) )
        {
            logWarning(">>>>> Failed initializing vdisks. <<<<<");
            return (ERROR);
        }
    }



    # done (maybe print a list)
    return GOOD;
}


########################################################################################################################



##############################################################################
#
#          Name: CreateSingleVdisk
#
#        Inputs: controllerID, name, numBlocks, raidLevel
#
#       Outputs: vdisk number, if successful, INVALID otherwise
#
#  Globals Used: none
#
#   Description: Creates the specified Vdisk on supplied list of drives
#
#
#                Will return ERROR if the drives are not appropriate for
#                for the raid type, or if there is not enough disk space
#                available.
#
#                Will adjust parity if needed to mathc the number of
#                available disks.
#
#                Current CLI functionality does not allow us to use all
#                parameters.
#
##############################################################################

sub CreateSingleVdisk
{
    trace();


    my ($controller, $name, $capacity_org, $rtype, $stripe, $depth, $parity, $pdPointer, $vid) = @_;
    my @array;
    my $capacity = -1;
    my $numPDs;
    my @disks;
    my $i;

    my @dataPdisks;
    my @unsafePdisks;

    my $dataCount = 0;
    my $unsafeCount = 0;

    my $diskPtr;
    my %ret;
    my $rtn;
    my $chkNumPDs;


    if(uc($pdPointer) eq "ALL")
    {
        #
        my %pdisks = $controller->physicalDisks();
        my $cnt = $pdisks{COUNT};
        my $usable_disks = 0;

        for($i = 0; $i < $cnt; ++$i)
        {
            if($pdisks{PDISKS}[$i]{PD_CLASS} == 3)      # unsafe
            {
                $unsafePdisks[$unsafeCount] = $pdisks{PDISKS}[$i]{PD_PID};
                ++$unsafeCount;
            }

            if($pdisks{PDISKS}[$i]{PD_CLASS} == 1)      # data
            {
                $disks[$dataCount] = $pdisks{PDISKS}[$i]{PD_PID};
                ++$dataCount;
            }
        }


        if ( $rtype == RAID_1 ||  $rtype == RAID_5 ||  $rtype == RAID_10 )
        {
            $numPDs = $dataCount;
            @disks = @dataPdisks;
        }
        else
        {
            $numPDs = $unsafeCount;
            @disks = @unsafePdisks;
        }

        if ($numPDs <= 0)
        {
            logInfo ("No physical disks labeled appropriately. use PDISKLABEL");
            return INVALID;
        }

    }
    else
    {
        @disks = @$pdPointer;
        $chkNumPDs = @disks;
     my $productID = getMagProductID( 0, $controller ); # Get the product ID
     if ( $productID != 7000 ) 
        {
        $numPDs = scalar(@disks);
        }
        else
        {
        $numPDs = scalar(@disks);
        if ( $numPDs > 6 )
         {
         while ( $numPDs > 6 )
          {
          # Need to reduce the number to 6.  Take off from the end of the list
          pop(@disks);
          $numPDs = scalar(@disks);

           
          }
         }
       }  
    }




    $capacity =  $capacity_org * 2048;     # mb to sectors conversion


    my $str = " ------------------------------------------------- CREATING: --------------------------------------- \n";


    # all parameters are ready for the call to create the vdisk
    $str .= "NAME: $name  ";                 # first line of print
    $str .= "CAPACITY: $capacity blocks  ";
    $str .= "RAID: $rtype  ";
    $str .= "STRIPE SIZE: $stripe  ";
    $str .= "MIRROR DEPTH: $depth  ";
    $str .= "PARITY: $parity  ";
    $str .= "NUMBER of PDs: $numPDs  \n";   # second line
    $numPDs = scalar(@disks);
    $str .= "PD IDs:  @disks \n";
    if (defined $vid)
    {
        $str .= "VID:  $vid \n";
    }
 #   logInfo($str);




    logInfo("Start Validate Vdisk Parms");

    $rtn = ValidateVdiskParams( \$depth, \$rtype, \$stripe, \$parity, \@disks );
    logInfo("End Validate Vdisk Parms");

    $str = "";


    # all parameters are ready for the call to create the vdisk
    $str .= "NAME: $name  ";                 # first line of print
    $str .= "CAPACITY: $capacity blocks  ";
    $str .= "RAID: $rtype  ";
    $str .= "STRIPE SIZE: $stripe  ";
    $str .= "MIRROR DEPTH: $depth  ";
    $str .= "PARITY: $parity  ";
    $numPDs = scalar(@disks);
    $str .= "NUMBER of PDs: $numPDs  \n";   # second line
    $str .= "PD IDs:  @disks \n";
    if (defined $vid)
    {
        $str .= "VID:  $vid \n";
    }
    logInfo($str);


    if ( $rtn == INVALID )
    {
        logInfo("Parameters for creating the vdisk are invalid.");
        return INVALID;
    }



    %ret = $controller->virtualDiskCreate($capacity,
                                          \@disks,       # list of vdisks
                                          $rtype,        # raid type
                                          $stripe,       # stripe size
                                          $depth,        # mirror depth
                                          $parity,       # parity
                                          $vid,          # vid to use (can be undef)
                                          4,             # maxraids
                                          10,            # threshold
                                          0,             # flags
                                          0              # minPD
                                          );


    if ( ! %ret  )              # if no return from call
    {
        logInfo(">>>>> Failed to get response from virtualDiskCreate <<<<<");
        return INVALID;
    }

    debug("%ret");

    if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>> Error from virtualDiskCreate <<<<<");
        PrintError(%ret);
        return INVALID;
    }

    print "VDisk ID = $ret{VID} WAS CREATED \n";
    %ret = $controller ->virtualDiskInfo($ret{VID});

    if ( ! %ret  )              # if no return from call
    {
        logInfo(">>>>> Failed to get response from virtualDiskInfo <<<<<");
        return INVALID;
    }

    if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>> Error from virtualDiskInfo <<<<<");
        PrintError(%ret);
        return INVALID;
    }
    else
    {
        # good path, display the data
        logVirtualDiskInfo(%ret);
    }

    # return, signal if anything changed from request <- can't do

    return ($ret{VID});
}














##############################################################################
#
#          Name: ValidateVdiskParams
#
#        Inputs:  /$depth, /$rtype, /$stripe, /$parity, /$mirror, /@disks
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: All inputs are pointers, updates values to give legit
#                inputs for pdisk creation
#
#
##############################################################################

sub ValidateVdiskParams
{

    my ( $depth, $rtype, $stripe, $parity,  $dskPtr ) = @_;

    my @pdisks = @$dskPtr;

    my $numPDs = scalar(@pdisks);
    my $i;

    if ( $$rtype == RAID_1 )
    {
        # rules for raid 1:
        #     only supported depth is 2
        #     will only use 2 pdisks even if more are supplied,
        #     must be at least two pdisks
        #     no apparent stripe size limitation
        #     must be less than 8 pdisks (caused by a bug )
        #     min stripe size is 128

        if($$stripe < 128 )
        {
            $$stripe = DEFAULT_STRIPE_SIZE_RAID_0;
        }

        if ( $$depth == 0)
        {
            $$depth = 2;
        }

        if  ( $$depth > 6 )                        # limit to what works
        {
            $$depth = 6;
        }

        if ($numPDs > 6 )
        {
            logInfo ("Too many PDDs supplied, list will be truncated.");

            my @pdl;

            for ( $i = 0; $i < 6; $i++ )
            {
                $pdl[$i] = $$dskPtr[$i];
            }

            @$dskPtr = @pdl;
            $numPDs = scalar(@$dskPtr);

        }

        if ($numPDs < 2)
        {
            logInfo("Need at least two disks for raid 1\n");
            return INVALID;
        }


    }
    elsif ( $$rtype == RAID_5 )
    {
        # rules for raid 5:
        #     require at least 3 pdisks
        #     parity 9 is unsupported, but may work (currently broken)
        #     stripe size cannot exceed 64

        if($$stripe < 1 )
        {
            $$stripe = DEFAULT_STRIPE_SIZE_RAID_5;
        }

        if ( $$stripe > 64 )                      #  limit to what works
        {
            $$stripe = 64;
        }

        if ($numPDs < 3)
        {
            logInfo("Need at least three disks for raid 5\n");
            return INVALID;
        }
        elsif ($numPDs < 5)
        {
            $$parity = 3;
        }
        elsif ($numPDs < 9)
        {
            $$parity = 5;
        }
        else
        {
            $$parity = 5;                   # limit to what works, should be 9
        }


    }
    elsif ( $$rtype == RAID_10 )
    {

        # rules for raid 10:
        #     max supported depth is 4 larger may work
        #     must be at least three pdisks
        #     no apparent stripe size limitation
        #     must be at least one more pdisk than mirror depth

        if($$stripe < 128 )
        {
            $$stripe = DEFAULT_STRIPE_SIZE_RAID_10;
        }

        if ( $$depth == 0)
        {
            $$depth = 1;
        }

        if  ( $$depth > 7 )                        # limit to what works
        {
            $$depth = 7;
        }

        if ( $$depth >= $numPDs )
        {
            $$depth = $numPDs - 1;
        }

        if ($numPDs < 3)
        {
            logInfo("Need at least three disks for raid 10\n");
            return INVALID;
        }


    }
    elsif ( $$rtype == RAID_0 )
    {

        # rules for raid 0:
        #     max supported depth is 4 larger may work
        #     will only use 2 pdisks even if more are supplied,
        #     must be at least two pdisks
        #     no apparent stripe size limitation
        #     must be less than 8 pdisks (caused by a bug )

        if($$stripe < 128 )
        {
            $$stripe = DEFAULT_STRIPE_SIZE_RAID_0;
        }

        if ( $$depth == 0)
        {
            $$depth = 2;
        }

        if  ( $$depth > 7 )                        # limit to what works
        {
            $$depth = 7;
        }

        if ($numPDs < 2)
        {
            logInfo("Need at least two disks for raid 0\n");
            return INVALID;
        }


    }
    else # raid_none
    {

        # rules for raid none:

        if ($numPDs > 1)
        {
            logInfo("Need at only one disk for RAID_NONE\n");

            # let this go thru and the controller can handle it
            #return INVALID;
        }


    }

    return GOOD;

}

##############################################################################
#
#          Name: InitializeAllVdisks
#
#        Inputs: controllerID
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Launches the initiialization of all vdisks. Does not wait
#                for completion.
#
#
##############################################################################
sub InitializeAllVdisks
{
    trace();

    my ($controller) = @_;
    my %ret = $controller->raidList();   # get list of raid devices

    if ( ! %ret )               # if no return from call
    {
        logInfo(">>>>> Failed to get response from raidList <<<<<");
        return ERROR;
    }

    if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>> Error from raidList <<<<<");
        PrintError(%ret);
        return ERROR;
    }

    my $Sub_ArrayVD = $ret{LIST};        # massage the data
    my @Raid_Array = @$Sub_ArrayVD;


    for(my $i = 0; $i < scalar(@Raid_Array); $i++)
    {
        %ret = $controller->virtualDiskInit($Raid_Array[$i]);

        if ( ! %ret )               # if no return from call
        {
            logInfo(">>>>> Failed to get response from virtualDiskInit <<<<<");
            return ERROR;
        }

        if ( ($ret{STATUS} != PI_GOOD) && ( $controller->PI_ERROR_INIT_IN_PROG != $ret{ERROR_CODE} ) )
        {
            # if call returned an error
            logInfo(">>>>> Error from virtualDiskInit <<<<< " .
            "ERROR---VD Raid_ID $Raid_Array[$i] was NOT Initialized");
            PrintError(%ret);
            return ERROR;
        }

        # no error from virtualDiskInit

        logInfo("Initialize started on VD Raid_ID $Raid_Array[$i]");
    }

    # done, then
    return GOOD;
}

##############################################################################
#
#          Name: InitializeSomeVdisks
#
#        Inputs: controllerID , pointer to list of vdisks
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Launches the initiialization of all vdisks. Does not wait
#                for completion.
#
#
##############################################################################
sub InitializeSomeVdisks
{
    trace();

    my ($controller, $vddPtr ) = @_;

    my $i;
    my $j;
    my @vddList;
    my @Raid_Array;
    my %ret;
    my $raidCount;
    my $totalRaids;

    @vddList = @$vddPtr;

    $raidCount = 0;
    #
    # build array of RDDs based upon supplied VDD list
    #

    for ( $i = 0 ; $i < scalar(@vddList); $i++ )
    {
        # get the vdisk info
        %ret = $controller ->virtualDiskInfo($vddList[$i]);

        # extract raids to array
        if ( ! %ret  )              # if no return from call
        {
            logInfo(">>>>> Failed to get response from virtualDiskInfo <<<<<");
            return ERROR;
        }

        if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
        {

            if ( $ret{ERROR_CODE} != $controller ->PI_ERROR_INV_VID )
            {
                # handle errors EXCEPT invalid vdisk (it is considered OK)
                logInfo(">>>>> Error from virtualDiskInfo <<<<<");
                PrintError(%ret);
                return ERROR;
            }
        }
        else
        {
            # good path, display the data
            $totalRaids = $ret{RAIDCNT} + $ret{DRAIDCNT};

            my $str =  "Raid IDs: ";
            for ($j = 0; $j < $totalRaids; $j++)
            {
                $str .= sprintf " %hu", $ret{RIDS}[$j];
                push ( @Raid_Array, $ret{RIDS}[$j] );
                $raidCount++;
            }
            logInfo($str);
        }
    }

    # be sure to check that the vdisk is still there and was not
    # deleted (handled above)


    for(my $i = 0; $i < scalar(@Raid_Array); $i++)
    {
        %ret = $controller->virtualDiskInit($Raid_Array[$i]);

        if ( ! %ret )               # if no return from call
        {
            logInfo(">>>>> Failed to get response from virtualDiskInit <<<<<");
            return ERROR;
        }

        if ( ($ret{STATUS} != PI_GOOD) && ( $controller->PI_ERROR_INIT_IN_PROG != $ret{ERROR_CODE} ) )
        {
            # if call returned an error
            logInfo(">>>>> Error from virtualDiskInit <<<<< " .
            "ERROR---VD Raid_ID $Raid_Array[$i] was NOT Initialized");
            PrintError(%ret);
            return ERROR;
        }

        # no error from virtualDiskInit

        logInfo("Initialize started on VD Raid_ID $Raid_Array[$i]");
    }

    # done, then
    return GOOD;
}

##############################################################################
#
#          Name: DisassocOne
#
#        Inputs: controller, SID, LUN
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Attempt to undo any existing configuration and restore
#                the controllers to a specific starting point. Ie.,
#                do wipe_clean even though we can't. Second controller
#                is optional
#
#
##############################################################################
sub DisassocOne
{
    trace();
    my ($ctlr, $sid, $lun, $vdd) = @_;


    logInfo("Disassociating LUN $lun (vdisk $vdd) from SID $sid");

    my %rsp = $ctlr->serverDisassociate($sid, $lun, $vdd);


    if (!%rsp)                        # no response
    {
        logInfo(">>>>> Failed to receive a response from serverdisAssociate <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} == 1)            # 1 is bad
    {
        logInfo(">>>>> Failed: serverdisAssociate returned an error <<<<<");
        PrintError(%rsp);
        logInfo("Failure with LUN $lun, SERVER $sid, VDISK $vdd");
        return ERROR;
    }
    logInfo("done.");
    return GOOD;
}

##############################################################################
#
#          Name: DeleteAllVdisks2
#
#        Inputs: controllerID, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Deletes all vdisks on the specified controller
#                option = 0: delete them all
#                option = 1: delete vlinks only ( VID < 64 )
#                option = 2; delete vdisks only ( VID > 63 )
#
##############################################################################
sub DeleteAllVdisks2
{
    trace();

    my ($ctlr1, $option) = @_;

    my $i;
    my $vdisklist;
    my @vdisklistarray;
    my %rsp;
    my $numVDDs;
    my $r;
    my $ret;

    logInfo("---- Deleting Vdisks ----");

    # get list of vdisks

    %rsp = $ctlr1->getObjectList(PI_VDISK_LIST_CMD);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from PI_VDISK_LIST_CMD <<<<<");
        return ERROR;
    }


    if ($rsp{STATUS} == PI_GOOD)
    {
        logInfo("Virtual Disk List:");
        logObjectList(%rsp);
        # in here is my list of disks.. now how do i extract it?
        # need to build this array >>>> @vdisklistarray = @$vdisklist;       # make an array
    }
    else
    {
        logInfo(">>>>> Unable to retrieve list of virtual disk identifiers. <<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    # put drives into an array
    for ( $r=0; $r< $rsp{COUNT}; $r++)
    {
        push  @vdisklistarray, $rsp{LIST}[$r];
    }

    #######
#    @vdisklistarray = GetVdiskList( $ctlr1 );
#    if ( $vdisklistarray[0] == INVALID )
#    {
#        print ">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<\n";
#        return ERROR;
#    }
#    $numVDDs = scalar (@vdisklistarray);  # of drives available to map
    #######
    $numVDDs = $rsp{COUNT};  # of drives available to map

    for ( $i = 0 ;$i < $numVDDs; $i++ )
    {
        debug("Looking at $vdisklistarray[$i]");

        $ret = GOOD;

        if ( $option == 0 )    # delete them all
        {
            logInfo("Deleting $vdisklistarray[$i]");
            $ret = BreakVlink($ctlr1, $vdisklistarray[$i]);
            $ret = DeleteSingleVdisk($ctlr1, $vdisklistarray[$i]);
        }

        if ( ($option == 1)  && ($vdisklistarray[$i] < 64) )       # delete vlinks
        {
            logInfo("Deleting $vdisklistarray[$i]");
            $ret = DeleteSingleVdisk($ctlr1, $vdisklistarray[$i]);
        }

        if (( $option == 2 ) && ($vdisklistarray[$i] > 63) )       # delete real VDDs
        {
            logInfo("Deleting $vdisklistarray[$i]");
            $ret = DeleteSingleVdisk($ctlr1, $vdisklistarray[$i]);
        }

        if ( $ret == ERROR )
        {
            return ERROR;
        }
    }


    return GOOD;
}


##############################################################################
#
#          Name: DeleteSingleVdisk
#
#        Inputs: Controller,vdisk number
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: de;letes a vdisk
#
#
##############################################################################

sub DeleteSingleVdisk
{
    trace();
    my ($ctlr, $vid) = @_;

    my %rsp;

    #logInfo("Deleting $vid");
    %rsp = $ctlr->virtualDiskDelete($vid);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from virtualDiskDelete <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Unable to delete virtual disk $vid. <<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: GetUsedLuns
#
#        Inputs: Controller, server number, option
#
#       Outputs: Arry of LUNS, INVALID otherwise
#
#  Globals Used: none
#
#   Description: option 0 or undef = all LUNs
#                                1 = only those for vlinks
#
#
##############################################################################

sub GetUsedLuns
{
    trace();
    my ($ctlr, $id, $option) = @_;
    my @luns;
    my @map;
    my @usedLuns;
    my $validLuns;

    my $k;

    if ( !$option )
    {
        $option = 0;
    }

    my $str = "---- Server $id Information ---- \n";

    my %serverinfo = $ctlr->serverInfo($id);

    if (%serverinfo)
    {

        debug("%serverinfo " . %serverinfo);
        while((my $k, my $v) = each %serverinfo)
        {
            debug("$k = $v");
        }
    }
    else
    {
        logWarning(">>>>> Failed to get information for server $id <<<<<");
        push ( @usedLuns, INVALID );
        return @usedLuns;
    }

    if ( 0 == $serverinfo{NLUNS} )
    {
        # nothing mapped
        push ( @usedLuns, INVALID );
        return @usedLuns;
    }

    $validLuns = 0;

    for (my $i = 0; $i < $serverinfo{NLUNS}; $i++)
    {
        $str =  "  ";
        $str .= sprintf "%3d", $serverinfo{LUNMAP}[$i]{LUN};
        $str .=  "   ";
        $str .= sprintf "%3d", $serverinfo{LUNMAP}[$i]{VID};
        $str .=  "\n";
        if ( ($serverinfo{LUNMAP}[$i]{VID} < 64 ) || ($option == 0) )
        {
            # push vlinks or all if option = 0
            push ( @usedLuns, $serverinfo{LUNMAP}[$i]{LUN} );
            $validLuns++;
        }
    }
    logInfo($str);


    logInfo("On SID $id, these LUNs are used: @usedLuns");

    if ( $validLuns == 0 )
    {
        push ( @usedLuns, INVALID );
    }

    return @usedLuns;
}
##############################################################################
#
#          Name: GetAssociatedVdisk
#
#        Inputs: Controller, server number, lun
#
#       Outputs: corresponding vdisk number, INVALID otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################

sub GetAssociatedVdisk
{
    trace();
    my ($ctlr, $id, $lun) = @_;
    my @map;
    my $vdd;

    my $k;


    my $str = "---- Server $id Information ---- \n";

    my %serverinfo = $ctlr->serverInfo($id);

    if (%serverinfo)
    {

        debug("%serverinfo " . %serverinfo);
        while((my $k, my $v) = each %serverinfo)
        {
            debug("$k = $v");
        }
    }
    else
    {
        logWarning(">>>>> Failed to get information for server $id <<<<<");
        return INVALID;
    }

    if ( 0 == $serverinfo{NLUNS} )
    {
        # nothing mapped
        return INVALID;
    }


    for (my $i = 0; $i < $serverinfo{NLUNS}; $i++)
    {
        if ( $lun == $serverinfo{LUNMAP}[$i]{LUN} )
        {

print ("LUN $lun is associated to VDISK $serverinfo{LUNMAP}[$i]{VID} \n");

            return $serverinfo{LUNMAP}[$i]{VID};
        }

    }

    # didn't match LUN number
    return INVALID;
}

##############################################################################
#
#          Name: DisassocAll
#
#        Inputs: controller , option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Attempt to undo any existing configuration and restore
#                the controllers to a specific starting point. Ie.,
#                do wipe_clean even though we can't. Second controller
#                is optional
#
#                option = 0 or undef  ...... ALL LUNs
#                option = 1 ..... VLINKS only
#
#
##############################################################################
sub DisassocAll
{
    trace();
    my ($ctlr, $option) = @_;

    my $i;
    my $j;
    my $ret;
    my @sids;
    my %rsp;
    my $vdd;

    if ( !$option )
    {
        $option = 0;
    }

    # first, get the number of SIDs and exit cleanly if none are found

    %rsp = $ctlr->serverCount();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from serverCount <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from serverCount <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    if ( $rsp{COUNT} < 1 )
    {
        logInfo("No SIDs found to use (probably not an error)");
        return GOOD;
    }

    # now get a list of SIDs to use

    @sids = GetSIDs( $ctlr, 0 );

    if ( $sids[0] == INVALID )
    {
        logWarning(">>>>> Failed: Unable to get SIDs for dissasoc. or No SIDs found <<<<<");
        return ERROR;
    }

    for ( $i = 0; $i < scalar(@sids); $i++ )
    {
        my @luns = GetUsedLuns( $ctlr, $sids[$i], $option);

        if ( $luns[0] != INVALID )
        {
            # if there are any luns on this server...

            logInfo(scalar(@luns) . " LUNs to dissassociate");

            for ( $j = 0; $j < scalar(@luns); $j++ )
            {
                $vdd = GetAssociatedVdisk ($ctlr, $sids[$i], $luns[$j]);

                $ret = DisassocOne( $ctlr, $sids[$i], $luns[$j], $vdd );                           # oops
                if ( $ret == ERROR )
                {
                    return ERROR;
                }
            }
        }
    }
    return GOOD;
}

##############################################################################
#
#          Name: SelectMapOption
#
#        Inputs: current mapping option
#
#       Outputs: new option, if successful, INVALID otherwise
#
#  Globals Used: none
#
#   Description: prompt the user and gat an input.
#
#
##############################################################################
sub SelectMapOption
{
    trace();
    my ( $current ) = @_;
    print "\n\nOptions for mapping vdisks are: \n";
    print "   1) alternate between two user selected servers \n";
    print "   2) allocated among supplied WWNs \n";
    print "   3) TBD \n";
    print "   4) TBD \n";
    print "\n$current is presently selected\n";
    print "\n\nEnter your  choice: ";

    my $ans = <STDIN>;
    chomp ($ans);

    if ( $ans > 4 || $ans < 1 )
    {
        # bad choice
        return INVALID;
    }

    # answer is in range, use it
    return $ans;
}

##############################################################################
#
#          Name: FindServerMates
#
#        Inputs: $controller,            A controller object
#                $SidPtr,                ref to list of SIDs
#                $matePtr                ref to empty list
#
#       Outputs: GOOD or ERROR and a filled array
#
#  Globals Used: none
#
#   Description: Finds the SID that is the dual path mate for each SID.
#
#
##############################################################################
sub FindServerMates
{
    my ($ctlr, $sidPtr, $matePtr) = @_;

    my $i;
    my $t;
    my $s;
    my $pn;
    my $nn;
    my $targ;
    my $mate;
    my $mateSid;
    my $node;
    my $sid;
    my $tid;
    my $flag = 0;
    my %info;

    my $server;

    my @portData;
    my @portSize;
    my @portValid;
    my %rsp;


    my $debug = 0;                      # flag for debugging this code



    # init the output array to all INVALID entries
    for ( $i = 0; $i < scalar(@$sidPtr); $i ++)
    {
        # this defaults the array to show no mates. If anything fails
        # after this, the array is at least initialized and won't
        # cause any funny side effects

        $$matePtr[$i] = INVALID;
    }

#return GOOD;

    # do "devicelist fe #" on all 4 FE ports to learn what is seen
    # This builds a mapping between port WWN and node WWN with a separate map
    # for each target


    for ( $i = 0; $i < 4; $i++ )
    {
        # Validate port and check if it is ISCSI or FC based on which devicelist 
        # values are retrieved
        
        &TestLibs::iscsi::ValidateTargetType ($ctlr, $i, \$flag); 
        
        if ($flag == 1)
        {
            %rsp = $ctlr->deviceList("FE", $i);

            if ( !%rsp )
            {
                # no response
                logInfo("Failure to get FE devicelist on channel $i.");
                return ERROR;
            }

            if ($rsp{STATUS} != PI_GOOD)
            {
                if ( $rsp{ERROR_CODE} != 0x36 )     # ignore, 36 = no card
                {
                    # returned an error
                    logInfo("Error getting FE devicelist on channel $i.");
                    PrintError(%rsp);
                    return ERROR;
                }
                else
                {
                    $portValid[$i] = INVALID;
                    next;
                }
            }

            # got the data, for each line,

            $portSize[$i] =  $rsp{NDEVS};
            $portValid[$i] = GOOD;

            if ( $debug == 1)
            {
                printf ("Port $i: PortSize =  %04x , portValid = %04x \n", $portSize[$i], $portValid[$i] );
            }

            for ( $t = 0; $t < $rsp{NDEVS}; $t++ )
            {
                # get the port name (2 bytes)

                $pn =   $rsp{LIST}[$t]{PORT_WWN_HI} % 65536;

                # get the node name (2 bytes)

                $nn =   $rsp{LIST}[$t]{NODE_WWN_HI} % 65536;

                # add to data structure

                $portData[$i][$t]{PORT} = $pn;
                $portData[$i][$t]{NODE} = $nn;

                if ( $debug == 1)
                {
                    printf("        Dev $t: Port = %04x,   Node = %04x \n", $pn, $nn );
                }

            } # End of for loop 3
        }
    } # End of for loop 2


    # do a servers to get a nice mapping of SIDs and TIDs

    %info = $ctlr->servers();

    if ( !%info )
    {
        # no response
        logInfo("Failure to get servers data.");
        return ERROR;
    }

    if ($info{STATUS} != PI_GOOD)
    {
        # returned an error
        logInfo("Error getting servers data.");
        PrintError(%info);
        return ERROR;
    }

    # now we have all the needed data in or hands, for each server, we
    # are working with , find its mate

    if ( $flag == 1 )
    { 
        for ( $sid = 0; $sid < scalar(@$sidPtr); $sid++ )
        {
            $server = $sidPtr->[$sid];

            #print "server is $server\n";

            # got the SID, now identify the TID it is one

            $tid = INVALID ;

            for ( $i = 0; $i < scalar(@{$info{SERVERS}}); $i++ )
            {
                if ( $server == $info{SERVERS}[$i]{SID} )
                {
                    # this gives me the TID and the WWN tag I need.

                   $tid = $info{SERVERS}[$i]{TARGETID};
                    $pn =  ($info{SERVERS}[$i]{WWN_HI} % 65536);

                    last;
                }
            }

            if ( $debug == 1)
            {
                printf ( "Server $server: Target $tid, port %04x  \n", $pn);
            }



            if ( ($tid == INVALID)  )
            {
                # we didn't find the SID. it should be there
                logInfo("Lost a SID while looking for the mate - tid was $tid");
                return ERROR;
            }

#print "target is $tid\n";

        # map the port name to a node name using device list data

        $node = INVALID;

        # search all for dev lists for the port name to node name
        # matching

            for ( $t = 0; $t < 3; $t++ )
            { 
                if (  $portValid[$t] != GOOD )
                {
                    next;      # skip bad ports
                }
    
                for ( $i = 0; $i < $portSize[$t]; $i++ )
                {

                    if ( $debug == 1)
                    {
                        printf( "        Checking ports to find the node %04x ?? %04x (node = %04x)  \n",
                                 $pn, $portData[$t][$i]{PORT}, $portData[$t][$i]{NODE} );
                    }

                    if ( $pn == $portData[$t][$i]{PORT} )
                    {
    
                        # found the matching port name, get its node
                        $node = $portData[$t][$i]{NODE};

                        if ( $debug == 1)
                        {
                            printf ("node is %04x\n", $node);
                        }

                        last;

                    }

                }
                # if we found one, we are done
                if ( $node != INVALID )
                {
                    last;
                }

            }

            if ($node == INVALID)
            {
                # no match on this target, try the next
                last;
            }
        
        # find the other (1st one) port name that has the same
        # node name


        $mate = INVALID;  # indicate no match

        for ( $t = 0; $t < 3; $t++ )
        {
            if (  $portValid[$t] != GOOD )
            {
                next;      # skip bad ports
            }

            for ( $i = 0; $i < $portSize[$t]; $i++ )
            {

                if ( $debug == 1)
                {
                    printf("        Checking nodes to find mate's port %04x ?? %04x (port = %04x)  \n",
                            $node, $portData[$t][$i]{NODE}, $portData[$t][$i]{PORT});
                }

                if ( $node == $portData[$t][$i]{NODE} )
                {


                    if ( $debug == 1)
                    {
                        printf( "        Checking ports %04x ?? %04x (node = %04x)  \n",
                                $pn, $portData[$t][$i]{PORT}, $portData[$t][$i]{NODE} );
                    }

                    # found the matching node name, check its port
                    if ( $pn != $portData[$t][$i]{PORT} )
                    {
                        # found a different port on the node
                        # this is what we want
                        $mate = $portData[$t][$i]{PORT};

                        if ( $debug == 1)
                        {
                            printf( "        Found matching port %04x   \n",
                                    $mate );
                        }


                        # stop looking
                        last;
                    }
                }

            }
        }


    #printf ("mate is %04x \n", $mate);

            if ( $mate == INVALID )
            {
                # we didn't find a mate, go on to the next SID
                next;
            }

            # we know the WWN of the mate, now lets find out which SID
            # he is.

            my $nsrv;

            $nsrv = scalar(@{$info{SERVERS}});

            $mateSid = INVALID;

            for ( $i = 0; $i < $nsrv; $i++ )
            {

                my $x;
                my $y;

                # the mask should be 0xfd if using 4 FE ports and 0xfc if
                # only 2 fe ports

                $x = $tid & 0xfd;
                $y = $info{SERVERS}[$i]{TARGETID} & 0xfd;

                if ( $debug == 1)
                {
                    printf ("   comparing %08x to %08x and ",$mate, ($info{SERVERS}[$i]{WWN_HI} % 65536));
                    printf ("   comparing %d to %d  as $x, $y\n",$tid, $info{SERVERS}[$i]{TARGETID});
                }

                if  ( $mate == ($info{SERVERS}[$i]{WWN_HI} % 65536) &&
                    #$tid == $info{SERVERS}[$i]{TARGETID}
                    $x == $y
                     )
                {
                    # this gives me the TID and the WWN tag I need.
    
                   $mateSid =  $info{SERVERS}[$i]{SID};

                    last;
                }
            }

            if ( $debug == 1)
            {
                print "matesid is $mateSid\n";
            }

            # update the mates array

            $matePtr->[$sid] = $mateSid;
        }
    }
    return GOOD;
}

##############################################################################
#
#          Name: AssociateServers
#
#        Inputs: controllerID, strategy, wwn
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Associated drives to servers based on strategy.
#
#                The following strategies may happen.
#
#                1) Alternate - justs walks the list of drives assigning
#                first to one, then the other and repeating. The drives
#                should be created in the desired order. (2 servers only)
#
#                2) Associate vdisks by SID to each server listed in wwn 
#                array
#
#                3) Associate vdisks by SID to each server that has the 
#                wwn of the first in the wwn array
#
#                4) Associate vdisks to each SID that has the wwn of the  
#                first wwn in the wwn array.  Vdisks are spread across   
#                owning controllers.  ie. First vdisk is assigned to a SID     
#                owned by the first controller, 2nd vdisk to a SID owned
#                by the 2nd controller, etc, repeating thru controllers 
#                until all vdisks are associated.
#
#                n+1-?) Whatever Mike can dream up.
#
#
#                Some will use default servers, others wil use managed
#                servers. Those will clear the new bit
#
#                If multiple paths exist to a server, each path will get
#                drives associated. This will be done by bulding a list
#                of the paths to the server(s) and alternating the servers
#                in a combined list. The disks will be distributed based
#                upon the number of seen paths to servers.
#
#
##############################################################################
sub AssociateServers
{
    trace();
    my ($controller, $strategy, $wwn ) = @_;

    # variables I use
    my $numberToAssoc;
    my $r;
    my $ret;
    my $retn;
    my $numVDDs;
    my $server;           # working server number
    my $lun;              # working lun number
    my $s1lun = 0;        # current lun number on server
    my $s2lun = 0;        # current lun number on server
    my $count1;
    my $count2;
    my $vdisklist;
    my @vdisklistarray;
    my $remaining;
    my $numSids;
    my $Server_IDs;
    my $ans;
    my $r1;
    my $r2;
    my @wwn2;
    my @wwnList;
    my @serverMates;
    my @SIDUsed;
    my @SIDOwner;
    my $i;
    my $j;
    my $foundIt;
    my @ownersUsed;
    my $numOwners;
    my $skipped;
    my $numUsedSIDs;

    my %rsp;
    my %info;

    # dummys for the compile, re-declared later
    my @AServer;
    my @Lun;
    my @VDisk;
    my @Select_Server_ID;

    debug("in assoc with $controller, $strategy");

    # need to get the SIDs to use. This could be passed in, but
    # then the callers needs to know the SID, or the caller can
    # spec a WWN tail and we can can the serverlist for matching
    # WWNs and determine the SID ourselves.

    if ( $strategy == 1 )
    {
        # Ask user for 2 SIDs
        @Select_Server_ID = SelectServers( $controller, 2 );
    }
    elsif ( $strategy == 2 )
    {
        # find SIDs based on wwn list
        @Select_Server_ID = FindSIDs( $controller, 0, $wwn);
    }
    elsif ( ( $strategy == 3 )  || ( $strategy == 4 ) ) 
    {
        # find SIDs based upon 1st wwn in the list only

        @wwnList = @$wwn;

    logInfo ("first server are  @wwnList\n");
    logInfo ("server is $wwnList[0]\n");
        %{$wwn2[0]} = %{$wwnList[0]};
    logInfo ("servers are @wwn2\n");
        @Select_Server_ID = FindSIDs( $controller, 0, \@wwn2);
    }
 
    if ( ! @Select_Server_ID )
    {
        # we've got no server list, exit without error
        logInfo("We have no servers to work with, no associations can be done. ");
        logInfo("This may or may not be an error to look at");
        return GOOD;
    }

    logInfo("received @Select_Server_ID");

    # the next line generates an error if no matching servers were found.
    # need to bail out in that case, or go into prompt mode.

    if ( INVALID == $Select_Server_ID[0] )
    {
        logWarning(">>>>> Failed to get server number(s) <<<<<");
        return ERROR;
    }

#print "calling servermates with these servers: @Select_Server_ID \n";

    $ret = FindServerMates($controller, \@Select_Server_ID, \@serverMates);
    if ( $ret != GOOD )
    {
        logInfo("Error finding server mates.");
        logInfo("   Servers found: @Select_Server_ID ");
        logInfo("   the Mates: @serverMates ");
    }

print "--------------- servermates----------------\n";

for ( $r = 0; $r < scalar(@Select_Server_ID); $r++)
{
print " index: $r  SID: $Select_Server_ID[$r], mate: $serverMates[$r] \n";
}
print "--------------- servermates----------------\n";

#return GOOD;



    # discover what VDDs are there and how they are labeled (    )
        # assume there are some physical drives for the moment

    # get list of vdisks

    %rsp = $controller->getObjectList(PI_VDISK_LIST_CMD);

    if ( ! %rsp  )
    {
        logInfo(">>>>> Failed to get response from PI_VDISK_LIST_CMD <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} == PI_GOOD)
    {
        logInfo("Virtual Disk List");
        logObjectList(%rsp);
        # in here is my list of disks.. now how do i extract it?
        # need to build this array >>>> @vdisklistarray = @$vdisklist;       # make an array
    }
    else
    {
        logInfo(">>>>> Unable to retrieve list of virtual disk identifiers. <<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    #debug("the disks " . $rsp{LIST}[2]);
    #debug("this many " . $rsp{COUNT});

    # put drives into an array
    for ( $r=0; $r< $rsp{COUNT}; $r++)
    {
        push  @vdisklistarray, $rsp{LIST}[$r];
    }

    $numVDDs = $rsp{COUNT};  # of drives available to map

    # group drives, possibly according to strategy - just data manipulation

    debug("this many $numVDDs, of this  @vdisklistarray");

    #
    # This is done by making arrays for the vdisk's association parms
    # and then walking the arrays to map the individual vdisks. The
    # content of the arrays is based upon the strategy passed in.
    #

    if ( $strategy == 1 )
    {
        ###########################################
        # 1 - alternates drives between 2 servers
        #     assume they were created as desired
        ###########################################

        $r = $numVDDs;
        $count1 = 0;
        $count2 = 0;
        while ( $r > 0)
        {
            push @AServer, $Select_Server_ID[0];                  # Server to Assoc
            push @Lun, $count1;                    # Lun to use
            push @VDisk, $vdisklistarray[$count2]; # vdisk to use

            debug("map added $Select_Server_ID[0], $count1, $vdisklistarray[$count2], $r, $count2, $count1");

            $r--;         # decrement  vdds to do
            $count2++;    # increment vdd array index
                          # don't incr lun count

            if ( $r > 0 )     # if still more (second of pair)
            {
                push @AServer, $Select_Server_ID[1];                  # Server to Assoc
                push @Lun, $count1;                    # Lun to use
                push @VDisk, $vdisklistarray[$count2]; # vdisk to use

                debug("map added $Select_Server_ID[1], $count1, $vdisklistarray[$count2], $r, $count2, $count1");

                $r--;         # decrement  vdds to do
                $count2++;    # increment vdd array index
                $count1++;    # increment to next lun
            }
        }
    }

    elsif ( ($strategy == 2) || ( $strategy == 3 ))
    {
        ###########################################
        # 2 - alternates drives between 2 servers
        #     assume they were created as desired
        #     AUTO SERVER SELECT
        ###########################################

        $r = $numVDDs;
        $count1 = 0;
        $count2 = 0;
        while ( $r > 0)
        {
            # map each drive
            for ( $r2 = 0; $r2 < scalar(@Select_Server_ID); $r2++)
            {
                # go thru the list of SID mapping drives if there are any left
                if ( $r > 0)
                {
                    push @AServer, $Select_Server_ID[$r2]; # Server to Assoc
                    push @Lun, $count1;                    # Lun to use
                    push @VDisk, $vdisklistarray[$count2]; # vdisk to use

                    if ( $serverMates[$r2] >= 0 )
                    {
                        push @AServer, $serverMates[$r2]; # Server to Assoc
                        push @Lun, $count1;                    # Lun to use
                        push @VDisk, $vdisklistarray[$count2]; # vdisk to use
                    }


                    $r--;         # decrement  vdds to do
                    $count2++;    # increment vdd array index
                                  # don't incr lun count
                }
            }
            $count1++;    # increment to next lun
        }
    }

    elsif ($strategy == 4) 
    {
        ###########################################
        # 4 - assign vdisks to each server id 
        #     spreading vdisks across each owning
        #     controller.
        ###########################################

        #
        # Determine owning controller for each server id in array
        # and initialize arrays used to track which has already been used.
        #
        %info = $controller->servers();
        if ( !%info )
        {
            logInfo(">>>>> Failure to get servers data <<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>> Error getting servers data <<<<<");
            PrintError(%info);
            return ERROR;
        }

        for ( $i = 0; $i < scalar(@Select_Server_ID); $i++ )
        {
            $foundIt = 0;
            for ($j = 0; $j < $info{COUNT}; ++$j)
            {
                if ( $Select_Server_ID[$i] == $info{SERVERS}[$j]{SID} ) 
                {
                    $SIDOwner[$i] = $info{SERVERS}[$j]{OWNER};
                    $foundIt = 1; 
                }
            }
            if ( $foundIt == 0 )
            {
                logInfo(">>>>> No owner found for Server ID $Select_Server_ID[$i]<<<<<");
                return ERROR;
            }
            $SIDUsed[$i] = 0;
            
            #
            # Create separate array of just all the owners so we can find out
            # how many owners there are.
            #
            if ( !IsInList( $SIDOwner[$i], \@ownersUsed ) )
            {
                push( @ownersUsed, $SIDOwner[$i] ); 
            }
        }

        #
        # determine how many owners there are and then clear out array
        #
        $numOwners = scalar( @ownersUsed );
        @ownersUsed = ();

        #
        # Now loop thru each vdisk and match to a SID
        # 
        $r = $numVDDs;
        $count1 = 0;
        $count2 = 0;
        $numUsedSIDs = 0;
        while ( $r > 0)
        {
            #
            # Go thru each SID
            #
            for ( $r2 = 0; $r2 < scalar(@Select_Server_ID); $r2++)
            {
                # 
                # check to see if there are any vdisks left
                #
                if ( $r > 0)
                {
                    #
                    # If SID has already been taken, increment skipped and continue.
                    # If not, check the owner
                    #
                    if ( $SIDUsed[$r2] == 0 )
                    {
                        #
                        # Check to see if owning controller has already been used
                        #
                        if ( !IsInList( $SIDOwner[$r2], \@ownersUsed ) ) 
                        {
                            push( @ownersUsed, $SIDOwner[$r2] );  # owner used 
                           
                            push @AServer, $Select_Server_ID[$r2]; # Server to Assoc
                            push @Lun, $count1;                    # Lun to use
                            push @VDisk, $vdisklistarray[$count2]; # vdisk to use

                            if ( $serverMates[$r2] >= 0 )
                            {
                                push @AServer, $serverMates[$r2]; # Server to Assoc
                                push @Lun, $count1;                    # Lun to use
                                push @VDisk, $vdisklistarray[$count2]; # vdisk to use
                            }

                            $numUsedSIDs++;
                            $SIDUsed[$r2] = 1;
                            $skipped = 0;
                            $r--;         # decrement  vdds to do
                            $count2++;    # increment vdd array index
                                          # don't incr lun count
                                          
                            #
                            # If we have been thru each possible owner, clear the 
                            # owners array so we start over
                            #
                            if ( scalar( @ownersUsed ) >= $numOwners )
                            {
                                @ownersUsed = ();
                            }
                             
                            #
                            # If we have used all select SIDs, clear the SIDUsed
                            # array so we start over
                            #
                            if ( $numUsedSIDs >= scalar(@Select_Server_ID) )
                            {
                                for ( $i = 0; $i < scalar(@Select_Server_ID); $i++ )
                                {
                                    $SIDUsed[$i] = 0;   
                                }
                                $numUsedSIDs = 0;
                            }
                        }
                        else 
                        {
                            #
                            # This SID's owner has already been used.
                            # Skip it for now
                            #
                            $skipped++;
                        }                                          
                    }
                    else
                    {
                        #
                        # This SID has already been used.
                        # Skip it for now
                        #
                        $skipped++;
                    }
                }

                #
                # Been thru all SIDs and not found an unused SID with an unused 
                # owners.  Clear the ownersUsed array so that it will take the 
                # next unused SID, even if it has the same owner, and continue.
                #
                if ( $skipped >= scalar(@Select_Server_ID) )
                {
                    @ownersUsed = ();
                }  
            }
            $count1++;    # increment to next lun
        }
    }

    else
    {
        #########################
        # you have chosen badly
        #########################
        logWarning(">>>>> Unavailable strategy specified. Sorry, no vdisks mapped. <<<<<");
        return ERROR;

    }

    # figure out how many to map, based upon smallest array size. This helps
    # when we miscount the number of elements in an array.
    $numberToAssoc = min( scalar(@AServer), min(scalar(@Lun), scalar(@VDisk) ) );


    debug("number of vdisks to associate $numberToAssoc");

    # now actually associate the vdisks
    for( $r = 0; $r < $numberToAssoc; $r++)
    {
        # first, is this disk ready for use. (devstat = 0x10)
        if ( 0 != CheckInitProgress($controller, $VDisk[$r] ) )
        {
            logInfo("Waiting for vdisk $VDisk[$r] to become operational");

            while ( 0 != ( $remaining = CheckInitProgress($controller, $VDisk[$r] ) ) )
            {
                print " $remaining percent left to initialize \r";
                # pause for a second or 2
                sleep 2;
            }
        }

        debug("mapping vdisk using  $AServer[$r], $Lun[$r], $VDisk[$r] ");
#print "         AssociateSingleVdisk($controller, $AServer[$r], $VDisk[$r], $VDisk[$r]) \n";
        $ret = AssociateSingleVdisk($controller, $AServer[$r], $VDisk[$r], $VDisk[$r]);
        if ( $ret == ERROR )
        {
            logWarning(">>>>> Failed mapping Vdisk <<<<<");
            return (ERROR);
        }
    }

    # drives mapped, but these are 'new' servers. need to change state

# no longer needed
#    for( $r = 0; $r < scalar(@Select_Server_ID); $r++)
#    {
#        # clear the new bit on all servers we just mapped to
#        $ret = SetServerProp($controller, $Select_Server_ID[$r]);
#        if ( $ret == ERROR )
#        {
#            logError(">>>>> Failed to clear new bit on server <<<<<");
#            return (ERROR);
#        }
#    }

    # done (maybe print a list)
    return GOOD;
}

##############################################################################
#
#          Name: SelectServers
#
#        Inputs: controller, number of servers needed
#
#       Outputs: an array of servers, INVALID if failure
#
#  Globals Used: none
#
#   Description: Associates the specified vdisk to the specified server and
#                lun.
#
#
##############################################################################
sub SelectServers
{
    trace();
    my ($controller, $count ) = @_;

    # variables I use
    my $ret;
    my %rsp;
    my $numSids;
    my $retn;
    my $Server_IDs;
    my $ans;
    my @Select_Server_ID;
    my $r1;

    logInfo("in select servers with $controller, $count");

    # need to get the SIDs to use. This could be passed in, but
    # then the callers needs to know the SID, or the caller can
    # spec a WWN tail and we can can the serverlist for matching
    # WWNs and determine the SID ourselves.
    $ret = 1;
    while ( $ret == 1 )
    {
        # get list of servers (serverlist)
        %rsp = $controller->getObjectList(PI_SERVER_LIST_CMD);

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                debug("Got server list successfully.");
            }
            else
            {
                logInfo(">>>>> Failed to get server list <<<<<");
                PrintError(%rsp);
                push @Select_Server_ID, INVALID;
                return @Select_Server_ID;
            }
        }
        else
        {
            logInfo("Did not receive a response packet getting server list");
            push @Select_Server_ID, INVALID;
            return @Select_Server_ID;
        }

        $numSids = $rsp{COUNT};

        $retn = ListSIDs($controller, 0);
        if ( GOOD != $retn )                # if no return from call
        {
            logWarning(">>>>> Failed to get server list to display <<<<<");
            push @Select_Server_ID, INVALID;
            return @Select_Server_ID;
        }

        print "\nSelect $count server ID's, separated by a space: \n";
        $Server_IDs = <STDIN>;
        chomp($Server_IDs);

        print "You Entered $Server_IDs, is this correct? (Y/N): \n";
        $ans = <STDIN>;
        chomp($ans);
        if(($ans eq "Y") || ($ans eq "y"))
        {
            debug("validating response");

            @Select_Server_ID = split(/ /, $Server_IDs);
            $ret = 0;
            # check for right number of entries
            if ( $count !=  scalar(@Select_Server_ID) )
            {
                logWarning("you must enter $count numbers");
                $ret = 1;
            }
            # check each entry to be in the list
            for($r1 = 0; $r1 < scalar(@Select_Server_ID); $r1++)
            {

                debug("checking ($r1) $numSids > $Select_Server_ID[$r1]");
                if( $numSids > $Select_Server_ID[$r1] )
                {
                    #--do nothing  SID is OK
                    print "$Select_Server_ID[$r1] is OK \n";
                }
                else
                {
                    $ret = 1;
                    print "$Select_Server_ID[$r1] is not available, try again \n";
                }
            }
        }
    }

    #  SIDs will probably need to be in an array...
    return @Select_Server_ID;
}

##############################################################################
#
#          Name: FindSIDs
#
#        Inputs: controller, option, ptr to list of WWNs
#
#       Outputs: an array of servers, INVALID if failure
#
#  Globals Used: none
#
#   Description: deretmines which SIDs are connected to specific WWNs
#
#
##############################################################################
sub FindSIDs
{
    trace();
    my ($controller, $option, $wwnlist ) = @_;

    # variables I use
    my $ret;
    my %rsp;
    my $numSids;
    my $retn;
    my $Server_IDs;
    my $ans;
    my @Select_Server_ID;
    my $r1;
    my $r;
    my @SIDarray;
    my %thisWWN;
    my $count;

    # need to get the SIDs to use. This could be passed in, but
    # then the callers needs to know the SID, or the caller can
    # spec a WWN tail and we can can the serverlist for matching
    # WWNs and determine the SID ourselves.

    # get list of servers (serverlist)
    %rsp = $controller->getObjectList(PI_SERVER_LIST_CMD);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            #print " Got server list successfully.\n";
        }
        else
        {
            logInfo(">>>>> Failed to get server list <<<<<");
            PrintError(%rsp);
            push @Select_Server_ID, INVALID;
            return @Select_Server_ID;
        }
    }
    else
    {
        logInfo("Did not receive a response packet getting server list");
        push @Select_Server_ID, INVALID;
        return @Select_Server_ID;
    }

    $numSids = $rsp{COUNT};
 
    if ( $numSids == 0 )
    {
        return @Select_Server_ID;       # empty array
    }

    $count = 0;              # counter for # of matching SIDs

    # Get an array of the SIDs
    for ( $r=0; $r < $numSids; $r++ )
    {
        push @SIDarray, $rsp{LIST}[$r];
    }


    for ( $r = 0; $r < $numSids; $r++ )
    {
        # do serverinfo
        %rsp = $controller->serverInfo($SIDarray[$r]);

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                #print " Got server info $SIDarray[$r] successfully.\n";
            }
            else
            {
                logInfo(">>>>> Failed to get server info $SIDarray[$r] <<<<<");

                PrintError(%rsp);

                push @Select_Server_ID, INVALID;

                return @Select_Server_ID;
            }
        }
        else
        {
            logInfo("Did not receive a response packet getting server info $SIDarray[$r]");

            push @Select_Server_ID, INVALID;

            return @Select_Server_ID;
        }

        debug("server info    " . %rsp);

        debug(sprintf " Server(SID) %3d has (TID=%3d) WWN %256s  ", $r,
                $rsp{TARGETID},  $rsp{WWN});

        # now check to see if the WWN is in the list

        $thisWWN{WWN} = $rsp{WWN};

        #print("this wwn is %thisWWN");
        $r1 = CheckWWN(\%thisWWN, $wwnlist);
        if ( $r1 == GOOD )
        {
            # it was, save the SID
            push @Select_Server_ID, $SIDarray[$r];
            $count++;
        }
    }

    if ( $count == 0 )
    {
        logWarning(">>>>> Failed: Did not find matching SIDs. <<<<<");
        push @Select_Server_ID, INVALID;
    }

    logInfo("matching servers ids (SID): @Select_Server_ID");

    # note, if none were found, this will be an error condition inthe caller
    # need to return INVALID if none were found, or forse the caller
    # to go into prompt mode.

    return @Select_Server_ID;
}
##############################################################################
#
#          Name: CheckWWN
#
#        Inputs: wwn to find, list to search
#
#       Outputs: The list, or undef if not successful
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
#
#sub  CheckWWN
#{
#    my ( $thisWWN, @wwnlist) = @_;
#
#    my $wwn;
#    my $r;
#    my @match;
#
#    for( $r = 0; $r < scalar(@wwnlist) ; $r++)
#    {
#        $wwn = $wwnlist[$r];
#
#        if ( $thisWWN == $wwn )
#        {
#            return GOOD;
#        }
#    }
#
#    return ERROR;
#
#}
##############################################################################
#
#          Name: AssociateSingleVdisk
#
#        Inputs: controller, server, lun, vdisk
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Associates the specified vdisk to the specified server and
#                lun.
#
#
##############################################################################
sub AssociateSingleVdisk
{
    trace();

    my ($controller, $server, $lun, $vd) = @_;
    debug("Mapping Server ID $server, Lun $lun, VD_ID $vd");

    my %info = $controller->serverAssociate($server, $lun, $vd);

    if (!%info)                        # no response
    {
        logInfo(">>>>> Failed to receive a response from serverAssociate <<<<<");
        return ERROR;
    }

    if ($info{STATUS} == 1)            # 1 is bad
    {
        logInfo(">>>>> Failed: serverAssociate returned an error <<<<<");
        PrintError(%info);
        logInfo("Failure with VDISK $vd, LUN $lun, SERVER $server");
        return ERROR;
    }

    if($info{STATUS} == 0)             # 0 is good
    {
        logInfo("VDISK $vd is mapped using LUN $lun to SERVER $server");
    }

    return GOOD;
}

##############################################################################
#
#          Name: CheckInitProgress
#
#        Inputs: controller, vdisk
#
#       Outputs: 0 if done, else percent remaining to init
#
#  Globals Used: none
#
#   Description: Checks vdisk status to see if init is running. If so,
#                returns amount left to do. Else returns 0 to indicate
#                not running (not started, or done).
#
#
##############################################################################
sub CheckInitProgress
{
    trace();
    my ($controller, $vdd) = @_;

    my $status;
    my $r;
    my @RIDarray;
    my $numRIDs;
    my $rtn;

    my %rsp = $controller->virtualDiskInfo($vdd);

    debug(" vdi " . %rsp);

    if ( ! %rsp )
    {
        logWarning(">>>>> Failed to get vdisk status <<<<<");
        return (100);          # fake it as we have a problem
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logWarning(">>>>> Error getting vdisk status <<<<<");
        return (100);          # fake it as we have a problem
    }

    #this check no longer works. init status is not reflected in the vdisk
    $status = $rsp{DEVSTAT};
#    if ( $status == 0x10 )
#    {
#        logInfo("Vdisk $vdd is ready for use             ");
#        return 0 ;       # disk ready to use
#    }

    debug("dev stat = $status");

    # re got status, but it wasn't 'available' as desired. Now
    # get the raid info to see how much is left to do
    $numRIDs = $rsp{RAIDCNT} +  $rsp{DRAIDCNT};    #Number of RIDs

    # put drives into an array
    for ( $r=0; $r< $numRIDs; $r++)
    {
        push  @RIDarray, $rsp{RIDS}[$r];
    }

    debug("this many rids: $numRIDs, here they are @RIDarray");

    # for now... assume we are initing the disk and just
    # return 50% to go

    # now get completion percent to go for each rid

    for ($r = 0; $r< $numRIDs; $r++)
    {
        # get raidinfo
        my %rsp = $controller->virtualDiskRaidInfo($RIDarray[$r]);

        debug("rid# $r, rdi " . %rsp);

        if ( ! %rsp )
        {
            logWarning(">>>>> Failed to get raidinfo status <<<<<");
            return (100);          # fake it as we have a problem
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logWarning(">>>>> Error getting raidinfo status <<<<<");
            return (100);          # fake it as we have a problem
        }

        $rtn = $rsp{PCTREM};

        debug("complt pc to go = $rtn");

        # check it
        if ( $rtn > 0 )
        {
            # return if non-zero
            return $rtn;
        }
    }
    # The vdisk wasn't operational, but we didn't find a raid doing init
    # return something to force us back thru the loop

    #print "                                                      vdisk status is $status \r";
    if ($status != 0x10 )
    {
        return 99;      #  return, not quite done
    }

    return (0);         # guess we are done
}
##############################################################################
#
#          Name: SetServerProp
#
#        Inputs: controller, serverID
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: clears the new bit by doing serverprop # 0 0
#
#
##############################################################################
sub  SetServerProp
{
    trace();

    my ($controller, $sid) = @_;

    my %rsp = $controller->serverProperties($sid, 0, 0);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo("Properties for Server $sid set successfully");
        }
        else
        {
            logInfo(">>>>> Failed to set properties on server $sid <<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }
    else
    {
        logInfo("Did not receive a response packet setting server properties");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: ListSIDs
#
#        Inputs: controller, startSID
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Lists the servers starting at startSID to allow the user
#                to select SIDs for associating.
#
#    How called: $ret = ListSIDs($master, 0);
#
##############################################################################
sub ListSIDs
{
    trace();
    my $numSIDs;
    my @SIDarray;
    my $r;
    my $sWWN;

    my ($controller, $startSID) = @_;

    # get list of servers (serverlist)
    my %rsp = $controller->getObjectList(PI_SERVER_LIST_CMD);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            debug("Got server list successfully");
        }
        else
        {
            logInfo(">>>>> Failed to get server list <<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }
    else
    {
        logInfo("Did not receive a response packet getting server list");
        return ERROR;

    }

    debug("serverlist info    " . %rsp);

    $numSIDs = $rsp{COUNT};

    for ( $r=0; $r < $numSIDs; $r++ )
    {
        push @SIDarray, $rsp{LIST}[$r];
    }

    debug("this many sids: $numSIDs, here they are @SIDarray");

    # bounds check startSID (can be past end of SID list)
    if ( $numSIDs <= $startSID )
    {
        # return 'no match'
        return INVALID;
    }
    # for each SID

    debug("sid scan fron  $startSID  to  $numSIDs");

    for ( $r = $startSID; $r < $numSIDs; $r++ )
    {
        # do serverinfo
        %rsp = $controller->serverInfo($r);

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                debug("Got server info $r successfully");
            }
            else
            {
                logInfo(">>>>> Failed to get server info $r <<<<<");
                PrintError(%rsp);
                return ERROR;
            }
        }
        else
        {
            logInfo("Did not receive a response packet getting server info $r");
            return ERROR;
        }
        debug("server info    " . %rsp,);

        logInfo(sprintf " Server(SID) %3d has (TID=%3d) WWN %256s  ", $r,
                $rsp{TARGETID},  $rsp{WWN});
    }

    # ran out of SIDs, done
    return GOOD;
}

##############################################################################
#
#          Name: GetSIDs
#
#        Inputs: controller, startSID
#
#       Outputs: and array of SIDs, INVALID otherwise
#
#  Globals Used: none
#
#   Description: Lists the servers starting at startSID to allow the user
#                to select SIDs for associating.
#
#    How called: $ret = ListSIDs($master, 0);
#
##############################################################################
sub GetSIDs
{
    trace();
    my $numSIDs;
    my @SIDarray;
    my $r;
    my $sWWN;
    my @sidList;

    my ($controller, $startSID) = @_;

    # get list of servers (serverlist)
    my %rsp = $controller->getObjectList(PI_SERVER_LIST_CMD);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            debug("Got server list successfully");
        }
        else
        {
            logInfo(">>>>> Failed to get server list <<<<<");
            PrintError(%rsp);
            push (@sidList, INVALID);
            return @sidList;
        }
    }
    else
    {
        logInfo("Did not receive a response packet getting server list");
        push (@sidList, INVALID);
        return @sidList;
    }

    debug("serverlist info    " . %rsp);

    $numSIDs = $rsp{COUNT};

    for ( $r=0; $r < $numSIDs; $r++ )
    {
        push @SIDarray, $rsp{LIST}[$r];
    }

    debug("this many sids: $numSIDs, here they are @SIDarray");

    # bounds check startSID (can be past end of SID list)
    if ( $numSIDs <= $startSID )
    {
        # return 'no match'
        logInfo("No matching SIDs found");
        push (@sidList, INVALID);
        return @sidList;
    }
    # for each SID

    debug("sid scan fron  $startSID  to  $numSIDs");

    for ( $r = $startSID; $r < $numSIDs; $r++ )
    {
        # do serverinfo
        %rsp = $controller->serverInfo($r);

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                debug("Got server info $r successfully");
            }
            else
            {
                logInfo(">>>>> Failed to get server info $r <<<<<");
                PrintError(%rsp);
                push (@sidList, INVALID);
                return @sidList;
            }
        }
        else
        {
            logInfo("Did not receive a response packet getting server info $r");
            push (@sidList, INVALID);
            return @sidList;
        }
        debug("server info    " . %rsp);

        logInfo(sprintf " Server(SID) %3d has (TID=%3d) WWN %256s  ", $r,
                $rsp{TARGETID},  $rsp{WWN});
        push (@sidList, $r);
    }

    # ran out of SIDs, done
    return @sidList;
}

##############################################################################
#
#          Name:Wipe2Clean
#
#        Inputs: controller1, controller2, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: similar to wipe_clean.pl with 2 addresses. Clears config,
#                corrupts BE NVRAM. Does not trash the logs.
#
#
##############################################################################
sub Wipe2Clean
{
    trace();
    my( $ctlr1, $ctlr2, $option ) = @_;

    my $ret;

    #
    # now disable health monitor and failure manager
    #

    $ret = disableHealthMonitor($ctlr1);

    if ( $ret == ERROR )
    {
        logWarning(">>>>> Failed disableHealthMonitor <<<<<");
        return (ERROR);
    }

    if ( $ctlr2 != 0 )
    {
        $ret = disableHealthMonitor($ctlr2  );

        if ( $ret == ERROR )
        {
            logWarning(">>>>> Failed disableHealthMonitor <<<<<");
            return (ERROR);
        }
    }

    $ret = Unconfigure($ctlr1, $option  );

    if ( $ret == ERROR )
    {
        logWarning(">>>>> Failed unconfigure <<<<<");
        return (ERROR);
    }

    if ( $ctlr2 == 0 )
    {
        # done if ctlr2 is 0

        $ret = CorruptBENvram( $ctlr1 );
        if ( $ret == ERROR )
        {
            logWarning(">>>>> Failed corrupting BE NVRAM <<<<<");
            return (ERROR);
        }

        return GOOD;
    }

    $ret = Unconfigure($ctlr2, $option  );

    if ( $ret == ERROR )
    {
        logWarning(">>>>> Failed unconfigure <<<<<");
        return (ERROR);
    }

    $ret = CorruptBENvram( $ctlr1 );
    if ( $ret == ERROR )
    {
        logWarning(">>>>> Failed corrupting BE NVRAM <<<<<");
        return (ERROR);
    }

    $ret = CorruptBENvram( $ctlr2 );
    if ( $ret == ERROR )
    {
        logWarning(">>>>> Failed corrupting BE NVRAM <<<<<");
        return (ERROR);
    }

    return GOOD;
}


##############################################################################
#
#          Name: GetStatePO
#
#        Inputs: controller object#
#       Outputs: Power-on State of the Controller
#
#  Globals Used: none
#
#   Description: Retrieves the power-on state from the controller.
#
#    How called: $ret = GetStatePO($controller);
#
##############################################################################
sub GetStatePO
{
    trace();
    my $state = 0;

    my ($controller) = @_;

    # get list of servers (serverlist)
    my %rsp = $controller->powerUpState();

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            $state = $rsp{STATE};
        }
        else
        {
            logInfo(">>>>> Failed to get power-up state <<<<<");
            PrintError(%rsp);
        }
    }
    else
    {
        logInfo("Did not receive a response packet getting power-up state");
    }

    return $state;
}

# quiet version

sub GetStatePOQ
{
    trace();
    my $state = 0;

    my ($controller) = @_;

    # get list of servers (serverlist)
    my %rsp = $controller->powerUpState();

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            $state = $rsp{STATE};
        }
        else
        {
           # logInfo(">>>>> Failed to get power-up state <<<<<");
           # PrintError(%rsp);
        }
    }
    else
    {
      #  logInfo("Did not receive a response packet getting power-up state");
    }

    return $state;
}

##############################################################################
#
#          Name: WipeControllersClean2
#
#        Inputs: controller1 list pointer, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: similar to wipe_clean.pl. Issues a manufacturing clean,
#                brute force cleaning the drives but NOT clearing the logs.
#                The controllers get reset and then reconnected on exit.
#
#
##############################################################################
sub WipeControllersClean2
{
    trace();
    my( $ctlrPtr ) = @_;

    my $ret;
    my $obj1;

    my @objList;               # turn pointer into an array
    @objList = @$ctlrPtr;

    foreach $obj1 (@objList)
    {
        logInfo "Issuing a MfgClean LICENSE to $obj1->{HOST}";
        my %rsp = $obj1->mfgClean(INIT_CCB_NVRAM_TYPE_LICENSE|0x02|0x04);

        if (!%rsp)
        {
            logInfo(">>>>>>>> No response from mfgClean <<<<<<<<");
            $ret = ERROR;
            last;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo ">>>>>>>> mfgClean failed, Error Code $rsp{ERROR_CODE}. <<<<<<<<";
            $ret = ERROR;
            last;
        }

        $obj1->logout();
    }

    # Sleep here for a bit. The mfgClean is actually a forked call with a
    # delay, so it is possible to reconnect to a controller BEFORE it gets
    # reset.
    sleep 20;

    return TestNReconnectAll($ctlrPtr);
}


##############################################################################
#
#          Name: WipeControllersClean
#
#        Inputs: controller1 list pointer, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: similar to wipe_clean.pl. Clears config,
#                corrupts BE NVRAM. Does not trash the logs.
#
#
##############################################################################
sub WipeControllersClean
{
    trace();
    my( $ctlrPtr, $option ) = @_;

    my $ret;
    my $obj1;
    my $i;
    my $numCtlrs;

    my @objList;               # turn pointer into an array
    @objList = @$ctlrPtr;

    $numCtlrs = scalar(@objList);

    logInfo("Unconfiguring controllers");

    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        if (GetStatePO( $objList[$i] ) == POWER_UP_COMPLETE)
        {
            #  disable cache on controllers
            logInfo("Disabling cache on $i");
            logInfo("You may ignore warnings from slave controllers");
            $ret = DisableCache( $objList[$i] );
        }
    }

    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        if (GetStatePO( $objList[$i] ) == POWER_UP_COMPLETE)
        {
            #  delete server associations on controllers
            logInfo("Disassociate VLINKS on $i");
            $ret = DisassocAll( $objList[$i], 1 );
        }
    }

    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        if (GetStatePO( $objList[$i] ) == POWER_UP_COMPLETE)
        {
            #  delete vlinks on controllers
            print "removing vlinks on $i \n";
            $ret = DeleteAllVdisks2( $objList[$i], 1 );
        }
    }

#    for ( $i = 0; $i < $numCtlrs; $i++ )
#    {
#        if (GetStatePO( $objList[$i] ) == POWER_UP_COMPLETE)
#        {
#            #  delete vdisks on controllers
#            print "Delete vdisks and LUNs on $i \n";
#            $ret = DeleteAllVdisks2( $objList[$i], 2 );
#        }
#    }
#
#    for ( $i = 0; $i < $numCtlrs; $i++ )
#    {
#        if (GetStatePO( $objList[$i] ) == POWER_UP_COMPLETE)
#        {
#            #  unlabel the drives
#            print "Unlabelling drives on controller $i \n";
#            $ret = LabelSingleDrive( $objList[$i], 0xffff, 0);
#        }
#    }


    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        #  trash BE NVRAM (1st time)
        logInfo("Corrupt BE NVRAM $i");
        $ret = CorruptBENvram( $objList[$i] );
    }

    #
    # now disable health monitor and failure manager
    #

    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        logInfo("Change Mode to Disable Health Monitor and Failure Manager");

        $obj1 = $objList[$i];
        $ret = disableHealthMonitor( $obj1);

        if ( ERROR == $ret )
        {
            logError(">>>>> Failed: Unable to Change Mode. <<<<<");
            # exit(0);                      # JT doesn't want us to die
        }
    }

    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        if (GetStatePO( $objList[$i] ) == POWER_UP_COMPLETE)
        {
            #  final wipe clean on controllers
            logInfo("Final wipe clean on $i");
            $ret = Unconfigure( $objList[$i], 0 );
        }
    }

    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        #  trash BE NVRAM  (final time)
        logInfo("Corrupt BE NVRAM $i");
        $ret = CorruptBENvram( $objList[$i] );
    }

#    $ret = Unconfigure($ctlr1, $option  );
#
#    if ( $ret == ERROR )
#    {
#        print ">>>>>>>> Failed unconfigure <<<<<<<<\n";
#        return (ERROR);
#    }
#
#    if ( $ctlr2 == 0 )
#    {
#        # done if ctlr2 is 0
#        return GOOD;
#    }
#
#    $ret = Unconfigure($ctlr2, $option  );
#
#    if ( $ret == ERROR )
#    {
#        print ">>>>>>>> Failed unconfigure <<<<<<<<\n";
#        return (ERROR);
#    }

    return GOOD;
}

##############################################################################
#
#          Name: Unconfigure
#
#        Inputs: controller, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Attempt to undo any existing configuration and restore
#                the controllers to a specific starting point. Ie.,
#                do wipe_clean even though we can't. Second controller
#                is optional
#
#
##############################################################################
sub Unconfigure
{
    trace();
    # vcgmake single

    my( $controller, $option ) = @_;

    logInfo("Cleaning Controller");

    my $rc = 1;            #Assume Good
    my %rsp;
    my $address;
    my $data;
    my $format;
    my $bindata;
    my $proc;

    # initprocnvram - blow away configuration
    my $value = 400;
    logInfo("Setting MRP timeout to 400 seconds");
    %rsp = $controller->timeoutMRP("MRP", $value);
    # assumes success

    %rsp = $controller->initProcNVRAM(0x00);

    if (!%rsp)
    {
        # no response from controller
        logInfo(">>>>> Failed initProcNVRAM did not respond <<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>> Failed: Error during initProcNVRAM <<<<<");
        PrintError(%rsp);
        return ERROR;
    }
    logInfo("Init Proc NVRAM Complete");
    return GOOD;
}
##############################################################################
# Name:     AsciiHexToBin
#
# Desc:     Converts an ASCII hex string to packed binary data
#
# Input:    data - hex string representing the MRP input data
#           format - byte|short|word  (default: word)
##############################################################################
#sub AsciiHexToBin
#{
#    trace();
#    my ($data, $format) = @_;
#
#    $data =~ s/0x//i;
#
#    if (!defined $data) {
#        logWarning("AsciiHexToBin: No input data");
#        return undef;
#    }
#
#    if (!defined $format) {
#        $format = "word";
#    }
#
#    if ($format !~ /^byte$|^short$|^word$/i) {
#        logWarning("AsciiHexToBin: format incorrect ($format)");
#        return undef;
#    }
#
#    # setup to parse the input data string
#    my $cCnt;
#    my $cTpl;
#
#    if ($format =~ /^byte$/i) {
#        $cCnt = 2;
#        $cTpl = "C";
#    }
#    elsif ($format =~ /^short$/i) {
#        $cCnt = 4;
#        $cTpl = "S";
#    }
#    else { # word
#        $cCnt = 8;
#        $cTpl = "L";
#    }
#
#    my @wData;
#    my $i;
#    my $template = "";
#    my $length = length $data;
#
#    if ($length % $cCnt) {
#        logWarning("AsciiHexToBin: Input data string length not correct for the " .
#                 "format selected data = $data, format = $format");
#        return undef;
#    }
#
#    # parse the input data string
#    for($i=0; $i<$length; $i+=$cCnt) {
#        push @wData, oct("0x" . substr $data, 0, $cCnt);
#        $data = substr $data, $cCnt;
#        $template .= $cTpl;
#    }
#
#    $data = pack $template, @wData;
#
#    return $data;
#}

##############################################################################
#
#          Name: DecToAsciiHexData
#
#        Inputs: uinteger, format as a string (either "word", "short", or "byte"
#
#       Outputs: the specified integer is converted into an ASCII Hex, word
#                short, or byte string.
#
#  Globals Used: none
#
#   Description: Converts the specified integer into an ASCII Hex word, short, or
#                byte string.  Example - Input: 255, "word" - Output:
#                "000000ff", without the quotation marks.  Example - Input 255,
#                "short" - Output: "00ff".
#
##############################################################################
#sub DecToAsciiHexData
#{
#    trace();
#    use constant BITS_IN_NIBBLE => 4; # the number of bits in a nibble
#    use constant WORD_SIZE => 8;      # the number of hex nibbles
#                                      # (4-bit chunks) in a word
#    use constant SHORT_SIZE => 4;     # the number of hex nibbles in a short
#    use constant BYTE_SIZE => 2;      # the number
#
#
#    my ($inputValue, $formatString) = @_;  # the input to this function
#    my $ret;                               # return value
#    my $condensedHexString;   # the hex string without padding
#    my $fillNumber;           # the number of zeros to pad the data with
#    my $maxInput;             # the maximum number that can be entered
#    my $minInput;             # the minimum number that can be entered
#    my $dataSize;             # the size of the data to format
#
#    if ($formatString)
#    {
#        #
#        # Parse the data format string
#        #
#        if ($formatString eq "word")
#        {
#            $dataSize = WORD_SIZE;
#        }
#        elsif ($formatString eq "short")
#        {
#            $dataSize = SHORT_SIZE;
#        }
#        elsif ($formatString eq "byte")
#        {
#            $dataSize = BYTE_SIZE;
#        }
#        else
#        {
#            debug("Invalid data format specifier");
#            die "Invalid data format specifier.";
#        }
#    }
#    else {
#        debug("No data format specifier was provided");
#        die "No data format specifier was provided.";
#    }
#
#    #
#    # Find out the max and mins that are allowed to be entered.
#    #
#    $maxInput = 2**((BITS_IN_NIBBLE * $dataSize)) - 1;
#    $minInput = 0;
#
#    # Ensure that the input is within the allowed range.
#    if (! (($inputValue <= $maxInput) && ($inputValue >= $minInput)) ) {
#        debug("The input $inputValue in not within the range of values for the " .
#              "specified data format");
#        die "The input $inputValue in not within the range of values for the " .
#            "specified data format.";
#    }
#
#    #
#    # Convert the input to hex
#    #
#    $condensedHexString = sprintf("%x", $inputValue);
#
#    #
#    # Get the number of zeros to pad the string with
#    #
#    $fillNumber = $dataSize - length($condensedHexString);
#
#    #
#    # Pad the string with zeros to make it the correct size
#    #
#    $ret = ("0" x $fillNumber) . "$condensedHexString";
#
#    return $ret;
#}
#
##############################################################################
#
#          Name:IPValidate
#
#        Inputs: possible IP address
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Validates a scaler to be a proper IP address and is in the
#                range of LAB devices.
#
##############################################################################
#sub IPValidate
#{
#    # just make sure the ip address meets ###.###.###.### style and
#    # the numbers are in the correct range (0-255)
#
#    return GOOD;
#
#}


##############################################################################
#
#          Name: min
#
#        Inputs: oneValue, anotherValue
#
#       Outputs: the less positive of the two values
#
#  Globals Used: none
#
#   Description: basic min function because I know I will need it.
#
#
##############################################################################
# basic min(x,y) function
#sub min
#{
#    my ($a, $b ) = @_;
#    if ( $a > $b ) {return $b};     # b is smaller, send it back
#    return $a;                      # a=b or is smaller, send it back
#}
#
#
##############################################################################
#
#          Name: ValidateResponse
#
#        Inputs: TBD
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Looks for a adequate response from a function call.
#                This allows looking deeper into the response and
#                printing a possibly useful error message.
#
#
##############################################################################
sub ValidateResponse
{
    trace();

    # sees if there is a response, if missing, that is bad

    # if a response, see if it is good

    # if it is bad, print some appropriate message

    return GOOD;

}

##############################################################################
#
#          Name: PromptUser
#
#        Inputs: choice     - which prompt
#
#       Outputs: nothing, any input is tossed
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
#sub PromptUser
#{
#    my ($choice) = @_;           # which one to do
#    my $dummy;
#
#    print " \n";                  # make this stand out a little bit
#
#    if ( $choice == 1 )
#    {
#        print "ACTION: Now rescan for drives on your server(s). \n";
#        print "ACTION: Then press return to continue the script. ";
#        $dummy = <STDIN>;
#        print " Thanks. \n\n";
#        return;
#    }
#    elsif ( $choice == 2 )
#    {
#        print "ACTION: Please wait for all the initializations to complete. \n";
#        print "ACTION: They will be done when the drive LEDs stop flashing. \n";
#        print "ACTION: Then press return to continue the script. ";
#        $dummy = <STDIN>;
#        print " Thanks. \n\n";
#        return;
#    }
#    elsif ( $choice == 3 )
#    {
#        print "ACTION: Now rescan for drives on your server(s). You do NOT \n";
#        print "ACTION: need to wait for all the initializations to complete. \n";
#        print "ACTION: (The script will wait as needed for inits to complete.) \n";
#        print "ACTION: Then press return to continue the script. ";
#        $dummy = <STDIN>;
#        print " Thanks. \n\n";
#        return;
#    }
#    elsif ( $choice == 4 )
#    {
#        print "ACTION: Press return to finish the scripts, Then \n";
#        print "ACTION: cycle power on the controller(s) and \n";
#        print "ACTION: wait for them to finish booting. \n\n";
#        $dummy = <STDIN>;
#        print " Thanks. \n\n";
#        return;
#    }
#    elsif ( $choice == 5 )
#    {
#        print "ACTION: Don't forget to clear the new bit in the server \n";
#        print "ACTION: properties. (Currently no CLI facility for that. \n";
#        print "ACTION: Now press return to continue the script. ";
#        $dummy = <STDIN>;
#        print " Thanks. \n\n";
#        return;
#    }
#    elsif ( $choice == 6 )
#    {
#        print "ACTION: You can now start IO on the server(s). \n";
#        print "ACTION: Two VDISKS should be available for IO. \n";
#        print "\n";
#        DelaySecs(15);
#        return;
#    }
#    else
#    {
#        print "ACTION: We are not supposed to be here! Something is wrong! \n";
#        print "ACTION: Then press return to continue the script. ";
#        $dummy = <STDIN>;
#        print " Thanks. \n\n";
#        return;
#    }
#}

##############################################################################
#
#          Name: PrintError
#
#        Inputs: ret (hash returned from a command)
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: Just prints the error fields in a has. This is frequently
#                used code.
#
#
##############################################################################
sub PrintError
{
    trace();
    my (%ret) = @_;

    logInfo(sprintf("Status Code: 0x%02x\n", $ret{STATUS}));

    if (defined($ret{STATUS_MSG}))
    {
        logInfo("$ret{STATUS_MSG}");
    }
    logInfo(sprintf("Error Code: 0x%02x ", $ret{ERROR_CODE}));

    if (defined($ret{ERROR_MSG}))
    {
        logInfo($ret{ERROR_MSG});
    }
    return;
}

##############################################################################
#
#          Name: EnableCache
#
#        Inputs: $controller, $option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################

sub EnableCache
{
    trace();
    # enable cache on all vdisks and in global config.

    my( $controller, $option ) = @_;

    logInfo("Enabling cache on all vdisks and the controller");

    my %rsp;
    my @vdisklistarray;
    my @vdisklistarray2;
    my $numVDDs;
    my $r;
    my $thisVDD;

    # get list of vdisks to process

    %rsp = $controller->getObjectList(PI_VDISK_LIST_CMD);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from PI_VDISK_LIST_CMD <<<<<<<<");
        return ERROR;
    }


    if ($rsp{STATUS} == PI_GOOD)
    {
        logInfo("Virtual Disk List");
        logObjectList(%rsp);
        # in here is my list of disks.. now how do i extract it?
        # need to build this array >>>> @vdisklistarray = @$vdisklist;       # make an array
    }
    else
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    debug("the disks " . $rsp{LIST}[2]);
    debug("this many " . $rsp{COUNT});


    # put drives into an array
    for ( $r=0; $r< $rsp{COUNT}; $r++)
    {
        push  @vdisklistarray2, $rsp{LIST}[$r];
    }

    TestLibs::BEUtils::RemoveVlinks( $controller, \@vdisklistarray2, \@vdisklistarray );

    $numVDDs = scalar(@vdisklistarray);  # of drives available to map

    #
    # now check each vdisk to see if the cache is enabled. if not,
    # go ahead and set the bit for caching.
    #

    $r = $numVDDs;
    while ( $r > 0)
    {
        # adjust $r as the index to the array
        $r--;

        # get caching info (CACHEEN:)

        %rsp = $controller->virtualDiskInfo($vdisklistarray[$r]);

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
            return ERROR;
        }


        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to retrieve virtual disk information. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        # if necessary, turn on cache

        $thisVDD = $rsp{ATTR} & 256;   # CACHEEN is bit 8

        debug("VDD $vdisklistarray[$r] has  CACHEEN =  $thisVDD");

        if ( ! $thisVDD  )
        {
            %rsp = $controller->virtualDiskSetCache($vdisklistarray[$r], 1);

            if ( ! %rsp  )
            {
                logInfo(">>>>>>>> Failed to get response from virtualDiskSetCache <<<<<<<<");
                return ERROR;
            }

            if ($rsp{STATUS} != PI_GOOD)
            {
                logInfo(">>>>>>>> Unable to enable cache on VDD $vdisklistarray[$r] <<<<<<<<");

                PrintError(%rsp);

                return ERROR;
            }

            logInfo("Write Cache enabled on VDD $vdisklistarray[$r]");
        }

        # back to do the next one
    }

    # now, turn on the global caching bit

    %rsp = $controller->globalCacheSet(0x81);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from globalCacheSet <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to enable global caching. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Global write caching enabled on controller");

    # we are done

    return GOOD;
}

##############################################################################
#
#          Name: DisableCache
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub DisableCache
{
    trace();
    # disable cache in global config.

    my( $controller, $option ) = @_;

    my %rsp;

    logInfo("Global disable cache");

    # now, turn off the global caching bit

    %rsp = $controller->globalCacheSet(0x80);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from globalCacheSet <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to disable global caching. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Global write caching disabled on controller");

    # we are done

    return GOOD;
}

##############################################################################
#
#          Name:  ConfigView
#
#        Inputs:  $ctlr1, $ctlr2, $option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: displays some of the configuration for two controllers
#                "targetst", "vcginfo", "devstat pd"
#
##############################################################################
sub ConfigView
{
    trace();
    # disable cache in global config.

    my( $ctlr1, $ctlr2, $option ) = @_;

    my %rsp;
    my $ret;

    logInfo("View configuration for master");

    my $pus = GetStatePO($ctlr1);
    if ( $pus != 65535 )
    {
        logInfo("Controller not ready yet (PO state = $pus)");
        return GOOD;
    }

    $ret = RescanBE( $ctlr1 );
    if( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to rescan drives. <<<<<<<<");
        return (ERROR);
    }

    ############ target status ###############

    $ret =  TargetList( $ctlr1 );

    if ( $ret == ERROR )
    {
        return ERROR;
    }

    ########### devstat PD ################

    $ret = DispPdiskInfo( $ctlr1 );

    if ( $ret == ERROR )
    {
        return ERROR;
    }

    ############### virtualDisks ################

    $ret = DispVdiskInfo( $ctlr1  );

    if ( $ret == ERROR )
    {
        return ERROR;
    }

    ############### vcginfo ################
    %rsp = $ctlr1->vcgInfo(0);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from vcgInfo <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get vcgInfo <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    # display it
    logVCGInfo(%rsp);

    ############## check for 2nd controller to do  ######################
    if ( $ctlr2 == 0 )
    {
        # bail if none
        return GOOD;
    }

    $pus = GetStatePO($ctlr2);
    if ( $pus != 65535 )
    {
        logInfo("Controller not ready yet (PO state = $pus)");
        return GOOD;
    }

    logInfo("View configuration for slave");

    $ret = RescanBE( $ctlr2 );
    if( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to rescan drives. <<<<<<<<");
        return (ERROR);
    }

    ############ target status ###############

    $ret =  TargetList( $ctlr2 );

    if ( $ret == ERROR )
    {
        return ERROR;
    }

    ########### devstat PD ################

    $ret = DispPdiskInfo( $ctlr2 );

    if ( $ret == ERROR )
    {
        return ERROR;
    }

    ############### virtualDisks ################

    $ret = DispVdiskInfo( $ctlr2  );

    if ( $ret == ERROR )
    {
        return ERROR;
    }


    ############### vcginfo ################
    %rsp = $ctlr2->vcgInfo(0);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from vcgInfo <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get vcgInfo <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    # display it
    logVCGInfo(%rsp);

    # all done
    return GOOD;
}

##############################################################################
#
#          Name: TestMenu
#
#        Inputs: none
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Allow user to select from a menu of tests
#
#
##############################################################################
sub TestMenu
{
    trace();
    # disable cache in global config.

    my( $ctlr1, $ctlr2, $option, $wwnList) = @_;

    my %rsp;
    my $ret;

    my @coList;

    $coList[0] = $ctlr1;
    $coList[1] = $ctlr2;

    print "\n\n\n\n";
    print "##########################################\n";
    print "########## Single Test Menu ##############\n";
    print "##########################################\n";
    print "  1) Cycle write cache on and off (200x)  51) GP Cache Test\n";
    print "  2) Delete All vdisks on master          52) GP devstat Test \n";
    print "  3) Elections test (2 way) (200x)        53) GP DiskBay Test \n";
    print "  4) Re-Label PDDs (50x)                  54) GP Logging Test\n";
    print "  5) Fail PDD/rebuild (5x)                55) GP Memory Leak Test \n";
    print "  6) Good Path Test (all)                 56) GP Misc Commands Test \n";
    print "  7) GP test subset while IO runs         57) GP Raid commands Test \n";
    print "  8) Extended GP test                     58) GP Phys Disk Command Test\n";
    print "  9) Extended GP IO test                  59) GP Reset QL Test\n";
    print "  10) Defrag Test (full)                  60) GP Server Commands Test\n";
    print "  11) Defrag Part 1                       61) GP Statistics Commands Test\n";
    print "  12) Defrag part 2                       62) GP Target Commands Test\n";
    print "  13) Defrag pert 3                       63) GP Vdisk Commands Test\n";
    print "  14) Defrag part 4                       64) GP Mode Bit(s) Test\n";
    print "                                          65) GP Fid Read Test\n";
    print "                                          66) GP VDD C/E/I/D Test raid 5\n";
    print "                                          67) GP Config real 1 way Test\n";
    print "                                          68) GP VDD C/E/I vdisk Test\n";
    print "  80) Case 1 test (no IO)                 69) \n";
    print "  81) Case 1 test (with IO)               70) BEET failover\n";
    print "  82) Case 1 test, 2 way, no IO           71) \n";
    print "  82) Case 1 test, 2 way, no IO           72) B] find master controller\n";
    print "                                          73) B] \n";
    print "  86) stop/startIO MRP 10k loops          74) B] \n";
    print "                                          75) \n";
    print "                                          76) \n";
    print "                                          77) GP VDD C/E/I/D Test raid 10\n";
    print "                                          78) \n";
    print "                                          79) \n";
    print "                                    \n";
    print "  95) Many of the above (the non-destructive ones) \n";
    print "\n\n Select an option: ";

    my $ans = <STDIN>;
    chomp ($ans);

    if ( !$ans )
    {
        return ERROR;
    }

    if ( $ans < 0  )
    {
        return ERROR;
    }

    if ( $ans > 99 )
    {
        return ERROR;
    }

    $option = $ans;

    print "\n\nThanks.\n\n";

    # now call functions based upon the option


    if ( $option == 1 )
    {
        $ret = CacheCycleTest($ctlr1, 200);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failure turning cache in and off <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 2 )
    {
        $ret = DeleteAllVdisks($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to delete the existing vdisks <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 3 )
    {
        $ret = ElectionsTest($ctlr1, $ctlr2, 200);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in the elections test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 4 )
    {
        # re-label PDD test, usually done while IO is running
        $ret = ReLabelPD($ctlr1, 50);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed while re-labeling PDDs <<<<<<<<");
            return (ERROR);
        }

    }
    elsif ( $option == 5 )
    {
        # fail and rebuild PDD test
        $ret = FailDrivesTest($ctlr1, 5, 0);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed while failing and rebuilding PDDs <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 6 )
    {
        $ret = GoodPathTest($ctlr1, 0, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 7 )
    {
        $ret = GoodPathSubset1($ctlr1, 0, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 8 )
    {
        $ret = GoodPathSuperset($ctlr1, 0, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 9 )
    {
        $ret = GoodPathIOTest($ctlr1, 0, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 10 )
    {
        $ret = DefragTest($ctlr1, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in defrag<<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 11)
    {
        $ret = DefragPart1($ctlr1, 1, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in defrag<<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 12 )
    {
        #$ret = DefragPart2($ctlr1, 10, ( DEFRAG_WAIT + NO_RAID_INIT ) );
        $ret = DefragPart2($ctlr1, 5, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in defrag<<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 13 )
    {
        $ret = DefragPart3($ctlr1, (DEFRAG_WAIT) );
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in defrag<<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 14 )
    {
        $ret = DefragPart4($ctlr1, (DEFRAG_WAIT) );
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in defrag<<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 51 )
    {
        $ret = GPCaching($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path cache test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 52 )
    {
        $ret = GPDeviceStatus($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path device status test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 53 )
    {
        $ret = GPDiskBayCommands($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path disk bay command test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 54 )
    {
        $ret = GPLoggingTest($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path logging test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 55 )
    {
        $ret = GPMemoryLeakTest($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path memory leak test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 56 )
    {
        $ret = GPMiscCommands($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path misc coammands test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 57 )
    {
        $ret = GPRaidCommands($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path raid commands test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 58 )
    {
        $ret = GPPhysicalDiskCommands($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path physical disk test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 59 )
    {
        $ret = GPResetTest($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path reset qlogic test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 60 )
    {
        $ret = GPServerCommands($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path server commands test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 61 )
    {
        $ret = GPStatsCommands($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path Statistics commands test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 62 )
    {
        $ret = GPTargetCommands($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path target commands test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 63 )
    {
        $ret = GPVirtualDiskCommands($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path vdisk commands test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 64 )
    {
        $ret = GPModes($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path mode bits test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 65 )
    {
        $ret = GPFidRead($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path FID read test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 66 )
    {
        $ret = GPCreateExpandDelete($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path Vdisk create/expand/init/delete test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 67 )
    {
        $ret = GPReal1Way($ctlr1, $wwnList, 2);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path create real 1 way test <<<<<<<<");
            return (ERROR);
        }

    }
    elsif ( $option == 68 )
    {
        $ret = GPCreateExpand($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path create/expand/init test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 70 )
    {
        $ret = GPCreateExpand($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path create/expand/init test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 71 )
    {
        $ret = FindMaster(\@coList);
        if ( $ret == INVALID )
        {
            logError(">>>>>>>> Failed to find the master  test <<<<<<<<");
            return (ERROR);
        }
        logInfo("master is $ret");
    }
    elsif ( $option == 77 )
    {
        $ret = GPCreateExpandDelete2($ctlr1);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path Vdisk create/expand/init/delete test (2) <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 80 )
    {
        $ret = GPCase1(\@coList, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in Case 1 test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 81 )
    {
        $ret = GPCase1IO(\@coList, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in Case 1 IO test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 82 )
    {
        $ret = GPCase1TwoWay(\@coList, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in Case 1, 2 way, no IO test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 83 )
    {
        $ret = GPCase1TwoWay(\@coList, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in Case 1, 2 way, IO test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 86 )
    {
        $ret = StopStartIOTest($ctlr1, 10000);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in stop/start io using generic MRP test <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $option == 95 )
    {
        ########## most of the tests, back to back #########
        ########## doable with I/O running         #########

        ####### Cache Cycle test ######
#        $ret = CacheCycleTest($ctlr1, 20);
#        if ( $ret == ERROR )
#        {
#            logError(">>>>>>>> Failure turning cache in and off <<<<<<<<");
#            return (ERROR);
#        }


        ####### Re-label PDDs test ######
        # re-label PDD test, usually done while IO is running
        $ret = ReLabelPD($ctlr1, 20);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed while re-labeling PDDs <<<<<<<<");
            return (ERROR);
        }

        ####### Good path (w/IO) test ######
        $ret = GoodPathIOTest($ctlr1, 0, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path test <<<<<<<<");
            return (ERROR);
        }

        ####### Defrag test (part 2 only) ######
        $ret = DefragPart2($ctlr1, 10, ( DEFRAG_WAIT + NO_RAID_INIT ) );
        #$ret = DefragPart2($ctlr1, 2, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in defrag<<<<<<<<");
            return (ERROR);
        }

        ####### Extended Good Path test ######
        $ret = GoodPathSuperset($ctlr1, 0, $wwnList);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in good path test <<<<<<<<");
            return (ERROR);
        }

        ####### Fail PDDs test ######
        # fail and rebuild PDD test
        $ret = FailDrivesTest($ctlr1, 5, 0);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed while failing and rebuilding PDDs <<<<<<<<");
            return (ERROR);
        }

        ####### Elections test (should have 2 way system) ######
        $ret = ElectionsTest($ctlr1, $ctlr2, 50);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed in the elections test <<<<<<<<");
            return (ERROR);
        }
    }
    else
    {
        print " You have chosen poorly. \n";
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: DispVcgInfo
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub DispVcgInfo
{
    trace();

    my ($ctlr1) = @_;

    my %vcginfo;

    ########### vcginfo ################

    # get information from the master controller
    logInfo("VCG information");

    %vcginfo = $ctlr1->vcgInfo(0);

    if ( ! %vcginfo  )
    {
        logInfo(">>>>>>>> Failed to get vcginfo from master <<<<<<<<");
        return (ERROR);
    }

    if (%vcginfo)
    {
        if ($vcginfo{STATUS} == PI_GOOD)
        {
            logVCGInfo(%vcginfo);
        }
        else
        {
            logInfo(">>>>>>>> Error getting vcginfo from master <<<<<<<<");
            PrintError(%vcginfo);
        }
    }
    return GOOD;
}

##############################################################################
#
#          Name: DispPdiskInfo
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub DispPdiskInfo
{
    trace();
    my ($ctlr1) = @_;
    my %rsp;

    ########### devstat PD ################

    logInfo("Physical disk information");

    %rsp = $ctlr1->deviceStatus("PD");

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from deviceStatus <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get device status <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    # display it
    logDeviceStatus("PD", "N", %rsp);

    # if we got here, we must be
    # done
    return (GOOD);
}


##############################################################################
#
#          Name: DispVdiskInfo
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################


sub DispVdiskInfo
{
    trace();
    my ($ctlr1) = @_;

    my %rsp;
    my $i;
    my $r;
    my @ar;
    my $vdisklist;
    my @vdisklistarray;
    my $numVDDs;
    my  $ap;
    my  %vd;

    %rsp = $ctlr1->virtualDisks();

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks <<<<<<<<");
        return ERROR;
    }

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            if ($rsp{COUNT} > 0)
            {
                logVirtualDisks(%rsp);
            }
            else
            {
                logInfo("No virtual disks present");
            }
        }
        else
        {
            logInfo(">>>>>>>> Unable to retrieve  virtual disk information. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }

    return GOOD;
}


##############################################################################
#
#          Name: GetTargetStatus
#
#        Inputs: controller object
#
#       Outputs: Hash with the data
#                INVALID  on error
#
#  Globals Used: none
#
#   Description: This function gets the TARGETSTATUS information from the
#                controller. The data is returned in a hash that matches that
#                used internally in the the CCBCL.
#
##############################################################################
sub GetTargetStatus
{
    my($ctlr) = @_;

    my $serverCount = 0;
    my $targetCount = 0;
    my @servers;
    my @targets;
    my %info1;
    my %info2;
    my %info3;
    my %info4;
    my $rc;
    my $i;
    my $j;
    my $k;

    # get all the targets
    %info1 = $ctlr->targetList();

    $rc = 1;

    $info4{STATUS} = PI_GOOD;
    $info4{ERROR_CODE} = 0;

    if (%info1)
    {
        if ($info1{STATUS} == PI_GOOD)
        {
            for $i (0..$#{$info1{LIST}})
            {
                #if (defined($tid))
                #{
                #    $info1{LIST}[$i] = $tid;
                #}

                %info2 = $ctlr->targetInfo($info1{LIST}[$i]);
                if (%info2)
                {
                    if ($info2{STATUS} == PI_GOOD)
                    {
                        $targets[$targetCount]{STATUS_MRP}  = $info2{STATUS_MRP};
                        $targets[$targetCount]{LEN}         = $info2{LEN};
                        $targets[$targetCount]{TGD_TID}     = $info2{TGD_TID};
                        $targets[$targetCount]{TGD_CHAN}    = $info2{TGD_CHAN};
                        $targets[$targetCount]{TGD_OPT}     = $info2{TGD_OPT};
                        $targets[$targetCount]{TGD_ID}      = $info2{TGD_ID};
                        $targets[$targetCount]{TGD_POWNER}  = $info2{TGD_POWNER};
                        $targets[$targetCount]{TGD_OWNER}   = $info2{TGD_OWNER};
                        $targets[$targetCount]{TGD_CLUSTER} = $info2{TGD_CLUSTER};
                        $targets[$targetCount]{TGD_PNAME}   = $info2{TGD_PNAME};
                        $targets[$targetCount]{TGD_PNAME_LO}= $info2{TGD_PNAME_LO};
                        $targets[$targetCount]{TGD_PNAME_HI}= $info2{TGD_PNAME_HI};
                        $targets[$targetCount]{TGD_NNAME}   = $info2{TGD_NNAME};
                        $targets[$targetCount]{TGD_NNAME_LO}= $info2{TGD_NNAME_LO};
                        $targets[$targetCount]{TGD_NNAME_HI}= $info2{TGD_NNAME_HI};
                        $targetCount++;

                        #if (defined($tid))
                        #{
                        #    last;
                        #}
                    }
                    else
                    {
                        $rc = 0;
                        logInfo( "error getting target info");
                        $info4{STATUS} = $info2{STATUS};
                        $info4{ERROR_CODE} = $info2{ERROR_CODE};
                    }
                }
                else
                {
                    $rc = 0;
                }
            }
        }
        else
        {
            $rc = 0;
            logInfo( "error getting target list");
            $info4{STATUS} = $info1{STATUS};
            $info4{ERROR_CODE} = $info1{ERROR_CODE};
        }
    }
    else
    {
        $rc = 0;
    }

    if ($rc)
    {

        %info1 = $ctlr->serverList();
    }

    if (%info1 && $rc)
    {
        if ($info1{STATUS} == PI_GOOD)
        {
            for $i (0..$#{$info1{LIST}})
            {
                #print "getting server info on $i \n";
                %info2 = $ctlr->serverInfo($info1{LIST}[$i]);
                if (%info2)
                {
                    if ($info2{STATUS} == PI_GOOD)
                    {
                        $servers[$serverCount]{STATUS_MRP}  = $info2{STATUS_MRP};
                        $servers[$serverCount]{LEN}         = $info2{LEN};
                        $servers[$serverCount]{SID}         = $info2{SID};
                        $servers[$serverCount]{NLUNS}       = $info2{NLUNS};
                        $servers[$serverCount]{TARGETID}    = $info2{TARGETID};
                        $servers[$serverCount]{SSTATUS}     = $info2{SSTATUS};
                        $servers[$serverCount]{PRI}         = $info2{PRI};
                        $servers[$serverCount]{ATTRIB}      = $info2{ATTRIB};
                        $servers[$serverCount]{SESSION}     = $info2{SESSION};
                        $servers[$serverCount]{OWNER}       = $info2{OWNER};
                        $servers[$serverCount]{LUNMAP}      = $info2{LUNMAP};
                        $servers[$serverCount]{REQCNT}      = $info2{REQCNT};
                        $servers[$serverCount]{WWN}         = $info2{WWN};
                        $servers[$serverCount]{WWN_HI}      = $info2{WWN_HI};
                        $servers[$serverCount]{WWN_LO}      = $info2{WWN_LO};
                        $serverCount++;
                    }
                    else
                    {
                        $rc = 0;
                        logInfo( "error getting server info");
                        $info4{STATUS} = $info2{STATUS};
                        $info4{ERROR_CODE} = $info2{ERROR_CODE};
                    }
                }
                else
                {
                    $rc = 0;
                }
            }
        }
        else
        {
            $rc = 0;
            logInfo( "error getting server list");
            $info4{STATUS} = $info1{STATUS};
            $info4{ERROR_CODE} = $info1{ERROR_CODE};
        }
    }

    #print "\ntargets:\n";
    #print @targets;
    #print "\nservers:\n";
    #print @servers;
    #print "done\n";

    $info4{SERVERS} = \@servers;
    $info4{TARGETS} = \@targets;

    return %info4;


}

##############################################################################
#
#          Name: DispLogs
#
#        Inputs: controller object, # of logs to disply, mode
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of misc functions.
#
##############################################################################
sub DispLogs
{
    trace();
    my ($ctlr, $count, $mode) = @_;

    logInfo("################  Controller $ctlr->{HOST} Logs - last $count entries #######################");

    my $rc = 1;
    my %rsp;
    my %i;


    ######################
    # LOG INFO
    ######################


    %rsp = $ctlr->logInfo($count, $mode, 0);
    if ( ! %rsp  )              # if no return from call
    {
        logWarning(">>>>>>>> Failed to get response from logInfo <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logWarning(">>>>>>>> Error from logInfo <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }


    logLogInfo($mode, 0, %rsp);

    #logInfo("Completed testing logging operations");

    return GOOD;
}



##############################################################################
#
#          Name: LogTargetStatus
#
#        Inputs: targetStatus hash
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: This function just prints the targetstatus hash.
#
##############################################################################
sub LogTargetStatus
{
    my (%info) = @_;

    my $targetCount;
    my @targets;
    my @servers;
    my $i;
    my $j;
    my $k;
    my $msg;
    my $linecount;

    my $targPtr = $info{TARGETS};
    my $servPtr = $info{SERVERS};

    @targets = @$targPtr;
    @servers = @$servPtr;

    #print "\ntargets:\n";
    #print @targets;
    #print "\nservers:\n";
    #print @servers;

    logInfo("\n");

    $targetCount = scalar(@targets);

    # print @targets;

    # now print the stuff to the log

    logInfo( " TID  Channel   Owner       Port WWN      SID        WWN         LUN  VID ");
    logInfo( " ---  -------  -------  ----------------  ---  ----------------  ---  --- ");
    for ($i = 0; $i < $targetCount; ++$i)
    {
        $msg = "";
        #print " i = $i, \n";
        $msg .= sprintf( " %2hu     %2lu     %6lu   %8.8x%8.8x",
                                      $targets[$i]{TGD_TID},
                                      $targets[$i]{TGD_CHAN},
                                      $targets[$i]{TGD_OWNER},
                                      $targets[$i]{TGD_PNAME_LO},
                                      $targets[$i]{TGD_PNAME_HI});
        $linecount = 0;

        for ($j = 0; $j < scalar(@servers); ++$j)
        {
            if ($targets[$i]{TGD_TID} == $servers[$j]{TARGETID})
            {
                if ($linecount++ >= 0)
                {
                    logInfo($msg);
                    $msg = "                                        ";
                }
                $msg .= sprintf( "  %2hu   %8.8x%8.8x",
                                              $servers[$j]{SID},
                                              $servers[$j]{WWN_LO},
                                              $servers[$j]{WWN_HI});

                if ($servers[$j]{NLUNS} > 0)
                {
                    for ($k = 0; $k < $servers[$j]{NLUNS}; ++$k)
                    {
                        if ($k > 0)
                        {
                            logInfo($msg);
                            $msg = "                                                               ";
                        }
                        $msg .= sprintf( "   %2hu  %3hu",
                                                $servers[$j]{LUNMAP}[$k]{LUN},
                                                $servers[$j]{LUNMAP}[$k]{VID});
                    }
                }
            }
        }
        logInfo($msg);
        logInfo("");
    }
    logInfo("");
}

##############################################################################
#
#          Name:  TargetList
#
#        Inputs:  $ctlr1
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: display 'targetstatus'
#
##############################################################################
sub TargetList
{
    trace();
    # disable cache in global config.

    my( $ctlr1 ) = @_;

    my %rsp;
    my $ret;

    logInfo("Target Status");

    ############ target status ###############

    %rsp = GetTargetStatus($ctlr1);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from targetStatus <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get target status <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    LogTargetStatus(%rsp);        # print it

    return GOOD;
}

##############################################################################
#
#          Name: ConfigSelect
#
#        Inputs: arrays of the controller objects, ip addresses and wwns
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: create a configuration and build it.
#
#
##############################################################################
sub ConfigSelect
{
    trace();
    # disable cache in global config.

    my( $objPtr, $ipPtr, $wwnPtr) = @_;

    my $numDataOption;
    my $numUnsafeOption;
    my $numHotspareOption;
    my $vdiskOption;
    my $mapOption;
    my $vcgOption;

    my $f;
    my $option;
    my $ret;

    # these lines help manage the transition from passing 2 controllers
    # to passing an array of controllers for n-way setup

    my @ipList;
    my @objList;

    my $master;
    my $slave;
    my $masterIP;
    my $slaveIP;
    my $masterIndex;

    @objList = @$objPtr;
    @ipList = @$ipPtr;

    $master = $objList[0];     # controller objects
    $slave  = $objList[1];

    $masterIP = $ipList[0];    # controller ip addresses
    $slaveIP  = $ipList[1];

    #####################
    $numDataOption =  19;
    $numUnsafeOption = 2;
    $numHotspareOption = 1;
    $vdiskOption = 2;
    $mapOption = 2;
    $vcgOption = 0;

    $f = 1;

    while ( $f == 1 )
    {
        # loop to get use inputs

        # first display config
        print "__________________________________________________\n";
        print "Current selection:\n\n";
        print "    Number of data drives:  $numDataOption \n";
        print "     Number unsafe drives:  $numUnsafeOption \n";
        print "   Number hotspare drives:  $numHotspareOption \n";
        print "    Vdisk creation option:  $vdiskOption \n";
        print "       LUN mapping option:  $mapOption \n";
        print "      VCG creation option:  ";
        if ($vcgOption == 0 )
        {
            print "will NOT create a VCG\n";
        }
        else
        {
            print "WILL create a VCG ( 2 way system )\n";
        }


        print "\n\nYou can select one of the following:\n\n";
        print "  1) Change the number of data drives. \n";
        print "  2) Change the number of unsafe drives. \n";
        print "  3) Change the number of hot spare drives. \n";
        print "  4) Change the vdisk creation option. \n";
        print "  5) Change the vdisk/LUN mapping option. \n";
        print "  6) Toggle the VCG creation option. \n";
        print " 10) Execute the configuration. \n";
        print " 99) Quit without configuring. \n";

        print "\n\n Select an option: ";
        my $ans = <STDIN>;
        chomp ($ans);

        $option = $ans;

        if ( $option == 1 )
        {
            # number of data drives
            print " Enter the number of data drives to allocate: ";
            my $ans = <STDIN>;
            chomp ($ans);
            $numDataOption = $ans;
            print "\n\n";

        }
        elsif ( $option == 2 )
        {
            # number of unsafe drives
            print " Enter the number of unsafe drives to allocate: ";
            my $ans = <STDIN>;
            chomp ($ans);
            $numUnsafeOption = $ans;
            print "\n\n";
        }
        elsif ( $option == 3 )
        {
            # number of hot spare drives
            print " Enter the number of hot spare drives to allocate: ";
            my $ans = <STDIN>;
            chomp ($ans);
            $numHotspareOption = $ans;
            print "\n\n";

        }
        elsif ( $option == 4 )
        {
            # get the arrangement of vdisks to use
            $ret = SelectVdiskOption ( $vdiskOption );
            if ( $ret != INVALID )
            {
                $vdiskOption = $ret;
            }
        }
        elsif ( $option == 5 )
        {
            # get the vdisk/lun mapping options
            $ret = SelectMapOption ( $mapOption );
            if ( $ret != INVALID )
            {
                $mapOption = $ret;
            }

        }
        elsif ( $option == 6 )
        {
            # toggle vcg creation
            if ( $vcgOption == 0 )
            {
                $vcgOption = 1;
                print "A two way system WILL be created.\n";
            }
            else
            {
                $vcgOption = 0;
                print "A two way system WILL NOT be created.\n";
            }

        }
        elsif ( $option == 10 )
        {
            # now do it
            $f = 0;
        }
        elsif ( $option == 99 )
        {
            # exit without configuring
            return GOOD;
        }
        else
        {
            print "You have chosen unwisely, please try again \n";
        }
    }

    # now execute the desired configuration

    #
    # if a new vcg is not going to be created, get the current master.
    #
    if ( $vcgOption == 0 )
    {
        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        } 
        $master = $objList[$masterIndex]; 
    }   
    
    $ret = LabelAllDrives($master, $numDataOption, $numUnsafeOption, $numHotspareOption, 0, 0 );     # for 14 drive bays
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to label the drives <<<<<<<<");
        return (ERROR);
    }

    if ( $vcgOption != 0 )
    {
        $ret = MakeNWay($objPtr);
        if ( $ret == ERROR )
        {
            logWarning(">>>>>>>> Failed to create the VCG <<<<<<<<");
            return (ERROR);
        }
        
        $masterIndex = FindMaster($objPtr);
        if ( $masterIndex == INVALID ) 
        { 
            logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
            return(ERROR); 
        }
        $master = $objList[$masterIndex]; 
    }

    $ret = MakeVdisks($master, $vdiskOption, 0 );
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to create new vdisks <<<<<<<<");
        return (ERROR);
    }

    $ret = PromptUser( 3 );

    $ret = AssociateServers($master, $mapOption, $wwnPtr );
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to associate drives to servers <<<<<<<<");
        return (ERROR);
    }

    return GOOD;
}
##############################################################################
#
#          Name: SingleItemMenu
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub SingleItemMenu
{
    trace();
    # disable cache in global config.

    my( $objPtr, $ipPtr, $wwn, $option ) = @_;

    my %rsp;
    my $ret;
    my $ctlr1;     # controller objects
    my $ctlr2;
    my $i;
    my $idx;       # index into controller arrays ie., current controller

    # these lines help manage the transition from passing 2 controllers
    # to passing an array of controllers for n-way setup
    my @ipList;
    my @objList;

    my $masterIP;
    my $slaveIP;


    @objList = @$objPtr;
    @ipList = @$ipPtr;

    $ctlr1 = $objList[0];     # controller objects
    $ctlr2  = $objList[1];

    $masterIP = $ipList[0];    # controller ip addresses
    $slaveIP  = $ipList[1];

    my $numCtlrs = scalar(@objList);

    $idx = 0;
    print "\n\n";
    print "#########################################\n\n";
    print "Using $numCtlrs controllers \n\n";
    print "   ##      controller IP \n";
    print "   --      ------------- \n";
    for ( $i = 0; $i < $numCtlrs; $i++)
    {
        printf "  %3d   %15s  \n", $i, $ipList[$i];
    }
    print "\n\n";

    # make sure we have a license for this controller
    $ret = GetMyLicense( $objList[$idx], $ipList[$i], $idx);

    while ( 1 )
    {
        print "\n\n";
        print "####################################################################################\n";
        print "############################# Single Command menu ##################################\n";
        print "\nCurrent controller is $idx ( $ipList[$idx] )\n\n";
        print "  1) label all drives: many data, 2 unsafe, 1 spare   21) Disassociate all vdisks\n";
        print "  2) Vdisk create menu                                22) Delete all vdisks \n";
        print "  3) make vdisks (strategy 2)                         23) unlabel all drives \n";
        print "  4) make vcg                                         24) make single \n";
        print "  5) Rescan BE on master                              25) Break all mirror vdisks\n";
        print "  6) List servers on master                           26) Show vdisks on server 6\n";
        print "  7) Display VCG Information                          27) Get SIDs \n";
        print "  8) Display VDisk Information                        28) Enable write caching\n";
        print "  9) Display PDisk Information                        29) Disable global write cache\n";
        print " 10)                                                  30) add 100 MB to all vdisks\n";
        print " 11) Delete all vdisks                                31) Fix Pdisk Labels\n";
        print " 12) Check VdiskInit remaining                        32) trace data on 2 controllers\n";
        print " 13) Find SIDs                                        33) Delete unused vdisks\n";
        print " 14) List SIDs                                        34) Set Random Priorities on vdisks\n";
        print " 15) Associate servers: select                        35) Set Default Priorities on vdisks\n";                 
        print " 16) Associate servers: by wwn                        36) Get iSCSI Target Info\n";
        print " 17) Target List                                      37) Configure (Add/Modify/Remove) iSCSI chap Information\n";
        print " 18) ServerInfo(6)                                    38) Configure iSCSI Target parameter values\n";
        print " 19) Get iSCSI chap info                              39) Georaid vdisk create menu\n";
        print " 20) Get iSCSI session statistics                     40) Set Geolocation on a drivebay\n";
        print " 41) Get Geolocation on drivebays                     42) Configure geolocation when N drivebays are present\n";
        print " 43) Label 750 drives when only 5 pdisks present      44) Get iSCSI server statistics\n";
        print " 45) Label 750 drives when 8 pdisks present\n";
        print " 90) Use a different serial number\n";
        print " 99) Exit Menu                     \n";
        print "\n\n Select an option: ";
        my $ans = <STDIN>;
        chomp ($ans);

        $option = $ans;

        print "\n\n";

        # now call functions based upon the option
        if ( $option == 1 )
        {
            $ret = LabelAllDrives($objList[$idx], 100, 2, 1, 0, 0 );    # for one drive bay
        }
        elsif ( $option == 2 )
        {
            $ret = VdiskMenu($objList[$idx]);
        }
        elsif ( $option == 3 )
        {
            $ret = MakeVdisks($objList[$idx], 2, 0 );
        }
        elsif ( $option == 4 )
        {
            $ret = MakeNWay($objPtr);
        }
        elsif ( $option == 5 )
        {
            $ret = RescanBE($objList[$idx]);
        }
        elsif ( $option == 6 )
        {
            $ret = ListSIDs($objList[$idx], 0 );
        }
        elsif ( $option == 7 )
        {
            $ret = DispVcgInfo( $objList[$idx] );
        }
        elsif ( $option == 8 )
        {
            #$ret = ShowVdisks( $objList[$idx] );
            $ret = DispVdiskInfo( $objList[$idx]  );
        }
        elsif ( $option == 9 )
        {
            $ret = DispPdiskInfo( $objList[$idx] );
        }
        elsif ( $option == 10 )
        {
            #$ret =  DispPDisks( $objList[$idx] );
        }
        elsif ( $option == 11 )
        {
            $ret =  DeleteAllVdisks( $objList[$idx] );
        }
        elsif ( $option == 12 )
        {
            $ret =  CheckInitProgress( $objList[$idx], 64);
            print "Percent left to init = $ret \n";
            if ( $ret == 0 )
            {
                $ret = GOOD;
            }
            else
            {
                $ret = ERROR;
            }
        }
        elsif ( $option == 13 )
        {
            $ret = FindSIDs($objList[$idx], 0, $wwn );
            print "Found $ret matching SIDs \n";
        }
        elsif ( $option == 14 )
        {
            $ret =  ListSIDs ($objList[$idx], 0);
        }
        elsif ( $option == 15 )
        {
            $ret =  AssociateServers($objList[$idx], 1, $wwn );
        }
        elsif ( $option == 16 )
        {
            $ret =  AssociateServers($objList[$idx], 2, $wwn );
        }
        elsif ( $option == 17 )
        {
            $ret =  TargetList( $objList[$idx] );
        }
        elsif ( $option == 18 )
        {
            $ret =  ShowServerInfo( $objList[$idx], 6 );
        }
        elsif ( $option == 19 )
        {
            print "Enter the target id to know the chap user information : ";

            my $targetid = <STDIN>;

            chomp ($targetid);

            print "\n";
            
            $ret = &TestLibs::iscsi::GetiSCSIChapInfo ($objPtr, $targetid);
        }
        elsif ( $option == 20 )
        {
            print "Enter the target id to know the iSCSI session statistics : ";

            my $targetid = <STDIN>;

            chomp ($targetid);

            print "\n";
            
            $ret = &TestLibs::iscsi::GetiSCSIStats ($objPtr, $targetid);
        }
        elsif ( $option == 21 )
        {
            $ret =  DisassocAll( $objList[$idx], 0 );
        }
        elsif ( $option == 22 )
        {
            $ret =  DeleteAllVdisks( $objList[$idx] );
        }
        elsif ( $option == 23 )
        {
            $ret =  LabelSingleDrive($objList[$idx], 0xffff, 0);
        }
        elsif ( $option == 25 )
        {
            $ret = BreakAllMirrorVdisks($objPtr);
            
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to Breaks Mirrors <<<<<");
                return (ERROR);
            }
        }    
        elsif ( $option == 26 )
        {
            $ret =  GetUsedLuns( $objList[$idx], 6, 0 );
        }
        elsif ( $option == 27 )
        {
            $ret =  GetSIDs( $objList[$idx], 0 );
        }
        elsif ( $option == 28 )
        {
            $ret = EnableCache($objList[$idx],  0);
        }
        elsif ( $option == 29 )
        {
            $ret =  DisableCache($objList[$idx],  0);
        }
        elsif ( $option == 30 )
        {
            $ret =  ExpandVdisks( $objList[$idx], 100);
        }
        elsif ( $option == 31 )
        {
            $ret = FindMaster($objPtr);
            if ( $ret != INVALID)
            {
                $ret = &TestLibs::BEUtils::FixPdiskLabels($objList[$ret], 0);
            }
            else
            {
                logInfo("Cannot determine master, unable to fix pdisk labels.");
                $ret = ERROR;
            }
        }
        elsif ( $option == 32 )
        {
            # mrp trace data for 2 controllers

            getTrace($ctlr1, "C:\\temp\\trace_master.txt");
            getTrace($ctlr2, "C:\\temp\\trace_slave.txt");
            $ret =  GOOD;
        }
        elsif ( $option == 33 )
        {
            $ret = FindMaster($objPtr);
            if ( $ret != INVALID)
            {
                $ret = &TestLibs::BEUtils::DeleteUnusedVdisks($objList[$ret], 0);
            }
            else
            {
                logInfo("Cannot determine master, unable to delete unused vdisks.");
                $ret = ERROR;
            }
                
        }
        elsif ( $option == 34 )
        {
          $ret = &TestLibs::VdiskPriority::SetRandomPriority ($objPtr);           
        }
        elsif ( $option == 35 )
        {
           $ret = &TestLibs::VdiskPriority::SetDefaultPriority ($objPtr);           
        }
        elsif ( $option == 36 )
        {
            print "Enter the target id to know the information of iSCSI Target : ";

            my $targetid = <STDIN>;

            chomp ($targetid);

            print "\n";
            
            $ret = &TestLibs::iscsi::GetiSCSIInfo ($objPtr, $targetid);
        }
        elsif ( $option == 37 )
        {
            my @opt;
            my @tid;
            my @sname;
            my @secret1;
            my @secret2;
            
            print "Enter option [0/1]: ";
            $opt[0] = <STDIN>;
            print "\n";
            chomp ($opt[0]);

            print "Enter iSCSI Target ID : ";
            $tid[0] = <STDIN>;
            print "\n";
            chomp ($tid[0]);
            
            print "Enter server name : ";
            $sname[0] = <STDIN>;
            print "\n";
            chomp ($sname[0]);
           
            print "Enter secret value 1 : ";
            $secret1[0] = <STDIN>;
            print "\n";
            chomp ($secret1[0]);
            
            print "Enter secret value 2 : ";
            $secret2[0] = <STDIN>;
            print "\n";
            chomp ($secret2[0]);

            $ret = &TestLibs::iscsi::ConfigiSCSIChapInfo( $objPtr, \@opt, \@tid, \@sname, \@secret1, \@secret2 );
        }
        elsif ( $option == 38 )
        {
            my @tid;
            my @pid;
            my @paramval;
            
            print "Enter iSCSI Target ID : ";
            $tid[0] = <STDIN>;
            print "\n";
            chomp ($tid[0]);
            
            print "Enter param to be configured : ";
            $pid[0] = <STDIN>;
            print "\n";
            chomp ($pid[0]);
           
            print "Enter iSCSI param value : ";
            $paramval[0] = <STDIN>;
            print "\n";
            chomp ($paramval[0]);
            
            $ret = &TestLibs::iscsi::ConfigiSCSITargetParam( $objPtr, \@tid, \@pid, \@paramval );
        }
        elsif ( $option == 39 )
        {
            $ret = &TestLibs::GeoRaid::GeoVdiskMenu ($objPtr, $wwn, $ipPtr );
        }
        elsif ( $option == 40 )
        {
            my $bayId;
            my $locId;
            
            print "Enter BayID : ";
            $bayId = <STDIN>;
            print "\n";
            chomp ($bayId);
            
            print "Enter GeoLocation for the bay : ";
            $locId = <STDIN>;
            print "\n";
            chomp ($locId);
 
            $ret = &TestLibs::GeoRaid::ConfigGeoLocation ($objList[$idx], $bayId, $locId );
        }
        elsif ( $option == 41 )
        {
            $ret = &TestLibs::GeoRaid::GetGeoLocation ($objList[$idx]);
        }
        elsif ( $option == 42 )
        {
            $ret = &TestLibs::GeoRaid::GeoLocationConfig($objList[$idx]);
            
            if ( $ret == ERROR )
            {
                logError(">>>>> Failed to configure geolocation <<<<<");
                return (ERROR);
            }
        }    
        elsif ( $option == 43 )
        {
            $ret = LabelAllDrives($objList[$idx], 4, 0, 1, 0, 0 );    # for one drive bay
        }
        elsif ( $option == 44 )
        {
            print "Enter the iSCSI server name: ";

            my $servername = <STDIN>;

            chomp ($servername);

            print "\n";
            
            $ret = &TestLibs::iscsi::GetiSCSIServerStats ($objPtr, $servername);
        }
        elsif ( $option == 45 )
        {
            $ret = LabelAllDrives($objList[$idx], 100, 2, 1, 0, 0 );    # for one drive bay
        }
        elsif ( $option == 90 )
        {
            print "Available controllers: \n\n";
            print "   ##      controller IP \n";
            print "   --      ------------- \n";
            for ( $i = 0; $i < $numCtlrs; $i++)
            {
                printf "  %3d   %15s  \n", $i, $ipList[$i];
            }
            print "\n\n";

            print "Enter a new controller number: ";
            my $ans = <STDIN>;
            print "\n";

            chomp ($ans);

            $ctlr1 = $ans;
            if ( ($ans < $numCtlrs)  &&  ($ans >= 0)  )
            {
                $idx = $ans;
            }
            else
            {
                print "Invalid number, try again. \n";
            }

            print "Checking license...\n";

            # make sure we have a license for this controller
            $ret = GetMyLicense( $objList[$idx], $ipList[$i], $idx);
            if ( $ret == ERROR )
            {
                logError(">>>>>>>> Error while getting a license. <<<<<<<<");
            }

            print "\n The current controller is # $idx ( $ipList[$idx] ) \n";
        }
        elsif ( $option == 99 )
        {
            return GOOD;
        }
        else
        {
            print " You have chosen poorly. Try again.\n";
        }
    }  # end while(1)

    return GOOD;
}
##############################################################################
#
#          Name: VdiskMenu
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub VdiskMenu
{
    trace();
    #print " Not ready, coming to a theater near you. \n";

    # disable cache in global config.

    my( $ctlr ) = @_;

    my $ret;
    my $option;

    print "\n\n";
    print "##################################################################################\n";
    print "############################# Vdisk Create menu ##################################\n";
    print "\n";
    print "  1) 20 Raid 5, growing size 1-5.5 GB   \n";
    print "  2) 16 mixed Raid, growing sizes        \n";
    print "  3) 20 mixed Raid, growing sizes             \n";
    print "  4) 20 Raid 10, growing sizes  \n";
    print "  5) 20 Raid 1, growing sizes (does not work)  \n";
    print "  6) 20 Raid 1, growing sizes       \n";
    print "  7) 4 Raid 10, 4 Raid 5    \n";
    print "  8) 2 Raid 10   \n";
    print "  9) 2 Raid 10, on different pdisks than 8  \n";
    print " 10) 26 Mixed Raid various sizes \n";
    print " 11) 4 Raid 10, 4 Raid 5   (on ALL pdds)    \n";
    print " 12) 3 small Raid 10 \n";
    print " 13) 2 small Raid 10 on all PDDs               \n";
#    print " 14)  \n";
#    print " 15)  \n";
#    print " 16)  \n";
    print "   \n";
    print " 18) 2 small Raid 5 \n";
    print " 19) 2 Raid 5, a little bigger  \n";
    print " 20) 12 Raid 10  \n";
    print " 21) 12 Raid 0  \n";
    print " 22) 26 mixed Raid 0,1,10  \n";
    print " 23) 26 mixed Raid 0,1,10  \n";
    print " 24) 26 mixed Raid 0,10  \n";
    print " 25) 26 mixed Raid 0,1,10  \n";
    print " 26) 26 mixed Raid 0,10  \n";
    print " 27) 26 mixed Raid 0,10  \n";
    print " 28) 26 Raid 10  \n";
    print " 29) 26 Raid 1 \n";
    print " 30) 26 mixed Raid 5,10  \n";
    print " 31) 26 Raid 5  \n";
    print " 32) 26 Raid 5 bigger, on all pdisks \n";
    print " 33) 26 mixed small Raid 10  (100-200 mb)\n";
    print " 34) 14 mixed small Raid 10  (100-200 mb)\n";
    print " 40) 26 small Raid 0,1,10, multiple groups  \n";
    print " 41) 26 small Raid 0,1,5,10, multiple groups  \n";
    print " 43) 15 Raid 10 vdisks on 750 with 5 pdisks \n";
    print " 44) 26 Raid 0,1,5(P3),10, multiple groups  \n";
    print " 45) 10 small Raid 0,1,5(P3),10, multiple groups for defrag tests \n";
    print " 46) 10 small Raid 10 vdisks on 750 with 5 pdisks for defrag tests \n";
    print "  \n";
    print "\n 99) Exit Menu                     \n";
    print "\n Selections 26-34, 40, 41 will use both Sata and Fibre bays.\n";
    print "\n\n Select an option: ";
    my $ans = <STDIN>;
    chomp ($ans);

    $option = $ans;

    print "\n\n";

    # now call functions based upon the option
    if ( $option == 99 )
    {
        return GOOD;
    }

    $ret = MakeVdisks($ctlr, $option, 0 );

    return $ret;
}

##############################################################################
#
#          Name:  DelaySecs
#
#        Inputs:  seconds
#
#       Outputs: none
#
#  Globals Used: none
#
#   Description: Delay specified number of seconds with countdown
#
#
##############################################################################
#sub DelaySecs
#{
#    my ($amount ) = @_;
#
#    while ( $amount > 0 )
#    {
#        print "Pause for $amount seconds          \r";
#        sleep 1;
#        $amount--;
#    }
#    print "                               \r";
#
#    return
#}

##############################################################################
#
#          Name: SanLinksAssoc
#
#        Inputs: $ctlr1, $ctlr2
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub SanLinksAssoc
{
    trace();

    my ( $ctlr1, $ctlr2, $wwn ) = @_;

    my @wwnList;

    my $ret;
    my @sids1;
    my @sids2;
    my %rsp;

    @wwnList = @$wwn;

    #print " WWNs to look for  @wwnList \n";



    ##  Method from Mike's scripts. case for shared drive bay
    ##
    ##  Create Server Records and associated to Vdisks.
    ##      Server A (SID 5) using 1 GB Vdisk 64 on controller A.
    ##      Controller B (SID 4) using 2 GB Vdisk 65 on controller A.
    ##      Server B (SID 5) using 3 GB Vdisk 64 on controller B.
    ##      Controller A (SID 4) using 4 GB Vdisk 65 on controller B.
    ##
    ##

    ######################
    #chgconn 0  our $ctlr1
    ######################


    print "\n\n";
    print "*********************************************************** \n";
    print "*                                                         * \n";
    print "*       CRAIG: PAY ATTENTION, this is VLINKS!!!!          * \n";
    print "*                                                         * \n";
    print "* For the first controller, indicate the SID for the      * \n";
    print "* link to the other controller and the SID to the server  * \n";
    print "* SIDs must be in the correct order.                      * \n";
    print "*********************************************************** \n";

    @sids1 = SelectServers( $ctlr1, 2 );

    logInfo("received @sids1");

    if ( INVALID == $sids1[0] )
    {
        logWarning(">>>>>>>> Failed to get server number(s) <<<<<<<<");
        return ERROR;
    }

    $ret = GOOD;               # this assignment used for debugging
    ######################
    #serverproperty 4 0 0
    ######################

    $ret = SetServerProp (  $ctlr1, $sids1[0] );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    ######################
    #serverproperty 5 0 0
    ######################
    $ret = SetServerProp (  $ctlr1, $sids1[1] );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    ######################
    #serverassoc 5 0 64
    ######################
    $ret = AssociateSingleVdisk( $ctlr1, $sids1[1], 0, 64 );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    ######################
    #serverassoc 4 0 65
    ######################
    $ret = AssociateSingleVdisk( $ctlr1, $sids1[0], 0, 65 );
    if ( ERROR == $ret )
    {
        return ERROR;
    }

    # first, find the servers to attach the drives to. we need to find
    # two

    # assumes server 4 is the link between controllers and that
    # server 5 is the link to the actual server

    ######################
    #chgconn 1        our $ctlr2
    ######################
    print "\n\n";
    print "*********************************************************** \n";
    print "* For the second controller, indicate the SID for the     * \n";
    print "* link to the other controller and the SID to the server  * \n";
    print "* SIDs must be in the correct order.                      * \n";
    print "*********************************************************** \n";

    @sids2 = SelectServers( $ctlr2, 2 );

    logInfo("received @sids2");

    if ( INVALID == $sids2[0] )
    {
        logWarning(">>>>>>>> Failed to get server number(s) <<<<<<<<");
        return ERROR;
    }

    ######################
    #serverproperty 4 0 0
    ######################
    $ret = SetServerProp (  $ctlr2, $sids2[0] );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    ######################
    #serverproperty 5 0 0
    ######################
    $ret = SetServerProp (  $ctlr2, $sids2[1] );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    ######################
    #serverassoc 5 0 64
    ######################
    $ret = AssociateSingleVdisk( $ctlr2, $sids2[1], 0, 64 );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    ######################
    #serverassoc 4 0 65
    ######################
    $ret = AssociateSingleVdisk( $ctlr2, $sids2[0], 0, 65 );
    if ( ERROR == $ret )
    {
        return ERROR;
    }

    ##
    ##  Create a Vlink from Server A to 3 GB Vdisk 65 on controller B.
    ##

    ######################
    #chgconn 0       our $ctlr1
    ######################

    #################
    # vlinkctrlcount
    #################
    print "\n";

    %rsp = $ctlr1->virtualLinkCtrlCount();

    if (!%rsp)
    {
        # no response from controller
        logInfo(">>>>>>>> Failed virtualLinkCtrlCount <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        # status was bad - print it
        logInfo(">>>>>>>> Failed: Error from virtualLinkCtrlCount <<<<<<<<");

        PrintError(%rsp);

        return ERROR;
    }
    logInfo("Number of remote controllers: " . $rsp{COUNT});

    #################
    # vlinkctrlinfo 0
    #################
    print "\n";
    %rsp = $ctlr1->virtualLinkCtrlInfo( 0 );
    if (!%rsp)
    {
        # no response from controller
        logInfo(">>>>>>>> Failed virtualLinkCtrlInfo <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        # status was bad - print it
        logInfo(">>>>>>>> Failed: Error from virtualLinkCtrlInfo <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logVirtualLinkCtrlInfo(%rsp);


    #################
    # vlinkctrlvdisks 0
    #################
    %rsp = $ctlr1->virtualLinkCtrlVDisks(0);
    if (!%rsp)
    {
        # no response from controller
        logInfo(">>>>>>>> Failed virtualLinkCtrlVDisks <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        # status was bad - print it
        logInfo(">>>>>>>> Failed: Error from virtualLinkCtrlVDisks <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logVirtualLinkCtrlVDisks(%rsp);

    #################
    # vlinkcreate 0 0
    #################
    $ret = CreateSingleVlink( $ctlr1, 0, 0 );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    #################
    # vdisklist
    #################
    $ret = ShowVdisks( $ctlr1 );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    #################
    # serverassoc 5 1 0
    #################
    $ret = AssociateSingleVdisk( $ctlr1, $sids1[1], 1, 0 );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    #################
    # serverinfo 4
    #################
    $ret = ShowServerInfo( $ctlr1, $sids2[0]);
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    #################
    # serverinfo 5
    #################
    $ret = ShowServerInfo( $ctlr1, $sids2[1]);
    if ( ERROR == $ret )
    {
        return ERROR;
    }

    ##
    ##  Create a Vlink from Server B to 2 GB Vdisk 65 on controller A.
    ##
    ########################
    # chgconn 1   our $ctlr2
    ########################

    #################
    # vlinkctrlcount
    #################
    print "\n";

    %rsp = $ctlr2->virtualLinkCtrlCount();

    if (!%rsp)
    {
        # no response from controller
        logInfo(">>>>>>>> Failed virtualLinkCtrlCount <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        # status was bad - print it
        logInfo(">>>>>>>> Failed: Error from virtualLinkCtrlCount <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }
    logInfo("Number of remote controllers: " . $rsp{COUNT});

    #################
    # vlinkctrlinfo 0
    #################
    print "\n";
    %rsp = $ctlr2->virtualLinkCtrlInfo( 0 );
    if (!%rsp)
    {
        # no response from controller
        logInfo(">>>>>>>> Failed virtualLinkCtrlInfo <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        # status was bad - print it
        logInfo(">>>>>>>> Failed: Error from virtualLinkCtrlInfo <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logVirtualLinkCtrlInfo(%rsp);

    #################
    # vlinkctrlvdisks 0
    #################
    %rsp = $ctlr2->virtualLinkCtrlVDisks(0);
    if (!%rsp)
    {
        # no response from controller
        logInfo(">>>>>>>> Failed virtualLinkCtrlVDisks <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        # status was bad - print it
        logInfo(">>>>>>>> Failed: Error from virtualLinkCtrlVDisks <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logVirtualLinkCtrlVDisks(%rsp);

    #################
    # vlinkcreate 0 0
    #################
    $ret = CreateSingleVlink( $ctlr2, 0, 0 );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    #################
    # vdisklist
    #################
    $ret = ShowVdisks( $ctlr2 );
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    #################
    # serverassoc 5 1 0
    #################
    $ret = AssociateSingleVdisk( $ctlr2, $sids2[1], 1, 0 );
    if ( ERROR == $ret )
    {
        return ERROR;
    }

    #################
    # serverinfo 4
    #################
    $ret = ShowServerInfo( $ctlr2, $sids2[0]);
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    #################
    # serverinfo 5
    #################
    $ret = ShowServerInfo( $ctlr2, $sids2[1]);
    if ( ERROR == $ret )
    {
        return ERROR;
    }
    #

    return GOOD;

    #
    # #  from sanlinks_map_vd2.cmd
    #
    #let $Mserver = 8
    #let $Sserver = 9
    #let $Vcntrl  = 0
    #
    #timeout CCBCL 600
    ##
    ##  Create Vlinks to other controller.
    ##
    #chgconn 0
    #vlinkctrlcount
    #vlinkctrlinfo $Vcntrl
    #vlinkctrlvdisks $Vcntrl
    #vlinkcreate $Vcntrl 0
    #vlinkcreate $Vcntrl 1
    #vlinkcreate $Vcntrl 2
    #vlinkcreate $Vcntrl 3
    #vlinkcreate $Vcntrl 4
    #vlinkcreate $Vcntrl 5
    #vlinkcreate $Vcntrl 6
    #vlinkcreate $Vcntrl 7
    #
    #vdisklist
    #
    #serverassoc $Mserver 1     0
    #serverassoc $Mserver 3     1
    #serverassoc $Mserver 5     2
    #serverassoc $Mserver 8 3
    #serverassoc $Mserver 10    4
    #serverassoc $Mserver 12    5
    #serverassoc $Mserver 14    6
    #serverassoc $Mserver 16    7
    #
    #serverinfo $Mserver
    #serverinfo $Sserver
    #

    return GOOD;
}


##############################################################################
#
#          Name: ShowVdisks
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub ShowVdisks
{
    trace();
    my ($ctlr1) = @_;

    logInfo("Virtual disks present");

    my %rsp = $ctlr1->getObjectList(PI_VDISK_LIST_CMD);

    if (!%rsp)
    {
        # no response from controller
        logInfo(">>>>>>>> Failed PI_VDISK_LIST_CMD <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        # status was bad - print it
        logInfo(">>>>>>>> Failed: Error from PI_VDISK_LIST_CMD <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logObjectList(%rsp);
    return GOOD;
}

##############################################################################
#
#          Name: ShowServerInfo
#
#        Inputs: Controller, server number
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################

sub ShowServerInfo
{
    trace();
    my ($ctlr, $id) = @_;

    my %rsp = $ctlr->serverInfo($id);
    if (!%rsp)
    {
        # no response from controller
        logInfo(">>>>>>>> Failed serverInfo: no response <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        # status was bad - print it
        logInfo(">>>>>>>> Failed: Error from serverInfo <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logServerInfo(%rsp);

    print "\n";

    return GOOD;
}

##############################################################################
#
#          Name: CreateSingleVlink
#
#        Inputs: controller objct, controller number to link, vdisk to link to
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub CreateSingleVlink
{
    trace();
    my ($ctlr, $cid, $vid) = @_;

    my %rsp = $ctlr->virtualLinkCreate($cid, $vid);
    if (!%rsp)
    {
        # no response from controller
        logInfo(">>>>>>>> Failed virtualLinkCreate: no response <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        # status was bad - print it
        logInfo(">>>>>>>> Failed: Error from virtualLinkCreate <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logVirtualLinkCreate(%rsp);

    return GOOD;
}

##############################################################################
#
#          Name: ElectionsTest
#
#        Inputs: master object, slave object, loops
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: perform elections 'loops' number of times on the
#                'controller object'
#
#
##############################################################################
sub ElectionsTest
{
    trace();

    my ($ctlrM, $ctlrS, $loopCount) = @_;

    my $i;
    my %rsp;
    my %rsp2;
    my $elStateM;
    my $elStateS;
    my $elStateShold;
    my $start_time;
    my $ret;

#    if ( $ctlrS == 0 )
#    {
#        logWarning(">>>>>>>> Failed, need two valid controller objects. <<<<<<<<");
#        return (ERROR);
#    }

    # a loop that starts and election, then follows it completion

    logInfo("------------ Elections test: $loopCount loops ------------");

    for ( $i = 0; $i < $loopCount; $i++ )
    {
        #add a 5 second pause after every 5 elections
		if ( (($i+1) % 5) == 0 )
		{
		    sleep 5;
		}
        #
        # first start the election
        #

        logInfo("Starting election number " . (1 + $i));

        my $procNum = 0;  #dummy value

        %rsp = $ctlrM->genericCommand("ELECTION", $procNum);

        ##
        # Remember when the election started
        ##
        $start_time = time;

        # see how the start of the election went

        if (!%rsp)                        # no response
        {
            logInfo(">>>>>>>> Failed to receive a response from ELECTION start <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} == 1)            # 1 is bad
        {
            logInfo(">>>>>>>> Failed: starting an election returned an error <<<<<<<<");
            PrintError(%rsp);
            logWarning("Failure in elections test");
            return ERROR;
        }

        ##
        # now track the progress of the election
        ##
        $elStateM = INVALID;
        $elStateShold =  0;

        # loop getting state and printing changes until election finishes
        while ( $elStateM != 0 )
        {
            ##
            # get the master's election state
            ##
            %rsp = $ctlrM->vcgElectionState();

            # see how getting the master's status went
            if (!%rsp)                        # no response
            {
                logInfo(">>>>>>>> Failed to receive a response from ELECTION status <<<<<<<<");
                return ERROR;
            }

            if ($rsp{STATUS} == 1)            # 1 is bad
            {
                logInfo(">>>>>>>> Failed: getting election status returned an error <<<<<<<<");
                PrintError(%rsp);
                logInfo("Failure in elections test");
                return ERROR;
            }

            ##
            # get the slave's election state
            ##

            if ( $ctlrS != 0 )
            {
                %rsp2 = $ctlrS->vcgElectionState();

                # see how getting the slave's status went
                if (!%rsp2)                         # no response
                {
                    logInfo(">>>>>>>> Failed to receive a response from ELECTION status <<<<<<<<");
                    return ERROR;
                }

                if ($rsp2{STATUS} == 1)             # 1 is bad
                {
                    logInfo(">>>>>>>> Failed: getting election status returned an error <<<<<<<<");
                    PrintError(%rsp2);
                    logInfo("Failure in elections test");
                    return ERROR;
                }

                $elStateShold =  $rsp2{STATE};
            }
            ##
            # Display the state changes to the console
            ##
            if ( ($elStateM != $rsp{STATE}) ||
                 ($elStateS != $elStateShold) )
            {
                # Master or slave state has changed, show it
                $elStateM = $rsp{STATE};
                my $str = sprintf("Master: [%2d]%50s\n", $elStateM, $rsp{STATE_MSG});

                if ( $ctlrS != 0 )
                {
                    $elStateS = $elStateShold;
                    $str .= sprintf(" Slave: [%2d]%50s\n", $elStateS, $rsp2{STATE_MSG});

                }
                logInfo($str);
            }
        }

        ##
        # Calculate and print how long the election took
        ##
        logInfo(sprintf("Elapsed time: %d seconds", (time - $start_time)));

# this is debug...

        #DelaySecs(5);

        $ret = CheckIOStop( $ctlrM, $ctlrS );
        if ($ret == ERROR)
        {
            return ERROR;
        }

    }

    return GOOD;
}

##############################################################################
#
#          Name: ElectionsTestNWay
#
#        Inputs: controller object list
#                idx of controller that should call the election
#                  - if idx < 0, randomly select a controller to start
#                loopCount - number of times to call the election
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: perform elections 'loops' number of times on the
#                'controller object list'
#
#
##############################################################################
sub ElectionsTestNWay
{
    trace();

    my ($coPtr, $coIndex, $loopCount) = @_;

    my @coList = @$coPtr;
    my $numCtlrs = scalar(@coList);

    my $ctlr0;
    my $ctlr0Idx;
    my $ctlr;
    my $ctlrIdx;
    my $i;
    my %rsp;
    my $start_time;
    my $ret;
    my %lastState;
    my $productID =  getMagProductID( 0, @coList );  # Get the product ID
    # a loop that starts and election, then follows it completion

    logInfo("------------ Elections test: $loopCount loops ------------");

    for ( $i = 0; $i < $loopCount; $i++ )
    {
        # Initialize all of the last state vars
        foreach $ctlrIdx (0..($numCtlrs-1))
        {
            $lastState{$ctlrIdx} = -1;
        }

        #
        # first start the election
        #

        logInfo("Starting election number " . (1 + $i));

        my $procNum = 0;  #dummy value

        if ($coIndex < 0)
        {
            $ctlr0Idx = int(rand($numCtlrs));
            $ctlr0 = $coList[$ctlr0Idx];
        }
        else
        {
            $ctlr0Idx = $coIndex;
            $ctlr0 = $coList[$coIndex];
        }

        %rsp = $ctlr0->genericCommand("ELECTION", $procNum);

        ##
        # Remember when the election started
        ##
        $start_time = time;

        # see how the start of the election went

        if (!%rsp)                        # no response
        {
            logInfo(">>>>>>>> Failed to receive a response from ELECTION start <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} == 1)            # 1 is bad
        {
            logInfo(">>>>>>>> Failed: starting an election returned an error <<<<<<<<");
            PrintError(%rsp);
            logWarning("Failure in elections test");
            return ERROR;
        }

        ##
        # now track the progress of the election
        ##

        # loop getting state and printing changes until election finishes
        while ( $lastState{$ctlr0Idx} != 0 )
        {
            foreach $ctlrIdx (0..($numCtlrs-1))
            {
                $ctlr = $coList[$ctlrIdx];

                ##
                # get the starter's election state (note: this isn't necessarily
                # the master)
                ##
                %rsp = $ctlr->vcgElectionState();

                # see how getting the master's status went
                if (!%rsp)                        # no response
                {
                    logInfo(">>>>>>>> No response from vcgElectionState() <<<<<<<<");
                    return ERROR;
                }

                if ($rsp{STATUS} == 1)            # 1 is bad
                {
                    logInfo(">>>>>>>> Got an error from vcgElectionState() <<<<<<<<");
                    PrintError(%rsp);
                    logInfo("Failure in elections test");
                    return ERROR;
                }

                ##
                # Display the state changes to the console
                ##
                
                

                if ($productID == 5000 or $productID == 7000 )
                {
                $lastState{$ctlr0Idx} = 0;
                }
                else
                {
                if ( $rsp{STATE} != $lastState{$ctlrIdx} )
                {
                    $lastState{$ctlrIdx} = $rsp{STATE} ;

                    my $str = sprintf("$ctlr->{'HOST'}: [%2d]%50s\n",
                                    $lastState{$ctlrIdx}, $rsp{STATE_MSG});

                    logInfo($str);
                }
                }
            }
        }

        ##
        # Calculate and print how long the election took
        ##
        logInfo(sprintf("Elapsed time: %d seconds", (time - $start_time)));

        # Check to see if this is a Nitrogen System, if so skip the test.  Global Cache is not supported
        #
        # Check stop counts
        #
        

        if ($productID == 5000 or $productID == 7000 )
        {
        }
        else
        {
        $ret = CheckIOStopNWay($coPtr);
        if ($ret == ERROR)
        {
            return ERROR;
        }
       }
    }

    return GOOD;
}

##############################################################################
#
#          Name: CheckIOStop
#
#        Inputs: controller object, slave controller object
#
#       Outputs: GOOD, if both IO stop counts are 0, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
##############################################################################
sub CheckIOStop
{
    my ( $ctlr1, $ctlr2 ) = @_;

    my $ret1;
    my $ret2 = 0;
    my %rsp;


    # get stop count from master

    %rsp = $ctlr1->globalCacheInfo();

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get globalCacheInfo from master <<<<<<<<");
        return (ERROR);
    }

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            $ret1 = $rsp{CA_STOPCNT};
            logGlobalCacheInfo(%rsp);
            logInfo("Master stop count = $ret1 ");
        }
        else
        {
            logInfo(">>>>>>>> Error getting globalCacheInfo from master <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }



    # get stop count from slave

    if ($ctlr2)
    {
        %rsp = $ctlr2->globalCacheInfo();

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get globalCacheInfo from slave <<<<<<<<");
            return (ERROR);
        }

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                $ret2 = $rsp{CA_STOPCNT};
                logGlobalCacheInfo(%rsp);
                logInfo("Slave stop count = $ret2 ");
            }
            else
            {
                logInfo(">>>>>>>> Error getting globalCacheInfo from slave <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }
        }

        # check results
        if ( ($ret1 > 2) || ($ret2 > 2) )
        {
            # we failed, print result, get trace
            logInfo("Incorrect stop counts found");

            getTrace($ctlr1, "C:\\temp\\fail_master.txt");
            getTrace($ctlr2, "C:\\temp\\fail_slave.txt");

            return ERROR;
        }
    }
    else
    {
        # check results
        if ( $ret1 > 2 )
        {
            # we failed, print result, get trace
            logInfo("Incorrect stop counts found");

            getTrace($ctlr1, "C:\\temp\\fail_master.txt");

            return ERROR;
        }
    }

    return GOOD;
}


##############################################################################
#
#          Name: CheckIOStopNWay
#
#        Inputs: controller object list
#
#       Outputs: GOOD, if all IO stop counts are 0, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
##############################################################################
sub CheckIOStopNWay
{
    my ($coPtr) = @_;

    my @coList = @$coPtr;
    my $numCtlrs = scalar(@coList);
    my $ctlr;
    my $ctlrIdx;

    my %rsp;
    my $ret;
    my $maxRet = 0;
    my $overallRC = GOOD;


    foreach $ctlrIdx (0..($numCtlrs-1))
    {
        $ctlr = $coList[$ctlrIdx];

        %rsp = $ctlr->globalCacheInfo();

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get globalCacheInfo from $ctlr->{'HOST'} <<<<<<<<");
            $overallRC = ERROR;
        }

        if (%rsp)
        {
            if ($rsp{STATUS} == PI_GOOD)
            {
                $ret = $rsp{CA_STOPCNT};
                logGlobalCacheInfo(%rsp);
                logInfo("$ctlr->{'HOST'} stop count = $ret");
                if ($ret > $maxRet)
                {
                    $maxRet = $ret;
                }
            }
            else
            {
                logInfo(">>>>>>>> Error getting globalCacheInfo from $ctlr->{'HOST'} <<<<<<<<");
                PrintError(%rsp);
                $overallRC = ERROR;
            }
        }
    }

    if ($overallRC != GOOD or $maxRet > 2)
    {
        # we failed, print result, get trace
        logInfo(">>>>>>>> Incorrect stop counts found <<<<<<<<");

        foreach $ctlrIdx (0..($numCtlrs-1))
        {
            $ctlr = $coList[$ctlrIdx];
            getTrace($ctlr, "c:\\temp\\StopCountFail_$ctlr->{'HOST'}.txt");
        }
    }

    return $overallRC;
}


##############################################################################
# Get Trace Info
##############################################################################
sub getTrace
{
    my($obj, $outfile) = @_;


    my %rsp = $obj->generic2Command("TRACE");

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {

            print "Writing trace data to $outfile ...\n";
            my $rc = open OF, ">$outfile";
            if (!$rc) {
                print "Couldn't open $outfile ...\n";
            }
            else {
                binmode OF;
                print OF $rsp{DATA};
                close OF;
            }
        }
    }

}



##############################################################################
#
#          Name: CreateExpandInitDelete
#
#        Inputs: controller object, loops, subloops, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: A test to create a vdisk and expand it several times,
#                then init the new raids and monitor until they are done.
#                Delete the vdisk and repat the whole thing.
#
#                The option is bit sensitive. Bit 0 (LSB),if set, skips the
#                deletion of the vdisk. Bit 1 skips the wait for the
#                inits to complete.
#
#
##############################################################################
sub CreateExpandInitDelete
{
    trace();

    my ($ctlr, $loopCount, $numExp, $option) = @_;

    my $i;
    my $j;
    my $k;
    my $remaining;

    my %rsp;
    my %ret;
    my %rsp2;
    my $vdd;
    my $ourSN;
    my $diskSN;
    my @A_ll;

    use constant  NODELETEBIT   => 1;
    use constant  NOINITWAITBIT => 2;

    logInfo("VDISK create/expand/delete test");

    ###############################################################
    #
    # setup for the test: get SN, list of vdisks
    ###############################################################

    #
    # first we've got to get a list of vdisks
    #

    # get our serial number, used to see if we will own a drive

    $ourSN = GetGroupSerial( $ctlr );
    logInfo("Getting physical disk list for controller $ourSN");
    if ( INVALID == $ourSN  )
    {
        logWarning(">>>>>>>> Failed to get controller's serial number <<<<<<<<");
        return (ERROR);
    }
    my %LIST = $ctlr->physicalDiskList();

    if ( ! %LIST )     # no response from controller
    {
        logInfo(">>>>>>>> Failed to get pdisk list (no response) <<<<<<<<");
        return ERROR;
    }
    else                          # got a response
    {
        if ( $LIST{STATUS} == PI_GOOD )
        {
            # good path - this is expected
            logInfo("physical disk list is good, now walking it");
        }
        else
        {
            # got an error, report it, bail
            logInfo(">>>>>>>> Failed tgetting pdisk list <<<<<<<<");
            PrintError(%LIST);
            return ERROR;
        }
    }

    my $LIST1 = $LIST{LIST};
    my @disks = @$LIST1;


    # go thru the disk list and count the data and unsafe disks. keep
    # an array of each

    for(my $i = 0; $i < scalar(@disks); ++$i)
    {
        # get the disk's information (type)
        my %diskhash = $ctlr->physicalDiskInfo($disks[$i]);
# need an error check here

        debug("diskhash = " . %diskhash);

        # let's see if we 'own' this disk. To own it, the serial number
        # must be ours.

        $diskSN = $diskhash{PD_SSERIAL};

        debug("disksn = $diskSN , oursn - $ourSN");

        # compare to our SN, if match we can use
        if ( $ourSN == $diskSN )
        {
            # OK to use this drive - put in right group

            if($diskhash{PD_CLASS} == CCBEDATATYPE)
            {
                # add data drive to array
                push(@A_ll, $disks[$i]);
            }
        }
    }


    ##################################################################
    #
    #  Start of the test loop
    #
    ##################################################################

    logInfo("starting test loop");

    # for loopCount times
    for ( $i = 0; $i < $loopCount; $i++ )
    {
        ##########################################
        # create a vdisk ( save the vdisk number )
        ##########################################
        logInfo("Creating the virtual disk for the test");


        $vdd = CreateSingleVdisk($ctlr, "NoName", 500, RAID_10, 128, 3, 0, \@A_ll, undef);

        if ( $vdd == INVALID )
        {
            return ERROR;
        }

   #     %ret = $ctlr->virtualDiskCreate( 1000000,     #  $capacity,
   #                                     \@A_ll,       #  $pdPointer,
   #                                     RAID_10,      #  $rtype,
   #                                     128,           #  $stripe,
   #                                     3,            #  $depth,
   #                                     5 );          #  $parity);
   #
   #
   #     if ( ! %ret  )              # if no return from call
   #     {
   #         logInfo(">>>>>>>> Failed to get response from virtualDiskCreate <<<<<<<<");
   #         return ERROR;
   #     }
   #
   #     debug("%ret");
   #
   #     if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
   #     {
   #         logInfo(">>>>>>>> Error from virtualDiskCreate <<<<<<<<");
   #         PrintError(%ret);
   #         return ERROR;
   #     }
   #
   #     $vdd = $ret{VID};        # the VDD that was created

        logInfo("Vdisk $vdd created");

#        %ret = $ctlr ->virtualDiskInfo($vdd);
#
#        if ( ! %ret  )              # if no return from call
#        {
#            logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
#            return ERROR;
#        }
#
#        if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
#        {
#            logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
#
#            PrintError(%ret);
#
#            return ERROR;
#        }
#
#
#
#
#        my @raids;               # array we recreate every time
#
#        my $totalRaids = $ret{RAIDCNT} + $ret{DRAIDCNT};
#
#            print  "  Raid IDs:\n";
#
#        for ($j = 0; $j < $totalRaids; $j++)
#        {
#            printf "    %hu\n", $ret{RIDS}[$j];
#            $raids[$j] = $ret{RIDS}[$j];
#        }
#

        ShowRids ($ctlr, $vdd);

        # for NumExp times
        for ( $j = 0; $j < $numExp; $j++ )
        {
            ##########################################
            # expand the capacity
            ##########################################

            logInfo("Expanding the virtual disk");

            %ret = $ctlr->virtualDiskExpand( $vdd,        #  vdd to expand
                                            1000000,      #  $capacity,
                                            \@A_ll,       #  $pdPointer,
                                            RAID_10,      #  $rtype,
                                            64,           #  $stripe,
                                            3,            #  $depth,
                                            5 );          #  $parity);


            if ( ! %ret  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
                return ERROR;
            }

            debug("%ret");

            if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
                PrintError(%ret);
                return ERROR;
            }

            $vdd = $ret{VID};        # the VDD that was created

            logInfo("Vdisk $vdd expanded");
            ShowRids($ctlr, $vdd);
        }

        ##########################################
        # start an init on the new raid
        ##########################################

        InitVdiskRids($ctlr, $vdd);

        # monitor the inits until they are all done

        if ( ($option & NOINITWAITBIT) == 0 )
        {
            logInfo("Waiting for vdisk $vdd to become operational");

            while ( 0 != ( $remaining = CheckInitProgress($ctlr, $vdd ) ) )
            {
                print "$remaining percent left to initialize \r";
                # pause for a second or 2
                sleep 2;
            }
        }

        # when done with the inits, check the status

        ##########################################
        # finally delete the vdisk
        ##########################################

        if ( ($option & NODELETEBIT) == 0 )
        {
            logInfo("deleting vdisk $vdd");

            if ( ERROR == DeleteSingeVdisk($ctlr, $vdd) )
            {
                return ERROR;
            }
            else
            {
                logInfo("VDisk ID =  $vdd was deleted");
            }


        }
     }
    return GOOD;
}


##############################################################################
#
#          Name: ShowRids
#
#        Inputs: controller, vdd number
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: displays the RIDs associated to a vdisk
#
#
##############################################################################
sub ShowRids
{
    trace();
    my ($ctlr, $vdd) = @_;

    my %ret;
    my $j;

    %ret = $ctlr ->virtualDiskInfo($vdd);

    if ( ! %ret  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
        return ERROR;
    }

    if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
        PrintError(%ret);
        return ERROR;
    }

    my @raids;               # array we recreate every time

    my $totalRaids = $ret{RAIDCNT} + $ret{DRAIDCNT};

    my $str = "\nRaid IDs:\n";

    for ($j = 0; $j < $totalRaids; $j++)
    {
        $str .= sprintf("    %hu\n", $ret{RIDS}[$j]);
        $raids[$j] = $ret{RIDS}[$j];
    }
    logInfo($str);
    return GOOD;
}

##############################################################################
#
#          Name:  InitVdiskRids
#
#        Inputs:  controller object, VDD number
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Get the RDDs for a given VDD and start raid init.
#
#
##############################################################################
sub InitVdiskRids
{                                                                          trace();
    my ($ctlr, $vdd) = @_;

    my %ret;
    my %rtn;
    my $j;


    %ret = $ctlr ->virtualDiskInfo($vdd);

    if ( ! %ret  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
        return ERROR;
    }

    if ( $ret{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
        PrintError(%ret);
        return ERROR;
    }

    my @raids;               # array we recreate every time

    my $totalRaids = $ret{RAIDCNT} + $ret{DRAIDCNT};

    logInfo("Raid IDs");

    for ($j = 0; $j < $totalRaids; $j++)
    {
        logInfo(sprintf("%hu\n", $ret{RIDS}[$j]));

        $raids[$j] = $ret{RIDS}[$j];            # not used

        #now init this raid drive

        %rtn = $ctlr->virtualDiskInit($ret{RIDS}[$j]);

        if ( ! %rtn )               # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskInit <<<<<<<<");
            return ERROR;
        }

        if ( ($rtn{STATUS} != PI_GOOD) && ( $ctlr->PI_ERROR_INIT_IN_PROG != $rtn{ERROR_CODE} ) )
        {
            # if call returned an error, but not init in progress

            logInfo(">>>>>>>> Error from virtualDiskInit <<<<<<<<");
            print "ERROR---VD Raid_ID $ret{RIDS}[$j] was NOT Initialized  \n";
            PrintError(%rtn);
            return ERROR;
        }

        # no error from virtualDiskInit

        logInfo("Initialize started on VD Raid_ID $ret{RIDS}[$j]");
    }

    return GOOD;
}


##############################################################################

##############################################################################
# Name:     disableHealthMonitor
#
# Desc:     Sets the mode bits.
#
# Input:    bits and masks.
##############################################################################
sub disableHealthMonitor
{
    trace();
    my ($obj) = @_;

    my %bitHash;

    my $rc = GOOD;


    $bitHash{CCB_BITS1}         =0x6B;        # 0x6f >> 0x6b for m550
    $bitHash{CCB_BITS_MASK1}    =0x6B;
    $bitHash{PROC_BITS1}        =0x00;
    $bitHash{PROC_BITS2}        =0x01;
    $bitHash{PROC_BITS3}        =0;
    $bitHash{PROC_BITS4}        =0;
    $bitHash{PROC_BITS_MASK1}   =0;
    $bitHash{PROC_BITS_MASK2}   =0;
    $bitHash{PROC_BITS_MASK3}   =0;
    $bitHash{PROC_BITS_MASK4}   =0;


    # Randy recently added these
    $bitHash{CCB_BITS_DPRINTF}      = 0;
    $bitHash{CCB_BITS_DPRINTF_MASK} = 0;
    $bitHash{CCB_BITS_RSVD1}        = 0;
    $bitHash{CCB_BITS_RSVD1_MASK}   = 0;
    $bitHash{CCB_BITS_RSVD2}        = 0;
    $bitHash{CCB_BITS_RSVD2_MASK}   = 0;



    my %rsp = $obj->modeDataSet(%bitHash);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo("Mode bits set successful");
        }
        else
        {
            logInfo(">>>>>>>> Unable to set mode bits. <<<<<<<<");
            PrintError( %rsp);
            $rc = ERROR;
        }
    }
    else
    {
#        print "ERROR: Did not receive a response packet.\n";
#        logout();
        $rc = ERROR;
    }

    return $rc;
}

##############################################################################
#
#          Name: GetPddList
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: assumes all drives are owned by the controller
#                used by re-label test
#
##############################################################################
sub GetPddList
{
    trace();
    my ($ctlr) = @_;
    my @driveList;
    my $i;
    my %drives;
    # do a devstat to get the list of drives and status of each
    #   have to do this with pdisklist and pdiskinfo as devstat seems to
    #   be missing

    %drives = $ctlr->physicalDisks();  # get list of drives present

    if( ! %drives )
    {
        logInfo(">>>>>>>> Failed to get physical disk list. <<<<<<<<");

        push (@driveList, INVALID);
        return @driveList;
    }

    if ( $drives{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from physicalDisks command <<<<<<<<");
        PrintError(%drives);
        push (@driveList, INVALID);
        return @driveList;
    }

    # check each drive in the list

    # build an array of all the good ones. To be good a drive must have
    # 'operational' status

    for ( $i = 0; $i < $drives{COUNT}; $i++)     # for each drive
    {
        if (($drives{PDISKS}[$i]{PD_DEVSTAT} == 0x10))  # if drive is good
        {
            push (@driveList, $drives{PDISKS}[$i]{PD_PID});
        }
    }
    if ( 0 == $drives{COUNT} )
    {
        logInfo(">>>>>>>> No drives to work with. <<<<<<<<");
        push (@driveList, INVALID);
        return @driveList;
    }

    return @driveList;
}
##############################################################################
#
#          Name: GetDataDisks
#
#        Inputs: controller object
#                (optional) interface type
#                   - PD_DT_ALL       ALL disk types
#                   - PD_DT_FC_DISK   FC disks only (default)
#                   - PD_DT_SATA      SATA disks only
#                   - FC_PREFERRED  
#                   - SATA_PREFERRED 
#                       The preferred options will return only the type of disk
#                       preferred (FC or SATA) unless there are not enough of
#                       that type available (at least 5).  If there are not 
#                       enough available, it will then return the other type, 
#                       if there are enough of that type available. 
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: returns list of vdisks, or INVALID as the first one
#
##############################################################################
sub GetDataDisks
{
    trace();
    my ($ctlr, $hdType) = @_;
    my @drives;
    my $numDrives;
    my $preferredOption = FALSE;
    my $preferredType;
    my $tryAlternateType = FALSE;

    #
    # If type is not passed in, default to FC only for backwards compatability
    #     
    if ( !defined($hdType) )
    {
        $hdType = FC_PREFERRED;
    }
    
    #
    # if one of the preferred options was selected, save the initial option, 
    # set the type to the preferred type, set the $preferredOption flag
    #
    

    if ($hdType == FC_PREFERRED)
    {
        $preferredType = $hdType;
        $hdType = PD_DT_FC_DISK;
        $preferredOption = TRUE;
    }
    elsif ($hdType == SATA_PREFERRED)
    {
        $preferredType = $hdType;
        $hdType = PD_DT_SATA;
        $preferredOption = TRUE;
    }    
    MAIN:
    {

        #
        # If we are coming back thru to try the other type, switch types
        #

        if ($tryAlternateType == TRUE) 
        {
            if ($hdType == PD_DT_FC_DISK)
            {
                $hdType = PD_DT_SATA;
            }
            elsif ($hdType == PD_DT_SATA)
            {
                $hdType = PD_DT_FC_DISK;
            }
        }
        #
        # Get the drives of the specified type
        #
        @drives = GetTheseDisks( $ctlr, CCBEDATATYPE, $hdType);
        if ( $preferredOption == TRUE )
        {
            #
            # Looking for a preferred type of disk.  If it fails, or not enough
            # of that type are available, go back and look for the alternate 
            # type
            #
            if ( $drives[0] == INVALID )
            {
                if ( $tryAlternateType == TRUE )
                {
                    logInfo(">>>>>>>> No data drives of alternate type available. <<<<<<<<");
                    return @drives;
                }
                else 
                {
                    logInfo("No data drives of preferred type available.");
                    logInfo("Checking for data drives of alternate type.");
                    $tryAlternateType = TRUE;
                    redo MAIN;
                }
            }    
       
            #
            # Verify enough drives available
            # 
            $numDrives = scalar(@drives);        
            if( $numDrives < 3 ) 
            {
                if ( $tryAlternateType == TRUE )
                {
                    logInfo(">>>>>>>> Not enough data drives of alternate type to work with. <<<<<<<<");
                    logInfo("There are only $numDrives data drives available: @drives \n");
                    $drives[0] = INVALID;
                    return @drives;
                }
                else
                {
                    logInfo("Not enough data drives of preferred type to work with.");
                    logInfo("There are only $numDrives data drives available: @drives \n");
                    logInfo("Checking for data drives of alternate type.");
                    $tryAlternateType = TRUE;
                    redo MAIN;
                }
            }    
        }
        else   # not a preferred option
        {
            #
            # This path looking for a specific type.  If that type is not found,
            # we are done.
            # 
            if ( $drives[0] == INVALID )
            {
                logInfo(">>>>>>>> No data drives available <<<<<<<<");
                return @drives;
            }    
        
            $numDrives = scalar(@drives);        
            if( $numDrives < 3 )
            {
                logInfo(">>>>>>>> Not enough data drives to work with. <<<<<<<<");
                logInfo("There are only $numDrives data drives available: @drives \n");
                $drives[0] = INVALID;
                return @drives;
            }    
        }
        
        #
        # If we got here, we have a valid list of drives to return
        #
        return @drives;
        
    }  # end of MAIN
}



##############################################################################
#
#          Name: GetVdiskList
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: returns list of vdisks, or INVALID as the first one
#
##############################################################################
sub GetVdiskList
{
    trace();
    my ($ctlr) = @_;
    my @driveList;
    my $i;
    my %drives;
    my %rsp;

    # get list of vdisks

    %rsp = $ctlr->getObjectList(PI_VDISK_LIST_CMD);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from PI_VDISK_LIST_CMD <<<<<<<<");
        push (@driveList, INVALID);
        return @driveList;
    }


    if ($rsp{STATUS} == PI_GOOD)
    {
        logInfo("Virtual Disk List");

        # logObjectList(%rsp);
        # in here is my list of disks.. now how do i extract it?
        # need to build this array >>>> @vdisklistarray = @$vdisklist;       # make an array
    }
    else
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        PrintError(%rsp);
        push (@driveList, INVALID);
        return @driveList;
    }

    # put drives into an array
    for ( $i=0; $i< $rsp{COUNT}; $i++)
    {
        push  @driveList, $rsp{LIST}[$i];
    }

    if (  $rsp{COUNT} == 0 )
    {
        push (@driveList, INVALID);
        return @driveList;
    }

    logInfo(" @driveList ");

    return @driveList;
}

##############################################################################
#
#          Name: GetDriveLabel
#
#        Inputs: controller object, drive number
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: gets the class (type) of the drive
#                used by re-label test
#
##############################################################################
sub GetDriveLabel
{
    trace();
    my ($ctlr, $drv) = @_;
    my $type;

    my %rsp = $ctlr->physicalDiskInfo($drv);

    if (!%rsp)                        # no response
    {
        logInfo(">>>>>>>> Failed to receive a response from physicalDiskInfo <<<<<<<<");
        return INVALID;
    }

    if ($rsp{STATUS} == 1)            # 1 is bad
    {
        logInfo(">>>>>>>> Failed: physicalDiskInfo returned an error <<<<<<<<");
        PrintError(%rsp);
        return INVALID;
    }
    return $rsp{PD_CLASS};
}
##############################################################################
#
#          Name: ReLabelSingleDrive
#
#        Inputs: controllerID, driveID, type
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Labels the specified drive on the specified controller
#                Will generally succeed but will fail if the drive does
#                not exist, the type is wrong, ot the controller signals
#                an error.
#
#
##############################################################################
sub ReLabelSingleDrive
{
    trace();
    my ( $controller, $pdd, $type ) = @_;
    my $i;
    my %rsp;
    my @pddList;

    my $zero = 0;

    # labels a drive, if pdd is 0xffff, than all drives at once

    debug("labeling $controller, $pdd, $type");

    if ( 0xffff == $pdd )
    {
        # all drive case, build the list

        my %rsplist = $controller->physicalDiskList();

        if (%rsplist)
        {
            if ($rsplist{STATUS} == PI_GOOD)
            {
                for $i (0..$#{$rsplist{LIST}})
                {
                    $pddList[$i] = $rsplist{LIST}[$i];
                }
            }
            else
            {
                logInfo(">>>>>>>> Error getting a pdd list <<<<<<<<");
                PrintError(%rsplist);
                return ERROR;
            }
        }
        else
        {
            logInfo(">>>>>>>> Failed to get a pdd list <<<<<<<<");
            return ERROR;
        }
    }
    else
    {
        # single drive case, just populate the array
        $pddList[0] = $pdd;
    }

    %rsp = $controller->physicalDiskLabel(\@pddList, $type, $zero, $zero );

    if ( %rsp )
    {

        debug("label status $rsp{STATUS}");

        if ($rsp{STATUS} == PI_GOOD)
        {
            debug("Physical disk ($pdd) labeled ($type).");
        }
        else
        {
            logInfo(">>>>>>>> Failed to label pdd # $pdd as $type <<<<<<<<");
            PrintError(%rsp);
            return (ERROR);
        }
    }
    else
    {
        logInfo(">>>>>>>> Did not receive a response packet.\n <<<<<<<<");
        return (ERROR);
    }

    return GOOD;
}

##############################################################################
#
#          Name: ReLabelPD
#
#        Inputs: controller object, loop count
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: assumes all drives are owned by the controller
#
#
##############################################################################

sub ReLabelPD
{
    trace();

    my ($ctlr, $loops) = @_;

    my $i;
    my $j;
    my $type;
    my $typeV;
    my @drives;
    my $ret;

    logInfo("PDisk re-label test, $loops loops");

    # need a longer timeout for this
    my $value = 400;
    logInfo("Setting MRP timeout to $value seconds");
    my %rsp = $ctlr->timeoutMRP("MRP", $value);

    if (!%rsp)                        # no response
    {
        logInfo(">>>>>>>> Failed to receive a response from timeoutMRP <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} == 1)            # 1 is bad
    {
        logInfo(">>>>>>>> Failed: timeoutMRP returned an error <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    # assumes success

    for ( $i = 0; $i < $loops; $i++ )
    {
        #  get a list of physical disks
        @drives = GetPddList( $ctlr);
        if ( $drives[0] == INVALID )
        {
            return ERROR;
        }

        logInfo("LOOP # $i, drive list: @drives");

        # for each PDD, get label, re-label, get label (to confirm)

        for ( $j = 0; $j < scalar(@drives); $j++ )
        {
            # start time
            my ($sec_b, $min_b, $hour_b) = CORE::localtime(time);

            ###### get the label
            $type = GetDriveLabel( $ctlr, $j );
            if ( $type == INVALID )
            {
                return ERROR;
            }
            logInfo(sprintf("Drive %3d is class %2d .", $j, $type));

            ###### label the disk
            $ret = ReLabelSingleDrive( $ctlr, $drives[$j], $type);
            if ( $ret == ERROR )
            {
                logWarning(">>>>>>>> Failed to label drive $j as $type <<<<<<<<");
                return (ERROR);                # bail on an error
            }
            logInfo("labeled");

            ###### verify the label
            $typeV = GetDriveLabel( $ctlr, $j );
            if ( $typeV == INVALID )
            {
                return ERROR;
            }
            if ( $type == $typeV )
            {
                logInfo("verified as class $typeV");
            }
            else
            {
                logInfo("verify failed: got class $typeV");
                return ERROR;
            }

            my ($sec_e, $min_e, $hour_e) = CORE::localtime(time);
            CalcTime("physicalDiskLabel", $sec_b, $min_b, $hour_b, $sec_e, $min_e, $hour_e);
        }
    }
}
##############################################################################
# Name:     CalcTime
#
# Desc:     Calculates time for single command execution
#
# In:       $sec_b  - Sec at the Beginning
#           $min_b  - Min at the Beginning
#           $hour_b - Hour at the Beginning
#           $sec_e  - Sec at the End
#           $min_e  - Min at the End
#           $hour_e - Hour at the End
#
# Returns:  $TimeExecute - Time took to execute the command
#
##############################################################################

#sub CalcTime
#{
#    trace();
#    my ($command, $sec_b, $min_b, $hour_b, $sec_e, $min_e, $hour_e) = @_;
#    my $TimeStampB = (($hour_b * 3600) + ($min_b * 60) + $sec_b);
#    my $TimeStampE = (($hour_e * 3600) + ($min_e * 60) + $sec_e);
#    my $TimeExecute = $TimeStampE - $TimeStampB;
##    print "\n", "TimeStampB  ", "  >>>>>>>>>>>> ", "$TimeStampB time of the day in sec \n";
##    print       "TimeStampE  ", "  >>>>>>>>>>>> ", "$TimeStampE time of the day in sec \n";
##    print       "TimeExecute ", "  >>>>>>>>>>>> ", "$TimeExecute sec \n";
#
##    print OUT "\n", "TimeStampB  ", "  >>>>>>>>>>>> ", "$TimeStampB time of the day in sec \n";
##    print OUT       "TimeStampE  ", "  >>>>>>>>>>>> ", "$TimeStampE time of the day in sec \n";
##    print OUT       "TimeExecute ", "  >>>>>>>>>>>> ", "$TimeExecute sec \n";
#
##    if($TimeExecute > 5)
##    {
##       print "\n", "WARNING: TOOK $TimeExecute sec to EXECUTE $command  \n";
##    }
##    else
##    {
#       loginfo(sprintf("TIME: %3d sec \n", $TimeExecute));
##    }
#
#    return $TimeExecute;
#}
#
##############################################################################
#
#          Name: CacheCycleTest
#
#        Inputs: controller object, count
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Turns global cache on (and on drives, if needed), turns
#                global cache bit off. Repeats 'count' number of times.
#
#
##############################################################################
sub CacheCycleTest
{
    trace();
    my ($ctlr1, $c )= @_;
    my $ret;
    my $delay = 20;

    logInfo("Turning write cache on and off $c times using delay = $delay seconds");

    while ( $c > 0 )
    {
        logInfo("Loops to go $c");

        $ret = EnableCache($ctlr1,  0);
        if ( GOOD != $ret )
        {
            logWarning(">>>>>>>> Failed while enabling write cache <<<<<<<<");
            return (ERROR);
        }

        DelaySecs( $delay );

        $ret = DisableCache($ctlr1,  0);
        if ( GOOD != $ret )
        {
            logWarning(">>>>>>>> Failed while disabling global write cache <<<<<<<<");
            return (ERROR);
        }

        DelaySecs( $delay );

        $c--;
    }
    return GOOD;
}

##############################################################################
#
#          Name: GetAllVdiskDataDisks
#
#        Inputs: controller object
#
#       Outputs: An array of all the data disk pids that are part of a vdisk.
#                Note: if an error occurs, INVALID is the first item in the
#                array which means that the returned array is no good.  Note:
#                the data pids that are returned are owned by the specified
#                controller.
#
#  Globals Used: none
#
#   Description: Gets the data drives that are part of some vdisk and are owned
#                by the specified controller.
#
#
##############################################################################
sub GetAllVdiskDataDisks
{
    trace();
    my ($ctlr) = @_;      # The controller object
    my $ourSN;            # The serial number for this controller
    my @dataDisks;        # The dataDisk array to be returned.
    my %LIST;             # The list of physical disks
    my %info;             # Device status information (devstat info)

    # Get our serial number
    $ourSN = GetGroupSerial( $ctlr );
    if ( INVALID == $ourSN  )
    {
        logWarning(">>>>>>>> Failed to get controller's serial number <<<<<<<<");
        $dataDisks[0] = INVALID;
        return @dataDisks;
    }

    # Get the current information
    my $ret = RescanBE( $ctlr );
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> BE rescan failed <<<<<<<<");
        $dataDisks[0] = INVALID;
        return @dataDisks;
    }

    # Get the list of physical disks
    %LIST = $ctlr->physicalDiskList();

    if ( ! %LIST )               # No response from the controller
    {
        logInfo(">>>>>>>> Failed to get pdisk list (no response) <<<<<<<<");
        $dataDisks[0] = INVALID;
        return @dataDisks;
    }
    else                         # Got a response from the controller
    {
        if ( $LIST{STATUS} == PI_GOOD )
        {
            # This is the 'good' path...the path that is expected
            logInfo("Disk list is good, now looking for data disks that are part of vdisks");
        }
        else
        {
            # Got an error, report it and bail
            logInfo(">>>>>>>> Failed getting pdisk list <<<<<<<<");
            PrintError(%LIST);
            $dataDisks[0] = INVALID;
            return @dataDisks;
        }
    }

    # Get the device status information for raids so that it can later be used
    # to find out which data disks are part of a vdisk
    %info = $ctlr->deviceStatus("RD");

    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from deviceStatus <<<<<<<<");
        $dataDisks[0] = INVALID;
        return @dataDisks;;
    }

    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get device status <<<<<<<<");
        PrintError(%info);
        $dataDisks[0] = INVALID;
        return @dataDisks;;
    }

    my $LIST1 = $LIST{LIST};
    my @disks = @$LIST1;

    # Go thru the disk list and look for data disks
    for(my $i = 0; $i < scalar(@disks); ++$i)
    {
        # Get the disk's information (type)
        my %diskhash = $ctlr->physicalDiskInfo($disks[$i]);

        if ( ! %diskhash )            # No response from the controller
        {
            logInfo(">>>>>>>> Failed to get pdisk info (no response) <<<<<<<<");
            $dataDisks[0] = INVALID;
            return @dataDisks;
        }
        else                          # Got a response from the controller
        {
            if ( $diskhash{STATUS} != PI_GOOD )
            {
                # Got an error, report it and bail
                logInfo(">>>>>>>> Failed getting pdisk info <<<<<<<<");

                PrintError(%diskhash);
                $dataDisks[0] = INVALID;
                return @dataDisks;
            }
        }

        debug("diskhash = " . %diskhash);

        # Let's see if we 'own' this disk. To own it, the serial number
        # must be ours.

        my $diskSN = $diskhash{PD_SSERIAL};

        debug("disksn = $diskSN , oursn - $ourSN");

        # Compare to our SN, if match we can use
        if ( $ourSN == $diskSN )
        {
            # Check to see if the drive is a data disk
            if($diskhash{PD_CLASS} == CCBEDATATYPE)
            {
                # Go through each raid and find out if the drive is part
                # of any one of them.
                my $ri = 0;
                my $raidMembership = FALSE;
                while ( ($ri < scalar(@{$info{LIST}}) ) &&  !($raidMembership) )
                {
                    # Go through the pids in the raid and see if the drive
                    # is one of those pids
                    my $pi = 0;
                    while ( ($pi < $info{LIST}[$ri]{PSDCNT}) && !($raidMembership) )
                    {
                        if ( $info{LIST}[$ri]{PIDS}[$pi]{PID} == $disks[$i] )
                        {
                            $raidMembership = TRUE;

                            # Add the data drive to the array
                            push(@dataDisks, $disks[$i]);
                        }
                        $pi++;
                    }
                    $ri++;
                }
            }
        }
    }

    return @dataDisks;
}
##############################################################################
#
#          Name: GetTheseDisks
#
#        Inputs: controller object
#                label type
#                interface type (optional) 
#                   - PD_DT_ALL       ALL disk types
#                   - PD_DT_FC_DISK   FC disks only (default)
#                   - PD_DT_SATA      SATA disks only
#                   - FC_PREFERRED    
#                   - SATA_PREFERRED 
#                       The preferred options will return only the type of disk
#                       preferred (FC or SATA) unless there are not any of that  
#                       type available.  If there are not any of the preferred
#                       type available, it will then return the other type.  If 
#                       there are not any of the other type available, it will 
#                       return INVALID as the first item in the array. 
#
#       Outputs: An array of pids of the desired drive label and type.  
#                If an error occurs or there are no drives available that match
#                the specified label and type, the first item in the array will 
#                be INVALID.   
#                Note:  The pids returned are the ones owned by the specified controller.
#
#  Globals Used: none
#
#   Description: Gets the drive PIDs of the specified label and type that are 
#                owned by the specified controller.
#
#
##############################################################################
sub GetTheseDisks
{
    trace();
    my ($ctlr, $class, $pdType) = @_;    
   
    my $i;
    my $ourSN;            
    my @drives;           
    my $ret;
    my %pdisks;
    my $preferredOption = FALSE;
    my $preferredType;
    my $tryAlternateType = FALSE;
    my $fcCount = 0;
    my $sataCount = 0;
    my $HighPerfCount = 0;
    my $PerfCount = 0;
    my $BalanceCount = 0;
    my $CapCount = 0;
                 
    #
    # If $pdType is not passed in, default to FC only 
    #     
    if ( !defined( $pdType ) )
    {
        $pdType = PD_DT_FC_DISK;
    }

    #
    # Get our serial number
    #
    $ourSN = GetGroupSerial( $ctlr );

    if ( INVALID == $ourSN  )
    {
        logInfo(">>>>>>>> Failed to get controller's serial number <<<<<<<<");
        $drives[0] = INVALID;
        return @drives;
    }

    #
    # Make sure the info we get is current ( rescan loop )
    #
    $ret = RescanBE( $ctlr );
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> BE rescan failed <<<<<<<<");
        $drives[0] = INVALID;
        return @drives;
    }

    #
    # get data indicating what is out there (pdisks command)
    #
    %pdisks = $ctlr->physicalDisks();

    if ( ! %pdisks )     # no response from controller
    {
        logInfo(">>>>> Failed to get pdisk list (no response) <<<<<");
        $drives[0] = INVALID;
        return @drives;
    }
    
    if ( $pdisks{STATUS} != PI_GOOD )     # got a bad response
    {
        # got an error, report it, bail
        logInfo(">>>>> Failed getting pdisk list <<<<<");
        PrintError(%pdisks);
        $drives[0] = INVALID;
        return @drives;
    }
    
    #
    # if one of the preferred options was selected, save the initial option, 
    # set the type to the preferred type, set the $preferredOption flag
    #
    
    
    #
    # Forget the preferred type and check what types we have.  Then pick a type.  This was added to handle 
    # ISE drive types
    #

        
    for(my $i = 0; $i < $pdisks{COUNT}; ++$i)
    {
        # These are the data items we will use

        #    $pdisks{COUNT}
        #    $pdisks{PDISKS}[$i]{PD_PID}
        #                   [$i]{SES},
        #                   [$i]{SLOT},
        #                   [$i]{PD_CLASS},
        #                   [$i]{PD_SSERIAL},
        #                   [$i]{PD_PID},

        #
        # count fibre vs. sata drives vs. ISE drive teirs
        #
        if ( PD_DT_FC_DISK == $pdisks{PDISKS}[$i]{PD_DEVTYPE} )  # fibre
        {
            $fcCount++;
        }
        elsif ( PD_DT_SATA == $pdisks{PDISKS}[$i]{PD_DEVTYPE} ) #sata
        {
            $sataCount++;
        }
        elsif ( PD_DT_ISE_HIGH_PERF == $pdisks{PDISKS}[$i]{PD_DEVTYPE} ) #ISE High Perf
        {
            $HighPerfCount++;
        }
        elsif ( PD_DT_ISE_PERF == $pdisks{PDISKS}[$i]{PD_DEVTYPE} ) #ISE Perf
        {
            $PerfCount++;
        }
        elsif ( PD_DT_ISE_BALANCE == $pdisks{PDISKS}[$i]{PD_DEVTYPE} ) #ISE Balance
        {
            $BalanceCount++;
        }
        elsif ( PD_DT_ISE_CAPACITY == $pdisks{PDISKS}[$i]{PD_DEVTYPE} ) #ISE Cap
        {
            $CapCount++;
        }


    logInfo("Found $fcCount Fibre drives, $sataCount SATA drives, $HighPerfCount ISE High Performance Drives.");
    logInfo("Found $PerfCount ISE Performance drives, $BalanceCount ISE Balance drives and $CapCount ISE Capacity Drives.");
    }
    
    # NEAL
    
        #
        # If multiple types exist, use the type with the most drives/volumes
        #
        if (( $fcCount > 0 ) && ( $sataCount < $fcCount )&& ( $HighPerfCount < $fcCount )&& ( $PerfCount < $fcCount )
            && ( $BalanceCount < $fcCount )&& ( $CapCount < $fcCount )) # fibre
        {
            $pdType = PD_DT_FC_DISK;
            $preferredOption = TRUE;
            $preferredType = $pdType;
        }
        elsif (( $sataCount > 0 ) && ( $fcCount < $sataCount )&& ( $HighPerfCount < $sataCount )&& ( $PerfCount < $sataCount )
            && ( $BalanceCount < $sataCount )&& ( $CapCount < $sataCount ))  #sata
        {
            $pdType = PD_DT_SATA;
            $preferredOption = TRUE;
            $preferredType = $pdType;
        }
        elsif (( $HighPerfCount > 0 ) && ( $sataCount < $HighPerfCount )&& ( $fcCount < $HighPerfCount )&& ( $PerfCount < $HighPerfCount )
            && ( $BalanceCount < $HighPerfCount )&& ( $CapCount < $HighPerfCount ))  #ISE High Perf
        {
            $pdType = PD_DT_ISE_HIGH_PERF;
            $preferredOption = TRUE;
            $preferredType = $pdType;
        }
        elsif (( $PerfCount > 0 ) && ( $sataCount < $PerfCount )&& ( $HighPerfCount < $PerfCount )&& ( $fcCount < $PerfCount )
            && ( $BalanceCount < $PerfCount )&& ( $CapCount < $PerfCount )) #ISE Perf
        {
            $pdType = PD_DT_ISE_PERF;
            $preferredOption = TRUE;
            $preferredType = $pdType;            
        }
        elsif (( $BalanceCount > 0 ) && ( $sataCount < $BalanceCount )&& ( $HighPerfCount < $BalanceCount )&& ( $PerfCount < $BalanceCount )
            && ( $fcCount < $BalanceCount )&& ( $CapCount < $BalanceCount )) #ISE Balance
        {
            $pdType = PD_DT_ISE_BALANCE;
            $preferredOption = TRUE;
            $preferredType = $pdType;            
        }
        elsif (( $CapCount > 0 ) && ( $sataCount < $CapCount )&& ( $HighPerfCount < $CapCount )&& ( $PerfCount < $CapCount )
            && ( $BalanceCount < $CapCount )&& ( $fcCount < $CapCount )) #ISE Cap
        {
            $pdType = PD_DT_ISE_CAPACITY;
            $preferredOption = TRUE;
            $preferredType = $pdType;            
        }

   
   
   
    MAIN:
    {

        #
        # If we are coming back thru to try the other type, switch types
        #
        if ($tryAlternateType == TRUE) 
        {
            if ($pdType == PD_DT_FC_DISK)
            {
                $pdType = PD_DT_SATA;
            }
            elsif ($pdType == PD_DT_SATA)
            {
                $pdType = PD_DT_FC_DISK;
            }
            elsif ($pdType == PD_DT_ISE_HIGH_PERF) 
            {
                $pdType = PD_DT_ISE_CAPACITY;
            }
            elsif ($pdType == PD_DT_ISE_PERF) 
            {
                $pdType = PD_DT_ISE_BALANCE;
            }
            elsif ($pdType == PD_DT_ISE_BALANCE) 
            {
                $pdType = PD_DT_ISE_HIGH_PERF;
            }
            elsif ($pdType == PD_DT_ISE_CAPACITY) 
            {
                $pdType = PD_DT_ISE_PERF;
            }
            else 
            {
                $pdType = PD_DT_FC_DISK;
            }
        }
    
        #
        # Now walk the pdisks hash and get the disks that are the type we
        # want. Also check the PD type (fibre, sata or ISE) if specified.
        #
        for( $i = 0; $i < $pdisks{COUNT}; ++$i )
        {
            if ( $ourSN == $pdisks{PDISKS}[$i]{PD_SSERIAL} )
            {
                #
                # Serial number matches, check label;.
                #
                if ( $pdisks{PDISKS}[$i]{PD_CLASS} == $class )
                {
                    #
                    # disk label matches, now check PD_DEVTYPE
                    #
                    if ( $pdType == PD_DT_ALL )
                    {
                        #
                        # All the disks are wanted 
                        #
                        push(@drives, $pdisks{PDISKS}[$i]{PD_PID} );
                    }
                    else
                    {
                        #
                        # a specific type was specified, now check it
                        #
                        if ( $pdType == $pdisks{PDISKS}[$i]{PD_DEVTYPE} )
                        {
                            push (@drives, $pdisks{PDISKS}[$i]{PD_PID} );
                        }
                    }
                }
            } # end if serial
        } # end for pdisks
       
  	    if( scalar( @drives ) == 0 )
        {
            if ( $preferredOption == TRUE )
            {
                #
                # Looking for a preferred type of disk.  If there are no drives 
                # of that type available, go back and look for the alternate type.
                # If we have already checked tried the alternate, then we are done.
                #
                if ( $tryAlternateType == TRUE )
                {
                    logInfo("No drives of alternate type available either.");
                    logInfo(">>>>>>>> No drives available. <<<<<<<<");
                    $drives[0] = INVALID;
                    return @drives;
                }
                else 
                {
                    logInfo("No drives of preferred type available.");
                    logInfo("Checking for drives of alternate type.");
                    $tryAlternateType = TRUE;
                    redo MAIN;
                }
            }
            else   # not a preferred option
            {
                #
                # This path looking for a specific type.  If that type is not found,
                # we are done.
                # 
                logInfo(">>>>>>>> No drives available <<<<<<<<");
                $drives[0] = INVALID;
                return @drives;
            }
        }
  
        #
        # If we got here, we have a valid list of drives to return
        #
        return @drives;
        
    }  # end of MAIN

}




##############################################################################
#
#          Name: StopStartIOTest
#
#        Inputs: controller object, loops, option (start, stop, or cycle)
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Loop on the following,
#                   Stop IO     using genericMRP
#                   Start IO
#
#                Stop after n loops or on error
#
#
##############################################################################
sub StopStartIOTest
{
    trace();
    my ($ctlr, $loops, $delay, $option) = @_;

    my $i;
    my $ret;

    if (!defined $option  || $option eq 'none')
    {
        $option = "cycle";
    }

    if (!defined $delay  || $delay eq 'none')
    {
        $delay = 2;
    }

    for ( $i = 0; $i < $loops; $i++ )
    {

        # Stop IO if requested
        if (lc $option ne "start")
        {
            logInfo("Stopping I/O, loop # $i ");

            # genmrp 0x51c 8 00000002
            $ret = GenericMRP($ctlr, 0x51c, 8, "00000002");
            if ( $ret != GOOD )
            {
                return ERROR;
            }
            DelaySecs($delay) if ($delay);
        }

        # Start IO if requested
        if (lc $option ne "stop")
        {
            logInfo("Starting I/O");

            # genmrp 0x51d 8
            $ret = GenericMRP($ctlr, 0x51d, 8, "00000000");
            if ( $ret != GOOD )
            {
                return ERROR;
            }
            DelaySecs($delay) if ($delay);
        }
    }
    return GOOD;
}

##############################################################################
#
#          Name: GenericMRP
#
#        Inputs: controller object, loops, , eight, data
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Executes a generic MRP
#
#
#
##############################################################################
sub GenericMRP
{
    trace();
    my ($ctlr, $opcode, $eight, $data ) = @_;

    my %rsp;

    if (defined $data) {
        $data = AsciiHexToBin($data, "word");;
        if (!defined $data) {
            print "The data field was NOT correct.\n";
            return;
        }
    }



    %rsp = $ctlr->genericMRP($opcode,
                             $eight,
                             $data );

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get a response from generic MRP. <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Error from generic MRP. <<<<<<<<");
        PrintError(%rsp);
        # After MRP data returned, format it appropriately.
        $ctlr->FormatData($rsp{RSP_DATA}, 0x00000000,
                "word", undef, undef);

        return ERROR;
    }

    return GOOD;
}




##############################################################################
#
#          Name: FailDrivesTest
#
#        Inputs: controller object, loops, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Loop on the following,
#                   Fail a drive,
#                   Let rebuild finish
#                   Unfail the drive
#                   Make drive a hotspare
#                   Repeate for next used drive
#
#
#
##############################################################################
sub FailDrivesTest
{
    trace();
    my ($ctlr, $loops, $option ) = @_;

    my $loop;
    my $drive;
    my $ourSN;
    my $diskSN;
    my $ret;
    my %rsp;
    my $lc;
    my $cdb;
    my %pdisks;
    my @deviceID;
    my $msg;
    my @driveList;
    my @GroupOfHS;

    # check to see if none of the drives are degraded, if so, we can't
    # go on

    logInfo("Checking to make sure all drives are ready");
    $ret = DegradeCheck( $ctlr );
    if ( ($ret == INVALID) || ($ret == ERROR) )
    {
        logWarning(">>>>>>>> Not all drives were ready. Sorry, test exiting. <<<<<<<<");
        return ERROR;
    }

    ########### devstat PD ################

    $ret = DispPdiskInfo( $ctlr );

    if ( $ret == ERROR )
    {
        return ERROR;
    }

    # let's do it

    ####################################
    # do the desired number of loops
    ####################################
    for ( $loop = 0; $loop < $loops; $loop++ )
    {
        logInfo(sprintf("Test loop #%d of $loops", (1+$loop)));

        ###########################################
        #  Locate the useable drives for the test
        ###########################################

        logInfo("Disks Group and Drive Information");
        print "Please wait, scanning drives for type info ... \n";

        @driveList = GetAllVdiskDataDisks( $ctlr);
        @GroupOfHS = GetTheseDisks( $ctlr, CCBEHOTSPARETYPE );

        if ( scalar(@driveList) < 2 )   # got to have some redundancy
        {
            logWarning(">>>>>>>> Not enough data disks found. Sorry, test exiting. <<<<<<<<");
            return ERROR;
        }

        if ( scalar(@GroupOfHS) < 1 )
        {
            logWarning(">>>>>>>> No hot spare disks found. Sorry, test exiting. <<<<<<<<");
            return ERROR;
        }

        logInfo("Using these PPDs: @driveList");

        #
        # Now we have a valid list of drives to work with in @driveList
        #

        #########################
        # for each data drive
        #########################
        for ( $drive = 0; $drive < scalar(@driveList); $drive++ )
        {
            logInfo("Failing drive $driveList[$drive]");
            #######################
            # Fail the drive
            #######################

            #
            # The failing will be "simulated" by sending a stop unit SCSI command.
            #

            $cdb = AsciiHexToBin("1B0100000000", "byte");

            #
            # Retrieve WWN/LUN from the specified physical disk
            #
            %pdisks = $ctlr->physicalDiskInfo($driveList[$drive]);
            if (%pdisks)
            {
                if ($pdisks{STATUS} == PI_GOOD)
                {
                    $deviceID[0]{WWN_LO} = $pdisks{WWN_LO};
                    $deviceID[0]{WWN_HI} = $pdisks{WWN_HI};
                    $deviceID[0]{PD_LUN} = $pdisks{PD_LUN};
                }
                else
                {
                    logInfo(">>>>>>>> Unable to retrieve pdisk info <<<<<<<<");
                    PrintError(%pdisks);
                    return ERROR;
                }
            }
            else
            {
                logInfo(">>>>>>>> ERROR: Did not receive a response packet from physicalDiskInfo() <<<<<<<<");                       return ERROR;
            }

            #
            # Send the SCSI cmd.
            #
            %rsp = $ctlr->scsiCmd($cdb, "", @deviceID);

            if (%rsp)
            {
                #
                # If successful, tell the user
                #
                if ($rsp{STATUS} == PI_GOOD)
                {
                    logInfo("Stop unit SCSI command successful");
                }
                #
                # If failure, display sense data
                #
                else
                {
                    logInfo(">>>>>>>> SCSI cmd failed <<<<<<<<");
                    PrintError(%rsp);

                    logWarning(sprintf("Sense Key:      0x%02X\n", $rsp{SENSE_KEY}));
                    logWarning(sprintf("Sense Code:     0x%02X\n", $rsp{ADTL_SENSE_CODE}));
                    logWarning(sprintf("Sense Code Qual:0x%02X\n", $rsp{ADTL_SENSE_CODE_QUAL}));
                    return ERROR;
                }
            }
            else
            {
                logInfo(">>>>>>>> ERROR: Did not receive a response packet <<<<<<<<");
                return ERROR;
            }

            ######################
            # start the rebuild
            ######################
            # this should be automatic, allow 120 secs to get rolling

            logInfo("waiting 120 seconds for the rebuild to start");
            DelaySecs( 120 );

            #############################
            # wait for rebuild to finish
            #############################
            # rebuild is done if no drives are 'degraded'

            logInfo("polling until rebuild finishes");
            $ret = INVALID;

            $lc = 0;
            while ( $ret != GOOD )
            {
                $lc++;
                logInfo(sprintf("Rebuild check loop iteration: %5d - ", $lc));

                $ret = DegradeCheck( $ctlr );
                if ( $ret == ERROR )
                {
                    return ERROR;
                }
                DelaySecs( 15 );
            }

            #############################################################
            # make the disk visible again by sending a LIP reset MRP
            #############################################################

            %rsp = $ctlr->genericMRP($ctlr->MRBELOOPPRIMITIVE,
                                     8,
                                     AsciiHexToBin(DecToAsciiHexData($driveList[$drive], "short") .
                                     DecToAsciiHexData(MLPSIDPIDRES, "short") . "0000000000000000") );

            if ( ! %rsp  )
            {
                logInfo(">>>>>>>> Failed to get a response from Loop Primitive (LIP Reset) MRP. <<<<<<<<");
                return ERROR;
            }

            if ($rsp{STATUS} != PI_GOOD)
            {
                logInfo(">>>>>>>> Unable to send a LIP Reset to drive $driveList[$drive]. <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }

            logInfo("Physical disk fiber channel port was reset");

            ########################
            # 'restore' the drive
            ########################

            logInfo("restoring the physical drive");
            %rsp = $ctlr->physicalDiskRestore($driveList[$drive]);
            if ( ! %rsp  )
            {
                logInfo(">>>>>>>> Failed to get response from physicalDiskRestore <<<<<<<<");
                return ERROR;
            }

            if ($rsp{STATUS} != PI_GOOD)
            {
                logInfo(">>>>>>>> Unable to restore drive $driveList[$drive]. <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }

            $ret = RescanBE( $ctlr);
            if ( $ret == ERROR )
            {
                return ERROR;
            }

            ##################################
            # Label the drive as a hotspare
            ##################################

            $ret = LabelSingleDrive( $ctlr, $driveList[$drive], CCBEUNLABLEDTYPE);
            if ( $ret == ERROR )
            {
                return ERROR;
            }
            $ret = LabelSingleDrive( $ctlr, $driveList[$drive], CCBEHOTSPARETYPE);
            if ( $ret == ERROR )
            {
                return ERROR;
            }

            ########### devstat PD ################

            $ret = DispPdiskInfo( $ctlr );

            if ( $ret == ERROR )
            {
                return ERROR;
            }
        }

        # do we want some summary data here?
    }
    # done.

    logInfo("Test Complete");
    return GOOD;
}

##############################################################################
#
#          Name: DegradeCheck
#
#        Inputs: controller object
#
#       Outputs: GOOD if none degraded,
#                INVALID if some degraded,
#                ERROR if we get an error
#
#  Globals Used: none
#
#   Description: Look at the vdisks that are in the operating state and see if
#                any are in a degraded state
#
#
##############################################################################
sub DegradeCheck
{
    trace();
    my ( $ctlr) = @_;

    my %rsp;
    my $i;

    # use 'devstat pd'

    %rsp = $ctlr->deviceStatus("PD");

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from deviceStatus <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get device status <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    # now we have the data, let's look at it

 #   logDeviceStatus("PD", undef, %rsp);

    # now check it

    for $i (0..$#{$rsp{LIST}})
    {

        #
        # Skip all drives that are not currently operable
        #
        if (  $rsp{LIST}[$i]{PD_DEVSTAT} == 0x10  )
        {
            #
            # Check to see if the drive is degraded
            #
            if ( ( $rsp{LIST}[$i]{PD_MISCSTAT} & 0x03 ) != 0 )
            {
                print "PDD # $rsp{LIST}[$i]{PD_PID} is still rebuilding",
                      " (MISCSTAT = $rsp{LIST}[$i]{PD_MISCSTAT})",
                      " (CLASS = $rsp{LIST}[$i]{PD_CLASS}) \r";
                return INVALID;
            }

        }
     }

    # now also check the raids and make sure they are all operable


    %rsp = $ctlr->raids();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    for (my $i = 0; $i < $rsp{COUNT}; $i++)
    {
        #$output .= sprintf("%3hu  0x%2.2x     0x%2.2x  %3d  %14s  %4d  %5d\n",
        #                   $rsp{RAIDS}[$i]{RID},
        #                   $rsp{RAIDS}[$i]{TYPE},
        #                   $rsp{RAIDS}[$i]{DEVSTAT},
        #                   $rsp{RAIDS}[$i]{VID},
        #                   $rsp{RAIDS}[$i]{CAPACITY},
        #                   $rsp{RAIDS}[$i]{PCTREM},
        #                   $rsp{RAIDS}[$i]{FRCNT});

        # make sure they are all operational
        if ( $rsp{RAIDS}[$i]{DEVSTAT} != 0x10 )
        {
            # this one was not operational, return INVALID
            logInfo("Raid $rsp{RAIDS}[$i]{RID} was not operational.".
                    " (status =$rsp{RAIDS}[$i]{DEVSTAT})" );
            return INVALID;
        }

    }





    logInfo("Drives have completed rebuild");

    return GOOD;    # none were degraded
}
##############################################################################
#
#          Name: DegradeCheckRunning
#
#        Inputs: controller object
#
#       Outputs: GOOD if none running,
#                INVALID if some running,
#                ERROR if we get an error
#
#  Globals Used: none
#
#   Description: Look at the pdisks that are in the operating state and see if
#                any are actively rebuilding
#
#
##############################################################################
sub DegradeCheckRunning
{
    trace();
    my ( $ctlr) = @_;

    my %rsp;
    my $i;

    # use 'devstat pd'

    %rsp = $ctlr->deviceStatus("PD");

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from deviceStatus <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get device status <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    # now we have the data, let's look at it

    # now check it

    for $i (0..$#{$rsp{LIST}})
    {

        #
        # Skip all drives that are not currently operable
        #
        if (  $rsp{LIST}[$i]{PD_DEVSTAT} == 0x10  )
        {
            #
            # Check to see if the drive is actively rebuilding
            #
            if ( ( $rsp{LIST}[$i]{PD_MISCSTAT} & 0x02 ) != 0 )
            {
                print "PDD # $rsp{LIST}[$i]{PD_PID} is still rebuilding",
                      " (MISCSTAT = $rsp{LIST}[$i]{PD_MISCSTAT})",
                      " (CLASS = $rsp{LIST}[$i]{PD_CLASS}) \r";
                return INVALID;
            }

        }
     }

    # now also check the raids and make sure they are all operable


    %rsp = $ctlr->raids();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    for (my $i = 0; $i < $rsp{COUNT}; $i++)
    {
        #$output .= sprintf("%3hu  0x%2.2x     0x%2.2x  %3d  %14s  %4d  %5d\n",
        #                   $rsp{RAIDS}[$i]{RID},
        #                   $rsp{RAIDS}[$i]{TYPE},
        #                   $rsp{RAIDS}[$i]{DEVSTAT},
        #                   $rsp{RAIDS}[$i]{VID},
        #                   $rsp{RAIDS}[$i]{CAPACITY},
        #                   $rsp{RAIDS}[$i]{PCTREM},
        #                   $rsp{RAIDS}[$i]{FRCNT});

        # make sure they are all operational
        if ( $rsp{RAIDS}[$i]{DEVSTAT} != 0x10 )
        {
            # this one was not operational, return INVALID
            logInfo("Raid $rsp{RAIDS}[$i]{RID} was not operational.".
                    " (status =$rsp{RAIDS}[$i]{DEVSTAT})" );
#            return INVALID;
        }

    }





    logInfo("Drives have not started or have completed the rebuild");

    return GOOD;    # none were degraded
}

##############################################################################
#
#          Name: CorruptBENvram
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: # Corrupt BE NVRAM CRC
#                  memwrite -pBE -t byte 0xfe400004 0x81
#                  memwrite -pBE 0xfe808000 00000000
#
#
##############################################################################
sub CorruptBENvram
{
    trace();

    my ($ctrl) = @_;

    my $proc;
    my %rsp;
    my $data;
    my $address;

    # enable writes to memory

    logInfo("Corrupting BE NVRAM");

    %rsp = $ctrl->WriteMemory(0xfe400004, 0x81, "BE");

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from WriteMemory <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to WriteMemory <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    # overwrite the checksum

    %rsp = $ctrl->WriteMemory(0xfe808000,    0, "BE");

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from WriteMemory <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to WriteMemory <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: SuicideOK
#
#        Inputs: list of controller objects
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: sets the mode bit to let proc suicide#
#
##############################################################################
sub SuicideOK
{
    trace();
    my ($ctlrPtr) = @_;

    my $i;

    my $bits = 0x00;           # 0 for M610 and later, 1 for m601 and before

    my $mask = 0x01;

    my %bitHash;
    my $obj;

    my @objList;               # turn pointer into an array
    @objList = @$ctlrPtr;

    if ($bits =~ /^0x/i) {
        $bits = oct $bits;
    }
    if ($mask =~ /^0x/i) {
        $mask = oct $mask;
    }

    $bitHash{CCB_BITS1}         =0;
    $bitHash{CCB_BITS_MASK1}    =0;
    $bitHash{PROC_BITS1}        =0;
    $bitHash{PROC_BITS2}        =0;
    $bitHash{PROC_BITS3}        =0;
    $bitHash{PROC_BITS4}        =0;
    $bitHash{PROC_BITS_MASK1}   =0;
    $bitHash{PROC_BITS_MASK2}   =0;
    $bitHash{PROC_BITS_MASK3}   =0;
    $bitHash{PROC_BITS_MASK4}   =0;


    $bitHash{PROC_BITS1}         =$bits;
    $bitHash{PROC_BITS_MASK1}    =$mask;

    # Randy recently added these
    $bitHash{CCB_BITS_DPRINTF}      = 0;
    $bitHash{CCB_BITS_DPRINTF_MASK} = 0;
    $bitHash{CCB_BITS_RSVD1}        = 0;
    $bitHash{CCB_BITS_RSVD1_MASK}   = 0;
    $bitHash{CCB_BITS_RSVD2}        = 0;
    $bitHash{CCB_BITS_RSVD2_MASK}   = 0;


    logInfo("Enabling proc suicide on controllers");

    for ( $i = 0; $i < scalar(@objList); $i++ )
    {
        $obj = $objList[$i];

        my %rsp = $obj->modeDataSet(%bitHash);

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from modeDataSet <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to set mode bits <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }
    return GOOD;
}

##############################################################################
#
#          Name: NoSuicide
#
#        Inputs: list of controller objects
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: sets the mode bit for no suicide on error trap
#           modebitset 0x20 0x20
#
#
##############################################################################
sub NoSuicide
{
    trace();
    my ($ctlrPtr) = @_;

    my $i;

    my $bits = 0x40;
    my $mask = 0x40;

    my %bitHash;
    my $obj;

    my @objList;               # turn pointer into an array
    @objList = @$ctlrPtr;

    if ($bits =~ /^0x/i) {
        $bits = oct $bits;
    }
    if ($mask =~ /^0x/i) {
        $mask = oct $mask;
    }

#    $bitHash{CCB_BITS1}         =0;
#    $bitHash{CCB_BITS_MASK1}    =0;
    $bitHash{PROC_BITS1}        =0x01;      # enable suicide, m610 and later
    $bitHash{PROC_BITS2}        =0;
    $bitHash{PROC_BITS3}        =0;
    $bitHash{PROC_BITS4}        =0;
    $bitHash{PROC_BITS_MASK1}   =0x01;
    $bitHash{PROC_BITS_MASK2}   =0;
    $bitHash{PROC_BITS_MASK3}   =0;
    $bitHash{PROC_BITS_MASK4}   =0;


    $bitHash{CCB_BITS1}         =$bits;
    $bitHash{CCB_BITS_MASK1}    =$mask;


    # Randy recently added these
    $bitHash{CCB_BITS_DPRINTF}      = 0;
    $bitHash{CCB_BITS_DPRINTF_MASK} = 0;
    $bitHash{CCB_BITS_RSVD1}        = 0;
    $bitHash{CCB_BITS_RSVD1_MASK}   = 0;
    $bitHash{CCB_BITS_RSVD2}        = 0;
    $bitHash{CCB_BITS_RSVD2_MASK}   = 0;


    logInfo("Inhibiting suicide on controllers");

    for ( $i = 0; $i < scalar(@objList); $i++ )
    {
        $obj = $objList[$i];

        my %rsp = $obj->modeDataSet(%bitHash);

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from modeDataSet <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to set mode bits <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

    }

    return GOOD;
}
##############################################################################
#
#          Name: NoFailureManager
#
#        Inputs: list of controller objects
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: sets the mode bit for no suicide on error trap
#           modebitset 0x20 0x20
#
#
##############################################################################
sub NoFailureManager
{
    trace();
    my ($ctlrPtr) = @_;

    my $i;

    my $bits = 0x20;
    my $mask = 0x20;

    my %bitHash;
    my $obj;

    my @objList;               # turn pointer into an array
    @objList = @$ctlrPtr;

    if ($bits =~ /^0x/i) {
        $bits = oct $bits;
    }
    if ($mask =~ /^0x/i) {
        $mask = oct $mask;
    }

#    $bitHash{CCB_BITS1}         =0;
#    $bitHash{CCB_BITS_MASK1}    =0;
    $bitHash{PROC_BITS1}        =0x01;      # enable suicide, m610 and later
    $bitHash{PROC_BITS2}        =0;
    $bitHash{PROC_BITS3}        =0;
    $bitHash{PROC_BITS4}        =0;
    $bitHash{PROC_BITS_MASK1}   =0x01;
    $bitHash{PROC_BITS_MASK2}   =0;
    $bitHash{PROC_BITS_MASK3}   =0;
    $bitHash{PROC_BITS_MASK4}   =0;


    $bitHash{CCB_BITS1}         =$bits;
    $bitHash{CCB_BITS_MASK1}    =$mask;


    # Randy recently added these
    $bitHash{CCB_BITS_DPRINTF}      = 0;
    $bitHash{CCB_BITS_DPRINTF_MASK} = 0;
    $bitHash{CCB_BITS_RSVD1}        = 0;
    $bitHash{CCB_BITS_RSVD1_MASK}   = 0;
    $bitHash{CCB_BITS_RSVD2}        = 0;
    $bitHash{CCB_BITS_RSVD2_MASK}   = 0;


    logInfo("Inhibiting failure manager on controllers");

    for ( $i = 0; $i < scalar(@objList); $i++ )
    {
        $obj = $objList[$i];

        my %rsp = $obj->modeDataSet(%bitHash);

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from modeDataSet <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to set mode bits <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

    }

    return GOOD;
}

##############################################################################
#
#          Name: GoodPathIOTest
#
#        Inputs: controller object, (unused option), list of server wwns
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Controller tests that can be done while IO is running
#
#
##############################################################################
sub GoodPathIOTest
{
    trace();
    my ($ctlr, $option, $wwnList) = @_;

    my $ret;
    my $loops1;
    my $loops2;
    my $i;

    $loops1 = 10;
    $loops2 = 10;

    ##################
    # basic good path
    ##################
    $ret =  GoodPathSubset1($ctlr, $option, $wwnList);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path subset  test <<<<<<<<");
        return (ERROR);
    }

    for ( $i = 0; $i < $loops1; $i++ )
    {
        ################################
        # create/expand/delete vdisks
        ################################

        $ret = GPCreateExpandDelete($ctlr);     # does several passes itself
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failure in create/expand/init/delete vdisk test <<<<<<<<");
            return (ERROR);
        }
    }
    return GOOD;
}

##############################################################################
#
#          Name: GoodPathSubset1
#
#        Inputs: controller object, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Emulation of the good_path.pl script, only those that
#                won't trash concurrent IO (is this the new robustness
#                script?)
#
#
##############################################################################
sub GoodPathSubset1
{
    my ($ctlr, $option, $wwnList) = @_;

    my $ret;

    $ret = GPModes($ctlr);      # first, as it turns off no suicide bit
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path mode bits test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDeviceStatus($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path device status test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDiskBayCommands($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path Disk Bay Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPCaching($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path caching test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPRaidCommands($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path Raid Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPServerCommands($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path Server Commands test  <<<<<<<<");
        return (ERROR);
    }


    $ret = GPMiscCommands($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path misc. Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPFidRead($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path FID read test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPStatsCommands($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path statistics Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPLoggingTest($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path Logging test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPMemoryLeakTest($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path memory leak test <<<<<<<<");
        return (ERROR);
    }

    return GOOD;
}

##############################################################################
#
#          Name: GoodPathSuperset
#
#        Inputs: controller object, (unused option), list of server wwns
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Extended version of good path, 1 way regression
#
#
##############################################################################
sub GoodPathSuperset
{
    my ($ctlr, $option, $wwnList) = @_;

    my $ret;
    my $loops1;
    my $loops2;
    my $i;

    $loops1 = 10;
    $loops2 = 10;

    #
    # make sure the controller has a license
    #
    $ret = GetMyLicense($ctlr, 0, 0);
    if ( $ret != GOOD )
    {
        logWarning(">>>>>>>> Failed to get license <<<<<<<<");
        return (ERROR);
    }

    #########################################
    # clean up anything from previous tests
    #########################################

    $ret = DisassocAll ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to disassociate all servers <<<<<<<<");
        return (ERROR);
    }

    $ret = DeleteAllVdisks2 ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to delete all vdisks <<<<<<<<");
        return (ERROR);
    }

    $ret = LabelSingleDrive ( $ctlr, 0xffff, 0 );
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to unlabel all drives <<<<<<<<");
        return (ERROR);
    }


    ##################
    # basic good path
    ##################
    $ret =  GoodPathTest($ctlr, $option, $wwnList);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure in good path  test <<<<<<<<");
        return (ERROR);
    }

    for ( $i = 0; $i < $loops1; $i++ )
    {

        ################################
        # configure a 1 way many times
        ################################
        $ret = GPReal1Way($ctlr, $wwnList, 2);
        if ( $ret == ERROR )
        {
            logWarning(">>>>>>>> Failure creating 1 way configuration <<<<<<<<");
            return (ERROR);
        }
    }

    for ( $i = 0; $i < $loops2; $i++ )
    {

        ################################
        # create/expand/delete vdisks
        ################################

        $ret = GPCreateExpandDelete($ctlr);
        if ( $ret == ERROR )
        {
            logWarning(">>>>>>>> Failure in create/expand/init/delete vdisk test <<<<<<<<");
            return (ERROR);
        }
    }

#    ##########################
#    # basic good path - again    This will fail as the pdisks are labelled
#    ##########################
#    $ret =  GoodPathTest($ctlr, $option, $wwnList);
#    if ( $ret == ERROR )
#    {
#        logWarning(">>>>>>>> Failure in good path  test <<<<<<<<");
#        return (ERROR);
#    }
#



    #####################
    # show what is there
    #####################

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }

    $ret = DispVdisksRaids($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to display vdisks and raids <<<<<<<<");
        return (ERROR);
    }


    return GOOD;
}


##############################################################################
#
#          Name: GoodPathTest
#
#        Inputs: controller object, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Emulation of the good_path.pl script
#                Note: this must not require real servers to be attached
#                or their WWNs be known. THis requirement is for the code
#                building process for the CCB code
#
##############################################################################
sub GoodPathTest
{
    trace();
    my ($ctlr, $option, $wwnList) = @_;

    my $ret;

    #
    # make sure the controller has a license
    #
    $ret = GetMyLicense($ctlr, 0, 0);
    if ( $ret != GOOD )
    {
        logError(">>>>>>>> Failure in good path get license <<<<<<<<");
        return (ERROR);
    }

    $ret = GPModes($ctlr);      # first, as it turns off no suicide bit
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path mode bits test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDeviceStatus($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path device status test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPResetTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path QL reset test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPMiscCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path misc. Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDiskBayCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Disk Bay Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPPhysicalDiskCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Physical Disk test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPVirtualDiskCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Virtual Disk test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPRaidCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Raid Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPTargetCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Target Commands test <<<<<<<<");
        return (ERROR);
    }


    $ret = GPServerCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Server Commands test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPFidRead($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path FID read test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPCaching($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path caching test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDeviceStatus($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path device status test <<<<<<<<");
        return (ERROR);
    }

#    $ret = GPReal1Way($ctlr, $wwnList, 2);       # may fail for missing SIDs
#    if ( $ret == ERROR )
#    {
#        logError(">>>>>>>> Failure in good path 1 way config test <<<<<<<<");
#        return (ERROR);
#    }

    $ret = GPStatsCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Stats test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPLoggingTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Logging test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPMemoryLeakTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path memory leak test <<<<<<<<");
        return (ERROR);
    }






    return GOOD;
}
#################################################################################

##############################################################################
#
#          Name: GPServerCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of disk bay related functions
#
#
##############################################################################


sub GPServerCommands
{
    trace();
    my ($ctlr) = @_;

    my %rsp;
    my $i;
    my $r;
    my @vdisks;
    my $sidCount;

    logInfo("Testing server operations");

    my $sid = 0;
    my $lun = 32;

    ################
    # server count
    ################

    %rsp = $ctlr->serverCount();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from serverCount <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from serverCount <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    $sidCount = $rsp{COUNT};

    logInfo("Server Count: $rsp{COUNT}");

    ################
    # server list
    ################

    logInfo("Server List");

    %rsp = $ctlr->serverList();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from serverList <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from serverList <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    my $str = " ";

    for $i (0..$#{$rsp{LIST}})
    {
        $str .= "  " . $rsp{LIST}[$i] ;
    }

    logInfo($str);

    logInfo("Retrieving server information for each server.");

    for $i (0..$#{$rsp{LIST}})
    {

        ###################
        # server info
        ###################
        my $id = $rsp{LIST}[$i];
        my %info = $ctlr->serverInfo($id);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from serverInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from serverInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logServerInfo(%info);
    }

    #
    # need an array of vdisk ids for the following
    #

    ######################
    # vdisk list
    ######################

    %rsp = $ctlr->getObjectList(PI_VDISK_LIST_CMD);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from PI_VDISK_LIST_CMD <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Virtual Disk List");
    logObjectList(%rsp);
    # in here is my list of disks.. now how do i extract it?
    # need to build this array >>>> @vdisklistarray = @$vdisklist;       # make an array

    # put drives into an array
    for ( $r=0; $r< $rsp{COUNT}; $r++)
    {
        push  @vdisks, $rsp{LIST}[$r];
    }

    #$numVDDs = $rsp{COUNT};  # of drives available to map



    # these next two require at leasat one server, so qualify the count

 #   if( $sidCount > 0 )
 # test disabled, need a better method for selecting servers,
 #  vids and luns.   6/26/03 CM

    if(  0 )
    {

        ###################
        # server associate
        ###################

        my $theLun;
        my $remaining;

        logInfo("Associating Servers");
        for ($i = 0; $i < scalar(@vdisks); $i++)
        {
            logInfo("Make sure the vdisk has finished init");
            while ( 0 != ( $remaining = CheckInitProgress($ctlr, $vdisks[$i] ) ) )
            {
                print " $remaining percent left to initialize \r";
                # pause for a second or 2
                sleep 2;
            }


            $theLun = $lun;
            %rsp = $ctlr->serverAssociate($sid, $lun++, $vdisks[$i]);
            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from serverAssociate <<<<<<<<");
                return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from serverAssociate <<<<<<<<");
                PrintError(%rsp);
                logInfo("Attempted to map vdisk $vdisks[$i] to server $sid, lun $theLun. ");

                return ERROR;
            }

            logInfo("Associated vdisk $vdisks[$i]  to server $sid at lun $theLun");
        }


        ######################
        # server disassociate
        ######################

        logInfo("Disassociating Servers");
        while ($lun > 32)
        {
            %rsp = $ctlr->serverDisassociate($sid, --$lun, $vdisks[--$i]);
            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from serverDisassociate <<<<<<<<");
                return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from serverDisassociate <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }

            logInfo("Disassociated vdisk from server $sid at lun $lun");
        }

    }
    else
    {
        logInfo("#############################################################");
        logInfo("#                                                           #");
        logInfo("# No SIDs were found, Associate/Disassociate tests skipped  #");
        logInfo("#                                                           #");
        logInfo("#############################################################");
    }

    #############
    #  SERVERS
    #############
    logInfo("Servers Command");
    %rsp = $ctlr->servers();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from Servers <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get Servers info <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logServers(%rsp);

    logInfo("Completed testing server operations");

    return GOOD;
}

##############################################################################
#
#          Name: GPDiskBayCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of disk bay related functions
#
#
##############################################################################


sub GPDiskBayCommands
{
    trace();
    my ($ctlr) = @_;

    my %rsp;
    my %info;
    my $i;

    logInfo("Testing disk bay operations");

    ###################
    # disk bay count
    ###################
    %rsp = $ctlr->diskBayCount();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from diskBayCount <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get disk bay count <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Disk Bay Count: " . $rsp{COUNT});



    ###################
    # disk bay list
    ###################
    %rsp = $ctlr->diskBayList();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from diskBayList <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get disk bay list <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    my $str = "Disk Bay List:";

    for $i (0..$#{$rsp{LIST}})
    {
        $str .= "  " . $rsp{LIST}[$i] ;
    }
    logInfo($str);

    #######################
    # disk bay information
    #######################
    logInfo("Retrieving disk bay information for each bay");

    for $i (0..$#{$rsp{LIST}})
    {
        my $id = $rsp{LIST}[$i];
        my %info = $ctlr->diskBayInfo($id);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from diskBayInfo <<<<<<<<");
            return ERROR;
        }

        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to get disk bay info <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logDiskBayInfo(%info);     # this shouldn't have problems
    }

    ##############
    # disk bays
    ##############
    logInfo("DiskBays Command");
    %info = $ctlr->diskBays();
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from diskBays <<<<<<<<");
        return ERROR;
    }
    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get diskBay info <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logDiskBays( %info);


    ###################
    # disk bay status
    ###################
    %rsp = $ctlr->diskBayStatus();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from diskBayStatus <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get diskBayStatus <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Completed testing disk bay operations");
    return GOOD;
}

##############################################################################
#
#          Name: GPPhysicalDiskCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of PDD related functions
#
#
##############################################################################
sub GPPhysicalDiskCommands
{
    trace();
    my ($ctlr, $noLabel) = @_;

    my %rsp;
    my %info;
    my $i;
    my $id;
    my $ret;
    my $dur;

    logInfo("Testing physical disk operations");

    #######################
    #  RESCAN DEVICE  (BE)
    #######################

    $ret = RescanBE( $ctlr );
    if( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to rescan drives. <<<<<<<<");
        return (ERROR);
    }

    ###############
    #  PDISKCOUNT
    ###############

    %rsp = $ctlr->physicalDiskCount();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDiskCount <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to physicalDiskCount <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Physical Disk Count: $rsp{COUNT}");

    #############
    #  PDISKLIST
    #############

    %rsp = $ctlr->physicalDiskList();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDiskList <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to physicalDiskList <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    my $str = "Physical Disk List:";

    for $i (0..$#{$rsp{LIST}})
    {
        $str .=  " " . $rsp{LIST}[$i];
    }

    logInfo($str);

    #
    # we do the following for each physical drive
    #

    for $i (0..$#{$rsp{LIST}})
    {
        logInfo("Testing physical disk $rsp{LIST}[$i]");
        $id = $rsp{LIST}[$i];

        ################
        #  PDISKBEACON
        ################

# commented out because this is just too annoying for all to listen to
#
#        $dur = 2;
#        logInfo ("Physical Disk Beacon($id, $dur): ");
#        %info = $ctlr->physicalDiskBeacon($id, $dur);
#        if ( ! %info  )
#        {
#            logInfo(">>>>>>>> Failed to get response from physicalDiskBeacon <<<<<<<<");
#            return ERROR;
#        }
#        if ($info{STATUS} != PI_GOOD)
#        {
#            logInfo(">>>>>>>> Unable to physicalDiskBeacon <<<<<<<<");
#            PrintError(%info);
#            return ERROR;
#        }

        ##############
        #  PDISKINFO
        ##############
        logInfo("Retrieving physical disk information for each disk");
        %info = $ctlr->physicalDiskInfo($id);
        if ( ! %info  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskInfo <<<<<<<<");
            return ERROR;
        }
        if ($info{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to physicalDiskInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logPhysicalDiskInfo(%info);

        if (!defined($noLabel) or $noLabel == 0)
        {

            ##############
            #  PDISKLABEL
            ##############

            logInfo("Labeling drive $id");
            $ret = LabelSingleDrive( $ctlr, $id, 1 );
            if ( $ret == ERROR  )
            {
                logWarning(">>>>>>>> Failed to label drive. <<<<<<<<");
                return ERROR;
            }

    #        ################
    #        #  PDISKFAIL
    #        ################
    #        logInfo (" Failing (intentionally) drive $id ");
    #        %info = $ctlr->physicalDiskFail($id, 0);
    #        if ( ! %info  )
    #        {
    #            logInfo(">>>>>>>> Failed to get response from physicalDiskFail <<<<<<<<");
    #            return ERROR;
    #        }
    #        if ($info{STATUS} != PI_GOOD)
    #        {
    #            logInfo(">>>>>>>> Unable to physicalDiskFail <<<<<<<<");
    #            PrintError(%info);
    #            return ERROR;
    #        }
    #
    #
    #
    #        ################
    #        #  PDISKRESTORE
    #        ################
    #        logInfo ("Restoring drive $id  ");
    #        %info = $ctlr->physicalDiskRestore($id);
    #        if ( ! %info  )
    #        {
    #            logInfo(">>>>>>>> Failed to get response from physicalDiskRestore <<<<<<<<");
    #            return ERROR;
    #        }
    #        if ($info{STATUS} != PI_GOOD)
    #        {
    #            logInfo(">>>>>>>> Unable to physicalDiskRestore <<<<<<<<");
    #            PrintError(%info);
    #            return ERROR;
    #        }

            #
            # this is a little cleanup from the above
            #

            $ret = LabelSingleDrive( $ctlr, 0xffff, 0);  # unlabel all
            if ( $ret == ERROR  )
            {
                logWarning(">>>>>>>> Failed to unlabel all drives. <<<<<<<<");
                return ERROR;
            }

            $ret = LabelSingleDrive( $ctlr, 0xffff, 1);  # make all data
            if ( $ret == ERROR  )
            {
                logWarning(">>>>>>>> Failed to label all drives as data. <<<<<<<<");
                return ERROR;
            }

        }
    }

    ###############
    # devstat PD
    ###############

    $ret = DispPdiskInfo( $ctlr );

    if ( $ret == ERROR )
    {
        return ERROR;
    }

    #############
    #  PDISKS
    #############
    logInfo("Physical Disks Command");
    %info = $ctlr->physicalDisks();
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from physicalDisks <<<<<<<<");
        return ERROR;
    }
    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to get physicalDisks info <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logPhysicalDisks("STD", %info);

    #################
    #  PDISKDEFRAG
    #################

    ################
    #  PDISKDELETE
    ################

    logInfo("Completed testing physical disk operations");

    return GOOD;
}


##############################################################################
#
#          Name: GPVirtualDiskCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none  (Causes all PDDs to be relabeled)
#
#   Description: executes a bunch of VDD related functions.
#                Relabels all drives for this test
#
##############################################################################
sub GPVirtualDiskCommands
{
    trace();
    my ($ctlr, $noLabel) = @_;

    my %rtn;
    my $ret;
    my @pddList;
    my $i;
    my %rsp;
    my @raidTypes;

     my $productID = getMagProductID( 0, $ctlr ); # Get the product ID
     if ( $productID != 7000 )
        { 
            @raidTypes = (RAID_1, RAID_5, RAID_10, RAID_5 );
        }
     else
        {
            @raidTypes = (RAID_1, RAID_10, RAID_10, RAID_1 );
        }
    my @space = (1, 2, 3, 4, 5, 6);

    return (  GPVirtualDiskCommandsTest( $ctlr, \@space, \@raidTypes, $noLabel ) );
}

##############################################################################
#
#          Name: GPVirtualDiskCommands2
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none     (Causes all PDDs to be relabeled)
#
#   Description: executes a bunch of VDD related functions.
#                Relabels all drives for this test
#
##############################################################################
sub GPVirtualDiskCommands2
{
    trace();
    my ($ctlr, $noLabel) = @_;

    my %rtn;
    my $ret;
    my @pddList;
    my $i;
    my %rsp;
    my @raidTypes;

    # this one has no raid 5 drives
     my $productID = getMagProductID( 0, $ctlr ); # Get the product ID
     if ( $productID != 7000 )
        { 
           @raidTypes = (RAID_1, RAID_10, RAID_10, RAID_5, RAID_5 );
        }
     else
        {
           @raidTypes = (RAID_1, RAID_10, RAID_10, RAID_1, RAID_10 );
        }

    my @space = (1, 2, 3, 4, 5, 6);

    return (  GPVirtualDiskCommandsTest( $ctlr, \@space, \@raidTypes, $noLabel ) );
}

##############################################################################
#
#          Name: GPVirtualDiskCommandsTest
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of VDD related functions.
#                Relabels all drives for this test
#
##############################################################################
sub GPVirtualDiskCommandsTest
{
    trace();
    my ($ctlr, $spacePtr, $raidPtr, $noLabel) = @_;

    my %rtn;
    my $ret;
    my @pddList;
    my @shortPList;
    my $i;
    my %rsp;
    my $listPtr;

    my @raidTypes;
    my @space = (1, 2, 3, 4, 5, 6);

    @raidTypes = @$raidPtr;
    @space = @$spacePtr;
    my $rtype;
    my $depth = 1;
    my $stripe = 0;
    my $parity = 1;
    my $numPDs;
    my @uVdds;

    if (!defined($noLabel) or $noLabel == 0)
    {
        #
        #  make sure we have data drives for the test
        #

        ######################
        # pdisk label
        ######################


        $ret = LabelSingleDrive( $ctlr, 0xffff, 0);  # unlabel all
        if ( $ret == ERROR  )
        {
            logWarning(">>>>>>>> Failed to unlabel all drives. <<<<<<<<");
            return ERROR;
        }

        $ret = LabelSingleDrive( $ctlr, 0xffff, 1);  # make all data
        if ( $ret == ERROR  )
        {
            logWarning(">>>>>>>> Failed to label all drives as data. <<<<<<<<");
            return ERROR;
        }
    }
    else
    {
        logInfo "NOT relabeling drives for this part of the test\n";
    }

    #
    # create an array of the PDDs so we know what wer are working with
    #

    ######################
    # pdisk list
    ######################

    @pddList = GetDataDisks($ctlr, FC_PREFERRED);

    if ( $pddList[0] == INVALID )
    {
        logWarning(">>>>>>>> Could not get data drive list  <<<<<<<<");
        return (ERROR);
    }

    if ( scalar(@pddList) < 3)
    {
        logInfo("There are not enough pdisks to run this test");
        return ERROR;
    }

    for ( $i = 0; $i < 3; $i++)
    {
        $shortPList[$i] = $pddList[$i];
    }

    #
    # loop for redundant raid types
    #

    for(my $i = 0; $i < scalar(@raidTypes); $i++)
    {
        # Name:     calcRaidParms
        # Desc:     Based on the raid type passed in and how many disk we have
        #           returns the correct parameters to be used in the create vdisk
        #           packet

        if ( RAID_1 ==   $raidTypes[$i] )
        {
            $listPtr = \@shortPList;
        }
        else
        {
            $listPtr = \@pddList;
        }

        $rtype =  $raidTypes[$i];

        my $chkNumPDs =  @pddList;
        my $productID = getMagProductID( 0, $ctlr ); # Get the product ID
        if ( $productID != 7000 ) 
        {
        }
        else
        {
         while ($chkNumPDs >= 6)
          {
          # Need to reduce the number to 6.  Take off from the end of the list
          pop(@pddList);
          $chkNumPDs =  @pddList; 
          }
        }


        ####################
        # calc Raid Parms
        ####################
        my $requestedBytes =  Math::BigInt->new($space[$i] * 2048 );

        my $rtn = ValidateVdiskParams( \$depth, \$rtype, \$stripe, \$parity, \@pddList );

        my $str = "";


        # all parameters are ready for the call to create the vdisk
        $str .= "CAPACITY: $requestedBytes blocks  ";
        $str .= "RAID: $rtype  ";
        $str .= "STRIPE SIZE: $stripe  ";
        $str .= "MIRROR DEPTH: $depth  ";
        $str .= "PARITY: $parity  ";
        $numPDs = scalar(@pddList);
        $str .= "NUMBER of PDs: $numPDs  ";   # second line
        $str .= "PD IDs:  @pddList \n";

        logInfo($str);


        if ( $rtn == INVALID )
        {
            logInfo("Parameters for creating the vdisk are invalid.");
            return INVALID;
        }
   #     my %raidParms = $ctlr->calcRaidParms($listPtr, $raidTypes[$i]);
   #
   #     logInfo(" Pdisks: @$listPtr ");
   #
   #     foreach my $name (sort keys %raidParms)
   #     {
   #         logInfo("Name: $name, Value: $raidParms{$name}");
   #     }
   #
   #     logInfo("Space $requestedBytes Creating VD");

        ###############
        # VDISK create
        ###############

        %rtn = $ctlr->virtualDiskCreate(   $requestedBytes,
                                            \@pddList,
                                            $rtype,
                                            $stripe,
                                            $depth,
                                            $parity,
                                            undef,          # vid to use (can be undef)
                                            4,             # maxraids
                                            10,            # threshold
                                            0,             # flags
                                            0              # minPD
                                            );


        if ( ! %rtn  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskCreate <<<<<<<<");
            return ERROR;
        }
        if ( $rtn{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskCreate <<<<<<<<");
            PrintError(%rtn);
            return ERROR;
        }



   #     my $vdc = CreateSingleVdisk($ctlr, "NoName",$space[$i], $raidTypes[$i], 0, 0, 0, $listPtr, undef);
   #
   #     if ( $vdc == INVALID )
   #     {
   #         return ERROR;
   #     }


        ###############
        # VDISK expand
        ###############
        logInfo("Expanding VDD");

        my %info = $ctlr->virtualDiskExpand($rtn{VID},
                                    $requestedBytes,
                                    \@pddList,
                                    $rtype,
                                    $stripe,
                                    $depth,
                                    $parity,
                                    4,             # maxraids
                                    10,            # threshold
                                    0,             # flags
                                    0              # minPD
                                    );



        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }





        #############
        # RAIDINIT
        #############
        logInfo("Now, initialize the VDD");
        $ret = InitVdiskRids($ctlr, $rtn{VID});

        if ( $ret != GOOD )
        {
            logWarning(">>>>>>>> Failure to initialize RAIDS <<<<<<<<");
            return ERROR;
        }


        #####################
        # VDISK information
        #####################
        logInfo("Get Vdisk Information");
        %info = $ctlr->virtualDiskInfo($rtn{VID});
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logVirtualDiskInfo(%info);


        #####################
        # VDISK move
        #####################

        @uVdds = ();
        $ret = TestLibs::BEUtils::FindUnusedVdds ( $ctlr, \@uVdds, 1 );
        if ( $ret != GOOD )
        {
            logInfo(">>>>> Failed to get an unused vdisk ID <<<<<");
            return ERROR;
        }

        #
        # move the vdisk to a different number
        #
        logInfo "Moving vdisk $rtn{VID} to $uVdds[0]."; 
                                                  # src         dest
        %rsp = $ctlr->virtualDiskControl(0x00, $rtn{VID}, $uVdds[0]);

        if (!%rsp)                        # no response
        {
            print "\n";
            logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
            return ERROR;
        }

        if ($rsp{STATUS}  != PI_GOOD)            # 1 is bad
        {
            logInfo(">>>>> virtualDiskControl failed <<<<<");
            print "\n";
            PrintError(%rsp);
            return ERROR;
        }



        #
        # move it back
        #
        logInfo "Moving vdisk $uVdds[0] to $rtn{VID}."; 
                                                  # src         dest
        %rsp = $ctlr->virtualDiskControl(0x00, $uVdds[0], $rtn{VID});

        if (!%rsp)                        # no response
        {
            print "\n";
            logInfo(">>>>> Failed to receive a response from virtualDiskControl <<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)            # 1 is bad
        {
            logInfo(">>>>> virtualDiskControl failed <<<<<");
            print "\n";
            PrintError(%rsp);
            return ERROR;
        }

    }
    
    return GPVdiskMisc($ctlr);
}

##############################################################################
#
#          Name: GPVdiskMisc
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of RDD related functions.
#
##############################################################################
sub GPVdiskMisc
{
    trace();
    my ($ctlr) = @_;

    my %rsp;

    #################
    # VDISK count
    #################

    my %info = $ctlr->virtualDiskCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logInfo("Number of disks present $info{COUNT}");

    ##############
    # VDISK List
    ##############

    %info= $ctlr->virtualDiskList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskList <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDiskList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    my $string = $info{LIST};
    my @Array_Virtual = @$string;
    logInfo("List of Virtual disks @Array_Virtual");

    ############
    # VDISKS
    ############

    %rsp = $ctlr->virtualDisks();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logVirtualDisks(%rsp);

    ###############
    # VDISKCONTROL
    ###############

    ##############
    # VDISKDELETE
    ##############

    ###############
    # VDISKPREPARE
    ###############

    ################
    # VDISKSETCACHE
    ################

    #############
    # VDISKOWNER
    #############

    return GOOD;
}

##############################################################################
#
#          Name: GPRaidCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of RDD related functions.
#
##############################################################################
sub GPRaidCommands
{
    trace();
    my ($ctlr) = @_;

    my %rtn;
    my $ret;
    my %info;
    my $i;



    ############
    # RAIDCOUNT
    ############

    %info = $ctlr->raidCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raidCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raidCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logInfo("Number of raid devices $info{COUNT}");

    ############
    # RAIDLIST
    ############

    %info = $ctlr->raidList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raidList <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raidList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    my $string = $info{LIST};
    my @array_Raid = @$string;
    logInfo("List of raid devices @array_Raid");


    #
    # tests on individual RDDs
    #

    for ( $i = 0; $i < scalar(@array_Raid); $i++ )
    {
        my $id = $array_Raid[$i];


        ##############
        # RAIDINFO
        ##############


        %info = $ctlr->virtualDiskRaidInfo($id);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskRaidInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskRaidInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logVirtualDiskRaidInfo(%info);


        ##############
        # RAIDBEACON
        ##############

        #
        # note: beaconing was tested at the PDD level, this only adds
        # testing the function in cmRaid.pm for correct operation.
        #

#        $ctlr->raidBeacon(2,%info);
#        if ( ! %info  )              # if no return from call
#        {
#            logInfo(">>>>>>>> Failed to get response from raidBeacon <<<<<<<<");
#            return ERROR;
#        }
#        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
#        {
#            logInfo(">>>>>>>> Error from raidBeacon <<<<<<<<");
#            PrintError(%info);
#            return ERROR;
#        }



    }



    ############
    # RAIDS
    ############

    %info = $ctlr->raids();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logRaids(%info);


    ############
    # RAIDINIT   Note: this was tested when the vdisks were created
    ############



    return GOOD;
}

##############################################################################
#
#          Name: GPTargetCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of target related functions.
#
##############################################################################
sub GPTargetCommands
{
    trace();
    my ($ctlr) = @_;

    my %rtn;
    my $ret;
    my %info;
    my $id;
    my %rsp;
    my $i;

    #####################
    # TARGETCOUNT
    #####################
    %info = $ctlr->targetCount();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from targetCount <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from targetCount <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logInfo("Number of Targets $info{COUNT}");



    #####################
    # TARGETSTATUS
    #####################

    %info = $ctlr->targetStatus($id);
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from targetStatus <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from targetStatus <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }




    #####################
    # TARGETLIST
    #####################
    %info = $ctlr->targetList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from targetList <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from targetList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    my $string = $info{LIST};
    my @array_Targets = @$string;
    logInfo("List of Targets @array_Targets");


    #
    # tests on individual targets
    #


    for ( $i = 0; $i < scalar(@array_Targets); $i++ )
    {
        $id = $array_Targets[$i];


        #####################
        # TARGETINFO
        #####################
        %info = $ctlr->targetInfo($id);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from targetInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from targetInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logTargetInfo(%info);
    }

    #####################
    #  TARGETS
    #####################

    %rsp = $ctlr->targets();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from targets command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from targets command <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logTargets(%rsp);

    #####################
    # TARGETSETPROP
    #####################





    #####################
    # TARGETMOVE
    #####################



    #####################
    # TARGETRESLIST
    #####################



    #####################
    # TARGETTEST
    #####################

    return GOOD;
}


##############################################################################
#
#          Name: GPStatsCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of stats related functions.
#
##############################################################################
sub GPStatsCommands
{
    trace();
    my ($ctlr) = @_;

    my %rtn;
    my $ret;
    my %rsp;
    my %info;
    my $i;
    my $r;
    my @vdisks;
    my @serverIDs;
    my $msg;

    ###################
    # envStats
    ###################

    my $productID =  getMagProductID( 0, $ctlr );
    
    if ($productID == 2750)
    {
        my %info = $ctlr->piEnvIIGet();


        if (%info)
        {
            if ($info{STATUS} == PI_GOOD)
            {
                $msg = $ctlr->envIIDisplay(%info);
                logInfo( $msg );
    }
            else
    {
                logInfo(">>>>>>>> Unable to retrieve environmental statistics. <<<<<<<<");
            }
        }
    }
    else
    {
        %info = $ctlr->environmentalStatsExtended();
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from environmentalStatsExtended <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from environmentalStatsExtended <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        my $msg = $ctlr->displayEnvironmentalStatsExtended(%info);
        logInfo( $msg);
    }


    # make sure we have some servers to work with
    %rsp = $ctlr->serverCount();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from serverCount <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from serverCount <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    if ( $rsp{COUNT} < 1 )
    {
        logInfo("##################################################");
        logInfo("#                                                #");
        logInfo("# No SIDs were found, StatsServer tests skipped  #");
        logInfo("#                                                #");
        logInfo("##################################################");
    }
    else
    {


        # find SIDs based on wwn list
        @serverIDs = GetSIDs( $ctlr, 0);


    #    debug(" received @Select_Server_ID )";

        # the next line generates an error if no matching servers were found.
        # need to bail out in that case, or go into prompt mode.

        if ( INVALID == $serverIDs[0] )
        {
            logWarning(">>>>>>>> Failed to get server number(s) <<<<<<<<");
            return ERROR;
        }

        for ( $i = 0; $i < scalar(@serverIDs); $i++ )
        {

            ###################
            # STATSSERVER                # need a loop thru servers
            ###################

            logInfo("Getting statistics for server $serverIDs[$i]");
            %info = $ctlr->statsServer($serverIDs[$i]);
            if ( ! %info  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from statsServer <<<<<<<<");
                return ERROR;
            }
            if ( $info{STATUS} != PI_GOOD )      # if call returned an error
            {
                if ( $info{ERROR_CODE} == 0x2f )
                {
                    logInfo("Not my server");
                }
                else
                {
                    logInfo(">>>>>>>> Error from statsServer <<<<<<<<");
                    PrintError(%info);
                    return ERROR;
                }
            }

            if ( $info{STATUS} == PI_GOOD )      # if call returned an error
            {
                logStatsServer(%info);
            }
        }
    }
    #
    # need an array of vdisk ids for the following
    #

    ######################
    # vdisk list
    ######################


    %rsp = $ctlr->getObjectList(PI_VDISK_LIST_CMD);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from PI_VDISK_LIST_CMD <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Virtual Disk List:");
    logObjectList(%rsp);
    # in here is my list of disks.. now how do i extract it?
    # need to build this array >>>> @vdisklistarray = @$vdisklist;       # make an array

    # put drives into an array
    for ( $r=0; $r< $rsp{COUNT}; $r++)
    {
        push  @vdisks, $rsp{LIST}[$r];
    }

#    $numVDDs = $rsp{COUNT};  # of drives available to map

    for ( $i = 0;  $i < scalar(@vdisks); $i++ )
    {
        ###################
        # STATSCACHEDEV              # need a loop thru vdisks
        ###################

        %info = $ctlr->statsCacheDevices($vdisks[$i]);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from statsCacheDevices <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from statsCacheDevices <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logStatsCacheDevices($vdisks[$i],%info);
    }

    ###################
    # STATSPCI
    ###################
    %info = $ctlr->statsPCI("BE");
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from statsPCI <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from statsPCI <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logStatsPCI("BE", %info);

    %info = $ctlr->statsPCI("FE");
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from statsPCI <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from statsPCI <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logStatsPCI("FE", %info);

    ###################
    # STATSPROC
    ###################


    %info = $ctlr->statsProc("BE");
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from statsProc <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from statsProc <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logStatsProc("BE", %info);


    %info = $ctlr->statsProc("FE");
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from statsProc <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from statsProc <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logStatsProc("FE", %info);

    ###################
    # STATSLOOP
    ###################

    my @option = ("BE", "FE");
    my $j;
    for my $i (0..1)
    {
        for $j (0)
        {
            logInfo("Stats Loop ($option[$i]) channel $j:");
            %info = $ctlr->statsLoop($option[$i], $j);
            if ( ! %info  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from statsLoop <<<<<<<<");
                return ERROR;
            }
            if ( $info{STATUS} != PI_GOOD )      # if call returned an error
            {
                if ( $info{ERROR_CODE} != $ctlr->PI_ERROR_INV_CHAN )
                {
                    logInfo(">>>>>>>> Error from statsLoop <<<<<<<<");
                    PrintError(%info);
                    return ERROR;
                }
                else
                {
                    logInfo("No card on channel $j");
                }
            }
            else
            {
                logStatsLoop($option[$i], %info);
            }
        }
    }


    ###################
    # STATSVDISK
    ###################

    ###################
    #
    ###################


    ###################
    #
    ###################

    return GOOD;
}

##############################################################################
#
#          Name: StatsProcAll
#
#        Inputs: controller object list pointer
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes aand logs StatsProc on each controller.
#
##############################################################################
sub StatsProcAll
{
    trace();
    my ($coPtr) = @_;

    my $i;
    my %info;
    my @coList = @$coPtr;

    logInfo("*** StatsProc on all controllers ***");

    for ( $i =0; $i < scalar(@coList); $i++ )
    {

        logInfo("    StatsProc on controller $coList[$i]->{HOST} ");

        %info = $coList[$i]->statsProc("ALL");
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from statsProc <<<<<<<<");
            return ERROR;
        }

        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from statsProc <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logStatsProc("ALL", %info);

     }

    logInfo("*** StatsProc complete ***");

    return GOOD;

}
##############################################################################
#
#          Name: GPMiscCommands
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of misc functions.
#
##############################################################################
sub GPMiscCommands
{
    trace();
    my ($ctlr) = @_;

    my %rtn;
    my $ret;
    my %rsp;
    my $flag = 0;


    #####################
    #  Firmware Version
    #####################
    logInfo("Testing firmware version operations");

    %rsp = $ctlr->fwVersion();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from fwVersion <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from fwVersion <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logFirmwareVersion(%rsp);

    logInfo("Completed testing firmware version operations");

    ###################
    # memory read
    ###################
    logInfo("Testing memory read operations");

    my $address = 0x48000000;
    my $length = 128;
    my $format = "word";
    my $outfile;

    my @procs = ("CCB", "BE", "FE");

    if ( $ctlr->{CONTROLLER_TYPE} != CTRL_TYPE_BIGFOOT )
    {
        logInfo("Memory read test invalid on Wookiee controller - test skipped");
    }
    else
    {
        for (my $i = 0; $i < scalar(@procs); ++$i)
        {
            my $proc = $procs[$i];

            logInfo("Reading memory for $proc");

            %rsp = $ctlr->ReadMemory($address, $length, $proc);
            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from ReadMemory <<<<<<<<");
                return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                logInfo(">>>>>>>> Error from ReadMemory <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }

            $ctlr->FormatData($rsp{RD_DATA}, $address, $format, $outfile);
        }

        logInfo("Completed testing memory read operations");
    }

    ######################
    # Serial Number - get
    ######################
    logInfo("Testing Serial Number functionality");

    my $origSN = "";

    logInfo("Getting the serial number");
    %rsp = $ctlr->serialNumGet();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from serialNumGet <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from serialNumGet <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logSerialNumbers(%rsp);
    $origSN = $rsp{2}{SERIAL_NUM};

    logInfo("Controller serial number is $rsp{1}{SERIAL_NUM}  ".
             "Group serial number is $rsp{2}{SERIAL_NUM}");

    ######################
    # Serial Number - set
    ######################

    logInfo("Setting the serial number");
    %rsp = $ctlr->serialNumSet($rsp{2}{SERIAL_NUM}, $ctlr->SYSTEM_SN);
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from serialNumSet <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from serialNumSet <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Getting the serial number");
    %rsp = $ctlr->serialNumGet();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from serialNumGet <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from serialNumGet <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logSerialNumbers(%rsp);

    if ( $origSN != $rsp{2}{SERIAL_NUM} )
    {
        logInfo(">>>>>>>> Original and final serial numbers do not match. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Completed testing Serial Number functionality");

    ###################
    #  MRP timeout
    ###################

    my $value = 400;

    logInfo("Setting MRP timeout to 400 seconds");
    %rsp = $ctlr->timeoutMRP("MRP", $value);
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from timeoutMRP <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from timeoutMRP <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("MRP global timeout set ($value)");
    logInfo("Resetting MRP timeout to 30 seconds");
    $value = 30;

    %rsp = $ctlr->timeoutMRP("MRP", $value);
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from timeoutMRP <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from timeoutMRP <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Completed Testing Setting MRP Timeout");

    ###################
    # Device List
    ###################

    my @option = ("BE", "FE");
    my $j;
    for my $i (0..1)
    {
        for $j (0..3)
        {
            if ($option[$i] eq "FE")
            {
                # Validate port and check if it is ISCSI or FC based on which devicelist 
                # values are retrieved
                
                &TestLibs::iscsi::ValidateTargetType ($ctlr, $j, \$flag);
            } 
           
            if (($flag == 1) || ($option[$i] eq "BE"))
            {
            logInfo("Device List ($option[$i]) channel $j:");

            %rsp = $ctlr->deviceList($option[$i], $j);
            
            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from deviceList <<<<<<<<");
                return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
                if ( $rsp{ERROR_CODE} != $ctlr->PI_ERROR_INV_CHAN )
                {
                    logInfo(">>>>>>>> Error from deviceList <<<<<<<<");
                    PrintError(%rsp);
                    return ERROR;
                }
                else
                {
                    logInfo("No card on channel $j");
                }
            }
            else
            {
                logDeviceList(%rsp);
                }
            }
            else
            {
                    logInfo(" Port $j is a iSCSI port");
            }
        }
    }
    #my $msg = "Unable get devicelist on channel $chan for device " . uc($type) . "\n";

    return GOOD;
}

##############################################################################
#
#          Name: GPResetTest
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of misc functions.
#
##############################################################################
sub GPResetTest
{
    trace();
    my ($ctlr) = @_;

    logInfo("Testing Reset Operations");

    my %rsp;
    my $fe_reset = 1;
    my $be_reset = 2;
    my $reset_all_qlogic = 0xFF;
    my $i;
    my $pause_at_end = 10;
    my @feportlist;
    my @beportlist;


    my $productID =  getMagProductID( 0, $ctlr );


    @feportlist = FindQL($ctlr, "FE", 5 );
    @beportlist = FindQL($ctlr, "BE", 5 );
    
    logInfo("List of FE ports: @feportlist\n");
    logInfo("List of BE ports: @beportlist\n");

    ####################
    # resetQlogicFE
    ####################
    logInfo("Resetting Individual Qlogic cards on FE:");

    for $i (0..3)
    {
        %rsp = $ctlr->resetQlogicFE($i, $ctlr->RESET_QLOGIC_RESET_INITIALIZE);

        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from resetQlogicFE <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {

            if ( $rsp{ERROR_CODE} != $ctlr->PI_ERROR_INV_CHAN )
            {

                logInfo(">>>>>>>> Error from resetQlogicFE <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }
            else
            {
                logInfo("No card on channel $i");
            }
        }
    }

    if ($productID != 2750)
    {
        ####################
        # resetQlogicBE
        ####################
        logInfo("Resetting Individual Qlogic cards on BE:");

        for $i (0..3)
        {
            %rsp = $ctlr->resetQlogicBE($i, $ctlr->RESET_QLOGIC_RESET_INITIALIZE);

            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from resetQlogicBE <<<<<<<<");
                return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {

                if ( $rsp{ERROR_CODE} != $ctlr->PI_ERROR_INV_CHAN )
                {

                    logInfo(">>>>>>>> Error from resetQlogicBE <<<<<<<<");
                    PrintError(%rsp);
                    return ERROR;
                }
                else
                {
                    logInfo("No card on channel $i");
                }
            }
        }
    }

    ######################
    # resetQlogicFE - all
    ######################

    logInfo("Resetting ALL Qlogic cards on FE:");

    %rsp = $ctlr->resetQlogicFE($reset_all_qlogic, $ctlr->RESET_QLOGIC_RESET_INITIALIZE);
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from resetQlogicFE <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from resetQlogicFE for all channels <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }



    if ($productID != 2750)
    {
    
        ######################
        # resetQlogicBE - all
        ######################

        logInfo("Resetting ALL Qlogic cards on BE:");

        %rsp = $ctlr->resetQlogicBE($reset_all_qlogic, $ctlr->RESET_QLOGIC_RESET_INITIALIZE);
        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from resetQlogicBE <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from resetQlogicBE for all channels <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }

        my @feportlist1 = FindQL($ctlr, "FE", 5 );
        my @beportlist1 = FindQL($ctlr, "BE", 5 );

        logInfo("List of FE ports Available after resets: @feportlist1\n");
        logInfo("List of BE ports Available after resets: @beportlist1\n");

        while ( ( scalar(@feportlist) != scalar(@feportlist1)) || ( scalar(@beportlist) != scalar(@beportlist1) ) )
        {
            @feportlist1 = FindQL($ctlr, "FE", 5 );
            @beportlist1 = FindQL($ctlr, "BE", 5 );
            
            logInfo("List of FE ports (Inside While): @feportlist1\n");
            logInfo("List of BE ports: @beportlist1\n");
        }

    logInfo("Pausing for $pause_at_end Seconds to Allow QLogic cards to reinitialize");
    sleep $pause_at_end;
    logInfo("Pause Complete");
    logInfo("Completed Testing Reset Operations");
    return GOOD;
}


##############################################################################
#
#          Name: GPDeviceStatus
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes DEVSTAT function with its options.
#
##############################################################################
sub GPDeviceStatus
{
    trace();
    my ($ctlr) = @_;

    logInfo("Testing device status operations");

    my $i;
    my $rc = 1;
    my %rsp;
    my $swtch;
    my @arr_dev;
    $arr_dev[0] = "VD";
    $arr_dev[1] = "RD";
    $arr_dev[2] = "PD";

    for $i (0..2)
    {
        ######################
        # device status
        ######################


        %rsp = $ctlr->deviceStatus($arr_dev[$i]);
        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from deviceStatus <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from deviceStatus <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        logInfo("Printing device status for ($arr_dev[$i]):");
        logDeviceStatus($arr_dev[$i], "N", %rsp);
        logDeviceStatus($arr_dev[$i], "S", %rsp);
    }

    logInfo("Completed testing device status operations");

    return GOOD;
}

##############################################################################
#
#          Name: GPLoggingTest
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of misc functions.
#
##############################################################################
sub GPLoggingTest
{
    trace();
    my ($ctlr) = @_;

    logInfo("Testing logging operations");

    my $rc = 1;
    my %rsp;
    my %i;


    ######################
    # LOG INFO
    ######################

    %rsp = $ctlr->logInfo(50, 0x10, 0);
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from logInfo <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from logInfo <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logLogInfo(0, 0, %rsp);


    %rsp = $ctlr->logInfo(100, 0x12, 0);
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from logInfo <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from logInfo <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logLogInfo(2, 0, %rsp);

    logInfo("Completed testing logging operations");

    return GOOD;
}

##############################################################################
#
#          Name: GPCaching
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: executes a bunch of caching functions.
#
##############################################################################
sub GPCaching
{
    trace();
    my ($ctlr) = @_;

    logInfo("Testing Virtual Disk Caching Operations");

    my $rc = 1;
    my %rsp;
    my %rsp2;
    my %rsp3;
    my $i;
    my $r;
    my @vdisks;

    #
    # need an array of vdisk ids for the following
    #

 
    if ( $ctlr->{CONTROLLER_TYPE} != CTRL_TYPE_BIGFOOT && 
         CACHING_ALLOWED_WOOKIEE == 0 )
    {
        logInfo("Caching test invalid on Wookiee controller - test skipped");
        return GOOD;
    }
 
 
    ######################
    # vdisk list
    ######################

    %rsp = $ctlr->getObjectList(PI_VDISK_LIST_CMD);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from PI_VDISK_LIST_CMD <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logInfo("Virtual Disk List:");
    logObjectList(%rsp);
    # in here is my list of disks.. now how do i extract it?
    # need to build this array >>>> @vdisklistarray = @$vdisklist;       # make an array

    # put drives into an array
    for ( $r=0; $r< $rsp{COUNT}; $r++)
    {
        push  @vdisks, $rsp{LIST}[$r];
    }

#    $numVDDs = $rsp{COUNT};  # of drives available to map





    for $i (0..(scalar(@vdisks)-1))
    {
        my $id = $vdisks[$i];          # the vdisk to work on

        ######################
        # VDISK info
        ######################


        my %info = $ctlr->virtualDiskInfo($id);
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        my $old_cache = (512 & $info{ATTR}) ? 1 : 0 ;             # cache is bit 8
        my $new_cache = $old_cache == 1 ? 0 : 1;
        my $old_cache_desc = $old_cache == 1 ? "Enabled" : "Disabled";
        my $new_cache_desc = $new_cache == 1 ? "Enabled" : "Disabled";

        logInfo("Virtual Disk $id Caching $old_cache_desc, Setting to $new_cache_desc:");


        ######################
        # VDISK set cache
        ######################


        %rsp2 = $ctlr->virtualDiskSetCache($id, $new_cache);
        if ( ! %rsp2  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskSetCache <<<<<<<<");
            return ERROR;
        }
        if ( $rsp2{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskSetCache <<<<<<<<");
            PrintError(%rsp2);
            return ERROR;
        }
        logInfo("Virtual Disk $id Caching $new_cache_desc.");
        logInfo("Resetting Virtual Disk $id Caching to $old_cache_desc.");

        %rsp3 = $ctlr->virtualDiskSetCache($id, $old_cache);
        if ( ! %rsp3  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskSetCache <<<<<<<<");
            return ERROR;
        }
        if ( $rsp3{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskSetCache <<<<<<<<");
            PrintError(%rsp3);
            return ERROR;
        }
        logInfo("Virtual Disk $id Caching $old_cache_desc.");



    }

    logInfo("Completed Testing Virtual Disk Caching Operations");
    logInfo("Testing Global Caching operations");

    my $enabled = 0x04;
    my $mode;

    ######################
    # global cache info
    ######################


    logInfo("Global caching information");
    %rsp = $ctlr->globalCacheInfo();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from globalCacheInfo <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from globalCacheInfo <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logGlobalCacheInfo(%rsp);

    if ($rsp{CA_STATUS} == $enabled)
    {
        $mode = 0x80;
        logInfo("Global caching is enabled...Disabling:");
    }
    else
    {
        $mode = 0x81;
        logInfo("Global caching is disabled...Enabling:");
    }

    ######################
    # global cache set
    ######################


    %rsp2 = $ctlr->globalCacheSet($mode);
    if ( ! %rsp2  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from globalCacheSet <<<<<<<<");
        return ERROR;
    }
    if ( $rsp2{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from globalCacheSet <<<<<<<<");
        PrintError(%rsp2);
        return ERROR;
    }

    if ($mode == 0x80)
    {
        logInfo("Global caching disabled.");
        $mode = 0x81;
    }
    else
    {
        logInfo("Global caching enabled.");
        $mode = 0x80;
    }

    logInfo("Restoring caching to its original state:");

    %rsp3 = $ctlr->globalCacheSet($mode);
    if ( ! %rsp3  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from globalCacheSet <<<<<<<<");
        return ERROR;
    }
    if ( $rsp3{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from globalCacheSet <<<<<<<<");
        PrintError(%rsp3);
        return ERROR;
    }


    if ($mode == 0x81)
    {
        logInfo("Global caching restored to enabled.");
    }
    else
    {
        logInfo("Global caching restored to disabled.");
    }

    logInfo("Completed testing global caching operations");

    return GOOD;
}



##############################################################################
#
#          Name: GPMemoryLeakTest
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: display information for evaluating memory leaks.
#
##############################################################################


sub GPMemoryLeakTest
{
    trace();
    my ($ctlr) = @_;

    logInfo("Looking for memory leaks");

    my %rsp;

    ######################
    # Gen MRP ??
    ######################
    %rsp = $ctlr->generic2Command("heap");
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from get heap MRP <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from get heap MRP <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    my $msg = $ctlr->FormatHeapData($rsp{DATA}, undef);

    if (defined($msg))
    {
        logInfo($msg);
    }
    else
    {
        logInfo("Couldn't get Formatted Memory Leak Data...");
    }

    logInfo("Completed memory leak operations");
    return GOOD;
}

##############################################################################
#
#          Name: GPModes
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: displays mode bits, also leaves no-suicide bit set
#
#
##############################################################################
sub GPModes
{
    trace();
    my ($ctlr) = @_;
    my $ret;
    my %rsp;


    my @objList;                 # set up for NoSuicide call
    $objList[0] = $ctlr;

    ######################
    # MODE BIT INFO
    ######################
    logInfo("Getting mode bit info");

    %rsp = $ctlr->modeDataGet();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from modeDataGet <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve mode data. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logModeDataInfo(%rsp);

    ######################
    # MODE BIT SET
    ######################

    $ret = NoSuicide(\@objList);
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failure setting no suicide bit <<<<<<<<");
        return (ERROR);
    }

    #
    # see that the change occurred
    #

    %rsp = $ctlr->modeDataGet();
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from modeDataGet <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve mode data. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logModeDataInfo(%rsp);

    return GOOD;
}

##############################################################################
#
#          Name: GPFidRead
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub GPFidRead
{
    trace();
    my ($ctlr) = @_;

    my %data;


    ###################
    # FID READ
    ###################

    logInfo("Reading file system (may be slow)");

    %data = $ctlr->ReadFID(2);
    if ( ! %data  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from ReadFID <<<<<<<<");
        return ERROR;
    }
    if ( $data{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from ReadFID <<<<<<<<");
        PrintError(%data);
        return ERROR;
    }

    # After data read up, format it appropriately.
    $ctlr->FormatData($data{RD_DATA}, 0, "byte", undef, 1024);



    return GOOD;


}
##############################################################################
#
#          Name: GPCreateExpandDelete
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Created Vdisks, expands, init and deletes them
#
#
##############################################################################
sub GPCreateExpandDelete
{
    trace();
    my ($ctlr) = @_;
    my $ret;
    my $i;
    my @pddList;
    my @raidTypes;

    my $productID =  getMagProductID( 0, $ctlr );  # Get the product ID
     
     if ( $productID != 7000 )
        { 

            @raidTypes = (RAID_5, RAID_5, RAID_5, RAID_5, RAID_5,
                        RAID_5, RAID_5, RAID_5, RAID_5, RAID_5 );
        }
     else
        {
            @raidTypes = (RAID_1, RAID_1, RAID_1, RAID_10, RAID_10,
                        RAID_10, RAID_1, RAID_10, RAID_1, RAID_1 );
        }


    my @space = (1105, 1755.25, 500, 2155.75, 60310, 10, 4016.5, 5516.75, 7107, 12125);

    return  GPCreateExpandDeleteTest($ctlr, \@space, \@raidTypes);
}

##############################################################################
#
#          Name: GPCreateExpandDelete2
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Created Vdisks, expands, init and deletes them
#
#
##############################################################################
sub GPCreateExpandDelete2
{
    trace();
    my ($ctlr) = @_;
    my $ret;
    my $i;
    my @pddList;
    my @raidTypes;

     my $productID =  getMagProductID( 0, $ctlr );  # Get the product ID
     if ( $productID != 7000 )
        { 
            @raidTypes = (RAID_1, RAID_10, RAID_1, RAID_10, RAID_1,
                            RAID_10, RAID_1, RAID_10, RAID_1, RAID_10 );
        }
     else
        {
            
            @raidTypes = (RAID_1, RAID_10, RAID_1, RAID_10, RAID_1,
                            RAID_10, RAID_1, RAID_10, RAID_1, RAID_10 );
        }
                        
    my @space = (1105, 5, 1115.5, 15115.75, 575, 1161.25, 5120, 1116.75, 50, 2450);

    return  GPCreateExpandDeleteTest($ctlr, \@space, \@raidTypes);
}


##############################################################################
#
#          Name: GPCreateExpandDeleteTest
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Created Vdisks, expands, init and deletes them
#
#
##############################################################################
sub GPCreateExpandDeleteTest
{
    trace();
    my ($ctlr, $spacePtr, $raidPtr) = @_;
    my $ret;
    my $i;
    my @pddList;

    my @raidTypes;
    my @space;
    my $parity = 1;
    my $depth = 1;
    my $stripe = 0;
    my $numPDs;

    @raidTypes = @$raidPtr;
    @space = @$spacePtr;

    $ret = DispVdisksRaids($ctlr);
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failure dispaly config info <<<<<<<<");
        return (ERROR);
    }

    #
    # create an array of the PDDs so we know what are working with
    #

    ######################
    # pdisk list                      # need to use only the data disks
    ######################
 
    @pddList = GetDataDisks($ctlr, FC_PREFERRED);
    my $chkNumPDs =  @pddList;
     my $productID = getMagProductID( 0, $ctlr ); # Get the product ID
     if ( $productID != 7000 ) 
        {
        }
        else
        {
         while ($chkNumPDs >= 6)
          {
          # Need to reduce the number to 6.  Take off from the end of the list
          pop(@pddList);
          $chkNumPDs =  @pddList; 
          }
        }
        
    if ( $pddList[0] == INVALID )
    {
        logInfo(">>>>>>>> Not enough drives for C/E/I/D test  <<<<<<<<");
        return (ERROR);
    }



    for(my $i = 0; $i < scalar(@raidTypes); $i++)
    {

        logInfo(sprintf("C/E/I/D drive %d of %d", ($i + 1), scalar(@raidTypes)));

        # Name:     calcRaidParms
        # Desc:     Based on the raid type passed in and how many disk we have
        #           returns the correct parameters to be used in the create vdisk
        #           packet


        ####################
        # calc Raid Parms
        ####################

        my $requestedBytes =  Math::BigInt->new(($space[$i] * 2048) );
    #    logInfo("Space $requestedBytes");

        my $rtn = ValidateVdiskParams( \$depth, \$raidTypes[$i], \$stripe, \$parity, \@pddList );

        my $str = "";


        # all parameters are ready for the call to create the vdisk
        $str .= "CAPACITY: $requestedBytes blocks  ";
        $str .= "RAID: $raidTypes[$i]  ";
        $str .= "STRIPE SIZE: $stripe  ";
        $str .= "MIRROR DEPTH: $depth  ";
        $str .= "PARITY: $parity  ";
        $numPDs = scalar(@pddList);
        $str .= "NUMBER of PDs: $numPDs  ";   # second line
        $str .= "PD IDs:  @pddList \n";

        logInfo($str);


        if ( $rtn == INVALID )
        {
            logInfo("Parameters for creating the vdisk are invalid.");
            return INVALID;
        }
        logInfo("Creating VD");

        ###############
        # VDISK create
        ###############

        my %rtn = $ctlr->virtualDiskCreate(   $requestedBytes,
                                            \@pddList,
                                            $raidTypes[$i],
                                            $stripe,
                                            $depth,
                                            $parity,
                                            undef,          # vid to use (can be undef)
                                            4,             # maxraids
                                            10,            # threshold
                                            0,             # flags
                                            0              # minPD
                                            );


        if ( ! %rtn  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskCreate <<<<<<<<");
            return ERROR;
        }
        if ( $rtn{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskCreate <<<<<<<<");
            PrintError(%rtn);
            return ERROR;
        }


        ###############
        # VDISK expand
        ###############
        my %info = $ctlr->virtualDiskExpand($rtn{VID},
                                        $requestedBytes,
                                        \@pddList,
                                        $raidTypes[$i],
                                        $stripe,
                                        $depth,
                                        $parity,
                                        4,             # maxraids
                                        10,            # threshold
                                        0,             # flags
                                        0              # minPD
                                        );


        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        #############
        # RAIDINIT
        #############
        logInfo("Now, initialize the VDD");
        $ret = InitVdiskRids($ctlr, $rtn{VID});

        if ( $ret != GOOD )
        {
            logInfo(">>>>>>>> Failure to initialize RAIDS <<<<<<<<");
            return ERROR;
        }

        #####################
        # VDISK information
        #####################
        logInfo("Get Vdisk Information");
        %info = $ctlr->virtualDiskInfo($rtn{VID});
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logVirtualDiskInfo(%info);

        #####################
        # VDISK Delete
        #####################

        logInfo("Deleting vdisk $rtn{VID}");

        if ( ERROR == DeleteSingleVdisk($ctlr, $rtn{VID}) )
        {
           return ERROR;
        }

    }

    $ret = DispVdisksRaids($ctlr);
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failure to display raid info <<<<<<<<");
        return (ERROR);
    }


    #####################
    # Orphaned raid check
    #####################

    $ret =  TestLibs::UETestSupport::OrphanedRaidCheck2 ($ctlr);
    if ( $ret == ERROR )
    {
        logInfo(">>>>>>>> Failure checking for orphaned raids <<<<<<<<");
        return (ERROR);
    }


    return GOOD;


}

##############################################################################
#
#          Name: GPCreateExpand
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Created Vdisks, expands, init and deletes them
#
#
##############################################################################
sub GPCreateExpand
{
    trace();
    my ($ctlr) = @_;
    my $ret;
    my $i;
    my @pddList;
    my $stripe = 0;
    my $parity = 1;
    my $depth = 1;
    my $numPDs;
    my @raidTypes;

     my $productID =  getMagProductID( 0, $ctlr );  # Get the product ID
     if ( $productID != 7000 )
        { 
            @raidTypes = (RAID_5, RAID_5, RAID_5, RAID_5, RAID_5,
                        RAID_5, RAID_5, RAID_5, RAID_5 );
        }
     else
        {
            @raidTypes = (RAID_10, RAID_10, RAID_10, RAID_10, RAID_10,
                            RAID_10, RAID_10, RAID_10, RAID_10, RAID_10 );
        }
                        
    my @space = (5, 5.25, 5.5, 5.75, 6, 6.25, 6.5, 6.75, 7,7.5);

    $ret = DispVdisksRaids($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure dispaly config info <<<<<<<<");
        return (ERROR);
    }

    #
    # create an array of the PDDs so we know what are working with
    #

    ######################
    # pdisk list                      # need to use only the data disks
    ######################
 
    @pddList = GetDataDisks($ctlr, FC_PREFERRED);
    my $chkNumPDs =  @pddList;
     if ( $productID != 7000 ) 
        {
        }
        else
        {
         while ($chkNumPDs > 6)
          {
          # Need to reduce the number to 6.  Take off from the end of the list
          pop(@pddList);
          $chkNumPDs =  @pddList; 
          }
        }



    if ( $pddList[0] == INVALID )
    {
        logWarning(">>>>>>>> Not enough drives for C/E/I/D test  <<<<<<<<");
        return (ERROR);
    }



    for(my $i = 0; $i < scalar(@raidTypes); $i++)
    {
        # Name:     calcRaidParms
        # Desc:     Based on the raid type passed in and how many disk we have
        #           returns the correct parameters to be used in the create vdisk
        #           packet


        ####################
        # calc Raid Parms
        ####################
       my $requestedBytes =  Math::BigInt->new(($space[$i] * 2048) );

        my $rtn = ValidateVdiskParams( \$depth, \$raidTypes[$i], \$stripe, \$parity, \@pddList );

        my $str = "";


        # all parameters are ready for the call to create the vdisk
        $str .= "CAPACITY: $requestedBytes blocks  ";
        $str .= "RAID: $raidTypes[$i]  ";
        $str .= "STRIPE SIZE: $stripe  ";
        $str .= "MIRROR DEPTH: $depth  ";
        $str .= "PARITY: $parity  ";
        $numPDs = scalar(@pddList);
        $str .= "NUMBER of PDs: $numPDs  ";   # second line
        $str .= "PD IDs:  @pddList \n";

        logInfo($str);


        if ( $rtn == INVALID )
        {
            logInfo("Parameters for creating the vdisk are invalid.");
            return INVALID;
        }


        ###############
        # VDISK create
        ###############

        my %rtn = $ctlr->virtualDiskCreate(   $requestedBytes,
                                            \@pddList,
                                            $raidTypes[$i],
                                            $stripe,
                                            $depth,
                                            $parity,
                                            undef,          # vid to use (can be undef)
                                            4,             # maxraids
                                            10,            # threshold
                                            0,             # flags
                                            0              # minPD
                                            );

        if ( ! %rtn  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskCreate <<<<<<<<");
            return ERROR;
        }
        if ( $rtn{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskCreate <<<<<<<<");
            PrintError(%rtn);
            return ERROR;
        }


        ###############
        # VDISK expand
        ###############
        my %info = $ctlr->virtualDiskExpand($rtn{VID},
                                        $requestedBytes,
                                        \@pddList,
                                        $raidTypes[$i],
                                        $stripe,
                                        $depth,
                                        $parity,
                                        4,             # maxraids
                                        10,            # threshold
                                        0,             # flags
                                        0              # minPD
                                        );

        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskExpand <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskExpand <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }





        #############
        # RAIDINIT
        #############
        logInfo("Now, initialize the VDD");
        $ret = InitVdiskRids($ctlr, $rtn{VID});

        if ( $ret != GOOD )
        {
            logWarning(">>>>>>>> Failure to initialize RAIDS <<<<<<<<");
            return ERROR;
        }


        #####################
        # VDISK information
        #####################
        logInfo("Get Vdisk Information");
        %info = $ctlr->virtualDiskInfo($rtn{VID});
        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }

        logVirtualDiskInfo(%info);
    }

    $ret = DispVdisksRaids($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failure display config info <<<<<<<<");
        return (ERROR);
    }

    return GOOD;


}



##############################################################################
#
#          Name:DispVdisksRaids
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: displays vdisks raids and maybe other stuff
#
#
##############################################################################
sub DispVdisksRaids
{
    trace();
    my ($ctlr) = @_;

    my %info;
    my %rsp;
    my $i;
    my $j;

    ############
    # VDISKS
    ############

    %rsp = $ctlr->virtualDisks();
    if ( ! %rsp  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks command <<<<<<<<");
        return ERROR;
    }
    if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from virtualDisks command <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    logVirtualDisks(%rsp);

    ############
    # RAIDS
    ############

    %info = $ctlr->raids();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logRaids(%info);

    ############
    # RAIDLIST
    ############

    for ( $i = 0; $i < $info{COUNT}; $i++ )
    {
        my @pidList;         # needs to be declared here

        # extract the pdisklist (in order)

        for ($j = 0; $j < $info{RAIDS}[$i]{PSDCNT}; $j++)
        {
            push(@pidList, $info{RAIDS}[$i]{PIDS}[$j]{PID});
        }

        logInfo("    Raid $i uses these PDDs: @pidList ");
    }

    logInfo("");

    return GOOD;
}


##############################################################################
#
#          Name: GPReal1Way
#
#        Inputs: controller object, WWN list, vdisk option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: deletes what is there and creates a reasonable 1 way
#
#
##############################################################################
sub GPReal1Way
{
    trace();
    my ($ctlr, $wwnPtr, $diskOption) = @_;

    my $ret;
    my $minpdisksflag = TRUE;

    
    #
    # show what was there
    #

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }


    #
    # clean up anything from previous tests
    #

    $ret = DisassocAll ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to disassociate all servers <<<<<<<<");
        return (ERROR);
    }

    $ret = DeleteAllVdisks2 ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to delete all vdisks <<<<<<<<");
        return (ERROR);
    }

    $ret = LabelSingleDrive ( $ctlr, 0xffff, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to unlabel all drives <<<<<<<<");
        return (ERROR);
    }


    #
    # now build the configuration
    #

    my %pdisks = $ctlr->physicalDisks();
    
    # set $minpdisksflag to FALSE, if there are more than 8 physical disks
    # this is intended for a 750 controller with minimum number of physical
    # disks.
        
    # This check can go once each 750 is supplied with enough pdisks

    if ( $pdisks{COUNT} > 8 )
    {
        $minpdisksflag = FALSE;
    }
    elsif( $pdisks{COUNT} == 8 )
    {
        $diskOption = 44;
    }
    else
    {
         $diskOption = 43;
    }


    if ($minpdisksflag == FALSE)
    {
    $ret = LabelAllDrives($ctlr, 11, 2, 1, 0, 0 );     # for 14 drive bays
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to label the drives <<<<<<<<");
        return (ERROR);
    }

    }
    elsif ( $diskOption == 43 )
    {
        $ret = LabelAllDrives($ctlr, 100, 0, 1, 0, 0 );     # for 750 with min pdisks
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to label the drives <<<<<<<<");
            return (ERROR);
        }
    }
    elsif ( $diskOption == 44 )
    {
        $ret = LabelAllDrives($ctlr, 100, 2, 1, 0, 0 );     # for 750 with min pdisks
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to label the drives <<<<<<<<");
            return (ERROR);
        }
    }
    
    
    $ret = MakeVdisks($ctlr, $diskOption, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to create new vdisks <<<<<<<<");
        return (ERROR);
    }

    GetSIDs( $ctlr, 0 );   # show sids to user

#    $ret = PromptUser( 3 );    # assume the server objects are there

    $ret = AssociateServers($ctlr, 2, $wwnPtr );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to associate drives to servers <<<<<<<<");
        return (ERROR);
    }

    #
    # show what is there now
    #

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }
    return GOOD;


}

##############################################################################
#
#          Name: PingAll
#
#        Inputs: controller object list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Pings from one controller to another. Used to keep
#                connections alive (keep them from timing out due
#                to inactivity.)
#
#
##############################################################################
sub PingAll
{
    trace();
    my ($coPtr) = @_;

    my $ctlr1;
    my $ctlr2;
    my $i;
    my $sn1;
    my $sn2;
    my %rsp;


    my @coList;

    @coList = @$coPtr;

    # Sleep for 10 seconds and let the system normalize.
    sleep (10);


    if (scalar(@coList) < 2 )
    {
        # only one controller, no need to bother as other activity
        # will keep it alive, and there is nobody else to ping anyway.
        return GOOD;
    }

    $ctlr1 = $coList[0];
    $ctlr2 = $coList[1];

    $sn1 = GetSerial($ctlr1);
    $sn2 = GetSerial($ctlr2);

    if ( ( INVALID == $sn1 ) || ( INVALID == $sn2 ) )
    {
        logError(">>>>>>>> Failed to get one of the serial numbers <<<<<<<<");
        return ERROR;
    }

    # Now ping from the first one to the second

    %rsp = $ctlr1->vcgPing($sn2);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> No response pinging master to (1st) slave <<<<<<<<");
        return (ERROR);
    }

    if ( $rsp{STATUS} != PI_GOOD )
    {
        logInfo(">>>>>>>> Failed to ping 1st slave <<<<<<<<");

        PrintError(%rsp);

        return (ERROR);
    }

    # now ping the rest back to the master

    for ( $i = 1; $i< scalar(@coList); $i++)
    {
        $ctlr2 = $coList[$i];                 # the one to ping from

        %rsp = $ctlr2->vcgPing($sn1);

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> No response pinging slave $i to master <<<<<<<<");
            return (ERROR);
        }

        if ( $rsp{STATUS} != PI_GOOD )
        {
            logInfo(">>>>>>>> Slave $i failed to ping master <<<<<<<<");

            PrintError(%rsp);

            return (ERROR);
        }

    }

    # done with all

    return GOOD;

}


##############################################################################
#
#          Name: GPReal2Way
#
#        Inputs: controller object, WWN list, vdisk option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: deletes what is there and creates a reasonable 1 way
#
#
##############################################################################
sub GPReal2Way
{
    trace();
    my ($coPtr, $wwnPtr, $diskOption) = @_;

    my $ret;
    my $ctlr;
    my $ctlr2;
    my $i;
    my $numCtlrs;

    my @coList;
    my $masterIndex;

    @coList = @$coPtr;

    $ctlr  = $coList[0];
    $ctlr2 = $coList[1];

    $numCtlrs = scalar(@coList);

    #
    # show what was there
    #

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }


    ########################################
    # clean up anything from previous tests
    ########################################

    # this really needs to be wipe clean, then reboot&reconnect

    $ret = DisassocAll ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to disassociate all servers <<<<<<<<");
        return (ERROR);
    }

    $ret = DeleteAllVdisks2 ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to delete all vdisks <<<<<<<<");
        return (ERROR);
    }

    $ret = LabelSingleDrive ( $ctlr, 0xffff, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to unlabel all drives <<<<<<<<");
        return (ERROR);
    }

# the following trashes the licenses.

#    for ( $i = 0; $i < $numCtlrs; $i++ )
#    {
#        #  trash BE NVRAM
#        logInfo("Corrupt BE NVRAM $i");
#        $ret = CorruptBENvram( $coList[$i] );
#        if ( $ret == ERROR )
#        {
#            logError(">>>>>>>> Failed to corrupt BE NVRAM <<<<<<<<");
#            return (ERROR);
#        }
#
#    }
#
#    $ret = RebootControllers ( $coPtr, 60 );
#
#    # this also does a reconnect
#
#    if ( $ret == ERROR )
#    {
#        logError(">>>>>>>> Failed to reboot all controllers <<<<<<<<");
#        return (ERROR);
#    }




    #
    # now build the configuration
    #

    $ret = LabelAllDrives($ctlr, 11, 2, 1, 0, 0 );     # for 14 drive bays
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to label the drives <<<<<<<<");
        return (ERROR);
    }

    $ret = MakeNWay($coPtr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to add controller to vcg <<<<<<<<");
        return (ERROR);
    }

    $masterIndex = FindMaster($coPtr);
    if ( $masterIndex == INVALID ) 
    { 
        logInfo(">>>>>>>> Unable to identify the master controller. <<<<<<<<");
        return(ERROR); 
    }
    $ctlr = $coList[$masterIndex]; 

    $ret = MakeVdisks($ctlr, $diskOption, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to create new vdisks <<<<<<<<");
        return (ERROR);
    }

    GetSIDs( $ctlr, 0 );   # show sids to user

#    $ret = PromptUser( 3 );    # assume the server objects are there

    $ret = AssociateServers($ctlr, 2, $wwnPtr );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to associate drives to servers <<<<<<<<");
        return (ERROR);
    }

    #
    # show what is there now
    #

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }
    return GOOD;


}

##############################################################################

##############################################################################
#
#          Name: DefragTest
#
#        Inputs: controller object, server wwn list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub DefragTest
{
    trace();
    my ($ctlr, $wwnPtr) = @_;

    my $ret;
    my $option;
    my $loops;


    # we start from scratch,
    # label the drives
    # get list of data drives
    # create 3 vdisks
    # associate 2nd and 3rd to servers so IO can be done

    $ret = DefragPart1($ctlr, 1, $wwnPtr);   # 1 is 1 way system


    # for n loops

        # create 2 vdisks
        # start inits
        # delete 1st of the 2 vdisks
        # start defrag

    $loops = 25;


    #
    # option flag, bit significant controls...
    #        NO_RAID_INIT   No init of the raids
    #        DEFRAG_WAIT    Wait for raids to finish in each loop
    #

 #   $option = NO_RAID_INIT + DEFRAG_WAIT;
    $option = 0;

    $ret = DefragPart2($ctlr, $loops, $option);

    # delete first vdisk
    # start defrag

    $ret = DefragPart3($ctlr, $option);

    # delete every other disk (ones from the loop)
    # start defrag (for each)

    $ret = DefragPart4($ctlr, $option);

    return GOOD;


}

##############################################################################
#
#          Name: DefragPart4
#
#        Inputs: controller object , option flag
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Deletes every other vdisk (starting w/ 1st unused) and
#                starts defrag on all pdds.
#
##############################################################################
sub DefragPart4
{
    trace();
    my ($ctlr, $option) = @_;


    my @vdisks;
    my $numVDDs;
    my %rsp;
    my $lun;
    my $sid;
    my $ret;
    my $unowned;
    my $i;
    my $firstNew;
    my $j;

    # delete every other unused vdisk
    # start defrag

    logInfo("Defrag test: Part 4, delete every other vdisk, defrag");

    #
    # figure out who has the first vdisk
    #

    # get a list of vdisks (vdisklist)
    @vdisks = GetVdiskList( $ctlr );

    if ( $vdisks[0] == INVALID )
    {
        logError(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }

    $numVDDs = scalar (@vdisks);  # of drives available

    logInfo("Found $numVDDs vdisks");

    # find the first un-owned drive
    $unowned = ERROR;
    $i = 0;
    while ( ($unowned == ERROR) && ( $i < $numVDDs) )
    {

        logInfo("Look to see if vdisk $vdisks[$i] is owned.");

        # get the owner
        %rsp = $ctlr->virtualDiskOwner($vdisks[$i]);
        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskOwner <<<<<<<<");
            return ERROR;
        }
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to retrieve virtualDiskOwner. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        if ( $rsp{NDEVS} == 0 )
        {
            $unowned = GOOD;
            $firstNew = $i;         # firstNew is the array index here
        }

        $i++;

    }

    if ( $unowned == ERROR )
    {
        logError(">>>>>>>> Failed to find an unowned vdisk <<<<<<<<");
        return ERROR;
    }

    # $firstNew points to the unowned vdisk

    #
    # now delete every other disk
    #

    while ( ( $firstNew < $numVDDs) )
    {

        logInfo("Deleting $vdisks[$firstNew]");

        if ( ERROR == DeleteSingleVdisk($ctlr, $vdisks[$firstNew]) )
        {
            return ERROR;
        }



#        #
#        # now start the defrag
#        #
#
#
#        logInfo("Beginning defrag.");
#
#        $ret = DefragBegin($ctlr);
#        if ( $ret == ERROR )
#        {
#            logWarning(">>>>>>>> Failed to start defrag(s). <<<<<<<<");
#            return (ERROR);
#        }


        $firstNew = $firstNew + 2;      # point to next one to delete

    }

    #
    # now start the defrag
    #


    logInfo("Beginning defrag.");

    $ret = DefragAllBegin($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to start defrag(s). <<<<<<<<");
        return (ERROR);
    }


    #
    # Wait for completion
    #

    # This will wait for all the defrags to complete. Either include
    # this call (to be nice to the controller, or skip it. If it
    # is skipped, you will test what happens when we use up all the
    # memory.

    if ( ($option & DEFRAG_WAIT) )
    {
        $ret = TestLibs::BEUtils::DefragWait( $ctlr );
    }


    return GOOD;

}

##############################################################################
#
#          Name: DefragPart3
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Deletes the first vdisk, starts defrag
#
##############################################################################
sub DefragPart3
{
    trace();
    my ($ctlr, $option) = @_;


    my @vdisks;
    my $numVDDs;
    my %rsp;
    my $lun;
    my $sid;
    my $ret;
    my $unowned;
    my $i;
    my $firstNew;

    # delete first vdisk
    # start defrag

    logInfo("Defrag test: Part 3, delete first not-associated vdisk, defrag");

    #
    # figure out who has the first vdisk
    #

    # get a list of disks (vdisklist)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logWarning(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available



    # find the first un-owned drive
    $unowned = ERROR;
    $i = 0;
    while ( ($unowned == ERROR) && ( $i < $numVDDs) )
    {
        # get the owner
        %rsp = $ctlr->virtualDiskOwner($vdisks[$i]);
        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskOwner <<<<<<<<");
            return ERROR;
        }
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to retrieve virtualDiskOwner. <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        if ( $rsp{NDEVS} == 0 )
        {
            $unowned = GOOD;
            $firstNew = $vdisks[$i];
        }

        $i++;

    }

    if ( $unowned == ERROR )
    {
        logWarning(">>>>>>>> Failed to find an unowned vdisk <<<<<<<<");
        return ERROR;
    }

    # $firstNew points to the first unowned vdisk

    #
    # now delete the first disk
    #

    logInfo("Deleting $firstNew");

    if ( ERROR == DeleteSingleVdisk($ctlr, $firstNew) )
    {
        return ERROR;
    }


    #
    # now start the defrag
    #

    $ret = DefragAllBegin($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to start defrag(s). <<<<<<<<");
        return (ERROR);
    }

    #
    # Wait for completion
    #

    # This will wait for all the defrags to complete. Either include
    # this call (to be nice to the controller, or skip it. If it
    # is skipped, you will test what happens when we use up all the
    # memory.

    if ( ($option & DEFRAG_WAIT) )
    {
        $ret = TestLibs::BEUtils::DefragWait( $ctlr );
    }





    return GOOD;
}

##############################################################################
#
#          Name: DefragDebug1
#
#        Inputs: controller object, pdd number
#
#       Outputs: prints sos table
#
#  Globals Used: none
#
#   Description: .
#
##############################################################################
sub DefragDebug1
{
    trace();
    my ($ctlr, $pdd) = @_;

    my %info;


    print "Retrieving SOS Table for disk $pdd.      \r";
    %info = $ctlr->getSos($pdd);
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get response from getSos <<<<<<<<");
        return ERROR;
    }
    if ($info{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> ERROR: Could not retrieve SOS table ($pdd) <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    logSos(%info);

    return GOOD;

    # return
}

##############################################################################
#
#          Name: DefragDebug2
#
#        Inputs: controller object
#
#       Outputs: prints sos table
#
#  Globals Used: none
#
#   Description: .
#
##############################################################################
sub DefragDebug2
{
    trace();
    my ($ctlr, $pdd) = @_;

    my %info;
    my @disks;
    my $i;
    
    @disks = GetDataDisks($ctlr, PD_DT_ALL);
    
    if ( $disks[0] == INVALID )
    {
        return ERROR;
    }

    for ( $i = 0; $i <scalar(@disks); $i++)
    {
        DefragDebug1($ctlr, $disks[$i])
    }

    return GOOD;

    # return

}


##############################################################################
#
#          Name: DefragBegin
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Start defrag on all pdds.
#
##############################################################################
sub DefragBegin
{
    trace();
    my ($ctlr ) = @_;
    my @drives;
    my $i;
    my $numDrives;
    my %rsp;

    #return GOOD;      #  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  bail out early




    #  get a list of physical disks
    @drives = GetDataDisks($ctlr, PD_DT_ALL);
    if ( $drives[0] == INVALID )
    {
        return ERROR;
    }

    $numDrives = scalar(@drives);

    # for each pdd in list
    for ( $i = 0; $i < $numDrives; $i++ )
    {
        # start the defrag
        %rsp = $ctlr->physicalDiskDefrag($drives[$i]);
        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from physicalDiskDefrag <<<<<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            if ( $rsp{ERROR_CODE} !=  0x2d  )   # 0x2d = deactrebuild
            {
                logInfo(">>>>>>>> Unable to start defrag on drive $drives[$i]. <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }
            else
            {
                logInfo("Defrag already running on drive $drives[$i].");
            }
        }
        else
        {
            # display message
            logInfo("Defrag started on drive $drives[$i].");
        }
    }


    #finish up


    return GOOD;

}

##############################################################################
#
#          Name: DefragPart2
#
#        Inputs: controller object, loops
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Create/create/delete/defrag loop for defrag test.
#                This will add 'loops' vdisks to the configuration
#
##############################################################################
sub DefragPart2
{
    trace();
    my ($ctlr, $loops, $option) = @_;
    my @vdisks;
    my $i;
    my $ret;
    my $firstNew;
    my %rsp;
    my $numVDDs;


    logInfo("Defrag test: Part 2, create 2/delete 1/defrag vdisks");


    # for n loops
    for ( $i = 0; $i < $loops; $i ++ )
    {

        # first get a list of existing vdisks
        @vdisks = GetVdiskList( $ctlr );
        if ( $vdisks[0] == INVALID )
        {
            logWarning(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
            return ERROR;
        }
        $numVDDs = scalar (@vdisks);  # of drives available




        #
        # create 2 vdisks
        #

        #
        # The 3rd parameter in MakeVdisks, if 0 will do raid inits on ALL NEW
        # raids each time it is called, Even on drives that are already
        # done. Using 'NO_RAID_INIT' will skip the raid inits. This gives
        # two different test scenarios.
        #


        $ret = MakeVdisks($ctlr, 15, ($option ) );  # option 13 is 2 vdisks
        if ( $ret == ERROR )
        {
            logWarning(">>>>>>>> Failed to create 2 new vdisks <<<<<<<<");
            return (ERROR);
        }

#DefragDebug2($ctlr);

        #
        # delete 1st of the 2 vdisks
        #
        $firstNew = FindFirstNew ( $ctlr, \@vdisks );
        if ( $firstNew == INVALID )
        {
            logWarning(">>>>>>>> Unable to determine first new vdisk. <<<<<<<<");
            return ERROR;
        }

        logInfo("Deleting $firstNew");

        if ( ERROR == DeleteSingleVdisk($ctlr, $firstNew) )
        {
            return ERROR;
        }




#DefragDebug2($ctlr);
        #
        # start defrag
        #

        DispPdiskInfo($ctlr);            # shows current state

        GPDeviceStatus($ctlr);           # for Jeff's debug

        $ret = DefragAllBegin($ctlr);
        if ( $ret == ERROR )
        {
            GPDeviceStatus($ctlr);        # also for debug
            logWarning(">>>>>>>> Failed to start defrags. <<<<<<<<");
            return (ERROR);
        }

        #
        # Wait for completion
        #

        # This will wait for all the defrags to complete. Either include
        # this call (to be nice to the controller, or skip it. If it
        # is skipped, you will test what happens when we use up all the
        # memory.

        if ( ($option & DEFRAG_WAIT) )
        {
            $ret = TestLibs::BEUtils::DefragWait( $ctlr );
        }

    #print " enter a character ";
    #my $ans = <STDIN>;



    }

    return GOOD;
}

##############################################################################
#
#          Name: FindFirstNew
#
#        Inputs: controller object, vdisklist list
#
#       Outputs: VDD of first new vdisk if successful, INVALID otherwise
#
#  Globals Used: none
#
#   Description: Gets a list of vdisks, returns first one that is not
#                in the supplied list.
#
##############################################################################
sub FindFirstNew
{
    trace();

    my ( $ctlr, $listPtr ) = @_;

    my @oldList;
    my @newList;
    my $numOld;
    my $numVDDs;
    my $i;
    my $j;
    my $match;

    debug(" in find first new with $ctlr, $listPtr ");

    @oldList = @$listPtr;

    $numOld = scalar(@oldList);

    # first get a list of existing vdisks
    @newList = GetVdiskList( $ctlr );
    if ( $newList[0] == INVALID )
    {
        logWarning(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@newList);  # of drives available

    #
    # compare the lists
    #

    for ( $i = 0; $i < $numVDDs; $i++ )
    {
        # compare each one in the new list
        $match = ERROR;
        for ( $j = 0; $j < $numOld; $j++ )
        {
            # compare to each one in the old list
            if ( $oldList[$j] == $newList[$i] )
            {
                $match = GOOD;   # if they match, indicate it,
                                 # as we can't use this one
            }
        }

        if ( $match == ERROR )
        {
            # the new one wasn't in the old list. we want this one.
            return $newList[$i];
        }

    }

    # if here, they all matched, or one of the lists was empty
    return INVALID;
}

##############################################################################
#
#          Name: DefragPart1
#
#        Inputs: controller object, option, server wwn list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Creates starting configuration for defrag test.
#                Option is 1 for 1 way system, 2 for 2 way system.
#                Default is  1 way.
#
##############################################################################
sub DefragPart1
{
    trace();
    my ($ctlr, $option, $wwnPtr) = @_;

    my $ret;
    my %rsp;
    my @vdisks;
    my $numVDDs;
    my $lun;
    my $sid;


    logInfo("Defrag test: Part 1, create initial vdisks");

    #
    # validate option
    #


    if ( ! $option )     # if not defined
    {
        $option = 1;
    }
    if ( ($option < 0) || ($option > 2) )  # out of range check
    {
        $option = 1;
    }

    #
    # we start from scratch,
    # label the drives
    #
    $ret = LabelAllDrives($ctlr, 11, 2, 1, 0, 0 );     # for 14 drive bays

    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to label the drives <<<<<<<<");
        return (ERROR);
    }


    #
    # create 3 vdisks
    #
    $ret = MakeVdisks($ctlr, 12, 0 );     # option 12 is 3 vdisks
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to create 3 new vdisks <<<<<<<<");
        return (ERROR);
    }

    #
    # associate 2nd and 3rd to servers so IO can be done
    # We're going to assoca all and then disassociate the first one
    #
    $ret = AssociateServers($ctlr, 2, $wwnPtr );
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to associate drives to servers <<<<<<<<");
        return (ERROR);
    }

    #
    # figure out who has the first vdisk
    #

    # find the first vdisk (vdisklist)
    @vdisks = GetVdiskList( $ctlr );
    if ( $vdisks[0] == INVALID )
    {
        logWarning(">>>>>>>> Unable to retrieve list of virtual disk identifiers. <<<<<<<<");
        return ERROR;
    }
    $numVDDs = scalar (@vdisks);  # of drives available




    # get the owner
    %rsp = $ctlr->virtualDiskOwner($vdisks[0]);
    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from virtualDiskOwner <<<<<<<<");
        return ERROR;
    }
    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve virtualDiskOwner. <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    if ( $rsp{NDEVS} > 0 )
    {
        $lun = $rsp{OWNERS}[0]{LUN};
        $sid = $rsp{OWNERS}[0]{SID};

        #
        # got the info, now disassoc it
        #
        $ret = DisassocOne( $ctlr, $sid, $lun, $vdisks[0]);
        if ( $ret == ERROR )
        {
            return ERROR;
        }
    }

    #####################
    # show what is there
    #####################

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }

    $ret = DispVdisksRaids($ctlr);
    if ( $ret == ERROR )
    {
        logWarning(">>>>>>>> Failed to display vdisks and raids <<<<<<<<");
        return (ERROR);
    }




    return GOOD;


}


##############################################################################
#
#          Name: GetPowerUpState
#
#        Inputs: Controller object
#
#       Outputs: state, or INVALID on error
#
#  Globals Used: none
#
#   Description: Gets power up state, this is somewhat bitmapped.
#                Caller should check against INVALID before testing
#                the bits.
#
##############################################################################
sub GetPowerUpState
{
    trace();
    my ($ctlr) = @_;
    my %rsp;
    my $msg;

    %rsp = $ctlr->powerUpState();

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from powerUpState <<<<<<<<");
        return INVALID;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to retrieve Power Up State. <<<<<<<<");
        PrintError(%rsp);
        return INVALID;
    }

    $msg = "Power-up State ($ctlr->{HOST}): ";
    $msg .= XIOTech::cmdMgr::_getString_POWERUP($rsp{STATE});

    logInfo($msg );

    return $rsp{STATE};
}

##############################################################################
#
#          Name: GetMyLicense
#
#        Inputs: controller object, ip addr, option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Checks  controller for a license, if none will
#                give it a license for itself.
#
#
##############################################################################
sub GetMyLicense
{
    trace();
    my ( $ctlr, $ipAddr, $option) = @_;

    my $i;
    my $state;
    my @coList;
    my @ipList;
    my @serialNums;
    my $sn;
    my @ipParts;
    my %rsp;

    $state = GetPowerUpState ($ctlr );

    if ($state == POWER_UP_COMPLETE )
    {
        # controller has a license, good enough for us
        return GOOD;
    }
    else
    {
        # master is without a license. Need to get ALL serial numbers
        # and put them into an array, Then apply the license.

        # get the serial number

     #   $sn = GetSerial( $ctlr );
     #   if ( $sn == INVALID )
     #   {
     #       return ERROR;
     #   }
     #
     #   # add to array
     #
     #   push ( @serialNums, $sn );


        # now get the group name. If we have an IP address, use it for
        # the group name. If no IP address, we just use the serial
        # number for the controller.

        if ( !$ipAddr )
        {
            # need to fake a serial number
            # get it from the ip adder in the object
            $ipAddr = $ctlr->{HOST}
        }

        if ($ipAddr)
        {
            @ipParts = split( /\./, $ipAddr);

            logInfo("The server SNs: @serialNums");
            logInfo("The ip addr ($ipAddr) parts: @ipParts");

            # now the fcn call

            $sn =  $ipParts[3];

        }


        logInfo("Using group SN: $sn");

        %rsp = $ctlr->vcgApplyLicense( $sn, 1);

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from vcgApplyLicense <<<<<<<<");
            return INVALID;
        }
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to apply License. <<<<<<<<");
            PrintError(%rsp);
            return INVALID;
        }


    }
    return GOOD;

}


##############################################################################
#
#          Name: GimmieLicense
#
#        Inputs: ptr to controller object list
#                ptr to ip addr list
#                option - 0 = License for max controllers in controller list
#                         1 = License for 1 controller
#                         2 = License for 2 controllers, etc.
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Checks first controller for a license, if none will
#                give it a license for all controllers in the list. (First
#                one is the master, rest are slaves.)
#
#
##############################################################################
sub GimmieLicense
{
    trace();
    my ( $coPtr, $ipPtr, $option) = @_;

    my $i;
    my $state;
    my @coList;
    my @ipList;
    my $obj;
    my @serialNums;
    my $sn;
    my @ipParts;
    my %rsp;

    @coList = @$coPtr;
    @ipList = @$ipPtr;

    $state = GetPowerUpState ($coList[0] );

    if (! defined($option))
    {
        $option = 0;
    }

    if (($state == POWER_UP_COMPLETE ) && ($option == 0))
    {
        # master has a license, good enough for us
        return GOOD;
    }
    else
    {
        # master is without a license. Need to get ALL serial numbers
        # and put them into an array, Then apply the license.

      #  for ( $i = 0; $i < scalar(@coList); $i++ )
      #  {
      #      # get the serial number
      #
      #      $sn = GetSerial( $coList[$i] );
      #      if ( $sn == INVALID )
      #      {
      #          return ERROR;
      #      }
      #
      #      # add to array
      #
      #      push ( @serialNums, $sn );
      #
      #  }

        # now get the group name

        #    @Select_Server_ID = split(/ /, $Server_IDs);

        @ipParts = split( /\./, $ipList[0]);

        logInfo("The server SNs: @serialNums");
        # logInfo("The ip addr ($ipList[0]) parts: @ipParts");

        $sn =  $ipParts[3];        # save master ip part

        if ( $ipList[1] )
        {
            @ipParts = split( /\./, $ipList[1]);

            #logInfo("The server SNs: @serialNums");
            #logInfo("The ip addr ($ipList[1]) parts: @ipParts");

            $sn =  $sn * 1000 + $ipParts[3];  # add slave ip part
        }

        # now the fcn call

        $obj = $coList[0];


        logInfo("Using group SN: $sn");


        # 
        # Work around for Wookiee defect # 11197
        #
        if ( $obj->{CONTROLLER_TYPE} != CTRL_TYPE_BIGFOOT )
        {
            logInfo(">>>>>> GIMMELICENSE - WOOKIEE WORKAROUND - Delaying 5 sec before applying license <<<<<<");
            sleep 5;    
        }

        # Apply license based on option input
        if ($option == 0)
        {
            %rsp = $obj->vcgApplyLicense( $sn, scalar(@coList) );
        }
        else
        {
            %rsp = $obj->vcgApplyLicense( $sn, $option );
        }
     #   %rsp = $obj->vcgApplyLicense( $sn, 8 );

        if ( ! %rsp  )
        {
            logInfo(">>>>>>>> Failed to get response from vcgApplyLicense <<<<<<<<");
            return INVALID;
        }
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Unable to apply License. <<<<<<<<");
            PrintError(%rsp);
            return INVALID;
        }


    }
    return GOOD;

}




##############################################################################
#
#          Name: ViewLicenseState
#
#        Inputs: Controller object list
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Gets poweronstate and vcginfo on all controllers
#
#
##############################################################################
sub ViewLicenseState
{
    trace();

    my ( $coPtr ) = @_;

    my $ret;
    my $i;
    my @coList;
    my $ctlr;
    my %rsp;

    @coList = @$coPtr;

    for ( $i = 0; $i < scalar(@coList); $i++ )
    {
        logInfo("Viewing License information for controller $i");

        #####################
        #  Firmware Version
        #####################
        #logInfo("");
        debug("Testing firmware version operations... ");
        $ctlr = $coList[$i];

        %rsp = $ctlr->fwVersion();
        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from fwVersion <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from fwVersion <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        logFirmwareVersion(%rsp);

        logInfo("Completed testing firmware version operations");

        # get the powerupstate

        $ret = GetPowerUpState($coList[$i]);

        # do VCGInfo

        $ret = DispVcgInfo($coList[$i] );

        #
    }

    return GOOD;

}
##############################################################################
##############################################################################
##############################################################################
#
#          Name: RebootControllers
#
#        Inputs: list of controlleres, initial delay (seconds)
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Causes each contoller to be reboot, wiats <initial delay>
#                seconds then trys to reconnect to each controller.
#
#
#
##############################################################################
sub RebootControllers
{
    trace();
    my ($coPtr, $delay) = @_;

    my $obj;
    my %rsp;
    my $host;
    my $port;
    my $rc;
    my $numObjs;
    my $i;
    my $ret;
    my $j;


    if ( !$delay )
    {
        $delay = 60;       # default delay is 60 secs.
    }

    # build needed arrays


    my @coList = @$coPtr;

    $numObjs = scalar(@coList);


    #
    # launch all resets
    #


    for ( $i = 0; $i<$numObjs; $i++ )
    {
        $ret = resetAll( $coList[$i] );

    }


    #
    # reconnect all
    #

    # Sleep for 60 second(s) before attempting to reconnect.

    logInfo("Sleeping for $delay seconds to allow controller(s) to reset");
    sleep($delay);


    for ( $i = 0; $i < $numObjs; $i++ )
    {

        $obj = $coList[$i];

        $obj->logout();


        $host = $obj->{HOST};
        $port = $obj->{PORT};
        $j = 1;
        $rc = 0;

        while ($rc == 0)
        {
            # Sleep for 5 second(s) before attempting to connect.
            sleep(5);

            print "On controller $i, connection attempt # $j \r";
            # Attempt to reconnect the socket
            $rc = $obj->login($host, $port);
            $j++;

            # set a timeoput for this in case a controller is too dead
            # to reconnect.
            if ( $j > 48 )
            {
                # didn't recover in 4 or 5 minutes, got a dead one
                logWarning(">>>>>>>> Failed to reconnect to controller $i \n <<<<<<<<");
                return ERROR;
            }
        }
    }



    #
    # set all timeouts to 600 sec
    #

    logInfo("Setting timeouts back to 600 sec");

    for ( $i = 0; $i<$numObjs; $i++ )
    {
        $obj = $coList[$i];
        $obj->{TIMEOUT} = CCBETIMEOUT;
    }


    # we are done

    # do something to indicate success for now

    $ret = ViewLicenseState( $coPtr );



    return GOOD;
}

##############################################################################
#
#          Name: resetAll
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Reset all processors on a controller
#
#
##############################################################################
sub resetAll
{
    trace();
    my ($ctlr) = @_;
    my $oldTimeout = $ctlr->{TIMEOUT};

    logInfo("Rebooting controller $ctlr->{HOST}");

    $ctlr->{TIMEOUT} = 10;

    my @arr;
    push @arr, 3;
    push @arr, 0;

    my %rsp = $ctlr->genericCommand("RESET", @arr);

    $ctlr->{TIMEOUT} = $oldTimeout;

    if (!%rsp)                        # no response
    {
        logInfo("Reboot successfully initiated");
        return GOOD;
    }
    elsif ($rsp{STATUS} == PI_SOCKET_ERROR)
    {
        logInfo("Reboot successfully initiated");
        return GOOD;
    }
    else
    {
        logInfo(">>>>>>>> Error rebooting controller <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }
    logInfo("Done.");
    return GOOD;


}


##############################################################################
#
#          Name: GPCase1TwoWay
#
#        Inputs: controller object, server wwn list ptr
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: A bunch of tests that can be run on a controller. No
#                host IO can run as this will delete/modify any existing
#                configuration.
#
#
##############################################################################
sub GPCase1TwoWay
{
    trace();

    my ($coPtr, $wwnList) = @_;

    my $ctlr;
    my $ctlr2;


    my $ret;
    my $i;
    my $numCtlrs;
    my $loops1;
    my $loops2;

    my @coList;
    my @ipList;

    @coList = @$coPtr;
    $ctlr = $coList[0];

    $loops1 = 1;
    $loops2 = 2;
    $numCtlrs = scalar(@coList);

    # build the ipList as we need it later
    for ( $i = 0; $i < $numCtlrs; $i++ )
    {

        $ipList[$i] = $coList[$i]->{HOST};
    }

    logInfo("Good Path Case 1 test: two way system (no IO)");

    if ( $numCtlrs < 2 )
    {
        logError(">>>>>>>> Need at least 2 controllers for this test <<<<<<<<");
        return (ERROR);
    }

    #####################
    # show what is there
    #####################

    logInfo("Starting configuration for controllers");

    for ( $i = 0; $i < $numCtlrs; $i++ )
    {


        $ret = ConfigView ( $coList[$i], 0, 0 );
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to display current configuration <<<<<<<<");
            return (ERROR);
        }
    }

    #########################################
    # clean up anything from previous tests
    #########################################

    $ret = DisassocAll ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to disassociate all servers <<<<<<<<");
        return (ERROR);
    }

    $ret = DeleteAllVdisks2 ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to delete all vdisks <<<<<<<<");
        return (ERROR);
    }

    $ret = LabelSingleDrive ( $ctlr, 0xffff, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to unlabel all drives <<<<<<<<");
        return (ERROR);
    }

    for ( $i = 0; $i < $numCtlrs; $i++ )
    {
        #  trash BE NVRAM
        logInfo("Corrupt BE NVRAM $i");
        $ret = CorruptBENvram( $coList[$i] );
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to corrupt BE NVRAM <<<<<<<<");
            return (ERROR);
        }

    }

    $ret = RebootControllers ( $coPtr, 60 );

    # this also does a reconnect

    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to reboot all controllers <<<<<<<<");
        return (ERROR);
    }

    # since we blew away the licenses for the controllers, need
    # to put one back
    GimmieLicense($coPtr, \@ipList, 0);

    ###################################################################
    # Now we have a clean system to test
    ###################################################################

    #########################################
    # Do some two way system stuff
    #########################################

    for ( $i = 0; $i < $loops1; $i++ )
    {

        ################################
        # configure a 2 way loops1 times
        ################################
        $ret = GPReal2Way($coPtr, $wwnList, 4);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failure creating 2 way configuration <<<<<<<<");
            return (ERROR);
        }
    }



    #########################################
    ####### Elections test (should have 2 way system) ######
    #########################################
    $ret = ElectionsTest($ctlr, $coList[1], 50);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed in the elections test <<<<<<<<");
        return (ERROR);
    }

    return GOOD;
}


##############################################################################
#
#          Name: GPCase1
#
#        Inputs: controller object, server wwn list ptr
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: A bunch of tests that can be run on a controller. No
#                host IO can run as this will delete/modify any existing
#                configuration.
#
#
##############################################################################
sub GPCase1
{
    trace();

    my ($coPtr, $wwnList) = @_;

    my $ctlr;
    my $ctlr2;

    my @coList;

    @coList = @$coPtr;

    $ctlr  = $coList[0];
    $ctlr2 = $coList[1];


    my $ret;
    my $i;
    my $loops1;
    my $loops2;


    $loops1 = 10;
    $loops2 = 2;

    logInfo("Good Path Case 1 test (no IO)");



    #####################
    # show what is there
    #####################

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }


    #########################################
    # clean up anything from previous tests
    #########################################

    $ret = DisassocAll ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to disassociate all servers <<<<<<<<");
        return (ERROR);
    }

    $ret = DeleteAllVdisks2 ( $ctlr, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to delete all vdisks <<<<<<<<");
        return (ERROR);
    }

    $ret = LabelSingleDrive ( $ctlr, 0xffff, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to unlabel all drives <<<<<<<<");
        return (ERROR);
    }

    #########################################
    # basic gp stuff
    #########################################

    $ret = GPModes($ctlr);      # first, as it turns off no suicide bit
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path mode bits test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDeviceStatus($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path device status test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPResetTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path QL reset test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPMiscCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path misc. Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDiskBayCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Disk Bay Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPPhysicalDiskCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Physical Disk test <<<<<<<<");
        return (ERROR);
    }

    # call the no raid 5 version
    $ret = GPVirtualDiskCommands2($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Virtual Disk [case 1] test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPRaidCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Raid Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPTargetCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Target Commands test <<<<<<<<");
        return (ERROR);
    }


    $ret = GPServerCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Server Commands test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPFidRead($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path FID read test <<<<<<<<");
        return (ERROR);
    }

    # no caching in Case 1
#    $ret = GPCaching($ctlr);
#    if ( $ret == ERROR )
#    {
#        logError(">>>>>>>> Failure in good path caching test <<<<<<<<");
#        return (ERROR);
#    }

    $ret = GPDeviceStatus($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path device status test <<<<<<<<");
        return (ERROR);
    }

#    $ret = GPReal1Way($ctlr, $wwnList, 2);       # may fail for missing SIDs
#    if ( $ret == ERROR )
#    {
#        logError(">>>>>>>> Failure in good path 1 way config test <<<<<<<<");
#        return (ERROR);
#    }

    $ret = GPStatsCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Stats test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPLoggingTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Logging test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPMemoryLeakTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path memory leak test <<<<<<<<");
        return (ERROR);
    }

    #########################################
    # Do some one way system stuff
    #########################################

    for ( $i = 0; $i < $loops1; $i++ )
    {

        ################################
        # configure a 1 way loops1 times
        ################################
        $ret = GPReal1Way($ctlr, $wwnList, 4);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failure creating 1 way configuration <<<<<<<<");
            return (ERROR);
        }
    }

    #########################################
    # vdisk creation and deletion
    #########################################
    for ( $i = 0; $i < $loops2; $i++ )
    {

        ################################
        # create/expand/delete vdisks
        ################################

        $ret = GPCreateExpandDelete2($ctlr);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failure in create/expand/init/delete vdisk test <<<<<<<<");
            return (ERROR);
        }
    }

    #########################################
    ####### Re-label PDDs test ######
    #########################################
    # re-label PDD test, usually done while IO is running
    $ret = ReLabelPD($ctlr, 10);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed while re-labeling PDDs <<<<<<<<");
        return (ERROR);
    }

    #########################################
    ####### Defrag test (part 2 only) ######
    #########################################
#    $ret = DefragPart2($ctlr, 10, ( DEFRAG_WAIT + NO_RAID_INIT ) );
#    #$ret = DefragPart2($ctlr, 2, 0 );
#    if ( $ret == ERROR )
#    {
#        logError(">>>>>>>> Failed in defrag<<<<<<<<");
#        return (ERROR);
#    }
#


    #########################################
    ####### Make it a 2 way system (later a loop) ######
    #########################################

    # don't try 2 way as the connection has timed out long ago
    # may need to add pings to fix that

#    $ret = GPReal2Way($coPtr, $wwnList, 4);
#    if ( $ret == ERROR )
#    {
#        logError(">>>>>>>> Failed while making 2 way <<<<<<<<");
#        return (ERROR);
#    }




    #########################################
    ####### Elections test (works better on a 2 way system) ######
    #########################################
    $ret = ElectionsTest($ctlr, 0, 50);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed in the elections test <<<<<<<<");
        return (ERROR);
    }


    #########################################
    ####### Fail PDDs test ######
    #########################################
    # fail and rebuild PDD test
    $ret = FailDrivesTest($ctlr, 5, 0);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed while failing and rebuilding PDDs <<<<<<<<");
        return (ERROR);
    }





    #########################################
    # basic gp stuff
    #########################################


    $ret = GPMemoryLeakTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path memory leak test <<<<<<<<");
        return (ERROR);
    }


    #####################
    # show what is there
    #####################

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }


    return GOOD;

}



##############################################################################
#
#          Name: GPCase1IO
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: A bunch of tests that can be done while IO is
#                running on existing vdisks. Assumes a 1 way system.
#
#
##############################################################################
sub GPCase1IO
{
    trace();
    my ($coPtr, $wwnList) = @_;


    my $ret;
    my $i;
    my $loops1;
    my $loops2;


    $loops1 = 3;
    $loops2 = 2;

    my $ctlr;
    my $ctlr2;

    my @coList;

    @coList = @$coPtr;

    $ctlr  = $coList[0];
    $ctlr2 = $coList[1];



    logInfo("Good Path Case 1 with host IO");

    #####################
    # show what is there
    #####################

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }



    #########################################
    # basic gp stuff
    #########################################

    $ret = GPModes($ctlr);      # first, as it turns off no suicide bit
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path mode bits test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDeviceStatus($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path device status test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPResetTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path QL reset test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPMiscCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path misc. Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPDiskBayCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Disk Bay Commands test <<<<<<<<");
        return (ERROR);
    }

  # can't run this one, it relabels pdisks
  #  $ret = GPPhysicalDiskCommands($ctlr);
  #  if ( $ret == ERROR )
  #  {
  #      logError(">>>>>>>> Failure in good path Physical Disk test <<<<<<<<");
  #      return (ERROR);
  #  }

    # call the limited version
    $ret = GPVdiskMisc($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Virtual Disk misc. test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPRaidCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Raid Commands test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPTargetCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Target Commands test <<<<<<<<");
        return (ERROR);
    }


    $ret = GPServerCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Server Commands test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPFidRead($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path FID read test <<<<<<<<");
        return (ERROR);
    }

    # no caching in Case 1
#    $ret = GPCaching($ctlr);
#    if ( $ret == ERROR )
#    {
#        logError(">>>>>>>> Failure in good path caching test <<<<<<<<");
#        return (ERROR);
#    }

    $ret = GPDeviceStatus($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path device status test <<<<<<<<");
        return (ERROR);
    }


    $ret = GPStatsCommands($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Stats test <<<<<<<<");
        return (ERROR);
    }

    $ret = GPLoggingTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path Logging test  <<<<<<<<");
        return (ERROR);
    }

    $ret = GPMemoryLeakTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path memory leak test <<<<<<<<");
        return (ERROR);
    }


    #########################################
    # vdisk creation and deletion
    #########################################
    for ( $i = 0; $i < $loops2; $i++ )
    {

        ################################
        # create/expand/delete vdisks
        ################################

        $ret = GPCreateExpandDelete2($ctlr);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failure in create/expand/init/delete vdisk test <<<<<<<<");
            return (ERROR);
        }
    }

    #########################################
    ####### Re-label PDDs test ######
    #########################################
    # re-label PDD test, usually done while IO is running
    $ret = ReLabelPD($ctlr, 10);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed while re-labeling PDDs <<<<<<<<");
        return (ERROR);
    }

    #########################################
    ####### Defrag test (part 2 only) ######
    #########################################
    $ret = DefragPart2($ctlr, 10, ( DEFRAG_WAIT + NO_RAID_INIT ) );
    #$ret = DefragPart2($ctlr, 2, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed in defrag<<<<<<<<");
        return (ERROR);
    }


    #########################################
    ####### Elections test (should have 2 way system) ######
    #########################################
    $ret = ElectionsTest($ctlr, $ctlr2, 50);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed in the elections test <<<<<<<<");
        return (ERROR);
    }


    #########################################
    ####### Fail PDDs test ######
    #########################################
    # fail and rebuild PDD test
    $ret = FailDrivesTest($ctlr, 5, 0);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed while failing and rebuilding PDDs <<<<<<<<");
        return (ERROR);
    }





    #########################################
    # basic gp stuff
    #########################################


    $ret = GPMemoryLeakTest($ctlr);
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failure in good path memory leak test <<<<<<<<");
        return (ERROR);
    }


    #####################
    # show what is there
    #####################

    $ret = ConfigView ( $ctlr, 0, 0 );
    if ( $ret == ERROR )
    {
        logError(">>>>>>>> Failed to display current configuration <<<<<<<<");
        return (ERROR);
    }
    return GOOD;
}
##############################################################################
#
#          Name: BEETLoop
#
#        Inputs: controller list pointer, moxa information
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Loop that tests failover for back end error traps
#                Uses the moxa to cycle power
#
#
##############################################################################
sub BEETLoop
{
    trace();
    my ($coPtr) = @_;

    my $loop1;
    my $i;
    my $initMaster;
    my $initMasterSN;
    my $newMaster;
    my $slaveSN;
    my $masterSN;
    my $numCtlrs;
    my $j;
    my $chn;
    my $ret;
    my $failCount;
    my $temp;

    my @coList;

    @coList = @$coPtr;

    $numCtlrs = scalar( @coList );

    $failCount = 0;

    $loop1 = 2000;

    # loop
    for ( $i = 0; $i < $loop1; $i++ )
    {

        # find the master,
        logInfo("Searching for the master controller in the group [$failCount failovers completed]");
        $initMaster = FindMaster( $coPtr );

        # for each slave ( actually, each non-master )
        for ( $j = 0; $j < $numCtlrs; $j++ )
        {
            if ( $j != $initMaster )
            {
                # get slave SN
                $slaveSN = GetSerial( $coList[$j] );

                # fail the slave
                logInfo("Failing a controller");
                $failCount++;
                $ret = ErrorTrapController($coList[$j], "BE");
                if ( $ret == ERROR )
                {
                    logWarning(">>>>>>>> Failed to error trap the controller [$failCount failovers completed]  <<<<<<<<");
                    return ERROR;
                }


                logInfo("Pause for 60 seconds");
                sleep(60);

                DispVcgInfo($coList[$initMaster]);

                # power cycle the slave
                logInfo("Power Cycle the dead controller");
                if ( $j == 1 )
                {
                    $chn = "E";
                }
                else
                {
                    $chn = "F";
                }
                $ret = PowerCycle("10.64.99.60", $chn);
                if ( $ret == ERROR )
                {
                    logWarning(">>>>>>>> Failed to power cycle the controller [$failCount failovers completed]  <<<<<<<<");
                    return ERROR;
                }

                # need to reconnect to the controller
                logInfo("Pause for 60 seconds and reconnect");
                $ret = Reconnect( $coList[$j], 60 );
                if ( $ret == ERROR )
                {
                    logWarning(">>>>>>>> Failed to reconnect to the controller [$failCount failovers completed]   <<<<<<<<");
                    return ERROR;
                }

                # find the master, if it changed
                logInfo("Searching for the master controller in the group");
                $newMaster = FindMaster( $coPtr );
                if ( $newMaster == INVALID )
                {
                    logWarning(">>>>>>>> Failed to find the master controller [$failCount failovers completed]  <<<<<<<<");
                    return ERROR;
                }

                # unfail the slave
                logInfo("Unfailing the controller");
                $ret = UnFailController( $coList[$newMaster], $slaveSN );
                if (  $ret == ERROR )
                {
                    logWarning(">>>>>>>> Failed to restore the controller to active duty [$failCount failovers completed]  <<<<<<<<");
                    return ERROR;
                }

            }

            DispVcgInfo($coList[$initMaster]);

        }

        DispVcgInfo($coList[$initMaster]);


        # get master SN
        $masterSN = GetSerial( $coList[$initMaster] );


        # fail the Master
        logInfo("Failing a controller");
        $failCount++;
        $ret = ErrorTrapController($coList[$initMaster], "BE");
        if ( $ret == ERROR )
        {
            logWarning(">>>>>>>> Failed to error trap the controller [$failCount failovers completed]  <<<<<<<<");
            return ERROR;
        }

        logInfo("Pause for 60 seconds");
        sleep (60);


        $temp = 0;
        if ( $initMaster == 0 )
        {
            $temp = 1;
        }
        # do this on something other than what we just failed
        DispVcgInfo($coList[$temp]);


        # power cycle the master
        logInfo("Power Cycle the dead controller");
        if ( $initMaster == 1 )
        {
            $chn = "E";
        }
        else
        {
            $chn = "F";
        }
        $ret = PowerCycle("10.64.99.60", $chn);
        if ( $ret == ERROR )
        {
            logWarning(">>>>>>>> Failed to power cycle the controller  [$failCount failovers completed] <<<<<<<<");
            return ERROR;
        }

        # need to reconnect to the controller
        logInfo("Pause for 60 seconds and reconnect");
        $ret = Reconnect( $coList[$initMaster], 60 );
        if ( $ret == ERROR )
        {
            logWarning(">>>>>>>> Failed to reconnect to the controller  [$failCount failovers completed] <<<<<<<<");
            return ERROR;
        }

        # find the master, if it changed
        logInfo("Searching for the master controller in the group");
        $newMaster = FindMaster( $coPtr );
        if ( $ret == ERROR )
        {
            logWarning(">>>>>>>> Failed to find the new master controller  [$failCount failovers completed] <<<<<<<<");
            return ERROR;
        }

        # unfail the (old) master
        logInfo("Unfailing the controller");
        $ret = UnFailController( $coList[$newMaster], $masterSN );
        if ( $ret == ERROR )
        {
            logWarning(">>>>>>>> Failed to make the controller useable [$failCount failovers completed]  <<<<<<<<");
            return ERROR;
        }


        DispVcgInfo($coList[$newMaster]);


        logInfo("Loop $i completed, $failCount failovers completed.");
    }
    # end loop

    logInfo("End of BE-ET test, $failCount failovers completed.");
    return GOOD;

}



##############################################################################
#
#          Name: ErrorTrapController
#
#        Inputs: controller object, what/which to ET
#                     what is one of CCB, FE, BE, or ALL
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Causes an error trap on the specified controller
#
#
##############################################################################
sub ErrorTrapController
{
    trace();

    my ($ctlr, $type) = @_;

    my @parmArray;
    my $cmd;
    my %rsp;
    my @littleArray;

    push (@littleArray, $ctlr);

    if (uc($type) eq "CCB")
    {
        $cmd = $ctlr->PI_GENERIC_ERROR_TRAP_CCB;
    }
    elsif (uc($type) eq "FE")
    {
        $cmd = $ctlr->PI_GENERIC_ERROR_TRAP_FE;
    }
    elsif (uc($type) eq "BE")
    {
        $cmd = $ctlr->PI_GENERIC_ERROR_TRAP_BE;
    }
    elsif (uc($type) eq "ALL")
    {
        $cmd = $ctlr->PI_GENERIC_ERROR_TRAP_ALL;
    }
    else
    {
        $cmd = $ctlr->PI_GENERIC_ERROR_TRAP_BE;
    }

    push @parmArray, $cmd;

    if (uc($type) eq "CCB")
    {

        # allow this one controller to suicide
        SuicideOK(\@littleArray);

        # we just handle aas a timeout as the CCB won't return
        $ctlr->{TIMEOUT} = 10;
    }

    %rsp = $ctlr->genericCommand("ERROR_TRAP", @parmArray);

    if (%rsp)
    {
        if ($rsp{STATUS} != PI_GOOD)
        {
            if ( (uc($type) eq "CCB")  && ($rsp{STATUS} == 6))
            {
                # the new way CCBET responds...
                $ctlr->{TIMEOUT} = CCBETIMEOUT;
                return GOOD;
            }
            else
            {
                logInfo(">>>>>>>> Failed to error trap $type <<<<<<<<");
                PrintError( %rsp);
                return ERROR;
            }
        }
    }
    else
    {
        if (uc($type) eq "CCB")
        {
            # we should be timing out on this one
            $ctlr->{TIMEOUT} = CCBETIMEOUT;
            return GOOD;
        }
        else
        {
            logInfo(">>>>>>>> ERROR: Did not receive a response packet. <<<<<<<<");
            return ERROR;
        }
    }



    return GOOD;

}
##############################################################################
#
#          Name: FindMaster
#
#        Inputs: controller object list
#
#       Outputs: index for master, if successful, INVALID otherwise
#
#  Globals Used: none
#
#   Description: Finds the first controller in the supplied list that
#                is a master and has more than a single license.
#
#
##############################################################################
sub FindMaster
{
    trace();
    my ($coPtr) = @_;

    my $ctlr;
    my $i;
    my $j;
    my $k;
    my $numCtlrs;
    my $ourMaster;
    my $tempMaster;
    my $multipleMasters;
    my %info;
    my %rsp;
    my $msg;
    my $powerUpState;
    my @coSNs;
    my $electionInProgress;
    my $waitCount;
    my @coList;
    my $ret;
    my $retry;
    my $oldTimeout;

    @coList = @$coPtr;

    $numCtlrs = scalar(@coList);

    logInfo("FindMaster:  Looking for the master controller, some errors may be seen.");
    logInfo("FindMaster:  These are considered OK as we may be looking at failed controllers.");

    # Note: in the loops that follow, we are looking at this as an 'n' way
    # configuration where one of the controllers may be dead. Therefore
    # we will tolerate failed commands without aborting. However, if we
    # fail to find the controller we are looking for, we will return INVALID


    $retry = 0;
    MAIN:
    {
        $tempMaster = INVALID;
        $ourMaster = INVALID;
        $multipleMasters = 0;
    
        #
        # Build an array indicating which controllers are alive and responding
        # and which are not.  If a controller is good, put it's serial number
        # in the array.  Otherwise, set it's correspoinding entry to INVALID.
        #
        for ( $i = 0; $i < $numCtlrs; $i++ )
        {
            $ctlr = $coList[$i];
        
            #
            # If the controller object is 0, then this one is not valid. 
            #
            if ( !$ctlr )
            {
                $coSNs[$i] = INVALID;
                next;
            }

            #
            # If this object was never connected, skip it
            #
            if ( !$ctlr->{"socket"} )
            {
                $coSNs[$i] = INVALID;
                next;
            }

            # 
            # Shorten the timeout.  Attempt to communicate with the controller
            # to get the serial number.  If we can't get it because the
            # controller is dead or has other problems, the function  
            # returns INVALID.
            #
            $oldTimeout = $ctlr->{TIMEOUT};
            $ctlr->{TIMEOUT} = 5;
            $coSNs[$i] = GetSerial( $ctlr );
            $ctlr->{TIMEOUT} = $oldTimeout;
        }

        #
        # Return to here if any error occurs.  Some of the errors could be due 
        # to timeouts which are long enough that an election could have occurred
        # or is in progress and the master may change.  So we need to restart 
        # from the beginning.
        #
        ELECTION:
        {
            #
            # Check to see if an election if in progress.  If it is, wait until 
            # it is complete.
            #
            $waitCount = 0;
            do
            {
                $electionInProgress = FALSE;
                for ( $i = 0; $i < $numCtlrs; $i++ )
                {
                    if ( $coSNs[$i] != INVALID )
                    {
                        $ctlr = $coList[$i];
                        %rsp = $ctlr->vcgElectionState();

                        if ( !%rsp )                        # no response
                        {
                            logInfo(">>>>>>>> No response from vcgElectionState() for controller $i <<<<<<<<");
                            logInfo("FindMaster:  Controller $i marked INVALID.  Starting over.");
                            $coSNs[$i] = INVALID;
                            redo ELECTION;
                        }

                        if ( $rsp{STATUS} != PI_GOOD )      # error 
                        {
                            logInfo(">>>>>>>> Got an error from vcgElectionState() for controller $i <<<<<<<<");
                            logInfo("FindMaster:  Controller $i marked INVALID.  Starting over.");
                            PrintError(%rsp);
                            $coSNs[$i] = INVALID;
                            redo ELECTION;
                        }
                
                        if ( $rsp{STATE} != 0 ) 
                        {
                            $electionInProgress = TRUE;   
                        }
                    }
                }
              
                # 
                # In an election is in progress, check for timeout.  
                # If not timed out, delay 3 secs and check again
                #
                if ( $electionInProgress )
                {   
                    if ( $waitCount >= 30 )     # 30 * 3 = 90 secs
                    {
                        logInfo(">>>>>>>>  Timeout waiting for election to complete  <<<<<<<<");
                        return INVALID;
                    }    
                    else 
                    {
                        print "FindMaster:  Election in progress.  Waiting 3 secs.\n";
                        sleep 3;
                        $waitCount++;
                    }
                }
            }  
            while ( $electionInProgress );

            #
            # No election is in progress.  Go thru each valid controller
            # 
            for ( $i = 0; $i < $numCtlrs; $i++ )
            {
                if ( $coSNs[$i] != INVALID )
                {
                    $ctlr = $coList[$i];
                
                    #
                    # Get the powerupstate.  If we get 0, something failed.
                    # Mark controller INVALID and start over.
                    #
                    $powerUpState = GetStatePOQ($ctlr);  
                    if ( $powerUpState == 0 )
                    {
                        logInfo(">>>>>>>> Error from GetStatePOQ() for controller $i <<<<<<<<");
                        logInfo("FindMaster:  Controller $i marked INVALID.  Starting over.");
                        $coSNs[$i] = INVALID;
                        redo ELECTION;
                    } 
            
                    #
                    # Get the vcginfo.  If it fails, mark the controller INVALID
                    # and start over.
                    #
                    %info = $ctlr->vcgInfo(0);       
                    if ( ! %info  )
                    {
                        logInfo(">>>>>>>> No response from vcgInfo() for controller $i <<<<<<<<");
                        logInfo("FindMaster:  Controller $i marked INVALID.  Starting over.");
                        $coSNs[$i] = INVALID;
                        redo ELECTION;
                    }
                    if ($info{STATUS} != PI_GOOD)
                    {
                        logInfo(">>>>>>>> Error from vcgInfo() for controller $i <<<<<<<<");
                        logInfo("FindMaster:  Controller $i marked INVALID.  Starting over.");
                        $coSNs[$i] = INVALID;
                        redo ELECTION;
                    }

                    #
                    # We have vcginfo and powerupstate for this controller.
                    # See if this one is a master. First print some info.
                    # need powerupstate to be POWER_UP_COMPLETE
                    #


                    $msg =  "FindMaster:  ip: $ctlr->{HOST}, serial number: $coSNs[$i], ";
                    $msg .= "max ctlrs: $info{VCG_MAX_NUM_CONTROLLERS}, ";
                    $msg .= "PowerUpState = ";
                    $msg .=  XIOTech::cmdMgr::_getString_POWERUP($powerUpState);

                    logInfo($msg);

                    # if sn match with max controllers > 1 and master

                    # check max controllers
                    if (  $info{VCG_MAX_NUM_CONTROLLERS} >= 1)
                    {
                        # check each controller listed
                        for ( $j = 0; $j < $info{VCG_MAX_NUM_CONTROLLERS}; $j++ )
                        {
                            $msg = sprintf("FindMaster:  ctlr: %2d, sn: 0x%8.8x, state: 0x%2.2x ",
                                            $j,
                                            $info{CONTROLLERS}[$j]{SERIAL_NUMBER},
                                            $info{CONTROLLERS}[$j]{FAILURE_STATE});

                            $k =  $info{CONTROLLERS}[$j]{FAILURE_STATE};

                            if    ( $k == FD_STATE_UNUSED                   ) { $msg .= "(UNUSED                   )";}
                            elsif ( $k == FD_STATE_FAILED                   ) { $msg .= "(FAILED                   )";}
                            elsif ( $k == FD_STATE_OPERATIONAL              ) { $msg .= "(OPERATIONAL              )";}
                            elsif ( $k == FD_STATE_POR                      ) { $msg .= "(POR                      )";}
                            elsif ( $k == FD_STATE_ADD_CONTROLLER_TO_VCG    ) { $msg .= "(ADD_CONTROLLER_TO_VCG    )";}
                            elsif ( $k == FD_STATE_STRANDED_CACHE_DATA      ) { $msg .= "(STRANDED_CACHE_DATA      )";}
                            elsif ( $k == FD_STATE_FIRMWARE_UPDATE_INACTIVE ) { $msg .= "(FIRMWARE_UPDATE_INACTIVE )";}
                            elsif ( $k == FD_STATE_FIRMWARE_UPDATE_ACTIVE   ) { $msg .= "(FIRMWARE_UPDATE_ACTIVE   )";}
                            elsif ( $k == FD_STATE_UNFAIL_CONTROLLER        ) { $msg .= "(UNFAIL_CONTROLLER        )";}
                            elsif ( $k == FD_STATE_VCG_SHUTDOWN             ) { $msg .= "(VCG_SHUTDOWN             )";}
                            else                                              { $msg .= "(something else ($k)      )";}

                     #       logInfo($msg . ", master: $info{CONTROLLERS}[$j]{AM_I_MASTER}");

                            #
                            # is it the master
                            # AND operational
                            # AND power up complete
                            # AND the same serial number
                            #

                            if ( ($info{CONTROLLERS}[$j]{AM_I_MASTER} != 0) &&
                                 ($info{CONTROLLERS}[$j]{FAILURE_STATE} == FD_STATE_OPERATIONAL ) &&
                                 ($coSNs[$i] == $info{CONTROLLERS}[$j]{SERIAL_NUMBER}) &&
                                 ($powerUpState == POWER_UP_COMPLETE) )
                            {


                                #
                                # We save off the SN of the first master
                                # but also check to see if a subsequent
                                # master is found. THis indicates there
                                # appear to be two masters and will be a
                                # problem.
                                #                               

                                if ( $tempMaster == INVALID )
                                {
                                    $tempMaster = $info{CONTROLLERS}[$j]{SERIAL_NUMBER};
                                }
                                else
                                {
                                    if ( $tempMaster != $info{CONTROLLERS}[$j]{SERIAL_NUMBER} )
                                    {
                                        #
                                        # oops two different controllers have a different view as to
                                        # who is the master. this is not good, so we flag it as an error
                                        #

                                        logInfo("FindMaster:  Multiple masters found, serial numbers: ".
                                                "$tempMaster,  $info{CONTROLLERS}[$j]{SERIAL_NUMBER}");

                                        $multipleMasters = 1;
                                    }
                                }

                                # Success, return the array index
                                logInfo("FindMaster:  $ctlr->{HOST} is the master.");
                                $ourMaster = $i;
                            }
                        }       # end of for loop 
                    }       # end of if VCG_MAX_NUM_CONTROLLERS >= 1
                }       # endo of if sn valid loop
            }       # end of for loop
        
            #
            # Check again to see if an election if in progress.  If it is,  
            # go back to ELECTION
            #
            for ( $i = 0; $i < $numCtlrs; $i++ )
            {
                if ( $coSNs[$i] != INVALID )
                {
                    $ctlr = $coList[$i];
                    %rsp = $ctlr->vcgElectionState();

                    if ( !%rsp )                        # no response
                    {
                        logInfo(">>>>>>>> No response from vcgElectionState() for controller $i <<<<<<<<");
                        logInfo("FindMaster:  Controller $i marked INVALID.  Starting over.");
                        $coSNs[$i] = INVALID;
                        redo ELECTION;
                    }

                    if ( $rsp{STATUS} != PI_GOOD )      # error 
                    {
                        logInfo(">>>>>>>> Got an error from vcgElectionState() for controller $i <<<<<<<<");
                        logInfo("FindMaster:  Controller $i marked INVALID.  Starting over.");
                        PrintError(%rsp);
                        $coSNs[$i] = INVALID;
                        redo ELECTION;
                    }
            
                    if ( $rsp{STATE} != 0 ) 
                    {
                        logInfo("FindMaster:  Election detected.  Starting over.");
                        redo ELECTION;
                    }
                }
            }
        }       # end of ELECTION block

        #
        # If we did not find any masters, delay 10 secs to ensure a downed 
        # master controller has been detected and an election has occurred. 
        # Then retry.  Do the same if multiple masters were found.  
        #
        if ( ( $ourMaster == INVALID ) || ( $multipleMasters != 0 ) )
        {
            if ( $ourMaster == INVALID )
            {
                logInfo("FindMaster:  No master found/identified");
            }
            else 
            {
                logInfo("FindMaster:  Multiple masters found/identified");
                $ourMaster = INVALID;          
            }
            
            if ( $retry < 3 )
            {
                $retry++;
                logInfo("FindMaster:  Waiting 10 secs.");
                sleep 10;
                redo MAIN;     
            }
        } 
    }       # end of MAIN block

    return $ourMaster;     # returns the array index
}

##############################################################################
#
#          Name: FindMasterPickSlave
#
#   Description: Determines the master and randomly selects a slave controller
#                in the supplied list.
#
#        Inputs: controller object list
#
#       Outputs: A two value list:
#                      index of the master controller
#                      index of a randomly selected slave controller
#                Either or both of these indices can be returned as INVALID
#
#  Globals Used: none
#
##############################################################################
sub FindMasterPickSlave
{
    trace();
    my ($coPtr) = @_;
    my $masterIdx = FindMaster($coPtr);
    my $slaveIdx  = INVALID;
    my $numCtlrs = scalar(@$coPtr);
    my %rsp;

    # Find the max number of controllers licensed.  The slave index
    # must always be less than max controllers.
    %rsp = $$coPtr[$masterIdx]->vcgInfo(0);

    if ( ! %rsp  )
    {
        logInfo("Unable to get vcginfo from master");
    }
    else
    {
        # Get the max num controllers from the response hash.
        my $maxCtrls = $rsp{VCG_MAX_NUM_CONTROLLERS};

        # Generate a random slave index.
        if ($masterIdx != INVALID and $numCtlrs >= 2)
        {
            $slaveIdx = $masterIdx;

            # Loop until a valid slave index is found.
            while (($slaveIdx == $masterIdx) || ($slaveIdx >= $maxCtrls))
            {
                $slaveIdx = int(rand($numCtlrs));
            }
        }
    }

    return ($masterIdx, $slaveIdx);
}


#######################################################################
## Function name: CcbeConnectAll
##
## Purpose: Login to an array of controllers via the CCBE
##
## INPUT:    Array of Controller IP Addresses (xx.xx.xx.xx)
## Updated:  Array of CCBE Manager Objects
## OUTPUT:   Good or Error
#######################################################################
sub CcbeConnectAll
{
    trace();                        # This allows function tracability

    my ($contIPsPtr, $CCBEObjsPtr, $port) = @_;
    my $connectReturn;
    my $returnCode = GOOD;
    my $controllerIP;

    if ( !$port )
    {
        $port = 0;
    }


    foreach $controllerIP (@$contIPsPtr)  # Go through each controllers in this array
    {
        $connectReturn = TestLibs::IntegCCBELib::ccbe_connect($controllerIP, $port);
        if ($connectReturn == ERROR)
        {
            push (@$CCBEObjsPtr, 0);
            $returnCode = ERROR;
        }
        else
        {
            push (@$CCBEObjsPtr, $connectReturn);
        }
    }

    return $returnCode;
}


##############################################################################
#
# Name:         CcbeConnectAllWithRetries
#
# Inputs:       $ipPtr          Pointer to array of controller IP addresses
#               $CCBEObjsPtr    Pointer to array of CCBE Manager Objects
#               $port           CCB port
#               $retries        Retries (in seconds)
#
# Outputs:      GOOD, if successful, ERROR otherwise
#
# Globals Used: none
#
# Description:
#
#
#
#
##############################################################################
sub CcbeConnectAllWithRetries
{
    trace();

    my ($contIPsPtr, $CCBEObjsPtr, $port, $retries) = @_;

    my $contIP;
    my $rc;
    my $try;
    my $obj;


    # Convert retries into "retry seconds" assuming the current
    # DelaySecs() below;
    $retries = ($retries / 5) + 1;

    # Attempt to connect to each controller
    foreach $contIP (@$contIPsPtr)
    {
        # Initialize loop variables
        $rc = GOOD;
        $try = 1;

        # Create an object for this connection
        $obj = XIOTech::cmdMgr->new(\*STDOUT);

        # Log a message before we attempt to connect
        TestLibs::Logging::logInfo ("Logging into $contIP via CCBE port $port");

        # Loop until connection is made or retry limit is reached.
        # login returns 0 on ERROR.
        while ($rc == 0)
        {
            # Wait a bit before attempting to connect
            # if we've tried once and failed.
            if ($try > 1)
            {
                DelaySecs(5);
            }

            print "Connection attempt # $try \r";

            # Attempt to reconnect the socket
            $rc = $obj->login($contIP, $port);

            $try++;

            # If the retries are exhausted bail out.  We need to connect
            # to all controllers to proceed.
            if (($try > $retries) && ($rc == 0))
            {
                # Didn't connect.  Zero out the object and return an error.
                TestLibs::Logging::logInfo(">>>>>>>> Failed to connect to controller \n <<<<<<<<");
                push (@$CCBEObjsPtr, 0);
                return ERROR;
            }


        }

        # If we get here then the connection was successful.
        # Push the new controller object into the array.
        push (@$CCBEObjsPtr, $obj);
    }

    return GOOD;
}

#######################################################################
## Function name: CcbeDisconnectAll
##
## Purpose: Logout of an array of controllers via the CCBE
##
## INPUT:    Array of Controller Objects
## Updated:  Nonthing
## OUTPUT:   Good or Error
#######################################################################

sub CcbeDisconnectAll
{
    trace();                        # This allows function tracability

    my ($CCBEObjsPtr) = @_;
    my $disconnectReturn;
    my $returnCode = GOOD;

    foreach my $controllerObj (@$CCBEObjsPtr)  # Go through each controllers in this array
    {
        $disconnectReturn = TestLibs::IntegCCBELib::ccbe_disconnect($controllerObj);

        if ($disconnectReturn == ERROR)
        {
            $returnCode = ERROR;
        }
    }

    return $returnCode;
}

#######################################################################
## Function name: ccbe_connect
##
## Purpose: Login to a controller via the CCBE
##
## INPUT:    Controller IP Address (xx.xx.xx.xx)
## OUTPUT:   CCBE Manager Object or Error
#######################################################################

sub ccbe_connect
{
    trace();                        # This allows function tracability
    my ($contIP, $port) = @_;


    if ( !$port )
    {
        $port = CCB_PORT;
    }

    sleep(2);

    TestLibs::Logging::logInfo ("Logging into $contIP via CCBE port $port");

    my $obj = XIOTech::cmdMgr->new(\*STDOUT);

    unless  ($obj->login($contIP, $port))        # connect to controller
    {
        TestLibs::Logging::logWarning ("Failed to connect to controller IP:$contIP");
        return ERROR;
    }

    #---Set TimeOut
    $obj->{TIMEOUT} = CCBETIMEOUT;

    return $obj;
}


#######################################################################
## Function name: ccbe_disconnect
##
## Purpose: Disconnect from a controller via the CCBE
##
## INPUT:    CCBE Manager Object
## OUTPUT:   Good or Error
#######################################################################

sub ccbe_disconnect
{
    trace();                        # This allows function tracability
    my ($obj) = @_;

    TestLibs::Logging::debug ("Logging Off CCB");

    # If the object does not exist, we cannot disconnect and are done
    if (!$obj) {return GOOD;}

    unless  ($obj->logout())                # disconnect from controller
    {
        TestLibs::Logging::logWarning ("Failed to disconnect from controller");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: Reconnect
#
#        Inputs: controller object, initial delay (but not 0) in seconds
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Makes sure there is a valid connection to the controller.
#                Makes
#                the connection using the existing controller object.
#
#
##############################################################################
sub Reconnect
{
    trace();
    my ($obj, $delay ) = @_;

    my $ret;
    my $host;
    my $port;
    my $j;
    my $rc;


    # a little bounds check on delay

    if  ( !$delay )
    {
        $delay = 1;
    }

    if ( $delay < 0 )
    {
        $delay = 1;
    }

    DelaySecs( $delay );

    # get ip addr and port from existing object

    $host = $obj->{HOST};
    $port = $obj->{PORT};


    $obj->logout();                       # may need to check for a socket here


    $j = 1;
    $rc = 0;

    while ($rc == 0)
    {
        # Sleep for 5 second(s) before attempting to connect.
        sleep(5);

        print "Connection attempt # $j \r";
        # Attempt to reconnect the socket
        $rc = $obj->login($host, $port);
        $j++;

        # set a timeoput for this in case a controller is too dead
        # to reconnect.
        if ( $j > 48 )
        {
            # didn't recover in 4 or 5 minutes, got a dead one
            logWarning(">>>>>>>> Failed to reconnect to controller \n <<<<<<<<");
            return ERROR;
        }
    }

    return GOOD;

}

##############################################################################
#
#          Name: PowerCycle
#
#        Inputs: moxa IP addr, channel, new state
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Turns power off then one for the specified channel
#
##############################################################################
sub PowerCycle
{
    trace();
    my($ip, $chan) = @_;

    my $ret;

print "Moxa IP:$ip\n";
print "Moxa Chan:$chan\n";

    #$ret = system("common\\xiopower.exe",$ip, $chan, "0");
    $ret = ACPowerControl($ip, $chan, "0");

    if ( $ret != 0 )
    {
        # say what the parameters were
        logInfo ("Error controlling power. IP = $ip, channel = $chan, state = OFF. ");
        return ERROR;
    }

    sleep (10);

    $ret = ACPowerControl($ip, $chan, "1");

    if ( $ret != 0 )
    {
        # say what the parameters were
        logInfo ("Error controlling power. IP = $ip, channel = $chan, state = ON. ");
        return ERROR;
    }

    return GOOD;
}



##############################################################################
#
#          Name: PowerChange
#
#        Inputs: moxa IP addr, channel, new state
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Turns power on or off to one channel of the Moxa
#                This is really just a pass-thru function.
#
##############################################################################
sub PowerChange
{
    trace();
    my($ip, $chan, $state) = @_;

    my $ret;

    $ret = ACPowerControl($ip, $chan, $state);

    my $ret2 = $ret >> 8;

    if ( $ret == 0 )
    {
        logInfo ("Success controlling the power. IP = $ip, channel = $chan, state = $state. Return codes are $ret, $ret2.");

        return GOOD;
    }

    # say what the parameters were
    logInfo ("Error controlling the power. IP = $ip, channel = $chan, state = $state. Return codes are $ret, $ret2.");

    return ERROR;
}

##############################################################################
#
#          Name: PowerCheck
#
#        Inputs: moxa IP addr pointer, channel pointer
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Turns power on to all channels. Verifies we have control
#                of each Moxa channel.
#
##############################################################################
sub PowerCheck
{
    trace();
    my($ipPtr, $chanPtr) = @_;

    my $ret;
    my $i;

    my @moxaIP = @$ipPtr;
    my @moxaChan = @$chanPtr;

    my $channels;

    my $failFlag = GOOD;
    my $str;

    # Use the smaller of the two arrays. They should be the same size,
    # but let that test be elsewhere.

    $channels = min( scalar(@moxaIP), scalar(@moxaChan) );


    # Turn ON each of the listed ports. If we succeed, then we have control
    # over that port. If fail, then internet control is not working (or some
    # other problem).

    # One side effect of this test is that any test that calls this cannot
    # be started with power initially off intentionally. All ports
    # specified will be on when done.

    for ($i = 0; $i < $channels; $i++)
    {

        logInfo("\n\n\n\n ************************* checking moxa connection $i ***************************************");

        $ret = ACPowerControl($moxaIP[$i], $moxaChan[$i], 1);


        $str = sprintf ("XIOpower returned 0x%04x (%d)", $ret, $ret);
        logInfo("$str");

        #print "output: $? \n";

        if ( $ret != 0 )
        {
            # The failure is deferred so we can test each port rather than fail
            # one each time the test is invoked.
            logInfo("\n==> Failure testing control of channel $moxaChan[$i] on Moxa $moxaIP[$i]");
            $failFlag = ERROR;
        }
        else
        {
            logInfo("\n==> Success testing control of channel $moxaChan[$i] on Moxa $moxaIP[$i]");
        }

    }

    logInfo("\n\n\n ************************* checking moxa connections done ************************************");

    return $failFlag;
}


##############################################################################
#
#          Name: Unfail
#
#        Inputs: controller object for master, sn for dead one
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################









##############################################################################
#
#          Name: failController
#
#        Inputs: controller object for master, sn for one to fail
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: fails a controller using 'VCGFAIL'
#
#
##############################################################################

sub FailController
{
    trace();
    my ($obj, $csn) = @_;

    my %rsp;

    #We could be failing ourself, so set the timeout a bit on the short side

    $obj->{TIMEOUT} = 60;

    %rsp = $obj->vcgFailController($csn);

    $obj->{TIMEOUT} = CCBETIMEOUT;   # Restore timeout

    if (%rsp)
    {
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error failing the controller, Serial Number: $csn <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }
    else
    {
        logInfo(">>>>>>>> Did not receive a response packet (failController) <<<<<<<<");
        # we can't really return error either.


        return GOOD;
    }

    return GOOD;
}

##############################################################################
#
#          Name: UnFailController
#
#        Inputs: controller object for master, sn for dead one
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################
sub UnFailController
{
    trace();
    my ($obj, $csn) = @_;

    my %rsp;

    my $time1;

    $time1 = time;       # time when we start this command

    logInfo("Sending the unfail command.");

    %rsp = $obj->vcgUnfailController($csn);

    if (%rsp)
    {
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error unfailing the controller, Serial Number: $csn <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }
    else
    {
        logInfo(">>>>>>>> Did not receive a response packet (unfailController) <<<<<<<<");
        return ERROR;
    }

    $time1 = time - $time1;  # elapsed time for command

    logInfo("It took $time1 seconds to execute the unfail command.");

    return GOOD;
}

##############################################################################
#
#          Name: VcgConfigureController
#
#        Inputs: ipaddress, subnetMask, dfltgateway, dscid, node, replaceFlag
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine configures a controller
#
#
##############################################################################

sub VcgConfigureController()
{
    trace();

    my ($objPtr, $ipAddress, $subnetMask, $dfltGateway, $dscId, $node, $replaceFlag) = @_;

    my $ctlr;
    my $master;
    my %rsp;
    my @coList;

    #
    # Find the master controller
    #
    
    $master = &TestLibs::IntegCCBELib::FindMaster($objPtr);

    if ( $master == INVALID ) { return(ERROR); } 

    @coList = @$objPtr;

    $ctlr = $coList[$master];

    print "\n";

    my $subnet = unpack "L", $currentMgr->ip2long("255.255.240.0");
    my $gateway = unpack "L", $currentMgr->ip2long("10.64.128.1");
    my $nodeId = 0;
    my $replacement = 0;
    my $sno = 0;

    if (!defined($ipAddress))
    {
        print "Missing address.\n";
        return;
    }

    # Convert IP address
    my $ipAddr =  unpack "L", $currentMgr->ip2long($ipAddress);
    
    if (defined($subnetMask))
    {
        $subnet = unpack "L", $currentMgr->ip2long($subnetMask);
    }

    if (defined($dfltGateway))
    {
        $gateway = unpack "L", $currentMgr->ip2long($dfltGateway);
    }

    if(defined($dscId))
    {
        $sno = $dscId;
    }

    if(defined($node))
    {
        $nodeId = $node;
    }

    if(defined($replaceFlag))
    {
        $replacement = $replaceFlag;
    }

    %rsp = $currentMgr->configController($ipAddr, $subnet, $gateway, $sno, $nodeId, $replacement);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            print "Controller has been configured.\n";
        }
        else
        {
            my $msg = "Unable to configure the controller.";
            TestLibs::scrub::displayError($msg, %rsp);
        }
    }
    else
    {
        print "ERROR: Did not receive a response packet.\n";
        logout();
    }

    print "\n";

}


##############################################################################
#
#          Name:
#
#        Inputs:
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description:
#
#
##############################################################################





##############################################################################
#
#          Name: QLReset
#
#        Inputs: controller object, FE|BE, which QL, <reset | reset&init >
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: resetes the specific QL card with or without an init as requested
#
#
##############################################################################
sub QLReset
{
    trace();
    my ( $ctlr, $proc, $chan, $option, $ignoreIfMissing ) = @_;

    my %rsp;
    my $ignoreIfMis = defined($ignoreIfMissing) and $ignoreIfMissing ? 1 : 0;


    if (uc($chan) eq "ALL")
    {
        $chan = 0xFF;
    }
    elsif ($chan < 0 || $chan >= 4)
    {
        logWarning(">>>>>>>> Invalid parameter channel ($chan). <<<<<<<<");
        return ERROR;
    }

    if (defined($proc))
    {
        if (uc($proc) eq "BE")
        {
            %rsp = $ctlr->resetQlogicBE($chan, $option);
        }
        elsif (uc($proc) eq "FE")
        {
            %rsp = $ctlr->resetQlogicFE($chan, $option);
        }
        else
        {
            logInfo(">>>>>>>> Invalid parameter type ($proc). <<<<<<<<");
            return ERROR;
        }
    }

    if (%rsp)
    {
        if ($rsp{STATUS} != PI_GOOD)
        {

            if( $rsp{ERROR_CODE} == 0x36 and $ignoreIfMis )
            {
                logInfo(">>>>>>>> No card in chan: $proc:$chan. <<<<<<<<");
                # do nothing
            }
            else
            {

                if( $rsp{ERROR_CODE} != 0x36 )
                {
                    # print only if it is NOT Invalid Channel number
                    logInfo(">>>>>>>> Error resetting the QL card. <<<<<<<<");
                    PrintError(%rsp);
                }
                return ERROR;
            }
        }
    }
    else
    {
        logInfo(">>>>>>>> Did not receive a response packet (resetQlogicXX) <<<<<<<<");
        return ERROR;
    }

    return GOOD;
}

##############################################################################
#
#          Name: QLTest1
#
#        Inputs: controller object, loops, reset option
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: On the first valid QL card on the specified processor,
#                Reset, pause, reset&init, pause for the number of loops
#
#
##############################################################################
sub QLTest1
{
    trace();
    my ($ctlr, $loops, $proc, $option, $delay1, $delay2) = @_;

    my $i;
    my $ret;
    my $chan;

    my @QLList;

    # get a list of the existing QL cards
    @QLList = FindQL($ctlr, $proc );

    if ($QLList[0] == INVALID )
    {
        logInfo(">>>>>>>> Didn't find any QL cards on $proc <<<<<<<<");
        return ERROR;
    }


    $chan = $QLList[0];

    # do the desired number of loops
    for( $i = 0; $i < $loops; $i++ )
    {
        logInfo("Reset loop # $i, resetting $proc, chan $chan");
        $ret = QLReset($ctlr, $proc, $chan, 1 );   # reset only

        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Error on initial reset of the QL. <<<<<<<<");
            return ERROR;
        }

        DelaySecs( $delay1 );

        logInfo("Reset and Init on $proc, chan $chan");
        $ret = QLReset($ctlr, $proc, $chan, 0 );   # reset & init

        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> Error on 2nd reset/init of the QL. <<<<<<<<");
            return ERROR;
        }

        DelaySecs( $delay2 );
     }

    return GOOD;
}

##############################################################################
#
#          Name: FindQL
#
#        Inputs: Controller object, processor
#
#       Outputs: QL list array if OK, INVALID as 1st member on failure
#
#  Globals Used: none
#
#   Description: Find the valid QL cards on the specific proc
#
#
##############################################################################

sub FindQL
{
    trace();
    my ($ctlr, $proc, $option ) = @_;

    my @List;
    my $commandCode;
    my %rsp;
    my $i;
    my $count;

    if ($proc eq "BE")
    {
        $commandCode = PI_PROC_BE_PORT_LIST_CMD;
    }
    elsif ($proc eq "FE")
    {
        $commandCode = PI_PROC_FE_PORT_LIST_CMD;
    }
    else
    {
        logError(">>>>>>>> UNDEFINED COMMAND CODE $proc <<<<<<<<");
    }

    if ($option == INVALID)
    {
        $option = 0;
    }

    logInfo("Option is $option \n");

    %rsp = $ctlr->getPortList($commandCode, $option);

    if (%rsp)
    {
        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>>>>> Error getting QL list <<<<<<<<");
            PrintError(%rsp);
            push ( @List, INVALID);
            return @List;
        }
    }
    else
    {
        logInfo(">>>>>>>> Did not receive a response packet (getPortList) <<<<<<<<");
        push ( @List, INVALID);
        return @List;
    }

    $count = 0;
    for $i (0..$#{$rsp{LIST}})
    {
        push ( @List, $rsp{LIST}[$i] );
        $count++;
    }

    if ( $count < 1 )
    {
        logInfo(">>>>>>>> No QL cards were seen <<<<<<<<");
        push ( @List, INVALID);
        return @List;
    }

    # must be good
    logInfo("Found these QL cards @List");
    return @List;
}

##############################################################################
# Name:     ActiveServerList
#
# Desc:     Creates a list of the active servers.
#
# Input:  Pointer to an array of controllers
# Output: Array of active server Ids
##############################################################################
#sub ActiveServerList
#{
#    trace();
#    my ($coPtr) = @_;
#    my @ar1;
#    my @ar2;
#    my @retarr;
#    my @coList;
#    my $i;
#    my $j;
#    my $size;
#
#    @coList = @$coPtr;
#
#    #Initialize the server array to all inactive
#
#    for $i (0..255)
#    {
#        $retarr[$i] = FALSE;
#    }
#
#    my $numCtlrs = scalar( @coList );
#
#    #
#    # Walk through each of the controllers and flag the active servers
#    #
#    for $i (0..$numCtlrs-1)
#    {
#        @ar1 = GetServerIO($coList[$i]);
#        sleep(5);
#        @ar2 = GetServerIO($coList[$i]);
#
#
#        $size = min( scalar(@ar1), scalar(@ar2));
#
#        for $j (0..$size)
#        {
#            if (defined($ar1[$j]) && defined($ar2[$j]))
#            {
#                if ($ar2[$j] - $ar1[$j] > 100)
#                {
#                    $retarr[$j] |= TRUE;
#                }
#            }
#        }
#    }
#
#    # Display Active servers
#    my $str = "Active Servers:";
#
#    for $i (0..scalar(@retarr))
#    {
#        if ($retarr[$i])
#        {
#            $str .= " $i,";
#        }
#    }
#    logInfo($str);
#
#    return @retarr;
#}
###############################################################################
## Name:     GetServoIO
##
## Desc:     Looks to see if servers are still processing I/O requests.
##
## Input:    obj - controller object
###############################################################################
#sub GetServerIO
#{
#    trace();
#    my ($obj) = @_;
#    my @commands;
#
#    bless($obj, "XIOTech::cmdMgr");
#
#    my %rsp = $obj->serverList(undef);
#
#    if (%rsp)
#    {
#        if ($rsp{STATUS} != PI_GOOD)
#        {
#            logInfo("getServerIO: Unable to retrieve Server List.");
#        }
#        else
#        {
#            #
#            # Loop through all server
#            for my $i (0..$#{$rsp{LIST}})
#            {
#                # logInfo ("Retrieving stats for server $rsp{LIST}[$i]  ");
#                my %rsp2 = $obj->statsServer($rsp{LIST}[$i]);
#
#                if (%rsp2)
#                {
#                    if ($rsp2{STATUS} != PI_GOOD)
#                    {
#
#                        if (!(($rsp2{STATUS} == 0x01)  &&
#                                    ($rsp2{ERROR_CODE} == 0x2f)))
#                        {
#                            logInfo("getServIO: Unable to retrieve Server Stats.");
#                        }
#                        else
#                        {
#                            $commands[$rsp{LIST}[$i]] = 0;
#                            #logInfo("\t\tServer: $rsp{LIST}[$i] returned 0x2F");
#
#                        }
#                    }
#                    else
#                    {
#                        $commands[$rsp{LIST}[$i]] = ($rsp2{AG_READS} + $rsp2{AG_WRITES});
#                        logInfo("Server: $rsp{LIST}[$i] Reads: $rsp2{AG_READS} Writes: $rsp2{AG_WRITES}");
#                    }
#
#                }
#            }
#        }
#
#    }
#    else
#    {
#        logInfo("GetServoIO: Did not receive a response packet.");
#    }
#
#
#    return @commands;
#}
#
###############################################################################
## Name:     TestForServerIO
##
## Desc:     Looks to see if servers are still processing I/O requests.
##
## Input:    None
###############################################################################
#sub TestForServerIO
#{
#    trace();
#    my ($coPtr, $actServerPtr) = @_;
#
#    my $rc = GOOD;
#    my $retry = 0;
#
#    my @serverList = @$actServerPtr;
#
#    do
#    {
#        $rc = GOOD;
#        my @activeServers = ActiveServerList($coPtr);
#
#        if (scalar(@activeServers) != scalar(@serverList))
#        {
#            logInfo("Mismatch in number of active servers  ");
#            $rc = ERROR;
#        }
#        else
#        {
#            for my $i (0..scalar(@activeServers))
#            {
#                if (defined($activeServers[$i]))
#                {
#                    if ($activeServers[$i] != $serverList[$i])
#                    {
#                        logInfo("Mismatch in active server list  ");
#                        $rc = ERROR;
#                    }
#                }
#            }
#        }
#        if ($rc != GOOD)
#        {
#            ++$retry;
#            sleep (10);
#            logInfo("Failed Active Server test - Retry No. $retry");
#        }
#    } while (($rc != GOOD) && ($retry < 3));
#
#    return $rc;
#}
#
###############################################################################
## Name:     TestSystemState
##
## Desc:     Test the state of the system
##           Checks for:
##               Valid VCG
##               Servo I/O still active
##
## Inputs:   coPtr - pointer ot a list of controllers
##           masterCntlIndex - Index of master in controller list
##           actServerPtr - pointer to list of active servers
##           targetListPtr - pointer to list of assigned targets
###############################################################################
#sub TestSystemState
#{
#    trace();
#    my ($coPtr, $actServerPtr, $targetListPtr, $vdiskListPtr, $snPtr) = @_;
#    my @coList = @$coPtr;
#    my $rc = GOOD;
#
#    my $ret;
#    my %info1;
#    my @tmap;
#    my @vList;
#
#    logInfo("finding the master");
#
#
#
#    my $newMaster = FindMaster( $coPtr );
#    if ( $newMaster == INVALID )
#    {
#        logInfo(">>>>>>>> Failed to find the master controller  <<<<<<<<");
#        return ERROR;
#    }
#
#
#    logInfo("getting vcginfo on $newMaster");
#
#    $rc = DispVcgInfo($coList[$newMaster]);
#    if ( $rc == ERROR )
#    {
#        logInfo(">>>>>>>> Failed - Display VCG Info  <<<<<<<<");
#        return ERROR;
#    }
#
#    logInfo("getting pdisk info on $newMaster");
#
#    $ret = DispPdiskInfo($coList[$newMaster]);
#    if ( $ret == ERROR )
#    {
#        logInfo(">>>>>>>> Failed - Display Pdisk Info  <<<<<<<<");
#        return ERROR;
#    }
#
#    logInfo("getting target status on $newMaster");
#
#    $ret =  TargetList( $coList[$newMaster] );
#    if ( $ret == ERROR )
#    {
#        logInfo(">>>>>>>> Failed - Display target status  <<<<<<<<");
#        return ERROR;
#    }
#
#    #######################################
#    # check for continuing server activity
#    #######################################
#
#    logInfo("checking server activity on servers");
#
#    # if we have an active server list, compare against it
#    if (($actServerPtr))
#    {
#        #Test for Servo IO
#        $rc = TestForServerIO($coPtr, $actServerPtr);
#        if ( $rc == ERROR )
#        {
#            logInfo(">>>>>>>> Failed - Servo IO stopped  <<<<<<<<");
#            return ERROR;
#
#        }
#    }
#
#
#
#    ##################################################
#    # get the current tartget map and print it, even
#    # if we don't check it
#    ##################################################
#    %info1 = GetTargetStatus($coList[$newMaster]);
#
#    if ( ! %info1  )              # if no data from call
#    {
#        logInfo(">>>>>>>> Failed to get response from GetTargetStatus <<<<<<<<");
#        return ERROR;
#    }
#    if ( $info1{STATUS} != PI_GOOD )      # if call returned an error
#    {
#        logInfo(">>>>>>>> Error from GetTargetStatus <<<<<<<<");
#        PrintError(%info1);
#        return ERROR;
#    }
#
#    @tmap = CreateTargetMap($snPtr, %info1);
#
#    PrintTargetMap (\@tmap);
#
#    # if we have an active target list, compare against it the current
#    if (($targetListPtr))
#    {
#        $ret = CompareTargetMap(\@tmap, $targetListPtr);
#        if ( $ret == ERROR )
#        {
#            logInfo(">>>>>>>> Failed - Target maps didn't match  <<<<<<<<");
#            return ERROR;
#        }
#        else
#        {
#            logInfo("The target maps matched.");
#        }
#    }
#
#
#    ##########################################
#    # get and display the current vdisk list
#    ##########################################
#
#    @vList = ActiveVdiskList( \@coList );
#    if ( scalar(@vList) != 0 )
#    {
#        # we have some active vdisks
#        if ( $vList[0] == INVALID )
#        {
#            # error case
#            logInfo(">>>>>>>> Failed - can't get a current active vdisklist  <<<<<<<<");
#            $rc = ERROR;
#        }
#        else
#        {
#            # list is good
#
#            logInfo("Current vdisk list: @vList ");
#
#            # if we have an active target list, compare against it
#            if (($vdiskListPtr))
#            {
#                $ret = CompareLists( \@vList, $vdiskListPtr);
#                if ( ($ret == ERROR) || ($ret == INVALID) )
#                {
#                    logInfo(">>>>>>>> Failed - vdisk Lists didn't match  <<<<<<<<");
#                    return ERROR;
#                }
#            }
#        }
#    }
#    else
#    {
#        # we got no list, but we also may be expecting no list
#        if (($vdiskListPtr))
#        {
#            # this call works for empty lists, too
#            $ret = CompareLists( \@vList, $vdiskListPtr);
#            if ( ($ret == ERROR) || ($ret == INVALID) )
#            {
#                logInfo(">>>>>>>> Failed - vdisk Lists didn't match  <<<<<<<<");
#                return ERROR;
#            }
#        }
#
#    }
#    return $rc;
#}
#
#


##############################################################################
#
#          Name: CtlrLogText
#
#        Inputs: controller object, test message(scalar string)
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: puts a message in the controller logs
#
#
##############################################################################
sub CtlrLogText
{
    trace();
    my ($ctlr, $msg, $type) = @_;


    my $myType = 3;

    if (defined($type))
    {
        $myType = $type;
    }

    my %rsp = $ctlr->logTextMessage($msg, $myType);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo("Log message sent successfully ($ctlr->{HOST}): $msg");
        }
        else
        {
            logInfo(">>>>>>>> Failed to log the message  <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
    }
    else
    {
        logInfo(">>>>>>>> No response logging a message  <<<<<<<<");
        return ERROR;
    }

    return GOOD;
}
##############################################################################
#
#          Name: CtlrLogTextAll
#
#        Inputs: controller object list, test message(scalar string)
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: puts a message in the controller logs
#
#
##############################################################################
sub CtlrLogTextAll
{
    trace();
    my ($coPtr, $msg, $type) = @_;

    my $i;
    my $ret;

    my @coList = @$coPtr;

    for ($i = 0; $i < scalar(@coList); $i++)
    {

        $ret = CtlrLogText( $coList[$i], $msg, $type);

        if ($ret == ERROR)
        {
            return ERROR;
        }
    }

    return GOOD;
}

##############################################################################
#
#          Name: CtlrLogTextList
#
#        Inputs: controller object list, test message(scalar string)
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: puts a message in the controller logs
#
#
##############################################################################
sub CtlrLogTextList
{
    trace();
    my ($coPtr, $iPtr, $msg, $type) = @_;

    my $i;
    my $ret;

    my @coList = @$coPtr;
    my @idxList = @$iPtr;

    for ($i = 0; $i < scalar(@idxList); $i++)
    {

        $ret = CtlrLogText( $coList[$idxList[$i]], $msg, $type);

        if ($ret == ERROR)
        {
            return ERROR;
        }
    }

    return GOOD;
}


##############################################################################
#
#          Name: QLHoldReset
#
#        Inputs: controller object, processor, channel, reset delay and number
#                of seconds to hold reset
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Select a valid QL card on the specified processor, Hold for
#                X seconds in the form a reset and pause if the hold value
#                is > 0, reset&init, and pause between loops
#
#
##############################################################################
sub QLHoldReset
{
    trace();
    my ($ctlr, $proc, $chan, $delay, $hold) = @_;

    my $ret = GOOD;

    if($hold > 0)
    {
        logInfo("Holding $proc, channel $chan \n");
        $ret = QLReset($ctlr, $proc, $chan, RESET_QLOGIC_RESET_ONLY );   # reset only

        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> QLHoldReset:  Error on holding reset of the QL. <<<<<<<<\n");
            return ERROR;
        }

        # Hold Reset for X seconds
        DelaySecs( $hold );
    }

    logInfo("Reset $proc, channel $chan \n");
    $ret = QLReset($ctlr, $proc, $chan, RESET_QLOGIC_RESET_INITIALIZE );

    if ($ret != GOOD)
    {
        logInfo(">>>>>>>> QLHoldReset:  Error on reset of the QL. <<<<<<<<\n");
        return ERROR;
    }

    # Delay Between Resets
    DelaySecs( $delay );

    return $ret;
}


##############################################################################
#
#          Name: HoldResetPower
#
#        Inputs: controller object, processor, channel, reset delay and number
#                of seconds to hold reset
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Power cycle a port through a Moxa power switch.
#
##############################################################################
sub HoldResetPower
{
    trace();
    my ($ip, $chan, $delay, $hold) = @_;

    my $ret = GOOD;

    logInfo("Power OFF $ip, channel $chan \n");
    $ret = PowerChange($ip, $chan, "OFF");   # off only

    if ($ret != GOOD)
    {
         logInfo(">>>>>>>> HoldResetPower:  Error on holding power off on the Moxa hub. <<<<<<<<\n");
         return ERROR;
    }

    # Hold Reset for X seconds
    DelaySecs( $hold );

    logInfo("Power ON $ip, channel $chan \n");
    $ret = PowerChange($ip, $chan, "ON");   # on only

    if ($ret != GOOD)
    {
        logInfo(">>>>>>>> HoldResetPower:  Error on power on the Moxa hub. <<<<<<<<\n");
        return ERROR;
    }

    # Delay Between Resets
    DelaySecs( $delay );

    return $ret;
}



##############################################################################
#
#          Name: QLResetTestSeq
#
#        Inputs: controller object, loops, processor type, and delay between
#                resets in seconds to hold apdapter.
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Select a valid QL card in a sequential order on the specified
#                processor, Hold for X seconds in the form a reset and pause
#                if the hold value is > 0, reset&init, and pause between loops
#
#
##############################################################################
sub QLResetTestSeq
{
    trace();
    my ($ctlr, $loops, $proc, $delay, $hold) = @_;

    my $i;
    my $j = 0;
    my $ret;
    my $chan;

    my @QLList;

    # get a list of the existing QL cards
    @QLList = FindQL($ctlr, $proc );

    if ($QLList[0] == INVALID )
    {
        logInfo(">>>>>>>> QLResetTestSeq:  Didn't find any QL cards on $proc <<<<<<<<\n");
        return ERROR;
    }

    logInfo("Reset $loops times on QLogic cards Sequentially. \n");
    # do the desired number of loops
    for( $i = 0; $i < $loops; $i++ )
    {
        # Get channel sequentially
        $chan = $QLList[$j];

        print $i+1 . ".  ";
        $ret = QLHoldReset($ctlr, $proc, $chan, $delay, $hold);
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> QLResetTestSeq: faild to reset qlogic <<<<<<<<\n");
            return (ERROR);
        }

        ++$j;
        if($j >= scalar(@QLList))
        {
            $j = 0;
        }
    }


    return GOOD;
}

##############################################################################
#
#          Name: QLResetTestRnd
#
#        Inputs: controller object, loops, processor type, delay between resets
#                in seconds to hold apdapter, and the random generator seed.
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Select a valid QL card randomly on the specified processor,
#                Hold for X seconds in the form a reset and pause if the hold
#                value is > 0, reset&init, and pause between loops
#
#
##############################################################################
sub QLResetTestRnd
{
    trace();
    my ($ctlr, $loops, $proc, $delay, $hold, $seed) = @_;

    my $i;
    my $ret = GOOD;
    my $chan;

    my @QLList;

    # get a list of the existing QL cards
    @QLList = FindQL($ctlr, $proc );

    if ($QLList[0] == INVALID )
    {
        logInfo(">>>>>>>> QLResetTestRnd:  Didn't find any QL cards on $proc <<<<<<<<\n");
        return ERROR;
    }

    # set the seed of the random generator
    srand($seed);

    logInfo("Reset $loops times each QLogic channel Randomly with the seed of $seed. \n");
    # do the desired number of loops
    for( $i = 0; $i < $loops; $i++ )
    {

        # Get channel randomly
        $chan = $QLList[( (rand(scalar(@QLList))*1000) % scalar(@QLList) )] ;

        print $i+1 . ".  ";
        $ret = QLHoldReset($ctlr, $proc, $chan, $delay, $hold) ;
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> QLResetTestRnd: faild to reset qlogic <<<<<<<<\n");
            return (ERROR);
        }
    }



    return $ret;
}


##############################################################################
#
#          Name: DisableEnableSwitchPort
#
#        Inputs: switch object, port, number of seconds between disables
#                and number of seconds to keep the port disabled
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Select a port connected on a switch, turn off the port, Hold for
#                X seconds, enable the port, and delay for X seconds
#
##############################################################################
sub DisableEnableSwitchPort
{
    trace();
    my ($switch, $port, $delay, $hold) = @_;

    my $ret = GOOD;

    logInfo("Disable $port\n");
    $ret = BSWDisableSwitchPort($switch, $port);

    if ($ret != GOOD)
    {
        logInfo(">>>>>>>> DisableEnablePort:  Error on disable of port $port. <<<<<<<<\n");
        return ERROR;
    }

    if($hold >= 1)
    {
        # Hold Reset for X seconds
        DelaySecs( $hold );
    }

    logInfo("Enable port $port\n");
    $ret = BSWEnableSwitchPort($switch, $port);

    if ($ret != GOOD)
    {
        logInfo(">>>>>>>> DisableEnablePort:  Error on enable of port $port. <<<<<<<<\n");
        return ERROR;
    }

    # Delay Between Resets
    DelaySecs( $delay );

    return GOOD;
}

##############################################################################
#
#          Name: BypassBESwitchPorts  (NOT COMPLETE)
#
#        Inputs: ip of the switch, loops, number of seconds between disables,
#                number of seconds to keep the port disabled, port1 of drive
#                bay, port2 of drive bay, usname and password of switch
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Select a port connected on a switch, turn off the port, Hold for
#                X seconds, enable the port, and delay for X seconds
#
#
##############################################################################
sub BypassBESwitchPorts
{
    trace();
    my ($ipAddress, $loops, $delay, $hold, $driveBayPort1, $driveBayPort2, $seed, $username, $password) = @_;

    my $switch;
    my $port = 0;
    my $numberOfSwitchPorts = 0;
    my @portBitmapArray;
    my @controllerPorts;
    my $controllerPortIndex = 0;
    my @driveBayPorts;
    my $driveBayPortIndex = 0;

    my @configMap;

    my $ret = GOOD;

    # NOT COMPLETE BY RJR
    logInfo(">>>>>>>> BypassBESwitchPorts:  NOT COMPLETE 8/5/2002. <<<<<<<<\n");
    return ERROR;


    # set the zone to use all ports
    $portBitmapArray[0] = 255;

    # Login to the switch.  Use the username and password if they were
    # provided.
    logInfo("BypassBESwitchPorts:  Logon to switch @ $ipAddress\n");
    $switch = BSWLogInToSwitch($ipAddress, $username, $password);

    # Check to make sure that the login was successfull, otherwise try default.
    if ( !defined($switch) )
    {
        $switch = BSWLogInToSwitch($ipAddress);
    }

    # Check to make sure that the login was successfull, otherwise try fail.
    if ( !defined($switch) )
    {
        logInfo(">>>>>>>> BypassBESwitchPorts:  Unable to login to switch $ipAddress. <<<<<<<<\n");
        return ERROR;
    }

    # Port zone the switch
    logInfo("BypassBESwitchPorts:  Zoning switch @ $ipAddress with zone of $portBitmapArray[0]\n");
    if ( BSWZoneSwitch($switch, \@portBitmapArray) == GOOD )
    {

        # Show the results of the zoning.
        #if ( BSWShowSwitchZoningConfig($switch) == GOOD )
        #{
        #    logInfo("\BypassBESwitchPorts: The switch was successfully zoned.\n");
        #}
        #else
        #{
        #    logInfo(">>>>>>>> BypassBESwitchPorts:  An error occurred while trying to show the zoning configuration. <<<<<<<<");
        #   return ERROR;
        #}

    }
    else
    {
        logInfo(">>>>>>>> BypassBESwitchPorts:  An error occurred while attempting to zone the switch. <<<<<<<<");
        return ERROR;
    }

    # Get the number of ports on the specified switch.
    $numberOfSwitchPorts = BSWGetNumberOfSwitchPorts($switch);
    if ($numberOfSwitchPorts == INVALID)
    {
        logInfo(">>>>>>>> BypassBESwitchPorts: Could not get the number of switch ports <<<<<<<<\n");
        return ERROR;
    }

    #print ">>>>>>>> BypassBESwitchPorts: Number of ports = $numberOfSwitchPorts <<<<<<<<\n";
    #DelaySecs( 5 );

    # Scan all ports to see which ones are connected
    for ( $port=0; $port < $numberOfSwitchPorts; ++$port )
    {
        # Is it a Controller Port or a Drive Bay Port
        if(($port == $driveBayPort1) || ($port == $driveBayPort2))
        {
            # Check Drive Bay Ports
            logInfo("TODO RJR: ADD Eric's new port status function here\n");
            if(0 == 0)
            {
                #logInfo("BypassBESwitchPorts:  Found Drive Bay port @ $port.\n");
                $driveBayPorts[$controllerPortIndex] = $port;
                ++$controllerPortIndex;
                $configMap[$port] = "D";
            }
            else
            {
                $configMap[$port] = "X";
            }
        }
        else
        {
            # Check Controller Ports
            #logInfo("TODO RJR: ADD Eric's new port status function here\n");
            if(0 == 0)
            {
                #logInfo("BypassBESwitchPorts:  Found Controller port @ $port.\n");
                # Build Controller ports list
                $controllerPorts[$driveBayPortIndex] = $port;
                ++$driveBayPortIndex;
                $configMap[$port] = "C";
            }
            else
            {
                $configMap[$port] = "X";
            }
        }
    }

    # print configuration Map
    my $header = "          ";
    my $bar    = "----------";
    my $map    = "          ";
    for ($port=0; $port < scalar(@configMap); ++$port)
    {
        if($port < 10)
        {
            $header = $header . " " . $port . " ";
            $bar =  $bar . "---";
            $map =  $map . " " . $configMap[$port] . " ";
        }
        else
        {
            $header = $header . " " . $port . " ";
            $bar = $bar . "----";
            $map = $map . " " . $configMap[$port] . "  ";
        }
    }
    logInfo("BypassBESwitchPorts configuration map:  \n");
    logInfo($header . "\n" . $bar . "\n" . $map . "\n\n");

    # Check to see if we have at least one Drive Bay Port
    if(scalar(@driveBayPorts) < 1)
    {
        logInfo(">>>>>>>> BypassBESwitchPorts:  Not enough Drive Bay Ports connected to either $driveBayPort1 or $driveBayPort2. <<<<<<<<");
        return ERROR;
    }

    # Check to see if we have a minimum of two Controller Ports
    if(scalar(@controllerPorts) < 2)
    {
        logInfo(">>>>>>>> BypassBESwitchPorts:  Not enough Controller Ports connected. <<<<<<<<");
        return ERROR;
    }

    # Randomly Enable and Disable ports
    srand($seed);

    logInfo("Pull Cable $loops times each Controller port Randomly with the seed of $seed. \n");

    # do the desired number of loops
    for( my $i = 0; $i < $loops; $i++ )
    {

        # Get port randomly
        $port = $controllerPorts[( (rand(scalar(@controllerPorts))*1000) % scalar(@controllerPorts) )] ;

        logInfo($i+1 . ".  Pull cable on port $port\n");
        $ret = DisableEnableSwitchPort($switch, $port, $delay, $hold) ;
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> BypassBESwitchPorts: faild to disable/enable port. <<<<<<<<\n");
            return (ERROR);
        }
    }

    # Log out of the switch.
    if ( BSWLogOutOfSwitch($switch) == ERROR )
    {
        logInfo(">>>>>>>> BypassBESwitchPorts:  An error occurred while logging out of the switch. <<<<<<<<");
        return ERROR;
    }
    return GOOD;
}

##############################################################################
#
#          Name: DisableEnableHubPort
#
#        Inputs: hub object, port, number of seconds between disables
#                and number of seconds to keep the port disabled
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Select a port connected on a hub, turn off the port, Hold for
#                X seconds, enable the port, and delay for X seconds
#
##############################################################################
sub DisableEnableHubPort
{
    trace();
    my ($hub, $port, $delay, $hold) = @_;

    my $ret = GOOD;

    logInfo("Bypass port $port\n");
    $ret = VIXDisableHubPort($hub, $port);

    if ($ret != GOOD)
    {
        logInfo(">>>>>>>> DisableEnableHubPort:  Error on disable of port $port. <<<<<<<<\n");
        return ERROR;
    }

    if($hold >= 1)
    {
        # Hold Reset for X seconds
        DelaySecs( $hold );
    }

    logInfo("Activate port $port\n");
    $ret = VIXEnableHubPort($hub, $port);

    if ($ret != GOOD)
    {
        logInfo(">>>>>>>> DisableEnableHubPort:  Error on enable of port $port. <<<<<<<<\n");
        return ERROR;
    }

    # Delay Between Resets
    DelaySecs( $delay );

    return GOOD;
}

##############################################################################
#
#          Name: BypassBEHubPorts
#
#        Inputs: ip of the hub, loops, number of seconds between disables,
#                number of seconds to keep the port disabled, port1 of drive
#                bay, port2 of drive bay, usname and password of switch
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Select a port connected on a hub, turn off the port, Hold for
#                X seconds, enable the port, and delay for X seconds
#
#
##############################################################################
sub BypassBEHubPorts
{
    trace();
    my ($ipAddress, $loops, $delay, $hold, $driveBayPort, $seed, $password) = @_;

    my $hub;
    my $port = 0;
    my $portStatus;
    my $numberOfHubPorts = 0;
    my @portBitmapArray;
    my @controllerPorts;
    my $controllerPortIndex = 0;

    my @configMap;

    my $ret = GOOD;


    # set the zone to use all ports
    $portBitmapArray[0] = 255;

    # Login to the switch.  Use the username and password if they were
    # provided.
    logInfo("BypassBEHubPorts:  Logon to hub @ $ipAddress\n");
    $hub = VIXLogInToHub($ipAddress, $password);

    # Check to make sure that the login was successfull, otherwise try default.
    if ( !defined($hub) )
    {
        $hub = VIXLogInToHub($ipAddress);
    }

    # Check to make sure that the login was successfull, otherwise try fail.
    if ( !defined($hub) )
    {
        logInfo(">>>>>>>> BypassBEHubPorts:  Unable to login to hub $ipAddress. <<<<<<<<\n");
        return ERROR;
    }


    # Get the number of ports on the specified switch.
    $numberOfHubPorts = VIXGetNumberOfHubPorts($hub);
    if ($numberOfHubPorts == INVALID)
    {
        logInfo(">>>>>>>> BypassBEHubPorts: Could not get the number of hub ports <<<<<<<<\n");
        return ERROR;
    }

    logInfo("Initializing $numberOfHubPorts Vixel hub ports...");
    # Scan all ports to see which ones are connected
    for ( $port=1; $port <= $numberOfHubPorts; ++$port )
    {
        # Enable port
        logInfo("$port");
        $ret = VIXEnableHubPort($hub, $port);
        if ($ret != GOOD)
        {
            logInfo(">>>>>>>> BypassBEHubPorts:  Error on enable of port $port. <<<<<<<<\n");
            return ERROR;
        }
        # Is it a Controller Port or a Drive Bay Port
        if($port == $driveBayPort)
        {
            # Check Drive Bay Ports
            $portStatus = VIXGetPortStatus($hub, $port);
            if($portStatus eq VIX_STATUS_INSERTED)
            {
                $configMap[$port] = "D";
            }
            else
            {
                my $value = VIX_STATUS_INSERTED;
                my $res = $portStatus eq VIX_STATUS_INSERTED;
                logInfo(">>>>>>>> BypassBEHubPorts:  Result = $res, Drive Bay port $port($portStatus) $driveBayPort($value) not connected. <<<<<<<<\n");
                return ERROR;
            }
        }
        else
        {
            # Check Controller Ports
            $portStatus = VIXGetPortStatus($hub, $port);
            if($portStatus eq VIX_STATUS_INSERTED)
            {
                # Build Controller ports list
                $controllerPorts[$controllerPortIndex] = $port;
                ++$controllerPortIndex;
                $configMap[$port] = "C";
            }
            else
            {
                $configMap[$port] = "X";
            }
        }
    }

    # print configuration Map
    my $header = "          ";
    my $bar    = "----------";
    my $map    = "          ";
    for ($port=1; $port <= $numberOfHubPorts; ++$port)
    {
        if($port < 10)
        {
            $header = $header . " " . $port . " ";
            $bar =  $bar . "---";
            $map =  $map . " " . $configMap[$port] . " ";
        }
        else
        {
            $header = $header . " " . $port . " ";
            $bar = $bar . "----";
            $map = $map . " " . $configMap[$port] . "  ";
        }
    }
    logInfo("\n\nVixel hub BE configuration map:  \n");
    logInfo($header . "\n" . $bar . "\n" . $map . "\n\n");

    # Check to see if we have a minimum of two Controller Ports
    if(scalar(@controllerPorts) < 2)
    {
        logInfo(">>>>>>>> BypassBEHubPorts:  Not enough Controller Ports connected. <<<<<<<<");
        return ERROR;
    }

    # Randomly Enable and Disable ports
    srand($seed);

    logInfo("\nBypass port $loops times each Controller port Randomly with the seed of $seed. \n");

    # do the desired number of loops
    for( my $i = 0; $i < $loops; $i++ )
    {

        # Get port randomly
        $port = $controllerPorts[( (rand(scalar(@controllerPorts))*1000) % scalar(@controllerPorts) )] ;

        logInfo($i+1 . ".  Bypass port $port for $hold seconds, activate, and delay for $delay seconds\n");
        $ret = DisableEnableHubPort($hub, $port, $delay, $hold) ;
        if ( $ret == ERROR )
        {
            logInfo(">>>>>>>> BypassBEHubPorts: faild to disable/enable port. <<<<<<<<\n");
            return (ERROR);
        }
    }

    # Log out of the switch.
    if ( VIXLogOutOfHub($hub) == ERROR )
    {
        logInfo(">>>>>>>> BypassBEHubPorts:  An error occurred while logging out of the hub. <<<<<<<<");
        return ERROR;
    }
    return GOOD;
}

###############################################################################

=head2 TestNReconnectAll function

This function tests to see if we still have a connection to all controllers.

=cut

=over 1

=item Usage:

 my $rc = TestNReconnectAll( $coPtr, $attempts  );

 where: $coPtr is a pointer to a controller object list
        $attempts is the number of reconnect attempts to do (OPTIONAL,
                  default = 48)

=item Returns:

       $rc will be GOOD or ERROR. GOOD indicates we have a connection to
           all controllers. ERROR indicates there is no connection to
           one or more controllers.

=item Things to look for:

 If the test fails to reconnect, the controller may be powered off, or
 is failed.

=item Initial Conditions:

 Connections should have been established for all objects in the list.
 These connections provide the parameters for a reconnect, if needed.


=back

=cut


##############################################################################
#
#          Name: TestNReconnectAll
#
#        Inputs: controller object list pointer
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Loop through all controllers and see if a LAN
#                connection exists.
#
#
##############################################################################
sub TestNReconnectAll
{
    trace();
    my ($coPtr, $attempts ) = @_;

    my $ret;
    my $retFlag;
    my @coList;
    my $i;

    @coList = @$coPtr;

    $retFlag = GOOD;

    # just loop thru all controllers, verifying their connections

    for ( $i = 0; $i < scalar(@coList); $i++ )
    {
        $ret = TestNReconnect( $coList[$i], $attempts  );
        if ($ret != GOOD )
        {
            # set a flag for a failure but continue one to
            # check all controllers
            $retFlag = ERROR;
        }
    }

    return $retFlag;  # GOOD will mean all have connections
}

###############################################################################

=head2 TestNReconnect function

This function tests to see if we still have a connection to the controller.
If the connection is still good, we return. It the connection appears to be
bad, we attempt to reconnect. Goodness of the connection is determined
by an attempt to get the controller power up state. This command should always
work.

=cut

=over 1

=item Usage:

 my $rc = TestNReconnect( $ctlr, $times  );

 where: $ctlr is a controller object
        $attempts is the number of reconnect attempts to do (OPTIONAL,
                  default = 48)


=item Returns:

       $rc will be GOOD or ERROR. GOOD indicates we have a connection.
           ERROR indicates there is no connection to the controller.

=item Things to look for:

 If the test fails to reconnect, the controller may be powered off.

=item Initial Conditions:

 There should be a valid controller object that has been connected to
 the controller as the information within the object is used to make
 a new connection.


=back

=cut


##############################################################################
#
#          Name: TestNReconnect
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Makes sure there is a valid connection to the controller.
#                Test a command and if it times out reconnects to the controller.
#                Makes the connection using the existing controller object.
#
#
##############################################################################
sub TestNReconnect
{
    trace();
    my ($obj, $times ) = @_;

    my $ret;
    my $host;
    my $port;
    my $j;
    my $rc;
    my $oldTimeout;
    
    
    #
    # times is the number of times to retry the connection
    # attempts are 5 seconds apart
    #
    if ( !defined($times) ) {$times = 48; }
    if ( $times < 2       ) { $times = 48; }
    

    logInfo("      Check controller connection and login if needed. ");
    logInfo("      Socket errors may be seen....");

    # check to see if we are talking to the controller

    $oldTimeout = $obj->{TIMEOUT};    # save this

    $obj->{TIMEOUT} = 10;             # temporary short value


    # need to have a valid socket for this test
    # if no socket, we will be connecting for the first time
    if ( $obj->{socket} )
    {
        $ret = GetPowerUpState($obj);     # almost any command will do

        if ( $ret != INVALID )
        {
            # got an answer from the controller, connection is good
            $obj->{TIMEOUT} = $oldTimeout;   # restore old value, return
            return GOOD;
        }
    }

    # we got an error or timed out. Assume a timeout caused by
    # a lack of a connection. Attempt to reconnect.


    # get ip addr and port from existing object

    $host = $obj->{HOST};
    $port = $obj->{PORT};

    $obj->{TIMEOUT} = $oldTimeout;   # restore old value

    $obj->logout();


    $j = 1;
    $rc = 0;

    while ($rc == 0)
    {
        # Sleep for 5 second(s) before attempting to connect.
        sleep(5);

        print "Connection attempt # $j \r";
        # Attempt to reconnect the socket
        $rc = $obj->login($host, $port);
        $j++;

        # set a timeoput for this in case a controller is too dead
        # to reconnect.
        if ( $j > $times )
        {
            # didn't recover in 4 or 5 minutes, got a dead one
            logInfo(">>>>>>>> Failed to reconnect to controller $host <<<<<<<<");
            return ERROR;
        }
    }

    return GOOD;
}
###############################################################################

=head2 IsControllerAlive function

This function tests to see if we still have a connection to the controller.
If the connection is still good, we return GOOD, else ERROR.
=cut

=over 1

=item Usage:

 my $rc = IsControllerAlive( $ctlr  );

 where: $ctlr is a controller object


=item Returns:

       $rc will be GOOD or ERROR. GOOD indicates we have a connection.
           ERROR indicates there is no connection to the controller.

=item Things to look for:

 If the test fails to reconnect, the controller may be powered off.

=item Initial Conditions:

 There should be a valid controller object that has been connected to
 the controller as the information within the object is used to make
 a new connection.


=back

=cut


##############################################################################
#
#          Name: IsControllerAlive
#
#        Inputs: controller object
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Makes sure there is a valid connection to the controller.
#                Test a command and if it times out reconnects to the controller.
#                Makes the connection using the existing controller object.
#
#
##############################################################################
sub IsControllerAlive
{
    trace();
    my ($ctlr ) = @_;

    my $ret = GOOD;
    my $oldTimeout;
    my %rsp;


    # check to see if we are talking to the controller

    $oldTimeout = $ctlr->{TIMEOUT};    # save this

    $ctlr->{TIMEOUT} = 10;             # temporary short value


    # need to have a valid socket for this test
    # if no socket, we will be connecting for the first time


    if ( $ctlr->{socket} )
    {

        %rsp = $ctlr->powerUpState();

        if ( ! %rsp  )
        {
            $ret = ERROR;      # timeout
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            $ret = ERROR;      # some error
        }

    }
    else
    {
        $ret = ERROR;          # no socket, can't use
    }

    $ctlr->{TIMEOUT} = $oldTimeout;   # restore old value

    return $ret;

}

#######################################################################################
#
# This is the task menu for ICTest.pl and can be used by the XTC. It
# represtnts the choices for BasicCinfig().
#
#######################################################################################
sub IcTestMenu
{


    print "\n==================================================================================\n";


    print "==================================================================================\n";
    print "OPTIONS: \n\n";
    print "  1) N way, raids 0,1,5,10 small vdisks (servers alternate)\n";
    print "  2) N way same as 1) but, no hotspars \n";
    print "  3) san links  [using a shared drive bay] RAID 10 drives \n";
    print "  4) labels drives, makes raid 10 vdisks, no 2 way, no assoc  \n";
    print "  5) N way, mixed raids        \n";
    print "  6) labels drives, makes raid 10 vdisks, no 2 way, no assoc  \n";
    print "  7) labels drives, makes raid 5,10 vdisks, no 2 way, no assoc  \n";
    print "  8) (obsolete) \n";
    print "  9) (obsolete) \n";
    print " 10) N way, raids 0,1,5,10 small vdisks (SIDs based upon WWNs) \n";
    print " 11) san links  [using a shared drive bay] RAID 5 drives \n";
    print " 12) 1 way for 14 drive bay  \n";
    print " 13) N way for 14 drive bay all raid 5  \n";
    print " 14) N way for 14 drive bay all raid 10  \n";
    print " 15) N way for 14 drive bay all raid 10, all same, no disk groups \n";
    print " 16) N way for 14 drive bay all raid 0, all same, no disk groups \n";
    print " 17) N way Raids 0,1,10  multiple disk grps, not all assoc \n";
    print " 18) N way mixed raid 0,1,10 \n";
    print " 19) N way raids 0,10 only \n";
    print " 20) N way raids 0,1,10 multiple groups \n";
    print " \n";
    print " 21) enable write caching \n";
    print " 22) disable (global) write caching \n";
    print " \n";
    print " 23) N way tiny raids 0,10 multiple groups \n";
    print " 24) N way tiny raids 10 even/odd pdisk groups \n";
    print " 25) N way tiny raids 0,10 multiple groups \n";
    print " 26) N way tiny raids 1 even/odd pdisk groups \n";
    print " 27) N way raids 5,10 multiple groups \n";
    print " \n";
    print " 28) obsolete \n";
    print " 29) N way raids 0, 10, expanded vdisks\n";
    print " 30) view configuration    \n";
    print " 31) N way tiny raid 5, multiple groups  \n";
    print " 32) N way big raid 5, on all data disks  \n";
    print " \n";
    print " 40) N way, 26 small raids 0,1,10, multiple groups \n";
    print " 41) N way, 26 small raids 0,1,5,10, multiple groups \n";
    print " \n";
    print " 50) Test Menu    \n";
    print " 51) Single task Menu    \n";
    print " 52) Custom Configuration    \n";
    print " \n";
    print " 55) Add mirrors to current configuration    \n";
    print " \n";
    print " 61) N way, tiny raid 5,10 \n";
    print " 62) N way, tiny raid 10 \n";
    print " \n";
    print " 70) N way, raid 0,1,5,10 \n";
    print " 71) N way, raid 5,10 \n";
    print " 72) N way, raid 5,10  \n";
    print " 73) N way tiny raids 0,10 multiple groups \n";
    print " \n";
    print " 80) View License State      \n";
    print " \n";
    print " 81) N way, 20 source vdisks on one geolocation, raids 0,1,5,10, multiple groups \n";
    print " 82) N way, 20 source vdisks on multiple geolocations, raids 0,1,5,10, multiple groups \n";
    print " \n";
    print " 85) FE Simulator Configuration \n";
    print " \n";
    print " 86) Make 750 N way configuration, 15 vdisks only raid 10 \n";
    print " 87) Make 750 N way configuration, 26 small raids 0,1,5,10, multiple groups\n";
    print " \n";
    print " 90) Suicide prevention      \n";
    print " \n";
    print " 98), 99) Debug of the day.       \n";
    print " \n";
    print " 200) Exit       \n";
    print "\n Selections 23-27, 29, 31, 40, 41, 61, 62 and 73 will place vdisks on both sata and fibre drive bays.";
    print " \n\n";
    print "Enter an option: ";

    my $ans = <STDIN>;

    chomp ($ans);

    print "\n";

    return $ans;
}
##############################################################################
#
#          Name: MakeNWay
#
#        Inputs: objPtr
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: configure multiple controllers as a VCG
#
##############################################################################
sub MakeNWay
{
    trace();
    my ($objPtr) = @_;

    my $i;
    my %rsp;
    my $response;
    my @objList = @$objPtr;

    # make sure there are enough controller objects
    # or, we could do a findMaster here

#    if ( scalar(@objList) < 2 )
#    {
#        logError(">>>>> Failed, need at least two valid controller objects. <<<<<");
#        return (ERROR);
#    }

    # Assuming the first item is the master, add all others in as slaves

    for ( $i = 1; $i < scalar(@objList); $i++)
    {
        $response = AddController ($objPtr, $i);
        if ($response != GOOD)
        {
            return (ERROR);
        }
    }

    # get vcginfo from all

    for ( $i = 0; $i < scalar(@objList); $i++)
    {
        %rsp = $objList[$i]->vcgInfo(0);
        if ( ! %rsp  )
        {
            logError(">>>>> Failed to get vcginfo from controller $i <<<<<");
            return (ERROR);
        }
        else
        {
            if ( $rsp{STATUS} == PI_GOOD )
            {
                logInfo("VCGINFO for controller $i");
                logVCGInfo(%rsp);

            }
            else
            {
                logError(">>>>> Error getting vcginfo from controller $i <<<<<");
                PrintError(%rsp);
                return (ERROR);
            }
        }

    }


    return (GOOD);

}
###############################################################################

sub ExpandVdisks
{
    my ( $ctlr, $amountMB, $option) = @_;

    # expands all current vdisks by the specified amounts. Uses the parameter
    # from the first raid to specify the new raid. ICON won't mix raids, we
    # won't either.


    # Checks status of the drive and will not expand raid 10 that is mapped to
    # a server (because it can be initialized).


    my %info;
    my @oldRaids;
    my %vdisks;
    my $i;
    my $rtype;
    my %rsp;
    my $isOwned;
    my $r;
    my %ret;

    #
    # Check for option parm.  Current definitions -
    #   0 = Normal operation
    #   1 = Skip RAID inits.  Allow expand on mapped R10 VDisk
    #
    if ( !defined($option) )
    {
        $option = 0;
    }

    #
    # Get a list of existing raids
    #

    %info = $ctlr->raidList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raidList <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raidList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    $i = $info{LIST};

    @oldRaids = @$i;

    #
    # Get a list of the current vdisks. We will expand these.
    #

    %vdisks = $ctlr->virtualDisks();

    if ( ! %vdisks  )
    {
        logInfo(">>>>>>>> Failed to get response from virtualDisks <<<<<<<<");
        return ERROR;
    }

    if (%vdisks)
    {
        if ($vdisks{STATUS} == PI_GOOD)
        {
            if ($vdisks{COUNT} == 0)
            {
                logInfo("No virtual disks present, nothing to expand.");
                return GOOD;
            }
        }
        else
        {
            logInfo(">>>>>>>> Unable to retrieve  virtual disk information. <<<<<<<<");
            PrintError(%vdisks);
            return ERROR;
        }
    }


    #
    # For each vdisk
    #

    for ( $i = 0; $i < $vdisks{COUNT}; $i++ )
    {
        # get raidinfo

        logInfo("Expanding vdisk  $vdisks{VDISKS}[$i]{VID} ");

        %info = $ctlr->virtualDiskRaidInfo($vdisks{VDISKS}[$i]{RIDS}[0]);

        if ( ! %info  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from virtualDiskRaidInfo <<<<<<<<");
            return ERROR;
        }
        if ( $info{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from virtualDiskRaidInfo <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }


        #print ("   Checking VID $vdisks{VDISKS}[$i]{VID}, RAID $vdisks{VDISKS}[$i]{RIDS}[0]. Type is $info{TYPE}. \n");



        #
        # verify that it is OK to expand it ( is it mapped & raid 10)
        #


        $rtype = $info{TYPE};

        # got raid type, now get owned status

        %rsp = $ctlr->virtualDiskOwner($vdisks{VDISKS}[$i]{VID});

        if ( ! %rsp  )
        {
            logInfo(">>>>> Failed to get response from virtualDiskOwner <<<<<");
            return ERROR;
        }

        if ($rsp{STATUS} != PI_GOOD)
        {
            logInfo(">>>>> Unable to retrieve virtual Disk Owner for vdisk $vdisks{VDISKS}[$i]{VID}. <<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        # if the vdisk is owned, the number of devices will be non-zero


        if (   $rsp{NDEVS} == 0 )
        {
            $isOwned = 0;
        }
        else
        {
            $isOwned = 1;
        }

        # now do the test

        if ( $rtype == 4 && $isOwned == 1 )
        {
            # is raid 10 and owned, cannot expand
            # Unless option = 1
            if ($option != 1)
            {
                next;
            }
        }


        #
        # Get data for the first raid. We already did the raidinfo
        # so now just dig out the parameters.
        #

        #$rtype  = $info{TYPE};
        #$stripe = $info{SPS};
        #$depth  = $info{DEPTH};      # should be 2 for baby alpha
        #$parity = $info{DEPTH};

        # now the list of pdisks

        my @pdd;    # delclare here so it gets init'ed each time

        for ( $r = 0; $r < $info{PSDCNT}; $r++ )
        {
            $pdd[$r] = $info{PIDS}[$r]{PID}
        }

        #
        # Clone that raid, using the new size and do the expand
        #

        %rsp = $ctlr->virtualDiskExpand( $vdisks{VDISKS}[$i]{VID},   #  vdd to expand
                                         $amountMB * 2048,   #  $capacity,
                                         \@pdd,              #  $pdPointer,
                                         $info{TYPE},        #  $rtype,
                                         $info{SPS},         #  $stripe,
                                         $info{DEPTH},       #  $depth,
                                         $info{DEPTH},       # parity
                                         4,
                                         10,
                                         0,
                                         0);

        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>> Failed to get response from virtualDiskExpand <<<<<");
            return INVALID;
        }

        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>> Error from virtualDiskExpand <<<<<");
            PrintError(%rsp);
            return INVALID;
        }

    }

    #
    # now start inits on the new raids. Get a list of the current raids.
    # Check each raid to see if it was in the old list, if not, then
    # begin an init on that raid
    #



    %info = $ctlr->raidList();
    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raidList <<<<<<<<");
        return ERROR;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raidList <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }


    #
    # Skip init for option = 1
    #
    if ($option != 1)
    {
        for (my $i = 0; $i < $info{COUNT}; $i++)
        {

            if ( IsInList($info{LIST}[$i], \@oldRaids ) == 0 )
            {
                # the raid was not in the old list, init it


                %ret = $ctlr->virtualDiskInit($info{LIST}[$i]);

                if ( ! %ret )               # if no return from call
                {
                    logInfo(">>>>> Failed to get response from virtualDiskInit <<<<<");
                    return ERROR;
                }

                if ( ($ret{STATUS} != PI_GOOD) && ( $ctlr->PI_ERROR_INIT_IN_PROG != $ret{ERROR_CODE} ) )
                {
                    # if call returned an error
                    logInfo(">>>>> Error from virtualDiskInit <<<<< " .
                    "ERROR---Raid # $info{LIST}[$i] was NOT Initialized");
                    PrintError(%ret);
                    return ERROR;
                }

                # no error from virtualDiskInit

                logInfo("Initialize started on Raid # $info{LIST}[$i]");
            }
        }
    }

    #
    # return
    #

    return GOOD;

}
##############################################################################
sub GotRaid5
{
    my ($ctlr) = @_;

    # see if the controller has any raid 5 drives configured

    my %info;
    my $raid;

    logInfo("Looking to see if there are any raid 5 drives.");

    %info = $ctlr->raids();

    if ( ! %info  )              # if no return from call
    {
        logInfo(">>>>>>>> Failed to get response from raids command <<<<<<<<");
        return INVALID;
    }
    if ( $info{STATUS} != PI_GOOD )      # if call returned an error
    {
        logInfo(">>>>>>>> Error from raids command <<<<<<<<");
        PrintError(%info);
        return INVALID;
    }

    # for each raid
    for ( $raid = 0; $raid < $info{COUNT}; $raid++)
    {
        # look at the ASTATUS field

        print "     \n Checking raid $info{RAIDS}[$raid]{RID},".
            " type  = $info{RAIDS}[$raid]{TYPE} ";


        # if resync is in progress
        if ( $info{RAIDS}[$raid]{TYPE} == RAID_5 )
        {
            # return 1 if we had any
            print "\nAt least one found\n";
            return 1;
        }
    }

    print "\nNone found\n";

    return 0;     # no raid 5 found

}

##############################################################################
#
#          Name: GetAdminTime
#
#        Inputs: controller
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: This subroutine gets the time on controller
#
##############################################################################
sub GetAdminTime
{
    trace();

    my ( $ctlr ) = @_;

    my $msg;
    my %rsp;

    %rsp = $ctlr->GetTime();

    if (%rsp)
    {
        if ($rsp{STATUS} == GOOD)
        {
            $currentMgr->displayTime(%rsp);
            return GOOD;
        }
        else
        {
            $msg = "Unable to retrieve controller time.";
            return ERROR;
        }
    }
}
##############################################################################

1;   # we need this for a PM

