#! /usr/bin/perl 
# $Header$
##############################################################################
# File name:  TestLibs::FailOverSupport
#
# Desc: A set of library functions for integration testing. These focus on
#       controller fail-over support functions.
#
# Date: 04/15/2003
#
# Original Author:  Craig Menning
#
# Last modified by  $Author: EidenN $
# Modified date     $Date: 2006-09-20 08:56:32 -0500 (Wed, 20 Sep 2006) $
#
#   It is expected that the user will write a perl script that calls 
#   these.
#
#   Copyright 2002-2006 Xiotech Corporation. All rights reserved.
#
#   For Xiotech internal use only.
#
##############################################################################
=head1 NAME

TestLibs::FailOverSupport - Perl Tests to Fail Over XIOtech Storage Devices

$Id: FailOverSupport.pm 13859 2006-09-20 13:56:32Z EidenN $

=head1 SUPPORTED PLATFORMS

=begin html

 <UL> 
     <LI>Linux</LI> 
     <LI>Windows</LI> 
 </UL>

=end html

=head1 SYNOPSIS

This document describes the Perl Scripts to Test Controller 
Fail-over. This library is a collection of functions for fail-over testing.

=head1 DESCRIPTION

Test Functions Available (exported)


=cut

#                         
# - what I am
#

package TestLibs::FailOverSupport;

#
# - other modules used
#

use warnings;
use lib "../CCBE";
use XIOTech::cmdMgr;
use XIOTech::cmUtils;
use XIOTech::constants;
use XIOTech::errorCodes;
use XIOTech::xiotechPackets;
use XIOTech::PI_CommandCodes;
use XIOTech::logMgr;
use TestLibs::Logging;
use TestLibs::Constants;
use TestLibs::IntegCCBELib;
use TestLibs::utility;
use TestLibs::Fibre;
use Dumpvalue;

my $dumper = new Dumpvalue;
my $dumper2 = new Dumpvalue;

#
# - perl compiler/interpreter flags 'n' things
#

#use Getopt::Std;
#use FileHandle;
#use Text::Abbrev;
#use Cwd;
#use IO::Handle;

use strict;

#
# - A note on parameters. 
#
#   Most parameters are scalars, single values. However,
#   in some cases objects or addresses will be passed. The return from the
#   functions is generally a good/bad indication. If it is needed to
#   return additional data, or an array, then a pointer shall be passed in.
#   Global data will be avoided at all cost.
#
#   controllerIDs are OBJECTS. 
#
#
BEGIN {
    use Exporter   ();
    our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

    # set the version for version checking
    $VERSION     = 1.00;

    @ISA         = qw(Exporter);


#  need to fix callers for these
#                           &BrocadeStressDetermine
#                           &FailOverController
#                           &GetFailMethod
    @EXPORT      = qw(
                     
                     
                      &_MyPrintInterface
                      &_unFailInterface

                      &AreWeAlive

                      &BrocadeCheck1
                      &BrocadeStressApply
                      &BrocadeStressDetermine

                      &BuildGoodList
                      &BuildResources
                      &BuildResourcesFromControllers

                      &CleanUpUnfailAll
                       
                      &DisableInactivatePowerOff
                      
                      &ExtControl

                      &FailOverController
                      &FailThings
                      &FCLoopPrimitive
                      &FindNextFailedCtlr

                      &GetFailMethod
                      &GetFEPortMap
                      &GetGoodCtlrs
                      &GetLiveObjects
                      &GetNonFailMethod

                      &MoveTarget

                      &NWFType2Name
                      
                      &PostBStats
                      &PostSummary
                      &PowerCheck2
                      &PrintResources

                      &SelectRandom
                      
                      &UnfailAll2
                      &UnfailNonControllers

                      &ValidateType
                      &VCGInfoCheck
                      &VCGInfoCheck2

                      &WhatToFail
                      &WhichCtlr
                     
                     
                     
                      
                      );
    #%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

    TestLibs::Logging::logVersion(__PACKAGE__, q$Revision: 13859 $);
}
    our @EXPORT_OK;


###############################################################################



######################## Private Functions For DownFELoop functions ############
 

sub _MyPrintInterface
{
    my ($iface) = @_ ;
    my @ifaceNames =  ("A0", "A1", "A2", "A3", "B0", "B1", "B2", "B3", "A", "B");
    my $msg;
    my $flag ;

    my $i = TestLibs::FailOver::_MyIndex($iface) ;

    if ($i < scalar(@ifaceNames))
    {
        $msg = $ifaceNames[$i] ;
        $flag = GOOD ;
    }
    else
    {
        $msg = "Unknown interface\n" ;
        $flag = ERROR ;
    }
    logInfo($msg);
    return $flag ;
}



##############################################################################
# UnFail an interface
#    Inputs:
#           obj1 = master controller object
#           csn  = sn of controller to unfail interface
#           interface = interface to unfail
##############################################################################
sub _unFailInterface
{
    my $msg ;
    logInfo ("\n");

    my ($obj1, $ctrlSN, $interface) = @_;
    my %rsp;

    if (!defined($ctrlSN))
    {
        logInfo ("Missing controller serial number.\n");
        return;
    }
        
    if (!defined($interface))
    {
        logInfo("Missing interface ID.\n");
        return;
    }
    
    %rsp = $obj1->UnfailInterface($ctrlSN, $interface);

    if (%rsp)
    {
        if ($rsp{STATUS} == PI_GOOD)
        {
            logInfo ("Unfail interface requested.\n");
        }
        else
        {
            my $msg = "ERROR: Unable to unfail interface.";
            TestLibs::scrub::displayError($msg, %rsp);
        }
    }
    else
    {
        logInfo ("ERROR: Did not receive a response packet.\n");
        logout();
    }

    logInfo("\n");
}

################################################################################




##############################################################################


##############################################################################


##############################################################################


##############################################################################



##############################################################################
#
#          Name: AreWeAlive
#
#        Inputs: item index list pointer, 
#                timeout value
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: A loop to determine of the QLogic cards are ready for use
#                after we have messup the fe fibre connections.
#
##############################################################################

sub AreWeAlive
{
    my ($coPtr, $timeOut, $target ) = @_;

    my @coList;
    my $i;
    my $numCtlrs;
    my $ret;
    my %rsp;
    my $count;
    my $tMap;
    my $cMap;
    my $current;
    my $match;
    my $endTime;

    $endTime = time + $timeOut;

    @coList = @$coPtr;

    # loop until the ports match or we time out
    logInfo("Testing to see it the system is ready to continue...");
    $count = 0;

    do
    {
        $match = 0;    # indicate no match
        $count++;

        $current = GetFEPortMap( $coPtr, 2);

        $cMap = sprintf ( "0x%04x ",$current);
        $tMap = sprintf ( "0x%04x ",$target);
        print ("Attempt $count, target map: $tMap, current map: $cMap          \r"); 
        
        if ( $current == $target )
        {
            $match = 1;
        }

        sleep(5);
    }
    while ( ( time < $endTime ) && ($match == 0 ) );

    # if we've matched, things are good

    if  ($match != 0)
    {
        print "\n";
        return GOOD;
    }

    # no match, must have timed out
    
    return ERROR;

}
##############################################################################
#
#          Name: AreWeAlive
#
#        Inputs: item index list pointer, 
#                timeout value
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: A loop to determine of the QLogic cards are ready for use
#                after we have messup the fe fibre connections.
#
##############################################################################

sub GetFEPortMap
{
    my ( $coPtr, $count) = @_;

    my $map;
    my $i;
    my $ctlr;
    my @coList;
    my $numCtlrs;
    my %rsp;
    my $sz;
    my $j;

    @coList = @$coPtr;

    $map = 0;

    $numCtlrs = min ( 2, scalar(@coList));

    for ( $i = 0; $i < $numCtlrs; $i++ ) 
    {
        $ctlr = $coList[$i];
            
        %rsp = $ctlr->getPortList(PI_PROC_FE_PORT_LIST_CMD, 5);

        if ( ! %rsp )
        {
            # no response
            return ERROR;
        }
        elsif ($rsp{STATUS} == 1)             # 1 is bad
        {
            logInfo(">>>>>>>> Failed: getPortList returned an error <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }

        $sz = 1 + $#{$rsp{LIST}};

        #print "list type, = $i, size = $sz \n";

        for ( $j = 0; $j< $sz; $j++ )
        {
            
            #print "list has $rsp{LIST}[$j] \n";

            $map |= (1 << ( (4* $i) + $rsp{LIST}[$j] ));
            
        }

    }

    
    return $map;

}
##############################################################################

##############################################################################
#
#          Name: PostBStats
#
#        Inputs: a data hash
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: just prints the data
#
##############################################################################

sub PostBStats
{
    my (%statsB) = @_;

    logInfo(" $statsB{PC} loops complete using Power Cycle as the stress.");
    logInfo(" $statsB{RB} loops complete using Brocade reboots as the stress.");
    logInfo(" $statsB{RZ} loops complete using rezoning as the stress.");
    logInfo(" $statsB{LIP} loops complete using LIP as the stress.");
    logInfo(" $statsB{LIPA} loops complete using LIP all as the stress.");
    logInfo(" $statsB{RQ} loops complete using a QLogic reset as the stress.");
    logInfo(" $statsB{RQA} loops complete using multiple QLogic resets as the stress.");
    logInfo(" $statsB{PDC} loops complete using Port Down as the stress.");

    return;
}


##############################################################################
#
#          Name: BrocadeCheck1
#
#        Inputs: controller list pointer, data arrays
#
#       Outputs: GOOD or ERROR
#
#  Globals Used: none
#
#   Description: Check to see if all ports/WWNs are back
#
##############################################################################
sub BrocadeCheck1
{
    my ($master, $slave, $mData, $sData ) = @_;

    my @coList;
    my @mNodes;
    my @sNodes;
    my $ret;


    logInfo("Collecting Current node lists");

    @mNodes = FENodes( $master );
    @sNodes = FENodes( $slave );


    logInfo("Comparing master node lists");

    $ret = CompareLists2( $mData, \@mNodes);
    if ($ret != GOOD)
    {
        return ERROR;
    }


    logInfo("Comparing slave node lists");

    $ret = CompareLists2( $sData, \@sNodes);
    if ($ret != GOOD)
    {
        return ERROR;
    }

    

    return (GOOD);   
}

##############################################################################
#
#          Name: BrocadeStressDetermine
#
#        Inputs: controller list pointer, Moxa IP Address, Moxa, loop count
#
#       Outputs: the three parameters for the brocade stress
#
#  Globals Used: none
#
#   Description: Determines the parameters for BrocadeStressApply.
#
##############################################################################
sub BrocadeStressDetermine
{
    my ( $stress, $loop, $coPtr, $mipPtr, $mmPtr, $bipPtr  ) = @_;

    my @coList;
    my @mipList;
    my @mmList;
    my @bipList;
    my @stresses;
    my $t;

    @coList  = @$coPtr;
    @mipList = @$mipPtr;
    @mmList  = @$mmPtr;
    @bipList = @$bipPtr;

    $stress = uc ($stress);

    @stresses = ( "PC", "RQ", "RB", "RZ", "LIP", "RQA", "LIPA");



    # this was added as the XTC was not giving me any moxa data at one time
    if (scalar(@mipList) == 0 )
    {
        # hmmm, no moxa for us to use change PC to RB
        $stresses[0] = "RB";
    }

    if ( $stress eq "RND" )
    {
        # random one of the following
        $t = randomInt(0, (scalar(@stresses) - 1));
        $stress = $stresses[$t];
    }

    if ( $stress eq "PC" )
    {
        # power cycle the first Brocade
        # pass the ip addr of the moxa and the channel number
        return ("PC", $mipList[0], $mmList[0]);
    }

    if ( $stress eq "RQ" )
    {
        # reset qlogics on the first controller
        # pass the controller object and the chennel number
        return ("RQ", $coList[0], ($loop % 4) );
    }

    if ( $stress eq "RQA" )
    {
        # reset qlogics on the first controller
        # pass the controller object and the chennel number
        return ("RQA", $coList[0], 0 );
    }

    if ( $stress eq "RB" )
    {
        # reboot the first Brocade
        # pass the brocade IP addr
        return ("RB", $bipList[0], 0 );
    }

    if ( $stress eq "RZ" )
    {
        # rezone the first Brocade
        # parameters TBD
        return ("RZ", $bipList[0], 0 );
    }

    if ( $stress eq "LIP" )
    {
        # LIP the qlogics on the controller
        # send the controller object and the channel
        
        $t = min(2, scalar(@coList));
        $t = int($loop/4) % $t;

        return ("LIP", $coList[ $t], ($loop % 4));
    }

    if ( $stress eq "LIPA" )
    {
        # LIP the qlogics on the controller
        # send the controller object and the channel
        
        $t = min(2, scalar(@coList));
        $t = $loop % $t;
        return ("LIPA", $coList[ $t], 0);
    }


    return ("INVALID", "INVALID", "INVALID");   # note, these are strings...
}

##############################################################################
#
#          Name: BrocadeStressApply
#
#        Inputs: a stress selector,        (one of PC, RQ, RB, RZ, LIP)
#                stress parm 1, 
#                stress parm 2,
#                stress parm 3,
#                stress parm 4
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Applies the stress to the brocade. Since this may be done
#                from the controller, we also need the controller objects
#
#                The stress determines how the two parms are handled...
#
#                <stress>:  <parm1> <parm2> <parm3> <parm4)
#                --------   ------- ------- ------- -------
#                    PC     <moxa IP addr> <moxa channel>
#                    RQ     <ctlr object> <FE Qlogic channel>
#                    RB     <Brocade IP addr> <unused> <user> <password>
#                    RZ     <Brocade IP Addr> <TBD> <user> <password>       not yet implemented
#                   LIP     <ctlr object> <FE QLogic channel>
#                   PDC     <switch IP addr> <loops> <user> <password>
# 
#                PC: power cycle the Brocade switch
#                RQ: reset a Qlogic card
#                RB: reboot the Brocade
#                RZ: rezone the switch                   not implemented
#                LIP: LIP for a QLogic card            
#
#
#
##############################################################################
sub BrocadeStressApply
{
    my($stress, $sParm1, $sParm2, $sParm4, $sParm5) = @_;

    # declare variables
    my $ret;
    my %rsp;
    my $t;
    my $loop;

    $stress = uc ( $stress );          # convert to upper case


    print (" in BrocadeStress with  $stress, $sParm1, $sParm2 \n");

    ################################################################
    # input was PC, moxa IP, moxa channel             POWER CYCLE
    ################################################################


    # Determine the stress and do it
    if( $stress eq "PC" )
    {
        # power cycle the Brocade
        
        logInfo("Power Cycle the Brocade Switch");

        # power cycle the slave
        logInfo("Power Cycle the Brocade switch ");
        $ret = TestLibs::IntegCCBELib::PowerCycle($sParm1, $sParm2);
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Failed to power cycle the Brocade switch (IP=$sParm1 , chan=$sParm2 )  <<<<<<<<");
            return ERROR;
        }

        # now the switch does take forever to reboot ( like 5 minutes )

    }

    
    ################################################################
    # input was RQ, ctlr, channel                    RESET QLOGIC
    ################################################################
    
    if( $stress eq "RQ" )
    {
        # reset the QL adapter (which one)
        
        logInfo("Reset the QLogic card on port $sParm2");

        %rsp = $sParm1->resetQlogicFE($sParm2, $sParm1->RESET_QLOGIC_RESET_INITIALIZE);

        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from resetQlogicFE <<<<<<<<");
            return ERROR;
        }
        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            
            if ( $rsp{ERROR_CODE} != $sParm1->PI_ERROR_INV_CHAN )
            {

                logInfo(">>>>>>>> Error from resetQlogicFE <<<<<<<<");
                PrintError(%rsp);
                return ERROR;
            }
            else
            {
                logInfo("No card on channel $sParm2");
            }
        }



    }

    ################################################################
    # input was RQA, ctlr, channel                    RESET QLOGIC
    ################################################################
    
    if( $stress eq "RQA" )
    {
        # reset the QL adapter (which one)
        
        logInfo("Reset each QLogic card ");

        for ( $t = 0; $t < 4; $t++ )
        {
            %rsp = $sParm1->resetQlogicFE($t, $sParm1->RESET_QLOGIC_RESET_INITIALIZE);

            if ( ! %rsp  )              # if no return from call
            {
                logInfo(">>>>>>>> Failed to get response from resetQlogicFE <<<<<<<<");
                return ERROR;
            }
            if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
            {
            
                if ( $rsp{ERROR_CODE} != $sParm1->PI_ERROR_INV_CHAN )
                {

                    logInfo(">>>>>>>> Error from resetQlogicFE <<<<<<<<");
                    PrintError(%rsp);
                    return ERROR;
                }
                else
                {
                    logInfo("No card on channel $t");
                }
            }

            sleep(2);     # a pause between each
        }


    }

    
    ################################################################
    # input was RB, switch IP addr, unused         REBOOT BROCADE
    ################################################################



    if( $stress eq "RB" )
    {
        
        logInfo("Reboot the Brocade Switch at IP $sParm1");

        $t = BSWLogInToSwitch( $sParm1, $sParm4, $sParm5 );        # The IP address of the switch.
        if ( !$t )
        {
            logInfo("Unable to log into the Brocade switch");
            return ERROR;
        }

        # we are logged in, now reboot it

        $t->print("reboot");

        # the switch will go away now

    }

    
    ################################################################
    # input was RZ, switch IP addr, channel         REZONE BROCADE
    ################################################################

    if( $stress eq "RZ" )
    {
        # rezone the switch
        logInfo("Rezoning the switch is currently a nop.");
    }

    
    ################################################################
    # input was LIP, ctlr, channel                          LIP 
    ################################################################

    if( $stress eq "LIP" )
    {
        # send a LIP
        
        logInfo("Send a LIP from QLogic channel $sParm2");

        $ret = TestLibs::IntegCCBELib::GenericMRP($sParm1, 0x520, 8, 
                                       "000000000000" .
                                       DecToAsciiHexData($sParm2, "short") .
                                       "00000000" );
        if ( $ret != GOOD ) 
        {
            return ERROR;
        }
       
    }
    
    ################################################################
    # input was LIPA, ctlr, channel                    LIP ALL QL
    ################################################################

    if( $stress eq "LIPA" )
    {
        # send a LIP
        
        logInfo("Send a LIP from each QLogic channel ");

        # channel 0
        $ret = TestLibs::IntegCCBELib::GenericMRP($sParm1, 0x520, 8, 
                                       "000000000000" .
                                       DecToAsciiHexData(0, "short") .
                                       "00000000" );
        if ( $ret != GOOD ) 
        {
            return ERROR;
        }

        # channel 1
        $ret = TestLibs::IntegCCBELib::GenericMRP($sParm1, 0x520, 8, 
                                       "000000000000" .
                                       DecToAsciiHexData(1, "short") .
                                       "00000000" );
        if ( $ret != GOOD ) 
        {
            return ERROR;
        }

        # channel 2
        $ret = TestLibs::IntegCCBELib::GenericMRP($sParm1, 0x520, 8, 
                                       "000000000000" .
                                       DecToAsciiHexData(2, "short") .
                                       "00000000" );
        if ( $ret != GOOD ) 
        {
            return ERROR;
        }

        # channel 3
        $ret = TestLibs::IntegCCBELib::GenericMRP($sParm1, 0x520, 8, 
                                       "000000000000" .
                                       DecToAsciiHexData(3, "short") .
                                       "00000000" );
        if ( $ret != GOOD ) 
        {
            return ERROR;
        }
       
    }

    ################################################################
    # input was PDC, switch IP addr, loops           CYCLE PORTS 
    ################################################################

    if( $stress eq "PDC" )
    {
        my $t;
        
        logInfo("Fibre Channel loop cycle test at IP $sParm1, $sParm2 loops to do");

        $t = BSWLogInToSwitch( $sParm1, $sParm4, $sParm5  );       
        if ( !$t )
        {
            logInfo("Unable to log into the Brocade switch");
            return ERROR;
        }

        # we are logged in, now do the port loop


        # get a prompt
        $t->print("");

        $t->waitfor('/Switch:admin>.*$/');

            # Brocade commands used......
            #   portDisable             Disable a specified port
            #   portEnable              Enable a specified port
            #   exit


        $loop = 1;
        while ( $loop <= $sParm2 )
        {
    
            print " Begin loop # $loop\n";

            # disable 1st port
            $t->print("portDisable 1");             # <<<<<<<< PORT
            $t->waitfor('/Switch:admin>.*$/');
            sleep 5;
            
        
            # enable 1st port                       # <<<<<<<< PORT
            $t->print("portEnable 1");
            $t->waitfor('/Switch:admin>.*$/');
            sleep 5;
            
        
            $loop++;
    
        }

    }
    
    
    # give the system some minimal recovery opportunity
    logInfo("Pausing for 10 seconds");
    DelaySecs(10); 

    return GOOD;

}

##############################################################################
#
#          Name: FCLoopPrimitive
#
#        Inputs: controller object, FE or BE, option, port, option2
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Loop that tests failover for various failure types
#                Uses the moxa to cycle power   
#                Loop Count defaults to 2000 if not specified
#
##############################################################################
sub FCLoopPrimitive
{
    trace();                        # This allows function tracability

    my ($ctlr, $proc, $option, $port, $option2 ) = @_;
    
    my $cmd;

    $cmd = 0x520;



    return GOOD;

}

###############################################################################

###############################################################################
###############################################################################


sub  ExtControl
{
    my ($index, $how2fail, $dir , $fCtlPtr) = @_;

    my $cString;
    my $case;
    my $ret;
    my @parts;

    $case = INVALID;

    if ( $how2fail eq "FEPULL" &&  $dir eq "FAIL" ) # FE fail
    {
        $case = "FE_OPEN";
    }

    if ( $how2fail eq "FEPULL" &&  $dir eq "RESTORE" ) # FE restore
    {
        $case = "FE_CLOSE";
    }

    if ( $how2fail eq "BEPULL" &&  $dir eq "FAIL" ) # BE fail
    {
        $case = "BE_OPEN";
    }

    if ( $how2fail eq "BEPULL" &&  $dir eq "RESTORE" ) # BE restore
    {
        $case = "BE_CLOSE";
    }

    if ( $case eq INVALID )
    {
        # now match for test cases
        return ERROR;
    }

    # now do the call
    if ( !$fCtlPtr->{$index}->{$case})
    {
        logInfo("The external control string has not been defined.");
        logInfo("  Index = $index, Case = $case, method = $how2fail:$dir ");
        return ERROR;
    } 

    $cString = $fCtlPtr->{$index}->{$case};
    if ($cString eq INVALID)
    {
        logInfo("The external control string has is undefined.");
        logInfo("  Index = $index, Case = $case, method = $how2fail:$dir ");
        return ERROR;
    }


    @parts = split(/\s+/, $cString);

    #logInfo("  Index = $index, Case = $case, method = $how2fail:$dir ");
    logInfo ("Executing system call: $cString ");

    $ret = system(@parts);

    if ($ret != 0)
    {
        logInfo("System call failed, returned $ret");
        return ERROR;
    }

    return GOOD;

}
###############################################################################

=head2 GetFailMethod function

This is a function that is used to filter the user specified fail method. If
the user has asked for a specific fail method, then that is returned. If a 
random method was requested, one is selected and returned.


=cut

=over 1

=item Usage:

 my $rc = GetFailMethod($input);
 
 where $input is the user requested failure method
       

=item Returns:

       $rc will be a failure method.

=item Description:
 
 The failure method is one of the following.

 BEET - back end processor error trap
 FEET - front end processor error trap
 CCBET - CCB processor error trap
 RET - random processor error trap
 PC - power off the controller
 FC - fail using mrp command
 RND - random one of  BEET, FEET, CCBET, PC (this list may change)

 RET and RND are random and will changes each time the function is called.



=back

=cut


##############################################################################
#
#          Name: GetFailMethod
#
#        Inputs: requested method
#
#       Outputs: a method to use for failing the contoller
#
#  Globals Used: none
#
#   Description: Select means to failover a controller. Possible methods
#                are: 
#                     BEET = back end error trap
#                     FEET = front end error trap
#                     CCBET = CCB error trap
#                     RET = random error trap (one of above 3)
#                     RND = random (one of BE, FE, CCB, QLF) 
#                     FC  = use VCGFAILCONTROLLER
#                     PC = just power down controller
#
#                If one of the non-random methods is supplied, it is 
#                returned. If one of the random methods is supplied, a
#                non-random method is selected randomly and returned. 
#
##############################################################################
sub GetFailMethod
{
    trace();                        # This allows function tracability

    my ($input) = @_;
    
    my @possible;
    my $index;

    # this list contains all the supported possible (but not random) ways
    # to fault a controller

    @possible = ("BEET", "FEET", "CCBET", "FC", "IC", "PC" );
    
    $input = uc($input);       # convert to upper case
    
    # handle the just return what was supplied cases first

    if ( $input eq "BEET"   ||
         $input eq "FEET"   ||
         $input eq "CCBET"  ||
         $input eq "FEPULL" ||
         $input eq "BEPULL" ||
         $input eq "PC"     ||
         $input eq "IC"     ||
         $input eq "FC"  )
    {
        return $input;
    }

    # now the random cases

    #
    # random error trap (relies on members of possible 0..2 )
    #

    if (  $input eq "RET")
    {
        # a random one of the first 3 possibilities
        $index = TestLibs::utility::randomInt( 0, 2);
        return  $possible[$index];
    }

    #
    # random for all possibilities
    #
    if (  $input eq "RND")
    {
        # a random one of the possibilities
        $index = rand(@possible);
        return  $possible[$index];
    }
    
    # a default case

    return "PC";


}

###############################################################################

=head2 GetNonFailMethod function

This is a function used to select a failure method to be tried on a
controller. The controller is in a state that should not allow the
selected method to cause the controller to fail.


=cut

=over 1

=item Usage:

 my $rc = GetNonFailMethod($input);
 
 where $input is the user requested failure method
       

=item Returns:

       $rc will be a failure method.

=item Description:
 
 The failure method is one of the following.  (This list will change)

 PC - power off the controller
 FC - fail using mrp command
 RND - random one of  FC, PC (this list may change)

 RND is random and will changes each time the function is called.




=back

=cut



##############################################################################
#
#          Name: GetNonFailMethod
#
#        Inputs: requested method
#
#       Outputs: a method to use for failing the contoller
#
#  Globals Used: none
#
#   Description: Select means to failover a controller. Possible methods
#                are: 
#                     RND = random (one of BE, FE, CCB, QLF) 
#                     FC  = use VCGFAILCONTROLLER
#                     PC = just power down controller
#
#                If one of the non-random methods is supplied, it is 
#                returned. If one of the random methods is supplied, a
#                non-random method is selected randomly and returned. 
#
##############################################################################
sub GetNonFailMethod
{
    trace();                        # This allows function tracability

    my ($input) = @_;
    
    my @possible;
    my $index;

    # this list contains all the supported possible (but not random) ways
    # to fault a controller

    @possible = ( "FC", "PC");       #                
    $input = uc($input);       # convert to upper case
    
    # handle the just return what was supplied cases first

    if ( $input eq "PC"     ||
         $input eq "FC"  )
    {
        return $input;
    }

    # now the random cases


    #
    # random for all possibilities
    #
    if (  $input eq "RND")
    {
        # a random one of the possibilities
        $index = rand(@possible);
        return  $possible[$index];
    }

    # a default case

    return "PC";
}

###############################################################################

=head2 FailOverController function

This is a function used to select a failure method to be tried on a
controller. The controller is in a state that should not allow the
selected method to cause the controller to fail.


=cut

=over 1

=item Usage:

 my $rc = FailOverController($coPtr, $ctlr, $method );
 
 where $coPtr is a pointer to a list of controller objects
       $ctlr is the index into the list for the controller to fail
       $method is how the controller will be failed
       

=item Returns:

       $rc GOOD if no errors, ERROR otherwise. This reflects the
           result of the command that causes the failure and does
           not indicate if the controller is actually failed.

           An unknown method will just return GOOD with no action taken.

=item Description:
 
 The failure method is one of the following.  (This list may change)

 BEET - back end processor error trap
 FEET - front end processor error trap
 CCBET - CCB processor error trap
 BE - back end processor error trap
 FE - front end processor error trap
 CCB - CCB processor error trap
 FC - fail using mrp command





=back

=cut



##############################################################################
#
#          Name: FailOverController
#
#        Inputs: controller list pointer, controller to fail, method
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Generic means to failover a controller. Possible methods
#                are: 
#                     BE = back end error trap
#                     FE = front end error trap
#                     CCB = CCB error trap
#                     QLF = hold fe qlogics reset
#                     FC = Fail using VCGFAILCONTROLLER
#
##############################################################################
sub FailOverController
{
    trace();                        # This allows function tracability

    my ($coPtr, $ctlr, $method ) = @_;

    my $ret; 
    my @possible;
    my $index;
    my @coList;
    my $master;
    my $sn;

    @coList = @$coPtr;           # make array from pointer
    
    $method = uc($method);       # convert to upper case
    
    #
    # first the error traps, FE, BE, CCB
    #
    
    if (  $method eq "BE"    ||
          $method eq "FE"    ||
          $method eq "CCB"   ||
          $method eq "BEET"  ||
          $method eq "FEET"  ||
          $method eq "CCBET"   )
    {

        # correct input to match requirements of the fcn call
        if ( $method eq "BEET" ) { $method = "BE";  }
        if ( $method eq "FEET" ) { $method = "FE";  }
        if ( $method eq "CCBET") { $method = "CCB"; }
        
        print "Errortrapping $method \n";
        $ret = TestLibs::IntegCCBELib::ErrorTrapController( $coList[$ctlr], $method );
        return $ret;
    }


#    #
#    # hold all QL reset on FE
#    #
#
#    if (  $method eq "QLFALL")
#    {
#        #  4th parm conforms to option for RESETQLOGIC mrp
#        
#        #print "Failing using RESETQLOGIC FE ALL 5 \n";
#        #$ret = TestLibs::IntegCCBELib::QLReset( $coList[$ctlr], "FE", "ALL", 5 );    # 1 is reset only
#        
#        print "Failing using RESETQLOGIC FE ALL 4 (twice) \n";
#        $ret = TestLibs::IntegCCBELib::QLReset( $coList[$ctlr], "FE", "ALL", 4 );    # 1 is reset only
#        DelaySecs(10);
#        $ret = TestLibs::IntegCCBELib::QLReset( $coList[$ctlr], "FE", "ALL", 4 );    # 1 is reset only
#
#        return $ret;
#    }

    
    #
    # all loops down on FE (requires switch control)
    #

    # ............... skip this one for now



    #
    # just 'fail' the controller
    #


    if (  $method eq "FC")
    {
        # VCGFAILCONTROLLER
        $sn = TestLibs::IntegCCBELib::GetSerial($coList[$ctlr]);

        $master = TestLibs::IntegCCBELib::FindMaster( $coPtr );
        if ( $master == INVALID )
        {
            logError(">>>>>>>> Failed to find the new master controller  <<<<<<<<");
            return ERROR;
        }

        $ret = TestLibs::IntegCCBELib::FailController( $coList[$master], $sn );
        return $ret;
    }

    if (  $method eq "IC")
    {
        # VCGINACTIVATECONTROLLER

        $sn = TestLibs::IntegCCBELib::GetSerial($coList[$ctlr]);

        #
        # If this is a Wookiee controller, set the mode bit to prevent the 
        # controller from powering off when it is inactivated.  Otherwise
        # the controller will power off and will not power back up when 
        # power is cycled.
        #
        if ( $coList[$ctlr]->{CONTROLLER_TYPE} != CTRL_TYPE_BIGFOOT )
        {
            $ret = DisableInactivatePowerOff($coList[$ctlr]);
            if ( $ret != GOOD )   
            {
                logInfo(">>>>>>>> Error from DisableInactivatePowerOff <<<<<<<<");
                return ERROR;
            }
        }        
        
        #
        # Inactivate the controller
        #
        my %rsp = $coList[$ctlr]->vcgInactivateController($sn);
        

        if ( ! %rsp  )              # if no return from call
        {
            logInfo(">>>>>>>> Failed to get response from VCG INACTIVATE CONTROLLER <<<<<<<<");
            return ERROR;
        }

        if ( $rsp{STATUS} != PI_GOOD )      # if call returned an error
        {
            logInfo(">>>>>>>> Error from VCG INACTIVATE CONTROLLER <<<<<<<<");
            PrintError(%rsp);
            return ERROR;
        }
        
        return GOOD;
    }


    return GOOD;
}

###############################################################################


###############################################################################


#######################################################################

###############################################################################




###############################################################################

=head2 ValidateType function

Checks to see if the requested failure method is valid or not.



=cut

=over 1

=item Usage:

 my $rc = ValidateType( $method, $hashPtr );
 
 where,
        $method is the desired means to fail the controller
        $hashPtr is a pointer to the hash for BEPULL and FEPULL 

=item Returns:

       $rc GOOD if valid, ERROR otherwise. 

=item Description:
 
 Just checks the requested method against a list of valid values.

=back

=cut

##############################################################################
#
#          Name: ValidateType
#
#        Inputs: failure method
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: Generic means to failover a controller. Possible methods
#                are: 
#                     BE = back end error trap
#                     FE = front end error trap
#                     CCB = CCB error trap
#                     FC = Fail using VCGFAILCONTROLLER
#                     IC = Fail using VCGINACTIVATECONTROLLER
#                     BEPULL = Fail by pulling all BE cables
#                     FEPULL = Fail by pulling all FE cables
#
##############################################################################
sub ValidateType
{
    trace();                        # This allows function tracability

    my ($type, $hPtr, $testID ) = @_;
    
    
    #
    # $tID and $testID allow us to validate based upon who the 
    # caller is. If #testID is not passed, legacy callers are assumed.
    # Otherwise, add checks for the newer callers.
    #
    
    my $tID = 0;               # old FailoverLoop

    if ( defined $testID )
    {
        $tID = $testID;
    }


    if (    $type eq "CCBET"  ||    # these are the good ones
            $type eq "MULTIC" ||
            $type eq "FEET"   ||
            $type eq "BEET"   ||
            $type eq "RET"    ||
            $type eq "RND"    ||
            $type eq "PC"     ||
            $type eq "IC"     ||
            $type eq "FC"     
            )
    {
        return GOOD;
    }

#    if ( $tID == 1 )
#    {
#        # nway failover adds BES, FES, SITE and RNDALL
#
#        if (    $type eq "BES"    ||    # these are the good ones
#                $type eq "FES"    ||
#                $type eq "SITE"   ||
#                $type eq "RNDALL"     
#                )
#        {
#            return GOOD;
#        }
#        
#        # But not right away
#    }    


    if (    $type eq "BEPULL" ||
            $type eq "FEPULL" 
            )
    {
        
        if ( $hPtr )
        {
            if ( $hPtr->{0}->{FE_OPEN} ne INVALID )
            {
                return GOOD;   # user has filled in the 1st entry
            }
            else
            {
                logInfo("    Setup data for BEPULL/FEPULL has not been specified");
            }
        }
        else
        {
            logInfo("    Setup data for BEPULL/FEPULL has not been specified");
        }

    }
        
   
    return ERROR;
}

###############################################################################



###############################################################################

=head2 FindNextFailedCtlr function

Looks for any failed controllers in the VCG. Returns the serial
number of the first failed one that is found.

=cut

=over 1

=item Usage:

 my $rc = FindNextFailedCtlr( $ctlr );
 
 where,
        $ctlr is controller object for the master controller in the VCG.

=item Returns:

       $rc is serial number if one is failed, 0 if none failed, INVALID
           if there is an error.

=item Description:
 
 Gets VCG info and looks for a failed controller in the date.

=back

=cut



##############################################################################
#                                                                               
#          Name: FindNextFailedCtlr
#
#        Inputs: controller object
#
#       Outputs: SN of the failed controller, 0 if none failed, INVALID otherwise
#
#  Globals Used: none
#
#   Description: Gets the vcginfo from the master, returns first failed
#                controller in the list. 
#
##############################################################################
sub FindNextFailedCtlr
{
    trace();
    my ($ctlr) = @_;

    my $i;
    my $j;
    my %info;

    # get the vcginfo
    %info = $ctlr->vcgInfo(0);
    
    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get vcginfo from controller (no resp, index: $i) <<<<<<<<");
        return INVALID;
    }

    if (%info)
    {

        if ($info{STATUS} == PI_GOOD)
        {
           
            # check each controller listed
            for ( $j = 0; $j < $info{VCG_MAX_NUM_CONTROLLERS}; $j++ )   
            {
                
                # is it failed
                
                if ( $info{CONTROLLERS}[$j]{FAILURE_STATE} == FD_STATE_FAILED )     
                {
                    return ($info{CONTROLLERS}[$j]{SERIAL_NUMBER} );
                }
            }
        }
        else
        {
            logInfo(">>>>>>>> Error getting vcginfo from controller  <<<<<<<<");
            PrintError(%info);
            return INVALID;
        }
    }
    return 0;
}


###############################################################################

=head2 WhichCtlr function

Translates a serial number into the offset into the object and serial
number arrays.

=cut

=over 1

=item Usage:

 my $rc = WhichCtlr( $sn, $snPtr );
 
 where,
        $sn is the serial number of the controller to look up
        $snPtr is a pointer to a list of serial numbers

=item Returns:

       $rc is the index into the list for the matching serial number. 
           If there is no match, INVALID is returned,

=item Description:
 
 Searchs the list for a matching entry. The list can be anything numeric.

=back

=cut



##############################################################################
#                                                                               
#          Name: WhichCtlr
#
#        Inputs: serial number, SN array pointer
#
#       Outputs: index into array, INVALID if no match
#
#  Globals Used: none
#
#   Description: Looks for a matching number in the referenced list. Returns
#                index into list if found. Very generic.
# 
#
##############################################################################
sub WhichCtlr
{
    trace();
    my ($sn, $snPtr) = @_;

    my @snList;

    my $i;

    @snList = @$snPtr;    # convert pointer to list

    for ( $i = 0; $i < scalar(@snList); $i++ )
    {
        # check each list member to see if there is a match
        if ($sn == $snList[$i])
        {
            # got a match, return the index
            return $i;
        }
    }

    # no match found
    return INVALID;

}
    
#################################################################################


###############################################################################

####################################################################################
sub MoveTarget
{
    my ($ctlr, $sn, $targ) = @_;

    my $channel = $targ % 4;

    logInfo "target move: ctlr = $ctlr->{HOST}, targ = $targ to sn = $sn, chan = $channel ";

    my %rsp = $ctlr->targetMove($targ, $sn, $channel);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from targetMove <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to move the target <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }

    return GOOD;
}

#######################################################################################

=head2 BuildResources function

Using the user supplied data, builds the resource array used by the 
n-way failover test. The data includes the device type, IP addr, moxa
IP addr, moxa channels. A linked controller and georaid site may be 
provided.

=cut

=over 1

=item Usage:

 my $rc = BuildResources( $resPtr, $resListPtr, $coPtr );
 
 where,
        $resPtr points to the array that is vieing filled in
        $resListPtr points to the supplied information
        $coPtr points to a list of controller objects

=item Returns:

       $rc is GOOD if all goes well, ERRO otherwise,

=item Description:
 
  Fills a array of hashes with entries for the devices to be failed.
  
  Each entry has contains the following keys.
      {TYPE}        Device type, one of
                       CTLR
                       FEBSWITCH
                       BEBSWITCH
                       BEQSWITCH
                       DISKBAY
      {IPADDR}      IP Address of device (from the object)
      {MOXAIP}      IP Address of associated Moxa  (from $moxaIP)
      {MOXACHAN}    Channel(s) used on Moxa (from $moxaPtr
      {STATE}       current state of the device
      {HOWTOFAIL}   one of the possible failtypes
      {NUMFAILS}    number of times failed
      {NUMUNFAILS}  number of times unfailed
      {LINKEDCTLR}  associated controller
      {SERIALNUM}   if controller, serial number
      {OBJECT}      if controller, object pointer
      {GEOSITE}     for geo-raid
      {STAGGER}     flag for stagger or all-at-once

 

=back

=cut
#######################################################################

sub BuildResources
{
    
    my ( $resPtr, $resListPtr, $coPtr ) = @_;
    my $i;
    my $j;

    
    logInfo("BuildResources: Generating resource list from input data.");
    
    
    #
    # Check for empty arrays
    #

    if ( scalar(@$resListPtr) <= 0 ) 
    {
        logInfo("BuildResources: Input records were empty");
        return ERROR;
    }

    #
    # Now walk the inputs and fill in the array
    #

    for ( $i = 0; $i < scalar(@$resListPtr); $i++ )
    {
        # defaults for optional items

        $$resPtr[$i]->{GEOSITE}    = INVALID;      
        $$resPtr[$i]->{LINKEDCTLR} = INVALID;
        $$resPtr[$i]->{OBJECT}     = INVALID;         
        $$resPtr[$i]->{SERIALNUM}  = INVALID;


        # fill in the provided ones

        $$resPtr[$i]->{TYPE}       = $$resListPtr[$i]->{TYPE};      
        $$resPtr[$i]->{IPADDR}     = $$resListPtr[$i]->{IPADDR}; 
        $$resPtr[$i]->{MOXAIP}     = $$resListPtr[$i]->{MOXAIP};
        $$resPtr[$i]->{MOXACHAN}   = $$resListPtr[$i]->{MOXACHAN};

        if ( defined $$resListPtr[$i]->{GEOSITE}  )
        {
            $$resPtr[$i]->{GEOSITE}    = $$resListPtr[$i]->{GEOSITE};
        }

        if ( defined $$resListPtr[$i]->{LINKEDCTLR}  )
        {
            $$resPtr[$i]->{LINKEDCTLR} = $$resListPtr[$i]->{LINKEDCTLR};
        }


        # other defaults

        $$resPtr[$i]->{STATE}      = NWF_OK;              # defaulted
        $$resPtr[$i]->{HOWTOFAIL}  = 0;
        $$resPtr[$i]->{NUMFAILS}   = 0;
        $$resPtr[$i]->{NUMUNFAILS} = 0;
        $$resPtr[$i]->{STAGGER}    = 0;

        #
        # if it is a controller, then
        # we need to get the object and serial number based upon
        # the IP address
        #

        if ($$resPtr[$i]->{TYPE} == NWF_CTLR)
        {
            for ( $j = 0; $j < scalar( @$coPtr); $j++)
            {
                if ( $$coPtr[$j]->{HOST} ==  $$resPtr[$i]->{IPADDR})
                {
                    $$resPtr[$i]->{OBJECT}      = $$coPtr[$j];         
                    $$resPtr[$i]->{SERIALNUM}   = $$coPtr[$j]->{SERIAL_NUM};
                    $$resPtr[$i]->{OBJECTINDEX} = $j;         
                }
            }

            if ( $$resPtr[$i]->{OBJECT} == INVALID )
            {
                # we failed to find an object for the IP addr given
                # This is bad
                logInfo("BuildResources: Failed to find a valid controller object.");
                logInfo("                for IP addr $$resPtr[$i]->{IPADDR}");
                return ERROR;
            }
        }

    }

    return GOOD;


}
#######################################################################################
=head2 BuildResourcesFromControllers function

Using the failover information, builds the resource array used by the 
n-way failover test. From the failover information we get controller
object, moxa IP address, and the Moxa channels. The rest of the data is
intialized to default values. If called, this means only controllers 
will be failed and that all controllers are available to be failed.

=cut

=over 1

=item Usage:

 my $rc = BuildResourcesFromControllers( $resPtr, $coPtr, $moxaIP, $moxaPtr );
 
 where,
        $resPtr   is a pointer to the empty resource list
        $coPtr    is a pointer to the controller object array
        $moxaIP   is a pointer to the moxa IP address(es)
        $moxaPtr  is a pointer to the Moxa channel usage

=item Returns:

       $rc is GOOD if the resources array is filled in correctly 
              ERROR is returned on a failure. Fail information is logged.

=item Description:
 
 Uses data in the three source arrays to fill in the hash for the output
 array. The remaining items in the hash are initialized.

  Each entry has contains the following keys.
      {TYPE}        Device type, one of
                       CTLR
                       FEBSWITCH
                       BEBSWITCH
                       BEQSWITCH
                       DISKBAY
      {IPADDR}      IP Address of device (from the object)
      {MOXAIP}      IP Address of associated Moxa  (from $moxaIP)
      {MOXACHAN}    Channel(s) used on Moxa (from $moxaPtr
      {STATE}       current state of the device
      {HOWTOFAIL}   one of the possible failtypes
      {NUMFAILS}    number of times failed
      {NUMUNFAILS}  number of times unfailed
      {LINKEDCTLR}  associated controller
      {SERIALNUM}   if controller, serial number
      {OBJECT}      if controller, object pointer
      {GEOSITE}     for geo-raid
      {STAGGER}     flag for stagger or all-at-once



=back

=cut

#######################################################################

sub BuildResourcesFromControllers
{
    my ( $resPtr, $coPtr, $moxaIP, $moxaPtr )  = @_;
    
    my $coLen;
    my $mipLen;
    my $mchLen;
    my $i;
    
    logInfo("BuildResources: Generating resource list from legacy data.");
    
    #
    # Make sure the input arrays are the same size
    #
    
    $coLen = scalar(@$coPtr);
    $mipLen = scalar(@$moxaIP);
    $mchLen = scalar(@$moxaPtr);
    
    if ( ($coLen != $mipLen ) ||
         ($coLen != $mchLen) )
    {
        logInfo("BuildResources: Input records lengths to not match.");
        logInfo("       $coLen objects");
        logInfo("       $mipLen Moxa IP addresses");
        logInfo("       $mchLen Moxa channel listings");
        return ERROR;
    }    
    
    #
    # Check for empty arrays
    #

    if ( $coLen <= 0 ) 
    {
        logInfo("BuildResources: Input records were empty");
        return ERROR;
    }

    #
    # Now walk the inputs and fill in the array
    #

    for ( $i = 0; $i < $coLen; $i++ )
    {
        $$resPtr[$i]->{TYPE}        = NWF_CTLR;            # we know this

        $$resPtr[$i]->{OBJECT}      = $$coPtr[$i];         # provided
        $$resPtr[$i]->{OBJECTINDEX} = $i;                  # provided
        $$resPtr[$i]->{MOXAIP}      = $$moxaIP[$i];
        $$resPtr[$i]->{MOXACHAN}    = $$moxaPtr[$i];
        $$resPtr[$i]->{IPADDR}      = $$coPtr[$i]->{HOST}; 
        $$resPtr[$i]->{SERIALNUM}   = $$coPtr[$i]->{SERIAL_NUM};

        $$resPtr[$i]->{STATE}       = NWF_OK;              # defaulted
        $$resPtr[$i]->{HOWTOFAIL}   = 0;
        $$resPtr[$i]->{NUMFAILS}    = 0;
        $$resPtr[$i]->{NUMUNFAILS}  = 0;
        $$resPtr[$i]->{STAGGER}     = 0;
        $$resPtr[$i]->{LINKEDCTLR}  = INVALID;
        $$resPtr[$i]->{GEOSITE}     = INVALID;

    }

    return GOOD;

}

#######################################################################################
#######################################################################################
=head2 PowerCheck2 function

Verifies the ability to control the moxa port for each item in 
the resource list. THis is done by walking the list and attempting
to turn on each port.

=cut

=over 1

=item Usage:

 my $rc = PowerCheck2( $resPtr );
 
 where,
        $resPtr   is a pointer to the resource list

=item Returns:

       $rc is GOOD if all ports were accessed 
              ERROR if any port had problems.

=item Description:
 
 Using the data in the resource array, extract each moxa IP address and
 channel. Attempt to turn on that port. Repeat for all ports. 

=back

=cut

#######################################################################
sub PowerCheck2
{
    trace();
    my( $resPtr ) = @_;
    
    my $ret;
    my $i;
    my $dev;
    my $ip;
    my $str;

    my $moxaIP;
    my $moxaChan;

    my $failFlag = GOOD;

    my $ports = scalar(@$resPtr); 
 

    # Turn ON each of the listed ports. If we succeed, then we have control
    # over that port. If fail, then internet control is not working (or some
    # other problem).

    # One side effect of this test is that any test that calls this cannot 
    # be started with power initially off intentionally. All ports
    # specified will be on when done.

    for ($i = 0; $i < $ports; $i++)
    {
        
        logInfo("\n\n\n\n************************* checking moxa connection $i ***************************************");
        
        $moxaIP =  $$resPtr[$i]->{MOXAIP};
        $moxaChan = $$resPtr[$i]->{MOXACHAN};
        $dev = NWFType2Name($$resPtr[$i]->{TYPE});
        $ip =$$resPtr[$i]->{IPADDR};

        logInfo("  Turning on  $dev ip addr: $ip connected to moxa $moxaIP, channel $moxaChan");

        $ret = TestLibs::xiocontrol::ACPowerControl( $moxaIP, $moxaChan, 1);
        
        
        $str = sprintf (" XIOpower returned 0x%04x (%d)", $ret, $ret);
        logInfo("$str");

        #print "output: $? \n";
        
        if ( $ret != 0 )
        {
            # The failure is deferred so we can test each port rather than fail
            # one each time the test is invoked.
            logInfo("\n ==> Failure testing control of channel $moxaChan on Moxa $moxaIP");
            $failFlag = ERROR;
        }
        else
        {
            logInfo("\n ==> Success testing control of channel $moxaChan on Moxa $moxaIP");
        }

    }
    
    logInfo("\n\n\n************************* checking moxa connections done ************************************");
    
    return $failFlag;


}
#######################################################################################
#######################################################################################
=head2 WhatToFail function

Determines what should be failed in the resource list.

=cut

=over 1

=item Usage:

 my $rc = WhatToFail( $resPtr, $failType, $loop );
 
 where,
        $resPtr   is a pointer to list of resources
        $failType is the requested fail method
        $loop     is the current loop we are on

=item Returns:

       $rc is GOOD.

=item Description:
 
 Based upon the fail type, selects one or more things to fail. The 
 method to fail for this iteration is also determined.
 
 There are many options for failtype.
    PC - power cycle the item
    FC - vcgfail controller command
    BEET - Back end processor error trap
    FEET - Front end processor error trap
    CCBET - CCB processor error trap
    RND - random controller failue from above
    RET - random controller error trap
    RNDALL - a random failure of an object
    PCALL - power cycle an object.
    BEPULL - disconnect FE cable - requires additional hardware 
    FEPULL - Disconnect BE cable - requires additional hardware
    SITE - refers to a geo-raid site
    MULTIC - refers to an option that fails mulitple controllers
             and may choose between simultaneous and staggered 
             failure. This is the key n-way failover.


  PC, FC, BEET, FEET CCBET, RND, RET, BEPULL, FEPULL only apply to 
  controllers in the resource list. RNDALL and PCALL include controllers
  and other devices. SITE is for GEORAID failures and requires that the
  site information has been provided.

  MULTIC is a mode that will fail one or more controllers, may use 
  staaggered or sequenced failures. It also uses a random failure
  method for each controller.
    

=back

=cut

#######################################################################
sub WhatToFail
{

    my ( $resPtr, $failType, $loop, $coPtr ) = @_;
    
    my $objCount;
    my @ctlrList;
    my @otherList;
    my $ctlrCount = 0;
    my $otherCount = 0;
    my $i;
    my $retVal = GOOD;
    my $index;
    my $maxToFail;
    my $numToFail;
    my @victims;
    my $stagger;
    my $how2fail;
    my $ret;
    
    #
    # First, a little overhead. We count the controllers and 'other' 
    # objects, making a list of indices for each group. 
    #

    logInfo("WhatToFail: failure type is $failType.");

    $objCount = scalar ( @$resPtr );


    for ( $i = 0; $i < $objCount; $i++ )
    {
        if ( $$resPtr[$i]->{TYPE} == NWF_CTLR )   
        {
            push ( @ctlrList, $i );
            $ctlrCount++;
        }
        else
        {
            push ( @otherList, $i );
            $otherCount++;
        }

        #
        # While here, check to see if the states are correct.
        #
        
        if ( $$resPtr[$i]->{STATE} != NWF_OK ) 
        {
            logInfo("Object $index ($$resPtr[$i]->{IPADDR})is".
                       " not in the correct state.");
            logInfo(" Current state = $$resPtr[$i]->{STATE}     ");
            $retVal = ERROR;
        }


    }

    if ( $retVal != GOOD )
    {
        return $retVal;
    }

        
    #
    # Now, fall into three major branches, plus a 4th for the error
    # or not yet done path. One branch will be similar to the legacy 
    # failover script. The second is the multi-controller path. Third
    # it the path that include non-controllers. The 4th is the ones 
    # we don't have code for and willo generate an error.
    #

    if ( ($failType eq "PC") ||
         ($failType eq "FC") ||
         ($failType eq "IC") ||
         ($failType eq "BEET") ||
         ($failType eq "FEET") ||
         ($failType eq "CCBET") ||
         ($failType eq "RND") ||
         ($failType eq "RET") )
    {

        #
        # This is the legacy block. We selected one controller and then
        # select an appropriate failure method for it. Update the entry
        # in the resource list and we are done.
        #

        #
        # Check number of controllers, need at least one. We are asumming
        # that if only one was specified, there is another one in the system
        # that the user did not want to be failed. If the system is a 
        # 1 way, we better not be here.
        #

        if ( $ctlrCount < 1 )
        {
            logInfo(" You need to specifiy at least one controller to be failed.");
            logInfo("     Only $ctlrCount were found.");
            return ERROR;
        }

        #
        # Now we select a controller. This is always random. In the old code, 
        # we were guaranteed to be uniform by always failing each of the slaves
        # and then the master. This one will always select a random controller.
        # There are summary prints in the loops so that we can see how many 
        # times each was actually failed.
        #

        $index = TestLibs::utility::randomInt( 0, $ctlrCount);

        #
        # we have the index of the victim in the controller array, now
        # get the index into the resource array
        #
        $index =  $ctlrList[$index];

        #
        # We know which controller to fail, now figure out how to fail it
        #

        $how2fail = GetFailMethod($failType);

        #
        # Now update the entry in the resource list.
        #

        $$resPtr[$index]->{HOWTOFAIL} = $how2fail;
        $$resPtr[$index]->{STATE}     = NWF_2FAIL;

        logInfo(" Selected IP $$resPtr[$index]->{IPADDR} to fail using $$resPtr[$index]->{HOWTOFAIL}");
            
        # that's it

    }
    elsif ( $failType eq "MULTIC" )
    {

        #
        # This is the multi-controller block. Here we select how many
        # controllers to fail ( from 1 to n-1 ) and then how to fail
        # them. Additionally we need to decide if they are failed at the
        # same time, or fail them sequentially (cascade fail). Then update
        # the entries in the resource list and we are done.
        #

        #
        # Check number of controllers, need at least one.
        #

        if ( $ctlrCount < 1 )
        {
            logInfo(" You need to specifiy at least one controller to be failed.");
            logInfo("     Only $ctlrCount were found.");
            return ERROR;
        }

        #
        # Now determine the maximum number of controllers to fail. This must
        # allow for one to remain alive. So, if the number of coPtr items  
        # is bigger than $ctlrCount, we can use all in ctlrCount, otherwise
        # we must leave one of ctlrCount alive.
        #


        $maxToFail = min ( (scalar(@$coPtr) - 1), $ctlrCount);

        #
        # Get the number we will fail this time around.
        #

        $numToFail = TestLibs::utility::randomInt( 1, $maxToFail);


        #
        # Now select those we will fail. This is a random selection
        #


        $ret = SelectRandom( \@victims, \@ctlrList, $numToFail );

        #
        # We also select to batch or stagger the failures.
        #

        $stagger = TestLibs::utility::randomInt( 0, 100);

        
        #
        # the following determines the ralative mix of staggered vs
        # batched failures.
        #
        # Smaller number is more staggers
        #
        
        if ( $stagger > 30 )
        {
            $stagger = NWF_STAGE;
        }
        else
        {
            $stagger = NWF_SIMUL;
        }


        #
        # Now we will update the resource list by marking the ones
        # that will be failed, we will also determine a random failure
        # method for the failure.
        #

        for ( $i = 0; $i < $numToFail; $i++ )
        {
            
            #
            # WHen failing multiple controllers, the failure method
            # is random. This could be changed.
            #
            
            $how2fail = GetFailMethod("RND");                        #  <<<<< something other than RND can be done here

            #
            # Seems that we can not get some MRPs thru while an election
            # is in progress. Therefore, if we are failing controllers
            # simultaneously, our best option is to just turn them off.
            # (THis was found by trying to FC a controller just after
            # PCing a previous controller. An election was running and
            # the vcgfial command failed.
            #
            
            if ( $stagger == NWF_SIMUL )
            {
                $how2fail = "PC"
            }
            
            
            $index = $victims[$i];

            $$resPtr[$index]->{HOWTOFAIL} = $how2fail;
            $$resPtr[$index]->{STATE}     = NWF_2FAIL;


            $$resPtr[$index]->{STAGGER}   = $stagger;
        
        
            logInfo("Selected IP $$resPtr[$index]->{IPADDR} to ".
                    "fail using $$resPtr[$index]->{HOWTOFAIL} ".
                    "(stagger = $stagger)");
        
        }
        
        # that's it

    }
    elsif ( ($failType eq "RNDALL") || ($failType eq "PCALL") )
    {
        
        #
        # This is the block that includes the non-controller objects.
        # Here we select of of the items in resource list and mark it to
        # be failed. If it is a non-controller, we will power it off. 
        # Controllers may be powered off or some other failure used.
        # The entry for the seletcted item is updated.
        #

        logInfo("$failType is not a supported option for failover.");
        return ERROR;

    }
    elsif ( $failType eq "SITE" )
    {
        #
        # This is the block for future GEO-RAID testing. Here a site
        # is selected and all items in that site are marked for 
        # failure. The failure methos is PC and all will fail at the
        # same time.
        #
        # This will be done at a later date.
        #

        logInfo("$failType is not a supported option for failover.");
        return ERROR;
    }
    else
    {
        #
        # Something else we don't understand was specified. That is a 
        # failure. Log a message and error out. If this happen often, 
        # we need to write more code.
        #

        logInfo("You selected $failType. This is not currently supported, try again.");
        return ERROR;
    }


    return $retVal;


}
#######################################################################################
#######################################################################################
=head2 SelectRandom function

Selects n random items from a list.

=cut

=over 1

=item Usage:

 my $rc = SelectRandom( $destPtr, $srcPtr, $request );
 
 where,
        $destPtr   points to the destination array
        $srcPtr    points to a source list
        $request   is how many we want

=item Returns:

       $rc is GOOD. ERROR if not enough elements provided.

=item Description:
 
 Uses random selection without replacement. Caller should make sure the 
 destination array is empty before calling this function. If all items
 are asked for the order is randomized rather than returning the source 
 list.

=back

=cut

#######################################################################
sub SelectRandom
{
    my ($destPtr, $srcPtr, $request) = @_;
    my $vd;
    my $j;
    my $i;
    my $gotOne;
    my $listSize;
    my $listSize2;


    
    my @srcList = @$srcPtr;      #need a local copy

    # this method is 'random selection without replacement'

    $listSize =  scalar(@srcList);
    $listSize2 = $listSize;

    # for each requested disk
    for ( $i = 0; $i < $request; $i++ )
    {
        # select a random number
        $vd = randomInt(0, ($listSize - 1));

        # remove it from the list
        $gotOne = 0;                          # clear flag

        for ( $j = 0; $j <$listSize; $j++)
        {
            if ( $j == $vd )
            {
                # we are at the chosen index
                $gotOne = 1;                # set flag
                $$destPtr[$i] = $srcList[$j];  # get the vd
            }
            else
            {
                # this isn't the one we wanted
                if ( $gotOne != 0 )
                {
                    # copy the one after the selected item up one position
                    $srcList[$j-1] = $srcList[$j];
                }
            }
        }

        $listSize--;

        if (($listSize == 0) && $i < ($request - 1) )
        {
            # we ran out of things in the list before getting the 
            # desired number. Shouldn't happen.
            logInfo("Unable to get $request items from a list of $listSize2 items.");
            return ERROR; 
        }

    }

    return GOOD;

}


#######################################################################################
=head2 PostSummary function

Checks VCGInfo to make sure no controllers have failed.

=cut

=over 1

=item Usage:

 my $rc = PostSummary( $resPtr, $loop );
 
 where,
        $resPtr   is a pointer to list of resources
        $loop     is the current loop count

=item Returns:

       $rc is GOOD.

=item Description:
 
 Logs information about the number of failovers completed for each item.

=back

=cut

#######################################################################
sub PostSummary
{
    my ($resPtr, $loop) = @_;

    my $i;
    my $type;
    my $ip;
    my $fails;
    my $unfails;

    logInfo("-----------------------------------------------------------------");
    logInfo("PostSummary: Summary of failover and fail back operations by device.");

    for ( $i = 0; $i < scalar( @$resPtr); $i++ )
    {
        $type    =  NWFType2Name($$resPtr[$i]->{TYPE});
        $ip      =  $$resPtr[$i]->{IPADDR};
        $fails   =  $$resPtr[$i]->{NUMFAILS};
        $unfails =  $$resPtr[$i]->{NUMUNFAILS};
    
        logInfo("PostSummary: $type object at IP $ip: failed $fails times, unfailed $unfails times.");
    }
    logInfo("-----------------------------------------------------------------");

    return GOOD;

}
#######################################################################################
=head2 UnfailAll2 function

This function unfails all failed controllers. In addition to unfailing the 
controllers, the counts in the resource list are updated. (Otherwise we would 
be using the existing UnfailAll function.)

=cut

=over 1

=item Usage:

 my $rc = UnfailAll2( $resPtr, $coPtr, $snPtr, $moxaIP, $moxaPtr);
 
 where,
        $resPtr    points to the failover resource list
        $coPtr     points to a controller object list.
        $snPtr     pointer to list of serial numbers
        $moxaIP    pointer to list of Moxa IP addresses
        $moxaPtr   pointer to a list of moxa channel assignments

=item Returns:

       $rc is GOOD. ERROR if not enough elements provided.

=item Description:
 
 Findss the master in the coPtr list. Determines which controllers are 
 failed and then power cycles each, and unfails it. Updates counts in
 the resource list. May not catch a controller that fails while unfailing
 the others.

=back

=cut


#######################################################################################
sub UnfailAll2
{

    my ($resPtr, $coPtr, $snPtr, $moxaIP, $moxaPtr, $timelineDuration, $failCount ) = @_;

    my @deadOnes;
    my $master;
    my $ctlr;
    my %info;
    my $j;
    my @snList;
    my $ret;
    my @moxaMap;
    my @moxaList;
    my @coList;
    my $i;
    my $k;

    @moxaList = @$moxaIP;
    @moxaMap = @$moxaPtr;
    @coList = @$coPtr;
    @snList = @$snPtr;

    logInfo("      Locating and unfailing all failed controllers.");

    #
    # Need the master controller so we can get a valid list of the failed ones
    #

    $master = FindMaster($coPtr);

    if ( $master == INVALID ) 
    { 
        logInfo("UnfailAll2: Could not identify the master controller.".
                " Controllers may still be failed.");
        return(ERROR); 
    } 

    
    #
    # from vcginfo on the master, identify all failed controllers
    #
    
    $ctlr = $coList[$master];
    
    %info = $ctlr->vcgInfo(0);
    
    if ( ! %info  )
    {
        logInfo(">>>>>>>> UnfailAll2: Failed to get vcginfo from ".
                "controller (no resp, index: $i) <<<<<<<<");
        return (ERROR);
    }


    if ($info{STATUS} == PI_GOOD)
    {
       
        # if sn match with max controllers > 1 and master

        #
        # Check max controllers If max controllers is 1 we are in a 
        # 1-way config and have no reason to be here. Also there can't
        # be any failed controllers and have stuff still be working.
        #
        
        if (  $info{VCG_MAX_NUM_CONTROLLERS} > 1)            
        {
            # check each controller listed
            for ( $j = 0; $j < $info{VCG_MAX_NUM_CONTROLLERS}; $j++ )   
            {
                if ( ($info{CONTROLLERS}[$j]{FAILURE_STATE} == FD_STATE_INACTIVATED) || 
                     ($info{CONTROLLERS}[$j]{FAILURE_STATE} == FD_STATE_FAILED)  )   
                {
                    # save the serial number of the failed controller
                    push( @deadOnes, $info{CONTROLLERS}[$j]{SERIAL_NUMBER} );

                }
            }
        }
                
    }
    else
    {
        logInfo(">>>>>>>> UnfailAll2: Error getting vcginfo from ".
                "controller (error returned, index: $i) <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    #
    # If we have no dead ones, we can leave without doing anything more.
    #

    if ( scalar( @deadOnes) < 1 )
    {
        # there were no failed controllers
        logInfo("UnfailAll2: No failed controllers were found.");
        return GOOD;
    }


    #
    # We have a list of dead controllers by serial number, we also
    # need to have a list of indices into coList for these devices
    # and a list of indices into the resource list.
    #


    my @objectDead;
    my @resDead;

    for ( $i = 0; $i < scalar( @deadOnes); $i++ )
    {   
        # first the SN/object list
        
        for ( $j = 0; $j < scalar (@$snPtr); $j++ )
        {
        
            if ( $snList[$j] == $deadOnes[$i] )
            {
                # found it ...  Use $j as the index
                push (@objectDead, $j);
            }
        }

        # then the resource list
        
        for ( $j = 0; $j < scalar (@$resPtr); $j++ )
        {
        
            if ( $$resPtr[$j]->{SERIALNUM} == $deadOnes[$i] )
            {
                # found it ...  Use $j as the index
                push (@resDead, $j);
            }
        }
    }



    #
    # Now we have a list of failed controllers and can go and unfail them.
    # We unfail each and then do a short timeline after each, except for 
    # the last one. The caller will do the final timeline. 
    # 



    
    # unfail each
    for ( $i = 0; $i < scalar( @deadOnes); $i++ )
    {   
        #
        # need to map the serial numbers to the moxa index
        #
        
        for ( $j = 0; $j < scalar( @snList); $j++ )
        {   
           
#print " (SN[$j] = $snList[$j])  ?= (do[$i] = $deadOnes[$i]) \n";
           
            if ( $snList[$j] == $deadOnes[$i] )
            {
                # found it ...  Use $j as the index
                last;
            }
        }
 
#print " i= $i, j= $j \n"; 
#print " DO[$i]=  $deadOnes[$i],  od[$i]= $objectDead[$i],   rd[$i] $resDead[$i] \n";
        logInfo("");
        logInfo("");
        logInfo("      ********************************************************************  ");
        logInfo("           UnfailAll2: Power up controller $coList[$j]->{HOST}  (sn $snList[$j] )");
        logInfo("      ********************************************************************  ");
        logInfo("");


        #
        # Turn on the power for the controller. (Assumption is that the power
        # was turned off earlier. This is true for FailOverNWayLoop(). If 
        # the function is called from another loop, then there may be 
        # problems.
        #


        $ret = TestLibs::IntegCCBELib::PowerChange($moxaList[$j], $moxaMap[$j], 1);
        if ( $ret != GOOD ) 
        { 
            logInfo("Failure turning on power (power control problem).");
            return ERROR; 
        }


        # need to reconnect to the controller
        if ($coList[$j])
        {
            logInfo("UnfailAll2: Pause for 60 seconds and reconnect".
                    " to controller $deadOnes[$i]" );

#print " snl: snList[$j] ";                    
                    
                                
            #
            # The time in the function is how long to wait befroe attempting
            # to reconnect. 
            #
            
            
            $ret = TestLibs::IntegCCBELib::Reconnect( $coList[$j], 60 );
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> UnfailAll2: Failed to reconnect to the controller    <<<<<<<<");
                return ERROR;

            }
            
            #
            # wait for the controller to sufficiently boot. The timeout
            # here means we will not wait longer then the specified time.
            # We have already reconnected, so this should not take as
            # long as we allow.
            #

            TestLibs::Validate::Wait4MinPowerUpState($coList[$j], POWER_UP_INACTIVE, 480);          

        }
        else
        {
            #
            # If here, we have no controller object for some reason. This
            # might need to be an error path.
            #
            logInfo("UnfailAll2: Pause for 200 seconds to allow controller to power up ");
            logInfo("****************************************************************************");
            logInfo("************** Unfailing a controller that has no object! ******************");
            logInfo("****************************************************************************");
            DelaySecs(200);
        }

        #
        # unfail the controller
        #
        
        logInfo("UnfailAll2: Unfailing the controller ($deadOnes[$i])  ");
        $ret = TestLibs::IntegCCBELib::UnFailController( $coList[$master], $deadOnes[$i] );
        if (  $ret == ERROR )
        {
            logInfo(">>>>>>>> Failed to restore the controller to active duty  <<<<<<<<");
            return ERROR;
        }

        #
        # Do a shorter timeline in here to observe IO resume. Start with 
        # 120 sec and move down as desired. Note that the user specified 
        # timeline time is not used. No I/O check is done at this time.
        #

        #
        # must determine the deadlist !!
        #
        # The deadList is those controllers we have yet to unfail. Since 
        # we made the object dead array we just use to ones we have yet to 
        # unfail.
        #

        my @deadList;   # must be in this loop/ at the location

        for ($k = $i + 1; $k < scalar(@objectDead); $k++ )
        {
            push (@deadList, $objectDead[$k]);
        }

        # now the timeline will skip the controllers in deadList
        
        logInfo("Timeline after unfailing a controller [$failCount failovers completed]");
        
        TestLibs::Validate::FailOverTimeLineNway( $coPtr, $timelineDuration, $snPtr, \@deadList);


        #
        # Now update the unfail count for this controller
        #
          
        $$resPtr[$resDead[$i]]->{NUMUNFAILS} = $$resPtr[$resDead[$i]]->{NUMUNFAILS} + 1;  
          
        #
        # This Item should be in the failed state and now gets put into the 
        # good state. Befroe updating, check to see if the item is really
        # supposed to be failed. If not, raise flag by posting a bunch of
        # log messages and returning an error. (Yes, a controller failing
        # on its own is bad news.)
        #  
                                    
        if ( $$resPtr[$resDead[$i]]->{STATE} == NWF_FAILED )
        {
            # we unfaled a failed one, this is cool.  
            $$resPtr[$resDead[$i]]->{STATE} = NWF_OK;
        }
        else
        {
            # we unfailed a good one. this is bad.
            logInfo("Test Error: We just unfailed a controler that should not have been failed>");
            logInfo("This should not have happened. Test failed.");
            logInfo("Controller $$resPtr[$resDead[$i]]->{IPADDR}, state was $$resPtr[$resDead[$i]]->{STATE} ");
            return ERROR;
        }

        #
        # Want to test the VCGINFO for each controller to see if they are in the correct state
        #

        $ret = VCGInfoCheck2($coPtr, $resPtr);

        if (  $ret != GOOD )
        {
            logInfo(">>>>>>>> Failed: Controllers are not in the expected state  <<<<<<<<");
            return ERROR;
        }


    }  # end of looping thru the dead ones

    #
    # return immediately so that we can to a longer timeline and I/O 
    # checks. (Or the above timeline may be sufficient.)
    #
    
    return GOOD;

}





#######################################################################################
#######################################################################################
=head2 CleanUpUnfailAll function

This function unfails all failed controllers. In addition to unfailing the 
controllers, the counts in the resource list are updated. (Otherwise we would 
be using the existing UnfailAll function.)

=cut

=over 1

=item Usage:

 my $rc = CleanUpUnfailAll( $resPtr, $coPtr, $snPtr, $moxaIP, $moxaPtr);
 
 where,
        $resPtr    points to the failover resource list
        $coPtr     points to a controller object list.
        $snPtr     pointer to list of serial numbers
        $moxaIP    pointer to list of Moxa IP addresses
        $moxaPtr   pointer to a list of moxa channel assignments

=item Returns:

       $rc is GOOD. ERROR if not enough elements provided.

=item Description:
 
 Findss the master in the coPtr list. Determines which controllers are 
 failed and then power cycles each, and unfails it. Updates counts in
 the resource list. May not catch a controller that fails while unfailing
 the others.

=back

=cut
#######################################################################################
sub CleanUpUnfailAll
{

    my ($resPtr, $coPtr, $snPtr, $moxaIP, $moxaPtr, $timelineDuration, $failCount ) = @_;

    my @deadOnes;
    my $master;
    my $ctlr;
    my %info;
    my $j;
    my @snList;
    my $ret;
    my @moxaMap;
    my @moxaList;
    my @coList;
    my $i;
    my $k;

    @moxaList = @$moxaIP;
    @moxaMap = @$moxaPtr;
    @coList = @$coPtr;
    @snList = @$snPtr;

    logInfo("CLEANUP -  Locating and unfailing all failed controllers.");

    #
    # Need the master controller so we can get a valid list of the failed ones
    #

    $master = FindMaster($coPtr);

    if ( $master == INVALID ) 
    { 
        logInfo("CleanUpUnfailAll: Could not identify the master controller.".
                " Controllers may still be failed.");
        return(ERROR); 
    } 

    
    #
    # from vcginfo on the master, identify all failed controllers
    #
    
    $ctlr = $coList[$master];
    
    %info = $ctlr->vcgInfo(0);
    
    if ( ! %info  )
    {
        logInfo(">>>>>>>> CleanUpUnfailAll: Failed to get vcginfo from ".
                "controller (no resp, index: $i) <<<<<<<<");
        return (ERROR);
    }


    if ($info{STATUS} == PI_GOOD)
    {
       
        # if sn match with max controllers > 1 and master

        #
        # Check max controllers If max controllers is 1 we are in a 
        # 1-way config and have no reason to be here. Also there can't
        # be any failed controllers and have stuff still be working.
        #
        
        if (  $info{VCG_MAX_NUM_CONTROLLERS} > 1)            
        {
            # check each controller listed
            for ( $j = 0; $j < $info{VCG_MAX_NUM_CONTROLLERS}; $j++ )   
            {
                if ( ($info{CONTROLLERS}[$j]{FAILURE_STATE} == FD_STATE_INACTIVATED) || 
                     ($info{CONTROLLERS}[$j]{FAILURE_STATE} == FD_STATE_FAILED)  )   
                {
                    # save the serial number of the failed controller
                    push( @deadOnes, $info{CONTROLLERS}[$j]{SERIAL_NUMBER} );

                }
            }
        }
                
    }
    else
    {
        logInfo(">>>>>>>> CleanUpUnfailAll: Error getting vcginfo from ".
                "controller (error returned, index: $i) <<<<<<<<");
        PrintError(%info);
        return ERROR;
    }

    #
    # If we have no dead ones, we can leave without doing anything more.
    #

    if ( scalar( @deadOnes) < 1 )
    {
        # there were no failed controllers
        logInfo("CleanUpUnfailAll: No failed controllers were found, continue with test case.");
        return GOOD;
    }


    #
    # We have a list of dead controllers by serial number, we also
    # need to have a list of indices into coList for these devices
    # and a list of indices into the resource list.
    #


    my @objectDead;
    my @resDead;

    for ( $i = 0; $i < scalar( @deadOnes); $i++ )
    {   
        # first the SN/object list
        
        for ( $j = 0; $j < scalar (@$snPtr); $j++ )
        {
        
            if ( $snList[$j] == $deadOnes[$i] )
            {
                # found it ...  Use $j as the index
                push (@objectDead, $j);
            }
        }

        # then the resource list
        
        for ( $j = 0; $j < scalar (@$resPtr); $j++ )
        {
        
            if ( $$resPtr[$j]->{SERIALNUM} == $deadOnes[$i] )
            {
                # found it ...  Use $j as the index
                push (@resDead, $j);
            }
        }
    }



    #
    # Now we have a list of failed controllers and can go and unfail them.
    # We unfail each and then do a short timeline after each, except for 
    # the last one. The caller will do the final timeline. 
    # 



    
    # unfail each
    for ( $i = 0; $i < scalar( @deadOnes); $i++ )
    {   
        #
        # need to map the serial numbers to the moxa index
        #
        
        for ( $j = 0; $j < scalar( @snList); $j++ )
        {   
           
#print " (SN[$j] = $snList[$j])  ?= (do[$i] = $deadOnes[$i]) \n";
           
            if ( $snList[$j] == $deadOnes[$i] )
            {
                # found it ...  Use $j as the index
                last;
            }
        }
 
#print " i= $i, j= $j \n"; 
#print " DO[$i]=  $deadOnes[$i],  od[$i]= $objectDead[$i],   rd[$i] $resDead[$i] \n";
        logInfo("");
        logInfo("");
        logInfo("      ********************************************************************  ");
        logInfo("        CleanUpUnfailAll: Power up controller $coList[$j]->{HOST}  (sn $snList[$j] )");
        logInfo("      ********************************************************************  ");
        logInfo("");


        #
        # Turn on the power for the controller. (Assumption is that the power
        # was turned off earlier. This is true for FailOverNWayLoop(). If 
        # the function is called from another loop, then there may be 
        # problems.
        #


        $ret = TestLibs::IntegCCBELib::PowerChange($moxaList[$j], $moxaMap[$j], 1);
        if ( $ret != GOOD ) 
        { 
            logInfo("Failure turning on power (power control problem).");
            return ERROR; 
        }


        # need to reconnect to the controller
        if ($coList[$j])
        {
            logInfo("CleanUpUnfailAll: Pause for 60 seconds and reconnect".
                    " to controller $deadOnes[$i]" );

#print " snl: snList[$j] ";                    
                    
                                
            #
            # The time in the function is how long to wait befroe attempting
            # to reconnect. 
            #
            
            
            $ret = TestLibs::IntegCCBELib::Reconnect( $coList[$j], 60 );
            if ( $ret == ERROR )
            {
                logInfo(">>>>>>>> CleanUpUnfailAll: Failed to reconnect to the controller    <<<<<<<<");
                return ERROR;

            }
            
            #
            # wait for the controller to sufficiently boot. The timeout
            # here means we will not wait longer then the specified time.
            # We have already reconnected, so this should not take as
            # long as we allow.
            #

            TestLibs::Validate::Wait4MinPowerUpState($coList[$j], POWER_UP_INACTIVE, 480);          

        }
        else
        {
            #
            # If here, we have no controller object for some reason. This
            # might need to be an error path.
            #
            logInfo("CleanUpUnfailAll: Pause for 200 seconds to allow controller to power up ");
            logInfo("****************************************************************************");
            logInfo("************** Unfailing a controller that has no object! ******************");
            logInfo("****************************************************************************");
            DelaySecs(200);
        }

        #
        # unfail the controller
        #
        
        logInfo("CleanUpUnfailAll: Unfailing the controller ($deadOnes[$i])  ");
        $ret = TestLibs::IntegCCBELib::UnFailController( $coList[$master], $deadOnes[$i] );
        if (  $ret == ERROR )
        {
            logInfo(">>>>>>>> Failed to restore the controller to active duty  <<<<<<<<");
            return ERROR;
        }

        #
        # Do a shorter timeline in here to observe IO resume. Start with 
        # 120 sec and move down as desired. Note that the user specified 
        # timeline time is not used. No I/O check is done at this time.
        #

        #
        # must determine the deadlist !!
        #
        # The deadList is those controllers we have yet to unfail. Since 
        # we made the object dead array we just use to ones we have yet to 
        # unfail.
        #

        my @deadList;   # must be in this loop/ at the location

        for ($k = $i + 1; $k < scalar(@objectDead); $k++ )
        {
            push (@deadList, $objectDead[$k]);
        }

        # now the timeline will skip the controllers in deadList
        
        logInfo("Timeline after unfailing a controller");
        
        TestLibs::Validate::FailOverTimeLineNway( $coPtr, $timelineDuration, $snPtr, \@deadList);


        #
        # Now update the unfail count for this controller
        #
          
        $$resPtr[$resDead[$i]]->{NUMUNFAILS} = $$resPtr[$resDead[$i]]->{NUMUNFAILS} + 1;  
          
        #
        # This Item should be in the failed state and now gets put into the 
        # good state. Befroe updating, check to see if the item is really
        # supposed to be failed. If not, raise flag by posting a bunch of
        # log messages and returning an error. (Yes, a controller failing
        # on its own is bad news.)
        #  
                                    
        if ( $$resPtr[$resDead[$i]]->{STATE} == NWF_FAILED )
        {
            # we unfaled a failed one, this is cool.  
            $$resPtr[$resDead[$i]]->{STATE} = NWF_OK;
        }
        else
        {
            # we unfailed a good one. this is bad.
            logInfo("CleanUpUnFailAll:  All controllers are now active, proceeding with test case");
            logInfo("Controller $$resPtr[$resDead[$i]]->{IPADDR}, state was $$resPtr[$resDead[$i]]->{STATE} ");
            return GOOD;
        }

        #
        # Want to test the VCGINFO for each controller to see if they are in the correct state
        #

        $ret = VCGInfoCheck2($coPtr, $resPtr);

        if (  $ret != GOOD )
        {
            logInfo(">>>>>>>> Failed: Controllers are not in the expected state  <<<<<<<<");
            return ERROR;
        }


    }  # end of looping thru the dead ones

    #
    # return immediately so that we can to a longer timeline and I/O 
    # checks. (Or the above timeline may be sufficient.)
    #
    
    return GOOD;

}


#######################################################################################
sub PowerFailedControllersOffAfterTheTimeline
{

    #
    # This functions powers off all failed controllers after the timeline
    # is complete. This better matches the action of a user once something dies.
    # This means that the unfail only needs to do a power on in all cases.
    #

    # code is inline in FailOverNWayLoop() 


}
#######################################################################################
#######################################################################################
=head2 FailThings function

This function fails one or more devices for the n-way failover test. Items may be failed
simultaneously or in a staggered fashion. The default will be simultaneous. Failures
are based upon the flags in the resource list. After each failure a timeline 
is run. Non-controllers are powered off to effect the failure. Controllers have 
several different failure methods available.

=cut

=over 1

=item Usage:

 my $rc = FailThings( $resPtr, $timelineDuration, $coPtr, $snPtr );
 
 where,
        $resPtr           is a pointer to the resource list
        $timelineDuration is the length of the time line and
                          indirectly the delay between staggered 
                          failures.
        $coPtr            pointer to list of controller objects
        $snPtr            pointer to list of serial numbers
        $failCount        number of previous failures

=item Returns:

       $rc is GOOD or ERROR 

=item Description:
 
 Based upon flags in the resource list, the items marked 'NWF_2FAIL' are failed.
 If any item is marked to fail and has the stagger flag cleared, all failures
 will be done simultaneously. Stagger is only used if all are marked as stagger.

=back

=cut

#######################################################################
sub FailThings
{

#When doing a cascade, put a shorter timeline between the controllers - NO I/O check as I did not
#pass in the arrays.
#Waldk the resource array, failing things as found, do a timeline after each fail.
#If a grouped fail is found, then check the rest of the list and do all group items at
#that time, then finish the list with any added staggered ones.
#
#Also, bump the numfails counter


    my ($resPtr, $timelineDuration, $coPtr, $snPtr, $failCount) = @_;

    my $i;
    my $ret;
    my $how2fail;
    my $j;
    my $msg;
    my @deadList;

    #
    # First walk the list to determine if we will do staggered or
    # simultaneous failures. We set the method to staggered and
    # then check to see if any are set to simultaneous, then we will
    # do all simultaneous.
    #

    my $doStaggered = 1;

    for ( $i = 0; $i < scalar(@$resPtr); $i++ )
    {
        if ( $$resPtr[$i]->{STATE} == NWF_2FAIL )
        {
            if ( $$resPtr[$i]->{STAGGER} == NWF_SIMUL )
            {
                # found a item marked simlutaneous failure
                $doStaggered = 0;

                # don't need to look further
                last;

            }
        }
    }



    CtlrLogTextAll($coPtr , "-------------------------".
                            "  Beginning failures [$failCount failovers completed].".
                            "-------------------------");

    my @moxaList;        # power controller IP addresses
    my @moxaChans;       # channels for each controller
    my @goodList;        # list of object list indices (currently good)
    my @failList;        # list of resource list indices (to be failed)
    my @goodCtlrList;    # list of good objects
               

    if ( $doStaggered == 1 )
    {

        #
        # Now walk the resource list and fail the marked items.
        # If we are staggered, we will walk the list and fail one at a time.
        # there is a timeline between each failure.
        #
        for ( $i = 0; $i < scalar(@$resPtr); $i++ )
        {
            if ( $$resPtr[$i]->{STATE} == NWF_2FAIL )
            {

                #
                # We want to log what we are going to fail to each of the 
                # controllers and their debug consols. So, get a list of current 
                # known good controllers and then send a message to each.
                #
                
                my @okList;

                GetGoodCtlrs($resPtr, \@okList);

                $msg = "Failing $$resPtr[$i]->{IPADDR} using $$resPtr[$i]->{HOWTOFAIL}";

                CtlrLogTextList($coPtr, \@okList, $msg);
                
                
                
                #
                # This one will be failed, non-controllers are powered off. 
                #

                if ( $$resPtr[$i]->{TYPE} != NWF_CTLR )
                {
            
                    logInfo("Power off $$resPtr[$i]->{IPADDR}");
                
                    $ret = TestLibs::IntegCCBELib::PowerChange($$resPtr[$i]->{MOXAIP}, $$resPtr[$i]->{MOXACHAN}, 0);
                    if ( $ret == ERROR )
                    {
                        logError(">>>>>>>> Failed to power down the item [$failCount failovers completed]  <<<<<<<<");
                        return ERROR;
                    }
            

                }
                else
                {

                    $how2fail = $$resPtr[$i]->{HOWTOFAIL};

                    if ( $how2fail eq "CCBET" )
                    {
                        $ret = SuicideOKForController ( $$resPtr[$i]->{OBJECT} );
                        if ( $ret == ERROR )
                        {
                            logError(">>>>>>>> Failed to enable suicide for proc  <<<<<<<<");
                            return ERROR;
                        }
                    }

                    logInfo("Failing $$resPtr[$i]->{IPADDR} using $how2fail [$failCount failovers completed] ");

                    ########################
                    # now force the failure
                    ########################
                
                    if ( $how2fail eq "PC" )
                    {
                        # brute force power cycle handled here
                        $ret = TestLibs::IntegCCBELib::PowerChange($$resPtr[$i]->{MOXAIP}, $$resPtr[$i]->{MOXACHAN}, 0);
                        if ( $ret == ERROR )
                        {
                            logError(">>>>>>>> Failed to power down the controller [$failCount failovers completed]  <<<<<<<<");
                            return ERROR;
                        }
                    }

                    # these will take more work to support, also the unfail path is missing

                               #     elsif (  $how2fail eq "BEPULL" ||  $how2fail eq "FEPULL"  )
                               #     {
                               #         # generic external function handler
                               #         $ret = ExtControl($i, $how2fail, "FAIL" , $fCtlPtr);
                               #         if ( $ret == ERROR )
                               #         {
                               #             logError(">>>>>>>> Failed to externally fail the controller [$failCount failovers completed]  <<<<<<<<");
                               #             return ERROR;
                               #         }
                               #
                               #     }

                    else
                    {
                        # other forms of failure here

                        $j = WhichCtlr ($$resPtr[$i]->{SERIALNUM}, $snPtr);

                        $ret = FailOverController($coPtr, $j, $how2fail);
                        if ( $ret == ERROR )
                        {
                            logError(">>>>>>>> Could not fail the controller [$failCount failovers completed]  <<<<<<<<");
                            return ERROR;
                        }
                    }
                }


                #
                # Now update the fail count and state for this item
                #
                  
                $$resPtr[$i]->{NUMFAILS} = $$resPtr[$i]->{NUMFAILS} + 1;  
                $$resPtr[$i]->{STATE} = NWF_FAILED;  


                #
                # if it was a controller, add it to the deadlist. Do this
                # by matching the serial numbers. Search until first match.
                #


                for ( $j = 0; $j < scalar(@$snPtr); $j++ )
                {
                    #print "Checking $$snPtr[$j] against  $$resPtr[$i]->{SERIALNUM} \n";
                
                    if ( $$snPtr[$j] == $$resPtr[$i]->{SERIALNUM} )
                    {
                        push(@deadList, $j);
                        last;
                    }
                }
                
                #
                # Since we are doing staggered, we get to do the timeline here.
                # The duration of the timeline is also the time between 
                # failures.
                #
            
                logInfo("Timeline after failing a controller [$failCount failovers completed]");
                TestLibs::Validate::FailOverTimeLineNway( $coPtr, $timelineDuration, $snPtr, \@deadList);

                #
                # Add a check to verify that the failed controllers in the VCG are 
                # those that we failed and there were no additional volunteers.
                #


                $ret = VCGInfoCheck2($coPtr, $resPtr);
                if ( $ret != GOOD )
                {
                    logInfo("VCG controller state check has failed.");
                    return ERROR;
                }



            }  # end of if 'to be failed'


        }   # end of resource list item loop

    } # end of if staggered

    #
    # If not doing staggered, we are going to power off all things as 
    # close together as possible. The requires us to aggregate the 
    # failing items and minimize the calls to power control. These failures
    # will all be the power off type.
    #

    if ( $doStaggered == 0 )
    {
        logInfo("Timeline after failing controller(s) [$failCount failovers completed]");


        #        
        # Now we determine which things will be turned off. This also
        # generates a list of power controller IP and channels to use.
        # We aggregate the channels for each controller so that the 
        # power changes occur as close together as possible.
        # 
        
        #    my @moxaList;        # power controller IP addresses
        #    my @moxaChans;       # channels for each controller
        #    my @goodList;        # list of object list indices (currently good)
        #    my @failList;        # list of resource list indices (to be failed)
               

        IdentifyThingsToTurnOff($resPtr, 
                                \@moxaList,
                                \@moxaChans,
                                \@goodList,
                                \@failList);

        #
        # We want to log what we are going to fail to each of the 
        # controllers and their debug consols. So, get a list of current 
        # known good controllers and then send a message to each.
        #
        
        $msg = "";
        
        for ($i = 0; $i < scalar(@failList); $i++)
        {
            $msg .= " ".$$resPtr[$failList[$i]]{IPADDR};
        }

        CtlrLogTextList($coPtr, 
                        \@goodList, 
                        "Simultaneous power off of controllers".$msg );


        #
        # Now we walk the list created above which will turn off things.
        #


        for ( $i = 0; $i < scalar(@moxaList); $i++ )
        {
            # brute force power cycle handled here
            $ret = TestLibs::IntegCCBELib::PowerChange($moxaList[$i], $moxaChans[$i], 0);
            if ( $ret == ERROR )
            {
                logError(">>>>>>>> Failed to power down item(s) [$failCount failovers completed]  <<<<<<<<");
                return ERROR;
            }
        }

        #
        # Now update the fail count and state for these items. The 
        # List of what was failed was generatd above.
        #
                  
        for ( $i = 0; $i < scalar(@failList); $i++ )
        {
                $$resPtr[$failList[$i]]->{NUMFAILS} = $$resPtr[$failList[$i]]->{NUMFAILS} + 1;  
                $$resPtr[$failList[$i]]->{STATE} = NWF_FAILED;  
        }



        #
        # if it was a controller, add it to the deadlist. Do this
        # by matching the serial numbers. Search until first match.
        # Loop thru what was failed to find controller, Then, loop
        # thru the SNs.
        #

        for ( $i = 0; $i < scalar(@failList); $i++ )
        {
            
            if ( $$resPtr[$i]->{TYPE} == NWF_CTLR )
            {
                for ( $j = 0; $j < scalar(@$snPtr); $j++ )
                {
                    #print "Checking $$snPtr[$j] against  $$resPtr[$failList[$i]]->{SERIALNUM} \n";
    
                    if ( $$snPtr[$j] == $$resPtr[$failList[$i]]->{SERIALNUM} )
                    {
                        push(@deadList, $j);                                   # this should equal faillist !!!
                        last;
                    }
                }
            }
        }
        
        #
        # Homework done for the failures, now do the timeline.
        #
        
        TestLibs::Validate::FailOverTimeLineNway( $coPtr, $timelineDuration, $snPtr, \@deadList);

        $ret = TestLibs::Validate::PScanReqdWait($coPtr, 0, 0);              # 2nd and 3rd parms are not used
        if ( $ret == ERROR )
        {
            logError(">>>>>>>> Error while waiting for parity scans to complete [$failCount failovers completed]  <<<<<<<<");
            return ERROR;
        }
    
        
        #
        # Need to build a new (current) good list for the call to testNreconnect all.
        #
        $ret = BuildGoodList($coPtr, $resPtr, \@goodCtlrList);
        
        $ret = TestNReconnectAll(\@goodCtlrList);
        if ( $ret != GOOD ) 
        { 
            logInfo("Failed to reconnect to controllers.");
            return ERROR; 
        }



    }   # end of if not staggered


    return GOOD;

}
#######################################################################################
sub BuildGoodList
{
    my ($coPtr, $resPtr, $dPtr) = @_;
   
    #
    # A routine to identify the good controllers in an n-way system. These are controllers
    # that are NWF_OK in the resource list (resPtr). We want to return the objectf for those
    # controllers in the destination array (dPtr). resPtr items are matched to objects 
    # (coPtr) by comparing serial numbers.
    #
     
   
    my $i;
    my $j;
    my $dlIndex = 0;
    
    #
    # Walk thru each resPtr item, looking for controllers that are good (OK)
    #
    for ( $i = 0; $i < scalar(@$resPtr); $i++ )
    {
        if ( $$resPtr[$i]->{TYPE} == NWF_CTLR && $$resPtr[$i]->{STATE} == NWF_OK )
        {
            #
            # Find the matching controller object
            #
            for ( $j = 0; $j < scalar(@$coPtr); $j++ )
            {


                if ( $$coPtr[$j]->{SERIAL_NUM} == $$resPtr[$i]->{SERIALNUM} )
                {
                    #
                    # copy object to output
                    # 
                    $$dPtr[$dlIndex] = $$coPtr[$j];
                    $dlIndex++;
                }
            }
        }
    }
    


}
#######################################################################################
sub  UnfailNonControllers
{

    #
    # Identify what is failed. This is done by looking in the resource list
    # for non-controllers that are in the failed state. 
    #

    #
    # If an item is failed, the only current unfail method is to turn power 
    # back on. We will go through the list and turn on all devices that
    # have been failed via a power-off. Typically only one device is failed
    # but for geo-raid, we will turn off an entire site and thus turn on
    # the entire site at once.
    #

#add code here to turn on all offed devices - no wait for ready


# update unfail counters

        #
        # Now update the unfail count for this controller
        #
                                    


    #
    # Once we have turned on the power we need to figure out when the 
    # device is fully back to life. This is probebly device specific, 
    # hence the variety of device types in the resource list.
    #


#add code here to determine when all devices are online again. do one at a time

# initial code will not fail non-controllers. this is a NOP function.    
return GOOD;    


}
#######################################################################################
=head2 NWFType2Name function

Converts an object type to a name

=cut

=over 1

=item Usage:

 my $rc = NWFType2Name( $type );
 
 where,
        $type   is an object type

=item Returns:

       $rc is test string for the type 

=item Description:
 
 Just a lookup.

=back

=cut

#######################################################################
sub NWFType2Name
{
    my ($type) = @_;

    if ( $type == NWF_CTLR)  { return "        Controller "; }
    if ( $type == NWF_DBAY)  { return "          Disk Bay "; }
    if ( $type == NWF_FEBSW) { return " FE Brocade Switch "; }
    if ( $type == NWF_BEBSW) { return " BE Brocade Switch "; }
    if ( $type == NWF_BEQSW) { return "  BE QLogic Switch "; }

    return  "       Unknown type";

}
#######################################################################

#######################################################################################
=head2 VCGInfoCheck function

Checks VCGInfo to make sure no controllers have failed.

=cut

=over 1

=item Usage:

 my $rc = VCGInfoCheck( $coPtr );
 
 where,
        $coPtr   is a pointer to list of controller objects

=item Returns:

       $rc is GOOD if all controllers show Operational 
              ERROR if any controller is not operational.

=item Description:
 
 Finds the master controller, gets vcgInfo, evaluates it. 

=back

=cut

#######################################################################
sub VCGInfoCheck
{
    my ($coPtr) = @_;

    my $master;
    my $retVal = GOOD;
    my %info;
    my $j;
    my $k;
    my $msg;

    #
    # find the master
    #
    
    $master = FindMaster( $coPtr);

    #
    # get vcginfo
    #

    %info = $$coPtr[$master]->vcgInfo(0);

    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get vcginfo from master <<<<<<<<");
        return (ERROR);
    }

    if (%info)
    {
        if ($info{STATUS} == PI_GOOD)
        {
            #
            # evaluate it
            #

            for ( $j = 0; $j < $info{VCG_MAX_NUM_CONTROLLERS}; $j++ )   
            {
                $msg = sprintf("VCGInfoCheck: ctlr: %2d, sn: 0x%8.8x, state: 0x%2.2x ",
                                $j,
                                $info{CONTROLLERS}[$j]{SERIAL_NUMBER},
                                $info{CONTROLLERS}[$j]{FAILURE_STATE});

                $k =  $info{CONTROLLERS}[$j]{FAILURE_STATE};

                if    ( $k == FD_STATE_UNUSED                   ) { $msg .= "(UNUSED                   )";}
                elsif ( $k == FD_STATE_FAILED                   ) { $msg .= "(FAILED                   )";}
                elsif ( $k == FD_STATE_OPERATIONAL              ) { $msg .= "(OPERATIONAL              )";}
                elsif ( $k == FD_STATE_POR                      ) { $msg .= "(POR                      )";}
                elsif ( $k == FD_STATE_ADD_CONTROLLER_TO_VCG    ) { $msg .= "(ADD_CONTROLLER_TO_VCG    )";}
                elsif ( $k == FD_STATE_STRANDED_CACHE_DATA      ) { $msg .= "(STRANDED_CACHE_DATA      )";}
                elsif ( $k == FD_STATE_FIRMWARE_UPDATE_INACTIVE ) { $msg .= "(FIRMWARE_UPDATE_INACTIVE )";}
                elsif ( $k == FD_STATE_FIRMWARE_UPDATE_ACTIVE   ) { $msg .= "(FIRMWARE_UPDATE_ACTIVE   )";}
                elsif ( $k == FD_STATE_UNFAIL_CONTROLLER        ) { $msg .= "(UNFAIL_CONTROLLER        )";}
                elsif ( $k == FD_STATE_VCG_SHUTDOWN             ) { $msg .= "(VCG_SHUTDOWN             )";}
                else                                              { $msg .= "(something else ($k)      )";}
                     
                logInfo ($msg);

                if (( $k != FD_STATE_OPERATIONAL ) &&
                    ( $k != FD_STATE_UNUSED )) 
                { 
                    $retVal = ERROR; 
                }

            }
        }
        else
        {
            logInfo(">>>>>>>> Error getting vcginfo from master <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
    }
    

    return $retVal;
    


}
#######################################################################################

#######################################################################################
=head2 VCGInfoCheck2 function

Checks VCGInfo to make sure that the failed controllers in the VCG match 
what we expect to see.

=cut

=over 1

=item Usage:

 my $rc = VCGInfoCheck2( $coPtr, $resPtr );
 
 where,
        $coPtr   is a pointer to list of controller objects
        $resPtr  is a pointer to the test resource list

=item Returns:

       $rc is GOOD if all controllers are good/bad as desired 
              ERROR if any controller is not in the correct state.

=item Description:
 
 Finds the master controller, gets vcgInfo, compares it to the
 flags in the resource list. 

=back

=cut

#######################################################################
sub VCGInfoCheck2
{
    my ($coPtr, $resPtr) = @_;

    my $master;
    my $retVal = GOOD;
    my %info;
    my $j;
    my $k;
    my $msg;
    my $expect;

    #
    # find the master
    #
    
    $master = FindMaster( $coPtr);

    logInfo("\nVCGinfo check verifying that the correct controllers appear failed");

    if ($master == INVALID)
    {
        logInfo("Failed to find the master controller, test fails.");
        return ERROR;
    }

    #
    # get vcginfo
    #

    %info = $$coPtr[$master]->vcgInfo(0);

    if ( ! %info  )
    {
        logInfo(">>>>>>>> Failed to get vcginfo from master <<<<<<<<");
        return (ERROR);
    }

    if (%info)
    {
        if ($info{STATUS} == PI_GOOD)
        {
            #
            # evaluate it
            #

            for ( $j = 0; $j < $info{VCG_MAX_NUM_CONTROLLERS}; $j++ )   
            {
                $msg = sprintf("VCGInfoCheck: ctlr: %2d, sn: 0x%8.8x, state: 0x%2.2x ",
                                $j,
                                $info{CONTROLLERS}[$j]{SERIAL_NUMBER},
                                $info{CONTROLLERS}[$j]{FAILURE_STATE});

                $k =  $info{CONTROLLERS}[$j]{FAILURE_STATE};

                if    ( $k == FD_STATE_UNUSED                   ) { $msg .= "(UNUSED                   )";}
                elsif ( $k == FD_STATE_FAILED                   ) { $msg .= "(FAILED                   )";}
                elsif ( $k == FD_STATE_OPERATIONAL              ) { $msg .= "(OPERATIONAL              )";}
                elsif ( $k == FD_STATE_POR                      ) { $msg .= "(POR                      )";}
                elsif ( $k == FD_STATE_ADD_CONTROLLER_TO_VCG    ) { $msg .= "(ADD_CONTROLLER_TO_VCG    )";}
                elsif ( $k == FD_STATE_STRANDED_CACHE_DATA      ) { $msg .= "(STRANDED_CACHE_DATA      )";}
                elsif ( $k == FD_STATE_FIRMWARE_UPDATE_INACTIVE ) { $msg .= "(FIRMWARE_UPDATE_INACTIVE )";}
                elsif ( $k == FD_STATE_FIRMWARE_UPDATE_ACTIVE   ) { $msg .= "(FIRMWARE_UPDATE_ACTIVE   )";}
                elsif ( $k == FD_STATE_UNFAIL_CONTROLLER        ) { $msg .= "(UNFAIL_CONTROLLER        )";}
                elsif ( $k == FD_STATE_VCG_SHUTDOWN             ) { $msg .= "(VCG_SHUTDOWN             )";}
                elsif ( $k == FD_STATE_INACTIVATED              ) { $msg .= "(VCG_INACTIVATED          )";}
                elsif ( $k == FD_STATE_ACTIVATE                 ) { $msg .= "(VCG_ACTIVATE             )";}
                elsif ( $k == FD_STATE_DISASTER_INACTIVE        ) { $msg .= "(VCG_DISASTER_INACTIVE    )";}
                else                                              { $msg .= "(something else ($k)      )";}
                     
                logInfo ($msg);

                #
                # Now compare the state to the corresponding entry in the
                # resource list. Get the expected state from the resource
                # list and then make the appropriate comparison to the 
                # vcg state
                #

                $expect = StateFromSN( $info{CONTROLLERS}[$j]{SERIAL_NUMBER}, $resPtr);


                if ($expect != INVALID)
                {
                    if ( ($k == FD_STATE_OPERATIONAL  && $expect == NWF_FAILED ) ||
                         ($k != FD_STATE_OPERATIONAL  && $expect == NWF_OK )     ||
                         ($k != FD_STATE_OPERATIONAL  && $expect == NWF_2FAIL ) )
                    { 
                        $msg = "              Failure: expected state is ";
                        if ($expect == NWF_OK ) 
                        {
                            $msg .= "OPERATIONAL.";
                        }
                        else
                        {
                            $msg .= "FAILED.";
                        }
                        logInfo($msg);

                        $retVal = ERROR; 
                    }
                }
            }
        }
        else
        {
            logInfo(">>>>>>>> Error getting vcginfo from master <<<<<<<<");
            PrintError(%info);
            return ERROR;
        }
    }
    
    logInfo(" ");

    return $retVal;
    


}
#######################################################################################
=head2 StateFromSN function

Scans the resource list and returns the state of the controller with a matching
serial number. Returns INVALID if no match.

=cut

=over 1

=item Usage:

 my $rc = StateFromSN( $serialnumber, $resPtr );
 
 where,
        $serialnumber is the serial number of a controller
        $resPtr       is a pointer to the test resource list

=item Returns:

       $rc is controller expected state if found in array 
              INVALID if no match found.

=item Description:
 
 Walks the list for a controller with a matching serial number. 

=back

=cut

###############################################
sub StateFromSN
{
    my ($serialnum, $resListPtr) = @_;
    my $href;
    my $role;
    my $i=0;
        
    #
    # walk the hash looking for a controller with the
    # matching serial number
    #
    
    for $href ( @$resListPtr ) 
    {
        if ( $href->{TYPE} == NWF_CTLR )
        {
            if ( $href->{SERIALNUM} == $serialnum )
            {
                return ( $href->{STATE} );
            }
        }
    }

    #
    # no match, return error
    #

    return (INVALID);

}
############################################### 
###############################################


###############################################
sub PrintResources
{
    my ($resListPtr) = @_;
    my $href;
    my $role;
    my $i=0;
        
    # prints the resource hash

    logInfo( "resources:\n");
    
    for $href ( @$resListPtr ) 
    {
        logInfo( "Array element $i:\n{ \n");
        for $role ( keys %$href ) 
        {
             logInfo("   $role=$href->{$role} \n");
        }
        logInfo("}\n\n");
        $i++;
    }
}
############################################### 

##############################################################################
#
#          Name: SuicideOKForController
#
#        Inputs: list of controller objects
#
#       Outputs: GOOD, if successful, ERROR otherwise
#
#  Globals Used: none
#
#   Description: sets the mode bit to let proc suicide#
#
##############################################################################
sub SuicideOKForController
{
    trace();
    my ($obj) = @_;

    my $i;

    my $bits = 0x00;           # 0 for M610 and later, 1 for m601 and before

    my $mask = 0x01;
    
    my %bitHash;

    
    if ($bits =~ /^0x/i) {
        $bits = oct $bits;
    }
    if ($mask =~ /^0x/i) {
        $mask = oct $mask;
    }
    
    $bitHash{CCB_BITS1}         =0;
    $bitHash{CCB_BITS_MASK1}    =0;
    $bitHash{PROC_BITS1}        =0;
    $bitHash{PROC_BITS2}        =0;
    $bitHash{PROC_BITS3}        =0;
    $bitHash{PROC_BITS4}        =0;
    $bitHash{PROC_BITS_MASK1}   =0;
    $bitHash{PROC_BITS_MASK2}   =0;
    $bitHash{PROC_BITS_MASK3}   =0;
    $bitHash{PROC_BITS_MASK4}   =0;

    
    $bitHash{PROC_BITS1}         =$bits;
    $bitHash{PROC_BITS_MASK1}    =$mask;

    # Randy recently added these
    $bitHash{CCB_BITS_DPRINTF}      = 0;
    $bitHash{CCB_BITS_DPRINTF_MASK} = 0;
    $bitHash{CCB_BITS_RSVD1}        = 0;
    $bitHash{CCB_BITS_RSVD1_MASK}   = 0;
    $bitHash{CCB_BITS_RSVD2}        = 0;
    $bitHash{CCB_BITS_RSVD2_MASK}   = 0;

    
    logInfo("Enabling proc suicide on controller $obj->{HOST}");


    my %rsp = $obj->modeDataSet(%bitHash);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from modeDataSet <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to set mode bits <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }
    
    return GOOD;
}


###############################################################################

=head2 DisableInactivatePowerOff function

This function sets the Wookiee Inactivate Controller Power-off Disable mode bit 
which prevents Wookiee controllers from powering off when they are inactivated.   

The bit will be restored to its default when the controller is power cycled.

=cut

=over 1

=item Usage:

 my $rc = DisableInactivatePowerOff( $ctlr );

 where: $ctlr - controller object
        
=item Returns:

        GOOD  - Function successful
        ERROR - Function failed

=item Things to look for:

 None

=item Initial Conditions:

 This is only needed for Wookiee controllers. 

=back

=cut

##############################################################################
#
#          Name: DisableInactivatePowerOff
#
##############################################################################
sub DisableInactivatePowerOff
{
    trace();
    my ($ctlr) = @_;

    my $i;
    my %bitHash;

    #
    # bits and mask for Wookiee Inactivate Controller Power-off Disable bit
    # 
    my $bits = 0x1000;           
    my $mask = 0x1000;

    
    if ($bits =~ /^0x/i) {
        $bits = oct $bits;
    }
    if ($mask =~ /^0x/i) {
        $mask = oct $mask;
    }
    
    $bitHash{CCB_BITS1}         =0;
    $bitHash{CCB_BITS_MASK1}    =0;
    $bitHash{PROC_BITS1}        =0;
    $bitHash{PROC_BITS2}        =0;
    $bitHash{PROC_BITS3}        =0;
    $bitHash{PROC_BITS4}        =0;
    $bitHash{PROC_BITS_MASK1}   =0;
    $bitHash{PROC_BITS_MASK2}   =0;
    $bitHash{PROC_BITS_MASK3}   =0;
    $bitHash{PROC_BITS_MASK4}   =0;

    
    $bitHash{CCB_BITS1}         =$bits;
    $bitHash{CCB_BITS_MASK1}    =$mask;

    # Randy recently added these
    $bitHash{CCB_BITS_DPRINTF}      = 0;
    $bitHash{CCB_BITS_DPRINTF_MASK} = 0;
    $bitHash{CCB_BITS_RSVD1}        = 0;
    $bitHash{CCB_BITS_RSVD1_MASK}   = 0;
    $bitHash{CCB_BITS_RSVD2}        = 0;
    $bitHash{CCB_BITS_RSVD2_MASK}   = 0;

    
    logInfo("Disabling Wookiee Inactivate Controller Power-off on controller $ctlr->{HOST}");


    my %rsp = $ctlr->modeDataSet(%bitHash);

    if ( ! %rsp  )
    {
        logInfo(">>>>>>>> Failed to get response from modeDataSet <<<<<<<<");
        return ERROR;
    }

    if ($rsp{STATUS} != PI_GOOD)
    {
        logInfo(">>>>>>>> Unable to set mode bits <<<<<<<<");
        PrintError(%rsp);
        return ERROR;
    }
    
    return GOOD;
}

##############################################################################
#
#          Name: IdentifyThingsToTurnOff
#
#        Inputs: pointers to resource list and (4) output lists
#
#       Outputs: nothing
#
#  Globals Used: none
#
#   Description: walk the resource list and identify good controllers and
#                things to run off. Aggregate the moxa information so that
#                minimal calls to PowerChage are done.
#
##############################################################################
sub IdentifyThingsToTurnOff
{
    my ($resPtr, 
        $moxaListPtr,
        $moxaChanPtr,
        $goodListPtr,
        $failListPtr) = @_;

    my $i;
    my $j;
    my $thisMoxa;
    my $thisChan;
    my $found;
    my $numIPs;

    #
    # go thru each of the resource list items. If the item is to be failed
    # add it to the appropriate lists. If it is a controller add it to 
    # the appropriate lists
    #

    for ( $i = 0; $i < scalar(@$resPtr); $i++ )
    {

        #
        # if NOT FAILED and it is a controller, add to the good list
        # (This is controllers that are good before we begin to fail
        #
        if ( $$resPtr[$i]->{STATE} != NWF_FAILED )
        {
            if ( $$resPtr[$i]->{TYPE} == NWF_CTLR  )
            {
                push( @$goodListPtr, $i);
            }
        }

        #
        # If this item is TO BE FAILED, then add to the fail list and
        # take care of the moxa information
        #
        if (  $$resPtr[$i]->{STATE} == NWF_2FAIL )
        {
            push( @$failListPtr, $i);

            $thisMoxa =  $$resPtr[$i]->{MOXAIP};   
            $thisChan =  $$resPtr[$i]->{MOXACHAN};
             
            # sort out moxa info
            
            $found = 0;
            $numIPs = scalar(@$moxaListPtr);

            for ( $j = 0; $j < $numIPs; $j++ )
            {
                if ( $$moxaListPtr[$j] eq $thisMoxa )
                {
                    $found = 1;
                    $$moxaChanPtr[$j] .=  $thisChan;       
                }
            }
            if ( $found == 0 )
            {
                $$moxaListPtr[$numIPs] = $thisMoxa;
                $$moxaChanPtr[$numIPs] = $thisChan;
            }

        }
    }
        
        
}
#######################################################################################

##############################################################################
#
#          Name: GetGoodCtlrs
#
#        Inputs: pointers to resource list and output list
#
#       Outputs: nothing
#
#  Globals Used: none
#
#   Description: walk the resource list and identify good controllers 
#
##############################################################################
sub GetGoodCtlrs
{
    my ($resPtr, $goodListPtr) = @_;

    my $i;
    my $thisMoxa;
    my $thisChan;
    my $found;
    my $numIPs;

    #
    # go thru each of the resource list items. If the item is to be failed
    # add it to the appropriate lists. If it is a controller add it to 
    # the appropriate lists
    #

    for ( $i = 0; $i < scalar(@$resPtr); $i++ )
    {

        #
        # if NOT FAILED and it is a controller, add to the good list
        # (This is controllers that are good before we begin to fail
        #
        if ( $$resPtr[$i]->{STATE} != NWF_FAILED )
        {
            if ( $$resPtr[$i]->{TYPE} == NWF_CTLR  )
            {
                push( @$goodListPtr, $i);
            }
        }

    }
        
        
}


##############################################################################

sub GetLiveObjects
{
    my ($coPtr, $dlPtr, $loPtr) = @_;

    my $i;
    my $j;
    my $k;
    my $isBad;
    
    $k = 0;
    
    
    for ($i = 0; $i < scalar(@$coPtr); $i++ )
    {
        $isBad = 0;
        for ( $j = 0; $j < scalar(@$dlPtr); $j++ )
        {
            if ( $i == $$dlPtr[$j] )
            {
                $isBad = 1;
                last;
            }
        }
        
        if ( $isBad == 0 )
        {
            $$loPtr[$k] = $$coPtr[$i];
        }
    }
    
    
}    

#######################################################################################

1;   # we need this for a PM

__END__

#######################################################################################

=head1 CHANGELOG

 $Log$
 Revision 1.4  2006/09/20 13:56:26  EidenN
 tbolt00000000:
 Added CleanUpUnFailAll sub to check for a failed controller at the start of the test and unfail it.

 Revision 1.3  2006/09/07 16:37:17  RustadM
 TBolt00000000 - Merge OPENISCSI649_BR branch to HEAD.

 Revision 1.2  2006/08/29 15:04:08  ElvesterN
 TBolt00015574 - Changed call to displayError to reference the full path.

 Revision 1.1.1.1.46.1  2006/09/05 18:16:20  RustadM
 TBolt00000000 - Update to F104 build.

 Revision 1.1.1.1  2005/05/04 18:53:52  RysavyR
 import CT1_BR to shared/Wookiee

 Revision 1.17  2005/01/28 16:30:20  PalmiD
 TBolt00000000: Index variable name change to prevent conflict with outer loop
 variable of same name.
 Reviewed by Craig Menning.

 Revision 1.16  2005/01/17 16:32:08  PalmiD
 TBolt00000000: Fixed typo.
 Reviewed by Craig Menning.

 Revision 1.15  2005/01/04 17:28:03  KohlmeyerA
 Tbolt00000000:  Added code to use new mode setting to prevent controller from powering
 down when a controller is inactivated.  Reviewed by Craig.

 Revision 1.14  2004/11/09 21:37:49  MenningC
 TBOLT00000000: fix for mirror resync wait and syswrite problem. Reviewed by Al

 Revision 1.13  2004/08/06 21:39:36  WaggieL
 Handle the case where we're licensed for more controllers than exist in the current DSC (e.g. 4-way license, but only 2 controllers added, with 2 "unused" slots).
 Coded/reviewed by Craig & Lynn.

 Revision 1.12  2004/06/16 16:18:40  MenningC
 Tbolt00000000: fix some function paths, reviewed by Al

 Revision 1.11  2004/05/07 19:14:07  KohlmeyerA
 Tbolt00000000 - Added PC to possible methods for RND option in MakeVdisks.  Reviewed by Craig

 Revision 1.10  2004/04/29 17:00:04  MenningC
 tbolt00000000: added a test and reconnect, reviewed by Al

 Revision 1.9  2004/04/26 19:04:46  MenningC
 tbolt00000000: added menu items in single item menu, added wait for pscan required bit to clear, reviewed by Al

 Revision 1.8  2004/04/14 18:06:54  MenningC
 tbolt00000000: added check for a missing master, reviewed by Al

 Revision 1.7  2004/02/25 17:58:23  MenningC
 tbolt00000000:Additional output and changes requested by Chris. reviewed by Al

 Revision 1.6  2004/02/05 19:54:09  MenningC
 tbolt00000000: new power control script and related changes; reviewed by Al.

 Revision 1.5  2004/01/27 19:52:41  MenningC
 TBOLT00000000:changes for readability and additional data collection.
 Reviewed by Al

 Revision 1.4  2004/01/19 22:49:52  MenningC
 TBOLT00000000:added vcg inactivate controller (IC) as a failure mechanism; reviewed by Carlos.

 Revision 1.3  2003/12/30 14:08:58  MenningC
 TBOLT00000000: Additions for nwayfailover

 Revision 1.2  2003/12/23 20:48:14  MenningC
 TBOLT00000000: Additions for the nway failover test. Reviewed by Olga

 Revision 1.1  2003/04/15 19:11:46  MenningC
 tbolt00000000: broke failover into two parts, fixed links; reviewed by JW


=cut
